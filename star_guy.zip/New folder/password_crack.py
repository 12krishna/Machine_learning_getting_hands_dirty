filename = 'X:\Data_Analytics\Positions\ML_20181206_bkp.xlsx'
import sys
import win32com.client
xlApp = win32com.client.Dispatch("Excel.Application")



xlwb = xlApp.Workbooks.Open(filename, True, True, None, Password= 'ML123')
# xlwb = xlApp.Workbooks.Open(filename)
xlws = xlwb.Sheets(1) # counts from 1, not from 0
content = xlws.Range("A:D").Value 

# Transfer content to pandas dataframe
dataframe = pd.DataFrame(list(content))
dataframe.dropna(how='all', inplace=True)
# create header
dataframe.columns = dataframe.iloc[0]
dataframe.reindex(dataframe.index.drop(0))
