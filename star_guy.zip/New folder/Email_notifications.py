import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
#from dateutil import parser 
#import re
import os 

MY_ADDRESS = 'Notifications@kotak.com'
to_add = 'krishna.yadav@kotak.com'  
server = '172.17.9.149'; port = 25

output_dir = "X:\\Data_Analytics\\Emails\\Output\\Bhavcopies_notification\\"


def email_notifier(subject, filename):   
    
    # set up the SMTP server
    s = smtplib.SMTP(server, port)    
    # For each contact, send the email:       
        
    msg = MIMEMultipart()       # create a message       
    
    # setup the parameters of the message
    msg['From']= MY_ADDRESS
    msg['To']=  to_add
            
    msg['Subject']= subject
            
    # add in the message body
    msg.attach(MIMEText('{} was successfully downloaded !'.format(filename), 'plain'))           
            
    # send the message via the server set up earlier.
    s.sendmail(MY_ADDRESS,to_add,msg.as_string())
    del msg
        
    # Terminate the SMTP session and close the connection
    s.quit()
    
                                    
    

 
def main():
   
    # loop through all the folders and send emails 
    for r, d, f in os.walk(output_dir):
        # traverse through all folders
        for filename in f:    
            if filename.startswith('fo'):
                subject = 'NSE Bhavcopy'
                #date = parser.parse(filename, fuzzy = True).date()
                email_notifier(subject, filename)
                os.remove(output_dir+filename)
            elif filename.startswith('cm'):
                subject = 'NSE Equities'
                #date = parser.parse(filename, fuzzy = True).date()
                email_notifier(subject, filename)
                os.remove(output_dir+filename)
            elif filename.startswith('MTO'):
                subject = 'NSE security wise delivery'
                #date = re.findall('\d+', filename)
                #date = parser.parse(date[0][:2]+' '+date[0][2:4]+' '+date[0][4:]).date()        
                email_notifier(subject, filename)
                os.remove(output_dir+filename)
            elif filename.startswith('SCBSEALL'):
                subject = 'BSE security wise delivery'
                #date = re.findall('\d+', filename)
                #date = parser.parse(date[0][:2]+' '+date[0][2:4]+' '+date[0][4:]).date()        
                email_notifier(subject, filename)
                os.remove(output_dir+filename)
            elif filename.startswith('EQ_ISINCODE'):
                subject = 'BSE bhavcopy'
                #date = parser.parse(filename, fuzzy = True, dayfirst = True).date()
                email_notifier(subject, filename)
                os.remove(output_dir+filename)
                
            
            
if __name__ == "__main__":
    main()
