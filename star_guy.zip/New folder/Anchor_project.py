import pandas as pd
#import numpy as np
#import os
from dateutil import parser
from collections import OrderedDict
from cassandra.cluster import Cluster
import logging 
from time import time
import datetime


input_dir = 'X:\\Data_Analytics\\BankNifty\\input\\'
output_dir = 'X:\\Data_Analytics\\BankNifty\\Output\\'
master_dir = 'X:\\Data_Analytics\\BankNifty\\Master\\'
log_path = "X:\\Data_Analytics\\BankNifty\\"

# log events in debug mode 
logging.basicConfig(filename=log_path+"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")



def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)


def get_values(min_date, max_date, key):
    '''Function to retrive values from cassandra db'''
    
    cluster = Cluster(['127.0.0.1'])
    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('test_df')
    logging.info('Using test_df keyspace')
    #define rows fetched from cassandra to be a pandas dataframe
    session.row_factory = pandas_factory
    session.default_fetch_size = None    

    query = 'SELECT * FROM test_bhavcopy WHERE price_date >= \'{0}\' AND price_date <= \'{1}\' AND key = \'{2}\'ALLOW FILTERING;'.format(
                        min_date,max_date,key)

    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    rows.drop(columns=['key','option_typ','strike_pr'], inplace=True)
    return rows
    
def anchor_buckets_func(value, anchor_date, days_index, symbol, df):
    '''Function to get bucket values'''
    
    dates = df['price_date']
    result = OrderedDict()
    # before anchor date
    anchor_value = df[df['price_date'] == anchor_date][value].values[0]
    
    for index in list(reversed(days_index)):
        try:
            result['X-{0}({1})'.format(index, value)] = df[df['price_date'] == dates[dates[dates == anchor_date].index[0] - index].date()][value].values[0] 
        except:
            logging.info('Not in index {0}'.format(index))
    

    result['X({0})'.format(value)] = anchor_value

    # after anchor date
    for index in days_index:
        try:
            result['X+{0}({1})'.format(index, value)] = df[df['price_date'] == dates[dates[dates == anchor_date].index[0] + index].date()][value].values[0] 
        except:
            logging.info('Not in index {0}'.format(index))

    res = pd.DataFrame(result, index=[anchor_date], columns=result.keys())
    
    return res


def min_max_calc(min_date, max_date, anchor_date):
    '''Func to handle absolute days for min and max dates'''
    min_date = min_date
    max_date = max_date
    if len(min_date)<=3:
        # handle abs days
        min_date = anchor_date - datetime.timedelta(days=int(min_date))
    else:
        try:
            min_date = parser.parse(min_date).date()
        except:
            logging.info('Out of range for current month')
        
    if len(max_date)<=3:
        #handle abs days
        max_date = anchor_date + datetime.timedelta(days=int(max_date))
    else:
        try:
            max_date = parser.parse(max_date).date()
        except:
            logging.info('Out of range for current month')
        
    return min_date, max_date
        
        


     


def main():
    
    # Get inputs
    symbol = str.upper('BANKNIFTY')
    anchor_dates = pd.read_excel(input_dir+'input.xlsx')    
    min_date, max_date = min(anchor_dates['Dates']).date() , max(anchor_dates['Dates']).date()
    
    anchor_dates['Dates'] = anchor_dates.apply(lambda row: row['Dates'].date(), axis=1)
    #min_date = raw_input('min date')
    #max_date = raw_input('max date')
    #min_date,max_date = min_max_calc(min_date, max_date, anchor_date)
    
    # fetch keys from master 
    keys = pd.read_excel(master_dir+'MasterData.xlsx')
    keys = keys[keys['IsActiveFNO']==True]
    keys.loc[keys['Type']=='SSF','instrument'] = 'FUTSTK'
    keys.loc[keys['Type']=='Index','instrument'] = 'FUTIDX'
    keys = keys['SYMBOL']+"_"+keys['instrument']+"_0.0_XX_1"
    
    # fetch key for symbol
    key = keys[keys.str.startswith(symbol+'_')].values[0]
    
    
    # get values from cassandra
    df = get_values(min_date,max_date,key)    
    days_index = [1]
    # get anchor+-1 close prices 
    close_df = pd.DataFrame()
    for anchor_date in anchor_dates['Dates']:
        close_df = close_df.append(anchor_buckets_func('close', anchor_date, days_index, symbol, df))
        
    close_df.index.name = symbol    
    # get anchor+-1 close prices
    open_df = pd.DataFrame()
    for anchor_date in anchor_dates['Dates']:
        open_df = open_df.append(anchor_buckets_func('open', anchor_date, days_index, symbol, df))
        
    open_df.index.name = symbol
    # get only X+1 open values 
    open_df = open_df[['X+1(open)']]
    # merge both the df
    final_df = close_df.merge(open_df, on=symbol)
    final_df.fillna(0, inplace=True)
    final_df.reset_index(inplace=True)
    
    
    # get report 
    report_df = pd.DataFrame(columns=['A_close to B-1_close','B-1_close to B_close', 'A+1_open to B-1_close' ])
    anchor_dates = final_df.index
    
    i = 0
    for anchor_date in final_df[symbol]:
        res = {}
        try:
             
            res['A_close to B-1_close'] = round(((final_df.iloc[i]['X-1(close)'] - final_df.iloc[i-1]['X(close)'])/final_df.iloc[i-1]['X(close)'])*100, 3)
            res['B-1_close to B_close'] = round(((final_df.iloc[i]['X(close)'] - final_df.iloc[i]['X-1(close)'])/final_df.iloc[i]['X-1(close)'])*100, 3)
            res['A+1_open to B-1_close'] = round(((final_df.iloc[i]['X-1(close)'] - final_df.iloc[i-1]['X+1(open)'])/final_df.iloc[i-1]['X+1(open)'])*100, 3)
            
        except:
            pass
        i += 1
        report_df = report_df.append(res, ignore_index=True)
       
        
    report_df[symbol] = final_df[symbol]
    
    expiry_dates = pd.read_excel(master_dir+'Expiry_dates_master.xlsx')
    expiry_dates = expiry_dates[expiry_dates['Expiry']=='E']
    expiry_dates['Dates'] = expiry_dates.apply(lambda row: parser.parse(str(row['Date'])+' '+row['Month']+' '+str(row['Year'])).date(), axis=1)
    # exclude expiry dates
    report_df = report_df[~report_df['BANKNIFTY'].isin(expiry_dates['Dates'].values)]
    
    
    report_df.set_index(symbol, inplace=True)
    report_df.fillna(0, inplace=True)
    # remove expiry dates from the report 
    expiry_dates = pd.read_excel(master_dir+'Expiry_dates_master.xlsx')
    
    report_df.to_csv(output_dir+'{0}_report.csv'.format(symbol))
    
    
    
    
start_time = time()

if __name__ == '__main__':
    main()

end_time = time()

logging.info('Time taken to process :'.format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)


          

    
