#import numpy as np 
import pandas as pd
import logging 
import time
from datetime import date, timedelta
import datetime
#import matplotlib.pyplot as plt 
import logging
import redis
#import zlib
#import os 


download_dir = "X:\\Data_Analytics\\Basis_Project\\5min_market_data\\"
master_dir = "X:\\Data_Analytics\\Basis_Project\\Master\\"
log_path = "X:\\Data_Analytics\\Basis_Project\\"


logging.basicConfig(filename=log_path+"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


        
              
            
if __name__ == '__main__':
    parameters_compute()     
        
        