#Copyright (c) 2017 Chinmay Hundekari
#See the file license.txt for copying permission.

#import urllib2
import datetime
from dateutil.relativedelta import relativedelta
import requests
import httplib, StringIO, zipfile
import os
import sys
from cassandra.cluster import Cluster
import logging
import pandas as pd 
from dateutil import parser


log_path = "X:\\Data_Analytics\\BSE\\"
equities_processed_files = "X:\\Data_Analytics\\BSE\\Processed_files\\Equities"
security_processed_files = "X:\\Data_Analytics\\BSE\\Processed_files\\Security_wise_delivery"

# log events in debug mode 
logging.basicConfig(filename=log_path+"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


class bseConnect:
    headers = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
               'Accept':'application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5',
               'Accept-Encoding':'gzip,deflate,sdch',
               'Referer':'https://www.bseindia.com'}

    url = "www.bseindia.com"
    
    def connect(self):
        response = requests.head('https://' + self.url)
        if response.status_code == 302:
            self.url = response.headers["Location"]
        
        self.url = self.url[self.url.find("//")+1:  ]
        self.conn = httplib.HTTPSConnection(self.url)
       
            
            
    def disconnect(self):
        self.conn.close()

    def getFilename(self, date, flag):
        [y, m, d] = self.convertDate(date)
        if flag==0:
            ''' Equities filename'''
            return "EQ_ISINCODE_%s%s%s.CSV" % (d, m, y[2:])
        elif flag==1:
            '''Securities filename'''
            return "SCBSEALL%s%s.txt" % (d, m)
            
        
            
        

    def convertDate(self, date):
        y = date.strftime("%Y")
        m = date.strftime("%m")
        d = date.strftime("%d")
        return [y, m, d]

    def getReqStr(self, date, flag):
        [y, m, d] = self.convertDate(date)
        
        if flag==0:
            # equities
            return "/download/BhavCopy/Equity/%s.ZIP" % (self.getFilename(date, flag)[:-4])
        elif flag==1:
            #securitites
            return "/BSEDATA/gross/%s/SCBSEALL%s%s.ZIP" % (y, d,m)
        

    def getResponse(self, reqstr):
        c = self.conn
        
        c.request("GET", reqstr, None, self.headers)
        response = c.getresponse()
        self.data = response.read()
        if response.status == 403:
            print "Response status is %s\tCould not download %s." % (response.status, reqstr)
            print "%s" % (self.data)
            return -1
        elif response.status == 404:
            print "File not found\tCould not download %s." % (reqstr)
            return -1
        elif response.status != 200:
            print "Response status is %s \tCould not download %s." % (response.status, reqstr)
            print "%s" % (self.data)
            return -1


def equities_cassandra_dumper(filename, date):
    '''Func to process downloaded equities csv file and dump the bhavcopy to cassandra db'''
    
    # read the equities csv file downloaded from BSE
    df = pd.read_csv(filename)    
    # drop all nan columns
    df.dropna(axis=1, how='all', inplace=True)
    if 'TDCLOINDI' in df.columns:
        df.drop(columns = ['TDCLOINDI'], inplace=True)
        
    # date format 
    df['TRADING_DATE'] = pd.to_datetime(df['TRADING_DATE'])
    df.fillna('NA', inplace=True)
    # dump file to cassandra db with temp.csv
    df.to_csv('temp.csv', index=False)   
    
    # dump csv file to cassandra db
    os.system('equitiesdump.bat')
    
def securities_cassandra_dumper(filename, date):
    '''Func to process securities file and dump to cassandra db'''

    # read txt file with delimeter into df
    df = pd.read_csv(filename, delimiter= "|")
    df['DATE']=date
    df.rename(columns={'DATE':'Traded_date'}, inplace=True)
    # write to temp csv to dump in cassandra db
    df.to_csv('temp.csv', index = False)
    
    # dump csv to cassandra
    os.system('securitiesdump.bat')
    
    
    
def filename_searcher(c,date):
    '''Func to lookup securities file in processed dir'''
    [y, m, d] = c.convertDate(date)
    
    filename = 'SCBSEALL%s%s%s.txt'%(d,m,y)
    if os.path.exists(os.path.join(security_processed_files, filename)):
        print 'File exist for {0}'.format(date)
        logging.info('File exist for {0}'.format(date))
        return True
    else:
        return False
    
    
    


def downloadCSV(c, date, flag):
    filename = c.getFilename(date, flag)
    reqstr = c.getReqStr(date, flag)
    [y, m, d] = c.convertDate(date)

    print "Downloading %s ..." % (filename)
    if c.getResponse(reqstr) == -1:
        return -1

    sdata = StringIO.StringIO(c.data)
    

    z = zipfile.ZipFile(sdata)
    try:
        csv = z.read(z.namelist()[0])
        
    
    except Exception as e:
        print "%s" % (format(e))
        return -1
    if not csv:
        print "Could not download %s." % (e.message)
        return -1
    else:
        if flag == 0:
            fil = open(os.path.join("Processed_files/Equities",filename), 'w')
            fil.write(csv)
            fil.close()
            # process and dump the csv file in cassandra db
            equities_cassandra_dumper(os.path.join("Processed_files/Equities",filename), date)  
            
            return 1
        if flag == 1:
            fil = open(os.path.join("Processed_files/Security_wise_delivery",'SCBSEALL%s%s%s.txt'%(d,m,y)), 'w')
            fil.write(csv)
            fil.close()
            # process and dump the csv file in cassandra db
            securities_cassandra_dumper(os.path.join("Processed_files/Security_wise_delivery",'SCBSEALL%s%s%s.txt'%(d,m,y)), date)  
            
            return 1



def getUpdate(c):
    '''Func to downlaod files and dump to cassandra db'''
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    cluster = Cluster(['127.0.0.1'])
    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('test_df')
    logging.info('Using test_df keyspace')
    '''
    # CREATE A TABLE; dump bhavcopies to this table
    session.execute('CREATE TABLE IF NOT EXISTS bse_equities (sc_code int,SC_NAME varchar, SC_GROUP varchar, SC_TYPE varchar, OPEN DECIMAL, HIGH DECIMAL,LOW DECIMAL, CLOSE DECIMAL, LAST DECIMAL, PREVCLOSE DECIMAL, NO_TRADES bigint, NO_OF_SHRS bigint, NET_TURNOV DECIMAL, isin_code varchar,trading_date DATE, PRIMARY KEY (sc_code, trading_date))')
    flag = 0 # download and dump equitites 
    errContinous = 0
    d = datetime.date.today()
    decr = datetime.timedelta(days=1)   
     
    while errContinous > -30 and (not os.path.exists(os.path.join(equities_processed_files,c.getFilename(d, flag)))):
        if d == parser.parse('2016 01 01').date():
            break
        if downloadCSV(c, d, flag) > -1:
            errContinous = 0
        else:
            errContinous -= 1
        d -= decr'''
       
    
    # CREATE A TABLE; dump bhavcopies to this table for securities
    session.execute('CREATE TABLE IF NOT EXISTS bse_securities (traded_date date, scrip_code int, delivery_qty int, delivery_val bigint ,day_volume bigint, day_turnover bigint, delv_per decimal, PRIMARY KEY (scrip_code, traded_date))')
        
    flag =1
    errContinous = 0
    d = datetime.date.today()
    decr = datetime.timedelta(days=1)   
     
    while errContinous > -30 and (not filename_searcher(c, d) ):
        if d == parser.parse('2016 01 01').date():
            break
        if downloadCSV(c, d, flag) > -1:
            errContinous = 0
        else:
            errContinous -= 1
        d -= decr
    
      
    


def _printUsage():
    print "Usage:"
    print "python getbhav.py -update \n\tUpdates bhav copy till last date found"
    

def main(args):
    c = bseConnect()
    c.connect()
    
    if args:
        if args[0] == "-update":
            getUpdate(c)        
        else:
            _printUsage()
    
    c.disconnect()

if __name__ == "__main__":
    main(sys.argv[1:])
