# hello.py
#import numpy as np
import xlwings as xw
import pandas as pd
import datetime 
#import matplotlib.pyplot as plt
import redis 
import win32api
import os



def get_timer(length):
    '''Func to get start and end times for processing '''
    
    time_buckets = [datetime.time(9,15),datetime.time(10,0),datetime.time(10,30),datetime.time(11,0),datetime.time(11,30),
                 datetime.time(12,0),datetime.time(12,30),datetime.time(13,0),datetime.time(13,30),datetime.time(14,0),
                 datetime.time(14,30),datetime.time(15,15)]
    
    time_range = [i for i in range(3,39,3)]
    
    if length in time_range:
        index =  time_range.index(length)
        return time_buckets[index],time_buckets[index+1]

    

def get_params():
    '''Func to display all the set params set by user from redis to excel'''

    # mock caller for debugging 
    xw.Book('X:\Data_Analytics\Basis_Project\TestXLWings.xlsm').set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()    
    # redis server connection
    r = redis.Redis(host='localhost', port=6379) 
    # get all redis keys for all the set params
    dividends = r.keys('*_dividend*')
    fa = r.keys('*_fa*')
    ra = r.keys('*_ra')
    df = pd.DataFrame({'Dividend':dividends, 'FA':fa, 'RA':ra })
    # get all symbols set so far
    symbols = set(df.apply(lambda row: row['FA'].split('_')[0] , axis=1))
    # get all the time frames 
    timeframes = set(df.apply(lambda row: '_'.join(row['FA'].split('_')[1:3]) , axis=1))
    
    result_df = pd.DataFrame()
    for time in list(sorted(timeframes)):
        result = []
        for symbol in list(sorted(symbols)):
            result.append({'symbol': symbol, 'Dividend': r.get('{}_{}_dividend'.format(symbol, time)),
                           'FA':r.get('{}_{}_fa'.format(symbol, time)),
                           'RA':r.get('{}_{}_ra'.format(symbol, time))})

        result = pd.DataFrame(result)
        result.set_index('symbol',inplace=True)
        result_df = pd.concat([result_df, result], axis=1)
        
    
    wb.sheets[1].range('A2').value = result_df    
    win32api.MessageBox(wb.app.hwnd, "Parameters imported!")      




def set_params():
    '''Func to fetch parameters from excel and write to redis'''
    
    # mock caller for debugging 
    xw.Book('X:\Data_Analytics\Basis_Project\TestXLWings.xlsm').set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()
    # Read entire excel data
    data = pd.DataFrame( wb.sheets[0].range('A3').expand('table').value )  # gets contents in list format with (symbol, div, FA, RA)
    # drop symbols that have no parameters set
    data.dropna(inplace=True)

    while len(data.columns)-1 != 0:
        
        # get start time and end times
        starttime, endtime = get_timer(len(data.columns)-1)           
        # read symbols
        symbols = data[0].values
        # parameters
        params = data.iloc[:, -3:]
        params.columns = ['dividend','fa','ra'] # set column names 
        params.index = symbols
        # redis server connection
        r = redis.Redis(host='localhost', port=6379)                  
    
        # write params to redis
        for symbol in symbols:
            r.set(symbol+'_'+str(starttime)[:-3]+'_'+str(endtime)[:-3]+'_'+'dividend', params.loc[symbol].values[0] )
            r.set(symbol+'_'+str(starttime)[:-3]+'_'+str(endtime)[:-3]+'_'+'fa', params.loc[symbol].values[1] )
            r.set(symbol+'_'+str(starttime)[:-3]+'_'+str(endtime)[:-3]+'_'+'ra', params.loc[symbol].values[2] )
            
        # update data
        data = data.iloc[:, :-3]        

    win32api.MessageBox(wb.app.hwnd, "Parameters Set!")
    #os.system('X:\\Data_Analytics\\Basis_Project\\compute.bat')
    
    
def result():
    '''Fetch results for set params'''
    
    # show result tab func 
    # mock caller for debugging 
    xw.Book('X:\Data_Analytics\Basis_Project\TestXLWings.xlsm').set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()
        
    df = pd.DataFrame( wb.sheets[0].range('A3').expand('table').value ) 
    symbols = list(df[0].values)   # display only those symbols that r set by user
    result = pd.DataFrame()
    result['Symbol'] = symbols
    # read result files from redis 
    r = redis.Redis(host='localhost', port=6379) 
    result_files = sorted(r.keys('*result*'))
    result_files = list(sorted([ x for x in result_files if x.startswith('result')])) # filter only result files 
    
    for res in result_files:
        # read the published msgpack
        df = pd.read_msgpack(r.get('{}'.format(res)))
        df = df[df.Symbol.isin(symbols)][['Symbol','dividend','FA','RA']]
        result = result.merge(df, on='Symbol', how='left')  
        
            
        
    result.set_index('Symbol', inplace=True)
    print result
    #wb.sheets[2].range('A2').value = 
    win32api.MessageBox(wb.app.hwnd, "Results imported!")    
        
        
        

        
        

