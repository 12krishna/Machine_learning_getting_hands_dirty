# hello.py
import numpy as np
import xlwings as xw
import pandas as pd
from nsepy import get_history
from cassandra.cluster import Cluster
import datetime as dt

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)
@xw.func
@xw.ret(expand='table')  # this makes it a dynamic array
def QDH(ticker, start_date=None, end_date=None):
    return get_history(symbol=ticker, start=start_date, end=end_date)

@xw.func
@xw.ret(expand='table')  # this makes it a dynamic array
def get_data():
	cluster = Cluster(['172.17.9.152'])
	session = cluster.connect('rohit')
	session.row_factory = pandas_factory
	session.default_fetch_size = 9995840
	query = "select * from sampledvwap where token(exchange,symbol) = token('NS','SEIN') and date >= '2017-03-31' and date <= '2017-03-31' allow filtering"
	rslt = session.execute(query, timeout = None)
	df2 = rslt._current_rows
	df2['date'] = str(df2['date'])
	df2['time'] = str(df2['time'])
	cluster.shutdown()
	return df2;
    