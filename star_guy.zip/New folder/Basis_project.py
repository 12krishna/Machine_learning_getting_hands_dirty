import numpy as np 
import pandas as pd
import logging 
#from dateutil import parser
import time
from datetime import date, timedelta
import datetime
#import matplotlib.pyplot as plt 
import logging
import redis
import zlib
import os 


download_dir = "X:\\Data_Analytics\\Basis_Project\\5min_market_data\\"
master_dir = "X:\\Data_Analytics\\Basis_Project\\Master\\"
log_path = "X:\\Data_Analytics\\Basis_Project\\"


logging.basicConfig(filename=log_path+"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")



def redis_key_generator():
    '''Generate all the keys needed for computation over a period of day '''
    
    # read master file for cash and fut codes 
    #symbols = pd.read_excel(master_dir+'PairMaster.xlsx')['Symbol']
    # redis server connection
    #r = redis.Redis(host='localhost', port=6379)
    #keys = []
    timekeys = []
    a = datetime.datetime(1,1,1,9,5)
    for i in range(77):
        a = a + datetime.timedelta(minutes=5)
        timekeys.append("{}{}".format(('0'+str(a.hour) if len(str(a.hour))==1 else str(a.hour)),
                                      ( '0'+str(a.minute) if len(str(a.minute))==1 else str(a.minute))))

    '''
    for symbol in symbols:
        for time in timekeys:
            keys.append(symbol+'.'+time)
            
    for key in keys:
        r.set(key, '') '''
        
    return timekeys


def gen_filename(timekeys):
    '''Generate filenames'''
    
    d = datetime.date.today()
    filename = []
    for timek in timekeys:
        filename.append( 'debug_log_mktdata_{}{}{}_{}.txt'.format(('0'+str(d.day) if len(str(d.day))==1 else str(d.day)),
                                                ('0'+str(d.month) if len(str(d.month))==1 else str(d.month)),
                                                str(d.year), timek ))
        
    return filename


def dateparse(row):
    '''Func to parse dates while reading ticker files'''
    d = row.split("+")[0]
    d = pd.to_datetime(d, format='%Y-%m-%d %H:%M:%S')
    return d
    

def aggregate_func(prices):
    '''Func to return max of volume traded and mean of LTP for 5 sec ticker data'''
    
    # read master file for cash and fut codes 
    pairmaster = pd.read_excel(master_dir+'PairMaster.xlsx')
    
    # loop through all securities in master file and generate stats:
    result = pd.DataFrame()
    for index, row in pairmaster.iterrows():
        try:            
            # filter for NFO and Futcode
            df = prices[prices['ExchangeSegment']=='NFO']
            df = df[df['SecurityCode']==row['FutCode']]       
            
            df['Symbol']=row['Symbol']            
            # groupby timegrouper        
            df = df.groupby(['Symbol', pd.Grouper(key='date', freq='5s')]).agg({'VolumeTraded':'max','LTP':'mean'})
            df['Exchange'] = 'NFO'
            result = result.append(df)
            
            # filter for NSE and Cashcode            
            df = prices[prices['ExchangeSegment']=='NSE']
            df = df[df['SecurityCode']==row['CashCode']]
            df['Symbol']=row['Symbol']            
            # groupby timegrouper        
            df = df.groupby(['Symbol', pd.Grouper(key='date', freq='5s')]).agg({'VolumeTraded':'max','LTP':'mean'})
            df['Exchange'] = 'NSE'
            result = result.append(df)         
            
        except Exception as e:
            print e            
            
    return result 

def summary_func(result):
    '''Func to generate summary data'''
    
    # cash df for NSE
    cash_df = result[result['Exchange']=='NSE']
    # fill na with forward pads i.e. copy value as it is in forward timestamp
    cash_df.fillna(method='pad', inplace=True)
    # difference of volume traded with cconsecutive time bound 
    cash_df['Volume_cash'] = cash_df.groupby('Symbol')['VolumeTraded'].diff()
    cash_df['Volume_cash'] = cash_df['Volume_cash'].fillna(cash_df['VolumeTraded'])

    fut_df = result[result['Exchange']=='NFO']
    # fill na with forward pads i.e. copy value as it is in forward timestamp
    fut_df.fillna(method='pad', inplace=True)
    # difference of volume traded with cconsecutive time bound 
    fut_df['Volume_fut'] = fut_df.groupby('Symbol')['VolumeTraded'].diff()
    fut_df['Volume_fut'] = fut_df['Volume_fut'].fillna(fut_df['VolumeTraded'])
    
    # merge cash and futures df
    temp = cash_df.reset_index().assign(key=cash_df.index.get_level_values(1)).merge(fut_df.reset_index().assign(key=fut_df.index.get_level_values(1)),
                                                                          on=['key','Symbol'], how='outer', suffixes=('_cash','_fut')).set_index(['Symbol']).drop(columns=['date_cash','date_fut','Exchange_cash','Exchange_fut'], axis=1)[['key','VolumeTraded_cash','LTP_cash','VolumeTraded_fut','LTP_fut','Volume_cash','Volume_fut']]

    temp.rename(columns={'key':'date'}, inplace=True)
    # fill non tarded time with zeros on merged df
    temp.fillna(0, inplace=True)

    # min of volume cash and future
    temp['cfvolume'] = temp[['Volume_cash','Volume_fut']].min(axis=1, numeric_only=True)
    
    # calc spread of price:ltp
    temp['spread_ab'] = temp['LTP_fut'] - temp['LTP_cash']
    # spread in 10,000 bps
    temp['spread_bps'] = temp['spread_ab']*10000/temp['LTP_cash']
    # replace inf with zeros; zero divison handling for cash=0
    temp.replace(np.inf, 0, inplace=True)
    
    return temp   
   
    
    
    
def ticker_generator(starttime,endtime, filename):
    '''Func to read 5 min logutility file and generate 5 sec ticker stats for volume traded and LTP for each symbol''' 
    
        
    cols = ['Date','Symbol','QtyBuy int','QtyBuy_2','QtyBuy_3','QtyBuy_4','QtyBuy_5','Bid','Bid_2','Bid_3','Bid_4','Bid_5','offer',
        'Offer_2','Offer_3','Offer_4','Offer_5','QtySell','QtySell_2','QtySell_3','QtySell_4','QtySell_5','VolumeTraded',
        'OpenPrice','Ccy', 'LTP','NumberOfOrdersBuy','NumberOfOrdersBuy_2','NumberOfOrdersBuy_3','NumberOfOrdersBuy_4',
        'NumberOfOrdersBuy_5','NumberOfOrdersSell','NumberOfOrdersSell_2','NumberOfOrdersSell_3','NumberOfOrdersSell_4',
        'NumberOfOrdersSell_5','LowerCircuitLimit','UpperCircuitLimit','HighPrice','LowPrice','ClosePrice','LTT timestamp',
        'NetChangeIndicator','LTQ','LotSize','OI','SecurityCode','ExchangeSegment','TradingSymbol']
    
    prices_df = pd.DataFrame(); prices_df_1 = pd.DataFrame()    
    
    try:  
        
        # read input file for every 5 sec data 
        prices_df = pd.read_csv(download_dir+filename[0],delimiter=',', engine='c',date_parser=dateparse, 
                                parse_dates={'date':[0]}, names=cols,skipinitialspace=True, low_memory=False )[['date','Symbol','VolumeTraded','LTP','SecurityCode','ExchangeSegment']]
        
        logging.info('Sucessfully read ticker file {}'.format(filename[0]))
        
    except Exception as e :
        logging.info('No file with name {}'.format(filename[0]))
        
        
    try:       
        print 'Processing : ',filename[1]
        prices_df_1 = pd.read_csv(download_dir+filename[1],delimiter=',', engine='c',date_parser=dateparse,
                                  parse_dates={'date':[0]}, names=cols,skipinitialspace=True, low_memory=False )[['date','Symbol','VolumeTraded','LTP','SecurityCode','ExchangeSegment']]
        
        logging.info('Sucessfully read ticker file {}'.format(filename[1]))
        
    except Exception as e :        
        logging.info('Exception: {} // No file with name {}'.format(e,filename[1]))
           
        

    # concat two dataframes
    prices_df = pd.concat([prices_df, prices_df_1], axis=0)
       
    # retain records between market hours and ignore rest
    prices_df['time'] = prices_df['date'].dt.time   
    prices = prices_df[ (prices_df['time']>= starttime ) & (prices_df['time']< endtime)]     
    
    # ignore codes with long codes
    prices = prices[ ~(prices.SecurityCode.str.len() > 6 ) ]

    # cpnvert to numeric
    prices['SecurityCode'] = pd.to_numeric(prices['SecurityCode'], errors='coerce') 
    prices.to_csv('ticker.csv')
    
    # final result 
    result = aggregate_func(prices)
    # get summary data for cashtill now and future till now;
    result = summary_func(result)
    
    return result
    
    

def parameters_compute():
    '''Func to fetch params from redis and process dumped files on redis to cal bps div, fa , ra'''   

    st = time.time()
    # redis server connection
    r = redis.Redis(host='localhost', port=6379) 
    # get all redis keys for all the set params
    dividends = list(sorted(r.keys('*_dividend*')))
    fa = list(sorted(r.keys('*_fa*')))
    ra = list(sorted(r.keys('*_ra')))
    if len(fa)==0 or len(ra)==0:
        print 'No parameters set in excel file !'
        return -1
        
    df = pd.DataFrame({'Dividend':dividends, 'FA':fa, 'RA':ra })
    # get all symbols from pairmaster file
    #symbols = set(df.apply(lambda row: row['FA'].split('_')[0] , axis=1))  symbols set so far
    symbols = list(sorted(pd.read_excel(master_dir+'PairMaster.xlsx')['Symbol'].values))
    # get all the time frames
    timeframes = sorted(set(df.apply(lambda row: '_'.join(row['FA'].split('_')[1:3]) , axis=1)))
    
    d = datetime.date.today()
    today_files = ''.join(['0'+str(d.day) if len(str(d.day))==1 else str(d.day)+'0'+str(d.month) if len(str(d.month))==1 else str(d.month),
             str(d.year)])
    today_files = sorted(r.keys('*{}*'.format(today_files)))
    today_files = [ x for x in today_files if not x.startswith('bpsresult') and not x.startswith('result') ] # take raw dumped files 
      
    
    if len(today_files)==0:
        print 'No raw ticker files are yet dumped in redis!'
        return -1
    
    # apply dividend, fa ,ra on files 
    file_indicator = 0 # for ignoring first file after first loop 
    for time_f in timeframes:
        
        i = [ i.replace(':','')  for i in time_f.split('_')]
        index = 0         
        try:
            index = [idx  for idx in range(len(today_files))  if today_files[idx].endswith(i[0]) or today_files[idx].endswith(i[1]) ]
            
        except Exception as e:
            print 'No raw ticker files dumped in backend for this time frame {}! : Error-{}'.format(time_f, e)
            return -1
        
        filenames = 0
        if len(index)==0:
            print 'No ticker files dumped in backend !'
            return -1
        
        if len(index) == 1:
            filenames = today_files[index[0]: ]   # fetch all the files avaliable till now; from start index time frame 
        else:
            filenames = today_files[index[0]: index[1]+1] # fetch files between time frame index
            
        df = pd.DataFrame()
        # pop first file if indicator is set during looping 
        if file_indicator==1:
            try:
                filenames.pop(0)
            except:
                pass
            
        print filenames
    
        for filename in filenames:
            # merge available files
            df_1 = pd.read_msgpack(r.get(filename))
            df = pd.concat([df, df_1], axis=0)
            
        # apply parametric operations on merged df 
        result = []
        if len(df)==0:
            # if no trading is done for 9:15 micro secs skip the process 
            return -1
        
        final_df = pd.DataFrame()
        for symbol in symbols:
            
            # get all the set params 
            div = r.get('{}_{}_dividend'.format(symbol, time_f))
            div = 1 if div == None else float(div) # convert div to float else set div to zero        
        
            fa = r.get('{}_{}_fa'.format(symbol, time_f))
            fa = 50 if fa == None else float(fa) # convert fa to float else set fa to default  
                        
            ra = r.get('{}_{}_ra'.format(symbol, time_f))
            ra = 10 if ra == None else float(ra) # convert ra to float else set div to default             
            
            try:                
                temp = df.loc[symbol] # filter on the symbol                
                # process on params 
                temp['spread_bps'] = temp.apply(lambda row: row['spread_bps'] + float(div)*10000/row['LTP_cash'] if row['LTP_cash']!=0 else 0, axis=1)
                
                final_df = final_df.append(temp)                
                sum_fa = temp[temp['spread_bps'] > float(fa)]['cfvolume'].sum() # filter on fa
                sum_ra = temp[temp['spread_bps'] < float(ra)]['cfvolume'].sum() # filter on ra  
                result.append([symbol, sum_fa, sum_ra])
            except :
                print 'Symbol {} was not traded...'.format(symbol)
            
        result = pd.DataFrame(result, columns=['Symbol','FA','RA'])
        result['dividend'] = div
        
        #result['timeframe'] = time_f
        #publish to redis 
        r.set('result_{}_{}'.format(today_files[0].split('_')[0],time_f), result.to_msgpack(compress='zlib'))
        r.set('bpsresult_{}_{}'.format(today_files[0].split('_')[0],time_f), final_df.to_msgpack(compress='zlib'))        
        file_indicator = 1 # skip first file now on..
        
    print 'Paramater computation time: {}'.format( time.time() - st )
    
    
    
    
def main():
    '''Func to read files, process and do scheduling of entire process'''
    
    # create redis keys
    timekeys = redis_key_generator()
    # get filenames to be processed over a time 
    files = gen_filename(timekeys)
    filenames = []
    for index, f in enumerate(files):
        try:
            filenames.append( [files[index-1], f] )
        except Exception as e:
            print 'Error'
            logging.info('Exception: {}'.format(e))
        
    filenames.pop(0)  
    
    # redis connection 
    r = redis.Redis(host='localhost', port=6379)
    
    for index, filename in enumerate(filenames):
        while not os.path.exists(download_dir+filename[1]):              
            print 'Resume after 10 secs'
            time.sleep(10)
        else:                 
            start = time.time()  
            result = ticker_generator(datetime.time(int(filenames[index-1][1].split('_')[-1].split('.')[0][:2]),
                                           int(filenames[index-1][1].split('_')[-1].split('.')[0][2:]) ),
                             datetime.time(int(filenames[index][1].split('_')[-1].split('.')[0][:2]), 
                                           int(filenames[index][1].split('_')[-1].split('.')[0][2:]) )
                             ,filename)           
            
            r.set('{}'.format('_'.join(filename[1].split('_')[-2:])[:-4]), result.to_msgpack(compress='zlib'))
            print 'Ticker data processing time : {}'.format(time.time()-start)
            
            #res = pd.read_msgpack(r.get('df'))      
            # process in backend for all avilable params ; this is executed once the new file is available else the system sleeps
            parameters_compute()
                 
                
    # delete all keys from redis db
    #r.flushall()

if __name__ == '__main__':
    main()

#print "Execution time: {0} Seconds.... ".format(end_time - start_time)