import pandas as pd
#from dateutil import parser
from cassandra.cluster import Cluster
#import cassandra
import logging 
from time import time
import datetime
import Cassandra_dumper
#import numpy as np 
import shutil



download_dir = "X:\\Data_Analytics\\FNO\\Download\\"
master_dir = "X:\\Data_Analytics\\FNO\\Master\\"
log_path = "X:\\Data_Analytics\\FNO\\"
output_dir = "X:\Data_Analytics\FNO\Output\\"
report_dir = "X:\\Data_Analytics\\Emails\\Output\\Daily_Descriptive_reports\\"
# log events in debug mode 
logging.basicConfig(filename=log_path+"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)


def instu(row):
    row = row.split('_')
    return row[1]

def sym(row):
    row = row.split('_')
    return row[0]

def descriptive_func(bhav_copy,keys):
    '''Function to get Min Max Avg 95% 97% 5% 3% for individual stocks'''      
 
    logging.info('Generating report for OPEN_INT...Min/Max/Avg/95%/97%/5%/3%')
    result = []
    # current date
    current_date = sorted(bhav_copy['price_date'], reverse = True)[0]
    logging.info('Processing for current date: {0}'.format(current_date.date()))
        
    for key in keys:
        current_OI = 0
        near_month_OI = 0
            
        # drop rows with zero current OI
        stock = bhav_copy[(bhav_copy['key']==key) & (~(bhav_copy['open_int']==0))]
        #current OI
        if len(stock[stock['price_date']==current_date ]) == 0:  
            logging.info('{0} is newly traded/removed from FNO...'.format(key.split("_")[0]))
            current_OI = 0
            near_month_OI = 0
            total_OI = 0
        else:
            current_OI = int(stock[stock['price_date']==current_date]['open_int'].values[0])
            near_month_OI = int(stock[stock['price_date']==current_date]['near_month_OI'].values[0])
            total_OI = current_OI + near_month_OI
            
        Range_percentile = 0       
        try:
            # convert to int and get the percentiles with describe method
            count,mi,ma,avg,per95,per97,per5,per3 = stock['Total_OI'].astype(int).describe(
                percentiles=[.95,.97,.05,.03]).loc[['count','min','max','mean','95%','97%','5%','3%']].values 
                
            if ma-mi == 0:
                Range_percentile = 0
            else:
                #Range_percentile = "{0:.0%}".format( (current_OI - mi) / (ma-mi) )
                Range_percentile = round((total_OI - mi)*100 / (ma-mi),2)
                    
                
                
        except Exception as e:
            logging.info('{0}'.format(e))
            logging.info('{0} Traded newly with OI zero...'.format(key.split("_")[0]))
            
            
        result.append([key,count,mi,ma,avg,per95,per97,per5,per3,current_OI,Range_percentile,near_month_OI, total_OI])                         
                              
                          
    result = pd.DataFrame(result, columns=['key','Days_traded','Min','Max','Avg','95%','97%','5%','3%','Current_OI','Range_percentile_%','Near_month_OI','Total_OI']) 
    # get symbol from key
    result['SYMBOL'] = result.apply(lambda row: sym(row['key']), axis=1)
    # get instruments
    result['INSTRUMENT'] = result.apply(lambda row: instu(row['key']), axis=1)
    # drop key
    result.drop('key',inplace=True, axis=1)
    # write the report to excel 
    result = result[['SYMBOL','INSTRUMENT','Days_traded','Total_OI','Range_percentile_%','Min','Max','Avg','95%','97%','5%','3%','Current_OI','Near_month_OI']]
        
    #result = result.style.apply(highlight_greater, axis=1)
    #result = result.style.applymap(highlight_cols, subset=pd.IndexSlice[:, ['Range_percentile']])
    #result = result.costyle.apply(background_gradient, axis = 1, columns=['Range_percentile'])
    result = result.sort_values(ascending=False, by=['Range_percentile_%'])
    result = result.style.background_gradient(cmap='RdBu', subset = pd.IndexSlice[:, ['Range_percentile_%']])
    
    result.to_excel(output_dir+'Descriptive_report.xlsx', index=False)
    #return result
    logging.info('Descriptive report generated successfully in excel...')
    
    
    
    
    
def cassandra_get_df(keys):
    '''Function to fetch values from cassandra db'''
    logging.info('Fetching values from cassandra')
    cluster = Cluster(['127.0.0.1'])
    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('test_df')
    logging.info('Using test_df keyspace')
    #define rows fetched from cassandra to be a pandas dataframe
    session.row_factory = pandas_factory
    session.default_fetch_size = None    
    
    # create empty dataframe 
    bhav_copy = pd.DataFrame()

    for key in keys:

        query = 'SELECT symbol,instrument,open_int,key,price_date,expiry_dt FROM test_bhavcopy WHERE price_date >= \'{0}\' AND price_date <= \'{1}\' AND key = \'{2}\'ALLOW FILTERING;'.format(
                    datetime.datetime.now().date() - datetime.timedelta(days=365),datetime.datetime.now().date(),key)
        rows = session.execute(query, timeout = None)
        rows = rows._current_rows

        if len(rows)==0:
            pass
        else :
            bhav_copy = bhav_copy.append(rows,ignore_index=True)
    bhav_copy.to_excel('test.xlsx')
    return bhav_copy

        
def dataframe_merger(current_month,near_month):
    '''Function to merge current_OI and near month_OI dataframes'''
    
    # process current_oi df to perform merge on
    # key is key_price date
    current_month['index_key'] = current_month.apply(lambda row: str(row['price_date']), axis=1)
    current_month['merge'] = current_month['key']+'_'+current_month['index_key']
    current_month.drop(columns=['index_key'], inplace=True)

    # process nea_month_oi to perfrom merge on
    near_month['index_key'] = near_month.apply(lambda row: str(row['price_date']), axis=1)
    near_month['merge'] = near_month['key']+'_'+near_month['index_key']
    near_month.drop(columns=['price_date','index_key','key'], inplace=True)

    # perform merge
    df = current_month.merge(near_month, on='merge', how='left')
    # replace NaN with zeros for symbols that werent traded on near_month_OI
    df.fillna(0, inplace=True)
    # total_OI
    df['Total_OI'] = df['open_int']+df['near_month_OI']
    # drop merger key
    df.drop(columns=['merge'], inplace=True)
    
    return df 
    




def main():
    '''Main function'''
    
    Cassandra_dumper.cassandra_dumper()
    
    logging.info('Read master file to fetch Active FNO symbols and generate keys...')
    keys = pd.read_excel(master_dir+'MasterData.xlsx')
    keys = keys[keys['IsActiveFNO']==True]
    keys.loc[keys['Type']=='SSF','instrument'] = 'FUTSTK'
    keys.loc[keys['Type']=='Index','instrument'] = 'FUTIDX'
    keys = keys['SYMBOL']+"_"+keys['instrument']+"_0.0_XX_1"
    
    # Fetch values from cassandra for Current_OI
    current_OI_df = cassandra_get_df(keys)
    
    # get near month OI from cassandra
    keys_near_month = keys.str.replace('_1','_2')
    near_month_df = cassandra_get_df(keys_near_month)
    near_month_df = near_month_df[['key','open_int','price_date']]          
            
    #replace back to og key to perfrom merge
    near_month_df['key'] = near_month_df['key'].str.replace('_2','_1')
    #rename open_int into near_month_oi
    near_month_df.rename(columns = {'open_int':'near_month_OI'},inplace=True)
    
    bhav_copy = dataframe_merger(current_OI_df, near_month_df)       
    
    logging.info('Calling descriptive func to process descriptive stats') 
    descriptive_func(bhav_copy,keys)
    shutil.copyfile(output_dir+'Descriptive_report.xlsx', report_dir+'Descriptive_report.xlsx')
    
    
        
start_time = time()

if __name__ == '__main__':
    main()

end_time = time()

logging.info('Time taken to process :'.format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)


          
