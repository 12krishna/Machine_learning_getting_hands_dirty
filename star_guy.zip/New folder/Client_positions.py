import numpy as np 
import pandas as pd
import logging 
from dateutil import parser
from time import time
import os
#import xlsxwriter
#from xlsxwriter.utility import xl_rowcol_to_cell
from dateutil import parser
import datetime
from datetime import timedelta
#import sys
import win32com.client
import shutil

input_dir = "X:\\Data_Analytics\\Positions\\Input\\"
master_dir = "X:\\Data_Analytics\\Positions\\Master\\"
log_path = "X:\\Data_Analytics\\Positions\\"
output_dir = "X:\\Data_Analytics\\Positions\\Output\\"
email_dir = "X:\\Data_Analytics\\Emails\\Output\\Positioning_reports\\"


def pre_process(excel_file,expiry_encoders,fut_stocks,exclude):
    '''func to pre process input files'''
    
    df = pd.read_excel(input_dir+excel_file)
    # convert date to datetime format
    df['Transaction Date'] = df.apply(lambda row: pd.to_datetime(row['Transaction Date'], format='%d-%b-%Y'), axis=1)
    df['Expiry'] = df.apply(lambda row: parser.parse(row['Expiry']) , axis=1)
    
    # fetch only near month expiry
    expiry_encoders = expiry_encoders[['Date','Expiry1']]
    
    # fetch current date from poisitoning
    current_date = df['Transaction Date'][0]
  
    # fetch near expiry for current date
   
    try:
        near_expiry = pd.to_datetime(expiry_encoders[expiry_encoders['Date']==current_date]['Expiry1'].values[0])  
     
        df = df[df['Expiry'] == near_expiry]
        
        logging.info('Near Expiry for current month is {0}'.format(near_expiry))
    except Exception as e:
        print e
        logging.info(e)
        logging.info('Expiry master has no near expiry month for current date {0}'.format(current_date))
    # filter only near expiry stocks
    
    
    
    #Filter only active stocks from master file
    df = df[df['Symbol'].isin(fut_stocks['SYMBOL']) ]
    logging.info('{0} Stocks were excluded, since not present in master file'.format(df[~df['Symbol'].isin(fut_stocks['SYMBOL']) ]))
    # exclude stocks from exclude list
    df = df[~df['Client Id'].isin(exclude)]
    
    # Convert SELL stocks to negative quantity
    df['Traded lots'] = df.apply(lambda row: -1*row['Traded lots'] if row['Buy/Sell']=='SELL' else row['Traded lots'], axis=1)
    
    
    
    df = df[['Client Id','Symbol','Expiry','Traded lots','Quantity','Transaction Date']]
    # get underlying ric and merge from master file mapping
    fut_stocks = fut_stocks[['SYMBOL','underlying RIC']]
    fut_stocks.rename(columns= {'SYMBOL':'Symbol'}, inplace = True)
    
    df = df.merge(fut_stocks,on='Symbol',how='left')

    
    return df



def fno_file_picker(day):
    
    for r,d,f in os.walk(input_dir):   
        
        for excel_file in f:  
            if excel_file.startswith('FNO_'):
                processing_date = parser.parse(excel_file[21:23]+' '+excel_file[23:26]+' '+excel_file[26:-4]).date()
                if day==processing_date:
                    return excel_file
                
def ml_file_picker(day):
    
    for r,d,f in os.walk(input_dir):  
        
        for excel_file in f:  
                
            if excel_file.startswith('ML_'):
                processing_date = parser.parse(excel_file[3:5]+' '+excel_file[5:8]+' '+excel_file[8:-4]).date()
                if day==processing_date:
                    return excel_file   
                
                
def operator(a,b):
    '''Operator function for pending calculation'''
    # take obsolute difference 
    return abs(a)-abs(b) 
    
def days_func(d1,d2):
    '''Func to get date range to loop over'''   
    days = [d1 + timedelta(days=x) for x in range((d2-d1).days + 1)]
    return days 

def password_cracker(filename):
    '''Func to crack excel password'''
    #win32com to crack password 
    xlApp = win32com.client.Dispatch("Excel.Application")
    xlwb = xlApp.Workbooks.Open(input_dir+filename, True, True, None, Password= 'ML123')
    # xlwb = xlApp.Workbooks.Open(filename)
    xlws = xlwb.Sheets(1) # counts from 1, not from 0
    content = xlws.Range("A:D").Value 

    # Transfer content to pandas dataframe
    dataframe = pd.DataFrame(list(content))

    dataframe.dropna(how='all', inplace=True)
    # create header
    dataframe.columns = dataframe.iloc[0]
    dataframe = dataframe.reindex(dataframe.index.drop(0))
    
    return dataframe  
    
    


def main():   

    logging.info('Reading master files')
    # read expiry contracts master
    expiry_encoders = pd.read_excel(master_dir+'Expiry_contract_Master.xlsx')
    # convert date to datetime format
    expiry_encoders['Expiry1'] = expiry_encoders.apply(lambda row: pd.to_datetime(row['Expiry1'], format='%d-%b-%Y'), axis=1)
    
    # read master file for future active stocks
    fut_stocks = pd.read_excel(master_dir+'MasterData.xlsx')
    fut_stocks = fut_stocks[fut_stocks['IsActiveFNO']==True]
    #futstk only stocks
    fut_stocks = fut_stocks[(fut_stocks['Type']=='SSF') | (fut_stocks['Type']=='Index')]
    # exclude list
    exclude = pd.read_excel(master_dir+'IgnoreNames.xlsx')
    exclude = list(exclude['Exclude'].values)
        
    result = fut_stocks[['SYMBOL','underlying RIC']]
    
    done_till_now = result[['underlying RIC']]
    
    total_df = done_till_now
    #initialize done till now with zeros
    done_till_now['Done_till'] = 0
    
    total_df['Total_qty'] = 0
    total_df['Done_till_now'] = 0
    
    # date to keep track of last traded date
    last_traded_date = ''
    last_order_df = pd.DataFrame()
    # get calendar days for current month
    start_date=datetime.datetime.today().replace(day=1).date() - datetime.timedelta(days=5)
    end_date = (datetime.datetime.today().replace(day=1).date() + datetime.timedelta(days=32)).replace(day=1) - datetime.timedelta(days=1)
    days = days_func(start_date,end_date)
    
    for day in days:
        
        # check for order files first
        order_file = ml_file_picker(day)
        if order_file!= None:     
            
            # merge donetillnow
            # done till now is calculated in FNO file processor if condition
            # get last traded column
          
            result['Done_till_{0}'.format(last_traded_date)] = done_till_now['Done_till']
            
            total_df['Done_till_now'] += result['Done_till_{0}'.format(last_traded_date)]
            # flush done till now 
            done_till_now['Done_till']=0
            
            
            # crack password for excel file 
            order_qty = password_cracker(order_file)
            # for final report 
            last_order_df = order_qty
               
            order_qty = order_qty[['underlying RIC','Pos Current Qty']]
            order_qty.fillna(0,inplace=True)
            order_qty.rename(columns={'Pos Current Qty':'Order_qty_{0}'.format(day)}, inplace=True)
            # merge order quantity in result
            result = result.merge(order_qty, on = 'underlying RIC', how='left')
            result.fillna(0,inplace=True)       
            
    
        
        
        file_fno = fno_file_picker(day)
        if file_fno!= None:  
                    
            # pre-process file 
            df = pre_process(file_fno,expiry_encoders,fut_stocks,exclude)
            
            df = df[['underlying RIC','Traded lots']]
            # colapse same row by addition of traded lots
            df = df.replace('None','').groupby('underlying RIC',as_index=False).agg(np.sum)
            
            # rename to current day
            df.rename(columns={'Traded lots':'{0}'.format(day)}, inplace=True)
            
            result = result.merge(df, on = 'underlying RIC', how='left')
            result.fillna(0, inplace=True)
            
            # add traded lots to done till now
            done_till_now = done_till_now.merge(df, on='underlying RIC', how='left')
            done_till_now.fillna(0, inplace=True)
            
            done_till_now['Done_till'] = done_till_now['Done_till']+done_till_now['{0}'.format(day)]
            done_till_now.drop(['{0}'.format(day)], inplace=True, axis=1) 
            # keep track of last traded date
            last_traded_date = day
            
            # pending based on short term done till now and current order quantity
            # take absolute difference
            try:
                result['pending_on_{0}'.format(day)] =  result.iloc[:,-2] + result.iloc[:,-1]
            except:
                pass            
        
        #result['pending_on_{0}'.format(day)] = result['Order_qty_{0}'.format(day)] - result['Done_till_{0}'.format(day)]
        #print 'order',len(done_till_now), len(result)      
            
    # writer object to append to diff sheets
    writer = pd.ExcelWriter(output_dir+'Report{0}.xlsx'.format(last_traded_date))
    result.to_excel(writer, sheet_name='Report')
    
    
    df = result    
    d = [ x for x in list(df.columns.values.astype(str)) if x.startswith('20')] # get all columns for order executed
    d.append('SYMBOL')
    d.append('underlying RIC')
    d.append('pending_on_{0}'.format(last_traded_date))
    d = d[-3:]+d[:-3]
    df = df.reindex(columns = d) # get all the order excuted columns    
    df['Net Done'] = df.iloc[:, 3:].sum(axis=1, skipna=True) # calculate net done till now 
    df = df[['SYMBOL','underlying RIC','Net Done','pending_on_{0}'.format(last_traded_date)]]
    df['Order size'] = df['pending_on_{0}'.format(last_traded_date)] - df['Net Done'] # cal order size 
    
    # client report tab
    result = result[['underlying RIC','pending_on_{0}'.format(last_traded_date)]]    
    # merge on underlying RIC
    last_order_df = last_order_df.merge(result, on='underlying RIC',how='left')    
    last_order_df.to_excel(writer, sheet_name='Client_Report{0}'.format(last_traded_date))   
    
    # Order summary tab
    df = df[df.iloc[:, 2:].sum(axis=1)!=0]
    df.to_excel(writer, sheet_name='Order_summary', index=False)   
        
    # save the file 
    writer.close()
    
    # move to email dir for auto emails 
    shutil.copy(output_dir+'Report{0}.xlsx'.format(last_traded_date), email_dir+'Report.xlsx')
                
   

start_time = time()

if __name__ == '__main__':
    main()

end_time = time()

logging.info('Time taken to process :'.format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)         