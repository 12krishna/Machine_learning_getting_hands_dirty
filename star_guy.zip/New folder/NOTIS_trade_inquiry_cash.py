import datetime
import base64
import requests
import json
import csv
#import pandas as pd
import logging 

import sys
import time

download_dir = "D:\\NSENotis\\"
log_path = "D:\\NSENotis\\"

logging.basicConfig(filename=log_path+"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def message_id_gen(seq_code):
    '''Sequence code generator for fetching records from API'''
    
    code = '08081' # kotak code to gen msg code
    d = datetime.datetime.today().date()
    req_date = ''.join([str(d.year),('0'+str(d.month) if len(str(d.month))==1 else str(d.month)),
                   ('0'+str(d.day) if len(str(d.day))==1 else str(d.day)) ])   
    
    return ''.join([code,req_date,seq_code]) 



def get_access_token():
    '''Func to get access token to tarde inquiry API'''
    
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'nonce': base64.b64encode(''.join(str(datetime.datetime.today()).split(" ")[0].split("-")[::-1])+''.join(datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f').split(" ")[1].split(":")).replace('.','')[:-3]+':457873'),
        'cache-control':'no-cache',
        'User-Agent':'PostmanRuntime/7.6.0',
        'Authorization':'Basic OTYyYjE1MmI1MWZhNGZkNzkzMjg5ODRiY2FiM2I4MTk6NjdmNjllZjRiZWRjNzE0NWI2MmFhYzkzYWU3NjE5MTA=',        
        'User-Agent': 'PostmanRuntime/7.6.0',
        'cookie':'_abck=AA356F8B6B6D7587FE36AA8024FB4CA573700289FD41000022243C5CC6EC0156~-1~3t9U/EYrV39jjjR9p+5cYYafpQkf59DC31MR4EsMoVY=~-1~-1; bm_sz=4C9545DAFF7863C5D97D9D9BA6B6DE45~QAAQiQJwc1/ALi9oAQAAWSjtSj6xZG1THawJBbprdFyoC5TpCCrpDOoiv+jmad+yl80+5RppTs6t8EJQHPLtCHs1dX/VbI2+ltOM0PbaQoXEeGEBGxCCKqiVEvwg6eKBbZQTqzTqY/5U9EgJbvsr4dEXJXd5Ew0AMKQ/oxME91GosnT+tgFD84ImpG3++AKPluXOt/OVQg==; ak_bmsc=B7C35229F021E695FDA068C2E402C00873700289FD41000035243C5CD8C67561~plGqXi/Uad9iZRC3rRsysx+B+CEx3Xzq5ikc9gRgj/eapPfr2K0xKLEdjsbSwbtQvgPBW0T0xj8uaYo1W1sr0LzUbx4FI5GZuPSQflM+gXvRWzeIXmktiV50WXAg1YPgJ1CjnJ2vK2vgaRrsK/vFWc34vvK0xUXcZj0G/vjdMBpG627R+twMbdtwzNsXkUDetiQQ3KesSEXl2PWI5XQoQpyNycZMXEKKwKfeAMfK25ttAsbo6hq0WlTMgFZvZtcB+w',
               
    }   
    proxy = {
        'host':"172.17.9.170",
        'port':'8080',
        'match':"http+https://*/*"
    }    
    data = {
            'Username':'962b152b51fa4fd79328984bcab3b819',
            'Password' :'67f69ef4bedc7145b62aac93ae761910',
            'grant_type':'client_credentials'
        }    
        
    url = 'https://www.devconnect2nse.com/token'
    req = requests.post(url, headers=headers, data=data, proxies=proxy)
    
    if req.status_code == 200:  
        logging.info('Successful connection with trading API!')
        print 'Successful connection..'
        # return access token on successful connection
        return req.json()['access_token']
    else:
        logging.info('Not able to ping API / Error_code: {}'.format(req.status_code))
        print 'Error : {}'.format(req.status_code)
        return -1
    

def get_trade_inquiry(token, seq_code,i):
    '''Func to get the trade inquiries'''
    
    if token!=-1:
        logging.info('Getting data with json response from server')
        headers = {
            'Content-Type': 'application/json',
            'nonce': base64.b64encode(''.join(str(datetime.datetime.today()).split(" ")[0].split("-")[::-1])+''.join(datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f').split(" ")[1].split(":")).replace('.','')[:-3]+':457873'),
            'cache-control':'no-cache',
            'Authorization':'Bearer {}'.format(token),        
            'User-Agent': 'PostmanRuntime/7.6.0',
            'cookie':'_abck=AA356F8B6B6D7587FE36AA8024FB4CA573700289FD41000022243C5CC6EC0156~-1~3t9U/EYrV39jjjR9p+5cYYafpQkf59DC31MR4EsMoVY=~-1~-1; bm_sz=4C9545DAFF7863C5D97D9D9BA6B6DE45~QAAQiQJwc1/ALi9oAQAAWSjtSj6xZG1THawJBbprdFyoC5TpCCrpDOoiv+jmad+yl80+5RppTs6t8EJQHPLtCHs1dX/VbI2+ltOM0PbaQoXEeGEBGxCCKqiVEvwg6eKBbZQTqzTqY/5U9EgJbvsr4dEXJXd5Ew0AMKQ/oxME91GosnT+tgFD84ImpG3++AKPluXOt/OVQg==; ak_bmsc=B7C35229F021E695FDA068C2E402C00873700289FD41000035243C5CD8C67561~plGqXi/Uad9iZRC3rRsysx+B+CEx3Xzq5ikc9gRgj/eapPfr2K0xKLEdjsbSwbtQvgPBW0T0xj8uaYo1W1sr0LzUbx4FI5GZuPSQflM+gXvRWzeIXmktiV50WXAg1YPgJ1CjnJ2vK2vgaRrsK/vFWc34vvK0xUXcZj0G/vjdMBpG627R+twMbdtwzNsXkUDetiQQ3KesSEXl2PWI5XQoQpyNycZMXEKKwKfeAMfK25ttAsbo6hq0WlTMgFZvZtcB+w',
            'Accept':'application/json',
            'Host': 'www.devconnect2nse.com'
                    
        }       
        proxy = {
            'host':"172.17.9.170",
            'port':'8080',
            'match':"http+https://*/*"
        }        
        params = {
                'version':'1.0','data':{'msgId':message_id_gen('{0:07d}'.format(i)), 'dataFormat':'CSV:CSV',
                                        'tradesInquiry':'{},ALL,,'.format(seq_code)
                        }                
                } 
    
        
        print 'Request to trade inquiry...'
        url = 'https://www.devconnect2nse.com/notis-cm/trades-inquiry'
        req = requests.post(url, headers=headers, proxies=proxy, data = json.dumps(params) )
        print req.status_code
        if req.status_code == 200:
            print 'Successfull connection with trading API; Fetching data...'
            data = req.json()['data']['tradesInquiry'].split('^')
            system_info = data[0]
            max_sequence_no = system_info.split(',')[-2] # max number of trade inquiry sent so far; send next time to get the response
            # store data so far in csv
            data = data[1:]
            
            
            f = open('data.csv', 'ab')
            w = csv.writer(f, delimiter = ',')
            w.writerows([ [str(int(float(j)))  if 'E' in j and '.' in j  else j   for j in x.split(',')] for x in data])
            f.close()
            
            print 'Data saved in csv'
            print max_sequence_no
            return max_sequence_no
        else:
            return req.status_code         
        
        

def main(time_interval):
    
    i = 1 # counter for request number of a day
    if len(time_interval)==0:
        time_interval = 5
    
    # get access token
    token = get_access_token()
    #fetch data from API and store to csv
    seq_code = get_trade_inquiry(token, 0,i)
    
    last_seq_code = 0
    while datetime.datetime.today().time() <= datetime.time(18,45):
        # keep fetching data for time interval specified 
        # get access token
        token = get_access_token()
        #fetch data from API and store to csv
        i += 1
        if len(seq_code) != 7:
            logging.info('No data found from server; status response : {}'.format(seq_code))
            seq_code = get_trade_inquiry(token, last_seq_code,i)
        elif len(seq_code) == 7:
            last_seq_code = seq_code
            seq_code = get_trade_inquiry(token, seq_code,i)         
        print 'time: ',time_interval
        time.sleep(time_interval)
        print ('Repeat after 5 sec')
        


if __name__ == "__main__":

    main(sys.argv[1:])
    
    
    
    
    


