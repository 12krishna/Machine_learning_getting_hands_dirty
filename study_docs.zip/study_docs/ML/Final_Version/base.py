# -*- coding: utf-8 -*-
"""
@author: krishnay
"""

import pandas as pd
import numpy as np 
#import time
import os 
import datetime



download_dir = "X:\\ML\\Download\\"



def dateparse(row):
    '''Func to parse dates while reading ticker files'''
    d = row.split("+")[0]
    d = pd.to_datetime(d, format='%Y-%m-%d %H:%M:%S')
    return d


def date_format():
    form = '%d-%b-%Y'
    return form


def agg_func(grp):
    '''agg func weighted avearge on LTP sum of volume diff'''    
    
    'Bid','Bid_2','Bid_3','Bid_4','Bid_5','offer','Offer_2','Offer_3','Offer_4','Offer_5',
    
    agg = pd.Series({'LTP': np.mean(grp['LTP']), 'Bid': grp['Bid'].tail(1).values[0], 'Bid_2': grp['Bid_2'].tail(1).values[0],
               'Bid_3': grp['Bid_3'].tail(1).values[0],'Bid_4': grp['Bid_4'].tail(1).values[0],
               'Bid_5': grp['Bid_5'].tail(1).values[0],'offer': grp['offer'].tail(1).values[0],
               'Offer_2': grp['Offer_2'].tail(1).values[0],'Offer_3': grp['Offer_3'].tail(1).values[0],
               'Offer_4': grp['Offer_4'].tail(1).values[0],'Offer_5': grp['Offer_5'].tail(1).values[0],
               'QtyBuy':grp['QtyBuy'].tail(1).values[0],'QtyBuy_2':grp['QtyBuy_2'].tail(1).values[0],
               'QtyBuy_3':grp['QtyBuy_3'].tail(1).values[0],'QtyBuy_4':grp['QtyBuy_4'].tail(1).values[0],
               'QtyBuy_5':grp['QtyBuy_5'].tail(1).values[0],'QtySell':grp['QtySell'].tail(1).values[0],
               'QtySell_2':grp['QtySell_2'].tail(1).values[0],'QtySell_3':grp['QtySell_3'].tail(1).values[0],
               'QtySell_4':grp['QtySell_4'].tail(1).values[0],'QtySell_5':grp['QtySell_5'].tail(1).values[0],
               'VolumeTraded':grp['VolumeTraded'].tail(1).values[0]                 
                    })
    
    return agg
   
    
def ticker_generator():
    '''Func to read 5 min log utility file and generate 5 sec ticker stats for volume traded and LTP for each symbol''' 
    
        
    cols = ['date','Symbol','QtyBuy','QtyBuy_2','QtyBuy_3','QtyBuy_4','QtyBuy_5','Bid','Bid_2','Bid_3','Bid_4','Bid_5','offer',
        'Offer_2','Offer_3','Offer_4','Offer_5','QtySell','QtySell_2','QtySell_3','QtySell_4','QtySell_5','VolumeTraded',
        'OpenPrice','Ccy', 'LTP','NumberOfOrdersBuy','NumberOfOrdersBuy_2','NumberOfOrdersBuy_3','NumberOfOrdersBuy_4',
        'NumberOfOrdersBuy_5','NumberOfOrdersSell','NumberOfOrdersSell_2','NumberOfOrdersSell_3','NumberOfOrdersSell_4',
        'NumberOfOrdersSell_5','LowerCircuitLimit','UpperCircuitLimit','HighPrice','LowPrice','ClosePrice','LTT timestamp',
        'NetChangeIndicator','LTQ','LotSize','OI','SecurityCode','ExchangeSegment','TradingSymbol']
    
    prices_df = pd.DataFrame() 
    
    try:  
        # read input file for every 5 sec data
        for r,d,f in os.walk(download_dir):
            for file in f:
                temp = pd.read_csv(download_dir+file,delimiter=',', engine='c'
                                , names=cols,skipinitialspace=True, low_memory=False)[['Symbol','date','Bid','Bid_2','Bid_3','Bid_4','Bid_5','offer','Offer_2','Offer_3','Offer_4','Offer_5',
            'QtyBuy','QtyBuy_2','QtyBuy_3','QtyBuy_4','QtyBuy_5', 'QtySell','QtySell_2','QtySell_3','QtySell_4','QtySell_5',
                                   'VolumeTraded','LTP','OI','SecurityCode','ExchangeSegment','TradingSymbol']]
                
                prices_df = prices_df.append(temp, ignore_index=True)
                
        
        prices_df['date'] = prices_df['date'].str.split('+',expand=True)
        prices_df['date'] = pd.to_datetime(prices_df['date'], format='%Y-%m-%d %H:%M:%S')   
        
        prices_df['time'] = prices_df['date'].dt.time   
        
        
        # ignore codes with long codes
        prices_df = prices_df[ ~(prices_df.SecurityCode.str.len() > 6 ) ]
        #prices = prices[(prices['Symbol']=='ACC') | (prices['Symbol']=='ADANIENT')]
        
        # cpnvert to numeric
        prices_df['SecurityCode'] = pd.to_numeric(prices_df['SecurityCode'], errors='coerce') 
        
        
        
    except Exception as e :
        print ('error: {}, file reading issue'.format(e))
        
        
    # filter on stock   
    # read master file for filtering on nse cashcode 
    pair_master = pd.read_csv("X:\\ML\\PairMaster.csv")
    
    

    prices_df = prices_df.merge(pair_master, on='Symbol',how='left')
    #prices_df.to_csv("debug.csv", index=False)
    prices_df = prices_df[ (prices_df['SecurityCode']==prices_df['NSECashCode'])
                         & (prices_df['ExchangeSegment'] == "NSE") ] # NSE cashcode 
    
    prices_df.sort_values(by=['Symbol','time'], inplace=True)  # sorting in time series 
    print (len(prices_df))
    prices_df = prices_df.groupby(['Symbol',pd.Grouper(key='date',freq='5s', 
                                                     sort=True)]).apply(lambda grp: agg_func(grp)).reset_index()
    prices_df['time'] = prices_df['date'].dt.time
  
    temp = pd.DataFrame()
    # merge on missing timeframes if any
    try:        
        # time range refrence ; for filling empty timeframes while aggr ip data
        time_keys = pd.DataFrame(pd.timedelta_range(start=str(datetime.time(9,15)), end=str(datetime.time(9,30)), freq = '5s')[:], columns=['time'])
        time_keys.sort_values(by='time', inplace=True)
        
        time_keys['time'] = time_keys.apply(lambda row: str(row['time']).split(' ')[-1], axis=1)  
        
        prices_df['time'] = prices_df['time'].astype(str)
        
        
        for gname, gelements in prices_df.groupby(['Symbol']): 
            t = time_keys.merge(gelements, on='time',how='left')
            t.fillna(method='ffill', inplace=True)
            if t.isnull().values.any()==True:
                t.fillna(method='bfill', inplace=True)
            temp = temp.append(t)
        
    except Exception as e:
        print ('Error: {} ; time format issue'.format(e))
  
    
    
    return temp

            
     

    
    
