"""
Title : Order Book Trend Prediciton Including First Hour Data Handling
Date : 08/11/2018
"""

#Imports
import argparse
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import ast
import csv
from collections import Counter
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from lightgbm import LGBMClassifier
from datetime import datetime
from datetime import timedelta
from sklearn.model_selection import train_test_split
from sklearn.metrics import cohen_kappa_score, accuracy_score, roc_auc_score,confusion_matrix,f1_score
from scipy.stats import zscore
import warnings
warnings.filterwarnings("ignore",category=DeprecationWarning)
from sklearn.preprocessing import MinMaxScaler,StandardScaler,RobustScaler
from sklearn.ensemble import AdaBoostClassifier
import os
from sklearn.model_selection import cross_val_score , cross_val_predict
from sklearn.model_selection import StratifiedKFold
import resource
import math

####################################################
#Helper Functions
####################################################


def real_to_class(dataframe_column,lab_timestep):
	"""Takes in a column, compares the value with the next
	and maps it to a class of 0,1,-1 respectively"""
	new_column = pd.Series([0]*len(dataframe_column))
	new_column.rename("classes", inplace=True)
	for i in range(len(dataframe_column)):
	    if i == (len(dataframe_column)-lab_timestep):
	        break
	    if dataframe_column[i] < dataframe_column[i+lab_timestep]:
	        new_column[i] = 1
	    elif dataframe_column[i] > dataframe_column[i+lab_timestep]:
	        new_column[i] = -1
	    else:
	        new_column[i] = 0
	return new_column


def convert_str_datetime(string):
	"""Takes in string ..converts to datetime format"""
	FMT = '%Y-%m-%d %H:%M:%S.%f+0530' 
	date = datetime.strptime(string, FMT)
	return date

def convert_str_datetime_for_intensity(string):
	"""Takes in string ..converts to datetime format"""
	FMT = '%Y-%m-%d %H:%M:%S.%f' 
	date = datetime.strptime(string, FMT)
	return date

def get_train_test_data(dataframe1, start_time, end_time,max_train_time,is_train=True):
	dataframe = dataframe1.copy()
	#df_timestamp = df['log_time_stamp'].apply(convert_str_datetime)
	if is_train == True:
		end_time = datetime.strptime(end_time,'%H:%M:%S')
		end_time = end_time - timedelta(seconds=max_train_time + lab_timestep)
		end_time = end_time.strftime('%H:%M:%S')
	#df_timestamp = df_order_book_time_stamp#df['log_time_stamp']
	#dataframe = pd.concat([df_timestamp, dataframe], axis=1)
	dataframe.set_index('log_time_stamp', inplace=True)
	dataframe = dataframe.between_time(start_time, end_time,include_end = False)
	dataframe.reset_index(drop=False, inplace=True)
	#dataframe.drop(dataframe.index[-1], inplace=True)
	#dataframe.reset_index(drop=True, inplace=True)
	#del dataframe['mean']
	return dataframe

def get_updated_time(original_time, time_update):
	"""Takes in time string, time_update in minutes converts to datetime object,
	updates it and returns in string type"""
	_ = datetime.strptime(original_time, '%H:%M:%S')
	updated_time = _ + timedelta(minutes=time_update)
	return updated_time.strftime('%H:%M:%S')
	
def get_only_prices(dataframe):
	'''
	takes in dataframe and retur dataframe containing all Ask prices and Bid prices. Ask volumes and Bid volumes are not taken
	'''
	df = dataframe[['AP1','AP2','AP3','AP4','AP5','BP1','BP2','BP3','BP4','BP5']]
	return df

def get_only_volumes(dataframe):
	'''
	takes in dataframe and returns dataframe containing all Ask volumes and Bid volumes. Ask prices and Bid prices are not taken
	'''
	df = dataframe[['AV1','AV2','AV3','AV4','AV5','BV1','BV2','BV3','BV4','BV5']]
	return df	

def get_Askvolumes(dataframe):
	'''
	takes in dataframe and returns dataframe containing all Ask volume. Bid volume, Ask price and Bid prices are not taken
	'''
	df = dataframe[['AV1','AV2','AV3','AV4','AV5']]
	return df


def get_Bidvolumes(dataframe):
	'''
	takes in dataframe and returns dataframe containing all Bid volume.Ask volume, Ask price and Bid prices are not taken
	'''
	df = dataframe[['BV1','BV2','BV3','BV4','BV5']]
	return df


def get_Bidprices(dataframe):
	'''
	takes in dataframe and returns dataframe containing all Bid prices.Ask prices, Ask volumes and Bid volumes are not taken
	'''
	df = dataframe[['BP1','BP2','BP3','BP4','BP5']]
	return df			

def get_Askprices(dataframe):
	'''
	takes in dataframe and returns dataframe containing all Ask prices. Bid prices, Ask volumes and Bid volumes are not taken
	'''
	df = dataframe[['AP1','AP2','AP3','AP4','AP5']]
	return df


def classwise_acc(confusion_matrix):
	class_minus_1 = confusion_matrix[0]
	class_0 = confusion_matrix[1]
	class_1 = confusion_matrix[2]

	acc_minus_1 = class_minus_1[0] / np.sum(class_minus_1)
	acc_0 = class_0[1] / np.sum(class_0)
	acc_1 = class_1[2] / np.sum(class_1)
	return acc_minus_1,acc_0,acc_1  

def Spread(df1):
	df = df1.copy()
	temp = pd.DataFrame()
	for i in range(1,6):
		temp['Spread_'+str(i)] = df['AP'+str(i)] - df['BP'+str(i)]
	return temp

def Mid_price(df1):
	df = df1.copy()
	temp = pd.DataFrame()
	for i in range(1,6):
		temp['Mid_price_'+str(i)] = (df['AP'+str(i)] + df['BP'+str(i)])/2
	return temp

def price_diff(df1):
	df = get_only_prices(df1)
	temp1 = pd.DataFrame()
	temp2 = pd.DataFrame()
	for i in range(1,6):
		if i == 5:
			temp1['Askprice_diff_'+str(i)] = abs(df['AP1'] - df['AP'+str(i)])
			temp2['Bidprice_diff_'+str(i)] = abs(df['BP1'] - df['BP'+str(i)])
		else:
			temp1['Askprice_diff_'+str(i)] = abs(df['AP'+str(i+1)] - df['AP'+str(i)])
			temp2['Bidprice_diff_'+str(i)] = abs(df['BP'+str(i+1)] - df['BP'+str(i)])
	temp = pd.concat([temp1,temp2],axis=1)
	return temp
			

def accumulated_price_diff_bet_Bid_Ask(df):
	df_AP = get_Askprices(df)
	df_BP = get_Bidprices(df)
	df_diff = pd.DataFrame(pd.DataFrame(df_AP.values).sub(pd.DataFrame(df_BP.values)))
	accumulated_sum = df_diff.sum(axis=1)
	return accumulated_sum

def accumulated_vol_diff_bet_Bid_Ask(df):
	df_AV = get_Askvolumes(df)
	df_BV = get_Bidvolumes(df)
	df_diff = pd.DataFrame(pd.DataFrame(df_AV.values).sub(pd.DataFrame(df_BV.values)))
	accumulated_sum = df_diff.sum(axis=1)
	return accumulated_sum

def price_spread(df):
	df_AP = get_Askprices(df)
	df_BP = get_Bidprices(df)
	df_diff = pd.DataFrame(pd.DataFrame(df_AP.values).sub(pd.DataFrame(df_BP.values)))
	df_diff.columns = ['price_spread_'+str(i+1) for i in range(df_AP.shape[1])]
	return df_diff

def volume_spread(df):
	df_AV = get_Askvolumes(df)
	df_BV = get_Bidvolumes(df)
	df_diff = pd.DataFrame(pd.DataFrame(df_AV.values).sub(pd.DataFrame(df_BV.values)))
	df_diff.columns = ['vol_spread_'+str(i+1) for i in range(df_AV.shape[1])]
	return df_diff	

def avg_price(df):
	df_AP = get_Askprices(df)
	df_BP = get_Bidprices(df)
	avg_df = pd.DataFrame()
	avg_df['avg_AP'] = df_AP.mean(axis=1)
	avg_df['avg_BP'] = df_BP.mean(axis=1)
	return avg_df

def avg_volume(df):
	df_AV = get_Askvolumes(df)
	df_BV = get_Bidvolumes(df)
	avg_df = pd.DataFrame()
	avg_df['avg_AV'] = df_AV.mean(axis=1)
	avg_df['avg_BV'] = df_BV.mean(axis=1)
	return avg_df


def sum_cm_for_all_days(list_cm):
	sum_cm_all_days = []
	for i in  range(len(list_cm[0])):
		temp = 0
		for j in range(len(list_cm)):	
			temp = temp + list_cm[j][i]
		sum_cm_all_days.append(list(temp))
	return np.array(sum_cm_all_days)


def convert_jiffies_datetime(jiffies):
	"""Takes in jiffies, converts to seconds, adds to the basis
	returns time stamp - 5hrs 30min """
	# jiffies = jiffies/65535.999999999985
	jiffies = jiffies/65536
	basis = '1980-1-1 00:00:00.000'
	FMT = '%Y-%m-%d %H:%M:%S.%f'
	basis = datetime.strptime(basis, FMT)
	#delta = datetime.strftime(basis, FMT) + timedelta(seconds=jiffies)
	delta = basis + timedelta(seconds=jiffies)
	# delta = delta - timedelta(hours=5, minutes=30)
	return delta
	

def get_intensities(df_order_book_data1,df_order_tik_data1):
	df_order_book_data = df_order_book_data1.copy()
	df_order_book_data.set_index('log_time_stamp',drop=True,inplace=True)
	df_order_data = df_order_tik_data1.copy()
	df_order_data.set_index('log_time_stamp',inplace=True,drop=True)
	
	temp_dict = {}

	temp_dict['limit_ask_order'] = [0]
	temp_dict['limit_bid_order'] = [0]
	temp_dict['market_ask_order'] = [0]
	temp_dict['market_bid_order'] = [0]
	temp_dict['cancel_ask_order'] = [0]
	temp_dict['cancel_bid_order'] = [0]

	for i in range(df_order_book_data.shape[0]-1):
		if np.mod(i,1000) == 0:
			print(i)
		start_time = df_order_book_data.index[i].time()
		end_time = df_order_book_data.index[i+1].time()
	
		temp_order_df = df_order_data.between_time(start_time,end_time,include_end=True,include_start=False)
		
		temp_dict['limit_ask_order'].append((temp_order_df[(temp_order_df.limit_price != 0) & (temp_order_df.buy_sell_indicator == 'S')].shape[0]))
		temp_dict['limit_bid_order'].append((temp_order_df[(temp_order_df.limit_price != 0) & (temp_order_df.buy_sell_indicator == 'B')].shape[0]))
		temp_dict['market_ask_order'].append((temp_order_df[(temp_order_df.market_order_flag == 1) & (temp_order_df.buy_sell_indicator == 'S')].shape[0]))
		temp_dict['market_bid_order'].append((temp_order_df[(temp_order_df.market_order_flag == 1) & (temp_order_df.buy_sell_indicator == 'B')].shape[0]))
		temp_dict['cancel_ask_order'].append((temp_order_df[(temp_order_df.activity_type == 3) & (temp_order_df.buy_sell_indicator == 'S')].shape[0]))
		temp_dict['cancel_bid_order'].append((temp_order_df[(temp_order_df.activity_type == 3) & (temp_order_df.buy_sell_indicator == 'B')].shape[0]))
	
	temp_df = pd.DataFrame(temp_dict)
	return temp_df

def cal_derivatives(df1,lab_timestep):
	df = df1.copy()
	
	df_timestamp = df.log_time_stamp.copy()
	del df['log_time_stamp']
	
	temp = pd.DataFrame()
	count = 1
	for i in range(lab_timestep):
		#temp = (df.sub(df.shift(1)))/0.5
		#temp = df.div(df.shift(lab_timestep))
		temp = pd.concat([temp,pd.DataFrame(df.div(df.shift(i)),columns=[ j +'_derivatives_' + str(i+1) for j in df.columns])],axis=1)
	#temp.columns = [ str(i) + '_derivatives' for i in df.columns]
	
	temp = temp.fillna(0)
	
	return temp


def convert_str_to_time(series):
	temp = pd.to_datetime(series.apply( lambda x : x.split('- ')[-1]))
	return temp

def cal_intensities_for_delta_T(intensities_df,delta_t): # delta_t = no of instances go back
	a = pd.DataFrame(0, index=np.arange(delta_t),columns=intensities_df.columns)
	for i in range(delta_t,intensities_df.shape[0]):
		a = a.append(intensities.iloc[i-delta_t:i].sum(),ignore_index=True)
	return a

def cal_cm_for_less_than_three_classes(actual,prediction):
	cm = confusion_matrix(actual,prediction)
	zero_data = np.zeros(shape=(3,3))
	d = pd.DataFrame(zero_data, columns=[-1,0,1])
	d.set_index(np.array([-1,0,1]),inplace=True)
	a = pd.DataFrame(cm,columns=np.sort(list(set(prediction))))
	a.set_index(np.sort(list(set(prediction))),inplace=True)
	for i in a.columns:
		for j in a.index:
		    d[i].loc[j] = a[i].loc[j]
	return d.values

def replicate_date_in_Timestamp(date1_list,date2):
	new_date = []
	for date1 in date1_list:
		day = date2[:2]
		month = date2[2:4]
		year = date2[4:]

		date1 = date1.replace(day=int(day),month=int(month),year=int(year))
		new_date.append(date1)
	return pd.Series(new_date)
	
def generate_features(OB):
	del OB['Trade_Quantity']
	del OB['last_traded_price']

	#df_order_book['spread'] = Spread(df_order_book)
	df_mid_prices = Mid_price(OB)
	df_derivatives = cal_derivatives(OB,lab_timestep)
	OB['accumulated_price_diff_bet_Bid_Ask'] = accumulated_price_diff_bet_Bid_Ask(OB)
	OB['accumulated_vol_diff_bet_Bid_Ask'] = accumulated_vol_diff_bet_Bid_Ask(OB)
	df_Avg_price = avg_price(OB)
	df_Avg_vol = avg_volume(OB)
	df_price_diff = price_diff(OB)
	df_price_spread = price_spread(OB)
	
	OB = pd.concat([OB,df_Avg_price,df_Avg_vol,df_mid_prices,df_price_spread,df_price_diff,df_derivatives],axis=1)	
	
	return OB
	
def generate_intensity_features(order_data,OB,date,stock):
	t_cal_intensity_df = datetime.now()
	
	# intensity_dir = '/home/local/ALGOANALYTICS/rchandgude/rupesh_work/order_book/lightgbm/18/intensities/'+date+'/'
	intensity_dir = os.getcwd() + '/data/intensities/' + date + '/'
	intensity_file = date+'_'+stock+'_intensities.csv'
	
	if not os.path.exists(intensity_dir):
		os.makedirs(intensity_dir)
		print('Calculating intensities for {} stocks {} data'.format(stock,date))
		t_cal_intensity_df = datetime.now()
		intensities = get_intensities(OB,order_data)
		intensities['log_time_stamp'] = OB.log_time_stamp
		print('time required for calculating intensity :',(datetime.now() - t_cal_intensity_df))
		intensities.to_csv(intensity_dir+intensity_file,index=False)

	else:
		# Read olready created files of intensities instead of calculating it
		if not os.path.exists(intensity_dir+intensity_file):
			print('Calculating intensities for {} stocks {} data'.format(stock,date))
			t_cal_intensity_df = datetime.now()
			intensities = get_intensities(OB,order_data)
			intensities['log_time_stamp'] = OB.log_time_stamp
			print('time required for calculating intensity :',(datetime.now() - t_cal_intensity_df))
			intensities.to_csv(intensity_dir+intensity_file,index=False)
		else:
			intensities = pd.read_csv(intensity_dir+intensity_file)
			intensities['log_time_stamp'] = intensities['log_time_stamp'].apply(convert_str_datetime_for_intensity)
			intensities_time = intensities.log_time_stamp.copy()
			del intensities['log_time_stamp']
			intensities['log_time_stamp'] = intensities_time
			del intensities_time

	return intensities

def cal_buy_bps(twap_buy_list,algo_buy_list):
	'''
	takes list of buy prices with twap approach and by our algo approach and returns the buy bps captured for those prices
	'''
	abs_gain = sum(twap_buy_list) - sum(algo_buy_list)
	percent_gain = (abs_gain / sum(twap_buy_list))*100
	buy_bps = percent_gain*100
	return buy_bps
	

def cal_sell_bps(twap_sell_list,algo_sell_list):
	'''
	takes list of sell prices with twap approach and by our algo approach and returns the sell bps captured for those prices
	'''
	abs_gain = sum(algo_sell_list) - sum(twap_sell_list)
	percent_gain = (abs_gain / sum(twap_sell_list))*100
	sell_bps = percent_gain*100
	return sell_bps

def get_twap_prices(test_data_timestamp,test_data_with_AP_BP,twap_interval):
	'''
	takes input as timestamps of test examples and OB at those timestamps along with time interval in seconds after which trade should be made and returns the dataframe having twap prices for buy and sell at twap interval timestamp
	'''	
	dict1 = {}
	dict1['test_data_time'] = []
	dict1['buy_twap_prices'] = []
	dict1['sell_twap_prices'] = []

	test_data_initial_timestamp = test_data_timestamp.iloc[0]
	for i in range(test_data_timestamp.shape[0] - lab_timestep):
		if (test_data_timestamp.iloc[i] - test_data_initial_timestamp).total_seconds() >= twap_interval:
			dict1['test_data_time'].append(test_data_timestamp.iloc[i])
			dict1['buy_twap_prices'].append(test_data_with_AP_BP.AP1.iloc[i])
			dict1['sell_twap_prices'].append(test_data_with_AP_BP.BP1.iloc[i])
			test_data_initial_timestamp = test_data_timestamp.iloc[i]		
	return pd.DataFrame.from_dict(dict1)
	
def get_smart_strategy_prices(test_data_timestamp,test_data_with_AP_BP,pred_lgb,twap_interval):
	'''
	takes input as timestamps of test examples ,OB at those timestamps, time interval in seconds after which trade should be made algong with prediction generated by algorithm at those timestamps and returns the dataframe having smart strategy prices for buy and sell at twap interval timestamp
	'''	
	dict1 = {}
	dict1['test_data_time'] = []
	dict1['buy_algo_prices'] = []
	dict1['sell_algo_prices'] = []

	test_data_initial_timestamp = test_data_timestamp.iloc[0]
	for i in range(test_data_timestamp.shape[0] - lab_timestep):
		if (test_data_timestamp.iloc[i] - test_data_initial_timestamp).total_seconds() >= twap_interval:
			dict1['test_data_time'].append(test_data_timestamp.iloc[i])

			if pred_lgb[i] == -1:
				dict1['buy_algo_prices'].append(test_data_with_AP_BP.AP1.iloc[i+lab_timestep])   # APPEND 5TH INSTANCE VALUE 
			else:
				dict1['buy_algo_prices'].append(test_data_with_AP_BP.AP1.iloc[i+1])  # APPEND NEXT INSTANCE VALUE 

			if pred_lgb[i] == 1:
				dict1['sell_algo_prices'].append(test_data_with_AP_BP.BP1.iloc[i+lab_timestep])   # APPEND 5TH INSTANCE VALUE 
			else: 
				dict1['sell_algo_prices'].append(test_data_with_AP_BP.BP1.iloc[i+1])   # APPEND NEXT INSTANCE VALUE 	
		
			test_data_initial_timestamp = test_data_timestamp.iloc[i]
	return pd.DataFrame.from_dict(dict1)

def get_all_correct_prices(test_data_timestamp,test_data_with_AP_BP,test_labels,twap_interval):
	'''
	takes input as timestamps of test examples ,OB at those timestamps, time interval in seconds after which trade should be made algong with actual labels at those timestamps and returns the dataframe having smart strategy prices for buy and sell at twap interval timestamp
	'''	
	dict1 = {}
	dict1['test_data_time'] = []
	dict1['buy_algo_prices'] = []
	dict1['sell_algo_prices'] = []

	test_data_initial_timestamp = test_data_timestamp.iloc[0]
	for i in range(test_data_timestamp.shape[0] - lab_timestep):
		if (test_data_timestamp.iloc[i] - test_data_initial_timestamp).total_seconds() >= twap_interval:
			dict1['test_data_time'].append(test_data_timestamp.iloc[i])

			if test_labels[i] == -1:
				dict1['buy_algo_prices'].append(test_data_with_AP_BP.AP1.iloc[i+lab_timestep])   # APPEND 5TH INSTANCE VALUE 
			else:
				dict1['buy_algo_prices'].append(test_data_with_AP_BP.AP1.iloc[i+1])  # APPEND NEXT INSTANCE VALUE 

			if test_labels[i] == 1:
				dict1['sell_algo_prices'].append(test_data_with_AP_BP.BP1.iloc[i+lab_timestep])   # APPEND 5TH INSTANCE VALUE 
			else: 
				dict1['sell_algo_prices'].append(test_data_with_AP_BP.BP1.iloc[i+1])   # APPEND NEXT INSTANCE VALUE 	
		
			test_data_initial_timestamp = test_data_timestamp.iloc[i]
	return pd.DataFrame.from_dict(dict1)
	
	
def get_twap_prices_continuous(test_data_timestamp,test_data_with_AP_BP):
	'''
	takes input as timestamps of test examples and OB at those timestamps and returns the dataframe having twap prices for buy and sell at each timestamp 
	'''	
	dict1 = {}
	dict1['test_data_time'] = []
	dict1['buy_twap_prices'] = []
	dict1['sell_twap_prices'] = []

	for i in range(test_data_timestamp.shape[0] - lab_timestep):
		dict1['test_data_time'].append(test_data_timestamp.iloc[i])
		dict1['buy_twap_prices'].append(test_data_with_AP_BP.AP1.iloc[i])
		dict1['sell_twap_prices'].append(test_data_with_AP_BP.BP1.iloc[i])
	return pd.DataFrame.from_dict(dict1)
	
def get_smart_strategy_prices_continuous(test_data_timestamp,test_data_with_AP_BP,pred_lgb):
	'''
	takes input as timestamps of test examples ,OB at those timestamps along with prediction generated by algorithm at those timestamps and returns the dataframe having smart strategy prices for buy and sell at each timestamp
	'''	
	dict1 = {}
	dict1['test_data_time'] = []
	dict1['buy_algo_prices'] = []
	dict1['sell_algo_prices'] = []

	for i in range(test_data_timestamp.shape[0] - lab_timestep):
		dict1['test_data_time'].append(test_data_timestamp.iloc[i])

		if pred_lgb[i] == -1:
			dict1['buy_algo_prices'].append(test_data_with_AP_BP.AP1.iloc[i+lab_timestep])   # APPEND 5TH INSTANCE VALUE 
		else:
			dict1['buy_algo_prices'].append(test_data_with_AP_BP.AP1.iloc[i+1])  # APPEND NEXT INSTANCE VALUE 

		if pred_lgb[i] == 1:
			dict1['sell_algo_prices'].append(test_data_with_AP_BP.BP1.iloc[i+lab_timestep])   # APPEND 5TH INSTANCE VALUE 
		else: 
			dict1['sell_algo_prices'].append(test_data_with_AP_BP.BP1.iloc[i+1])   # APPEND NEXT INSTANCE VALUE 	
	
	return pd.DataFrame.from_dict(dict1)


def get_all_correct_prices_continuous(test_data_timestamp,test_data_with_AP_BP,test_labels):
	'''
	takes input as timestamps of test examples ,OB at those timestamps along with actual labels at those timestamps and returns the dataframe having smart strategy prices for buy and sell at each timestamp
	'''	
	dict1 = {}
	dict1['test_data_time'] = []
	dict1['buy_algo_prices'] = []
	dict1['sell_algo_prices'] = []

	test_data_initial_timestamp = test_data_timestamp.iloc[0]
	for i in range(test_data_timestamp.shape[0] - lab_timestep):
		dict1['test_data_time'].append(test_data_timestamp.iloc[i])

		if test_labels[i] == -1:
			dict1['buy_algo_prices'].append(test_data_with_AP_BP.AP1.iloc[i+lab_timestep])   # APPEND 5TH INSTANCE VALUE 
		else:
			dict1['buy_algo_prices'].append(test_data_with_AP_BP.AP1.iloc[i+1])  # APPEND NEXT INSTANCE VALUE 

		if test_labels[i] == 1:
			dict1['sell_algo_prices'].append(test_data_with_AP_BP.BP1.iloc[i+lab_timestep])   # APPEND 5TH INSTANCE VALUE 
		else: 
			dict1['sell_algo_prices'].append(test_data_with_AP_BP.BP1.iloc[i+1])   # APPEND NEXT INSTANCE VALUE 	
	
	return pd.DataFrame.from_dict(dict1)

####################################################


####################################################
#### Argparse Config ###############################
####################################################

parser = argparse.ArgumentParser(description='Modelling')
parser.add_argument('-ad', "--ALL_DATES", default=False, type=lambda x: (str(x).lower() == 'true'),  metavar='',help="Enter Boolean Value for all dates mode....If all dates, training would start for all dates, else for a single or multiple date which you would be prompted for")
parser.add_argument("-as", "--ALL_STOCKS", default=False, type=lambda x: (str(x).lower() == 'true'), metavar='',help="Enter Boolean Value for all stocks mode...If all stocks, training would start for all stocks, else for a single or multiple stocks which you would be prompted for")
parser.add_argument('-ld',"--listdates", nargs = "*", type=str, default=[], metavar='', help="If you chose all dates, enter empty else enter dates in the format 'DDMNYY' 'DDMMYY' (space separated if more than two inputs)")
parser.add_argument('-lst',"--liststocks", nargs = "*", type=str, default=[], help="If you chose all stocks then enter empty else enter stocks in the format 'stock1' 'stock2' (space separated if more than one stock)")
parser.add_argument('-bid', "--bid_vol_flag", default=False, type=lambda x: (str(x).lower() == 'true'),  metavar='',help="Enter Boolean Value for bid flag mode....If bid flag, training would be done using labels generated from bid volumes else using labels generated from ask volumes")
args = parser.parse_args()

###################################################

t_initial = datetime.now()
round_off_digit = 2
ROOT_DIR = os.getcwd()


# stocks = ['AXISBANK']#,'BAJAJFINSV','EICHERMOT','HINDALCO','ICICIBANK','ITC','SBIN','RELIANCE','ULTRACEMCO''VEDL']
# dates =  ['03092018','04092018','05092018','06092018','07092018','10092018','11092018','12092018','14092018','17092018','18092018','19092018','21092018','24092018','25092018','26092018','27092018','28092018']

comment = ''

lab_timestep = 10

def start_train(ALL_DATES, ALL_STOCKS, listdates, liststocks, bid_vol_flag):
	""" Takes four inputs, 1) ALL_DATES : bool 2) ALL_STOCKS : bool, 3) listdates, 4) liststocks, 5) bid_vol_flag
    does model training for the specified STOCK_NAME and DATE
    """
	dates = []
	stocks = []


	if not ALL_DATES:
		match_flags = []
		date = listdates
		# date = date.replace(" ", "").split(',')
		for i in date:
			if i not in os.listdir(ROOT_DIR + '/data/orders'):
				print(date)
				match_flags.append(False)
			else:
				match_flags.append(True)
		if False in match_flags:
			raise ValueError("No tick data available for the date entered. Date Invalid...Exiting the process")
			
		length = len(date)
		if length == 1:
			dates.append(date[0])
		else:
			dates = date  
	else:
		dates = os.listdir(ROOT_DIR + '/data/orders')

	if not ALL_STOCKS:
		match_flags = []
		# print(os.listdir(ROOT_DIR + '/data/orders/' + all_dates[0]))
		stock = liststocks
		for i in stock:
			if i not in os.listdir(ROOT_DIR + '/data/orders/' + dates[0]):
				match_flags.append(False)
			else:
				match_flags.append(True)
		if False in match_flags:
			raise ValueError("No tick data available for the stock entered. Stock Name Invalid...Exiting the process")


		print("Thanks for the inputs!!!!...Started Training for the specified data!!!\n")
		length = len(stock)
		if length == 1:
			stocks.append(stock[0])
		else:
			stocks = stock   
	else:
		stocks = os.listdir(ROOT_DIR + '/data/orders/' + dates[0])

	dates = np.sort(dates)
	stocks = np.sort(stocks)

	for stock in stocks:
		
		# Create empty lists to store results for each date
		datewise_kappa = []
		datewise_cm = []
		datewise_acc_minus_1 = []
		datewise_acc_0 = []
		datewise_acc_1 = []
		datewise_algo_buy_price = []
		datewise_twap_buy_price = []
		datewise_all_correct_buy_price = []
		datewise_buy_abs_gain = []
		datewise_algo_sell_price = []
		datewise_twap_sell_price = []
		datewise_all_correct_sell_price = []
		datewise_sell_abs_gain = []

		datewise_algo_buy_price_continous = []
		datewise_twap_buy_price_continous = []
		datewise_all_correct_buy_price_continous = []
		datewise_buy_abs_gain_continous = []
		datewise_algo_sell_price_continous = []
		datewise_twap_sell_price_continous = []
		datewise_all_correct_sell_price_continous = []
		datewise_sell_abs_gain_continous = []

		for date in dates:
			print('Stock name :',stock)
			print('Date :',date)
			# file_path = '/home/local/ALGOANALYTICS/rchandgude/rupesh_work/order_book/OB_generation/order_book_generation/output/order_book_point5_seconds_'+date+'_'+stock+'.csv'
			file_path = ROOT_DIR + '/data/order_books/' + stock + '/order_book_point5_seconds_'+date+'_'+stock+'.csv'

			# order_file_path = '/home/local/ALGOANALYTICS/rchandgude/rupesh_work/order_book/OB_generation/order_book_generation/data/orders/'+date+'/'+stock
			order_file_path = ROOT_DIR + '/data/orders/' +date+'/'+stock

			# Read order book csv
			df = pd.read_csv(file_path)
			df.columns = ['Timestamp','AP1','AP2','AP3','AP4','AP5','AV1','AV2','AV3','AV4','AV5','BP1','BP2','BP3','BP4','BP5','BV1','BV2','BV3','BV4','BV5','Trade_Quantity','last_traded_price']
			
			df['log_time_stamp'] = convert_str_to_time(df['Timestamp'])
			del df['Timestamp']
			df['log_time_stamp'] = replicate_date_in_Timestamp(df['log_time_stamp'],date)
			df = df.sort_values(by='log_time_stamp')
			df.reset_index(inplace=True,drop=True)	

			# Read order tik data file
			orders_tik_data = pd.read_csv(order_file_path, delim_whitespace=True, header=None)
			orders_tik_data.columns = ['record_indicator', 'segment', 'order_no', 'jiffies',
								'buy_sell_indicator', 'activity_type', 'symbol', 'series',
								'volume_disclosed', 'volume_original', 'limit_price',
								'trigger_price', 'market_order_flag', 'stop_loss_flag',
								'IO_flag', 'algo_indicator', 'client_identity_flag']
			orders_tik_data['limit_price'] =  orders_tik_data.limit_price.apply(func=(lambda x: x/100.0))
			orders_tik_data['trigger_price'] =  orders_tik_data.trigger_price.apply(func=(lambda x: x/100.0))

			#Converting jiffie to timestamps
			orders_tik_data['log_time_stamp'] = orders_tik_data['jiffies'].apply(convert_jiffies_datetime)

			df_order_book = df.copy()
			
			# Generate features required for modeling
			df_order_book = generate_features(df_order_book)

			# Generate intensity features from order tik data
			print('calculating trade intensity')
			intensities = generate_intensity_features(orders_tik_data,df_order_book,date,stock)

			df_order_book.reset_index(drop=True,inplace=True)


			# Generating labels
			if bid_vol_flag:
				df_order_book['classes'] = real_to_class(df_order_book['BV1'],lab_timestep)
			else:
				df_order_book['classes'] = real_to_class(df_order_book['AV1'],lab_timestep)

			# define initial times for training and testing
			initial_train_start_time = '9:15:00'
			# initial_test_start_time = initial_train_start_time
			final_test_time = '15:30:01'
			# final_test_time = '10:15:01'

			# various training windows size in minutes
			train_window = 60     # time in minutes
			test_window = 5       # time in minutes
			twap_interval = 25    # twap interval(gap between two trades) in seconds 

			t0 = datetime.now() 
			
			print('training window is :',train_window)
			print('testing_window is :',test_window)
			
			add_min_to_train_start_time = train_window    
			add_min_to_test_start_time = test_window

			# get training as well as testing start time and end time
			# if initial_test_start_time < '10:15:01':
			train_start_time = initial_train_start_time
			train_end_time = get_updated_time(train_start_time, 10)
			test_start_time = train_end_time
			test_end_time = get_updated_time(test_start_time,add_min_to_test_start_time)



			initial_test_time = test_start_time
			get_slice = True


			
			max_train_time = 10  # max time required for training LightGBM

			# Create empty lists to store results for every test window
			test_kappa_lgb = []
			train_kappa_lgb = []
			train_f1_score_lgb = []
			test_f1_score_lgb = []
			acc_lgb = []
			acc_0_lgb = []
			acc_minus1_lgb = []
			acc_1_lgb = []
			auc_lgb = []
			cm_lgb = []
			actual = []
			pred_lgb = []
			pred_proba_lgb = []
			train_distibution = []
			test_distribution = []
			time_for_lgb = []
			training_start_time = []
			training_end_time = []
			testing_start_time = []
			testing_end_time = []


			# Iterate till final test end time occures
			count = 0
			while test_end_time < final_test_time:
				if test_end_time > '10:15:00':
					if count > 0:
						pass
					else:
						train_start_time = initial_train_start_time
						train_end_time = get_updated_time(train_start_time,add_min_to_train_start_time)
						test_start_time = train_end_time
						test_end_time = get_updated_time(test_start_time,add_min_to_test_start_time)
						count += 1

				training_start_time.append(train_start_time)
				training_end_time.append(train_end_time)
				testing_start_time.append(test_start_time)
				testing_end_time.append(test_end_time)

				print('start_time :',train_start_time)
				print('end_time :',train_end_time)

			
				# Get train data between train start time and train end_time
				t1 = datetime.now()
				train_data = get_train_test_data(df_order_book, train_start_time, train_end_time,max_train_time,is_train=True)
				train_labels = train_data.classes
				del train_data['classes']

				# Normalizing of data
				scalar = MinMaxScaler(feature_range=(-1,1))
		

				train_data_time_stamp = train_data.log_time_stamp
				del train_data['log_time_stamp']

				# get intensities for train_data
				train_intensities = get_train_test_data(intensities,train_start_time,train_end_time,max_train_time,is_train=True)
				del train_intensities['log_time_stamp']
			
				# Join train data with intensities
				train_data = pd.concat([train_data,train_intensities],axis=1)	

				# Normalization
				if scalar != None:
					train_data = pd.DataFrame(scalar.fit_transform(train_data),columns = train_data.columns)
					

				# Replace NaN and inf with 0 if any
				train_data.replace([np.inf, -np.inf], np.nan,inplace=True)
				train_data.fillna(0,inplace=True)
		
				train_data_col = train_data.columns

				train_distibution.append(Counter(train_labels))	

				print('time required for generating features for 1 hour train data :',datetime.now()-t1)


				# Get test data between test start time and test end_time
				t2 = datetime.now()
				test_data = get_train_test_data(df_order_book, test_start_time, test_end_time,max_train_time,is_train=False)
				test_labels = test_data.classes
				del test_data['classes']

				# get only Ask prices and Bid prices from test data (Will be used while calculating bps)
				test_data_with_AP_BP = pd.concat([get_Askprices(test_data),get_Bidprices(test_data),test_data.log_time_stamp],axis=1,sort=False)
				test_data_with_AP_BP = test_data_with_AP_BP
				test_data_with_AP_BP.reset_index(drop=True,inplace=True)

				test_data_timestamp = test_data.log_time_stamp
				test_data_timestamp.reset_index(drop=True,inplace=True)

				test_data_time_stamp = test_data.log_time_stamp
				del test_data['log_time_stamp']
		
				# get intensities for test data
				test_intensities = get_train_test_data(intensities,test_start_time,test_end_time,max_train_time,is_train=False)					
				del test_intensities['log_time_stamp']
				
				# Join test data with intensities
				test_data = pd.concat([test_data,test_intensities],axis=1) 


		
				# Normalization
				if scalar != None:
					test_data = pd.DataFrame(scalar.transform(test_data),columns = test_data.columns)

				# Replace NaN and inf with 0 if any
				test_data.replace([np.inf, -np.inf], np.nan,inplace=True)
				test_data.fillna(0,inplace=True)
		
				test_data_col = test_data.columns

				test_distribution.append(Counter(test_labels))
		
				print('time required for generating features for 5 min test data :',datetime.now()-t2)
				
							
				if test_data.shape[0] != test_data_with_AP_BP.shape[0]:
					raise ValueError('Shape of test data with prices and shape of test data are not same')
				
				
				actual_original_label = test_labels	
				actual.append(actual_original_label)
				
				
				trues_one_hot_encoded = pd.get_dummies(actual_original_label)	


				# LightGBM model
				model_lgb = LGBMClassifier(random_state=42,objective='multiclass',learning_rate=0.1,class_weight='balanced',n_estimators=50,n_jobs=1,max_depth=3, num_leaves=30,feature_fraction=0.8,bagging_fraction = 0.8,bagging_freq=100,min_split_gain=0.0) #max_bins=200,lambda_l1 = 0.0,lambda_l2 = 0.0,


				t_lgb = datetime.now()

				# train model on train data
				model_lgb.fit(train_data,train_labels)
				time_for_train_lgb = datetime.now() - t_lgb
				print('time required for training lgb model is {}'.format(time_for_train_lgb))
				time_for_lgb.append(time_for_train_lgb)

				# test the model on train data itself
				train_data_pred	 = model_lgb.predict(train_data)
				train_kappa = round(cohen_kappa_score(train_labels,train_data_pred),round_off_digit+2)
				print('train kappa score :',train_kappa)
				train_kappa_lgb.append(train_kappa)
				train_f1_score = round(f1_score(train_labels,train_data_pred,average='weighted'),round_off_digit+2)
				train_f1_score_lgb.append(train_f1_score)

				# make prediction on test_data
				test_data_prediction = model_lgb.predict(test_data)

				lgb_prediction_prob = model_lgb.predict_proba(test_data)
				pred_lgb.append(test_data_prediction)
				pred_proba_lgb.append(lgb_prediction_prob)
				


				# Cal performance measures like cohen_kappa_score, f1_score accuracy_score and roc_auc_score
				
				kappa_score_lgb = round(cohen_kappa_score(actual_original_label,test_data_prediction),round_off_digit+2)
				print("test kappa score : %f\n"%(kappa_score_lgb))	
				test_kappa_lgb.append(kappa_score_lgb)

				f1_score_lgb = round(f1_score(actual_original_label,test_data_prediction,average='weighted'),round_off_digit+2)
				#print("f1 score for random forest is %f\n"%(f1_score_lgb))
				test_f1_score_lgb.append(f1_score_lgb)

				accuracy_lgb = round(accuracy_score(actual_original_label, test_data_prediction)*100,round_off_digit)
				#print("Accuracy for random forest is %f\n"%(accuracy_lgb))	
				acc_lgb.append(accuracy_lgb)

				if len(set([-1,0,1]) - set(trues_one_hot_encoded.columns)) == 0:
					cm = confusion_matrix(actual_original_label,test_data_prediction)
					#print('confusion_matrix',cm)	
					cm_lgb.append(np.hstack(cm))
		
					acc_minus1,acc_0,acc_1 = classwise_acc(cm)
					acc_minus1_lgb.append(round(acc_minus1*100,round_off_digit))
					acc_0_lgb.append(round(acc_0*100,round_off_digit))
					acc_1_lgb.append(round(acc_1*100,2))
				
				else:
					cm = cal_cm_for_less_than_three_classes(actual_original_label,test_data_prediction)
					#print('confusion_matrix',cm)	
					cm_lgb.append(np.hstack(cm))
		
					acc_minus1,acc_0,acc_1 = classwise_acc(cm)
					if math.isnan(acc_minus1):
						acc_minus1 = 0
					if math.isnan(acc_0):
						acc_0 = 0
					if math.isnan(acc_1):
						acc_1 = 0															
					acc_minus1_lgb.append(round(acc_minus1*100,round_off_digit))
					acc_0_lgb.append(round(acc_0*100,round_off_digit))
					acc_1_lgb.append(round(acc_1*100,2))						
					

				if len(set([-1,0,1]) - set(trues_one_hot_encoded.columns)) == 0:
					AUC_lgb = roc_auc_score(trues_one_hot_encoded,lgb_prediction_prob)
					#print("AUC score for random forest is %f\n"%(AUC_lgb))
					auc_lgb.append(round(AUC_lgb,round_off_digit+2))
				else:
					auc_lgb.append(0)
						
				#update time for next iteration
				train_start_time = get_updated_time(train_start_time,test_window)
				train_end_time = get_updated_time(train_end_time,test_window)
				test_start_time = get_updated_time(test_start_time,test_window)
				test_end_time = get_updated_time(test_end_time,test_window)
				print('\n################\n')
			
			else:
				print('test time is greater than final test_end_time')
				pass


			if len(actual) > 0:
				mean_kappa = round(np.mean(test_kappa_lgb),round_off_digit+2)
				datewise_kappa.append(mean_kappa)
				print('avg kappa : ',mean_kappa)
				mean_f1 = round(np.mean(test_f1_score_lgb),round_off_digit+2)
				print('avg f1 score : ',mean_f1)
				print('avg auc : ',np.mean(auc_lgb))
				sum_cm = confusion_matrix(np.hstack(actual),np.hstack(pred_lgb))
				datewise_cm.append(sum_cm)
				print('sum confusion_matrix : ',sum_cm)
				ac_minus_1,ac_0,ac_1 = classwise_acc(sum_cm_for_all_days(datewise_cm))
				print('avg acc : ',accuracy_score(np.hstack(actual),np.hstack(pred_lgb)))
				print('avg acc for class -1 :',round(ac_minus_1*100,round_off_digit))
				datewise_acc_minus_1.append(round(ac_minus_1*100,round_off_digit))
				print('avg acc for class 0 :',round(ac_0*100,round_off_digit))
				datewise_acc_0.append(round(ac_0*100,round_off_digit))
				print('avg acc for class 1 :',round(ac_1*100,round_off_digit))
				datewise_acc_1.append(round(ac_1*100,round_off_digit))
				total_time_req = datetime.now()-t0
				print("Time required for code completion is {}\n".format(total_time_req))
				
				print('\n\n###############################################\n\n')


				# Create dictionaries to store results of bps calculations
				model_output = {}
				results = {}

				
				model_output['Comment'] = comment
				model_output['Stock'] = stock
				model_output['date'] = dates
				model_output['testing period'] = [initial_test_time,final_test_time]
				model_output['Model'] = model_lgb
				model_output['label_timestamp'] = str(lab_timestep/2) + ' sec'
				model_output['train window'] = train_window
				model_output['test window'] = test_window
				model_output['max training time'] = max_train_time
				model_output['train data shape'] = train_data.shape
				model_output['test data shape'] = test_data.shape
				model_output['scalar'] = scalar

				results['Date'] = [date]
				results['kappa'] = round(np.mean(test_kappa_lgb),round_off_digit+2)
				results['Confusion_matrix'] = [sum_cm]
				ac_minus_1,ac_0,ac_1 = classwise_acc(sum_cm)
				results['Acc of Class -1'] = round(ac_minus_1*100,round_off_digit)
				results['Acc of Class 0'] = round(ac_0*100,round_off_digit)
				results['Acc of Class 1'] = round(ac_1*100,round_off_digit)
				
				
				results_df = pd.DataFrame.from_dict(results)
				
				
				# Create directory to store results
				if bid_vol_flag:
					result_dir = 'output_model_bid_vol_combined/results_BV1/' + stock
				else:
					result_dir = 'output_model_ask_vol_combined/results_AV1/' + stock
				if not os.path.exists(result_dir):
					os.makedirs(result_dir)
				
									
		
				with open(result_dir+'/'+stock+'_results_'+str(datetime.now().date())+'.csv','a') as f2:
					if len(dates) == 1:
						f2.write('\n\n\n\n')
						writer = csv.writer(f2)
						for key, value in model_output.items():
							writer.writerow([key, value])
						f2.write('\n')
						results_df.to_csv(f2,header = True,index=False)
					else:
						if date == dates[0]:
							f2.write('\n\n\n\n')
							writer = csv.writer(f2)
							for key, value in model_output.items():
								writer.writerow([key, value])
							f2.write('\n')

							results_df.to_csv(f2,header = True,index=False)
				
						elif date == dates[-1]:
							temp_df = pd.DataFrame()
							temp_df['Date'] = ['Total']
							temp_df['kappa'] = round(np.mean(datewise_kappa),round_off_digit+2)
							temp_df['Confusion_matrix'] = [sum_cm_for_all_days(datewise_cm)]
							ac_minus_1,ac_0,ac_1 = classwise_acc(sum_cm_for_all_days(datewise_cm))
							temp_df['Acc of Class -1'] = round(ac_minus_1*100,round_off_digit)
							temp_df['Acc of Class 0'] =  round(ac_0*100,round_off_digit)
							temp_df['Acc of Class 1'] =  round(ac_1*100,round_off_digit)
							
							results_df = results_df.append(temp_df)

							results_df.to_csv(f2,header = False,index=False)
				
						else:
							results_df.to_csv(f2,header = False,index=False)

		

		
			
			else:
				print('len of actual list is zero')
				pass			

			total_time_taken = datetime.now() - t_initial
			print('total time taken by script to run is {}'.format(total_time_taken))

	print('total time taken by script to run is {}'.format(datetime.now() - t_initial))

if __name__ == "__main__":
    start_train(ALL_DATES = args.ALL_DATES, ALL_STOCKS = args.ALL_STOCKS, listdates = args.listdates, liststocks = args.liststocks, bid_vol_flag = args.bid_vol_flag)
