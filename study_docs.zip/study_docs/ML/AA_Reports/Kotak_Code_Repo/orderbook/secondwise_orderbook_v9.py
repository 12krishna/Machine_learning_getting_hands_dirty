"""
Title : (26/12/2018) Order Book Generation Without Trigger Logic, with market orders and with IOC orders and
        where buy and sell order book do not contain market orders
        (19/12/2018) Added support for volume checking
        (10/01/2018) Added support for running all dates for a stock from command line
Date : 26/12/2018
"""
#Imports
import numpy as np
import pandas as pd
import argparse
import os
import ast
from collections import Counter, OrderedDict
from datetime import datetime
from datetime import timedelta
from pprint import pprint
import csv
import pdb
import gc
import sys
import ast


####################################################
#Helper Functions
####################################################

####OLD
FMT = '%Y-%m-%d %H:%M:%S.%f'
def get_dataframe(filename):
    """Takes filename as input,
    outputs a dataframe in proper format
    """
    df = pd.read_csv(filename, header=None)
    a = df[1].str.split(',', expand=True)
    b = df[0]
    df = pd.concat([b,a], axis=1)
    df.columns = df.iloc[0]
    df = df.iloc[1:,:]
    df = df.reset_index(drop=True)
    # df['Categories'] = df['Categories'].astype('int64')
    for col_name in df.columns[1:]:
        df[col_name] = df[col_name].astype('float64')
    return df

def convert_str_datetime(string):
    """Takes in string ..converts to datetime format"""
    FMT = '%Y-%m-%d %H:%M:%S.%f+0530' 
    date = datetime.strptime(string, FMT)
    return date

def get_seconds(start_date, end_date):
    """Takes datetime in form '%Y-%m-%d %H:%M:%S'
    and calculates the total seconds between the input date and basis date"""
    delta = end_date - start_date
    return delta.total_seconds()

def get_updated_time(original_time, time_update):
    """Takes time in datetime, time_update in seconds converts to datetime object,
    updates it and returns in string type"""
    updated_time = original_time + timedelta(seconds=time_update)
    return updated_time

def convert_jiffies_datetime(jiffies):
    """Takes in jiffies, converts to seconds, adds to the basis
    returns time stamp - 5hrs 30min """
    # jiffies = jiffies/65535.999999999985
    jiffies = jiffies/65536
    basis = '1980-1-1 00:00:00.000'
    FMT = '%Y-%m-%d %H:%M:%S.%f'
    basis = datetime.strptime(basis, FMT)
    #delta = datetime.strftime(basis, FMT) + timedelta(seconds=jiffies)
    delta = basis + timedelta(seconds=jiffies)
    # delta = delta - timedelta(hours=5, minutes=30)
    return delta

def fill_array(arr, def_value=0, total_length=5):
    if len(arr) < total_length:
        while(len(arr) < total_length) :
            arr = np.append(arr, def_value)
    return arr    

def compare_volumes(v1, v2):
    # we should allow diffs for below 20, below 100, below 500 and above 500
    # RATIO_UPPER = 1.0 + tolerance_allowed
    # RATIO_LOWER = 1.0 - tolerance_allowed
    # ratio = round(v1/v2 , 2)

    # if v1 == v2:
    #     return True
    # elif v2 < 25:  # small volumes should be checked for difference, not percent
    #     return abs(v2 - v1) <= 3
    # elif ratio <= RATIO_UPPER and ratio >= RATIO_LOWER:
    #     return True
    # else:
    #     return False
    return v1 == v2

def calculate_volume_accuracy(nse_volumes, algo_volumes):
    nse_vol = [float(v) for v in nse_volumes.split('_')]
    DEPTH_LEVEL = len(nse_vol)
    max_matches = [0.0] * DEPTH_LEVEL
    total_match_count = -1

    if 0 not in nse_vol: 
        for str_volume in algo_volumes:
            current_match = []
            match_count = 0

            algo_vol = [float(v) for v in str_volume.split('_')]                       
            if DEPTH_LEVEL != len(algo_vol):
                continue
            else:    
                for count in range(0, DEPTH_LEVEL):

                    if compare_volumes(algo_vol[count], nse_vol[count]):
                        #current_match.append(1)
                        match_count += 1
                        current_match.append(str(nse_vol[count]))
                    else:    
                        #current_match.append(round(algo_vol[count]/nse_vol[count], 2))
                        current_match.append(str(algo_vol[count]) + " | " + str(nse_vol[count]))
                
            if match_count > total_match_count:
                max_matches = current_match
                total_match_count = match_count
            if total_match_count == DEPTH_LEVEL:
                break

    return max_matches

def calculate_number_volume_accuracy(accuracy_list, number):
    total_num_occurances = 0
    for volume_list in accuracy_list:       
        temp_dict = Counter(volume_list)
        if temp_dict[1] == number:
            total_num_occurances += 1

    return total_num_occurances / len(accuracy_list)

# used for each sample to calculate matches between our snapshot and NSE snapshot
def calc_accuracy(nse_prices, last_bin_prices):
    total_matches = []
    nse_price_list = [float(p) for p in nse_prices.split('_')]
    DEPTH_LEVEL = len(nse_price_list)
    if 0 < sum(n <= 0 for n in nse_price_list):  # ignore accuracy calculation for pre-open with negative values
        total_matches.append(DEPTH_LEVEL)
    else:    
        matches = 0
        for str_prices in last_bin_prices:
            algo_price_list = [float(p) for p in str_prices.split('_')]
            if DEPTH_LEVEL != len(algo_price_list):
                continue
            else:   
                for count in range(0, DEPTH_LEVEL):
                    if algo_price_list[count] == nse_price_list[count]:
                            matches+=1                
                # append current level of matches
                total_matches.append(matches)
                matches = 0
                # if 5 matched --> stop
                if DEPTH_LEVEL == max(total_matches, default=99):  
                   break   
    return max(total_matches, default=99)

# for getting accuracy for number of matches (5, 4 etc.)
def calculate_final_accuracy(accuracy_list, number):
    accuracy_array = np.array(accuracy_list)
    temp_dict = Counter(accuracy_array)
    total_correct = temp_dict[number]
    return round((total_correct / (len(accuracy_array) - temp_dict[99]) * 100), 2)


# def calc_accuracy_with_diff(nse_prices, last_bin_prices):
# 	total_matches = []
# 	nse_price_list = [float(p) for p in nse_prices.split('_')]
# 	DEPTH_LEVEL = len(nse_price_list)

# 	for str_prices in last_bin_prices:
# 		matches = []
# 		algo_price_list = [float(p) for p in str_prices.split('_')]

# 		if DEPTH_LEVEL != len(algo_price_list):
# 			continue
# 		else:
# 			for count in range(0, DEPTH_LEVEL):
# 				if algo_price_list[count] == nse_price_list[count]:
# 					matches.append("1")
# 				else:
# 					matches.append(str(algo_price_list[count]) + " - "  + str(nse_price_list[count]))

# 			if matches.count("1") >= total_matches.count("1"):
# 				total_matches = matches
# 			if total_matches.count("1") == DEPTH_LEVEL:
# 				break

# 	return total_matches

# def calculate_final_accuracy_with_diff(accuracy_list, num_string):
#     total_num_occurances = 0
#     for price_list in accuracy_list:       
#         temp_dict = Counter(price_list)
#         if temp_dict["1"] == num_string:
#             total_num_occurances += 1

#     return total_num_occurances/len(accuracy_list)

# this dumps all matching or non-matching values for each sample,
def calc_accuracy_with_diff_dump_all(nse_prices, last_bin_prices):
    total_matches = []
    total_match_count = -1
    nse_price_list = [float(p) for p in nse_prices.split('_')]
    DEPTH_LEVEL = len(nse_price_list)

    for str_prices in last_bin_prices:
        matches = []
        match_count = 0
        algo_price_list = [float(p) for p in str_prices.split('_')]

        if DEPTH_LEVEL != len(algo_price_list):
            continue
        else:
            for count in range(0, DEPTH_LEVEL):
                if nse_price_list[count] < 0:
                    match_count += 1
                    matches.append(str(algo_price_list[count])) # ignoring comparison for negatives
                elif algo_price_list[count] == nse_price_list[count]:
                    # matches.append("1")
                    match_count += 1
                    matches.append(str(nse_price_list[count]))   # dump everything, cannot get accuracy percent with this, but helps in debugging
                else:
                    matches.append(str(algo_price_list[count]) + " | "  + str(nse_price_list[count]))

            if match_count > total_match_count:
                total_matches = matches
                total_match_count = match_count
            if total_match_count == DEPTH_LEVEL:
                break

    return total_matches 

def dump_non_matching_accuracies(accuracies_list, filename, inaccuracies_only=True, delimiter="|"):
    dump_list = []

    if inaccuracies_only:
        for lst in accuracies_list:
            if sum(s.count(delimiter) > 0 for s in lst):
                dump_list.append(lst)
    else: # dump all accuracies 
        dump_list = accuracies_list
    
    #write filtered accuracies dump to file
    with open(filename, "w") as fo:
        fo.write(str(dump_list).replace("],", "],\n"))

def calculate_total_dump_accuracy(accuracy_list, acc_number, delimiter="|"):
    DEPTH_LEVEL = 5
    num_matches = 0
    for lst in accuracy_list:
        if sum(s.count(delimiter) == 0 for s in lst) == acc_number:
            num_matches += 1

    return round(num_matches/len(accuracy_list) * 100, 2)


def export_all_matches(all_matches_filename):
    max_index = len(buy_accuracies)
    with open(all_matches_filename, "a") as fo:
        fo.write("Buy Prices - Buy Volumes - Sell Prices - Sell Volumes\n")
        for i in range(0, max_index):
            row = str(buy_accuracies[i]).replace('"', '').replace("'", "")
            row += " - " + str(buy_volumes[i]).replace(".0", "").replace('"', '').replace("'", "")  # since volume is integer
            row += " - " + str(sell_accuracies[i]).replace('"', '').replace("'", "")
            row += " - " + str(sell_volumes[i]).replace(".0", "").replace('"', '').replace("'", "") + "\n"
            fo.write(row)


def export_all_matches_new(all_matches_filename, delimiter="|"):
    max_index = len(buy_accuracies)
    with open(all_matches_filename, "a") as fo:
        fo.write("A_BP1,A_BP2,A_BP3,A_BP4,A_BP5,A_BV1,A_BV2,A_BV3,A_BV4,A_BV5,A_AP1,A_AP2,A_AP3,A_AP4,A_AP5,A_AV1,A_AV2,A_AV3,A_AV4,A_AV5,")
        fo.write("N_BP1,N_BP2,N_BP3,N_BP4,N_BP5,N_BV1,N_BV2,N_BV3,N_BV4,N_BV5,N_AP1,N_AP2,N_AP3,N_AP4,N_AP5,N_AV1,N_AV2,N_AV3,N_AV4,N_AV5,")
        fo.write("D_BP1,D_BP2,D_BP3,D_BP4,D_BP5,D_BV1,D_BV2,D_BV3,D_BV4,D_BV5,D_AP1,D_AP2,D_AP3,D_AP4,D_AP5,D_AV1,D_AV2,D_AV3,D_AV4,D_AV5\n")

        for i in range(0, max_index):
            # for algo figures
            row = ",".join([s if s.count(delimiter) == 0 else s[:s.find(delimiter)] for s in buy_accuracies[i]]) + ","
            row += ",".join([s if s.count(delimiter) == 0 else s[:s.find(delimiter)] for s in buy_volumes[i]]) + ","
            row += ",".join([s if s.count(delimiter) == 0 else s[:s.find(delimiter)] for s in sell_accuracies[i]]) + ","
            row += ",".join([s if s.count(delimiter) == 0 else s[:s.find(delimiter)] for s in sell_volumes[i]]) + ","
            
            # for NSE figures
            row += ",".join([s if s.count(delimiter) == 0 else s[s.find(delimiter)+1:] for s in buy_accuracies[i]]) + ","
            row += ",".join([s if s.count(delimiter) == 0 else s[s.find(delimiter)+1:] for s in buy_volumes[i]]) + ","
            row += ",".join([s if s.count(delimiter) == 0 else s[s.find(delimiter)+1:] for s in sell_accuracies[i]]) + ","
            row += ",".join([s if s.count(delimiter) == 0 else s[s.find(delimiter)+1:] for s in sell_volumes[i]]) + ","
            
            # for difference figures
            row += ",".join(['0' if s.count(delimiter) == 0 else '1' for s in buy_accuracies[i]]) + ","
            row += ",".join(['0' if s.count(delimiter) == 0 else '1' for s in buy_volumes[i]]) + ","
            row += ",".join(['0' if s.count(delimiter) == 0 else '1' for s in sell_accuracies[i]]) + ","
            row += ",".join(['0' if s.count(delimiter) == 0 else '1' for s in sell_volumes[i]]) + "\n"
            fo.write(row)


############################################################################################
################################ Argparse Config #############################################
parser = argparse.ArgumentParser(description="Generate Order Book")
parser.add_argument('-sm', "--SECONDWISE_MODE", default=False, type=lambda x: (str(x).lower() == 'true'),  metavar='',help="Enter Boolean Value for secondwise mode...If secondwise mode, order book would be generated at fixed interval (default of 0.5 seconds)")
parser.add_argument('-ad', "--ALL_DATES", default=False, type=lambda x: (str(x).lower() == 'true'),  metavar='',help="Enter Boolean Value for all dates mode....If all dates, order book would be generated for all dates, else for a single or multiple date which you would be prompted for")
parser.add_argument("-as", "--ALL_STOCKS", default=False, type=lambda x: (str(x).lower() == 'true'), metavar='',help="Enter Boolean Value for all stocks mode...If all stocks, order book would be generated for all stocks, else for a single or multiple stocks which you would be prompted for")
parser.add_argument('-ld',"--listdates", nargs = "*", type=str, default=[], metavar='', help="If you chose all dates, enter empty else enter dates in the format 'DDMNYY' 'DDMMYY' (space separated if more than two inputs)")
parser.add_argument('-lst',"--liststocks", nargs = "*", type=str, default=[], help="If you chose all stocks then enter empty else enter stocks in the format 'stock1' 'stock2' (space separated if more than one stock)")
args = parser.parse_args()

############################################################################################

############################################################################################
################################ Config ####################################################

ROOT_DIR = os.getcwd()

############################################################################################


#******************************************************************************************#
#******************************* Main Function ********************************************#
#******************************************************************************************#

def generate_orderbook(SECONDWISE_MODE, ALL_DATES, ALL_STOCKS, listdates, liststocks):
    """ Take three inputs, 1) SECONDWISE_MODE : bool 2) ALL_DATES : bool, 3) ALL_STOCKS : bool
    If SECONDWISE_MODE : order book would be generated in a default interval of 0.5 seconds
    If ALL_DATES : order book for all dates would be generated
    returns generated order book for the specified STOCK_NAME
    """

    #########################################################################################
    ################################ Config #################################################
    # pdb.set_trace()
    all_dates = []
    all_stocks = []


    if not ALL_DATES:
        match_flags = []
        date = listdates
        # date = date.replace(" ", "").split(',')
        for i in date:
            if i not in os.listdir(ROOT_DIR + '/data/orders'):
                match_flags.append(False)
            else:
                match_flags.append(True)
        if False in match_flags:
            raise ValueError("No tick data available for the date entered. Date Invalid...Exiting the process")
            
        length = len(date)
        if length == 1:
            all_dates.append(date[0])
        else:
            all_dates = date  
    else:
        all_dates = os.listdir(ROOT_DIR + '/data/orders')

    if not ALL_STOCKS:
        match_flags = []
        # print(os.listdir(ROOT_DIR + '/data/orders/' + all_dates[0]))
        stock = liststocks
        for i in stock:
            if i not in os.listdir(ROOT_DIR + '/data/orders/' + all_dates[0]):
                match_flags.append(False)
            else:
                match_flags.append(True)
        if False in match_flags:
            raise ValueError("No tick data available for the stock entered. Stock Name Invalid...Exiting the process")


        print("Thanks for the inputs!!!!...Generating Order Book for the entered data\n")
        length = len(stock)
        if length == 1:
            all_stocks.append(stock[0])
        else:
            all_stocks = stock   
    else:
        all_stocks = os.listdir(ROOT_DIR + '/data/orders/' + all_dates[0])


    for date in all_dates:        
        for stock in all_stocks:
            # snapshot_file_path = "../../data/client_data/27th_reliance_all_data/20180927_corrected.txt"
            orders_file_path = ROOT_DIR + '/data/orders/' + date + '/' + stock
            trades_file_path = ROOT_DIR + '/data/trades/' + date + '/' + stock
            matches_dump_file = "all_matches_" + date + "_" + stock + ".out"

            generated_snapshot_file = ROOT_DIR + "/output/order_book_point5_seconds_" + date + "_" + stock + ".csv"
            sell_order_book_file = ROOT_DIR + "/output/sell_order_book_" + date + "_" + stock + ".csv"
            buy_order_book_file = ROOT_DIR + "/output/buy_order_book_" + date + "_" + stock + ".csv"

            snapshot_cols = ['stream_name', 'log_time_stamp', 'symbol', 'exchange', 'short_name',
                        'hub', 'scrip', 'array_buy_quantities', 'array_buy_prices', 'array_sell_prices',
                        'array_sell_quantities', 'array_buy_no_orders', 'array_sell_no_orders', 'volume_traded',
                        'open_price', 'currency', 'last_traded_price', 'lower_circuit', 'upper_circuit', 'high_price',
                        'low_price', 'close_price', 'last_trade_time', 'net_change_indicator', 'last_trade_quantity']

            order_cols = ['record_indicator', 'segment', 'order_no', 'jiffies',
                                'buy_sell_indicator', 'activity_type', 'symbol', 'series',
                                'volume_disclosed', 'volume_original', 'limit_price',
                                'trigger_price', 'market_order_flag', 'stop_loss_flag',
                                'IO_flag', 'algo_indicator', 'client_identity_flag']

            trade_cols = ['record_indicator', 'segment', 'trade_no', 'jiffies',
                                'symbol', 'series', 'trade_price', 'trade_quantity',
                                'buy_order_no', 'algo_indicator', 'buy_client_identity_flag',
                                'sell_order_no', 'sell_algo_indicator', 'sell_client_identity_flag']                                   

            ############################################################################################


            ################################ Secondwise config #########################################
            ############################################################################################
            # SECONDWISE_MODE = True
            #time update in seconds
            time_update = 0.5
            # start_time = "2018-09-27 09:00:00.000000+0530"
            # final_end_time = "2018-09-27 15:30:01.000000+0530"
            start_time = date[4:] + "-" + date[2:4] + "-" + date[0:2] + " " + "09:00:00.000000+0530"
            final_end_time = date[4:] + "-" + date[2:4] + "-" + date[0:2] + " " + "15:30:01.000000+0530"
            start_time = convert_str_datetime(start_time)
            final_end_time = convert_str_datetime(final_end_time)
            end_time = get_updated_time(start_time, time_update)

            num_timestamps = get_seconds(start_time, final_end_time) / time_update
            ############################################################################################



            t0 = datetime.now()
            #snap_t = t0

            if not SECONDWISE_MODE:
                #read snapshot, required ONLY for accuracy check
                df = pd.read_csv(snapshot_file_path, header=None, names=snapshot_cols)
                df['log_time_stamp'] = df['log_time_stamp'].apply(convert_str_datetime)
                df = df.sort_values(by='log_time_stamp')
                df.reset_index(inplace=True, drop=True)

                ############################### Here since it needs len(df) ################################
                num_timestamps = len(df) #3001


            # read orders tick data
            df_orders = pd.read_csv(orders_file_path, delim_whitespace=True, header=None, names=order_cols)

            #we only process "EQ" series
            df_orders = df_orders[df_orders["series"] == 'EQ']  # VEDL has P1 series, SBIN has Nx series, hence.... (fix added on 28/01/2019)

            df_orders['limit_price'] =  df_orders.limit_price.apply(func=(lambda x: x/100.0))
            df_orders['trigger_price'] =  df_orders.trigger_price.apply(func=(lambda x: x/100.0))
            df_orders.loc[df_orders["volume_disclosed"] == 0, "volume_disclosed"] = df_orders["volume_original"]  # to replace 0 volume_disclosed 

            # read trades tick data
            df_trades = pd.read_csv(trades_file_path, delim_whitespace=True, header=None, names=trade_cols)

            #we only process "EQ" series
            df_trades = df_trades[df_trades["series"] == 'EQ']  # VEDL has P1 series, SBIN has Nx series, hence.... (fix added on 28/01/2019)

            df_trades['trade_price'] =  df_trades.trade_price.apply(func=(lambda x: x/100.0))

            #Converting jiffie to timestamps
            df_orders['log_time_stamp'] = df_orders['jiffies'].apply(convert_jiffies_datetime)
            df_trades['log_time_stamp'] = df_trades['jiffies'].apply(convert_jiffies_datetime)

            df_orders["order_trade_flag"] = "O"
            df_trades["order_trade_flag"] = "T"

            columns_to_add_in_trades =list(set(df_orders.columns) - set(df_trades.columns))
            columns_to_add_in_orders = list(set(df_trades.columns) - set(df_orders.columns))

            df_orders = pd.concat([df_orders, pd.DataFrame(columns=columns_to_add_in_orders)],axis=1)
            df_trades = pd.concat([df_trades, pd.DataFrame(columns=columns_to_add_in_trades)],axis=1)

            df_orders.fillna(0, inplace=True)
            df_trades.fillna(0, inplace=True)

            all_transactions = df_orders.append(df_trades)

            #GC df_trades and df_orders
            del(df_orders)
            del(df_trades)
            gc.collect()

            print("Series counter: ", Counter(all_transactions["series"]))

            # all_transactions.sort_values(by='log_time_stamp', ascending=True, inplace=True)
            # lower orders must come first, this also ensures Trade before Order for same jiffy
            all_transactions.sort_values(by=["jiffies", "order_no"], ascending=[True, True], inplace=True)  
            #all_transactions.set_index('log_time_stamp', inplace=True)   #TODO: remove this index
            all_transactions.reset_index()


            categories = {}
            # categories['Categories'] = 'AP1,AP2,AP3,AP4,AP5,\
            # AV1,AV2,AV3,AV4,AV5,\
            # BP1,BP2,BP3,BP4,BP5,\
            # BV1,BV2,BV3,BV4,BV5,Trade_Quantity,last_traded_price'

            categories['Categories'] = 'AP1,AP2,AP3,AP4,AP5,AV1,AV2,AV3,AV4,AV5,BP1,BP2,BP3,BP4,BP5,BV1,BV2,BV3,BV4,BV5,Trade_Quantity,last_traded_price'

            with open(generated_snapshot_file, "a") as f:
                writer = csv.writer(f)
                for key, value in categories.items():
                    writer.writerow(["Timestamp", value])

            #For testing only
            # for name, group in order_groups:
            # pdb.set_trace()
            cumulative_volume_traded_nse = 0
            cumulative_volume_traded_historical = 0

            #Empty Buy order book and sell order book
            buy_order_book = pd.DataFrame()  # put index as order_no
            sell_order_book = pd.DataFrame() # put index as order_no
            buy_order_book_dict = OrderedDict()
            sell_order_book_dict = OrderedDict()
            bin_trade_volumes = {}
            bin_trade_volumes_nse = {}

            last_traded_price = 0
            #second_last_traded_price = 0

            unexcuted_buy_stoploss_orders = pd.DataFrame()
            unexcuted_sell_stoploss_orders = pd.DataFrame()

            ask_price = [0,0,0,0,0,0,0,0,0,0]
            bid_price = [0,0,0,0,0,0,0,0,0,0]
            ask_volume = [0,0,0,0,0,0,0,0,0,0]
            bid_volume = [0,0,0,0,0,0,0,0,0,0]

            if not SECONDWISE_MODE:
                total_accuracies = []
                buy_accuracies = []
                sell_accuracies= []
                buy_volumes = []
                sell_volumes = []

                temp_index = 0

                #untriggered_buy_orders = []
                #untriggered_sell_orders = []    
                last_two_bin_price_snapshots =[]
                a_last_two_bin_price_snapshots = []
                b_last_two_bin_price_snapshots = []
                a_last_two_bin_volume_snapshots = []
                b_last_two_bin_volume_snapshots = []
                group_shapes = []




            print("@@@@@@@@@@@@@@@@@--------------->>>> {} with SL order moving back to SL book after triggering fixes".format(num_timestamps))

            if not SECONDWISE_MODE:
                # cut off timestamp must be before loops start
                first_ts = df['log_time_stamp'][0].to_pydatetime()
                cut_off_time = first_ts
                cut_off_time = cut_off_time.replace(hour=15, minute=30, second=1, microsecond=0)

                # to ignore pre-open price & volume check
                pre_open_period = first_ts
                pre_open_period = pre_open_period.replace(hour=9, minute=15, second=0, microsecond=0)


            for i in range(0, int(num_timestamps) -1):  # to cover last 2 in start & end time
                
                if not SECONDWISE_MODE:
                    #start_time = datetime.time(df['log_time_stamp'][i])
                    #end_time = datetime.time(df['log_time_stamp'][i+1])

                    start_time = df['log_time_stamp'][i].to_pydatetime()
                    end_time = df['log_time_stamp'][i+1].to_pydatetime()

                    #current_ts = df['log_time_stamp'][i].to_pydatetime()    

                    if start_time > cut_off_time:
                        print("Stopping after cut-off: {}".format(cut_off_time))
                        break

                print("Iteration {} for timestamps: {} - {}".format(i+1, start_time, end_time.time()))    
                if i == (num_timestamps-2):
                    #group = all_transactions.between_time(start_time, end_time, include_end=True)        
                    # temp = temp_1.between_time(start_time, end_time, include_end=True)        
                    query_string = 'log_time_stamp >= "{}"  & log_time_stamp <= "{}"'.format(start_time, end_time)
                else:
                    #group = all_transactions.between_time(start_time, end_time, include_end=False)
                    # temp = temp_1.between_time(start_time, end_time, include_end=False)
                    query_string = 'log_time_stamp >= "{}"  & log_time_stamp < "{}"'.format(start_time, end_time)
                #create group based on diff of two timestamps
                group = all_transactions.query(query_string)    
                
                group.reset_index(inplace=True)  #TODO: comment this or remove
                
                if not SECONDWISE_MODE:
                    group_shapes.append(group.shape[0])
                    #print ("group shapes are : ", group_shapes, "\n")

                    if len(group_shapes) <= 19: #3
                        nse_timestamp_compare = False

                    elif len(group_shapes) > 19: #3
                        if len(group_shapes) > 20: #4
                            no_records_remove = group_shapes[0]
                            group_shapes = group_shapes[1:]
                            last_two_bin_price_snapshots = last_two_bin_price_snapshots[no_records_remove:]
                            a_last_two_bin_price_snapshots = a_last_two_bin_price_snapshots[no_records_remove:]
                            b_last_two_bin_price_snapshots = b_last_two_bin_price_snapshots[no_records_remove:]

                            a_last_two_bin_volume_snapshots = a_last_two_bin_volume_snapshots[no_records_remove:]
                            b_last_two_bin_volume_snapshots = b_last_two_bin_volume_snapshots[no_records_remove:]

                        nse_timestamp = df['log_time_stamp'][i].strftime(FMT) 
                        nse_timestamp_compare = True
                    # nse_timestamp = df['log_time_stamp'][i].strftime(FMT)

                    if nse_timestamp_compare == True:
                        nse_snapshot = df[df.log_time_stamp==nse_timestamp]
                        if nse_snapshot.shape[0]>1:
                            nse_snapshot = nse_snapshot.iloc[0]
                            buy_prices_best_end_time  = ast.literal_eval(nse_snapshot.array_buy_prices)[0:5]
                            sell_prices_best_end_time = ast.literal_eval(nse_snapshot.array_sell_prices)[0:5]
                            buy_volumes_best_end_time = ast.literal_eval(nse_snapshot.array_buy_quantities)[0:5]
                            sell_volumes_best_end_time = ast.literal_eval(nse_snapshot.array_sell_quantities)[0:5]

                            # best_buy_nse_snapshot.append(buy_prices_best_end_time)
                            # best_sell_nse_snapshot.append(sell_prices_best_end_time)
                        
                        else:
                            buy_prices_best_end_time  = ast.literal_eval(nse_snapshot.array_buy_prices.values[0])[0:5]
                            sell_prices_best_end_time = ast.literal_eval(nse_snapshot.array_sell_prices.values[0])[0:5]
                            buy_volumes_best_end_time = ast.literal_eval(nse_snapshot.array_buy_quantities.values[0])[0:5]
                            sell_volumes_best_end_time = ast.literal_eval(nse_snapshot.array_sell_quantities.values[0])[0:5]
                            # print("_nse_timestamp_compare_  *else* being used.............")

                            # best_buy_nse_snapshot.append(buy_prices_best_end_time)
                            # best_sell_nse_snapshot.append(sell_prices_best_end_time)

                        nse_snapshot_limit_prices = '_'.join([str(float(price)) for price in sell_prices_best_end_time]) + '_' + '_'.join([str(float(price)) for price in buy_prices_best_end_time])
                        a_nse_snapshot_limit_prices = '_'.join([str(float(price)) for price in sell_prices_best_end_time])
                        b_nse_snapshot_limit_prices = '_'.join([str(float(price)) for price in buy_prices_best_end_time])
                        a_nse_snapshot_volumes = '_'.join([str(int(volume)) for volume in sell_volumes_best_end_time])
                        b_nse_snapshot_volumes = '_'.join([str(int(volume)) for volume in buy_volumes_best_end_time])


                name = str(start_time.time()) + ' - ' + str(end_time.time())
                # timestamps.append(name)

                cumulative_volume_traded_historical += group["trade_quantity"].sum()
                # bin_trade_volumes_nse[name] = df.loc[i+1]['volume_traded']#cumulative_volume_traded_nse
                bin_trade_volumes[name] = cumulative_volume_traded_historical

                for idx, sample in group.iterrows():
                    if not SECONDWISE_MODE:
                        temp_index += 1

                    if sample["order_trade_flag"] == "O":
                        current_order_no = sample['order_no']               
                            
                        #Cancelling the orders
                        if sample['activity_type'] == 3:
                            if sample['buy_sell_indicator'] == 'B':
                                # if sample['market_order_flag'] != 'Y':
                                if sample["stop_loss_flag"] == "Y":
                                    unexcuted_buy_stoploss_orders = unexcuted_buy_stoploss_orders[unexcuted_buy_stoploss_orders["order_no"] != current_order_no]  #TODO: refactor
                                    if current_order_no in buy_order_book.order_no.tolist():
                                        buy_order_book = buy_order_book[buy_order_book['order_no'] != current_order_no]
                                elif sample["stop_loss_flag"] == "N":
                                    buy_order_book = buy_order_book[buy_order_book['order_no'] != current_order_no] #deleting the limit orders and market orders
                                else:
                                    raise ValueError("Invalid Stop Loss Flag")                    

                            elif sample['buy_sell_indicator'] == 'S':
                                #ADDED MARKET ORDER FLAG SUPPORT AND STOP 
                                # if sample['market_order_flag'] != 'Y':
                                if sample["stop_loss_flag"] == "Y":
                                    unexcuted_sell_stoploss_orders = unexcuted_sell_stoploss_orders[unexcuted_sell_stoploss_orders["order_no"] != current_order_no] #TODO: refactor
                                    if current_order_no in sell_order_book.order_no.tolist():
                                        sell_order_book = sell_order_book[sell_order_book['order_no'] != current_order_no]
                                elif sample["stop_loss_flag"] == "N":
                                    sell_order_book = sell_order_book[sell_order_book['order_no'] != current_order_no] #deleting sell limit orders and market orders
                                else:
                                    raise ValueError("Invalid Stop Loss Flag")
                            else:
                                raise ValueError("Invalid Buy Sell Indicator")

                        #Modification Activity
                        elif sample['activity_type']==4:

                            if sample['buy_sell_indicator']=='B':

                                if sample["stop_loss_flag"] == "Y":

                                    #order should remain in order book once triggered
                                    if current_order_no in buy_order_book.order_no.tolist():
                                        old_buy_order = buy_order_book.query("order_no == " + str(current_order_no))
                                        buy_order_book = buy_order_book[buy_order_book['order_no'] != current_order_no]  #TODO: refactor

                                        # In [47]: df_orders[df_orders["order_no"] == 1200000000114150][["log_time_stamp", "activity_type", "limit_price", "volume_original", "volume_disclosed", "market_order_flag", "stop_loss_flag"]]               
                                        # Out[47]: 
                                        #                   log_time_stamp  activity_type  limit_price  volume_original  volume_disclosed market_order_flag stop_loss_flag
                                        # 7059  2018-09-25 09:15:22.884216              1       1243.0              100                 0                 N              N
                                        # 25257 2018-09-25 09:16:27.063995              4       1229.0              100                 0                 N              Y
                                        # 48301 2018-09-25 09:17:52.234055              4       1243.0              100                 0                 N              N

                                        if old_buy_order.stop_loss_flag.values[0] == 'Y' and (old_buy_order.trigger_price == sample.trigger_price).values[0]:  # normal modification AND it is possible that trigger price changes for activated SL orders (ref: 1200000005828110 on 26/9/18)
                                            buy_order_book = buy_order_book.append(sample) 
                                        else:  # it is possible that stopploss 'N' gets converted to 'Y' (ref: order no 1200000000114150 on 25/9/18)
                                            unexcuted_buy_stoploss_orders = unexcuted_buy_stoploss_orders.append(sample)  # it is possible that trigger price changes for activated SL orders (ref: 1200000005828110 on 26/9/18)

            
                                        #                                     order_no  activity_type stop_loss_flag market_order_flag order_trade_flag  limit_price  trigger_price  volume_disclosed  volume_original
                                        # log_time_stamp                                                                                                                                                              
                                        # 2018-09-26 14:09:18.343796  1200000005828110              1              Y                 N                O      1236.35        1236.35                25               25
                                        # 2018-09-26 14:09:47.601456  1200000005828110              1              Y                 N                O      1236.35        1236.35                25               25
                                        # 2018-09-26 14:11:10.305664  1200000005828110              4              Y                 N                O      1245.00        1245.00                25               25
                                        # 2018-09-26 14:16:42.118454  1200000005828110              4              Y                 N                O      1255.00        1255.00                25               25
                                        # 2018-09-26 14:22:02.173813  1200000005828110              3              Y                 N                O      1255.00        1255.00                25               25
                                            
                                    elif unexcuted_buy_stoploss_orders.empty != True:
                                        if current_order_no in unexcuted_buy_stoploss_orders.order_no.tolist():
                                            unexcuted_buy_stoploss_orders = unexcuted_buy_stoploss_orders[unexcuted_buy_stoploss_orders["order_no"] != current_order_no]
                                            unexcuted_buy_stoploss_orders = unexcuted_buy_stoploss_orders.append(sample)
                                        else:    
                                            ValueError("SL order missing in Buy Sl order book @@@@@@@@-----> {}".format(current_order_no))		
                                    else:
                                        print("SL order  @@@@@@@@-----> {}".format(current_order_no))
                                        raise ValueError("Stop loss order missing from buy order book and stop loss book")

                                elif sample["stop_loss_flag"] == "N":
                                    #Check if stoploss orders getting converted to limit or market orders
                                    if unexcuted_buy_stoploss_orders.empty != True:
                                        if sample['order_no'] in unexcuted_buy_stoploss_orders.order_no.values.tolist():
                                            unexcuted_buy_stoploss_orders = unexcuted_buy_stoploss_orders[unexcuted_buy_stoploss_orders["order_no"] != current_order_no]
                                            # unexcuted_buy_stoploss_orders = unexcuted_buy_stoploss_orders.append(sample)
                                        else:
                                            pass
                                    if buy_order_book.empty != True:
                                        buy_order_book = buy_order_book[buy_order_book['order_no'] != current_order_no]
                                    buy_order_book = buy_order_book.append(sample)
                                else:
                                    raise ValueError("Invalid Stop Loss Flag")

                            elif sample['buy_sell_indicator']=='S':
                                    
                                if sample["stop_loss_flag"] == "Y":
                                    #Order should remain in order book once triggered
                                    if current_order_no in sell_order_book.order_no.tolist():
                                        old_sell_order = sell_order_book.query("order_no == " + str(current_order_no))
                                        sell_order_book = sell_order_book[sell_order_book['order_no'] != current_order_no]                       

                                        if old_sell_order.stop_loss_flag.values[0] == 'Y' and (old_sell_order.trigger_price == sample.trigger_price).values[0]:  # normal modification AND it is possible that trigger price changes for activated SL orders (ref: 1200000005828110 on 26/9/18) 
                                            sell_order_book = sell_order_book.append(sample)
                                        else:  # it is possible that stopploss 'N' gets converted to 'Y' (ref: order no 1200000000114150 on 25/9/18)
                                            unexcuted_sell_stoploss_orders = unexcuted_sell_stoploss_orders.append(sample) # it is possible that trigger price changes for activated SL orders (ref: 1200000005828110 on 26/9/18)

                                    # unexcuted_sell_stoploss_orders = unexcuted_sell_stoploss_orders[unexcuted_sell_stoploss_orders["order_no"] != current_order_no]
                                    
                                    elif unexcuted_sell_stoploss_orders.empty != True:
                                        if current_order_no in unexcuted_sell_stoploss_orders.order_no.tolist():
                                            unexcuted_sell_stoploss_orders = unexcuted_sell_stoploss_orders[unexcuted_sell_stoploss_orders["order_no"] != current_order_no]
                                            unexcuted_sell_stoploss_orders = unexcuted_sell_stoploss_orders.append(sample)
                                        else:    
                                            ValueError("SL order missing in Sell SL order book @@@@@@@@-----> {}".format(current_order_no))           
                                    else:
                                        raise ValueError("Stop loss order missing from sell order book and stop loss book")


                                elif sample["stop_loss_flag"] == "N":
                                    #Check if stoploss orders getting converted to market or limit orders
                                    if unexcuted_sell_stoploss_orders.empty != True:
                                        if sample['order_no'] in unexcuted_sell_stoploss_orders.order_no.values.tolist():
                                            unexcuted_sell_stoploss_orders = unexcuted_sell_stoploss_orders[unexcuted_sell_stoploss_orders["order_no"] != current_order_no]
                                            # unexcuted_sell_stoploss_orders = unexcuted_sell_stoploss_orders.append(sample)
                                    else:
                                        pass

                                    if sell_order_book.empty != True:
                                        sell_order_book = sell_order_book[sell_order_book['order_no'] != current_order_no]
                                    sell_order_book = sell_order_book.append(sample)
                                else:
                                    raise ValueError("Invalid Stop Loss Flag")

                            else:
                                raise ValueError("invalid buy sell indicator, stopping the execution")

                        elif sample['activity_type']==1: #order entry
                            if sample['buy_sell_indicator'] == 'B':
                                if sample["stop_loss_flag"] == "Y":
                                    
                                    if unexcuted_buy_stoploss_orders.empty != True and sample["order_no"] in unexcuted_buy_stoploss_orders.order_no.tolist():
                                        unexcuted_buy_stoploss_orders = unexcuted_buy_stoploss_orders[unexcuted_buy_stoploss_orders["order_no"] != current_order_no]
                                        buy_order_book = buy_order_book.append(sample)   # 1 is moving SL order to buy order book
                                    else:
                                        unexcuted_buy_stoploss_orders = unexcuted_buy_stoploss_orders.append(sample)

                                    
                                elif sample["stop_loss_flag"] == "N":
                                    #is this necessary because only stop_loss_flag == "Y" will have multiple one entries
                                    if buy_order_book.empty != True:
                                        buy_order_book = buy_order_book[buy_order_book["order_no"] != current_order_no]

                                    buy_order_book = buy_order_book.append(sample)

                                else:
                                    raise ValueError("Invalid Stop Loss Flag")

                            elif sample['buy_sell_indicator'] == 'S':
                                if sample["stop_loss_flag"] == "Y":

                                    if unexcuted_sell_stoploss_orders.empty != True and sample["order_no"] in unexcuted_sell_stoploss_orders.order_no.tolist():
                                        unexcuted_sell_stoploss_orders = unexcuted_sell_stoploss_orders[unexcuted_sell_stoploss_orders["order_no"] != current_order_no]
                                        sell_order_book = sell_order_book.append(sample)  # 1 is moving SL order to sell order book
                                    else:
                                        unexcuted_sell_stoploss_orders = unexcuted_sell_stoploss_orders.append(sample)

                                elif sample["stop_loss_flag"] == "N":
                                    #is this necessary because only stop loss orders would have multiple one entries
                                    if sell_order_book.empty != True:
                                        sell_order_book = sell_order_book[sell_order_book["order_no"] != current_order_no]
                                    sell_order_book = sell_order_book.append(sample)
                                else:
                                    raise ValueError("Invalid Stop Loss Flag")
                            else:
                                print ("invalid buy sell indicator")
                                raise ValueError("invalid buy sell indicator, stopping the execution")


                        else:
                            print ("invalid activity type")
                            raise ValueError("invalid activity type, stopping the execution")

                    
                    # ####################################################################  Trade Settlement ####################################################################        
                    elif sample['order_trade_flag']=='T':
                        trade_sample = sample
                        current_buy_order = trade_sample['buy_order_no']
                        current_sell_order = trade_sample['sell_order_no']
                        second_last_traded_price = last_traded_price
                        last_traded_price = trade_sample['trade_price']

                        trade_quantity = trade_sample['trade_quantity']
                        current_jiffies = trade_sample["jiffies"]            

                        # settle buy order
                        if trade_sample['trade_quantity']==buy_order_book.loc[buy_order_book["order_no"] == current_buy_order]['volume_original'].values[0]:
                            buy_order_book = buy_order_book[buy_order_book["order_no"] != current_buy_order]  #TODO: refactor
                        elif trade_sample['trade_quantity'] < buy_order_book.loc[buy_order_book["order_no"] == current_buy_order]['volume_original'].values[0]:
                            remaining_volume = buy_order_book.loc[buy_order_book["order_no"] == current_buy_order]['volume_original'].values[0] - trade_sample['trade_quantity']
                            #Updating volume original 
                            buy_order_book.loc[(buy_order_book["order_no"] == current_buy_order), 'volume_original'] = remaining_volume

                            # complex logic for disclosed volume
                            original_buy_volume_disclosed = all_transactions.query("order_no == " + str(current_buy_order) + " and jiffies < " + str(current_jiffies))["volume_disclosed"].values[-1] #take the last value
                            disclosed_volume = original_buy_volume_disclosed

                            current_disclosed_volume = buy_order_book.loc[buy_order_book["order_no"] == current_buy_order]['volume_disclosed'].values[0] 
                            if trade_quantity == current_disclosed_volume:
                                disclosed_volume = original_buy_volume_disclosed                              
                            elif trade_quantity < current_disclosed_volume:
                                disclosed_volume = current_disclosed_volume - trade_quantity    
                            # elif trade_quantity > current_disclosed_volume:
                            #     multiplier = int(np.ceil((trade_quantity - current_disclosed_volume)/original_buy_volume_disclosed))
                            #     disclosed_volume = ((multiplier * original_buy_volume_disclosed) + current_disclosed_volume) - trade_quantity
                            #     if disclosed_volume == 0: 
                            #         disclosed_volume = original_buy_volume_disclosed


                            # disclosed_volume = min(remaining_volume, buy_order_book.loc[buy_order_book["order_no"] == current_buy_order]['volume_disclosed'].values[0])
                            # buy_order_book.loc[(buy_order_book["order_no"] == current_buy_order),'volume_disclosed'] = disclosed_volume
                            buy_order_book.loc[(buy_order_book["order_no"] == current_buy_order),'volume_disclosed'] = disclosed_volume if remaining_volume > original_buy_volume_disclosed else remaining_volume #Updating volume disclosed
                        else:
                            raise ValueError("Invalid Trade Quantity Found for order no {}".format(current_buy_order))

                        # settle sell order    
                        if trade_sample['trade_quantity']==sell_order_book.loc[sell_order_book["order_no"] == current_sell_order]['volume_original'].values[0]:
                            sell_order_book = sell_order_book[sell_order_book["order_no"] != current_sell_order]
                        elif trade_sample['trade_quantity'] < sell_order_book.loc[sell_order_book["order_no"] == current_sell_order]['volume_original'].values[0]:
                            remaining_volume = sell_order_book.loc[sell_order_book["order_no"] == current_sell_order]['volume_original'].values[0] - trade_sample['trade_quantity'] 
                            sell_order_book.loc[(sell_order_book["order_no"] == current_sell_order), 'volume_original'] = remaining_volume

                            # complex logic for disclosed volume
                            original_sell_volume_disclosed = all_transactions.query("order_no == " + str(current_sell_order) + " and jiffies < " + str(current_jiffies))["volume_disclosed"].values[-1] #take the last value
                            disclosed_volume = original_sell_volume_disclosed

                            current_disclosed_volume = sell_order_book.loc[sell_order_book["order_no"] == current_sell_order]['volume_disclosed'].values[0]
                            if trade_quantity == current_disclosed_volume:
                                disclosed_volume = original_sell_volume_disclosed               
                            elif trade_quantity < current_disclosed_volume:
                                disclosed_volume = current_disclosed_volume - trade_quantity                    
                            # elif trade_quantity > current_disclosed_volume:
                            #     multiplier = int(np.ceil((trade_quantity - current_disclosed_volume)/original_sell_volume_disclosed))
                            #     disclosed_volume = ((multiplier * original_sell_volume_disclosed) + current_disclosed_volume) - trade_quantity
                            #     if disclosed_volume == 0:
                            #         disclosed_volume = original_sell_volume_disclosed

                            # disclosed_volume = min(remaining_volume, sell_order_book.loc[sell_order_book["order_no"] == current_sell_order]['volume_disclosed'].values[0])
                            # sell_order_book.loc[(sell_order_book["order_no"] == current_sell_order),'volume_disclosed'] = disclosed_volume
                            sell_order_book.loc[(sell_order_book["order_no"] == current_sell_order),'volume_disclosed'] = disclosed_volume if remaining_volume > original_sell_volume_disclosed else remaining_volume #Updating volume disclosed                            
                        else:
                            raise ValueError("Invalid Trade Quantity Found for order no {}".format(current_sell_order))

                    else:
                        raise ValueError("Stopping The Order Book Generation Process- Invalid transaction type")


                
                    if not SECONDWISE_MODE:    
                        ## $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Order Book generation $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$    
                        if sell_order_book.empty!=True:
                            sell_order_book_without_market_orders = sell_order_book.query("market_order_flag != 'Y'")
                            volume_aggregated_df_sell = pd.DataFrame(sell_order_book_without_market_orders.groupby('limit_price')['volume_disclosed'].sum())
                            #volume_aggregated_df_sell = pd.DataFrame(sell_order_book.groupby('limit_price')['volume_disclosed'].sum())
                            volume_aggregated_df_sell.reset_index(drop=False, inplace=True)
                            #volume_aggregated_df_sell.loc[volume_aggregated_df_sell["limit_price"] == 0.0, "limit_price"] = last_traded_price  # new stuff replace LTP here, so it gets involved in sort    
                            volume_aggregated_df_sell.sort_values(by='limit_price', ascending=True,inplace=True)

                            ask_price = volume_aggregated_df_sell['limit_price'].ravel()[:5]           
                            ask_volume = volume_aggregated_df_sell['volume_disclosed'].ravel()[:5]

                            sell_order_book_dict[sample['log_time_stamp']] = [fill_array(ask_price), fill_array(ask_volume)]            
                            
                        if buy_order_book.empty!=True:
                            #print("Inside BOB\n")
                            buy_order_book_without_market_orders = buy_order_book.query("market_order_flag != 'Y'")
                            volume_aggregated_df_buy = pd.DataFrame(buy_order_book_without_market_orders.groupby('limit_price')['volume_disclosed'].sum())
                            #volume_aggregated_df_buy = pd.DataFrame(buy_order_book.groupby('limit_price')['volume_disclosed'].sum())
                            volume_aggregated_df_buy.reset_index(drop=False, inplace=True)
                            #volume_aggregated_df_buy.loc[volume_aggregated_df_buy["limit_price"] == 0.0, "limit_price"] = last_traded_price  # new loic for LTP, so it gets involved in sort
                            volume_aggregated_df_buy.sort_values(by='limit_price', ascending=False,inplace=True)            

                            bid_price = volume_aggregated_df_buy['limit_price'].ravel()[:5]
                            bid_volume = volume_aggregated_df_buy['volume_disclosed'].ravel()[:5]
                            
                            buy_order_book_dict[sample['log_time_stamp']] = [fill_array(bid_price), fill_array(bid_volume), bin_trade_volumes[name], last_traded_price]

                        
                        # should be used if we are settling market orders ourselves with LTP   
                        # if sell_order_book.empty!=True and 0.0 in ask_price:  # for market orders
                        #      ask_price[0] = last_traded_price
                        #      ask_price.sort()
                        #      sell_order_book_dict[sample['log_time_stamp']] = [ask_price, ask_volume]
                        
                        # if buy_order_book.empty!=True and 0.0 in bid_price:  # for market orders
                        #      bid_price[len(bid_price) - 1] = last_traded_price
                        #      bid_price[::-1].sort()
                        #      buy_order_book_dict[sample['log_time_stamp']] = [bid_price, bid_volume, bin_trade_volumes[name], last_traded_price]    
                    


                        limit_price_snapshot = '_'.join([str(price) for price in ask_price]) + '_' + '_'.join([str(price) for price in bid_price])
                        last_two_bin_price_snapshots.append(limit_price_snapshot)

                        a_last_two_bin_price_snapshots.append('_'.join([str(price) for price in ask_price]))
                        b_last_two_bin_price_snapshots.append('_'.join([str(price) for price in bid_price]))

                        a_last_two_bin_volume_snapshots.append('_'.join([str(int(volume)) for volume in ask_volume]))
                        b_last_two_bin_volume_snapshots.append('_'.join([str(int(volume)) for volume in bid_volume]))
                
                
                        #print('Time required for completing group {} : {}\n'.format(name, datetime.now() - snap_t))
                        #snap_t = datetime.now()

                        if (temp_index+1) % 1000 == 0:
                        # if i == (len(df)-2):
                            for key, value in sell_order_book_dict.items():
                                value.extend(buy_order_book_dict[key])
                                stacked_values= np.hstack(value)
                                stacked_values=stacked_values.astype(str)
                                sell_order_book_dict[key]=",".join(stacked_values)

                            #print('##################################################')   
                            print("####################### Writing ({}).....".format(temp_index+1))
                            #print('##################################################')
                            
                            with open(generated_snapshot_file, 'a') as f:
                                writer = csv.writer(f)
                                for key, value in sell_order_book_dict.items():
                                    writer.writerow([key, value])
                            buy_order_book_dict = OrderedDict()
                            sell_order_book_dict = OrderedDict()
                            gc.collect()

                        if nse_timestamp_compare:

                            if start_time >= pre_open_period:
                                total_accuracies.append(calc_accuracy(nse_snapshot_limit_prices, last_two_bin_price_snapshots))
                                # use when you need to dump all prices - matching as well as non-matching
                                buy_accuracies.append(calc_accuracy_with_diff_dump_all(b_nse_snapshot_limit_prices, b_last_two_bin_price_snapshots))
                                sell_accuracies.append(calc_accuracy_with_diff_dump_all(a_nse_snapshot_limit_prices, a_last_two_bin_price_snapshots))

                                # buy_accuracies.append(calc_accuracy(b_nse_snapshot_limit_prices, b_last_two_bin_price_snapshots))
                                # sell_accuracies.append(calc_accuracy(a_nse_snapshot_limit_prices, a_last_two_bin_price_snapshots))        

                                buy_volumes.append(calculate_volume_accuracy(b_nse_snapshot_volumes, b_last_two_bin_volume_snapshots))
                                sell_volumes.append(calculate_volume_accuracy(a_nse_snapshot_volumes, a_last_two_bin_volume_snapshots))

                        #print ("length of last_two_bin_price_snapshots", len(last_two_bin_price_snapshots))



                if SECONDWISE_MODE:
                    ## $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Order Book generation $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$    
                    if sell_order_book.empty!=True:
                        sell_order_book_without_market_orders = sell_order_book.query("market_order_flag != 'Y'")
                        volume_aggregated_df_sell = pd.DataFrame(sell_order_book_without_market_orders.groupby('limit_price')['volume_disclosed'].sum())
                        #volume_aggregated_df_sell = pd.DataFrame(sell_order_book.groupby('limit_price')['volume_disclosed'].sum())
                        volume_aggregated_df_sell.reset_index(drop=False, inplace=True)
                        #volume_aggregated_df_sell.loc[volume_aggregated_df_sell["limit_price"] == 0.0, "limit_price"] = last_traded_price  # new stuff replace LTP here, so it gets involved in sort    
                        volume_aggregated_df_sell.sort_values(by='limit_price', ascending=True,inplace=True)

                        ask_price = volume_aggregated_df_sell['limit_price'].ravel()[:5]           
                        ask_volume = volume_aggregated_df_sell['volume_disclosed'].ravel()[:5]

                        sell_order_book_dict[name] = [fill_array(ask_price), fill_array(ask_volume)]            
                        
                    if buy_order_book.empty!=True:
                        #print("Inside BOB\n")
                        buy_order_book_without_market_orders = buy_order_book.query("market_order_flag != 'Y'")
                        volume_aggregated_df_buy = pd.DataFrame(buy_order_book_without_market_orders.groupby('limit_price')['volume_disclosed'].sum())
                        #volume_aggregated_df_buy = pd.DataFrame(buy_order_book.groupby('limit_price')['volume_disclosed'].sum())
                        volume_aggregated_df_buy.reset_index(drop=False, inplace=True)
                        #volume_aggregated_df_buy.loc[volume_aggregated_df_buy["limit_price"] == 0.0, "limit_price"] = last_traded_price  # new loic for LTP, so it gets involved in sort
                        volume_aggregated_df_buy.sort_values(by='limit_price', ascending=False,inplace=True)            

                        bid_price = volume_aggregated_df_buy['limit_price'].ravel()[:5]
                        bid_volume = volume_aggregated_df_buy['volume_disclosed'].ravel()[:5]
                        
                        buy_order_book_dict[name] = [fill_array(bid_price), fill_array(bid_volume), bin_trade_volumes[name], last_traded_price]

                    
                    # should be used if we are settling market orders ourselves with LTP   
                    # if sell_order_book.empty!=True and 0.0 in ask_price:  # for market orders
                    #      ask_price[0] = last_traded_price
                    #      ask_price.sort()
                    #      sell_order_book_dict[sample['log_time_stamp']] = [ask_price, ask_volume]
                    
                    # if buy_order_book.empty!=True and 0.0 in bid_price:  # for market orders
                    #      bid_price[len(bid_price) - 1] = last_traded_price
                    #      bid_price[::-1].sort()
                    #      buy_order_book_dict[sample['log_time_stamp']] = [bid_price, bid_volume, bin_trade_volumes[name], last_traded_price]    
                

                if not SECONDWISE_MODE:
                    if (i+2) == num_timestamps:         #(temp_index+1) % 1000 != 0:
                        for key, value in sell_order_book_dict.items():
                            value.extend(buy_order_book_dict[key])
                            stacked_values= np.hstack(value)
                            stacked_values=stacked_values.astype(str)
                            sell_order_book_dict[key]=",".join(stacked_values)

                        #print('##################################################')   
                        print("####################### Writing ({}).....".format(temp_index+1))
                        #print('##################################################')
                        
                        with open(generated_snapshot_file, 'a') as f:
                            writer = csv.writer(f)
                            for key, value in sell_order_book_dict.items():
                                writer.writerow([key, value])
                else:
                    if (i+1) % 1000 == 0 or (i+2) == num_timestamps:
                        for key, value in sell_order_book_dict.items():
                            if key in buy_order_book_dict.keys():
                                value.extend(buy_order_book_dict[key])
                            else:
                                 value.extend([np.array([0.0,0.0,0.0,0.0,0.0]), np.array([0.0,0.0,0.0,0.0,0.0]), 0, 0])  # empty 
                            stacked_values= np.hstack(value)
                            stacked_values=stacked_values.astype(str)
                            sell_order_book_dict[key]=",".join(stacked_values)

                        #print('##################################################')   
                        print("####################### Writing ({}).....".format(i+1))
                        #print('##################################################')
                        
                        with open(generated_snapshot_file, 'a') as f:
                            writer = csv.writer(f)
                            for key, value in sell_order_book_dict.items():
                                writer.writerow([key, value])

                        buy_order_book_dict = OrderedDict()
                        sell_order_book_dict = OrderedDict()
                        gc.collect()
                    
                    # update times for next iteration
                    start_time = get_updated_time(start_time, time_update)
                    end_time = get_updated_time(end_time, time_update)


            print("\n\nExporting buy_order_book and sell_order_book csv's")
            sell_order_book.to_csv(sell_order_book_file, index=False)
            buy_order_book.to_csv(buy_order_book_file, index=False)

            temp = get_dataframe(generated_snapshot_file)
            temp.to_csv(generated_snapshot_file, index=False)

            if not SECONDWISE_MODE:
                # dump all matches file
                #export_all_matches(matches_dump_file)
                print("Total time taken for generating '{}' - {}' snapshot (with NSE comparison): {}".format(start_time.date(), stock, datetime.now()-t0))
            else:    
                print("Total time taken for generating '{}' - {}' secondwise snapshot: {}".format(start_time.date(), stock, datetime.now()-t0))


if __name__ == "__main__":
    generate_orderbook(SECONDWISE_MODE = args.SECONDWISE_MODE, ALL_DATES = args.ALL_DATES, ALL_STOCKS = args.ALL_STOCKS, listdates = args.listdates, liststocks = args.liststocks)