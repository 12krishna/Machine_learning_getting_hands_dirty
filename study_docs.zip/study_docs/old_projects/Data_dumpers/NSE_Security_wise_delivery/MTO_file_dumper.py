import os
from cassandra.cluster import Cluster
import logging 
import pandas as pd
import datetime
import dateutil.parser as dparser
import time 
import requests
from dateutil import parser
import redis

processed_dir = "D:\\Data_dumpers\\NSE_Security_wise_delivery\\Processed_files\\"
log_path = "D:\\Data_dumpers\\NSE_Security_wise_delivery\\" 
master_dir = "D:\\Data_dumpers\\Master\\"
redis_host = 'localhost'
cassandra_host = '172.17.9.51'
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'}




# log events in debug mode 
logging.basicConfig(filename=log_path+"nse_security.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

    


def security_delivery_dumper(file_name, date,session,red):
    '''Func to dump security wise delivery from nse to cassandra'''
    
    # web scrap and get the data    
    url = 'https://archives.nseindia.com/archives/equities/mto/'+file_name
    print url
    # read holiday master
    holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
    if len(holiday_master[holiday_master['date']==date])==0:
        # working day so run until bhavcopy is downloaded
        while datetime.datetime.now().time() > datetime.time(16,0):
            # sleep for 2 min
            
            time.sleep(120)
            print 'Sleep for 2 minutes'
            logging.info('{} is Working day : sleep for 2 minutes '.format(date))
            try:
                response = requests.get(url, headers=headers, timeout=45)
                if response.status_code!= 200:
                    continue
                elif response.status_code== 200:
                    break
            except Exception as e:
                print e
                continue 
    else:
        print "Holiday : {}".format(date)
        return -1
    
    
    response = requests.get(url, headers=headers, timeout=45)
    trade_date, settlement_date = None, None
    if response.status_code == 200:
        # successfull connetion
        logging.info('Successful connection : status_code 200')
        
        # write data to file
        with open('temp.dat', 'wb') as f:
            # write the contents to temp dat file 
            f.write(response.content)
            f.close()
            date_extractor = str(response.content.split('\n')[2:3])
            trade_date =  dparser.parse(date_extractor[:25], fuzzy=True).date()
            logging.info('Traded date: {0}'.format(trade_date))
            print date_extractor
            settlement_date = ''
            try:
                settlement_date = dparser.parse(date_extractor[30:], fuzzy=True).date()
            except:
                logging.info("Settlement date not present in DAT file")
                print "Settlement date not present in DAT file"
        
            logging.info('Settlement date: {0}'.format(settlement_date))
            print 'Successfully downloaded {0}...'.format(file_name)
            logging.info('Successfully downloaded {0}...'.format(file_name))

    else:
        logging.info('Dat file not found for {0} day /{1} connection received from server...'.format(date,response.status_code))
        print 'Dat not found for {0} day /{1} connection received from server...'.format(date,response.status_code)
        return -1
    
    # read and process data to temp csv
    data = pd.read_csv('temp.dat', skiprows=4, delimiter=',', 
                       names=['Record Type','Sr No','Name of Security','Series',
                              'Quantity Traded','Deliverable Quantity(gross across client level)',
                              '% of Deliverable Quantity to Traded Quantity'], na_filter = False)
    og_len = len(data)
    
    data.drop(columns=['Record Type','Sr No'], inplace=True)
    # generate key to strore in cassandra db
    data['key'] = data['Name of Security']+'_'+data['Series']
    #get trade and settlement date
    data['Trade Date'] = trade_date
    data['Settlement Date'] = settlement_date
    data = data[['key','Trade Date','Settlement Date','Name of Security','Series',
                'Quantity Traded','Deliverable Quantity(gross across client level)',
                 '% of Deliverable Quantity to Traded Quantity']]
    data.to_csv('temp.csv', index=False)
    
    # processed file 
    data.to_csv(processed_dir+file_name)    
    # write csv file to cassandra db
    os.system(log_path+"dump.bat ")  
    
    #get number of rows dumped into cassandra and original rows in file
    d = datetime.datetime.strftime(datetime.datetime.strptime( file_name[4:6]+' '+file_name[6:8]+' '+file_name[8:12],
                                                      '%d %m %Y').date(), "%Y-%m-%d")
            
    c_len = session.execute('select count(*) from rohit.nse_security_wise_delivery where trade_date = \'{}\' allow filtering;'.format(d)).one()[0]
            
    print 'Number of rows in orginal file {},number of rows dumped in cassandra {}'.format(og_len,c_len)
    logging.info('{} : Number of rows in orginal file {}, number of rows dumped in cassandra {} '.format(d,og_len,c_len))
    # remove bhavcopy from download dir
                
    red.set('nse_mto_dumper', 1)
    red.set("market_snap_nse_security",1)
            
    red.set('nse_mto_dumper_lengths',
                  '{}: {} rows dumped in cassandra , whereas {} rows were present in original file'.format(d,c_len,og_len))
    
    
    logging.info('File successfully dumped to cassandra and moved to processed folder')
    return 1


def getFilename(date):
    '''Func to get filenames for given date'''
    return 'MTO_{0}{1}{2}.DAT'.format(date.strftime("%d"), date.strftime("%m"), date.strftime("%Y"))


def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster



def main():
    
    r = redis.Redis(host=redis_host, port=6379) 
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()
    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')
    logging.info('Using rohit keyspace')
    
    # CREATE A TABLE; to dump MTO files 
    session.execute('CREATE TABLE IF NOT EXISTS nse_security_wise_delivery (key VARCHAR, trade_date DATE, settlement_date DATE, Name_of_security VARCHAR, series VARCHAR, Quantity_Traded Decimal,Deliverable_Quantity_gross_client_level DECIMAL,Deliverable_Quantity_to_Traded_Quantity_percent DECIMAL, PRIMARY KEY (key, trade_date))')
    
    # check in processed folder and if not then dowload MTO file and dump in cassandra    
    errContinous = 0        
    d = datetime.date.today()-datetime.timedelta(days=0)
    decr = datetime.timedelta(days=1)
    while errContinous > -30 and (not os.path.exists(os.path.join(processed_dir,getFilename(d)))):
        if d == parser.parse('2015 12 31').date():
            logging.info('All files dumped till 2016/1/1')
            break
        
        if security_delivery_dumper(getFilename(d), d, session,r ) > -1:
            errContinous = 0
            logging.info('Final Success: {0}'.format(d))
        else:
            errContinous -= 1
        d -= decr
        
             
        
        
start_time = time.time()
if __name__ == '__main__':
    main()

end_time = time.time()

logging.info('Time taken to process :'.format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)
