# -*- coding: utf-8 -*-
"""
Created on Tue Jul 12 11:38:35 2022

@author: backup
"""

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import glob

from selenium  import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import time
import requests
import os
import pandas as pd
import logging
import sys
import datetime

server = '172.17.9.149'; port = 25
master_dir = "D:\\Data_dumpers\\Master\\"
#MY_ADDRESS = 'KIEResearchAlerts@kotak.com'
contacts_dir="D:\\Data_dumpers\\Circulars\\"

download_dir="D:\\Data_dumpers\\Circulars\\NSE\\"
output_dir="D:\\Data_dumpers\\Circulars\\NSE\\Output\\"
#contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIE_Circular@kotak.com'

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    msg['Cc']=','.join(kwargs['emails'][1])
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'csvfile' in kwargs.keys():
        #for csvfile in kwargs['csvfile']:
            print(kwargs['csvfile'])
            #print(csvfile)
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(os.path.join(output_dir,kwargs['csvfile']), "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(kwargs['csvfile']))
            msg.attach(part) 

    # read message text or html files to be appeneded in email body 
    if 'html_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['html_email'],'r').read()
        msg.attach(MIMEText(message, 'html'))
    
    if 'text_email' in kwargs.keys():
        # read html message file
        message = kwargs['text_email']
        msg.attach(MIMEText(message, 'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()
def process_running(d):
    
    try:
        logging.info("Email: Hourly process running check")    
        file = open(os.path.join(download_dir,"mail_data{}.txt".format(d.strftime('%H'))),"w")
        file.write("<html><head></head></html>")    
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> NSE  Circular hourly status: </b></p>")
        file.write("\n\n")
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'>process is running succesfully {}</p>".format(d.strftime("%y-%m-%d-%H:%M:%S")))
        file.write("\n\n")
        file.close()
        logging.info("Output txt for hourly status email compiled successfully")
    except Exception as e :
        logging.info("I/O Error in Output txt for hourly status email; exception / {} ".format(e))
    

def send_output_mail(df,d):
    file = open(os.path.join(download_dir,"NSE_data_{}.txt".format(d.strftime(format='%Y%m%d-%H'))),"w")
    file.write("<html><head></head></html>")
    file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b>{}---</b>{}</p>".format(df["Department"],df["Code"]))
    file.write("\n\n")
    file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> Sub: </b>{}</p>".format(df["Subject"]))
    file.write("\n\n")
    file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b>{}</p>".format(df["Link"]))
    file.write("\n\n")


    file.close()
     
    emails = get_contacts(os.path.join(contacts_dir,'circular_alerts.txt')) # read contacts
    subject = "{}-{}".format(df["Subject"],d.strftime("%y-%m-%d-%H"))  #subject
    #logging.info('CA email sending for {} , {} ,{}'.format(d,df["SCRIP_CD"],df['SLONGNAME']))

    process_email(emails=emails, subject=subject, html_email=os.path.join(download_dir,"NSE_data_{}.txt".format(d.strftime(format='%Y%m%d-%H'))))
   
    logging.info('Corporate action anouncement email was sent for {0}'.format(d))


def NSE_data(nd,d,nse_data):
#download_dir="C:\\Users\\backup\\Geeta\\"
    try:
        url = "https://www.nseindia.com/resources/exchange-communication-circulars"
        driver = webdriver.Chrome(master_dir+"chromedriver.exe")
        driver.set_page_load_timeout(60)
        driver.get(url)
        
        driver.maximize_window()
        pg_source=driver.page_source
        time.sleep(2)
        d1=datetime.datetime.today().date()-datetime.timedelta(nd)
        today=d1.strftime("%B %d, %Y")    
        soup = BeautifulSoup(pg_source, "html.parser")      
        all_data=soup.find_all('div',class_='card')
        for sub in all_data:
            
    
            try:
                dates=sub.find("h4").text
                if today==dates:
                    print(dates)
                    s=sub.find('p',class_='readMoreP').text
                    dept=sub.find("h3").text
                    print(dept)
                    c=sub.find('p',class_='pb-2').text
                    data=[dept,c]
                    if data not in nse_data[["Department","Code"]].values.tolist():
                   # if c not in nse_data['Code'].tolist():
                      # subj.append(s)
                       l=sub.find('a',class_='download')
                       data=[dept,c,s,l['href']]
                       df=pd.DataFrame([data],columns=["Department","Code","Subject","Link"])
                       time.sleep(5)
                       for x ,row in df.iterrows(): 
                           send_output_mail(row,d)
                       nse_data=pd.concat([nse_data,df])
                       nse_data.to_excel(os.path.join(output_dir,"NSE_data_{}.xlsx".format(d1.strftime("%d%m%y"))),index=False)
                       time.sleep(3)
                       
            except Exception as e:
                 print(e)
        driver.close()
        
    except Exception as e:
                 print(e)
                 driver.close()
def main(nd):
    d=datetime.datetime.now()
    dt="22:00:00"
    maindf=pd.DataFrame(columns=["Department","Code","Subject","Link"])
    if not os.path.isfile(os.path.join(output_dir,"NSE_data_{}.xlsx".format(d.strftime("%d%m%y")))):
        maindf.to_excel(os.path.join(output_dir,"NSE_data_{}.xlsx".format(d.strftime("%d%m%y"))),index=False)
        nse_data=pd.read_excel(os.path.join(output_dir,"NSE_data_{}.xlsx".format(d.strftime("%d%m%y"))))
    else:
        nse_data=pd.read_excel(os.path.join(output_dir,"NSE_data_{}.xlsx".format(d.strftime("%d%m%y"))))
    while d.strftime("%H:%M:%S")<dt:
    
        NSE_data(nd,d,nse_data)
        process_running(d)
        emails = get_contacts(os.path.join(contacts_dir,'circular.txt')) # read contacts
        subject = "NSE Circular running Alert - {} ".format(d.strftime("%y-%m-%d-%H"))  #subject    
        process_email(emails=emails, subject=subject, html_email=os.path.join(download_dir,"mail_data{}.txt".format(d.strftime("%H"))))
        time.sleep(3600)
        d=datetime.datetime.now()
        
    files = glob.glob(os.path.join(download_dir,'*.txt'))  # find .txt files in output dir and list them  
    for f in files:
        os.remove(f)  # remove all .txt files from the list     
    #logging.info("deleting text files from output directory") 
    print("deleting txt file for {}".format(d.date()))     
    if len(nse_data)!=0:    
        emails = get_contacts(os.path.join(contacts_dir,'circular_alerts.txt')) # read contacts
        subject = "NSE_Circular_data_for - {}".format(d.strftime("%y-%m-%d"))  #subject 
        print(subject)
        process_email(emails=emails, subject=subject, csvfile="{}".format("NSE_data_{}.xlsx".format(d.strftime("%d%m%y"))))
       
        
main(0)




