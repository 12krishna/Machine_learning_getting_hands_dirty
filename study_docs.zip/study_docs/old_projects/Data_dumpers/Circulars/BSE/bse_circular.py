# -*- coding: utf-8 -*-
"""
Created on Mon Jul 11 12:58:55 2022

@author: backup
"""
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import glob

from selenium  import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import time
import requests
import os
import pandas as pd
import logging
import sys
import datetime

server = '172.17.9.149'; port = 25

#MY_ADDRESS = 'KIEResearchAlerts@kotak.com'

download_dir="D:\\Data_dumpers\\Circulars\\BSE"
output_dir="D:\\Data_dumpers\\Circulars\\BSE\\Output\\"
contacts_dir="D:\\Data_dumpers\\Circulars\\"


MY_ADDRESS = 'KIE_Circular@kotak.com'

master_dir = "D:\\Data_dumpers\\Master\\"


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    msg['Cc']=','.join(kwargs['emails'][1])
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'csvfile' in kwargs.keys():
        #for csvfile in kwargs['csvfile']:
            print(kwargs['csvfile'])
            #print(csvfile)
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(os.path.join(output_dir,kwargs['csvfile']), "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(kwargs['csvfile']))
            msg.attach(part) 

    # read message text or html files to be appeneded in email body 
    if 'html_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['html_email'],'rb').read()
        msg.attach(MIMEText(message, 'html'))
    
    if 'text_email' in kwargs.keys():
        # read html message file
        message = kwargs['text_email']
        msg.attach(MIMEText(message, 'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()
    
def process_running(d):
    
    try:
        logging.info("Email: Hourly process running check")    
        file = open(os.path.join(download_dir,"mail_data{}.txt".format(d.strftime('%H'))),"w")
        file.write("<html><head></head></html>")    
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> BSE  Circular hourly status: </b></p>")
        file.write("\n\n")
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'>process is running succesfully {}</p>".format(d.strftime("%y-%m-%d-%H:%M:%S")))
        file.write("\n\n")
        file.close()
        logging.info("Output txt for hourly status email compiled successfully")
    except Exception as e :
        logging.info("I/O Error in Output txt for hourly status email; exception / {} ".format(e))


def send_output_mail(df,d):
   
    file = open(os.path.join(download_dir,"BSE_data_{}.txt".format(d.strftime(format='%Y%m%d-%H'))),"w")
    file.write("<html><head></head></html>")
    
    file.write("<table  border='1px solid black',border-collapse='collapse'>")
    file.write("<tr><th>Subject</th><th>Link</th></tr>")
    file.write("<tr>")
    file.write("<td><p style='color:black;font-size:14px;font-style:Calibri'>{}</p></td>".format(df['Subject']))
#    file.write("\n\n")
    file.write("<td><p style='color:black;font-size:14px;font-style:Calibri'>{}</p></td>".format(df["Link"]))
    file.write("</tr>")
    file.write("</table>")
    file.write("\n\n")
    file.close()

    emails = get_contacts(os.path.join(contacts_dir,'circular_alerts.txt')) # read contacts
    subject = "BSE_Circular_{}-{}".format(df["Subject"],d.strftime("%y-%m-%d-%H"))  #subject
    #logging.info('CA email sending for {} , {} ,{}'.format(d,df["SCRIP_CD"],df['SLONGNAME']))

    process_email(emails=emails, subject=subject, html_email=os.path.join(download_dir,"BSE_data_{}.txt".format(d.strftime(format='%Y%m%d-%H'))))
   
    

sub=[]
pdf_link=[]

def BSE_data(nd,d):
    try:
        url = "https://www.bseindia.com/markets/MarketInfo/NoticesCirculars.aspx?id=0&txtscripcd=&pagecont=&subject="
        driver = webdriver.Chrome(master_dir+"chromedriver.exe")
        driver.set_page_load_timeout(60)
        driver.get(url)
        driver.maximize_window()
        window_before = driver.window_handles[0]
        time.sleep(2)
        d1=datetime.datetime.today().date()-datetime.timedelta(nd)
        today=d1.strftime("%d/%m/%Y")
        sdate=driver.find_element_by_id("ContentPlaceHolder1_txtDate")
        time.sleep(5)
        sdate.click()
        date= int(d1.strftime("%d"))
        driver.find_element_by_xpath("//table[@class='ui-datepicker-calendar']//a[text()='{}']".format(date)).click()
        time.sleep(2)
        edate=driver.find_element_by_id("ContentPlaceHolder1_txtTodate").click()
        time.sleep(2)
        driver.find_element_by_xpath("//table[@class='ui-datepicker-calendar']//a[text()='{}']".format(date)).click()
        time.sleep(2)
        driver.find_element_by_id("ContentPlaceHolder1_btnSubmit").click()
        time.sleep(5)
        html=driver.page_source
        tables=pd.read_html(html)
        try:
            first_data=tables[2]
            first_data.columns=first_data.iloc[0,:]
            first_data=first_data.iloc[1:,:]
            #maindf=pd.DataFrame(columns=['Subject','Link'])
            for i in first_data["Subject"]:
                  if i not in sub:  
                    if len(i)>2:
                      sub.append(i)
                      try:
                          driver.find_element_by_link_text(i).click()
                          time.sleep(3)
                          window_after = driver.window_handles[1]    
                          driver.switch_to.window(window_after)
                          time.sleep(4)
                          print(driver.current_url)
                          #driver.get(driver.current_url)
                          pdf_link.append(driver.current_url)
                          i= i.encode('ascii', 'ignore').decode('ascii')
                          data=[i,driver.current_url]
                          df=pd.DataFrame([data],columns=['Subject','Link'])
                          driver.close()
                          driver.switch_to.window(window_before)
                          time.sleep(2)
                          #str(df['Subject'][0]).encode('utf-8')
                          #maindf=pd.concat([maindf,df])
                          for x ,row in df.iterrows(): 
                            send_output_mail(row,d)            
                          #driver.close()
                          time.sleep(3)
                         # driver.switch_to.window(window_before)
                      except Exception as e:
                            print(e)
            driver.close() 
        except Exception as e:
              print(e)
              driver.close()
    except Exception as e:
              print(e)

def main(nd):
    d=datetime.datetime.now()
    dt="22:00:00"
   

    while d.strftime("%H:%M:%S")<dt:
        if d.strftime("%H:%M:%S")>="21:55:00":
                   # logging.info("Remove files from the download dir after 11 PM ")
                    files = glob.glob(os.path.join(download_dir,'*.txt'))  # find .txt files in output dir and list them  
                    for f in files:
                        os.remove(f)  # remove all .txt files from the list     
                    #logging.info("deleting text files from output directory") 
                    print("deleting txt file for {}".format(d.date())) 
                    break
        BSE_data(nd,d)
        process_running(d)
        emails = get_contacts(os.path.join(contacts_dir,'circular.txt')) # read contacts
        subject = "BSE Circular running Alert - {} ".format(d.strftime("%y-%m-%d-%H"))  #subject    
        process_email(emails=emails, subject=subject, html_email=os.path.join(download_dir,"mail_data{}.txt".format(d.strftime("%H"))))
        time.sleep(1800)
        d=datetime.datetime.now()
        
    maindf=pd.DataFrame(list(zip(sub,pdf_link)),columns=['Subject','Link']) 
    if len(maindf)!=0:
        maindf.to_excel(os.path.join(output_dir,"BSE_data_{}.xlsx".format(d.strftime("%d%m%y"))),index=False)
        emails = get_contacts(os.path.join(contacts_dir,'circular_alerts.txt')) # read contacts
        subject = "BSE_Circular_data_for - {}".format(d.strftime("%y-%m-%d"))  #subject 
        print(subject)
    
        process_email(emails=emails, subject=subject, csvfile="{}".format("BSE_data_{}.xlsx".format(d.strftime("%d%m%y"))))
        
main(0)





     




