# -*- coding: utf-8 -*-
"""
Created on Tue Jul 26 11:31:26 2022

@author: backup
"""

#-*- coding: utf-8 -*-
"""
Created on Tue Jul  5 15:14:27 2022

@author: backup
"""

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import glob

import time
from bs4 import BeautifulSoup
from selenium  import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys

import requests
import os
import pandas as pd
import logging
import sys
#reload(sys)
#sys.setdefaultencoding('utf-8')
import datetime

server = '172.17.9.149'; port = 25

#MY_ADDRESS = 'KIEResearchAlerts@kotak.com'
download_dir="D:\\Data_dumpers\\Circulars\\"


#contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIE_Circular@kotak.com'

master_dir = "D:\\Data_dumpers\\Master\\"

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def email_utility(emails, subject,fname):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
    
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    
    
   # attachment = open(data_dir+fname,'rb')
    print(fname)
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(os.path.join(download_dir,fname), "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
    msg.attach(part)                     
    
   # msg.attach(MIMEText(message,'plain'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()



def main(nd):
    d=datetime.datetime.today().date()-datetime.timedelta(nd)
    td="{}.xlsx".format(d.strftime("%d%m%y"))
    
    writer = pd.ExcelWriter(os.path.join(download_dir,'all_circular_{}'.format(td)), engine='xlsxwriter')
    for r,d,f in os.walk(download_dir):              
        for file in f:
            if file.endswith(td):
                print(file)
                print(os.path.join(r,file))
                df=pd.read_excel(os.path.join(r,file))
                df.to_excel(writer, sheet_name=file[:-12],index=False)
    writer.save()     
    email_utility(get_contacts(download_dir+'circular_alerts.txt'), 
                                 'all_circular_{}'.format(td),'all_circular_{}'.format(td))
    
    

main(0)









