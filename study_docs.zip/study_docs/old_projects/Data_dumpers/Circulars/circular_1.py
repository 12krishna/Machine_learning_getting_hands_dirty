#-*- coding: utf-8 -*-
"""
Created on Tue Jul  5 15:14:27 2022

@author: backup
"""

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import glob

import time
from bs4 import BeautifulSoup
from selenium  import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys

import requests
import os
import pandas as pd
import logging
import sys
#reload(sys)
#sys.setdefaultencoding('utf-8')
import datetime

server = '172.17.9.149'; port = 25

#MY_ADDRESS = 'KIEResearchAlerts@kotak.com'

download_dir="D:\\Data_dumpers\\Circulars\\"
output_dir="D:\\Data_dumpers\\Circulars\\Output\\"
#contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIE_Circular@kotak.com'

master_dir = "D:\\Data_dumpers\\Master\\"
all_data=pd.DataFrame()
i=0
j=0
k=0
r=0
gazette_data=pd.DataFrame()
all_master_data=pd.DataFrame()
regulation_data=pd.DataFrame()
def circular_data(d):
    global i
    global all_data
    url = "https://sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=1&ssid=7&smid=0"
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")
    driver.set_page_load_timeout(60)
    driver.get(url)
    driver.maximize_window()
    window_before = driver.window_handles[0]
    driver.implicitly_wait(5)
    date= int(d.strftime("%d"))
    sdate=driver.find_element_by_id("fromDate").click()
    time.sleep(5)
    driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
    
    time.sleep(5)
    #sdate.send_keys(d1)
    edate=driver.find_element_by_id("toDate").click()
    time.sleep(5)
    driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
    time.sleep(5)

    time.sleep(5)
   
    go=driver.find_elements_by_xpath("//a[@class='go-search go_search']")[0].click()
    time.sleep(5)
   
    html=driver.page_source
    print("read html")
    try:
        if i==0:
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            table.to_csv(os.path.join(download_dir,"data_scraped{}.csv".format(d.strftime("%d%m%y-%H"))),index=False,encoding='utf-8')
            all_data=pd.concat([all_data,table])
            all_data['URL']=''
            for r in all_data['Title']:
                print(r)
                driver.find_element_by_link_text(r).click()
                time.sleep(5)
                window_after = driver.window_handles[1]    
                driver.switch_to.window(window_after)
                time.sleep(10)
                print(driver.current_url)
               # driver.get(driver.current_url)
                all_data["URL"][all_data['Title']==r]=driver.current_url
                driver.close()
                time.sleep(5)
                driver.switch_to.window(window_before)
            
            all_data.to_csv(os.path.join(output_dir,"all_data_{}.csv".format(d.strftime("%d%m%y"))),index=False,encoding='utf-8')
            for x ,row in all_data.iterrows():
              # str(row['Subject'][0]).encode('utf-8')
               send_output_mail(row,d)
            print('______________')
           # email  all_data
            i=1
           
        else:
            print("_____")
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            new_data=table[~table['Title'].isin(all_data['Title'])]           
            print(new_data)
            if not new_data.empty:
                new_data.to_csv(os.path.join(download_dir,"data_scraped{}.csv".format(d.strftime("%d%m%y-%H"))),index=False,encoding='utf-8')
                new_data['URL']=''
                for r in new_data['Title']:
                    print(r)
                    driver.find_element_by_link_text(r).click()
                    time.sleep(5)
                    window_after = driver.window_handles[1]    
                    driver.switch_to.window(window_after)
                    time.sleep(10)
                    print(driver.current_url)
                   # driver.get(driver.current_url)
                    new_data["URL"][all_data['Title']==r]=driver.current_url
                    driver.close()
                    time.sleep(5)
                    driver.switch_to.window(window_before)
                all_data=pd.concat([all_data,new_data])
                all_data.to_csv(os.path.join(output_dir,"all_data_{}.csv".format(d.strftime("%d%m%y"))),index=False,encoding='utf-8')
                for x ,row in new_data.iterrows():
                    send_output_mail(row,d)
           
            
    except Exception as e:
        print(e)
        
    driver.quit()


def circular_master_data(d):
    global j
    global all_master_data
    url = "https://sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=1&ssid=6&smid=0"
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")
    driver.set_page_load_timeout(30)
    driver.get(url)
    driver.maximize_window()
    window_before = driver.window_handles[0]
    driver.implicitly_wait(5)
  
    date= int(d.strftime("%d"))
    sdate=driver.find_element_by_id("fromDate").click()
    time.sleep(5)
    driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()

    time.sleep(5)

    edate=driver.find_element_by_id("toDate").click()
    time.sleep(5)
    driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
    time.sleep(5)
    
    time.sleep(5)

    go=driver.find_elements_by_xpath("//a[@class='go-search go_search']")[0].click()
    time.sleep(5)

    html=driver.page_source
    print("read html")
    try:
        if j==0:
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            table.to_csv(os.path.join(download_dir,"data_master_scraped{}.csv".format(d.strftime("%d%m%y-%H"))),index=False,encoding='utf-8')
            all_master_data=pd.concat([all_master_data,table])
            all_master_data['URL']=''
            for r in all_master_data['Title']:
                print(r)
                driver.find_element_by_link_text(r).click()
                time.sleep(5)
                window_after = driver.window_handles[1]    
                driver.switch_to.window(window_after)
                time.sleep(10)
                print(driver.current_url)
               # driver.get(driver.current_url)
                all_master_data["URL"][all_master_data['Title']==r]=driver.current_url
                driver.close()
                time.sleep(5)
                driver.switch_to.window(window_before)
            
            all_master_data.to_csv(os.path.join(output_dir,"all_master_data_{}.csv".format(d.strftime("%d%m%y"))),index=False,encoding='utf-8')
            for x ,row in all_data.iterrows():
                
               send_output_mail(row,d)
            print('______________')
           # email  all_data
            j=1
           
        else:
            print("_____")
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            new_master_data=table[~table['Title'].isin(all_master_data['Title'])]
            print(new_master_data)
            if not new_master_data.empty:
                new_master_data.to_csv(os.path.join(download_dir,"data_master_scraped{}.csv".format(d.strftime("%d%m%y-%H"))),index=False,encoding='utf-8')
                new_master_data['URL']=''
                for r in new_master_data['Title']:
                    print(r)
                    driver.find_element_by_link_text(r).click()
                    time.sleep(5)
                    window_after = driver.window_handles[1]    
                    driver.switch_to.window(window_after)
                    time.sleep(10)
                    print(driver.current_url)
                   # driver.get(driver.current_url)
                    new_master_data["URL"][new_master_data['Title']==r]=driver.current_url
                    driver.close()
                    time.sleep(5)
                    driver.switch_to.window(window_before)
                all_master_data=pd.concat([all_master_data,new_master_data])
                all_master_data.to_csv(os.path.join(output_dir,"all_master_data_{}.csv".format(d.strftime("%d%m%y"))),index=False,encoding='utf-8')
                for x ,row in new_master_data.iterrows():
                    send_output_mail(row,d)
           
            
    except Exception as e:
        print(e)
        
    driver.quit()

def gazette_data(d):
    global k
    global gazette_data
    url = "https://sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=1&ssid=82&smid=0"
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")
    driver.set_page_load_timeout(30)
    driver.get(url)
    driver.maximize_window()
    window_before = driver.window_handles[0]
    driver.implicitly_wait(5)

    date= int(d.strftime("%d"))
    sdate=driver.find_element_by_id("fromDate").click()
    time.sleep(5)
    driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
    
    time.sleep(5)
   
    edate=driver.find_element_by_id("toDate").click()
    time.sleep(5)
    driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
    time.sleep(5)  
    time.sleep(5)
   
    go=driver.find_elements_by_xpath("//a[@class='go-search go_search']")[0].click()
    time.sleep(5)

    html=driver.page_source
    print("read html")
    try:
        if k==0:
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            table.to_csv(os.path.join(download_dir,"gazette_data_scraped{}.csv".format(d.strftime("%d%m%y-%H"))),index=False,encoding='utf-8')
            gazette_data=pd.concat([gazette_data,table])
            gazette_data['URL']=''
            for r in gazette_data['Title']:
                print(r)
                driver.find_element_by_link_text(r).click()
                time.sleep(5)
                window_after = driver.window_handles[1]    
                driver.switch_to.window(window_after)
                time.sleep(10)
                print(driver.current_url)
               # driver.get(driver.current_url)
                gazette_data["URL"][gazette_data['Title']==r]=driver.current_url
                driver.close()
                time.sleep(5)
                driver.switch_to.window(window_before)
            
            gazette_data.to_csv(os.path.join(output_dir,"all_gazette_data_{}.csv".format(d.strftime("%d%m%y"))),index=False,encoding='utf-8')
            for x ,row in gazette_data.iterrows():
                
               send_output_mail(row,d)
            print('______________')
           # email  all_data
            k=1
           
        else:
            print("_____")
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            newz_data=table[~table['Title'].isin(gazette_data['Title'])]
            print(newz_data)
            if not newz_data.empty:
                newz_data.to_csv(os.path.join(download_dir,"gazette_data_scraped{}.csv".format(d.strftime("%d%m%y-%H"))),index=False,encoding='utf-8')
                newz_data['URL']=''
                for r in newz_data['Title']:
                    print(r)
                    driver.find_element_by_link_text(r).click()
                    time.sleep(5)
                    window_after = driver.window_handles[1]    
                    driver.switch_to.window(window_after)
                    time.sleep(10)
                    print(driver.current_url)
                  #  driver.get(driver.current_url)
                    newz_data["URL"][gazette_data['Title']==r]=driver.current_url
                    driver.close()
                    time.sleep(5)
                    driver.switch_to.window(window_before)
                gazette_data=pd.concat([gazette_data,newz_data])
                gazette_data.to_csv(os.path.join(output_dir,"all_gazette_data_{}.csv".format(d.strftime("%d%m%y"))),index=False,encoding='utf-8')
                for x ,row in newz_data.iterrows():
                    send_output_mail(row,d)
           
            
    except Exception as e:
        print(e)
        
    driver.quit()

#https://sebi.gov.in/sebiweb/home/HomeAction.do?doListingLegal=yes&sid=1&ssid=3&smid=0

def Regulations_data(d):
    global r
    global regulation_data
    url = "https://sebi.gov.in/sebiweb/home/HomeAction.do?doListingLegal=yes&sid=1&ssid=3&smid=0"
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")
    driver.set_page_load_timeout(30)
    driver.get(url)
    driver.maximize_window()
    window_before = driver.window_handles[0]
    driver.implicitly_wait(5)

    date= int(d.strftime("%d"))
    sdate=driver.find_element_by_id("fromDate").click()
    time.sleep(5)
    driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
    
    time.sleep(5)
   
    edate=driver.find_element_by_id("toDate").click()
    time.sleep(5)
    driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
    time.sleep(5)  
    time.sleep(5)
   
    go=driver.find_elements_by_xpath("//a[@class='go-search go_search']")[0].click()
    time.sleep(5)

    html=driver.page_source
    print("read html")
    try:
        if r==0:
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            table.to_csv(os.path.join(download_dir,"regulation_data_scraped{}.csv".format(d.strftime("%d%m%y-%H"))),index=False,encoding='utf-8')
            regulation_data=pd.concat([regulation_data,table])
            regulation_data['URL']=''
            for r in regulation_data['Title']:
                print(r)
                driver.find_element_by_link_text(r).click()
                time.sleep(5)
                window_after = driver.window_handles[1]    
                driver.switch_to.window(window_after)
                time.sleep(10)
                print(driver.current_url)
               # driver.get(driver.current_url)
                regulation_data["URL"][regulation_data['Title']==r]=driver.current_url
                driver.close()
                time.sleep(5)
                driver.switch_to.window(window_before)
            
            regulation_data.to_csv(os.path.join(output_dir,"all_regulations_data_{}.csv".format(d.strftime("%d%m%y"))),index=False,encoding='utf-8')
            for x ,row in regulation_data.iterrows():
                
               send_output_mail(row,d)
            print('______________')
           # email  all_data
            r=1
           
        else:
            print("_____")
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            newr_data=table[~table['Title'].isin(regulation_data['Title'])]
            print(newr_data)
            if not newr_data.empty:
                newr_data.to_csv(os.path.join(download_dir,"regulation_data_scraped{}.csv".format(d.strftime("%d%m%y-%H"))),index=False,encoding='utf-8')
                newr_data['URL']=''
                for r in newr_data['Title']:
                    print(r)
                    driver.find_element_by_link_text(r).click()
                    time.sleep(5)
                    window_after = driver.window_handles[1]    
                    driver.switch_to.window(window_after)
                    time.sleep(10)
                    print(driver.current_url)
                    #driver.get(driver.current_url)
                    newr_data["URL"][regulation_data['Title']==r]=driver.current_url
                    driver.close()
                    time.sleep(5)
                    driver.switch_to.window(window_before)
                regulation_data=pd.concat([regulation_data,newr_data])
                regulation_data.to_csv(os.path.join(output_dir,"all_regulations_data_{}.csv".format(d.strftime("%d%m%y"))),index=False,encoding='utf-8')
                for x ,row in newr_data.iterrows():
                    send_output_mail(row,d)
           
            
    except Exception as e:
        print(e)
        
    driver.quit()




def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    msg['Cc']=','.join(kwargs['emails'][1])
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'csvfile' in kwargs.keys():
        #for csvfile in kwargs['csvfile']:
            print(kwargs['csvfile'])
            #print(csvfile)
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(os.path.join(output_dir,kwargs['csvfile']), "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(kwargs['csvfile']))
            msg.attach(part) 

    # read message text or html files to be appeneded in email body 
    if 'html_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['html_email'],'rb').read()
        msg.attach(MIMEText(message, 'html'))
    
    if 'text_email' in kwargs.keys():
        # read html message file
        message = kwargs['text_email']
        msg.attach(MIMEText(message, 'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def process_running(d):
    
    try:
        logging.info("Email: Hourly process running check")    
        file = open(os.path.join(download_dir,"mail_data{}.txt".format(d.strftime('%H'))),"w")
        file.write("<html><head></head></html>")    
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> SEBI  Circular hourly status: </b></p>")
        file.write("\n\n")
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'>process is running succesfully {}</p>".format(d.strftime("%y-%m-%d-%H:%M:%S")))
        file.write("\n\n")
        file.close()
        logging.info("Output txt for hourly status email compiled successfully")
    except Exception as e :
        logging.info("I/O Error in Output txt for hourly status email; exception / {} ".format(e))

def send_output_mail(df,d):
    df['Title']= df['Title'].encode('ascii', 'ignore').decode('ascii')
    file = open(os.path.join(download_dir,"all_data_{}.txt".format(d.strftime(format='%Y%m%d-%H'))),"w")
    file.write("<html><head></head></html>")
    
    file.write("<table  border='1px solid black',border-collapse='collapse'>")
    file.write("<tr><th>Date</th><th>Title</th></tr>")
    file.write("<tr>")
    file.write("<td><p style='color:black;font-size:14px;font-style:Calibri'>{}</p></td>".format(df["Date"]))
#    file.write("\n\n")
    file.write("<td><p style='color:black;font-size:14px;font-style:Calibri'>{}\n\n{}</p></td>".format(df["Title"],df["URL"]))
    file.write("</tr>")
    file.write("</table>")
    file.write("\n\n")
    file.close()

    emails = get_contacts(os.path.join(download_dir,'circular.txt')) # read contacts
  #  subject = "SEBI circular-{}".format(d.strftime("%y-%m-%d-%H"))  #subject
    subject = "SEBI {}-{}".format(df["Title"],d.strftime("%y-%m-%d-%H"))  #subject
    #logging.info('CA email sending for {} , {} ,{}'.format(d,df["SCRIP_CD"],df['SLONGNAME']))

    process_email(emails=emails, subject=subject, html_email=os.path.join(download_dir,"all_data_{}.txt".format(d.strftime(format='%Y%m%d-%H'))))
   
    

def main(nd):
    d=datetime.datetime.now()
    dt="23:00:00"
    d1=datetime.datetime.today().date()-datetime.timedelta(nd)

    while d.strftime("%H:%M:%S")<dt:
        if d.strftime("%H:%M:%S")>="22:55:00":
                    logging.info("Remove files from the download dir after 11 PM ")
                    files = glob.glob(os.path.join(download_dir,'*.txt'))  # find .txt files in output dir and list them  
                    for f in files:
                        os.remove(f)  # remove all .txt files from the list     
                    logging.info("deleting text files from output directory") 
                    print("deleting txt file for {}".format(d.date())) 
                    files1=glob.glob(os.path.join(download_dir,'*.csv'))
                    for f in files1:
                        os.remove(f)
                    logging.info("deleting csv files from output directory")  
                    print("deleting csv file for {}".format(d.date())) 
                    break
        circular_data(d1)
        circular_master_data(d1)
        gazette_data(d1)
        Regulations_data(d1)
        process_running(d)
        emails = get_contacts(os.path.join(download_dir,'circular.txt')) # read contacts
        subject = "SEBI Circular running Alert - {} ".format(d.strftime("%y-%m-%d-%H"))  #subject    
        process_email(emails=emails, subject=subject, html_email=os.path.join(download_dir,"mail_data{}.txt".format(d.strftime("%H"))))
        time.sleep(3600)
        d=datetime.datetime.now() 
    
    emails = get_contacts(os.path.join(download_dir,'circular.txt')) # read contacts
    sub_list={'SEBI Circular data':"all_data_{}.csv".format(d1.strftime("%d%m%y")),
              'SEBI Master data':"all_master_data_{}.csv".format(d1.strftime("%d%m%y")),
              'SEBI Gazette data':"all_gazette_data_{}.csv".format(d1.strftime("%d%m%y")),
               "SEBI Regulation data":"all_regulations_data_{}.csv".format(d1.strftime("%d%m%y"))}
    for x in sub_list:
        try:                
           subject = "{} - {} ".format(x,d.strftime("%y-%m-%d"))  #subject 
           print(subject)
           process_email(emails=emails, subject=subject, csvfile="{}".format(sub_list[x]))
        except Exception as e:
          print(e)
main(0)


'''        
url = "https://sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=1&ssid=7&smid=0"
driver = webdriver.Chrome(master_dir+"chromedriver.exe")

driver.get(url)
driver.maximize_window()
window_before = driver.window_handles[0]
driver.implicitly_wait(5)
   # d=datetime.datetime.today().date()-datetime.timedelta(1)
#d1=str(d)
date= int(d1.strftime("%d"))
sdate=driver.find_element_by_id("fromDate").click()
time.sleep(5)
driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()

#sdate.send_keys(Keys.CONTROL, "a")
#sdate.send_keys(Keys.BACKSPACE)
time.sleep(5)
#sdate.send_keys(d1)
edate=driver.find_element_by_id("toDate").click()
time.sleep(5)
driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
time.sleep(5)
#edate.send_keys(Keys.CONTROL, "a")
#edate.send_keys(Keys.BACKSPACE)
#edate.send_keys(d1)

time.sleep(5)
#dept=driver.find_element_by_id("deptId").click()
#dept=driver.find_element_by_id("deptId").click()
#time.sleep(5)
go=driver.find_elements_by_xpath("//a[@class='go-search go_search']")[0].click()
time.sleep(5)
#all_data=pd.DataFrame()
#pg=driver.page_source
#final_soup = BeautifulSoup(pg,'lxml')
html=driver.page_source
print("read html")

if i==0:
    tables = pd.read_html(html)
    print(tables)
    table=tables[0]
    table.to_csv(os.path.join(download_dir,"data_scraped{}.csv".format(d.strftime("%d%m%y-%H"))),index=False,encoding='utf-8')
    all_data=pd.concat([all_data,table])
    all_data['URL']=''

    for r in all_data['Title']:
        print(r)
        driver.find_element_by_link_text(r).click()
        time.sleep(5)
        window_after = driver.window_handles[1]
    
        driver.switch_to.window(window_after)
        time.sleep(10)
        print(driver.current_url)
        driver.get(driver.current_url)
        all_data["URL"][all_data['Title']==r]=driver.current_url
        driver.close()
        time.sleep(5)
        driver.switch_to.window(window_before)
    
        time.sleep(5)
        
    all_data.to_csv(os.path.join(download_dir,"all_data_{}.csv".format(d.strftime("%d%m%y"))),index=False,encoding='utf-8')
    for x ,row in all_data.iterrows():
       send_output_mail(all_data.iloc[2,:]) 
       send_output_mail(row)
    print('______________')
   # email  all_data
    i=1
   
else:
    print("_____")
    tables = pd.read_html(html)
    print(tables)
    table=tables[0]
    table.to_csv(os.path.join(download_dir,"data_scraped{}.csv".format(d.strftime("%d%m%y-%H"))),index=False,encoding='utf-8')
    new_data=table[~table['Title'].isin(all_data['Title'])]
    if not new_data.empty:
        
        for r in new_data:
            print(r)
            driver.find_element_by_link_text(r).click()
            new_data["URL"]=driver.current_url
        all_data=pd.concat([all_data,new_data])
        all_data.to_csv(os.path.join(download_dir,"all_data_{}.csv".format(d.strftime("%d%m%y"))),index=False,encoding='utf-8')
        for x ,row in new_data.iterrows():
            send_output_mail(row)
       
        

    
driver.quit()

       
'''   
