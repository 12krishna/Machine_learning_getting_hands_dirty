# -*- coding: utf-8 -*-
"""
Created on Fri Jul  8 15:58:10 2022

@author: backup
"""
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from selenium  import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import time
import requests
import os
import pandas as pd
import logging
import sys
import datetime
master_dir = "D:\\Data_dumpers\\Master\\"
download_dir="C:\\Users\\backup\\Downloads\\"
contacts_dir="D:\\Data_dumpers\\Circulars\\"
server = '172.17.9.144'; port = 25

MY_ADDRESS = 'KIE_Circular@kotak.com'

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def email_utility(emails, subject,fname):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
    
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    
    
   # attachment = open(data_dir+fname,'rb')
    print(fname)
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(os.path.join(download_dir,fname), "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
    msg.attach(part)                     
    
   # msg.attach(MIMEText(message,'plain'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()
l=[]
def main_data(nd):
    url = "https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doRecognised=yes"
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")
    driver.set_page_load_timeout(60)
    driver.get(url)
    time.sleep(5)
    driver.maximize_window()
    d1=datetime.datetime.today().date()-datetime.timedelta(nd)
    today=d1.strftime("%b %d, %Y")
    
    page_data= requests.get(url).content       
    soup = BeautifulSoup(page_data, "html.parser")  
    all_data=soup.find_all("tr")
    
    i=-1
    for t in all_data[1:]:
     # if first not in l:
       # l.append(first)
        first=t.find_all("a")[0].text
        print(first)
        i=i+1
        if today in first:
            if first not in l:
                l.append(first)
                print(i)
                print(first[:-17])
                driver.find_elements_by_xpath("//i[@class='fa fa-download']")[i].click()
                time.sleep(5)
                for r,d,f in os.walk(download_dir):
                    for files in f:
                        if files.startswith(first[:-17]):
                             if "/" in files:
                                   files=files.replace("/","_")
                             email_utility(get_contacts(contacts_dir+'circular.txt'), 
                             "SEBI-Recognised Intermediaries-"+first,files )
                             time.sleep(5)
                             os.remove(os.path.join(download_dir,files))
        time.sleep(2)       
    driver.close()

def main(nd):
    d=datetime.datetime.now()
    dt="23:00:00"
    while d.strftime("%H:%M:%S")<dt:
        main_data(nd)
        time.sleep(3600)
        
main(0)       
        
 