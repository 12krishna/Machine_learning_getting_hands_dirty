# -*- coding: utf-8 -*-
"""
Created on Tue Jul 26 11:31:26 2022

@author: backup
"""


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import glob

import time
from bs4 import BeautifulSoup
from selenium  import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys

import requests
import os
import pandas as pd
import logging
import sys
#reload(sys)
#sys.setdefaultencoding('utf-8')
import datetime

server = '172.17.9.149'; port = 25

#MY_ADDRESS = 'KIEResearchAlerts@kotak.com'

download_dir="D:\\Data_dumpers\\Circulars\\"
output_dir="D:\\Data_dumpers\\Circulars\\Output\\"
#contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIE_Circular@kotak.com'

master_dir = "D:\\Data_dumpers\\Master\\"

rec_inter=gazzet=regdf=master=circular=pd.DataFrame(columns=["Subject","Link"])  


       
def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    msg['Cc']=','.join(kwargs['emails'][1])
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'csvfile' in kwargs.keys():
        #for csvfile in kwargs['csvfile']:
            print(kwargs['csvfile'])
            #print(csvfile)
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(os.path.join(output_dir,kwargs['csvfile']), "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(kwargs['csvfile']))
            msg.attach(part) 

    # read message text or html files to be appeneded in email body 
    if 'html_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['html_email'],'r').read()
        msg.attach(MIMEText(message, 'html'))
    
    if 'text_email' in kwargs.keys():
        # read html message file
        message = kwargs['text_email']
        msg.attach(MIMEText(message, 'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def process_running(d):
    
    try:
        logging.info("Email: Hourly process running check")    
        file = open(os.path.join(download_dir,"mail_data{}.txt".format(d.strftime('%H'))),"w")
        file.write("<html><head></head></html>")    
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> SEBI  Circular hourly status: </b></p>")
        file.write("\n\n")
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'>process is running succesfully {}</p>".format(d.strftime("%y-%m-%d-%H:%M:%S")))
        file.write("\n\n")
        file.close()
        logging.info("Output txt for hourly status email compiled successfully")
    except Exception as e :
        logging.info("I/O Error in Output txt for hourly status email; exception / {} ".format(e))

def send_output_mail(df,d):
    df['Subject']= df['Subject'].encode('ascii', 'ignore').decode('ascii')
    file = open(os.path.join(download_dir,"all_data_{}.txt".format(d.strftime(format='%Y%m%d-%H'))),"w")
    file.write("<html><head></head></html>")
    
    file.write("<p style='color:black;font-size:14px;font-style:Calibri'>{}</p>".format(df["Subject"]))
    file.write("<p style='color:black;font-size:14px;font-style:Calibri'>{}</p>".format(df["Link"]))

    file.write("\n\n")
    file.close()

   # emails = get_contacts(os.path.join(download_dir,'circular.txt')) # read contacts
    emails = get_contacts(os.path.join(output_dir,'back.txt')) # read contacts   'circular_alerts.txt'

  #  subject = "SEBI circular-{}".format(d.strftime("%y-%m-%d-%H"))  #subject
    subject = "SEBI {}-{}".format(df["Subject"],d.strftime("%y-%m-%d"))  #subject
    #logging.info('CA email sending for {} , {} ,{}'.format(d,df["SCRIP_CD"],df['SLONGNAME']))

    process_email(emails=emails, subject=subject, html_email=os.path.join(download_dir,"all_data_{}.txt".format(d.strftime(format='%Y%m%d-%H'))))
   
def circular_data(d):
     try: 
        global circular
        url = "https://sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=1&ssid=7&smid=0"
        driver = webdriver.Chrome(master_dir+"chromedriver.exe")
        driver.set_page_load_timeout(60)
        driver.get(url)
        driver.implicitly_wait(120)
        driver.maximize_window()
        driver.implicitly_wait(5)
        
        date= int(d.strftime("%d"))
        sdate=driver.find_element_by_id("fromDate").click()
        time.sleep(5)
       # driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
        driver.find_element_by_xpath('//td[@class="today day"]').click()
        time.sleep(5)
           
        edate=driver.find_element_by_id("toDate").click()
        time.sleep(5)
        driver.find_element_by_xpath('//td[@class="today day"]').click()
       # driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
        time.sleep(5)  
       
        go=driver.find_elements_by_xpath("//a[@class='go-search go_search']")[0].click()
        time.sleep(5)
        
        html=driver.page_source
       
        try:
            
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            if len(table)!=0:
                soup = BeautifulSoup(html, "lxml")
                titles=soup.find_all('tr')
                for i in titles[1:]:  
                   subject=i.find('a').text
                   if subject not in circular["Subject"].tolist():
                      link=i.find('a')['href']
                      print(link)
                      data=[subject,link]
                      df=pd.DataFrame([data],columns=["Subject","Link"])
                      for x ,row in df.iterrows(): 
                           send_output_mail(row,d)
                           time.sleep(3)
                      circular=pd.concat([circular,df])
                      circular.to_excel(os.path.join(output_dir,"Circular_{}.xlsx".format(d.strftime("%d%m%y"))),index=False)
                      time.sleep(3)
                driver.close()
        except Exception as e:
              print(e)    
              driver.close()
     except Exception as e:
              print(e)    
              driver.close()   

def master_data(d):
    try:
        global master      
        url = "https://sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=1&ssid=6&smid=0"
        driver = webdriver.Chrome(master_dir+"chromedriver.exe")
        driver.set_page_load_timeout(60)
        driver.get(url)
        driver.implicitly_wait(120)
        driver.maximize_window()
      
        driver.implicitly_wait(5)
        
        date= int(d.strftime("%d"))
        sdate=driver.find_element_by_id("fromDate").click()
        time.sleep(5)
        #driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
        driver.find_element_by_xpath('//td[@class="today day"]').click()
        time.sleep(5)
           
        edate=driver.find_element_by_id("toDate").click()
        time.sleep(5)
        driver.find_element_by_xpath('//td[@class="today day"]').click()
        #driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
        time.sleep(5)  
       
           
        go=driver.find_elements_by_xpath("//a[@class='go-search go_search']")[0].click()
        time.sleep(5)
        
        html=driver.page_source
        
        try:
            
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            if len(table)!=0:
                soup = BeautifulSoup(html, "lxml")
                titles=soup.find_all('tr')
                for i in titles[1:]:  
                   subject=i.find('a').text
                   if subject not in master["Subject"].tolist():
                      link=i.find('a')['href']
                      print(link)
                      data=[subject,link]
                      df=pd.DataFrame([data],columns=["Subject","Link"])
                      for x ,row in df.iterrows(): 
                           send_output_mail(row,d)
                           time.sleep(3)
                      master=pd.concat([master,df])
                      master.to_excel(os.path.join(output_dir,"master_circular_{}.xlsx".format(d.strftime("%d%m%y"))),index=False)
                      time.sleep(3)
                driver.close()
        except Exception as e:
              print(e)    
              driver.close()
    except Exception as e:
              print(e)    
              driver.close()         
       
def gazette_data(d):
  try:  
    global gazzet
    url = "https://sebi.gov.in/sebiweb/home/HomeAction.do?doListing=yes&sid=1&ssid=82&smid=0"
  
        
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")
    driver.set_page_load_timeout(60)
    driver.get(url)
    driver.implicitly_wait(120)
    driver.maximize_window()
    driver.implicitly_wait(5)
    
    date= int(d.strftime("%d"))
    sdate=driver.find_element_by_id("fromDate").click()
    time.sleep(5)
    #driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
    driver.find_element_by_xpath('//td[@class="today day"]').click()
    time.sleep(5)
       
    edate=driver.find_element_by_id("toDate").click()
    time.sleep(5)
   # driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
    driver.find_element_by_xpath('//td[@class="today day"]').click()  
    time.sleep(5)
       
    go=driver.find_elements_by_xpath("//a[@class='go-search go_search']")[0].click()
    time.sleep(5)
    
    html=driver.page_source
    
    try:
        
        tables = pd.read_html(html)
        print(tables)
        table=tables[0]
        if len(table)!=0:
            soup = BeautifulSoup(html, "lxml")
            titles=soup.find_all('tr')
            for i in titles[1:]:  
               subject=i.find('a').text
               if subject not in gazzet["Subject"].tolist():
                  link=i.find('a')['href']
                  print(link)
                  data=[subject,link]
                  df=pd.DataFrame([data],columns=["Subject","Link"])
                  for x ,row in df.iterrows(): 
                       send_output_mail(row,d)
                       time.sleep(3)
                  gazzet=pd.concat([gazzet,df])
                  gazzet.to_excel(os.path.join(output_dir,"Gazzete_{}.xlsx".format(d.strftime("%d%m%y"))),index=False)
                  time.sleep(3)
            driver.close()
    except Exception as e:
          print(e)    
          driver.close()
          
  except Exception as e:
              print(e)    
              driver.close()  




def regulation_data(d):
      try:  
        global regdf
        url = "https://sebi.gov.in/sebiweb/home/HomeAction.do?doListingLegal=yes&sid=1&ssid=3&smid=0"
        driver = webdriver.Chrome(master_dir+"chromedriver.exe")
        driver.set_page_load_timeout(60)     
        driver.get(url)
        driver.implicitly_wait(120)
        driver.maximize_window()
        driver.implicitly_wait(5)
        
        date= int(d.strftime("%d"))
        sdate=driver.find_element_by_id("fromDate").click()
        time.sleep(5)
       # driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
        driver.find_element_by_xpath('//td[@class="today day"]').click()
        time.sleep(5)
           
        edate=driver.find_element_by_id("toDate").click()
        time.sleep(5)
       # driver.find_element_by_xpath("//div[@class='datepicker-days']//td[text()='{}']".format(date)).click()
        driver.find_element_by_xpath('//td[@class="today day"]').click()
        time.sleep(5)  
        
           
        go=driver.find_elements_by_xpath("//a[@class='go-search go_search']")[0].click()
        time.sleep(5)
        
        html=driver.page_source
        
        try:
            
            tables = pd.read_html(html)
            print(tables)
            table=tables[0]
            if len(table)!=0:
                soup = BeautifulSoup(html, "lxml")
                titles=soup.find_all('tr')
                for i in titles[1:]:  
                   subject=i.find('a').text
                   if subject not in regdf["Subject"].tolist():
                      link=i.find('a')['href']
                      print(link)
                      data=[subject,link]
                      df=pd.DataFrame([data],columns=["Subject","Link"])
                      for x ,row in df.iterrows(): 
                           send_output_mail(row,d)
                           time.sleep(3)
                      regdf=pd.concat([regdf,df])
                      regdf.to_excel(os.path.join(output_dir,"Regulation_{}.xlsx".format(d.strftime("%d%m%y"))),index=False)
                      time.sleep(3)
                driver.close()
        except Exception as e:
              print(e)    
              driver.close()
      except Exception as e:
              print(e)    
              driver.close()   

def intermediary(d):
  try:  
    global rec_inter
    url = "https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doRecognised=yes"
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")
    driver.set_page_load_timeout(60)
    driver.get(url)
    driver.implicitly_wait(120)
    time.sleep(5)
    driver.maximize_window()
   # d1=datetime.datetime.today().date()-datetime.timedelta(1)
    today=d.strftime("%b %d, %Y")    
    page_data= requests.get(url).content       
    soup = BeautifulSoup(page_data, "html.parser")  
    all_data=soup.find_all("tr")
    all_data[0]
    try:
        for t in all_data[1:]:
            sub=t.find_all("a")[0].text
            if today in sub:
                print("today's data is available")
                sub=sub[:-17]
                print(sub)
               
                if sub not in rec_inter["Subject"].tolist():
                    link="https://www.sebi.gov.in"+t.find_all("a")[0]['href']
                    print(link)
                    data=[sub,link]
                    df=pd.DataFrame([data],columns=["Subject","Link"])
                    for x ,row in df.iterrows(): 
                       send_output_mail(row,d)
                       time.sleep(3)
                    rec_inter=pd.concat([rec_inter,df])
                    rec_inter.to_excel(os.path.join(output_dir,"Recognised_intermediaries_{}.xlsx".format(d.strftime("%d%m%y"))),index=False)
                    time.sleep(3) 
        driver.close()
    except Exception as e:
              print(e)    
              driver.close()
  except Exception as e:
              print(e)    
              driver.close()
   

def main(nd):
    d=datetime.datetime.now()
    dt="22:00:00"
    d1=datetime.datetime.today().date()-datetime.timedelta(nd)
    while d.strftime("%H:%M:%S")<dt:
        circular_data(d1)
        master_data(d1)
        gazette_data(d1)
        regulation_data(d1)
        intermediary(d1)
        process_running(d)
        emails = get_contacts(os.path.join(output_dir,'back.txt')) # read contacts   'circular.txt'
        subject = "SEBI Circular running Alert - {} ".format(d.strftime("%y-%m-%d-%H"))  #subject    
        process_email(emails=emails, subject=subject, html_email=os.path.join(download_dir,"mail_data{}.txt".format(d.strftime("%H"))))
        time.sleep(300)
        d=datetime.datetime.now()
        
     #logging.info("Remove files from the download dir after 11 PM ")
    files = glob.glob(os.path.join(download_dir,'*.txt'))  # find .txt files in download dir and list them  
    for f in files:
        os.remove(f)  # remove all .txt files from the list     
    #logging.info("deleting text files from download directory") 
    print("deleting txt file for {}".format(d.date()))          
    emails = get_contacts(os.path.join(output_dir,'back.txt')) # read contacts 'circular_alerts.txt'
    sub_list={'SEBI Circular data':"Circular_{}.xlsx".format(d1.strftime("%d%m%y")),
              'SEBI Master data':"master_circular_{}.xlsx".format(d1.strftime("%d%m%y")),
              'SEBI Gazette data':"Gazette_{}.xlsx".format(d1.strftime("%d%m%y")),
               "SEBI Regulation data":"Regulation_{}.xlsx".format(d1.strftime("%d%m%y")),
               "SEBI Recognised intermediary":"Recognised_intermediaries_{}.xlsx".format(d1.strftime("%d%m%y"))}
    for x in sub_list:
        try:                
           subject = "{} - {} ".format(x,d.strftime("%y-%m-%d"))  #subject 
           print(subject)
           process_email(emails=emails, subject=subject, csvfile="{}".format(sub_list[x]))
        except Exception as e:
          print(e)
       
          
main(0)
















