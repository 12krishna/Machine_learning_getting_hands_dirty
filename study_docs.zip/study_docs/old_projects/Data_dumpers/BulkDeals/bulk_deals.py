# -*- coding: utf-8 -*-
"""
Created on Tue Mar  2 15:56:44 2021

@author: krishna
"""

import os, shutil
import re
import sys
import logging
import numpy as np
import pandas as pd
import datetime, time
from sqlalchemy import create_engine
#import pymysql


input_dir = "D:\\Data_dumpers\\BulkDeals\\Input\\"
master_dir = "D:\\Master\\"
output_dir = "D:\\Data_dumpers\\BulkDeals\\Output\\"
processed_dir = "D:\\Data_dumpers\\BulkDeals\\Processed\\"
# define logging for the file system at debug or higher level
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    datefmt='%m-%d %H:%M',
                    filename='test.log')



def mysql_configs():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("mysql,")[-1].split("=")[-1]) for config in f if config.startswith("mysql")]
    return tuple(f)


def mysql_connect(mysql_host, username, password, db):
    try:
        sqlEngine = create_engine("mysql+pymysql://{}:{}@{}/{}".format(username, password,mysql_host,db),
                                   pool_recycle=3600)

        conn    = sqlEngine.connect()
        return conn, sqlEngine

    except Exception as e:
        logging.error(e)
        return -1, -1

def genfilename(d):

    return "Nse & Bse Bulk Deal "+d.strftime("%d-%b-")+d.strftime("%Y")[2:]+".xlsx"

def read_bulk_block_file(d):

    filename = genfilename(d)
    while 1:
        if os.path.exists(os.path.join(input_dir, filename)):
            # process
            df = pd.read_excel(os.path.join(input_dir, filename))
            df.dropna(how='all', axis=0, inplace=True)
            df.columns = [ col.strip().lower().replace(" ","") for col in df.columns]
            try:
                df['date'] = df['date'].dt.date
            except:
                logging.error("Date could not be parsed in file, format might have changed")

            df['buy/sell'] = df['buy/sell'].str.strip().str.lower()
            df.loc[df['buy/sell']=='buy', 'buy/sell'] = 'Buy'
            df.loc[df['buy/sell']=='sell', 'buy/sell'] = 'Sell'

            df['quantitytraded'] = df['quantitytraded'].astype(int)
            df['tradeprice'] = df['tradeprice'].astype(float)

            df[['symbol','clientname']] = df[['symbol','clientname']].applymap(lambda row : row.strip())
            df['inrcrs'] = df[['quantitytraded','tradeprice','inrcrs']].apply(
                            lambda row: round(row['quantitytraded']*row['tradeprice']/10**7,2), axis=1)

            return df, filename

        else:
            print ("Sleep for 2 min")
            time.sleep(120)


def dump_data(sqlEngine, conn, db, mysql_host, username, password, df, d, filename):

    # load data in mysql
    if df.empty!=True:
        logging.info("Pushing data to MYSQL server")

        sqlEngine.execute("CREATE TABLE IF NOT EXISTS bulkdeals (date DATE not null, ticker varchar(20) not null, \
                                                                 symbol VARCHAR(30), clientname varchar(255) not null, side varchar(5) not null,\
                                                                 quantitytraded bigint, tradeprice real, inrcrs real,\
                                                                 primary key (date, ticker, clientname, side) )")

        try:
            df.to_sql(name='bulkdeals', con=conn, if_exists = 'append', index=False)
            df.to_csv(os.path.join(output_dir,"bulkdeals_{}.csv".format(d)))
            shutil.move(os.path.join(input_dir, filename), os.path.join(processed_dir, filename))
            logging.info("Data dumped successfully.....")

        except Exception as e:
            logging.error(e)
            # refresh connection, try again
            conn, sqlEngine = mysql_connect(mysql_host, username, password, db)
            if conn!=-1:
                logging.info("(Refresh) MYSQL: {} -> Connection success".format(mysql_host))
                df.to_sql(name='bulkdeals', con=conn, if_exists = 'append', index=False)
                df.to_csv(os.path.join(output_dir,"bulkdeals_{}.csv".format(d)))
                shutil.move(os.path.join(input_dir, filename), os.path.join(processed_dir, filename))
                logging.info("Data dumped successfully.....")

def get_ticker(df):

    scripmaster = pd.read_csv(os.path.join(master_dir,"scripmaster.csv"), names = ['NseSymbol','BseSymbol','UnnamedField3',
                                'Company Name','UnnamedField5','UnnamedField6','ISIN','RICNse','Sedol',
                                'RICBse','UnnamedField11','BseTicker','NseTicker','UnnamedField14','NfoTicker'],
                                    encoding="ISO-8859-1", header=None)[['NseSymbol','BseSymbol','ISIN','BseTicker','NseTicker']]
    instrument = pd.read_csv(os.path.join(master_dir,"instrument.csv"), low_memory=False)
    instrument = instrument[instrument['ExchangeSegment'].isin(['NSE','BSE'])][['SecurityCode','Symbol','ExchangeSegment','ISIN']]
    instrument = instrument.merge(scripmaster, on=['ISIN'], how='left')
    instrument[['Symbol','NseTicker','BseTicker']] = instrument[['Symbol','NseTicker','BseTicker']].apply(lambda col: col.str.strip())
    instrument['NseTicker'] = instrument['NseTicker'].str[1:]
    #instrument.dropna(subset=['NseTicker','BseTicker'], inplace=True, how='all')
    instrument[['NseTicker','BseTicker']] = instrument[['NseTicker','BseTicker']].replace('', np.nan)

    instrument.loc[instrument['NseTicker']==instrument['BseTicker'], 'ticker'] = instrument['NseTicker']
    instrument.loc[instrument['NseTicker'].isna() , 'ticker'] = instrument['BseTicker']
    instrument.loc[instrument['BseTicker'].isna() , 'ticker'] = instrument['NseTicker']
    instrument = instrument[['Symbol','ticker']]
    instrument.drop_duplicates(inplace=True, keep='last')
    instrument.dropna(inplace=True)
    instrument.rename(columns={'Symbol':'symbol'}, inplace=True)

    df = df.merge(instrument, on=['symbol'], how='left')

    return df




def  main(nd):

    d = datetime.datetime.now().date() - datetime.timedelta(days=nd)
    logging.info("Processing for date {}".format(d))
    # get mysql config details
    mysql_host, username, password, db = mysql_configs()

    # mysql connection
    conn, sqlEngine = mysql_connect(mysql_host, username, password, db)
    if conn!=-1:
        logging.info("MYSQL: {} -> Connection success".format(mysql_host))

    df, filename = read_bulk_block_file(d)
    # get bloom ticker
    df = get_ticker(df)
    df = df[['date','ticker','symbol','clientname','buy/sell','quantitytraded','tradeprice','inrcrs']].rename(columns={'buy/sell':'side'})

    dump_data(sqlEngine, conn, db, mysql_host, username, password, df, d, filename)

    # close mysql connection gracefully
    conn.close()



if __name__ == "__main__":
    main(nd=0)  # set date range here;

