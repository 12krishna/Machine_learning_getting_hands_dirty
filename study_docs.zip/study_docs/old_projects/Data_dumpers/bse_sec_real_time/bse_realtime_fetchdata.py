# -*- coding: utf-8 -*-
"""
Created on Thu Jul  9 13:20:06 2020

@author: krishna
"""

import os,sys,os.path
import pandas as pd
import numpy as np
import datetime
import logging
import time
import copy
import bse


#redis_host = "localhost"
#redis_host = "10.223.104.65"
#r = redis.Redis(host=redis_host, port=6379)
#cassandra_host_list = ["172.17.9.51"]

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\nse_sec_real_time\\output\\'
log_path="D:\\Data_dumpers\\bse_sec_real_time\\"


# define logging for the file system at debug or higher level
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    datefmt='%m-%d %H:%M',
                    filename=log_path+'bse_realtime.log', filemode='w')
#logging.basicConfig(level=logging.DEBUG, format='%(relativeCreated)6d %(threadName)s %(message)s')
# define a Handler which writes INFO messages or higher to the sys.stderr
console = logging.StreamHandler()
console.setLevel(logging.INFO)
# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)
logging.info("Start process")


def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)


def get_bse_data(bse_symbols, non_fno_symbols, t):
    '''Func to fetch delivery data in real time for all the symbols'''
       
    bse_obj = bse.Bse()  # create nse object to scrap real time data; package nsetools
    logging.info("BSE object from bse.py created...")
    logging.info( "Fetching data for {} symbols".format(len(bse_symbols)) )
    s_time = time.time()
    #data = []
    
    t_back = t.replace(hour=t.hour-1, minute=50)
    if t.hour==16:
        logging.info("Scrap data for EOD")
        t_back = t
    
    append_flag=0
    while len(bse_symbols)!=0 :   
        if t.hour!=16:
            if datetime.datetime.now().time() >= datetime.time(t.hour,58):
                break
        else:
            if datetime.datetime.now().time() >= datetime.time(t.hour+2,58):
                break
    
        symbols_iter = copy.deepcopy(bse_symbols)
        for stock in symbols_iter:            
            try:            
                res = bse_obj.get_quote(stock)         
                sec_date = pd.to_datetime(res['TradeDate'].replace("|",''))   
                if not ((sec_date.time()>=t_back) and sec_date.date()==datetime.datetime.now().date()):
                    continue
                # append data in csv file 
                output_file = open(r"\\172.17.9.43\Fno_analytics\Security delivery position\BSE_delivery_{}.txt".format(datetime.datetime.now().date()), 'ab')
    
                output_file.write(','.join([stock, str(sec_date.date()), str(t),
                                            res['QtyTraded'], res['DeliverableQty'], res['PcDQ_TQ']])+"\n")
                output_file.flush()  
                output_file.close()
    
                bse_symbols.remove(stock)
                logging.info("Data fetched for {}".format(stock))
                
            except Exception as e:
                logging.error("Error fetching data for {}".format(stock))
                logging.error(e)
                logging.info("Sleep for 5 sec and, start new connection....")
                time.sleep(2)
                bse_obj = bse.Bse()
        
        
        if len(bse_symbols)!=0:
            logging.info("Data missing for {} stocks".format(len(bse_symbols)))
            time.sleep(5)     
            
        if len(bse_symbols)<=1 and append_flag==0:
            logging.info("Append non fno symbols for downloading...")
            bse_symbols = bse_symbols+non_fno_symbols
            append_flag=1
        
    
    logging.info("Data fetching time {}".format(time.time()-s_time))
        
#data = pd.DataFrame(data, columns=['Stock_name', 'Del_Qty',"Del_Pct", 'Qty_Traded', 'Time', 'Avg_Price'])
    
    
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        logging.info("Working day, open file and start process")        
        # csv file in append mode to append data
        if not os.path.exists(r"\\172.17.9.43\Fno_analytics\Security delivery position\BSE_delivery_{}.txt".format(datetime.datetime.now().date())):
            output_file = open(r"\\172.17.9.43\Fno_analytics\Security delivery position\BSE_delivery_{}.txt".format(datetime.datetime.now().date()), 'ab')
            output_file.write("Symbol,traded_date,traded_time,QT,DQ,pc_DQ_TQ\n")  # header    
            output_file.flush()
            output_file.close()    
        
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

    
def main():
    
    if process_run_check(datetime.datetime.now().date()) == -1:
        return -1 
    
    
    
    # load data for BSE 500 stocks universe
    symbols = pd.read_excel(master_dir+"BSE_500_tickers.xlsx")[['NSE Symbol']]
    symbols['NSE Symbol'] = symbols['NSE Symbol'].astype(str)
    symbols['NSE Symbol'] = symbols['NSE Symbol'].str.strip()
    symbols = list(sorted(symbols['NSE Symbol'].tolist()))
    
    
    # load active fno stocks 
    fno_symbols=pd.read_excel(master_dir+'MasterData.xlsx')
    fno_symbols=fno_symbols[(fno_symbols["IsActiveFNO"]==True) & (fno_symbols["Type"]=="SSF")]
    fno_symbols['SYMBOL'] = fno_symbols['SYMBOL'].astype(str)
    fno_symbols['SYMBOL'] = fno_symbols['SYMBOL'].str.strip()
    fno_symbols = list(sorted(fno_symbols['SYMBOL'].tolist()))
    
    # prospective fno symbols
    others = pd.read_excel(master_dir+"Security_delivery_nonNIFTY.xlsx")
    others['SYMBOL'] = others['SYMBOL'].str.strip()
    others = [ str(s) for s in others['SYMBOL'].values.tolist()]
    fno_symbols = list(set(fno_symbols+others))
    
    
    for i in range (10,17):
        while True:                
            if datetime.datetime.now().time() > datetime.time(i,0):
                logging.info("Fetch data for instance time {}".format(datetime.time(i,0)))
                temp_symbols = [s for s in symbols if s not in fno_symbols]  # symbols other than fno universe
                get_bse_data(copy.deepcopy(fno_symbols), copy.deepcopy(temp_symbols), datetime.time(i,0))
                #get_bse_data(copy.deepcopy(temp_symbols), datetime.time(i,0))
                
                break
            else:
                print "Sleep until next event time is triggered"
                time.sleep(30)
                
    # close csv output file 
    #output_file.close()
    
    

if __name__=='__main__':
    main()

# https://api.bseindia.com/BseIndiaAPI/api/SecurityPosition/w?quotetype=RR&scripcode=542602