# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 18:54:17 2020

@author: krishna
"""

import requests
from urllib import urlencode
import pandas as pd
import json

master_dir = "D:\\Data_dumpers\\Master\\"

class Bse():
    '''Class to fetch bse secuirty data'''
    
    def __init__(self):
        self.headers = self.bse_headers()
        # URL list
        self.get_delivery_url = "https://api.bseindia.com/BseIndiaAPI/api/SecurityPosition/w?"
        self.bse_codes_dict, self.bse_series_dict = self.scrip_code_reader()
        
    def bse_headers(self):            
        headers = {'Accept': '*/*',           
                'Accept-Language': 'en-US,en;q=0.5',
                'Host': 'www.api.bseindia.com',
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:28.0) Gecko/20100101 Firefox/28.0',
                'X-Requested-With': 'XMLHttpRequest'
                }
        return headers
    
    def scrip_code_reader(self):
        '''Reads master file for active symbols and bse 500 ticker file to fetch bse scripcodes
        Returns dict of bse scrip code and nse symbol mapping '''
        try:
            df = pd.read_excel(master_dir+"BSE_500_tickers.xlsx")[['BSE Code', 'NSE Symbol','Series']]
            print "BSE 500 ticker codes fetched"
        except :
            raise Exception ("BSE ticker file read error")
        '''
        try:
            active_symbols = pd.read_excel(master_dir+"MasterData.xlsx")
        except:
            raise Exception ("Master data file read error")
            
        active_symbols = active_symbols[(active_symbols['Type']=='SSF') & 
                                        (active_symbols['IsActiveFNO']==True)]['SYMBOL'].values.tolist()
        
        df = df[df['NSE Symbol'].isin(active_symbols)]
        '''
        df = df.astype(str)
        return dict(df[['NSE Symbol','BSE Code']].values.tolist()), dict(df[['NSE Symbol','Series']].values.tolist()) 
        
        
    
    def build_url_for_quote(self, code, series):
        """
        builds a url which can be requested for a given stock code  ; quotetype=EQ&scripcode=500209
        :param code: string containing stock code.
        :return: a url object
        """
        if code is not None and type(code) is str:
            encoded_args = urlencode([('quotetype', series), ('scripcode', code)])
            return self.get_delivery_url + encoded_args
        else:
            raise Exception('code must be string')
            
            
    def get_quote(self, code, as_json=False):
        """
        gets the quote for a given stock code
        :param code:
        :return: dict or None
        :raises: HTTPError, URLError
        """
        code = code.upper()
        
        if code in self.bse_codes_dict.keys():
            series = self.bse_series_dict[code] # get series for that symbol
            code = self.bse_codes_dict[code] # get bse scrip code for symbol
            url = self.build_url_for_quote(code, series)
            res = requests.get(url, timeout=10)
            if res.status_code==200:
                return self.parse_delivery_data(res.json())
            else:
                
                return None
            
            
    def parse_delivery_data(self, data):
        '''
        params: Takes in json data
        returns: parsed data in python dict format
        '''
        
        try:                
            data = json.loads(data)
            
            for key, value in data.iteritems():
                data[key] = str(value).replace(",","")
                
            return data
        except:
            raise ("Parsing json data error")
        

    
    
    
