from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime,os,shutil,logging,redis,sys
import pandas as pd 
#import schedule

redis_host = "localhost"
# redis_host = "10.223.104.61"
r = redis.Redis(host=redis_host, port=6379)

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\nse_sec_real_time\\output\\'
email_dir='D:\\Emails\\Output\\'
key_dir='D:\\Data_dumpers\\nse_sec_real_time\\key\\'

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["stock","date","QT","DQ","%DQ"]

f_list=["Symbol","Symbol_key","date","QT","DQ","%DQ"]

global f_df
f_df=pd.DataFrame(columns=f_list)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1
   
def main():
    d=datetime.datetime.now()-datetime.timedelta(hours=9)
      
    if process_run_check(d.date()) == -1:
        return -1 
    
    r_df=pd.read_msgpack(r.get('key_bse_sec_real_time_dev'))
    logging.info("data fetched from redis success")
    r_df=r_df.applymap(str)  
#    num=['10','11','12','13','14','15','16']
    
#    dt=['11:10:00','12:10:00','13:10:00','14:10:00','15:10:00','16:10:00']
    if os.path.exists(output_dir+"bse_Security-wise Delivery Position_{}.xlsx".format(d.date())):
        new_df=pd.read_excel(output_dir+"bse_Security-wise Delivery Position_{}.xlsx".format(d.date()))
        r_df=r_df[['Q_T','D_Q','%D_Q']]
#        columns1 = pd.MultiIndex.from_product([['{}'.format(d)], ['Q_T','DQ','%DQ']])
        columns1 = ['{}_Q_T'.format(d.strftime('%Y-%m-%d:%H:%M')),'{}_DQ'.format(d.strftime('%Y-%m-%d:%H:%M')),'{}_%DQ'.format(d.strftime('%Y-%m-%d:%H:%M'))]

        r_df.columns=columns1
        newdf=pd.concat([new_df,r_df],axis=1)
        newdf.to_excel(output_dir+"bse_Security-wise Delivery Position_{}.xlsx".format(d.date()),index=False)     
    else:
        print r_df
        r_df=r_df[['Symbol','Q_T','D_Q','%D_Q']]
#        columns = pd.MultiIndex.from_product([['{}'.format(d)], ['Q_T','DQ','%DQ']])
        columns = ['{}_Symbol'.format(d.strftime('%M')),'{}_Q_T'.format(d.strftime('%Y-%m-%d:%H:%M')),'{}_DQ'.format(d.strftime('%Y-%m-%d:%H:%M')),'{}_%DQ'.format(d.strftime('%Y-%m-%d:%H:%M'))]

        r_df.columns=columns
        r_df.to_excel(output_dir+"bse_Security-wise Delivery Position_{}.xlsx".format(d.date()),index=False)
        
        shutil.copy(output_dir+"bse_Security-wise Delivery Position_{}.xlsx".format(d.date()),
                    email_dir+"bse_Security-wise Delivery Position_{}.xlsx".format(d.date()))
     
main()
