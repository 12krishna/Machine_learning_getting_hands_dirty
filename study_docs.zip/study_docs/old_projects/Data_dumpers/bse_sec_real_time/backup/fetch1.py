from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options 
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime,re,os,random,shutil,logging
import pandas as pd 
from selenium.webdriver.common.proxy import Proxy,ProxyType
from lxml import html
import redis
import numpy as np

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\bse_sec_real_time\\output\\'
email_dir="D:\\Emails\\Output\\"

redis_host = "localhost"
# redis_host = "10.223.104.61"
r = redis.Redis(host=redis_host, port=6379)



def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["date","QT","DQ","%DQ","stock"]


def get_bse_secwise_real_time(stock,symbol,code,d):
    driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe")    
    data=''
    try:
        option = webdriver.ChromeOptions()
        option.add_argument('headless')
            
        driver.get("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))

        driver.find_element_by_xpath('//*[@id="sdp"]')
        
        WebDriverWait(driver,30).until(ec.visibility_of_element_located((By.XPATH,'//*[@id="sdp"]')))
       
        soup=BeautifulSoup(driver.page_source, 'lxml')
        h1=soup.find_all('td',{'class':'tdcolumn ng-binding'})
        #    print h1
        data=[]
        
        for i in h1:
            data.append(i.getText())
        
    
        data=pd.DataFrame(data)
        data=data[-4:]
        data=data.T
        data["stock"]=symbol
        data.columns=list1
        data.reset_index(drop=True,inplace=True)

#        
       
#        print data
        print "normal output",data
        if os.path.exists(output_dir+"bse_file_fe{}.txt".format(d.date())):
            file1 = open(output_dir+"bse_file_fe{}.txt".format(d.date()),"a") 
            l1=str(symbol) + "," + str(data["date"][0]) + "," + str(data["QT"][0]) + "," + str(data["DQ"][0]) + "," + str(data["%DQ"][0])
            file1.writelines(l1)
            file1.writelines("\n")
            file1.writelines("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))
            file1.writelines("\n")
            file1.close()
        else:
            file1 = open(output_dir+"bse_file_fe{}.txt".format(d.date()),"w") 
            l1=str(symbol) + "," + str(data["date"][0]) + "," + str(data["QT"][0]) + "," + str(data["DQ"][0]) + "," + str(data["%DQ"][0])
            file1.writelines(l1)
            file1.writelines("\n")
            file1.writelines("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))
            file1.writelines("\n")
            file1.close()
        
        driver.quit()
    except Exception as e:
        data=''
        print 'Exception : {}'.format(e)
        driver.quit()
        
    return data


def get_data_symbols(d,dt):
    
    print "hour",d.strftime('%H')
    date_d=d.strftime('%H:%M:%S')
    print dt
    print date_d
    while date_d < dt:
        
        r_df=pd.read_msgpack(r.get('bse_sec_realtime_data_dev'))
        r_df=r_df.applymap(str)
        hourly_df=r_df.loc[r_df["symbol_key"].str.endswith('{}'.format(d.strftime('%H')))] # curr hour data
        hourly_df.reset_index(drop=True,inplace=True)
        print "hourly",hourly_df
        check=hourly_df["DQ"].isin(['-']).any().any()
        print "check",check
        if check==True:
            n_df=hourly_df.loc[hourly_df["DQ"]=='-']
            print "Getting data for {} symbols".format(len(n_df))
            n_df.sort_values(by='symbol', inplace=True)
            df=[]
            for col,row in n_df.iterrows():                 
                df.append(get_bse_secwise_real_time(row["stock"], row['symbol'], row['code'], d))
        
            final_df=pd.concat(df)
            final_df.reset_index(drop=True,inplace=True)
            
            r_df.update(final_df)
            r.set('bse_sec_realtime_data_dev',r_df.to_msgpack(compress='zlib'))
         
            
            final_df.to_excel("temp.check.xlsx",index=False)
                   
            logging.info("data stored in redis success")

        else:
            print "Data scraped for all symbols; Sleep for 30 sec"
            time.sleep(30)
            
            d = datetime.datetime.now()-datetime.timedelta(hours=6)
            print "hour",d.strftime('%H')
            date_d=d.strftime('%H:%M:%S')
            print dt
            print date_d    
            return -1
    
    


def main():
   
    d=datetime.datetime.now()-datetime.timedelta(hours=8)
    dt='24:00:00'    
#    get_data_symbols(d,dt)  # keep updating data till market close
    
    bse_url=pd.read_excel(master_dir+"bse_scrip_master1.xlsx")
#    final_df=pd.DataFrame(columns=list1)
    
    num=['10','11','12','13','14','15','16']
    
#    dt=['11:10:00','12:10:00','13:10:00','14:10:00','15:10:00','16:10:00']
    
#    bse_url=pd.read_excel(master_dir+"bse_scrip_master.xlsx")
    
    symbol_key=[]
    
    for i in range(len(num)):
        for j in range(len(bse_url["symbol"])):
            val=bse_url["symbol"][j]+'_'+num[i]
            symbol_key.append(val)
                
    symbol=pd.DataFrame(symbol_key,columns=["symbol"])
    symbol=symbol["symbol"].str.split('_',expand=True)
    symbol.rename(columns={0:'symbol',1:'k_num'},inplace=True)
    symbol["symbol_key"]=symbol_key

    symbol=symbol.loc[symbol["symbol_key"].str.endswith('{}'.format(d.strftime("%H")))]
    symbol.reset_index(drop=True,inplace=True)
    symbol=symbol[["symbol","symbol_key"]]
    
    for i in range(len(list1)):
        symbol.insert(i+2,list1[i],'NAN')
        
    symbol["code"]=bse_url["code"]
    symbol["stock"]=bse_url["stock"]
    symbol=symbol[:7]
   
    r.set( 'bse_sec_realtime_data_dev',symbol.to_msgpack(compress='zlib'))
    
    dt='20:00:00'    
    get_data_symbols(d,dt) 
#    df=[]  
#    for i in range(len(bse_url)):
#        df.append(get_bse_secwise_real_time(bse_url['stock'][i],bse_url['symbol'][i],bse_url['code'][i],d))           
#        print "df",df[i]
#        
#    final_df=pd.DataFrame(df)
#    final_df=pd.concat([df])
#    final_df.columns=list1
#    final_df["Symbol"]=bse_url['symbol']
#    final_df["date_time"]=d
#     
#    final_df.to_excel("bse_scraped_fetch1{}.xlsx".format(d.date()),index=False)
       
    
    
main()