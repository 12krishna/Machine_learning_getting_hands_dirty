import time,datetime,os,shutil,logging,redis,sys
import pandas as pd 

#redis_host = "localhost"
redis_host = "10.223.104.65"
r = redis.Redis(host=redis_host, port=6379)

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\bse_sec_real_time\\output\\'
email_dir="D:\\Emails\\Output\\"
os.chdir("D:\\Data_dumpers\\bse_sec_real_time\\")

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["date","QT","DQ","%DQ"]

f_list=["date","QT","DQ","%DQ"]

global f_df
f_df=pd.DataFrame(columns=f_list)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

                 

def chunks(lst, n):  
        symbols_chunks= []
        for i in range(0, len(lst), n):
            symbols_chunks.append(lst[i:i + n])
        return symbols_chunks





def create_redis_dict(d):
    
    num=['10','11','12','13','14','15','16']
    
    bse_url=pd.read_excel(master_dir+"bse_scrip_master.xlsx")
    
  
    symbol_key=[]
    
    for i in range(len(num)):
        for j in range(len(bse_url["symbol"])):
            val=bse_url["symbol"][j]+'_'+num[i]
            symbol_key.append(val)
                
    symbol=pd.DataFrame(symbol_key,columns=["symbol"])
    symbol=symbol["symbol"].str.split('_',expand=True)
    symbol.rename(columns={0:'symbol',1:'k_num'},inplace=True)
    symbol["symbol_key"]=symbol_key

    symbol=symbol.loc[symbol["symbol_key"].str.endswith('{}'.format(d.strftime("%H")))]
    symbol.reset_index(drop=True,inplace=True)
    symbol=symbol[["symbol","symbol_key"]]
    
    for i in range(len(list1)):
        symbol.insert(i+2,list1[i],'NAN')
        
    symbol["code"]=bse_url["code"]
    symbol["stock"]=bse_url["stock"]
    
    symbol1=symbol[:50]
    symbol1.reset_index(drop=True,inplace=True)
    symbol2=symbol[50:100]
    symbol2.reset_index(drop=True,inplace=True)
    symbol3=symbol[100:]
    symbol3.reset_index(drop=True,inplace=True)
    
    r.set('bse_sec_realtime_data_dev1_{}'.format(d.strftime("%H")),symbol1.to_msgpack(compress='zlib'))
    r.set('bse_sec_realtime_data_dev2_{}'.format(d.strftime("%H")),symbol2.to_msgpack(compress='zlib'))
    r.set('bse_sec_realtime_data_dev3_{}'.format(d.strftime("%H")),symbol3.to_msgpack(compress='zlib'))
    
def main():
    
    
    d=datetime.datetime.now()#-datetime.timedelta(hours=8)
    
    if d.strftime("%H")=='10':
        num=[10,11,12,13,14,15,16]
        for i in range(len(num)):
            r.delete('bse_sec_realtime_data_dev1_{}'.format(num[i]))
            r.delete('bse_sec_realtime_data_dev2_{}'.format(num[i]))
            r.delete('bse_sec_realtime_data_dev3_{}'.format(num[i]))
      
    if process_run_check(d.date()) == -1:
        return -1 
    
    create_redis_dict(d)
    
    os.system("D:\\Data_dumpers\\bse_sec_real_time\\main_v1.bat")
    
main()
 
