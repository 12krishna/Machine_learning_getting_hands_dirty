import time,datetime,os,shutil,logging,redis,sys
import pandas as pd 

redis_host = "localhost"
# redis_host = "10.223.104.61"
r = redis.Redis(host=redis_host, port=6379)

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\bse_sec_real_time\\output\\'
email_dir="D:\\Emails\\Output\\"
os.chdir("D:\\Data_dumpers\\bse_sec_real_time\\")

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["date","QT","DQ","%DQ"]

f_list=["date","QT","DQ","%DQ"]

global f_df
f_df=pd.DataFrame(columns=f_list)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

                 

def chunks(lst, n):  
        symbols_chunks= []
        for i in range(0, len(lst), n):
            symbols_chunks.append(lst[i:i + n])
        return symbols_chunks





def create_redis_dict():
    
    num=['10','11','12','13','14','15','16']
    
#    dt=['11:10:00','12:10:00','13:10:00','14:10:00','15:10:00','16:10:00']
    
    bse_url=pd.read_excel(master_dir+"bse_scrip_master.xlsx")
    
    symbol_key=[]
    
    for i in range(len(num)):
        for j in range(len(bse_url["symbol"])):
            val=bse_url["symbol"][j]+'_'+num[i]
            symbol_key.append(val)
                
    symbol=pd.DataFrame(symbol_key,columns=["symbol"])
    symbol=symbol["symbol"].str.split('_',expand=True)
    symbol.rename(columns={0:'symbol',1:'k_num'},inplace=True)
    symbol["symbol_key"]=symbol_key
    f_df["symbol"]=symbol["symbol"]
    f_df["symbol_key"]=symbol["symbol_key"]
    
    f_df.fillna('-', inplace=True)
    
    
     # divide symbols and publish dict to redis
    symbols_list = chunks(list(f_df['symbol'].unique()), len(list(f_df['symbol'].unique()))/3 )
    final_symbols = []
    if len(symbols_list)>3:
        final_symbols.append(symbols_list[0]); final_symbols.append(symbols_list[1])
        final_symbols.append([y for x in symbols_list[2:] for y in x])
    else:
        final_symbols = symbols_list
    
    
    i=1    
    for l in final_symbols:
        temp = f_df[f_df['symbol'].isin(l)]
        temp = temp.merge(bse_url, on='symbol', how='left')
        
        r.set( 'bse_sec_realtime_data_{}'.format(i) ,temp[['symbol','symbol_key','stock','code',
              "date","QT","DQ","%DQ"]].to_msgpack(compress='zlib'))
        i+=1
          
    
       
    
def main():
    
    
    d=datetime.datetime.now()
   
    if process_run_check(d.date()) == -1:
        return -1 
    
    create_redis_dict()

    os.system("D:\\Data_dumpers\\bse_sec_real_time\\main.bat")
    
main()
 
