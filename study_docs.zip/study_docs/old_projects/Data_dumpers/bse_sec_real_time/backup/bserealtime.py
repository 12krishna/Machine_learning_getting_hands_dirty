#from selenium import webdriver
#from selenium.webdriver.support.ui import WebDriverWait
#from selenium.webdriver.chrome.options import Options 
#from selenium.webdriver.support import expected_conditions as ec
#from selenium.common.exceptions import TimeoutException
#from selenium.webdriver.common.by import By
#from bs4 import BeautifulSoup
#import time,datetime,re,os,random,shutil
#import pandas as pd 
#from selenium.webdriver.common.proxy import Proxy,ProxyType
#from lxml import html
#
#master_dir='D:\\Data_dumpers\\Master\\'
#output_dir=' '
#list1=["date","Quantity Traded","Deliverable Quantity (gross across client level)","% of Deliverable Quantity to Traded Quantity","stock"]
#
#def get_bse_secwise_real_time(stock,symbol,code):
#    try:
#        option = webdriver.ChromeOptions()
#        option.add_argument('headless')
#            
#        driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe")    
#        driver.get("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))
#
#        driver.find_element_by_xpath('//*[@id="sdp"]')
#        
#        WebDriverWait(driver,30).until(ec.visibility_of_element_located((By.XPATH,'//*[@id="sdp"]')))
#        driver.implicitly_wait(180)
#        time.sleep(8)
#        
#        soup=BeautifulSoup(driver.page_source, 'lxml')
#        h1=soup.find_all('td',{'class':'tdcolumn ng-binding'})
#        #    print h1
#        data=[]
#        for i in h1:
#            data.append(i.getText())
#        
#    
#        data=pd.DataFrame(data)
#        data=data[-4:]
#        data=data.T
#        data["stock"]=symbol
#
#        print data
#
#    finally:
#            driver.quit()
#    
#    driver.quit()
#    
#    return data
#
#def main():
#        d=datetime.datetime.now()
#        bse_url=pd.read_excel("final_bse_master.xlsx")
#        final_df=pd.DataFrame(columns=list1)
#        
#        df=[]  
#       
#        for i in range(len(bse_url)):
#            df.append(get_bse_secwise_real_time(bse_url['stock'][i],bse_url['symbol'][i],bse_url['code'][i]))           
#            print "df",df[i]
#         
#        final_df=pd.concat(df) 
#        final_df["stock"]=bse_url['symbol']
#        final_df.columns=list1
#        final_df["date_time"]=d
#        
#        if os.path.exists(output_dir+"bse_Security-wise Delivery Position_{}.xlsx".format(d.date())):
#            new_df=pd.read_excel(output_dir+"bse_Security-wise Delivery Position_{}.xlsx".format(d.date()))
#            new_df.append(final_df)
#        else:
#            final_df.to_excel(output_dir+"bse_Security-wise Delivery Position_{}.xlsx".format(d.date()),index=False)
#main()
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options 
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime,re,os,random,shutil,logging
import pandas as pd 
from selenium.webdriver.common.proxy import Proxy,ProxyType
from lxml import html

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\bse_sec_real_time\\output\\'
email_dir="D:\\Emails\\Output\\"

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["date","Quantity Traded","Deliverable Quantity (gross across client level)","% of Deliverable Quantity to Traded Quantity","Symbol"]

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

def get_bse_secwise_real_time(stock,symbol,code):
    try:
        ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
        p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
        ip=ip+':'+p
        # Configure Proxy Option
        prox = Proxy()
        prox.proxy_type = ProxyType.MANUAL
            
        # Proxy IP & Port
        prox.http_proxy = ip
        prox.https_proxy = ip
            
        # Configure capabilities 
        capabilities = webdriver.DesiredCapabilities.CHROME
        prox.add_to_capabilities(capabilities)

        option = webdriver.ChromeOptions()
        option.add_argument('headless')
            
        driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe",desired_capabilities=capabilities,chrome_options=option)    
        driver.get("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))

        driver.find_element_by_xpath('//*[@id="sdp"]')
        
        WebDriverWait(driver,30).until(ec.visibility_of_element_located((By.XPATH,'//*[@id="sdp"]')))
       
        soup=BeautifulSoup(driver.page_source, 'lxml')
        h1=soup.find_all('td',{'class':'tdcolumn ng-binding'})
        #    print h1
        data=[]
        
        for i in h1:
            data.append(i.getText())
            
    
        data=pd.DataFrame(data)
        data=data[-4:]
        print "data",data
        data=data.T
        data["stock"]=symbol

#        print data
        driver.quit()
    except: 
            data="no data"
            driver.quit()
        
    return data

def main():
   
    d=datetime.datetime.now()
    
        
    if process_run_check(d.date()) == -1:
        return -1 
    
    bse_url=pd.read_excel(master_dir+"bse_scrip_master.xlsx")
    bse_url=bse_url[:4]
    final_df=pd.DataFrame(columns=list1)

    df=[]  
    for i in range(len(bse_url)):
        df.append(get_bse_secwise_real_time(bse_url['stock'][i],bse_url['symbol'][i],bse_url['code'][i]))           
#        print "df",df[i]
        
#    final_df=pd.DataFrame(df)
    final_df=pd.concat([df])
    final_df.columns=list1
    final_df["Symbol"]=bse_url['symbol']
    final_df["date_time"]=d
     
    final_df.to_excel("bse_scraped_{}.xlsx".format(d.date()),index=False)
    
main()

