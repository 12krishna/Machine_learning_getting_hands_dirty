from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options 
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime,re,os,random,shutil,logging
import pandas as pd 
from selenium.webdriver.common.proxy import Proxy,ProxyType
from lxml import html
import redis
import numpy as np

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\bse_sec_real_time\\output\\'
email_dir="D:\\Emails\\Output\\"
log_dir='D:\\Data_dumpers\\bse_sec_real_time\\log\\'

#redis_host = "localhost"
redis_host = "10.223.104.65"
r = redis.Redis(host=redis_host, port=6379)

logging.basicConfig(filename=log_dir+"BSE_sec_delivery{}.log".format(datetime.datetime.now().date()),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["date","QT","DQ","%DQ","stock"]


def get_bse_secwise_real_time(stock,symbol,code,d):
    
    try:
        ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
        p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
        ip=ip+':'+p
        # Configure Proxy Option
        prox = Proxy()
        prox.proxy_type = ProxyType.MANUAL
            
        # Proxy IP & Port
        prox.http_proxy = ip
        prox.https_proxy = ip
            
        # Configure capabilities 
        capabilities = webdriver.DesiredCapabilities.CHROME
        prox.add_to_capabilities(capabilities)

        option = webdriver.ChromeOptions()
        option.add_argument('headless')

        driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe",desired_capabilities=capabilities,chrome_options=option)    
        driver.get("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))
        time.sleep(5)        
        soup=BeautifulSoup(driver.page_source, 'lxml')
        h1=soup.find_all('td',{'class':'tdcolumn ng-binding'})
        #    print h1
        data=[]
        
        for i in h1:
            data.append(i.getText())
       
        data=pd.DataFrame(data)
        data=data[-4:]
        data=data.T
        data["stock"]=symbol
        data.columns=list1
        data.reset_index(drop=True,inplace=True)
        
        if data.empty==True:
            print data
            data=pd.DataFrame(data)
            data.columns=list1
            data["date"]='NAN'
            data["QT"]='NAN'
            data["DQ"]='NAN'
            data["%DQ"]='NAN'
            data["stock"]=symbol
            data.reset_index(drop=True,inplace=True)
            driver.quit()
            print data
            logging.info("if df is empty add NAN")

            return data
        
        print data
#        print "normal output",data
        if os.path.exists(output_dir+"bse_file_fe{}.txt".format(d.date())):
            file1 = open(output_dir+"bse_file_fe{}.txt".format(d.date()),"a") 
            l1=str(symbol) + "," + str(data["date"][0]) + "," + str(data["QT"][0]) + "," + str(data["DQ"][0]) + "," + str(data["%DQ"][0])
            logging.info("{}".format(l1))
            file1.writelines(l1)
            file1.writelines("\n")
            file1.writelines("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))
            file1.writelines("\n")
            file1.close()
        else:
            file1 = open(output_dir+"bse_file_fe{}.txt".format(d.date()),"w") 
            l1=str(symbol) + "," + str(data["date"][0]) + "," + str(data["QT"][0]) + "," + str(data["DQ"][0]) + "," + str(data["%DQ"][0])
            logging.info("{}".format(l1))
            file1.writelines(l1)
            file1.writelines("\n")
            file1.writelines("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))
            file1.writelines("\n")
            file1.close()
        
        driver.quit()
    except Exception as e:
        print 'Exception : {}'.format(e)
        logging.info("exception occured")

        driver.quit()
        data=pd.DataFrame()
        data.columns=list1
        data["date"]='NAN'
        data["QT"]='NAN'
        data["DQ"]='NAN'
        data["%DQ"]='NAN'
        data["stock"]=symbol
        data.reset_index(drop=True,inplace=True)
      
    return data


def get_data_symbols(d,dt):
    
    print "hour",d.strftime('%H')
    date_d=d.strftime('%H:%M:%S')
    end_d=dt.strftime("%H:%M:%S")
    print dt
    print date_d
    while date_d <= end_d:
        
        r_df=pd.read_msgpack(r.get('bse_sec_realtime_data_dev2_{}'.format(d.strftime('%H'))))
        r_df.replace('','NAN',inplace=True)
        r_df=r_df.applymap(str)
        check1=r_df[r_df["QT"].str.contains(pat='i[a-z-A-Z]',regex=True)].any().any()
        check=r_df["DQ"].isin(['NAN']).any().any()
        print "check1",check1
        if check1==True:
            n_df=r_df[r_df["QT"].str.contains(pat='i[a-z-A-Z]',regex=True)]
            print "Getting data for {} symbols".format(len(n_df))
            n_df.sort_values(by='symbol', inplace=True)

        elif check==True:
            n_df=r_df.loc[r_df["DQ"]=='NAN']
            print "Getting data for {} symbols".format(len(n_df))
            n_df.sort_values(by='symbol', inplace=True)
            
        print "Getting data for {} symbols".format(len(n_df))    
        for col,row in n_df.iterrows():
            df=[]                
            df.append(get_bse_secwise_real_time(row["stock"], row['symbol'], row['code'], d))
            final_df=pd.concat(df)
            final_df.reset_index(drop=True,inplace=True)
            row['date']=final_df["date"][0]
            row["QT"]=final_df["QT"][0]
            row["DQ"]=final_df["DQ"][0]
            row["%DQ"]=final_df["%DQ"][0]
            row["stock"]=final_df["stock"][0]
                
            r_df = pd.concat([n_df,r_df[~r_df['symbol_key'].isin(n_df['symbol_key'].values)]], axis=0)
               
            r_df.sort_values(by='symbol_key', inplace=True)
            print r_df
            r.set('bse_sec_realtime_data_dev2_{}'.format(d.strftime('%H')),r_df.to_msgpack(compress='zlib'))
          
            logging.info("data stored in redis success")
        d=datetime.datetime.now()
        date_d=d.strftime("%H:%M:%S")

def main():
   
    d=datetime.datetime.now()#-datetime.timedelta(hours=1)
    dt=datetime.datetime.now()+datetime.timedelta(hours=1)  
    get_data_symbols(d,dt) 
       
main()

