from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options 
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime,re,os,random,shutil,logging
import pandas as pd 
from selenium.webdriver.common.proxy import Proxy,ProxyType
from lxml import html
import redis

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\bse_sec_real_time\\output\\'
email_dir="D:\\Emails\\Output\\"

redis_host = "localhost"
# redis_host = "10.223.104.61"
r = redis.Redis(host=redis_host, port=6379)



def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["date","QT","DQ","%DQ","stock"]


def get_bse_secwise_real_time(stock,symbol,code,d):
    driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe")    
    data=''
    try:
        option = webdriver.ChromeOptions()
        option.add_argument('headless')
            
        print ("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))

        driver.get("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))

        driver.find_element_by_xpath('//*[@id="sdp"]')
        
        #WebDriverWait(driver,30).until(ec.visibility_of_element_located((By.XPATH,'//*[@id="sdp"]')))
        time.sleep(5)
        soup=BeautifulSoup(driver.page_source, 'lxml')
        h1=soup.find_all('td',{'class':'tdcolumn ng-binding'})
        #    print h1
        data=[]
        
        for i in h1:
            data.append(i.getText())
        
    
        data = data[57:61] + [symbol]
        
        print data
        print "normal output",data
        if os.path.exists(output_dir+"bse_file_fe2{}.txt".format(d.date())):
            file1 = open(output_dir+"be_file_fe2{}.txt".format(d.date()),"a") 
            l1=str(symbol) + "," + str(data[0]) + "," + str(data[1]) + "," + str(data[2]) + "," + str(data[3])
            file1.writelines(l1)
            file1.writelines("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))
            file1.writelines("\n")
            file1.close()
        else:
            file1 = open(output_dir+"bse_file_fe2{}.txt".format(d.date()),"w") 
            l1=str(symbol) + "," + str(data[0]) + "," + str(data[1]) + "," + str(data[2]) + "," + str(data[3])
            file1.writelines(l1)
            file1.writelines("https://www.bseindia.com/stock-share-price/{}/{}/{}/".format(stock,symbol,code))
            file1.writelines("\n")
            file1.close()
        driver.quit()
    except Exception as e:
        data=''
        print 'Exception : {}'.format(e)
        driver.quit()
        
    return data


def get_data_symbols(d,dt):
    
    print "hour",d.strftime('%H')
    date_d=d.strftime('%H:%M:%S')
    print dt
    print date_d
    while date_d < dt:
        
        if d.time()>=datetime.time(d.time().hour,10):
            pass
        else:
            d=d-datetime.timedelta(minutes=30)
        
        r_df=pd.read_msgpack(r.get('bse_sec_realtime_data_2'))
        #r_df = r_df[r_df['symbol'].isin(list(r_df['symbol'].unique())[:5]) ]
        r_df=r_df.applymap(str)
        hourly_df=r_df.loc[r_df["symbol_key"].str.endswith('{}'.format(d.strftime('%H')))] # curr hour data
        hourly_df.reset_index(drop=True,inplace=True)
        check=hourly_df["DQ"].isin(['-']).any().any()
        print "check",check
        if check==True:
            n_df=hourly_df.loc[hourly_df["DQ"]=='-']
            print "Getting data for {} symbols".format(len(n_df))
            n_df.sort_values(by='symbol', inplace=True)
            for col,row in n_df.iterrows():
                df=[]                    
                temp = get_bse_secwise_real_time(row["stock"], row['symbol'], row['code'], d)
                
                if temp!='':
                    df.append(temp)
                    df=pd.DataFrame(df,columns=list1)
                    final_df=pd.concat([df])
                    final_df.columns=list1
                    final_df.reset_index(drop=True,inplace=True)
                    row["date"] = final_df['date'][0]
                    row["QT"] = final_df['QT'][0]
                    row["DQ"] = final_df['DQ'][0]
                    row["%DQ"] = final_df['%DQ'][0]
                else:
                    print "output error; fetch in next iteration"
            
    
            r_df = pd.concat([n_df,r_df[~r_df['symbol_key'].isin(n_df['symbol_key'].values)]], axis=0)
           
            
            
            r_df.sort_values(by='symbol_key', inplace=True)
            r.set('bse_sec_realtime_data_2',r_df.to_msgpack(compress='zlib'))
            logging.info("data stored in redis success")

        else:
            print "Data scraped for all symbols; Sleep for 30 sec"
            time.sleep(30)
        
            
            
        d = datetime.datetime.now()
        print "hour",d.strftime('%H')
        date_d=d.strftime('%H:%M:%S')
        print dt
        print date_d    
    
    
    


def main():
   
    d=datetime.datetime.now()  
    dt='17:00:00'    
    get_data_symbols(d,dt)  # keep updating data till market close
    
          
    
    
main()