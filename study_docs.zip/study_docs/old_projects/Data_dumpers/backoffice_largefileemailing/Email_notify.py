import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import datetime
import time
import logging
import pandas as pd 
import os

server = '172.17.9.144'; port = 25


contacts_dir = "D:\\Data_dumpers\\backoffice_largefileemailing\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'



def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def email_alert(subj_string, body_string):
    '''Func to send daily emails after the data is dumped'''
    
    # fetch contacts from the file 
    emails = get_contacts(contacts_dir+'contacts.txt') # read contacts
    
    subject = "{}".format(subj_string)       
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()       # create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    msg.attach(MIMEText('{}'.format(body_string),'plain'))        
            
    # send the message via the server set up earlier.
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    del msg       
    # Terminate the SMTP session and close the connection
    s.quit()





def main():
    
    # loop through all the folders and send emails 
    while True:
        
        file_list = []
        for r, _, f in os.walk(r"\\172.17.9.22\Users2\secmkt\KSINSTBO\TODAY_STP\Large_STP_file"):
            # traverse through all folders
            for file_name in f:  
                file_list.append( os.path.abspath(os.path.join(r, file_name)) )
                
        mail_body = []
        print len(file_list)
        if len(file_list)!=0:
            print "Files are created in this dir ; sending an email alert"
            
            for f in file_list:
                fdetails = os.stat(f)
                mail_body.append([ f.split("Large_STP_file")[-1], str(int(fdetails.st_size)) + "Kb", time.strftime('%Y-%m-%d %H:%M:%S', 
                                  time.localtime(fdetails.st_mtime))])
                
            mail_body = pd.DataFrame(mail_body)
            
            mail_body['text'] = mail_body[0].astype(str) +'\t\t\t'+ mail_body[1].astype(str)+'\t\t' + mail_body[2].astype(str) 
            main_body = "Large file Email Notification ! \n\n\n Filename\t\t\tFile Size\t\t\tFile modification time\n\n"+ '\n'.join(mail_body['text'])
                
            email_alert('Backoffice: Large file alert', main_body)
            print "Sleep for 3 min"
            time.sleep(60*3)
        else:
            print "No files present in dir "
            time.sleep(5)
            break
            
        
       

if __name__ == '__main__':
    main()

