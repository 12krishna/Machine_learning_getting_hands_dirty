# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 11:33:11 2022

@author: backup
"""
from selenium.webdriver import ActionChains 
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import OleFileIO_PL
import xlrd
import logging
import sys
# import requests
from selenium import webdriver
import openpyxl
import requests
import re, os, datefinder, datetime, time
from bs4 import BeautifulSoup
from selenium import webdriver
import datetime
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import openpyxl
import requests
import os
import pandas as pd
output_dir="D:\\Data_dumpers\\Amfi"
master_dir = "D:\\Data_dumpers\\Master\\"

download_dir="C:\\Users\\backup\\Downloads"


driver = webdriver.Chrome('D:\\Data_dumpers\\Master\\chromedriver')#,options=chrome_options)
time.sleep(1)
driver.set_page_load_timeout(30)
care_rating_url ="https://www.amfiindia.com/ter-of-mf-schemes"
#care_rating_url = "https://www.valueresearchonline.com/amfi/fund-performance"
driver.get(care_rating_url)
#time.sleep(1.5)
#driver.maximize_window()
time.sleep(5)
#driver.close()
month=driver.find_elements_by_xpath("//span[@class='ui-button-text']")[1]
time.sleep(2)
month.click()
driver.find_element_by_link_text("June-2022").click()
time.sleep(2)
types=driver.find_elements_by_xpath("//span[@class='ui-button-text']")[2]
time.sleep(2)
types.click()
driver.find_element_by_link_text("Open Ended").click()    
time.sleep(2)
scheme_cate=driver.find_elements_by_xpath("//span[@class='ui-button-text']")[3]
time.sleep(2)
scheme_cate.click()
driver.find_element_by_link_text("Equity Scheme").click()    
time.sleep(2)
sub_cate=driver.find_elements_by_xpath("//span[@class='ui-button-text']")[4]
time.sleep(2)
sub_cate.click()
time.sleep(2)
pg = driver.page_source
soup = BeautifulSoup(pg,'lxml')
subcat=soup.find("ul",id="ui-id-6").find_all("li")
print(subcat)
for sub in subcat[1:]:
    df1=df2=df3=df4=df5=df6=df7=df8=df9=df10=pd.DataFrame()#(columns=["Scheme Name"])
    t=sub.find("a").text
    print(t)
    month_cat=soup.find("ul",id="ui-id-2").find_all("li")
    for m in month_cat[1]:
#        month=driver.find_elements_by_xpath("//span[@class='ui-button-text']")[1]
#        time.sleep(2)
#        month.click()
#        mt=m.find("a").text
#        print(mt)
#        driver.find_element_by_link_text(mt).click()
#        time.sleep(2)
        mt="June-2022"
        time.sleep(2)
        sub_cate=driver.find_elements_by_xpath("//span[@class='ui-button-text']")[4]
        time.sleep(2)
        sub_cate.click()
        time.sleep(5)
        driver.find_element_by_partial_link_text(t).click()
        #driver.find_element_by_partial_link_text("Dynamic Asset").click()
        time.sleep(2)     
        mf=driver.find_elements_by_xpath("//span[@class='ui-button-text']")[5]
        time.sleep(2)
        mf.click()
        time.sleep(2)
        driver.find_element_by_link_text("All").click()
        time.sleep(2)
        driver.find_element_by_xpath("//a[@id='hrfGo']").click()
        time.sleep(2)
        driver.find_element_by_xpath("//input[@class='serch-rgt']").click()
        time.sleep(2)
        amfi=pd.read_html(os.path.join(download_dir,"AMFI_Reports.xls"))
        x=amfi[0]
        os.remove(os.path.join(download_dir,"AMFI_Reports.xls"))
        base_ter=ab=ac=gst=total=base_ter_1=ab_1=ac_1=gst_1=total_1=x[[x.columns[0],x.columns[1]]]
        base_ter[mt]=x[x.columns[2]]
        df1=pd.concat([df1,base_ter],axis=1)
        ab[mt]=x[x.columns[3]]
        df2=pd.concat([df2,ab],axis=1)
       # ac["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        ac[mt]=x[x.columns[4]]
        df3=pd.concat([df3,ac],axis=1)
        #gst["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        gst[mt]=x[x.columns[5]]
        df4=pd.concat([df4,gst],axis=1)
        #total["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        total[mt]=x[x.columns[6]]
        df5=pd.concat([df5,total],axis=1)
        #base_ter_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        base_ter_1[mt]=x[x.columns[7]]
        df6=pd.concat([df6,base_ter_1],axis=1)
        #ab_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        ab_1[mt]=x[x.columns[8]]
        df7=pd.concat([df7,ab_1],axis=1)
        #ac_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        ac_1[mt]=x[x.columns[9]]
        df8=pd.concat([df8,ac_1],axis=1)
        #gst_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        gst_1[mt]=x[x.columns[10]]
        df9=pd.concat([df9,gst_1],axis=1)
        #total_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        total_1[mt]=x[x.columns[11]]
        df10=pd.concat([df10,total_1],axis=1)
      

    print("______________")    
    if "/" in t:
        t=t.replace("/","_")
    print("in")    
    writer=pd.ExcelWriter(os.path.join(output_dir,"{}.xlsx".format(t)),engine='xlsxwriter')    
    df1.to_excel(writer,sheet_name="BASE_TER",index=False) 
    df2.to_excel(writer,sheet_name='AB',index=False)
    df3.to_excel(writer,sheet_name='AC',index=False)
    df4.to_excel(writer,sheet_name='GST',index=False)
    df5.to_excel(writer,sheet_name='TOTAL',index=False)
    df6.to_excel(writer,sheet_name='BASE_TER_1',index=False)
    df7.to_excel(writer,sheet_name='AB_1',index=False)
    df8.to_excel(writer,sheet_name='AC_1',index=False)
    df9.to_excel(writer,sheet_name='GST_1',index=False)
    df10.to_excel(writer,sheet_name='TOTAL_1',index=False)
    writer.save()
    print("___")
driver.close()


'''

#base_ter["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        base_ter[mt]=x[x.columns[2]]
        df1=pd.concat([df1,base_ter])
        ab[mt]=x[x.columns[3]]
        df2=pd.concat([df2,ab])
       # ac["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        ac[mt]=x[x.columns[4]]
        df3=pd.concat([df3,ac])
        #gst["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        gst[mt]=x[x.columns[5]]
        df4=pd.concat([df4,gst])
        #total["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        total[mt]=x[x.columns[6]]
        df5=pd.concat([df1,total])
        #base_ter_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        base_ter_1[mt]=x[x.columns[7]]
        df6=pd.concat([df6,base_ter_1])
        #ab_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        ab_1[mt]=x[x.columns[8]]
        df7=pd.concat([df7,ab_1])
        #ac_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        ac_1[mt]=x[x.columns[9]]
        df8=pd.concat([df8,ac_1])
        #gst_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        gst_1[mt]=x[x.columns[10]]
        df9=pd.concat([df9,gst_1])
        #total_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        total_1[mt]=x[x.columns[11]]
        df10=pd.concat([df10,total_1])
  

ag=pd.read_html(os.path.join(download_dir,"AMFI_Reports.xls"))
g=ag[0]

base_ter["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        base_ter[mt]=x[x.columns[2]]
       # df1=pd.concat([df1,base_ter])
        df1=df1.merge(base_ter,on=x.columns[0],how='outer')
        ab["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        ab[mt]=x[x.columns[3]]
        df2=df2.merge(ab,on=x.columns[0],how='outer')
        ac["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        ac[mt]=x[x.columns[4]]
        df3=df3.merge(ac,on=x.columns[0],how='outer')
        gst["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        gst[mt]=x[x.columns[5]]
        df4=df4.merge(gst,on=x.columns[0],how='outer')
        total["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        total[mt]=x[x.columns[6]]
        df5=df5.merge(total,on=x.columns[0],how='outer')
        base_ter_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        base_ter_1[mt]=x[x.columns[7]]
        df6=df6.merge(base_ter_1,on=x.columns[0],how='outer')
        ab_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        ab_1[mt]=x[x.columns[8]]
        df7=df7.merge(ab_1,on=x.columns[0],how='outer')
        ac_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        ac_1[mt]=x[x.columns[9]]
        df8=df8.merge(ac_1,on=x.columns[0],how='outer')
        gst_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        gst_1[mt]=x[x.columns[10]]
        df9=df9.merge(gst_1,on=x.columns[0],how='outer')
        total_1["{}_dates".format(mt.split("-")[0])]=x[x.columns[1]]
        total_1[mt]=x[x.columns[11]]
        df10=df10.merge(total_1,on=x.columns[0],how='outer')
'''
month_cat[1].find("a").text

