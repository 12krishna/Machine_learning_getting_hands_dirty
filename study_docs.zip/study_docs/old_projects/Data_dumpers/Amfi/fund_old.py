# -*- coding: utf-8 -*-
"""
Created on Fri Jun  3 10:37:43 2022

@author: backup
"""
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import OleFileIO_PL
import xlrd
import logging
import sys
# import requests
from selenium import webdriver
import openpyxl
import requests
import re, os, datefinder, datetime, time
from bs4 import BeautifulSoup
from selenium import webdriver
import datetime
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import openpyxl
import requests
import os
import pandas as pd
import shutil
server = '172.17.9.144'; port = 25

contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEResearchAlerts@kotak.com'
output_dir="D:\\Data_dumpers\\Amfi\\amfi data\\"
master_dir = "D:\\Data_dumpers\\Master\\"
data_dir='D:\\Data_dumpers\\Amfi'
download_dir="C:\\Users\\backup\\Downloads"

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 

#previous working date
def previous_working_day(d):
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d - datetime.timedelta(days=1)
            else:
                return d    




chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')

def other_data(nd1):
 # equity_cat=["Large Cap","Large & Mid Cap","Multi Cap","Mid Cap","Small Cap","Value","ELSS","Contra","Dividend Yield","Focused","Sectoral / Thematic","Flexi Cap"]
  other_cat=["Index Funds/ ETFs","FoFs (Overseas/Domestic)"]#,"Conservative Hybrid","Equity Savings","Arbitrage","Multi Asset Allocation","Dynamic Asset Allocation or Balanced Advantage"]
  #other_cat=["FoFs (Overseas/Domestic)"]#,"Conservative Hybrid","Equity Savings","Arbitrage","Multi Asset Allocation","Dynamic Asset Allocation or Balanced Advantage"]

  for i in other_cat:
    df1=df2=df3=df4=df5=df6=df7=df8=df9=df10=df11=df12=df13=df14=df15=df16=df17=df18=pd.DataFrame(columns=["Scheme Name","Benchmark"])  
    nd=0
#    date=datetime.datetime.now().date()-datetime.timedelta(days=nd)
#    #d1=previous_working_day(date)
#    d11=datetime.datetime.strftime(date,"%d-%b-%Y")
#    y =int(date.strftime("%Y"))
#    m = int(date.strftime("%m"))
#    d = int(date.strftime("%d"))
#    d1=datetime.date(y,m,d)
    while nd<nd1:       #d1>datetime.date(2022,6,1): #while nd<30  for last 30 days data
      try:
        driver = webdriver.Chrome('D:\\Data_dumpers\\Master\\chromedriver')#,options=chrome_options)
        time.sleep(1)
        driver.set_page_load_timeout(30)
        care_rating_url ="https://www.amfiindia.com/research-information/other-data/mf-scheme-performance-details"
        #care_rating_url = "https://www.valueresearchonline.com/amfi/fund-performance"
        driver.get(care_rating_url)
        time.sleep(1.5)
        driver.maximize_window()
        time.sleep(2)
        iframe = driver.find_element_by_tag_name("iframe")
        driver.switch_to.frame(iframe)
        time.sleep(2)
        category=driver.find_elements_by_tag_name("button")[1]
        category.send_keys(Keys.DOWN*5+Keys.RETURN)
        time.sleep(2)
        subcat=driver.find_elements_by_tag_name("button")[2]
        subcat.click()
        time.sleep(2)
        driver.find_element_by_link_text(i).click()
        time.sleep(2)
        d_element=driver.find_element_by_id("nav-date")
        print(d_element)
        time.sleep(2)
        #d_element.send_keys("25-Apr-2022")
        d_element.send_keys(Keys.CONTROL, "a")
        d_element.send_keys(Keys.BACKSPACE)
        date=datetime.datetime.now().date()-datetime.timedelta(days=nd)
        d1=previous_working_day(date)
        d11=datetime.datetime.strftime(d1,"%d-%b-%Y")
#        y =int(date.strftime("%Y"))
#        m = int(date.strftime("%m"))
#        d = int(date.strftime("%d"))
#        d1=datetime.date(y,m,d)
        d_element.send_keys(d11)
        time.sleep(5)
        search=driver.find_element_by_xpath("//button[@class='btn btn-primary amfi-btn']")
        print(search.text)
        search.click()
        time.sleep(5)
        download=driver.find_element_by_xpath("//a[@id='download-report-excel']")
        download.click()
        time.sleep(10)
        for r,d,f in os.walk(download_dir):
         for file in f:
          if file.startswith("fund-performance"):
             print(file)
             with open(os.path.join(download_dir,file),'rb') as f1:
                  ole = OleFileIO_PL.OleFileIO(f1)
                  if ole.exists('Workbook'):
                       d = ole.openstream('Workbook')
                       x=pd.read_excel(d,engine='xlrd',skiprows=5)
                       print(x.head(10))
                       print(x.shape)
             os.remove(os.path.join(download_dir,file))
          
        nav_r=nav_d=daily_a=return_1=return_1d=return_1b=return_3=return_3b=return_3d=return_5=return_5b=return_5d=return_10=return_10b=return_10d=return_s=return_sd=return_sb=x[[x.columns[0],x.columns[1]]]#,x.columns[5]]]
        nav_r[d11]=x[x.columns[5]]
        df1=df1.merge(nav_r,on=[x.columns[0],x.columns[1]],how='outer')
        nav_d[d11]=x[x.columns[6]]
        df2=df2.merge(nav_d,on=[x.columns[0],x.columns[1]],how='outer')
        daily_a[d11]=x[x.columns[22]]
        df3=df3.merge(daily_a,on=[x.columns[0],x.columns[1]],how='outer')
        return_1[d11]=x[x.columns[7]]
        df4=df4.merge(return_1,on=[x.columns[0],x.columns[1]],how='outer')
        return_1d[d11]=x[x.columns[8]]
        df5=df5.merge(return_1d,on=[x.columns[0],x.columns[1]],how='outer')
        return_1b[d11]=x[x.columns[9]]
        df6=df6.merge(return_1b,on=[x.columns[0],x.columns[1]],how='outer')
        return_3[d11]=x[x.columns[10]]
        df7=df7.merge(return_3,on=[x.columns[0],x.columns[1]],how='outer')
        return_3d[d11]=x[x.columns[11]]
        df8=df8.merge(return_3d,on=[x.columns[0],x.columns[1]],how='outer')
        return_3b[d11]=x[x.columns[12]]
        df9=df9.merge(return_3b,on=[x.columns[0],x.columns[1]],how='outer')
        return_5[d11]=x[x.columns[13]]
        df10=df10.merge(return_5,on=[x.columns[0],x.columns[1]],how='outer')
        return_5d[d11]=x[x.columns[14]]
        df11=df11.merge(return_5d,on=[x.columns[0],x.columns[1]],how='outer')
        return_5b[d11]=x[x.columns[15]]
        df12=df12.merge(return_5b,on=[x.columns[0],x.columns[1]],how='outer')
        return_10[d11]=x[x.columns[16]]
        df13=df13.merge(return_10,on=[x.columns[0],x.columns[1]],how='outer')
        return_10d[d11]=x[x.columns[17]]
        df14=df14.merge(return_10d,on=[x.columns[0],x.columns[1]],how='outer')
        return_10b[d11]=x[x.columns[18]]
        df15=df15.merge(return_10b,on=[x.columns[0],x.columns[1]],how='outer')     
        return_s[d11]=x[x.columns[19]]
        df16=df16.merge(return_s,on=[x.columns[0],x.columns[1]],how='outer')
        return_sd[d11]=x[x.columns[20]]
        df17=df17.merge(return_sd,on=[x.columns[0],x.columns[1]],how='outer')  
        return_sb[d11]=x[x.columns[21]]
        df18=df18.merge(return_sb,on=[x.columns[0],x.columns[1]],how='outer')
        nd=nd+1
        driver.close()
      except Exception as e:
            print(e)
            nd=nd+1
            driver.close() 
    #To delete duplicate columns from all the dataframe 
    dfs=[df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,df15,df16,df17,df18]
    for j in dfs:
        j=j.T.drop_duplicates().T
        j=j[list(j.columns[:2]) + list(j.columns[:1:-1])]

    if "/" in i:
        i=i.replace("/","_")
    writer=pd.ExcelWriter(os.path.join(output_dir,"{}.xlsx".format(i)),engine='xlsxwriter')    
    df1.to_excel(writer,sheet_name="Nav_Regular",index=False) 
    df2.to_excel(writer,sheet_name='Nav_Direct',index=False)
    df3.to_excel(writer,sheet_name='Daily AUM',index=False)
    df4.to_excel(writer,sheet_name='Return 1Y Regular',index=False)
    df5.to_excel(writer,sheet_name='Return 1Y Direct',index=False)
    df6.to_excel(writer,sheet_name='Return 1Y Benchmark',index=False)
    df7.to_excel(writer,sheet_name='Return 3Y Regular',index=False)
    df8.to_excel(writer,sheet_name='Return 3Y Direct',index=False)
    df9.to_excel(writer,sheet_name='Return 3Y Benchmark',index=False)
    df10.to_excel(writer,sheet_name='Return 5Y Regular',index=False)
    df11.to_excel(writer,sheet_name='Return 5Y Direct',index=False)
    df12.to_excel(writer,sheet_name='Return 5Y Benchmark',index=False)
    df13.to_excel(writer,sheet_name='Return 10Y Regular',index=False)
    df14.to_excel(writer,sheet_name='Return 10Y Direct',index=False)
    df15.to_excel(writer,sheet_name='Return 10Y Benchmark',index=False)
    df16.to_excel(writer,sheet_name='Return SI Regular',index=False)
    df17.to_excel(writer,sheet_name='Return SI Direct',index=False)
    df18.to_excel(writer,sheet_name='Return SI Benchmark',index=False)
    writer.save()


def hybrid_data(nd1):
 # equity_cat=["Large Cap","Large & Mid Cap","Multi Cap","Mid Cap","Small Cap","Value","ELSS","Contra","Dividend Yield","Focused","Sectoral / Thematic","Flexi Cap"]
  hybrid_cat=["Aggressive Hybrid","Balanced Hybrid","Conservative Hybrid","Equity Savings","Arbitrage","Multi Asset Allocation","Dynamic Asset Allocation or Balanced Advantage"]
  
  for i in hybrid_cat:
    df1=df2=df3=df4=df5=df6=df7=df8=df9=df10=df11=df12=df13=df14=df15=df16=df17=df18=pd.DataFrame(columns=["Scheme Name","Benchmark"])  
    nd=0
#    date=datetime.datetime.now().date()-datetime.timedelta(days=nd)
    #d1=previous_working_day(date)
#    d11=datetime.datetime.strftime(date,"%d-%b-%Y")
#    y =int(date.strftime("%Y"))
#    m = int(date.strftime("%m"))
#    d = int(date.strftime("%d"))
#    d1=datetime.date(y,m,d)
    while nd<nd1: #d1>datetime.date(2022,6,1):
      try:
        driver = webdriver.Chrome('D:\\Data_dumpers\\Master\\chromedriver')#,options=chrome_options)
        time.sleep(1)
        driver.set_page_load_timeout(30)
        care_rating_url ="https://www.amfiindia.com/research-information/other-data/mf-scheme-performance-details"
        #care_rating_url = "https://www.valueresearchonline.com/amfi/fund-performance"
        driver.get(care_rating_url)
        time.sleep(1.5)
        driver.maximize_window()
        time.sleep(2)
        iframe = driver.find_element_by_tag_name("iframe")
        driver.switch_to.frame(iframe)
        time.sleep(2)
        category=driver.find_elements_by_tag_name("button")[1]
        category.send_keys(Keys.DOWN*3+Keys.RETURN)
        time.sleep(2)
        subcat=driver.find_elements_by_tag_name("button")[2]
        subcat.click()
        time.sleep(2)
        driver.find_element_by_link_text(i).click()
        time.sleep(2)
        d_element=driver.find_element_by_id("nav-date")
        print(d_element)
        time.sleep(2)
#        #d_element.send_keys("25-Apr-2022")
        d_element.send_keys(Keys.CONTROL, "a")
        d_element.send_keys(Keys.BACKSPACE)
        date=datetime.datetime.now().date()-datetime.timedelta(days=nd)
        d1=previous_working_day(date)
        d11=datetime.datetime.strftime(d1,"%d-%b-%Y")
#        y =int(date.strftime("%Y"))
#        m = int(date.strftime("%m"))
#        d = int(date.strftime("%d"))
#        d1=datetime.date(y,m,d)
        d_element.send_keys(d11)
        time.sleep(5)
        search=driver.find_element_by_xpath("//button[@class='btn btn-primary amfi-btn']")
        print(search.text)
        search.click()
        time.sleep(5)
        download=driver.find_element_by_xpath("//a[@id='download-report-excel']")
        download.click()
        time.sleep(10)
        for r,d,f in os.walk(download_dir):
         for file in f:
          if file.startswith("fund-performance"):
             print(file)
             with open(os.path.join(download_dir,file),'rb') as f1:
                  ole = OleFileIO_PL.OleFileIO(f1)
                  if ole.exists('Workbook'):
                       d = ole.openstream('Workbook')
                       x=pd.read_excel(d,engine='xlrd',skiprows=5)
                       print(x.head(10))
                       print(x.shape)
             os.remove(os.path.join(download_dir,file))
          
        nav_r=nav_d=daily_a=return_1=return_1d=return_1b=return_3=return_3b=return_3d=return_5=return_5b=return_5d=return_10=return_10b=return_10d=return_s=return_sd=return_sb=x[[x.columns[0],x.columns[1]]]#,x.columns[5]]]
        nav_r[d11]=x[x.columns[5]]
        df1=df1.merge(nav_r,on=[x.columns[0],x.columns[1]],how='outer')
        nav_d[d11]=x[x.columns[6]]
        df2=df2.merge(nav_d,on=[x.columns[0],x.columns[1]],how='outer')
        daily_a[d11]=x[x.columns[22]]
        df3=df3.merge(daily_a,on=[x.columns[0],x.columns[1]],how='outer')
        return_1[d11]=x[x.columns[7]]
        df4=df4.merge(return_1,on=[x.columns[0],x.columns[1]],how='outer')
        return_1d[d11]=x[x.columns[8]]
        df5=df5.merge(return_1d,on=[x.columns[0],x.columns[1]],how='outer')
        return_1b[d11]=x[x.columns[9]]
        df6=df6.merge(return_1b,on=[x.columns[0],x.columns[1]],how='outer')
        return_3[d11]=x[x.columns[10]]
        df7=df7.merge(return_3,on=[x.columns[0],x.columns[1]],how='outer')
        return_3d[d11]=x[x.columns[11]]
        df8=df8.merge(return_3d,on=[x.columns[0],x.columns[1]],how='outer')
        return_3b[d11]=x[x.columns[12]]
        df9=df9.merge(return_3b,on=[x.columns[0],x.columns[1]],how='outer')
        return_5[d11]=x[x.columns[13]]
        df10=df10.merge(return_5,on=[x.columns[0],x.columns[1]],how='outer')
        return_5d[d11]=x[x.columns[14]]
        df11=df11.merge(return_5d,on=[x.columns[0],x.columns[1]],how='outer')
        return_5b[d11]=x[x.columns[15]]
        df12=df12.merge(return_5b,on=[x.columns[0],x.columns[1]],how='outer')
        return_10[d11]=x[x.columns[16]]
        df13=df13.merge(return_10,on=[x.columns[0],x.columns[1]],how='outer')
        return_10d[d11]=x[x.columns[17]]
        df14=df14.merge(return_10d,on=[x.columns[0],x.columns[1]],how='outer')
        return_10b[d11]=x[x.columns[18]]
        df15=df15.merge(return_10b,on=[x.columns[0],x.columns[1]],how='outer')     
        return_s[d11]=x[x.columns[19]]
        df16=df16.merge(return_s,on=[x.columns[0],x.columns[1]],how='outer')
        return_sd[d11]=x[x.columns[20]]
        df17=df17.merge(return_sd,on=[x.columns[0],x.columns[1]],how='outer')  
        return_sb[d11]=x[x.columns[21]]
        df18=df18.merge(return_sb,on=[x.columns[0],x.columns[1]],how='outer')
        nd=nd+1
        driver.close()
      except Exception as e:
            print(e)
            nd=nd+1
            driver.close()
    #To delete duplicate columns from all the dataframe
    dfs=[df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,df15,df16,df17,df18]
    for j in dfs:
        j=j.T.drop_duplicates().T
        j=j[list(j.columns[:2]) + list(j.columns[:1:-1])]    
   
    
    writer=pd.ExcelWriter(os.path.join(output_dir,"{}.xlsx".format(i)),engine='xlsxwriter')    
    df1.to_excel(writer,sheet_name="Nav_Regular",index=False) 
    df2.to_excel(writer,sheet_name='Nav_Direct',index=False)
    df3.to_excel(writer,sheet_name='Daily AUM',index=False)
    df4.to_excel(writer,sheet_name='Return 1Y Regular',index=False)
    df5.to_excel(writer,sheet_name='Return 1Y Direct',index=False)
    df6.to_excel(writer,sheet_name='Return 1Y Benchmark',index=False)
    df7.to_excel(writer,sheet_name='Return 3Y Regular',index=False)
    df8.to_excel(writer,sheet_name='Return 3Y Direct',index=False)
    df9.to_excel(writer,sheet_name='Return 3Y Benchmark',index=False)
    df10.to_excel(writer,sheet_name='Return 5Y Regular',index=False)
    df11.to_excel(writer,sheet_name='Return 5Y Direct',index=False)
    df12.to_excel(writer,sheet_name='Return 5Y Benchmark',index=False)
    df13.to_excel(writer,sheet_name='Return 10Y Regular',index=False)
    df14.to_excel(writer,sheet_name='Return 10Y Direct',index=False)
    df15.to_excel(writer,sheet_name='Return 10Y Benchmark',index=False)
    df16.to_excel(writer,sheet_name='Return SI Regular',index=False)
    df17.to_excel(writer,sheet_name='Return SI Direct',index=False)
    df18.to_excel(writer,sheet_name='Return SI Benchmark',index=False)
    writer.save()


def equity_data(nd1):
  equity_cat=["Large Cap","Large & Mid Cap","Multi Cap","Mid Cap","Small Cap","Value","ELSS","Contra","Dividend Yield","Focused","Sectoral / Thematic","Flexi Cap"]
  
  for i in equity_cat:
    df1=df2=df3=df4=df5=df6=df7=df8=df9=df10=df11=df12=df13=df14=df15=df16=df17=df18=pd.DataFrame(columns=["Scheme Name","Benchmark"])  
    nd=0
#    date=datetime.datetime.now().date()-datetime.timedelta(days=nd)
#    #d1=previous_working_day(date)
#    d11=datetime.datetime.strftime(date,"%d-%b-%Y")
#    y =int(date.strftime("%Y"))
#    m = int(date.strftime("%m"))
#    d = int(date.strftime("%d"))
#    d1=datetime.date(y,m,d)
    while nd<nd1:          # d1>datetime.date(2022,6,1):
      try:
        driver = webdriver.Chrome('D:\\Data_dumpers\\Master\\chromedriver')#,options=chrome_options)
        time.sleep(1)
        driver.set_page_load_timeout(30)
        care_rating_url ="https://www.amfiindia.com/research-information/other-data/mf-scheme-performance-details"
        #care_rating_url = "https://www.valueresearchonline.com/amfi/fund-performance"
        driver.get(care_rating_url)
        time.sleep(1.5)
        driver.maximize_window()
        time.sleep(2)
        iframe = driver.find_element_by_tag_name("iframe")
        driver.switch_to.frame(iframe)
        subcat=driver.find_elements_by_tag_name("button")[2]
        subcat.click()
        time.sleep(2)
        driver.find_element_by_link_text(i).click()
        time.sleep(2)
        d_element=driver.find_element_by_id("nav-date")
        print(d_element)
        time.sleep(2)
        #d_element.send_keys("25-Apr-2022")
        d_element.send_keys(Keys.CONTROL, "a")
        d_element.send_keys(Keys.BACKSPACE)
        date=datetime.datetime.now().date()-datetime.timedelta(days=nd)
        d1=previous_working_day(date)
        d11=datetime.datetime.strftime(d1,"%d-%b-%Y")
#        y =int(date.strftime("%Y"))
#        m = int(date.strftime("%m"))
#        d = int(date.strftime("%d"))
#        d1=datetime.date(y,m,d)
        d_element.send_keys(d11)
        time.sleep(5)
        search=driver.find_element_by_xpath("//button[@class='btn btn-primary amfi-btn']")
        print(search.text)
        search.click()
        time.sleep(5)
        download=driver.find_element_by_xpath("//a[@id='download-report-excel']")
        download.click()
        time.sleep(10)
        for r,d,f in os.walk(download_dir):
         for file in f:
          if file.startswith("fund-performance"):
             print(file)
             with open(os.path.join(download_dir,file),'rb') as f1:
                  ole = OleFileIO_PL.OleFileIO(f1)
                  if ole.exists('Workbook'):
                       d = ole.openstream('Workbook')
                       x=pd.read_excel(d,engine='xlrd',skiprows=5)
                       print(x.head(10))
                       print(x.shape)
             os.remove(os.path.join(download_dir,file))
          
        nav_r=nav_d=daily_a=return_1=return_1d=return_1b=return_3=return_3b=return_3d=return_5=return_5b=return_5d=return_10=return_10b=return_10d=return_s=return_sd=return_sb=x[[x.columns[0],x.columns[1]]]#,x.columns[5]]]
        nav_r[d11]=x[x.columns[5]]
        df1=df1.merge(nav_r,on=[x.columns[0],x.columns[1]],how='outer')
        nav_d[d11]=x[x.columns[6]]
        df2=df2.merge(nav_d,on=[x.columns[0],x.columns[1]],how='outer')
        daily_a[d11]=x[x.columns[22]]
        df3=df3.merge(daily_a,on=[x.columns[0],x.columns[1]],how='outer')
        return_1[d11]=x[x.columns[7]]
        df4=df4.merge(return_1,on=[x.columns[0],x.columns[1]],how='outer')
        return_1d[d11]=x[x.columns[8]]
        df5=df5.merge(return_1d,on=[x.columns[0],x.columns[1]],how='outer')
        return_1b[d11]=x[x.columns[9]]
        df6=df6.merge(return_1b,on=[x.columns[0],x.columns[1]],how='outer')
        return_3[d11]=x[x.columns[10]]
        df7=df7.merge(return_3,on=[x.columns[0],x.columns[1]],how='outer')
        return_3d[d11]=x[x.columns[11]]
        df8=df8.merge(return_3d,on=[x.columns[0],x.columns[1]],how='outer')
        return_3b[d11]=x[x.columns[12]]
        df9=df9.merge(return_3b,on=[x.columns[0],x.columns[1]],how='outer')
        return_5[d11]=x[x.columns[13]]
        df10=df10.merge(return_5,on=[x.columns[0],x.columns[1]],how='outer')
        return_5d[d11]=x[x.columns[14]]
        df11=df11.merge(return_5d,on=[x.columns[0],x.columns[1]],how='outer')
        return_5b[d11]=x[x.columns[15]]
        df12=df12.merge(return_5b,on=[x.columns[0],x.columns[1]],how='outer')
        return_10[d11]=x[x.columns[16]]
        df13=df13.merge(return_10,on=[x.columns[0],x.columns[1]],how='outer')
        return_10d[d11]=x[x.columns[17]]
        df14=df14.merge(return_10d,on=[x.columns[0],x.columns[1]],how='outer')
        return_10b[d11]=x[x.columns[18]]
        df15=df15.merge(return_10b,on=[x.columns[0],x.columns[1]],how='outer')     
        return_s[d11]=x[x.columns[19]]
        df16=df16.merge(return_s,on=[x.columns[0],x.columns[1]],how='outer')
        return_sd[d11]=x[x.columns[20]]
        df17=df17.merge(return_sd,on=[x.columns[0],x.columns[1]],how='outer')  
        return_sb[d11]=x[x.columns[21]]
        df18=df18.merge(return_sb,on=[x.columns[0],x.columns[1]],how='outer')
        nd=nd+1
        driver.close()
      except Exception as e:
            print(e) 
            nd=nd+1
            driver.close()
    #To delete duplicate columns from all the dataframe 
    dfs=[df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,df15,df16,df17,df18]
    for j in dfs:
        j=j.T.drop_duplicates().T
        j=j[list(j.columns[:2]) + list(j.columns[:1:-1])]
        
    if "/" in i:
        i=i.replace("/","_")
    writer=pd.ExcelWriter(os.path.join(output_dir,"{}.xlsx".format(i)),engine='xlsxwriter')    
    df1.to_excel(writer,sheet_name="Nav_Regular",index=False) 
    df2.to_excel(writer,sheet_name='Nav_Direct',index=False)
    df3.to_excel(writer,sheet_name='Daily AUM',index=False)
    df4.to_excel(writer,sheet_name='Return 1Y Regular',index=False)
    df5.to_excel(writer,sheet_name='Return 1Y Direct',index=False)
    df6.to_excel(writer,sheet_name='Return 1Y Benchmark',index=False)
    df7.to_excel(writer,sheet_name='Return 3Y Regular',index=False)
    df8.to_excel(writer,sheet_name='Return 3Y Direct',index=False)
    df9.to_excel(writer,sheet_name='Return 3Y Benchmark',index=False)
    df10.to_excel(writer,sheet_name='Return 5Y Regular',index=False)
    df11.to_excel(writer,sheet_name='Return 5Y Direct',index=False)
    df12.to_excel(writer,sheet_name='Return 5Y Benchmark',index=False)
    df13.to_excel(writer,sheet_name='Return 10Y Regular',index=False)
    df14.to_excel(writer,sheet_name='Return 10Y Direct',index=False)
    df15.to_excel(writer,sheet_name='Return 10Y Benchmark',index=False)
    df16.to_excel(writer,sheet_name='Return SI Regular',index=False)
    df17.to_excel(writer,sheet_name='Return SI Direct',index=False)
    df18.to_excel(writer,sheet_name='Return SI Benchmark',index=False)
    writer.save()
def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def email_utility(emails, subject,fname):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
   # message = open(file_dir+body_file,'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    
    
    
   # attachment = open(data_dir+fname,'rb')
    print(fname)
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(os.path.join(data_dir,fname), "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
    msg.attach(part)   
    
                    
    
   # msg.attach(MIMEText(message,'plain'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()


 
def main(nd):    
   equity_data(nd) 
   hybrid_data(nd)
   other_data(nd)
    
   shutil.make_archive(os.path.join(data_dir,'all_amfi'), 'zip', output_dir)
   email_utility(get_contacts(contacts_dir+'amfi.txt'), 'AMFI Data','all_amfi.zip')  #amfi.txt
   
   
main(3)   
