# -*- coding: utf-8 -*-
"""
Created on Tue Sep 20 15:56:04 2022

@author: backup
"""



import requests 
import pandas as pd
import re
import os
from lxml import html
import time
import sys
from bs4 import BeautifulSoup
from selenium import webdriver
import shutil
import numpy as np
import datetime,logging
master_dir = "D:\\Data_dumpers\\Master\\"
file_path=r"\\172.17.9.22\Users2\ojas\OFS"
#file_path=r"\\172.17.9.22\Users\krishna\geeta\OFS"

input_file=pd.read_excel(os.path.join(file_path,"symbol.xlsx"))
s_dict=dict(zip(input_file["symbol"],input_file["series"]))

def ofs(symbol):
      """ function to scrape table for a particular symbol"""
      try:
        s=time.time()
        options = webdriver.ChromeOptions()
        
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        options.add_argument('--disable-blink-features=AutomationControlled')
        
        driver = webdriver.Chrome(master_dir+"chromedriver.exe", options=options)
        driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        #url="https://www.nseindia.com/market-data/ofs-information?symbol=BUTTERFLY&series=IS&type=Active"
        url='https://www.nseindia.com/market-data/ofs-information?symbol={}&series={}&type=Active'.format(symbol,s_dict[symbol])
        driver.get(url)
        driver.maximize_window()
        time.sleep(2)
        driver.find_element_by_link_text("General Category").click()
        time.sleep(5)
        driver.find_elements_by_xpath("//span[@class='fa fa-plus']")[1].click()
        time.sleep(5)
        pg=driver.page_source #driver.current_url
        soup = BeautifulSoup(pg,'lxml')
        table=soup.find_all('table',class_='common_table noflex tableScroll customHeight-table w-100')
        print(table)
        df = pd.read_html(str(table))[0]  
        l=list(df.columns.levels[1])
        df.columns=[l[2],l[1],l[0],l[4],l[3],l[0],l[4],l[3]]
        df.to_csv(os.path.join(file_path,"ofs_{}.txt".format(symbol)),index=False)  # SAVE AS ofs_symbol.txt if more than one symbol  data is required
        driver.close()
        e=time.time()
        print("time required is ",e-s)
      except Exception as e:
          print(e)
          driver.close()
        
        
def main():
#    input_file=pd.read_excel(os.path.join(file_path,"symbol.xlsx"))
#    s_dict=dict(zip(input_file["symbol"],input_file["series"])) # if series is also required use dictionary instead of list
    dt="15:31:00"
    #dt="18:26:00"
    d=datetime.datetime.now()
    while d.strftime("%H:%M:%S")<dt:
        for i in s_dict:
           ofs(i)
           time.sleep(10)
           print("done")
        d=datetime.datetime.now()
main()       
       











