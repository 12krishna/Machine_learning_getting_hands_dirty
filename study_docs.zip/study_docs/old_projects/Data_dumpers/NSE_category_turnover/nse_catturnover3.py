import pandas as pd 
import numpy as np
import requests,re,os,datetime,time,logging,redis
#from urllib.request import urlopen
from cassandra.cluster import Cluster
from dateutil.parser import parse

os.chdir("D:\\Data_dumpers\\NSE_category_turnover\\")


cassandra_host = "172.17.9.51"
redis_host = 'localhost'
master_dir = "D:\\Data_dumpers\\Master\\"
processed_dir = "D:\\Data_dumpers\\NSE_category_turnover\\processed_dir\\"
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'}


#server = '172.17.9.149'; port = 25
#cassandra_host = "localhost"

logging.basicConfig(filename='test.log',
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


#previous working date
def previous_working_day(d):
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d - datetime.timedelta(days=1)   
            else:
                return d


#cluster = Cluster([cassandra_host])
cluster = cassandra_configs_cluster()
logging.info('Cassandra Cluster connected...')
# connect to your keyspace and create a session using which u can execute cql commands 
session = cluster.connect('rohit')
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None    



def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
        
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print ("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1
    
def cat_turnover(d):
    
    #d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    if process_run_check(d)== -1:
        return -1
    
    #d=datetime.datetime.strftime(d,'%d%m%y')
    
    while True:
        
        print ('https://archives.nseindia.com/archives/equities/cat/cat_turnover_{}.xls'.format(datetime.datetime.strftime(d,'%d%m%y')))
        try:
            filedata = requests.get('https://archives.nseindia.com/archives/equities/cat/cat_turnover_{}.xls'.format(
                datetime.datetime.strftime(d,'%d%m%y')), headers=headers)  
        except Exception as e:
            print (e)
            if datetime.datetime.now().time()>=datetime.time(17,30):
                print ("Sleep for 2 minutes")            
                time.sleep(1)
                continue
            else:
                break
            
        
        if filedata.status_code==200:
            print ("success")
            # write file to xlsx
            output=open("test.xls","wb")
            output.write(filedata.content)
            output.close()  
            # read and process           
            
            df=pd.read_excel("test.xls")      
            
            df=df[1:6]
            df.columns=["tradingdate","category","BuyValueinRs","SellValueinRs"]
            df.reset_index(drop=True,inplace=True)
            df=df[1:]
            df.dropna(inplace=True)
            df['tradingdate'] = pd.to_datetime(df['tradingdate'])
            df['tradingdate'] = df['tradingdate'].dt.date
            df.dropna(inplace=True)
            df.to_csv("catturnover.csv",index=False)
            df.to_csv(processed_dir+"catturnover_{}.csv".format(d),index=False)
            
            session.execute("CREATE TABLE IF NOT EXISTS nse_category_turnover(tradingdate DATE,category VARCHAR,BuyValueinRs FLOAT,SellValueinRs FLOAT,PRIMARY KEY(tradingdate,category))")
            os.system('nse_catturnover3.bat')

          
            r = redis.Redis(host=redis_host, port=6379) 
            r.set('nse_catturnover_flag',1)
        
            checker = session.execute("select * from nse_category_turnover where tradingdate >= \'{}\' allow filtering;".format(
                    datetime.datetime.now().date()- datetime.timedelta(days=10)))
            checker = checker._current_rows
            
            
            
            r.set("nse_catturnover_remarks",'Data dumped in nse_category_turnover table for {}'.format(
                    checker.sort_values("tradingdate").tail(1)['tradingdate'].values[0]))
            break
        
     


d = datetime.datetime.now().date()- datetime.timedelta(days=1)   # set date here; data is avialable for T-1 always

for i in range(365):        
    if os.path.exists(processed_dir+"catturnover_{}.csv".format(d)):
        print ("file exists")
        break
    else:
        print ("file not present")
        cat_turnover(d)    

        
    d = previous_working_day(d)