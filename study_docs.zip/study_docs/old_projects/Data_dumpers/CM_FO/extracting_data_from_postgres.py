# -*- coding: utf-8 -*-
"""
Created on Fri May 13 15:01:06 2022

@author: backup
"""
'''
from sqlalchemy import create_engine

engine = create_engine('postgresql://postgres:Kotak@123@172.17.9.51:5432/postgres')
'''

import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import datetime,psycopg2,logging,calendar, shutil, time
import warnings
warnings.filterwarnings("ignore")


def get_data(): 
  conn = psycopg2.connect(database="postgres",
                                user="postgres",
                                 password="Kotak@123", 
                                 host="172.17.9.51", 
                                 port="5432")
  df = pd.read_sql("select * from order_trade_data;",conn)
  return df

x=get_data()
y=x[x["Segment"]=="FO"]
x.to_excel("D:\Data_dumpers\CM_FO\credit ratings\all_data.xls")
y.to_excel("D:\Data_dumpers\CM_FO\credit ratings\FNO.xls")




'''
def get_postgress_data(d,d1):
    #get latest date from database
    df = pd.DataFrame()
    while True:        
        conn = psycopg2.connect(database="NSE-FNO",
                                user="postgres",
                                 password="kotak@123", 
                                 host="172.17.9.182", 
                                 port="5432")
        df = pd.read_sql("select * from tablename;") #d current date ,d1 previous date
        if len(df)!=0:
            break
        print "Data not present for {} in tca split postgres db; sleep for 30 sec".format(d)
        time.sleep(30)
        
    return df

df = get_postgress_data('2020-01-01','2022-01-12')
'''





