# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 12:24:10 2022

@author: backup
"""
import datetime
import time
import logging
import numpy as np
from cassandra.cluster import Cluster
import pandas as pd
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

contacts_dir = "D:\\Data_dumpers\\CM_FO\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
trade_data=r'\\172.17.9.141\Backup\NOTIS_API_TradeFile'
log_path='D:\\Data_dumpers\\CM_FO\\' 
master_dir = "D:\\Data_dumpers\\Master\\"
server = '172.17.9.144'; port = 25

from sqlalchemy import create_engine

engine = create_engine('postgresql://postgres:Kotak@123@172.17.9.51:5432/postgres')

logging.basicConfig(filename=log_path+"fo.log",filemode="w",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def cassandra_configs_cluster():
        f = open("D:\\Data_dumpers\\Master\\config.txt",'r').readlines()
        f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]

        from cassandra.auth import PlainTextAuthProvider

        auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
        cluster = Cluster([f[0]], auth_provider=auth_provider)

        return cluster

def checking_date(d1):
    try:
       logging.info("checking the availability of today's data")  
       cluster = cassandra_configs_cluster()
       session = cluster.connect('rohit')
       def pandas_factory(colnames, rows):
          return pd.DataFrame(rows, columns=colnames)
       query= "ALTER TABLE rohit.folog WITH GC_GRACE_SECONDS = 0 ;"
       rslt = session.execute(query,timeout=None)
       session.row_factory = pandas_factory
       session.default_fetch_size = 9995840
       query = "select distinct branch_id, user_id, date from folog where date='{}' allow filtering".format(d1)
       rslt = session.execute(query, timeout = None)
       df = rslt._current_rows
       df = df['date'].sort_values(ascending = False)
       df.to_csv('D:\\Data_dumpers\\CM_FO\\FODatesnew.csv', index = False)
       if df.empty:
         logging.info("empty dataframe")
         print("empty dataframe")
         return -1
       else:  
          dti = pd.read_csv('D:\\Data_dumpers\\CM_FO\\FODatesnew.csv', header = None)
          print 'FO dates updated'
          logging.info("FO dates updated")
          j= dti[dti.columns[0]].values[0]      
          print(j)
          return j 
       cluster.shutdown() 
    except Exception as e:
        logging.info("error-{} ".format(e))  
       

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

rng = pd.date_range('09:00:00.000','15:30:00.000',freq='1s')
rng = pd.Series(rng.format())
rng = rng + '.000000000'
IDs = pd.read_csv('D:\\Data_dumpers\\CM_FO\\FO_ID.csv')
#dti = pd.read_excel('C:\\Users\\backup\\Geeta\\New folder\\geeta\\FODatesnew.xlsx', header = None)
#dti=pd.to_datetime(dti[0]).dt.date
#dti = dti[dti.columns[0]]
#dti = dti[0:1]

cluster = Cluster(['172.17.9.51'],port = 9042)
session = cluster.connect('rohit')
i = 0
def plotorders(item1,j) :
   # global dti
   # for j in dti :
       # branch_id = IDs['branch_id'][IDs['user_id'] == item1].item()
        print 'writing file with user_id : %s' %(item1)

        session.row_factory = pandas_factory
        session.default_fetch_size = 10000000
        query= "ALTER TABLE rohit.folog WITH GC_GRACE_SECONDS = 0 ;"
        rslt = session.execute(query,timeout=None)
        query = "select user_id, date, time, activity_type from folog where user_id={} and date='{}' and time <= '13:30:00.000000000' allow filtering".format(item1,j)
        rslt = session.execute(query,timeout=None)
        df = rslt._current_rows
        query = "select user_id, date, time, activity_type from folog where user_id={} and date='{}' and time >= '13:30:00.000000000' and time <= '15:30:00.000000000' allow filtering".format(item1,j)
        rslt = session.execute(query,timeout=None)
        df = df.append(rslt._current_rows)
        query = "select user_id, date, time, activity_type from spreadlog where user_id={} and date='{}' and time <= '15:30:00.000000000' allow filtering".format(item1,j)
        rslt = session.execute(query,timeout=None)
        df11 = rslt._current_rows

        if df.empty == False :
            d = df.groupby(['time', 'activity_type'])['activity_type'].size().reset_index(name = 'freq')
            p = len(df[df['activity_type'] == 'ONEW'])
            q = len(df[df['activity_type'] == 'OMOD'])
            r = len(df[df['activity_type'] == 'OCXL'])
            s = len (df)
            d1 = d.groupby('time')['freq'].sum().reset_index(name = 'orders')
            d1['time'] = pd.to_datetime(d1['time'], format='%H:%M:%S.%f').dt.time
            f = pd.DataFrame({'time' : rng.str[11:]})
            f['time'] = pd.to_datetime(f['time'], format='%H:%M:%S.%f').dt.time

            df1 = pd.merge(d1,f,on = 'time', how = 'outer')
            df1 = df1.fillna(0)
            df1.sort_values('time', inplace = True)

            if df11.empty == False :
                d11 = df11.groupby(['time', 'activity_type'])['activity_type'].size().reset_index(name = 'freq')
                d12 = d11.groupby('time')['freq'].sum().reset_index(name = 'orders')
                d12['time'] = pd.to_datetime(d12['time'], format='%H:%M:%S.%f').dt.time

                df12 = pd.merge(d12,f,on = 'time', how = 'outer')
                df12 = df12.fillna(0)
                df12.sort_values('time', inplace = True)

                df1['orders'] = df1['orders'] + df12['orders']

           # count = df1['orders'][df1['orders'] >= IDs['capacity'][IDs['user_id'] == item1].item()].count()

            mode = df1['orders'][df1['orders'] > 0].mode().empty
            if mode == True :
                m = 0
            else :
                m = df1['orders'][df1['orders'] > 0].mode()[0]

            global IDs
            df5 = pd.read_csv(os.path.join(trade_data,"nsefo_bkcapi_{}.txt".format(j)), usecols=[1,11], names=['colA', 'colB'], header=None)
            temp = df5[(df5['colB']==int(item1)) & (df5['colA']==11)]            
            t = len(temp)
	        if t > 0:
              ratio = float(s) /  float(len(temp))
              print int(s)
	        else :
	           ratio = 0
            r=float(ratio) 
            
            df2 = pd.DataFrame({'UserID' : str(item1),'Date' : str(j), 'Segment': 'FO', 'Identifier' : np.nan, 'Capacity' : np.nan,'Shared': np.nan, 'TAP_IP' : np.nan, 'Total_Fills' : t , 'MaxOrderperSec' : int(df1['orders'].max()), 'AvgOrderperSec': str(df1['orders'][df1['orders'] > 0].mean())[:6], 'MedianOrderperSec': str(df1['orders'][df1['orders'] > 0].median())[:6], 'ModeOrderperSec': int(m), 'Count' : np.nan, 'ONEW' : str(p), 'OMOD' : str(q), 'OCXL' : str(r), 'TotalOrders' : str(s), 'P_L_ratio' : r},index=[0])

            df2 = df2[['Date', 'Identifier', 'Segment', 'UserID', 'AvgOrderperSec', 'Capacity', 'Count', 'MaxOrderperSec', 'MedianOrderperSec', 'ModeOrderperSec', 'Shared', 'TAP_IP', 'Total_Fills', 'ONEW', 'OMOD', 'OCXL', 'TotalOrders', 'P_L_ratio' ]]

            if i == 0 :
                df2.to_csv('D:\\Data_dumpers\\CM_FO\\python2FO.csv',index = False)
            else :
                df2.to_csv('D:\\Data_dumpers\\CM_FO\\python2FO.csv', mode = 'a', index = False, header = False)
            df2.to_sql('order_trade_data', engine,if_exists='append',index=False)
            print("data dumped")
            global i
            i += 1

            print 'done'
 
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


#"https://archives.nseindia.com/content/FO_Latency_stats25102021.csv"
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''

    if len(holiday_master[holiday_master['date']==d])==0:
        return 1

    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1
 
def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails
               
def combine_html_excel(emails,subject):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
#    message = open("output.txt",'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    msg.attach(MIMEText('FO data has been dumped','plain'))    
    # add all attachments 

#    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

          
def main(nd): 
   d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
   if process_run_check(d)== -1:
        return -1 
   d1=datetime.datetime.strftime(d,"%Y-%m-%d")
   while 1:
       k=checking_date(d1)
       print(k)
       if k==d1:      
          [plotorders(item1,k) for item1 in IDs['user_id']]
          break
       else:
           print("checking for today's date")
           logging.info("checking for today's date")
           print("sleep for 3 minutes")
           time.sleep(180) 
   emails = get_contacts(contacts_dir+'CM_FO.txt') # read contacts backoffice_automation.txt
   subject = "FO data dumped"
        
   combine_html_excel(emails,subject)
           
   

main(0)

