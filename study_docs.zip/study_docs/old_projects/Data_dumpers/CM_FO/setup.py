from cx_Freeze import setup, Executable 


options = {'build_exe': {'packages': ['numpy'],
                         'include_files':['D:\Anaconda\Lib\site-packages\mkl_intel_thread.dll']
                         } }

setup(name = "UCC_database" , 
       version = "1.0" , 
       description = "" ,
       options = options,  
       executables = [Executable("UCC_dump_BSE.py")])