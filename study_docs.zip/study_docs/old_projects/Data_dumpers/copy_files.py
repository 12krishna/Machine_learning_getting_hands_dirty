# -*- coding: utf-8 -*-
"""
@author: krishnay
"""

# UAT tradre inquiry
import datetime, shutil
import sys
import time, os

import smtplib
#from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
#from email.mime.base import MIMEBase


server = '172.17.9.144'; port = 25
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'

input_dir = r"\\172.17.9.97\TradeFile"
output_dir = r"\\172.17.9.141\Backup\NOTIS_API_TradeFile"
contacts_dir = "D:\\Data_dumpers\\"
_file_list = ['nsecm_bkcapi.txt','nsefo_bkcapi.txt','bsecm.csv']


d=datetime.datetime.now().date()

# copy files
counter = 0
# check if size of file is 0
for _file in _file_list:
    try:
        
        if os.stat(os.path.join(input_dir, _file)).st_size == 0:
            print('File {} is empty'.format(_file))
        else:
            print('File {} is not empty\nMoving files.....'.format(_file))
            # move
            shutil.copy(os.path.join(input_dir, _file), os.path.join(output_dir,"{}_{}.{}".format(_file.split(".")[0], d, _file.split(".")[-1])))
            counter += 1
            
    except Exception as e:
        print "e"
        



def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def data_dumper_notification(flag_string, length_string):
    '''Func to send daily emails after the data is dumped'''
    
    # fetch contacts from the file 
    emails = get_contacts(contacts_dir+'contacts.txt') # read contacts
    
    subject = "{}".format(flag_string)       
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()       # create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    msg.attach(MIMEText('{}'.format(length_string),'plain'))        
            
    # send the message via the server set up earlier.
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    del msg       
    # Terminate the SMTP session and close the connection
    s.quit()

if counter!=0:
    data_dumper_notification('Notis file backup','''{} NOTIS API files moved 
                             from 172.17.9.97\\TRADEFILE 
                             to \\172.17.9.141\\Backup\\NOTIS_API_TradeFile'''.format(counter))
