import pandas as pd
import re,datetime,requests,logging
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.common.proxy import Proxy,ProxyType

logging.basicConfig(filename='test.log',
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

master_dir="D:\\Data_dumpers\\Master\\"


options = webdriver.ChromeOptions()
options.add_argument('--headless')
options.add_argument('--no-sandbox')
options.add_argument('disable-infobars')
options.add_argument('--disable-extensions')
options.add_argument('dnt=1')
options.add_argument('upgrade-insecure-requests=1')
options.add_argument('user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36')
options.add_argument('accept=text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9')
options.add_argument( 'Accept=*/*' )
options.add_argument('sec-fetch-site=none')
options.add_argument('sec-fetch-mode=navigate')
options.add_argument('sec-fetch-user=?1')
options.add_argument('sec-fetch-dest=document')
options.add_argument('accept-language=en-GB,en-US;q=0.9,en;q=0.8')
options.add_argument('X-Requested-With=XMLHttpRequest')    

def get_data(url,location):
    headers= {'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:28.0) Gecko/20100101 Firefox/28.0',
                'X-Requested-With': 'XMLHttpRequest'
                }
    try: 
        print("url",url)
        logging.info("getting data for {}".format(url))
        res = requests.get(url,headers=headers)
        print("The status code is ", res.status_code)

        soup=BeautifulSoup(res.text,"html.parser")
        data=soup.find_all('div',{'class':'col-md-11 col-sm-11 col-xs-10 margin-bottom-5'})
        a_l=[]
        
        for i in data:
            a_l.append(i.getText())    
    
        prefixes = ('\n','-')
        a_l = [x for x in a_l if not x.startswith(prefixes)]
    
    except Exception as e:
        print("Error",e)
        logging.info("exception {}".format(e))
            
    df=pd.DataFrame(a_l,columns=["Address"])
    df["Location"]=location

    return df

#values fetched from inr deals website and few entries added manually as cant be scraped
def inrdeals():
    df_Ahemdabad=get_data('https://inrdeals.com/store/dmart-store/gujarat/dmart-store-in-ahmedabad','Ahmedabad')
    df_bhimavaram=get_data('https://inrdeals.com/store/dmart-store/andhra-pradesh/dmart-store-in-bhimavaram','Bhimavaram')
    df_navimumbai=get_data('https://inrdeals.com/store/dmart-store/maharashtra/dmart-store-in-navi-mumbai','Navimumbai')
    df_indore=get_data('https://inrdeals.com/store/dmart-store/madhya-pradesh/dmart-store-in-indore','Indore')
    df_ghandhidham=get_data('https://inrdeals.com/store/dmart-store/gujarat/dmart-store-in-gandhidham','Gandhidham')
    df_surat=get_data('https://inrdeals.com/store/dmart-store/gujarat/dmart-store-in-surat','Surat')
    df_lufdhiana=['Ludhiana, Punjab 141122',' 22-4-16 Karakambadi Road Mangalam, Akkarampalle, Tirupati, Andhra Pradesh 517507','79, Swami Vivekananda Nagar, near RK Puram, Yojana Scheme, Kota, Rajasthan 324010']
    df=pd.DataFrame(df_lufdhiana,columns=["Address"])
    df.reset_index(drop=True,inplace=True)
    df["Location"]='Ludhiana'
    df["Location"][1]='Tirupati'
    df["Location"][2]='Kota'
    q6=[df_Ahemdabad,df_bhimavaram,df_navimumbai,df_indore,df_ghandhidham,df,df_surat]
    df1=pd.concat(q6)
    return df1

#get data from google maps
def get_data_single(value):
    ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
    p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
    ip=ip+':'+p
    prox = Proxy()
    prox.proxy_type = ProxyType.MANUAL
    prox.http_proxy = ip
    prox.https_proxy = ip    
    capabilities = webdriver.DesiredCapabilities.CHROME
    prox.add_to_capabilities(capabilities)
      
    driver = webdriver.Chrome(master_dir+"chromedriver.exe",options=options,desired_capabilities=capabilities)
    try:
        url='https://www.google.com/maps/search/Dmart {}'.format(value)
        logging.info("data fetched for {}".format(url))
        driver.get(url)
        driver.implicitly_wait(40)
        driver.find_element_by_xpath('/html/body/jsl/div[3]/div[9]/div[8]/div/div[1]/div/div/div[10]/button/div/div[2]').click()
        content = driver.page_source
        soup=BeautifulSoup(content, 'html.parser') 
        da=soup.find('div',{'jsan':'7.ugiz4pqJLAG__primary-text,7.gm2-body-2'})
        d_a=[da.text,value]
        driver.close()
    except Exception as e:
        print("error",e)
        logging.info("error {} {}".format(e,value))
        print(value)
        driver.close()
    return d_a

#get values for only one store from google maps
def single():
    single=['Ajmer','Amritsar','belgaum','bhilai','palghar','chandigarh','chennai',
            'coimbatore','ghaziabad','guntur','kurnool','jalandhar','latur','nagpur',
            'nellore','raipur','ujjain','Vijayawada','Zirakhpur']
    data_single=[]
    for i in single:
        data_single.append(get_data_single(i))

    df=pd.DataFrame(data_single,columns=["Address","Location"])
    df.reset_index(drop=True,inplace=True)
    return df
 
def get_data_multiple(value):
    ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
    p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
    ip=ip+':'+p
    prox = Proxy()
    prox.proxy_type = ProxyType.MANUAL
    prox.http_proxy = ip
    prox.https_proxy = ip    
    capabilities = webdriver.DesiredCapabilities.CHROME
    prox.add_to_capabilities(capabilities)
 

    driver = webdriver.Chrome(master_dir+"chromedriver.exe",options=options,desired_capabilities=capabilities)
    try:
        url='https://www.google.com/maps/search/Dmart {}'.format(value)
        logging.info("data fetched for {}".format(url))
        driver.get(url)
        driver.implicitly_wait(20)
        driver.find_element_by_class_name('section-result-location').click()
        content = driver.page_source
        soup=BeautifulSoup(content, 'html.parser') 
        da=soup.find_all('span',{'class':'section-result-location'})
        d_a=[]
        for i in da:
            d_a.append(i.getText())
        
        driver.close() 
    except Exception as e:
        print("error",e)
        logging.info("error {} {}".format(e,value))
        print(value)
        driver.close()
        
    df=pd.DataFrame(d_a,columns=["Address"])
    df["Location"]=value
    return df

#data fetched for multiple stores from google maps
def multiple():
    multiple=['Anand','Aurangabad','banglore','bhopal','hyderabad','jaipur','vadodara',
              'mumbai','pune','rajkot','solapur','thane','vapi','warangal']

    data_multiple=[]
    for i in multiple:
        df=get_data_multiple(i)
        data_multiple.append(df)
    
    final_df=pd.concat(data_multiple)
    final_df.reset_index(drop=True,inplace=True)
    return final_df

#final data dmart
def dmart():
    df= inrdeals()
    df1=single()
    df2=multiple()
    df3=[df,df1,df2]
    final=pd.concat(df3)
    final.sort_values(by=['Location'], ascending=True,inplace=True)
    final.reset_index(drop=True,inplace=True)
    final.to_excel("dmat_store.xlsx",index=False)
    return final    

#final data big bazar 
def get_bb(df):
    filter_list=df["Location"].unique()
    data=pd.read_excel("bigbazar.xlsx")
    data.reset_index(drop=True,inplace=True)

    filter_col=data[data['City'].str.lower().isin([x.lower() for x in filter_list])]
    prefixes = ['FBB','FOOD BAZAAR']
    f_l =filter_col.loc[~filter_col['Format'].isin(prefixes)]

    f_l=f_l[["Store Name","City"]]
    f_l.columns=["Address","Location"]
    f_l.sort_values(by=['Location'], ascending=True,inplace=True)
    f_l.reset_index(drop=True,inplace=True)
    f_l.to_excel("bb_store.xlsx",index=False)
    return f_l

#calculate distance between dmart and big bazar store    
def get_distance(dm_df,bb_df):
    ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
    p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
    ip=ip+':'+p
    prox = Proxy()
    prox.proxy_type = ProxyType.MANUAL
    prox.http_proxy = ip
    prox.https_proxy = ip    
    capabilities = webdriver.DesiredCapabilities.CHROME
    prox.add_to_capabilities(capabilities)

    driver = webdriver.Chrome(master_dir+"chromedriver.exe",options=options,desired_capabilities=capabilities)
    try: 
        final_output=[]
        d_list=dm_df["Location"].unique()
        for i in d_list:
            dm =dm_df.loc[dm_df['Location'].isin([i])]
            bb =bb_df.loc[bb_df['Location'].isin([i])]
            for index,row in dm.iterrows():
                print(row["Address"])
                for index1,row1 in bb.iterrows():
                    print(row1["Address"])
                    url='https://maps.google.com/?saddr={}&daddr={}'.format(row["Address"],row1["Address"])
                    logging.info("distance {}".format(url))
                    print("https://maps.google.com/?saddr={}&daddr={}".format(row["Address"],row1["Address"]))
                    driver.get(url)
                    driver.implicitly_wait(20)
                    content = driver.page_source
                    soup=BeautifulSoup(content, 'html.parser') 
                    da=soup.find_all('div',{'class':'section-directions-trip-distance section-directions-trip-secondary-text'})
                    fin=[]
                    for i in da:
                        fin.append(i.getText()) 

                    pattern = '[a-z|A-z]'
                    dg = [re.sub(pattern,'', i) for i in fin] 
                    print("km",dg)
                    if len(dg)==0:
                        dg=0
                    else:
                        dg=[re.sub(' ','',i) for i in dg]
                        dg=[re.sub(',','',i) for i in dg]
                        dg=[float(i) for i in dg]
                        dg=min(dg)
                    final_output.append([row["Address"],row["Location"],row1["Address"],dg,url])
    except Exception as e:
        print("error",e)
        logging.info("error occured {}".format(e))
        
    return final_output

def main():                   
    d_d=dmart()
    logging.info("fetched dmart data")
    d_d['Location'] = d_d['Location'].replace('banglore','bengaluru')
    d_d['Location'] = d_d['Location'].replace('Navimumbai','Navi Mumbai')
    b_b=get_bb(d_d)
    logging.info("fetched bib bazar data")
    b_b['Location'] = b_b['Location'].str.upper()
    d_d['Location'] = d_d['Location'].str.upper()

    dm_f =d_d.loc[d_d['Location'].isin(b_b["Location"])]
    output=get_distance(dm_f,b_b)  

    df=pd.DataFrame(output,columns=["Dmart Address","Location","BB Address","Distance","url"])
    df.replace('',0,inplace=True)
    df.reset_index(drop=True,inplace=True)
    dk=df[df["Dmart Address"] !=0]
    dk.reset_index(drop=True,inplace=True)
    dk.to_excel("distance_dmart_bb_{}.xlsx".format(datetime.datetime.now().date()),index=False)
    logging.info("calculated disatance")

main()
              
#to check import
#import pandas as pd 
#df=pd.read_excel("C:\\Users\\devanshm\\Desktop\\dmart big bazar distance\\bigbazar.xlsx")