import pandas as pd 
import numpy as np
import requests,re,os,datetime,time,logging,redis,wget,urllib2
from cassandra.cluster import Cluster
from dateutil.parser import parse
from bs4 import BeautifulSoup
from lxml import html
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By



os.chdir("D:\\Data_dumpers\\Market_Turnover\\")

cassandra_host = "172.17.9.51"
redis_host = 'localhost'


master_dir = "D:\\Data_dumpers\\Master\\"
processed_dir = "D:\\Data_dumpers\\Market_Turnover\\Processed\\"

logging.basicConfig(filename='test.log',
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

cluster = Cluster([cassandra_host])
logging.info('Cassandra Cluster connected...')
# connect to your keyspace and create a session using which u can execute cql commands 
session = cluster.connect('rohit')
logging.info('Using rohit keyspace')

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
        
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print "working day wait file is getting downloaded"
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1
    
def nse_equities_traded(d):
    
    url = "https://www.nseindia.com/products/content/equities/equities/equities.htm"
    driver = webdriver.Chrome(master_dir+'chromedriver.exe')
    driver.get(url)
    soup = BeautifulSoup(driver.page_source, 'lxml')
    #print(soup.prettify())
#    tree = html.parse("C:\Users\devanshm\Desktop\devansh\scrapping\NSE - National Stock Exchange of India Ltd.html")
#    raw_html=html.tostring(tree)
#    soup = BeautifulSoup(raw_html, 'html.parser')
    
    div = soup.find_all('th')
    row_val1=[]
    for i in range(len(div)):
        row_val1.append(div[i].text)
    
    print row_val1
    
    div1 = soup.find_all('td')
    row_val2=[]
    for i in range(len(div1)):
        row_val2.append(div1[i].text)
        
    print row_val2
    
    p=row_val1[0]
    p=p[5:]
    p=parse('Aug 19, 2019 16:00 IST').date()

    val1=pd.DataFrame(row_val1).T
    val2=pd.DataFrame(row_val2).T
    val1.columns=val1.loc[0]
    val1.rename(columns={'As on Aug 19, 2019 16:00 IST':'tradingdate'},inplace=True)
    val1.drop(val1.index[0],inplace=True)
    
    val1.columns=["tradingdate","Traded_Volume_shares_lakh","Traded_Value_crores"]
    val1 = val1.append([{'tradingdate':p}], ignore_index=True)
    
    val1["Traded_Volume_shares_lakh"]=val2[0]
    val1["Traded_Value_crores"]=val2[1]
    val1['Traded_Volume_shares_lakh'] = (val1['Traded_Volume_shares_lakh'].replace(',','', regex=True).astype(float))
    val1['Traded_Value_crores'] = (val1['Traded_Value_crores'].replace(',','', regex=True).astype(float))
    val1["exchange"]='NSE'
#    val1.to_csv(processed_dir+"nse_equities_traded_{}.csv".format(d),index=False)
    driver.close()
    return row_val1

def bse_equities_traded(d):
    
    url = "https://www.bseindia.com"
    driver = webdriver.Chrome(master_dir+'chromedriver.exe')
    driver.get(url)
#    driver.find_element_by_link_text("Market Turnover").click()
#    driver = driver.find_element_by_xpath('//*[@id="Mkt"]')
#    el = driver.find_element_by_class_name('tab-pane largetable active')
#    el.click()
#    driver.find_element_by_link_text('https://www.bseindia.com/#Mkt')
#    driver.find_element_by_id("Mkt").click()
#    driver.find_elements_by_class_name("accordion-link last active").click()                                      
#    driver.find_element_by_name("ng-scope").click()
    driver.find_element(By.CLASS_NAME("accordion-link last active")).click()

    soup = BeautifulSoup(driver.page_source, 'lxml')
    #print(soup.prettify())
#    tree = html.parse("C:\Users\devanshm\Desktop\devansh\scrapping\BSE Ltd. (Bombay Stock Exchange) _ Live Stock Market Updates for S&P BSE SENSEX,Stock Quotes & Corporate Information.html")
#    raw_html=html.tostring(tree)
#    soup = BeautifulSoup(raw_html, 'html.parser')
    
    div1 = soup.find_all('td')
    row_val2=[]
    for i in range(len(div1)):
        row_val2.append(div1[i].text)
    
    del row_val2[-188:]
    del row_val2[0:184]
    row_val2=pd.DataFrame(row_val2)
    val2=row_val2.T
    val2.drop([3,4,5,6],inplace=True,axis=1)
    val2.columns=["exchange","Traded_Volume_shares_lakh","Traded_Value_crores","tradingdate"]
    val2['Traded_Volume_shares_lakh'] = (val2['Traded_Volume_shares_lakh'].replace(',','', regex=True).astype(float))
    val2['Traded_Value_crores'] = (val2['Traded_Value_crores'].replace(',','', regex=True).astype(float))
    val2["Traded_Volume_shares_lakh"]=val2["Traded_Volume_shares_lakh"]/100000
    val2["exchange"]="BSE"
    q=val2["tradingdate"][0]
    q=q.split('|') 
    q=q[0]
    val2["tradingdate"]=parse(q).date()
    #val2.to_csv(processed_dir+"bse_equities_traded_{}.csv".format(d),index=False)
    driver.close()
    return val2

def main():
    
    d=datetime.datetime.now().date()
    print "Processing for date ",d
    if process_run_check(d)== -1:
        return -1
#    nse=nse_equities_traded(d)
    bse=bse_equities_traded(d)
    
    while True:
        
        if nse["tradingdate"][0]==bse["tradingdate"][0]:
            print "yes dates are equal"
            final_df=pd.concat([bse,nse], ignore_index=True)
            final_df.to_csv("market_turnover.csv",index=False)
       
            #create table if not exists
            session.execute(
                    "CREATE TABLE IF NOT EXISTS market_turnover(Traded_Value_crores FLOAT,Traded_Volume_shares_lakh FLOAT,exchange TEXT,tradingdate DATE, PRIMARY KEY (tradingdate,exchange))")
            
            os.system("market_turnover.bat")
            
            r = redis.Redis(host=redis_host, port=6379) 
            r.set('market_turnover',1)
                
                    
            r.set("market_turnover_remarks",'Market turnover dumped in market_turnover table for NSE {}, BSE {}'.format(
                    nse["tradingdate"][0],bse["tradingdate"][0] ))
            
            break
        else:
            print "Date not available on either site ; sleep for 5 min"
            time.sleep(300)
            
#            nse=nse_equities_traded(d)
            bse=bse_equities_traded(d)
            

main()