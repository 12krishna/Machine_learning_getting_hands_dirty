# -*- coding: utf-8 -*-
"""
Created on Thu Apr 15 18:28:58 2021

@author: krishna
"""

from dateutil import parser
import os,sys,os.path
import pandas as pd
import numpy as np
import datetime
import logging
import time
import copy
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException
#from bs4 import BeautifulSoup
#from selenium.webdriver.common.proxy import Proxy,ProxyType
from urllib.parse import urlencode
import redis
import warnings
warnings.filterwarnings("ignore")

master_dir='D:\\Data_dumpers\\Master\\'
log_path="D:\\Data_dumpers\\nse_sec_real_time\\"
redis_host = "localhost"

# define logging for the file system at debug or higher level
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    datefmt='%m-%d %H:%M',
                    filename=log_path+'nse_realtime_new.log')
logging.info("Start process")




class Nse():
    """
    class which implements all the functionality for
    National Stock Exchange
    """

    def __init__(self):
        # URL list
        #self.get_quote_url = 'https://www.nseindia.com/get-quotes/equity?'  #new url
        self.get_quote_url = 'https://www.nseindia.com/get-quotes/equity?'
        self.driver = self.set_proxy_details()
        self.redis = redis.Redis(host=redis_host, port=6379, db=1) # write to cache


    def get_quote(self, code, as_json=False):
        """
        gets the quote for a given stock code
        :param code:
        :return: dict or None
        :raises: HTTPError, URLError
        """
        code = code.upper()
        quote = None
        try:
            s=time.time()
            self.driver.get(self.build_url_for_quote(code))
            time.sleep(2)
            try:
                quote = self.crawl_data()
            except Exception:
                print ("sleep for 1 second before crawling...")
                time.sleep(1)
                quote = self.crawl_data()

            print (time.time()-s)

        except Exception as e:
            print (f"{code} Get quote Error:\n {e}")
        #clear session and cache; to handle access denied error by NSE
        self.driver.delete_all_cookies()

        return quote



    def crawl_data(self):
        '''gets dict of data'''

        quote = {}
        '''
        # old 
        quote['quantityTraded'] = int((self.driver.find_element_by_id("securityWiseQT").text).replace(',',''))
        quote['deliveryQuantity'] = int((self.driver.find_element_by_id("securityWiseDQ").text).replace(',',''))
        quote['deliveryToTradedQuantity'] = float((self.driver.find_element_by_id("securityWiseDQTQ").text).replace('%',''))
        quote['averagePrice'] = float((self.driver.find_element_by_id("quoteLtp").text).replace(',',''))
        date=(self.driver.find_element_by_id("securityWiseDate").text).replace("EOD","16:00:00")
        quote['secDate'] =  datetime.datetime.strptime(date.title(), "%d-%b-%Y %H:%M:%S")
        '''
        # new changes in website
        try:
            scrp_data = self.driver.find_element_by_id("securityWiseInfo").text.split("\n")[-1].split(" ")
            quote['quantityTraded'] = int(scrp_data[0].replace(',',''))
            quote['deliveryQuantity'] = int(scrp_data[1].replace(',',''))
            quote['deliveryToTradedQuantity'] = float(scrp_data[2].replace(',',''))
            quote['averagePrice'] = float((self.driver.find_element_by_id("quoteLtp").text).replace(',',''))
            date=(self.driver.find_element_by_id("securityWiseDate").text).replace("EOD","16:00:00")
            quote['secDate'] =  datetime.datetime.strptime(date.title(), "%d-%b-%Y %H:%M:%S")
        except Exception as e:
            print (e)
                    

        return quote



    def set_proxy_details(self):
        '''Func to set proxy for driver'''

        opts = Options()
        # Add headers
        user_agent =  ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) '
                       'AppleWebKit/537.36 (KHTML, like Gecko) '
                       'Chrome/39.0.2171.95 Safari/537.36')
        opts.add_argument(f'user-agent={user_agent}')
        # Remove the Automation Info
        opts.add_argument('--disable-infobars')
        opts.add_argument("headless")
        opts.add_argument('--disable-gpu')
        opts.add_argument("--log-level=3")  # fatal


        driver = webdriver.Chrome(master_dir+"chromedriver.exe", chrome_options=opts)
        #driver.minimize_window()
        print ("Proxy details set for the session")
        return driver


    def build_url_for_quote(self, code):
        """
        builds a url which can be requested for a given stock code
        :param code: string containing stock code.
        :return: a url object
        """
        if code is not None and type(code) is str:
            encoded_args = urlencode([('symbol', code)])
            return self.get_quote_url + encoded_args
        else:
            raise Exception('code must be string')





def get_nse_data(nse_symbols, t):
    '''Func to fetch delivery data in real time for all the symbols'''

    nse_obj = Nse()  # create nse object to scrap real time data; package nsetools
    logging.info("Nse object from nsetools created...")
    logging.info( "Fetching data for {} symbols".format(len(nse_symbols)) )
    s_time = time.time()
    #data = []
    t_back=t
    '''
    if t.hour==16:
        logging.info("Scrap data for EOD")
        t_back=datetime.time(0,0)
    '''

    while len(nse_symbols)!=0 :
        if (datetime.datetime.now().time() >= datetime.time(t.hour,58)) and (t.hour!=16):
            break
        elif (t.hour==16) and (datetime.datetime.now().time() >= datetime.time(t.hour+5,58)):
            break

        symbols_iter = copy.deepcopy(nse_symbols)
        for stock in symbols_iter:
            try:
                q = nse_obj.get_quote(stock)

                sec_date = pd.to_datetime(q['secDate'])

                if t_back!=datetime.time(0,0):
                    if not ((sec_date.time()>=t_back) and sec_date.date()==datetime.datetime.now().date()):
                        continue
                else:
                    if not ((sec_date.time()==t_back) and sec_date.date()==datetime.datetime.now().date()):
                        continue

                '''
                # append data in csv file
                output_file = open(r"\\172.17.9.43\Fno_analytics\Security delivery position\_NSE_new_{}.txt".format(datetime.datetime.now().date()), 'a')

                output_file.write(','.join([stock, str(sec_date.date()), str(t),
                                            str(q['quantityTraded']), str(q['deliveryQuantity']),
                                            str(q['deliveryToTradedQuantity']), str(q['averagePrice'])])+"\n")
                output_file.flush()
                output_file.close()
                '''
                nse_obj.redis.set(stock, ','.join([stock, str(sec_date.date()), str(t),
                                            str(q['quantityTraded']), str(q['deliveryQuantity']),
                                            str(q['deliveryToTradedQuantity']), str(q['averagePrice'])])+"\n")

                nse_symbols.remove(stock)
                logging.info("Data fetched for {}".format(stock))
                print ("Data fetched for {}".format(stock))
            except TimeoutException as te:
                logging.error(f"{stock}: Timeout Exception {te}")
                logging.info("Closing driver; and creating new connection...")
                nse_obj.driver.close()
                nse_obj.driver.quit()
                nse_obj = Nse()
                logging.info("New driver connection created...")
            except Exception as e:
                logging.error("Error fetching data for {}".format(stock))
                logging.error(e)
                print("Error fetching data for {}".format(stock))


        if len(nse_symbols)!=0:
            logging.info("Data missing for {} stocks".format(len(nse_symbols)))
            print("Data missing for {} stocks".format(len(nse_symbols)))
            time.sleep(5)



    logging.info("Data fetching time {}".format(time.time()-s_time))
    nse_obj.driver.close()
    nse_obj.driver.quit()
#data = pd.DataFrame(data, columns=['Stock_name', 'Del_Qty',"Del_Pct", 'Qty_Traded', 'Time', 'Avg_Price'])


def main(start, end, t):
    # load data for BSE 500 stocks universe
    symbols = pd.read_excel(master_dir+"BSE_500_tickers.xlsx")[['NSE Symbol']]
    symbols['NSE Symbol'] = symbols['NSE Symbol'].astype(str)
    symbols['NSE Symbol'] = symbols['NSE Symbol'].str.strip()
    symbols = list(sorted(symbols['NSE Symbol'].tolist()))

    # load active fno stocks
    fno_symbols=pd.read_excel(master_dir+'MasterData.xlsx')
    fno_symbols=fno_symbols[(fno_symbols["IsActiveFNO"]==True) & (fno_symbols["Type"]=="SSF")]
    fno_symbols['SYMBOL'] = fno_symbols['SYMBOL'].astype(str)
    fno_symbols['SYMBOL'] = fno_symbols['SYMBOL'].str.strip()
    fno_symbols = list(sorted(fno_symbols['SYMBOL'].tolist()))

    # prospective fno symbols
    others = pd.read_excel(master_dir+"Security_delivery_nonNIFTY.xlsx")
    others['SYMBOL'] = others['SYMBOL'].str.strip()
    others = [ str(s) for s in others['SYMBOL'].values.tolist()]
    fno_symbols = list(sorted(list(set(fno_symbols+others))))
    fno_symbols = fno_symbols+[s for s in symbols if s not in fno_symbols]

    if end==-1:
        get_nse_data(fno_symbols[start:],   # takes , seprearted names of NSE symbols
                 datetime.time(t, 0) )  # time foe which data needs to be scrapped
    else:
        get_nse_data(fno_symbols[start:end],   # takes , seprearted names of NSE symbols
                 datetime.time(t, 0) )




if __name__ == "__main__":
    start, end, t = int(sys.argv[1:][0]), int(sys.argv[1:][1]), int(sys.argv[1:][2])
    main(start, end, t)
