# -*- coding: utf-8 -*-
"""
Created on Thu Apr  8 11:30:21 2021

@author: krishna
"""

import os
import datetime
import pandas as pd
import time
import redis

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\nse_sec_real_time\\output\\'
log_path="D:\\Data_dumpers\\nse_sec_real_time\\"

redis_host = "localhost"

# delete log file if more than 1 gb
def delete_log(filename):
    if os.path.exists(filename) and os.stat(filename).st_size/(1024**2)>=700:
        print ("Deleting log file")
        os.remove(filename)

delete_log(log_path+"nse_realtime_new.log")

def dateparse_d(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)


def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
    if len(holiday_master[holiday_master['date']==d])==0:
        print("Working day, open file and start process")

        # csv file in append mode to append data
        if not os.path.exists(r"\\172.17.9.43\Fno_analytics\Security delivery position\NSE_delivery_{}.txt".format(datetime.datetime.now().date())):
            output_file = open(r"\\172.17.9.43\Fno_analytics\Security delivery position\NSE_delivery_{}.txt".format(datetime.datetime.now().date()), 'a')
            output_file.write("Symbol,traded_date,traded_time,QT,DQ,pc_DQ_TQ,avg_price\n")  # header
            output_file.flush()
            output_file.close()
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        print('Holiday: skip for current date :{} '.format(d))
        return -1

def write_data(t):

    count = 0
    r = redis.Redis(host=redis_host, port=6379, db=1)
    while (r.keys() or count<502):
        if (t!=16 and datetime.datetime.now().time() > datetime.time(t,58)) or (t==16 and datetime.datetime.now().time() > datetime.time(t+3,58)):
            break
        for key in sorted(r.keys()):
            output_file = open(r"\\172.17.9.43\Fno_analytics\Security delivery position\NSE_delivery_{}.txt".format(datetime.datetime.now().date()), 'ab')
            output_file.write(r.get(key))
            output_file.flush()
            output_file.close()
            r.delete(key)
            count += 1
        time.sleep(15)
    else:
        print("Data for current batch scrapped successfully....")
        return



def main():

    if process_run_check(datetime.datetime.now().date()) == -1:
        return -1

    for i in range (10,17):

        while True:
            if datetime.datetime.now().time() > datetime.time(i,0):
                print("Fetch data for instance time {}".format(datetime.time(i,0)))

                os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat {} {} {}".format(0,30,i))
                os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat {} {} {}".format(30,60,i))
                os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat {} {} {}".format(60,90,i))
                os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat {} {} {}".format(90,120,i))
                os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat {} {} {}".format(120,150,i))                
                os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat {} {} {}".format(150,180,i))
                time.sleep(150)
                os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat {} {} {}".format(180,250,i))
                os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat {} {} {}".format(250,350,i))
                os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat {} {} {}".format(350,-1,i))
                write_data(i)

                break
            else:
                print ("Sleep until next event time is triggered")
                time.sleep(45)


if __name__=="__main__":
    main()


