# -*- coding: utf-8 -*-
"""
Created on Thu Jul  9 13:20:06 2020

@author: krishna
"""

import os,sys,os.path
import pandas as pd
import numpy as np
import datetime
#os.chdir('D:\\Data_dumpers\\nse_sec_real_time\\')
sys.path.insert(0, 'D:\\Data_dumpers\\nse_sec_real_time\\')
#sys.path.insert(-1,"D:\Master\\")
from nsetools import nse
#import redis
import logging
import time
import copy


#redis_host = "localhost"
#redis_host = "10.223.104.65"
#r = redis.Redis(host=redis_host, port=6379)
#cassandra_host_list = ["172.17.9.51"]

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\nse_sec_real_time\\output\\'
#email_dir='D:\\Emails\\Output\\'
key_dir='D:\\Data_dumpers\\nse_sec_real_time\\key\\'
log_path="D:\\Data_dumpers\\nse_sec_real_time\\"


# define logging for the file system at debug or higher level
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    datefmt='%m-%d %H:%M',
                    filename=log_path+'nse_realtime.log',filemode='w')
#logging.basicConfig(level=logging.DEBUG, format='%(relativeCreated)6d %(threadName)s %(message)s')
# define a Handler which writes INFO messages or higher to the sys.stderr
console = logging.StreamHandler()
console.setLevel(logging.INFO)
# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)
logging.info("Start process")

   

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)


def get_nse_data(nse_symbols, non_fno_symbols, t):
    '''Func to fetch delivery data in real time for all the symbols'''
       
    nse_obj = nse.Nse()  # create nse object to scrap real time data; package nsetools
    logging.info("Nse object from nsetools created...")
    logging.info( "Fetching data for {} symbols".format(len(nse_symbols)) )
    s_time = time.time()
    #data = []
    t_back=t
    if t.hour==16:
        logging.info("Scrap data for EOD")
        t_back=datetime.time(0,0)

    append_flag=0
    while len(nse_symbols)!=0 :   
        if (datetime.datetime.now().time() >= datetime.time(t.hour,58)) and (t.hour!=16):
            break
        elif (t.hour==16) and (datetime.datetime.now().time() >= datetime.time(t.hour+6,58)):
            break
    
        symbols_iter = copy.deepcopy(nse_symbols)
        for stock in symbols_iter:
            try:            
                q = nse_obj.get_quote(stock)  
                sec_date = pd.to_datetime(q['secDate'])
                
                if t_back!=datetime.time(0,0):
                    if not ((sec_date.time()>=t_back) and sec_date.date()==datetime.datetime.now().date()):
                        continue
                else:
                    if not ((sec_date.time()==t_back) and sec_date.date()==datetime.datetime.now().date()):
                        continue
                
                # append data in csv file 
                output_file = open(r"\\172.17.9.43\Fno_analytics\Security delivery position\NSE_delivery_{}.txt".format(datetime.datetime.now().date()), 'ab')
    
                output_file.write(','.join([stock, str(sec_date.date()), str(t),
                                            str(q['quantityTraded']), str(q['deliveryQuantity']), 
                                            str(q['deliveryToTradedQuantity']), str(q['averagePrice'])])+"\n")
                output_file.flush()  
                output_file.close()
    
    
                nse_symbols.remove(stock)
                logging.info("Data fetched for {}".format(stock))
                
            
            except Exception as e:
                logging.error("Error fetching data for {}".format(stock))
                logging.error(e)
                logging.info("Sleep for 5 sec and, start new connection....")
                time.sleep(2)
                nse_obj = nse.Nse()
        
        if len(nse_symbols)!=0:
            logging.info("Data missing for {} stocks".format(len(nse_symbols)))
            time.sleep(5)        
    
        if len(nse_symbols)<=5 and append_flag==0:
            logging.info("Append non fno symbols for downloading...")
            nse_symbols = nse_symbols+non_fno_symbols
            append_flag=1
        
        
    
    logging.info("Data fetching time {}".format(time.time()-s_time))
        
#data = pd.DataFrame(data, columns=['Stock_name', 'Del_Qty',"Del_Pct", 'Qty_Traded', 'Time', 'Avg_Price'])
    
    
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        logging.info("Working day, open file and start process")
        
        # csv file in append mode to append data
        if not os.path.exists(r"\\172.17.9.43\Fno_analytics\Security delivery position\NSE_delivery_{}.txt".format(datetime.datetime.now().date())):
            output_file = open(r"\\172.17.9.43\Fno_analytics\Security delivery position\NSE_delivery_{}.txt".format(datetime.datetime.now().date()), 'ab')
            output_file.write("Symbol,traded_date,traded_time,QT,DQ,pc_DQ_TQ,avg_price\n")  # header
            output_file.flush()
            output_file.close()        
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

    
def main():
    
    if process_run_check(datetime.datetime.now().date()) == -1:
        return -1 
    
    # load data for BSE 500 stocks universe
    symbols = pd.read_excel(master_dir+"BSE_500_tickers.xlsx")[['NSE Symbol']]
    symbols['NSE Symbol'] = symbols['NSE Symbol'].astype(str)
    symbols['NSE Symbol'] = symbols['NSE Symbol'].str.strip()
    symbols = list(sorted(symbols['NSE Symbol'].tolist()))
    
    # load active fno stocks 
    fno_symbols=pd.read_excel(master_dir+'MasterData.xlsx')
    fno_symbols=fno_symbols[(fno_symbols["IsActiveFNO"]==True) & (fno_symbols["Type"]=="SSF")]
    fno_symbols['SYMBOL'] = fno_symbols['SYMBOL'].astype(str)
    fno_symbols['SYMBOL'] = fno_symbols['SYMBOL'].str.strip()
    fno_symbols = list(sorted(fno_symbols['SYMBOL'].tolist()))
    
    # prospective fno symbols
    others = pd.read_excel(master_dir+"Security_delivery_nonNIFTY.xlsx")
    others['SYMBOL'] = others['SYMBOL'].str.strip()
    others = [ str(s) for s in others['SYMBOL'].values.tolist()]
    fno_symbols = list(set(fno_symbols+others))
    
        
    for i in range (10,17):
        while True:                
            if datetime.datetime.now().time() > datetime.time(i,0):
                logging.info("Fetch data for instance time {}".format(datetime.time(i,0)))
                temp_symbols = [s for s in symbols if s not in fno_symbols]  # symbols other than fno universe
                get_nse_data(copy.deepcopy(fno_symbols), copy.deepcopy(temp_symbols), datetime.time(i,0))
                #get_nse_data(copy.deepcopy(temp_symbols), datetime.time(i,0))
                break
            else:
                print "Sleep until next event time is triggered"
                time.sleep(45)
                
    # close csv output file 
    #output_file.close()
    
    

if __name__=='__main__':
    main()

