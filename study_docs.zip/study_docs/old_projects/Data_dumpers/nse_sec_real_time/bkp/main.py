from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime,os,shutil,logging,redis,sys
import pandas as pd , itertools
#import schedule
os.chdir("D:\\Data_dumpers\\nse_sec_real_time\\")

#redis_host = "localhost"
redis_host = "10.223.104.65"
r = redis.Redis(host=redis_host, port=6379)

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\nse_sec_real_time\\output\\'
email_dir='D:\\Emails\\Output\\'
key_dir='D:\\Data_dumpers\\nse_sec_real_time\\key\\'

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["stock","date","QT","DQ","%DQ"]

f_list=["Symbol","Symbol_key","date","QT","DQ","%DQ"]

global f_df
f_df=pd.DataFrame(columns=f_list)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1




def chunks(lst, n):  
        symbols_chunks= []
        for i in range(0, len(lst), n):
            symbols_chunks.append(lst[i:i + n])
        return symbols_chunks


def create_redis_dict():
    num=['10','11','12','13','14','15','16']
    
#    dt=['11:10:00','12:10:00','13:10:00','14:10:00','15:10:00','16:10:00']
    
    symbol_key=[]
    
    nse_symbol=pd.read_excel(master_dir+'MasterData.xlsx')
    nse_symbol=nse_symbol.loc[nse_symbol["IsActiveFNO"]==True]
    nse_symbol=nse_symbol.loc[nse_symbol["Type"]=="SSF"]
    print "Fetching data for symbols {}".format(len(nse_symbol))
    nse_symbol.reset_index(drop=True,inplace=True)
    nse_symbol.rename(columns={"SYMBOL":"Symbol"},inplace=True)
    
    for i in range(len(num)):
        for j in range(len(nse_symbol["Symbol"])):
            val=nse_symbol["Symbol"][j]+'_'+num[i]
            symbol_key.append(val)
                
    symbol=pd.DataFrame(symbol_key,columns=["Symbol"])
    symbol=symbol["Symbol"].str.split('_',expand=True)
    symbol.rename(columns={0:'Symbol',1:'k_num'},inplace=True)
    symbol["Symbol_key"]=symbol_key
    f_df["Symbol"]=symbol["Symbol"]
    f_df["Symbol_key"]=symbol["Symbol_key"]
    f_df.fillna("-", inplace=True)
    
    
    # divide symbols and publish dict to redis
    symbols_list = chunks(list(f_df['Symbol'].unique()), len(list(f_df['Symbol'].unique()))/3 )
    final_symbols = []
    if len(symbols_list)>3:
        final_symbols.append(symbols_list[0]); final_symbols.append(symbols_list[1])
        final_symbols.append([y for x in symbols_list[2:] for y in x])
    else:
        final_symbols=symbols_list
        
        
        
    i=1    
    for l in final_symbols:
        r.set( 'nse_sec_realtime_data_{}'.format(i) ,f_df[f_df['Symbol'].isin(l)].to_msgpack(compress='zlib'))
        i+=1
          
    
    
def main():

    d=datetime.datetime.now() # -datetime.timedelta(hours=1)
        
    if process_run_check(d.date()) == -1:
        return -1 
    
    create_redis_dict()  # create entire dict for day in redis
    #logging.info("data stored in redis success")
#    for i in range(len(dt)):
    os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat")
    
main()

