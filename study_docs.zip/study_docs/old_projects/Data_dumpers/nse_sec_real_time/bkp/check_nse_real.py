from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.proxy import Proxy,ProxyType
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options 
from selenium.common.exceptions import TimeoutException
from bs4 import BeautifulSoup
import datetime,os,logging
import pandas as pd 
from lxml import html
import requests
import numpy as np

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\nse_sec_real_time\\output\\'
email_dir='D:\\Emails\\Output\\'
key_dir='D:\\Data_dumpers\\nse_sec_real_time\\key\\'

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["stock","date","QT","DQ","%DQ"]

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1


def get_nse_secwise_real_time(symbol,d):
    output=''
    try:
        ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
        p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
        ip=ip+':'+p
        # Configure Proxy Option
        prox = Proxy()
        prox.proxy_type = ProxyType.MANUAL
            
        # Proxy IP & Port
        prox.http_proxy = ip
        prox.https_proxy = ip
            
        # Configure capabilities 
        capabilities = webdriver.DesiredCapabilities.CHROME
        prox.add_to_capabilities(capabilities)

        option = webdriver.ChromeOptions()
        option.add_argument('headless')
                   
        driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe",desired_capabilities=capabilities,chrome_options=option)    
        driver.get("https://www.nseindia.com/get-quotes/equity?symbol={}".format(symbol))
        
        soup=BeautifulSoup(driver.page_source, 'lxml')
        print "soup",soup
        h2=soup.find('h2').getText()
        date1=soup.find('span',{'id':'securityWiseDate'}).getText()
        label1=soup.find('label',{'id':'securityWiseQT'}).getText()
        label2=soup.find('label',{'id':'securityWiseDQ'}).getText()
        label3=soup.find('label',{'id':'securityWiseDQTQ'}).getText()
        output=[h2,date1,label1,label2,label3]
        
        print "output",output
        print "normal output",date1,label1,label2,label3
        if os.path.exists(output_dir+"nse_file_{}.txt".format(d.date())):
            file1 = open(output_dir+"nse_file_{}.txt".format(d.date()),"a") 
            l1=str(symbol.replace('%26','&') if '%26' in symbol else symbol) + "," + str(h2) + "," + str(date1) + "," + str(label1) + "," + str(label2) + "," + str(label3)
            file1.writelines(l1)
            file1.writelines("\n")
            file1.close()
        else:
            file1 = open(output_dir+"nse_file_{}.txt".format(d.date()),"w") 
            l1=str(symbol.replace('%26','&') if '%26' in symbol else symbol) + "," + str(h2) + "," + str(date1) + "," + str(label1) + "," + str(label2) + "," + str(label3)
            file1.writelines(l1)
            file1.writelines("\n")
            file1.close()
        driver.quit()
    except Exception as e:
        print 'Exception : {}'.format(e)
        driver.quit()
        
    return output

    
def main():
    d=datetime.datetime.now()
  
    
    nse_symbol=pd.read_excel(master_dir+'MasterData.xlsx')
    nse_symbol=nse_symbol.loc[nse_symbol["IsActiveFNO"]==True]
    nse_symbol=nse_symbol.loc[nse_symbol["Type"]=="SSF"]
    print "Fetching data for symbols {}".format(len(nse_symbol))
    nse_symbol.reset_index(drop=True,inplace=True)
    
    df=[]
    for i in range(len(nse_symbol["SYMBOL"])-130):
        df.append(get_nse_secwise_real_time(nse_symbol["SYMBOL"][i],d))
        
    df=pd.concat(df,columns=list)
    
main()   

