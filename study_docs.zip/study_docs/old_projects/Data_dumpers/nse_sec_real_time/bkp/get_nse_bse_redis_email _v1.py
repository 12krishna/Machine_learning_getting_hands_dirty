import time,datetime,os,shutil,logging,redis,sys
import pandas as pd 
#import schedule

redis_host = "localhost"
# redis_host = "10.223.104.61"
r = redis.Redis(host=redis_host, port=6379)

master_dir='D:\\Data_dumpers\\Master\\'
output_dir_nse='D:\\Data_dumpers\\nse_sec_real_time\\output\\'
output_dir_bse="D:\\Data_dumpers\\bse_sec_real_time\\output\\"
email_dir='D:\\Emails\\Output\\'
key_dir='D:\\Data_dumpers\\nse_sec_real_time\\key\\'

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["stock","date","QT","DQ","%DQ"]

f_list=["Symbol","Symbol_key","date","QT","DQ","%DQ"]

global f_df
f_df=pd.DataFrame(columns=f_list)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1
   

def get_data_redis(filename,d):
    
    if filename.startswith("nse"):   
    
        df = pd.DataFrame()
        for key in r.keys("{}*".format(filename)):
            print "Reading data from key {}".format(key)
            df=df.append(pd.read_msgpack(r.get(key)),ignore_index=True)
        df=df.applymap(str)  
            
        
        result = df[df['Symbol_key'].str.endswith('10')].drop(columns=['date','Symbol_key'])
        result.rename(columns={'QT':'QT_10','DQ':'DQ_10','%DQ':'%DQ_10'}, inplace=True)
        
        for i in ['11','12','13','14','15','16'] :
            result = result.merge( df[df['Symbol_key'].str.endswith(i)].drop(columns=['date','Symbol_key']),on='Symbol',how='left')
            result.rename(columns={'QT':'QT_{}'.format(i),'DQ':'DQ_{}'.format(i),'%DQ':'%DQ_{}'.format(i)}, inplace=True)
        
        columns = list(result.columns); columns.remove("Symbol")
             
        for col in columns:
            result[col] = result[col].str.replace('%','')
            result[col] = result[col].str.replace(',','')
            result[col] = pd.to_numeric(result[col], errors='coerce')           
           
        result.sort_values(by='Symbol', inplace=True)
        result.to_excel(output_dir_nse+"NSE_Security-wise Delivery Position_{}.xlsx".format(d.date()), index=False)
        return result
    
    elif filename.startswith("bse"):
        
        df = pd.DataFrame()
        for key in r.keys("{}*".format("bse_sec_realtime_data")):
            print "Reading data from key {}".format(key)
            df=df.append(pd.read_msgpack(r.get(key)),ignore_index=True)
 
        df=df.applymap(str)  
        df.reset_index(drop=True,inplace=True)
        df.rename(columns={'symbol_key':'Symbol_key','symbol':'Symbol'}, inplace=True)   

        result = df[df['Symbol_key'].str.endswith('10')].drop(columns=['date','Symbol_key','code','stock'])
        result.rename(columns={'QT':'QT_10','DQ':'DQ_10','%DQ':'%DQ_10'}, inplace=True)
       
        for i in ['11','12','13','14','15','16'] :
            result = result.merge( df[df['Symbol_key'].str.endswith(i)].drop(columns=['date','Symbol_key','code','stock']),on='Symbol',how='left')
            result.rename(columns={'QT':'QT_{}'.format(i),'DQ':'DQ_{}'.format(i),'%DQ':'%DQ_{}'.format(i)}, inplace=True)
        
        columns = list(result.columns); columns.remove("Symbol")
             
        for col in columns:
            result[col] = result[col].str.replace('%','')
            result[col] = result[col].str.replace(',','')
            result[col] = pd.to_numeric(result[col], errors='coerce')           
        
        result['Symbol'] = result['Symbol'].str.upper()
        result.sort_values(by='Symbol', inplace=True)
        result.to_excel(output_dir_bse+"BSE_Security-wise Delivery Position_{}.xlsx".format(d.date()), index=False)
        return result
        
        
        
        
    




def main():
    
    d=datetime.datetime.now()
      
    if process_run_check(d.date()) == -1:
        return -1 
    
    nse = get_data_redis("nse_sec_realtime_data",d)
    bse = get_data_redis("bse_sec_realtime_data",d)
    
    writer = pd.ExcelWriter(email_dir+'NSE_BSE_Security_delivery_position_{}.xlsx'.format(str(d.date())))
       
    nse.to_excel(writer,sheet_name = "NSE", index=False)
    bse.to_excel(writer, sheet_name = "BSE", index = False)
    writer.save()
    writer.close()
   
    
    
#    os.system("D:\\Emails\\Email.bat")
    
     
    
    
    
main()