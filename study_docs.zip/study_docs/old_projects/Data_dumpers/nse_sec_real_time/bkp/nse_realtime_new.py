import os,sys,os.path
import pandas as pd
import datetime,logging,time
#os.chdir('D:\\Data_dumpers\\nse_sec_real_time\\')
#sys.path.insert(0, 'D:\\Data_dumpers\\nse_sec_real_time\\')
#sys.path.insert(-1,"D:\Master\\")
#import redis

#redis_host = "localhost"
#redis_host = "10.223.104.65"
#r = redis.Redis(host=redis_host, port=6379)
#cassandra_host_list = ["172.17.9.51"]

master_dir='D:\\Data_dumpers\\Master\\'
#email_dir='D:\\Emails\\Output\\'
log_path="D:\\Data_dumpers\\nse_sec_real_time\\"


# define logging for the file system at debug or higher level
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    datefmt='%m-%d %H:%M',
                    filename=log_path+'nse_realtime.log')
#logging.basicConfig(level=logging.DEBUG, format='%(relativeCreated)6d %(threadName)s %(message)s')
# define a Handler which writes INFO messages or higher to the sys.stderr
console = logging.StreamHandler()
console.setLevel(logging.INFO)
# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)
logging.info("Start process")

   
def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        logging.info("Working day, open file and start process")
        
        # csv file in append mode to append data
        if not os.path.exists(r"\\172.17.9.21\Agent\Ojas Shah\Security delivery position\NSE_delivery_new{}.txt".format(datetime.datetime.now().date())):
            output_file = open(r"\\172.17.9.21\Agent\Ojas Shah\Security delivery position\NSE_delivery_new{}.txt".format(datetime.datetime.now().date()), 'ab')
            output_file.write("Symbol,traded_date,traded_time,QT,DQ,pc_DQ_TQ,avg_price\n")  # header
            output_file.flush()
            output_file.close()        
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

    
def main():
    
    if process_run_check(datetime.datetime.now().date()) == -1:
        return -1 
            
    for i in range (10,16):
        while True:                
            if datetime.datetime.now().time() > datetime.time(i,0):
                logging.info("Fetch data for instance time {}".format(datetime.time(i,0)))
                os.system("D:\\Data_dumpers\\nse_sec_real_time\\main.bat")
                logging.info("in turn call fetch1,2,3")
                break
            else:
                print "Sleep until next event time is triggered"
                time.sleep(45)
                    

if __name__=='__main__':
    main()

