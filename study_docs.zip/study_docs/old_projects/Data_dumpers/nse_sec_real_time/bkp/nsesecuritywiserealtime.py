from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime,os,shutil,logging,redis,sys
import pandas as pd 
#import schedule

redis_host = "localhost"
# redis_host = "10.223.104.61"
r = redis.Redis(host=redis_host, port=6379)

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\nse_sec_real_time\\output\\'
email_dir='D:\\Emails\\Output\\'
key_dir='D:\\Data_dumpers\\nse_sec_real_time\\key\\'

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["stock","date","QT","DQ","%DQ"]

f_list=["Symbol","Symbol_key","date","QT","DQ","%DQ"]

global f_df
f_df=pd.DataFrame(columns=f_list)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1


def get_nse_secwise_real_time(symbol,d):
    output=''
    try:
#        option = webdriver.ChromeOptions()
#        option.add_argument('headless')
                
        driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe")    
        driver.get("https://www.nseindia.com/get-quotes/equity?symbol={}".format(symbol))

#        try:
#            driver.find_element_by_xpath('//*[@id="info-tradeinfo"]/div/div[2]').click()
#        except NoSuchElementException:  #spelling error making this code not work as expected
#            pass
#            driver.quit()
#
#        WebDriverWait(driver,30).until(ec.visibility_of_element_located((By.XPATH,'//*[@id="info-tradeinfo"]/div/div[2]')))

        soup=BeautifulSoup(driver.page_source, 'lxml')
        
        h2=soup.find('h2').getText()
        date1=soup.find('span',{'id':'securityWiseDate'}).getText()
        label1=soup.find('label',{'id':'securityWiseQT'}).getText()
        label2=soup.find('label',{'id':'securityWiseDQ'}).getText()
        label3=soup.find('label',{'id':'securityWiseDQTQ'}).getText()
        output=[h2,date1,label1,label2,label3]
        
        print "output",output
        print "normal output",date1,label1,label2,label3
        if os.path.exists(output_dir+"nse_file_{}.txt".format(d.date())):
            file1 = open(output_dir+"nse_file_{}.txt".format(d.date()),"a") 
            l1=str(symbol.replace('%26','&') if '%26' in symbol else symbol) + "," + str(h2) + "," + str(date1) + "," + str(label1) + "," + str(label2) + "," + str(label3)
            file1.writelines(l1)
            file1.writelines("\n")
            file1.close()
        else:
            file1 = open(output_dir+"nse_file_{}.txt".format(d.date()),"w") 
            l1=str(symbol.replace('%26','&') if '%26' in symbol else symbol) + "," + str(h2) + "," + str(date1) + "," + str(label1) + "," + str(label2) + "," + str(label3)
            file1.writelines(l1)
            file1.writelines("\n")
            file1.close()

    except Exception as e:
        print 'Exception : {}'.format(e)
        
        
    return output

def get_data_symbols(d,dt):
    
    print "hour",d.strftime('%H')
    date_d=d.strftime('%H:%M:%S')
    print dt
    print date_d
    while date_d < dt:
        
        r_df=pd.read_msgpack(r.get('nse_sec_realtime_data'))
        r_df=r_df.applymap(str)
        hourly_df=r_df.loc[r_df["Symbol_key"].str.endswith('{}'.format(d.strftime('%H')))] # curr hour data
        hourly_df.reset_index(drop=True,inplace=True)
        check=hourly_df["DQ"].isin(['-']).any().any()
        print "check",check
        if check==True:
            n_df=hourly_df.loc[hourly_df["DQ"]=='-']
            print "Getting data for {} symbols".format(len(n_df))
            n_df.sort_values(by='Symbol', inplace=True)
            for col,row in n_df.iterrows():
                df=[]
                temp = get_nse_secwise_real_time(row["Symbol"].replace('&','%26') if '&' in row["Symbol"] else row["Symbol"],d)
                if temp!='':
                    df.append(temp)
                    df=pd.DataFrame(df,columns=list1)
                    final_df=pd.concat([df])
                    final_df.columns=list1
                    final_df.reset_index(drop=True,inplace=True)
                    row["date"] = final_df['date'][0]
                    row["QT"] = final_df['QT'][0]
                    row["DQ"] = final_df['DQ'][0]
                    row["%DQ"] = final_df['%DQ'][0]
            
    
            r_df = pd.concat([n_df,r_df[~r_df['Symbol_key'].isin(n_df['Symbol_key'].values)]], axis=0)
           
            
            
            r_df.sort_values(by='Symbol_key', inplace=True)
            r.set('nse_sec_realtime_data',r_df.to_msgpack(compress='zlib'))
            logging.info("data stored in redis success")

        else:
            print "Data scraped for all symbols; Sleep for 30 sec"
            time.sleep(30)
        d = datetime.datetime.now()
        print "hour",d.strftime('%H')
        date_d=d.strftime('%H:%M:%S')
        print dt
        print date_d    
    


def create_redis_dict():
    num=['10','11','12','13','14','15','16']
    
#    dt=['11:10:00','12:10:00','13:10:00','14:10:00','15:10:00','16:10:00']
    
    symbol_key=[]
    
    nse_symbol=pd.read_excel(master_dir+'MasterData.xlsx')
    nse_symbol=nse_symbol.loc[nse_symbol["IsActiveFNO"]==True]
    nse_symbol=nse_symbol.loc[nse_symbol["Type"]=="SSF"]
    print "Fetching data for symbols {}".format(len(nse_symbol))
    nse_symbol.reset_index(drop=True,inplace=True)
    nse_symbol.rename(columns={"SYMBOL":"Symbol"},inplace=True)
    
    for i in range(len(num)):
        for j in range(len(nse_symbol["Symbol"])):
            val=nse_symbol["Symbol"][j]+'_'+num[i]
            symbol_key.append(val)
                
    symbol=pd.DataFrame(symbol_key,columns=["Symbol"])
    symbol=symbol["Symbol"].str.split('_',expand=True)
    symbol.rename(columns={0:'Symbol',1:'k_num'},inplace=True)
    symbol["Symbol_key"]=symbol_key
    f_df["Symbol"]=symbol["Symbol"]
    f_df["Symbol_key"]=symbol["Symbol_key"]
    f_df.fillna("-", inplace=True)
#    d_df=f_df[:4]
    r.set('nse_sec_realtime_data',f_df.to_msgpack(compress='zlib'))
        
       
    
    
def main():

    d=datetime.datetime.now() # -datetime.timedelta(hours=1)
        
    if process_run_check(d.date()) == -1:
        return -1 
    
    create_redis_dict()  # create entire dict for day in redis
    logging.info("data stored in redis success")
#    for i in range(len(dt)):
    dt='17:00:00'
    
    
    get_data_symbols(d,dt)  # keep updating data till market close
    
main()

