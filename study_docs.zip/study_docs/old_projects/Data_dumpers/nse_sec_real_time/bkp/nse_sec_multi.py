from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime,os,shutil,logging,redis,sys,threading
import pandas as pd 
#import schedule

redis_host = "localhost"
# redis_host = "10.223.104.61"
r = redis.Redis(host=redis_host, port=6379)

master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\Data_dumpers\\nse_sec_real_time\\output\\'
email_dir='D:\\Emails\\Output\\'
key_dir='D:\\Data_dumpers\\nse_sec_real_time\\key\\'

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

list1=["stock","date","QT","DQ","%DQ"]

f_list=["Symbol","Symbol_key","date","QT","DQ","%DQ"]

global f_df
f_df=pd.DataFrame(columns=f_list)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1


def get_nse_secwise_real_time(symbol,d):
    try:
#        option = webdriver.ChromeOptions()
#        option.add_argument('headless')
                
        driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe")    
        driver.get("https://www.nseindia.com/get-quotes/equity?symbol={}".format(symbol))
        # set window size
#        driver.set_window_size(398,134)
#        print driver.get_window_size()
        try:
            driver.find_element_by_xpath('//*[@id="info-tradeinfo"]/div/div[2]').click()
        except NoSuchElementException:  #spelling error making this code not work as expected
            pass
            driver.quit()

        WebDriverWait(driver,30).until(ec.visibility_of_element_located((By.XPATH,'//*[@id="info-tradeinfo"]/div/div[2]')))

        soup=BeautifulSoup(driver.page_source, 'lxml')
        
        h2=soup.find('h2').getText()
        date1=soup.find('span',{'id':'securityWiseDate'}).getText()
        label1=soup.find('label',{'id':'securityWiseQT'}).getText()
        label2=soup.find('label',{'id':'securityWiseDQ'}).getText()
        label3=soup.find('label',{'id':'securityWiseDQTQ'}).getText()
        output=[h2,date1,label1,label2,label3]
        
        print "output",output
        print "normal output",date1,label1,label2,label3
        if os.path.exists(output_dir+"nse_file_{}.txt".format(d.date())):
            file1 = open(output_dir+"nse_file_{}.txt".format(d.date()),"a") 
            l1=str(symbol) + "," + str(h2) + "," + str(date1) + "," + str(label1) + "," + str(label2) + "," + str(label3)
            file1.writelines(l1)
            file1.writelines("\n")
            file1.close()
        else:
            file1 = open(output_dir+"nse_file_{}.txt".format(d.date()),"w") 
            l1=str(symbol) + "," + str(h2) + "," + str(date1) + "," + str(label1) + "," + str(label2) + "," + str(label3)
            file1.writelines(l1)
            file1.writelines("\n")
            file1.close()

    finally:
        driver.quit()
        
    return output

def get_data_symbols1(d,dt):
    print "hour",d.strftime('%H')
    date_d=d.strftime('%H:%M:%S')
    print dt
    print date_d
    while date_d < dt:
        
        r_df=pd.read_msgpack(r.get('key_nse_sec_real_time_dev'))
        r_df=r_df.applymap(str)
        r_df=r_df.loc[r_df["Symbol_key"].str.endswith('{}'.format(d.strftime('%H')))][:50]
        r_df.reset_index(drop=True,inplace=True)
        print"///////////DATA////////"
        check=r_df["DQ"].isin(['-']).any().any()
        print "check",check
        if check==True:
            n_df=r_df.loc[r_df["DQ"]=='-']
            for col,row in n_df.iterrows():
                df=[]
                df.append(get_nse_secwise_real_time(row["Symbol"],d))
                df=pd.DataFrame(df,columns=list1)
                final_df=pd.concat([df])
                final_df.columns=list1
                final_df.reset_index(drop=True,inplace=True)
                row["date"] = final_df['date'][0]
                row["QT"] = final_df['QT'][0]
                row["DQ"] = final_df['DQ'][0]
                row["%DQ"] = final_df['%DQ'][0]
            
            r_df.update(n_df)
                
            r.set('key_nse_sec_real_time_dev',r_df.to_msgpack(compress='zlib'))
            logging.info("data stored in redis success")

        else:
            for col,row in r_df.iterrows():
                df=[]
                df.append(get_nse_secwise_real_time(row["Symbol"],d))
                df=pd.DataFrame(df,columns=list1)
                final_df=pd.concat([df])
                final_df.columns=list1
                final_df.reset_index(drop=True,inplace=True)
                row["date"] = final_df['date'][0]
                row["QT"] = final_df['QT'][0]
                row["DQ"] = final_df['DQ'][0]
                row["%DQ"] = final_df['%DQ'][0]
        
            r.set('key_nse_sec_real_time_dev',r_df.to_msgpack(compress='zlib'))
            logging.info("data stored in redis success")

        
        r_df=pd.read_msgpack(r.get('key_nse_sec_real_time_dev'))
        check1=r_df["DQ"].isin(['-']).any().any()
        if check1==False:
            print "check1",check
            print "done1"
#            return -1
       
def get_data_symbols2(d,dt):
    print "hour",d.strftime('%H')
    date_d=d.strftime('%H:%M:%S')
    print dt
    print date_d
    while date_d < dt:
        
        r_df=pd.read_msgpack(r.get('key_nse_sec_real_time_dev'))
        r_df=r_df.applymap(str)
        r_df=r_df.loc[r_df["Symbol_key"].str.endswith('{}'.format(d.strftime('%H')))][50:100]
        r_df.reset_index(drop=True,inplace=True)
        print"///////////DATA////////"
        check=r_df["DQ"].isin(['-']).any().any()
        print "check",check
        if check==True:
            n_df=r_df.loc[r_df["DQ"]=='-']
            for col,row in n_df.iterrows():
                df=[]
                df.append(get_nse_secwise_real_time(row["Symbol"],d))
                df=pd.DataFrame(df,columns=list1)
                final_df=pd.concat([df])
                final_df.columns=list1
                final_df.reset_index(drop=True,inplace=True)
                row["date"] = final_df['date'][0]
                row["QT"] = final_df['QT'][0]
                row["DQ"] = final_df['DQ'][0]
                row["%DQ"] = final_df['%DQ'][0]
            
            r_df.update(n_df)
                
            r.set('key_nse_sec_real_time_dev',r_df.to_msgpack(compress='zlib'))
            logging.info("data stored in redis success")

        else:
            for col,row in r_df.iterrows():
                df=[]
                df.append(get_nse_secwise_real_time(row["Symbol"],d))
                df=pd.DataFrame(df,columns=list1)
                final_df=pd.concat([df])
                final_df.columns=list1
                final_df.reset_index(drop=True,inplace=True)
                row["date"] = final_df['date'][0]
                row["QT"] = final_df['QT'][0]
                row["DQ"] = final_df['DQ'][0]
                row["%DQ"] = final_df['%DQ'][0]
        
            r.set('key_nse_sec_real_time_dev',r_df.to_msgpack(compress='zlib'))
            logging.info("data stored in redis success")

        
        r_df=pd.read_msgpack(r.get('key_nse_sec_real_time_dev'))
        check1=r_df["DQ"].isin(['-']).any().any()
        if check1==False:
            print "check1",check
            print "done2"
#            return -1
        
def get_data_symbols3(d,dt):
    print "hour",d.strftime('%H')
    date_d=d.strftime('%H:%M:%S')
    print dt
    print date_d
    while date_d < dt:
        
        r_df=pd.read_msgpack(r.get('key_nse_sec_real_time_dev'))
        r_df=r_df.applymap(str)
        r_df=r_df.loc[r_df["Symbol_key"].str.endswith('{}'.format(d.strftime('%H')))][100:]
        r_df.reset_index(drop=True,inplace=True)
        print"///////////DATA////////"
        print "DATA FETCHED FROM REDIS",r_df
        check=r_df["DQ"].isin(['-']).any().any()
        print "check",check
        if check==True:
            n_df=r_df.loc[r_df["DQ"]=='-']
            for col,row in n_df.iterrows():
                df=[]
                df.append(get_nse_secwise_real_time(row["Symbol"],d))
                df=pd.DataFrame(df,columns=list1)
                final_df=pd.concat([df])
                final_df.columns=list1
                final_df.reset_index(drop=True,inplace=True)
                row["date"] = final_df['date'][0]
                row["QT"] = final_df['QT'][0]
                row["DQ"] = final_df['DQ'][0]
                row["%DQ"] = final_df['%DQ'][0]
            
            r_df.update(n_df)
                
            r.set('key_nse_sec_real_time_dev',r_df.to_msgpack(compress='zlib'))
            logging.info("data stored in redis success")

        else:
            for col,row in r_df.iterrows():
                df=[]
                df.append(get_nse_secwise_real_time(row["Symbol"],d))
                df=pd.DataFrame(df,columns=list1)
                final_df=pd.concat([df])
                final_df.columns=list1
                final_df.reset_index(drop=True,inplace=True)
                row["date"] = final_df['date'][0]
                row["QT"] = final_df['QT'][0]
                row["DQ"] = final_df['DQ'][0]
                row["%DQ"] = final_df['%DQ'][0]
        
            r.set('key_nse_sec_real_time_dev',r_df.to_msgpack(compress='zlib'))
            logging.info("data stored in redis success")

        
        r_df=pd.read_msgpack(r.get('key_nse_sec_real_time_dev'))
        check1=r_df["DQ"].isin(['-']).any().any()
        if check1==False:
            print "check1",check
            print "done3"
#            return -1
    
def main():

    d=datetime.datetime.now()#-datetime.timedelta(hours=9)
        
    if process_run_check(d.date()) == -1:
        return -1 
    
    num=['10','11','12','13','14','15','16']
    
#    dt=['11:10:00','12:10:00','13:10:00','14:10:00','15:10:00','16:10:00']
    
    symbol_key=[]
    
    nse_symbol=pd.read_excel(master_dir+'nse_sec_MasterData.xlsx')
    nse_symbol=nse_symbol.loc[nse_symbol["IsActiveFNO"]==True]
    nse_symbol=nse_symbol.loc[nse_symbol["Type"]=="SSF"]
    print "Fetching data for symbols {}".format(len(nse_symbol))
    nse_symbol.reset_index(drop=True,inplace=True)
    nse_symbol.rename(columns={"SYMBOL":"Symbol"},inplace=True)
    
    for i in range(len(num)):
        for j in range(len(nse_symbol["Symbol"])):
            val=nse_symbol["Symbol"][j]+'_'+num[i]
            symbol_key.append(val)
                
    symbol=pd.DataFrame(symbol_key,columns=["Symbol"])
    symbol=symbol["Symbol"].str.split('_',expand=True)
    symbol.rename(columns={0:'Symbol',1:'k_num'},inplace=True)
    symbol["Symbol_key"]=symbol_key
    f_df["Symbol"]=symbol["Symbol"]
    f_df["Symbol_key"]=symbol["Symbol_key"]
#    d_df=f_df[:4]
    r.set('key_nse_sec_real_time_dev',f_df.to_msgpack(compress='zlib'))
    logging.info("data stored in redis success")
#    for i in range(len(dt)):
    dt='16:10:00'
    
    t1 = threading.Thread(target=get_data_symbols1, args=(d,dt))
    t2 = threading.Thread(target=get_data_symbols2, args=(d,dt))
    t3 = threading.Thread(target=get_data_symbols3, args=(d,dt))

    # starting thread 1 
    t1.start() 
    # starting thread 2 
    t2.start() 
       # starting thread 2 
    t3.start() 
    
    # wait until thread 1 is completely executed 
    t1.join() 
    # wait until thread 2 is completely executed 
    t2.join() 
    # wait until thread 2 is completely executed 
    t3.join()
    
    # both threads completely executed 
    print("Done!") 
    
main()

