import pandas as pd
import datetime,time,logging,requests,sys
from pandas.io.json import json_normalize

master_dir='D:\\Data_dumpers\\Master\\'
log_path="D:\\Data_dumpers\\nse_sec_real_time\\New folder\\"

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    datefmt='%m-%d %H:%M',
                    filename=log_path+'nse_realtime.log')

console = logging.StreamHandler()
console.setLevel(logging.INFO)
# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)
logging.info("Start process")

def fetch_nse(symbol):
    output=''
    try:
        headers= {'Accept': '*/*',
                  'Accept-Language': 'en-US,en;q=0.5',
                  'Host': 'www.nseindia.com',
                  'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:28.0) Gecko/20100101 Firefox/28.0',
                  'X-Requested-With': 'XMLHttpRequest'
                }
        url2='https://www.nseindia.com/api/quote-equity?symbol={}&section=trade_info'.format(symbol)
        logging.info("url: {}".format(url2))

        res = requests.get(url2,headers=headers)
        logging.info("status code: {}".format(res))
        soup=res.json()
        df=json_normalize(soup['securityWiseDP']).assign(**soup['securityWiseDP']) #to fetch all quantity
        df.reset_index(drop=True,inplace=True)
        df1=json_normalize(soup["marketDeptOrderBook"]["ask"][0]).assign(**soup["marketDeptOrderBook"]["ask"][0]) # to fetch average from ask 
        df.reset_index(drop=True,inplace=True)
        output=[symbol,df["quantityTraded"][0],df["deliveryQuantity"][0],df["deliveryToTradedQuantity"][0],df1["price"][0]]
        logging.info("data {} fetched".format(output))

    except Exception as e:
        print('Exception : {}'.format(e))
        logging.info('Exception : {}'.format(e))
    
    return output
            
def get_data(symbols):
    e=datetime.datetime.now()+datetime.timedelta(minutes=55)
    while len(symbols)!=0:
        for stocks in symbols:
            if datetime.datetime.now()>e:
                sys.exit(1)
#            print("symbol",stocks)
            data=fetch_nse(stocks)
#            print("data received",data)
            if data!='':
                d=datetime.datetime.now().time()
                d=d.strftime("%H:00:00")
                final_list=','.join([data[0],str(datetime.datetime.now().date()),d,str(data[1]),str(data[2]),str(data[3]),str(data[4])])+"\n"
#                print("data fetched for {}".format(stocks))
                logging.info("data fetched {}".format(stocks))
#                print("final data",final_list)
                output_file = open(r"\\172.17.9.21\Agent\Ojas Shah\Security delivery position\NSE_delivery_{}.txt".format(datetime.datetime.now().date()), 'a+')
                output_file.writelines(final_list)
                output_file.flush()
                output_file.close()
                symbols.remove(stocks)
                print("symbols left",symbols)
                logging.info("symbols left {}".format(symbols))
            else:
                print("data not fetched for {}".format(stocks))
                logging.info("symbols not fetched")

          
def main():
    
    starttime=time.time()
    df=pd.read_excel('MasterData.xlsx')
    df=df[(df["IsActiveFNO"]==True) & (df["Type"]=="SSF")]
    df['SYMBOL'] = df['SYMBOL'].astype(str)
    df['SYMBOL'] = df['SYMBOL'].str.strip()
    symbols = list(sorted(df['SYMBOL'].tolist()))
    output_file = open(r"NSE_delivery_{}.txt".format(datetime.datetime.now().date()), 'a+')
    output_file.write("Symbol,traded_date,traded_time,QT,DQ,pc_DQ_TQ,avg_price\n")
    get_data(symbols)
    print('That took {} seconds'.format(time.time() - starttime))
    logging.info("full process completed")
    logging.info('That took {} seconds'.format(time.time() - starttime))
    
main()
