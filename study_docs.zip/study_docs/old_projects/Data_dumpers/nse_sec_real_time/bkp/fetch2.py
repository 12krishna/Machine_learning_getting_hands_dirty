import pandas as pd
import re,datetime,time
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.common.proxy import Proxy,ProxyType
import multiprocessing
import logging

master_dir='D:\\Data_dumpers\\Master\\'
log_path="D:\\Data_dumpers\\nse_sec_real_time\\"


# define logging for the file system at debug or higher level
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    datefmt='%m-%d %H:%M',
                    filename=log_path+'nse_realtime.log')

console = logging.StreamHandler()
console.setLevel(logging.INFO)
# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)
logging.info("Start process")


def fetch_nse(symbol):
    output=''
    driver=''
    try:
        ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
        p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
        ip=ip+':'+p
        url2='https://www.nseindia.com/get-quotes/equity?symbol={}&illiquid=0&smeFlag=0&itpFlag=0'.format(symbol)
        print("url",url2)
        logging.info("url: {}".format(url2))
        prox = Proxy()
        prox.proxy_type = ProxyType.MANUAL
        prox.http_proxy = ip
        prox.https_proxy = ip    
        capabilities = webdriver.DesiredCapabilities.CHROME
        prox.add_to_capabilities(capabilities)
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('disable-infobars')
        options.add_argument('--disable-extensions')
        options.add_argument('authority=nseindia.com')
        options.add_argument('dnt=1')
        options.add_argument('Host=www.nseindia.com')
        options.add_argument('upgrade-insecure-requests=1')
        options.add_argument('user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36')
        options.add_argument('accept=text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9')
        options.add_argument( 'Accept=*/*' )
        options.add_argument('sec-fetch-site=none')
        options.add_argument('sec-fetch-mode=navigate')
        options.add_argument('sec-fetch-user=?1')
        options.add_argument('sec-fetch-dest=document')
        options.add_argument('accept-language=en-GB,en-US;q=0.9,en;q=0.8')
        options.add_argument('X-Requested-With=XMLHttpRequest')            
        driver = webdriver.Chrome(master_dir+"chromedriver.exe",options=options,desired_capabilities=capabilities)
        driver.get(url2)
        content = driver.page_source
        soup=BeautifulSoup(content, 'html.parser')            
        avgp=soup.find('span',{'id':'quoteLtp'}).getText()           
        label1=soup.find('label',{'id':'securityWiseQT'}).getText()
        label2=soup.find('label',{'id':'securityWiseDQ'}).getText()
        label3=soup.find('label',{'id':'securityWiseDQTQ'}).getText()
        avgp=re.sub(r"[\s+]","",avgp).replace('-','').replace(',','')
        label1=re.sub(r"[\s+]","",label1).replace('-','').replace(',','')
        label2=re.sub(r"[\s+]","",label2).replace('-','').replace(',','') 
        label3=re.sub(r"[\s+]","",label3).replace('-','').replace(',','').replace('%','')
        if avgp=='' or label1=='' or label2=='' or label3=='':
            print("yes they are empty")
        else:
            print("information for stock fetched")
            logging.info("information for the stock {} fetched".format(symbol))
            output=[symbol,label1,label2,label3,avgp]      
    
    except Exception as e:
        print('Exception : {}'.format(e))
        logging.info('Exception : {}'.format(e))
        try:
            driver.delete_all_cookies()
            driver.refresh()
            driver.quit()
        except Exception as e:
            print('Exception 1 : {}'.format(e))  
            logging.info('Exception 1 : {}'.format(e))    
    driver.delete_all_cookies()
    driver.refresh()
    driver.quit()
    return output
            
def get_data(symbols):
    while len(symbols)!=0:
        try:
            for stocks in symbols:
                print("symbol",stocks)
                data=fetch_nse(stocks)
                print("data received",data)
                logging.info("data received",data)
                if data!='':
                    final_list=','.join([data[0],str(datetime.datetime.now().date()),str(datetime.datetime.now().time()),data[1],data[2],data[3],data[4]])+"\n"
                    print("data fetched for {}".format(stocks))
                    logging.info("data fetched {}".format(stocks))
                    print("final data",final_list)
                    output_file = open(r"\\172.17.9.21\Agent\Ojas Shah\Security delivery position\NSE_delivery_new{}.txt".format(datetime.datetime.now().date()), 'a+')
                    output_file.writelines(final_list)
                    output_file.flush()
                    output_file.close()
                    symbols.remove(stocks)
                    print("symbols left",symbols)
                    logging.info("symbols left {}".format(symbols))
                else:
                    print("data not fetched for {}".format(stocks))
                    logging.info("symbols not fetched")
        except Exception as e:
            print("internet Exception {}".format(e))
            logging.info("connection error {}".format(e))
           

def main():
    
    starttime=time.time()
    df=pd.read_excel(master_dir+'MasterData.xlsx')
    df=df[(df["IsActiveFNO"]==True) & (df["Type"]=="SSF")]
    df['SYMBOL'] = df['SYMBOL'].astype(str)
    df['SYMBOL'] = df['SYMBOL'].str.strip()
    symbols = list(sorted(df['SYMBOL'].tolist()))
    symbols=symbols[50:100]
#    output_file = open(r"NSE_delivery_{}.txt".format(datetime.datetime.now().date()), 'a+')
#    output_file.write("Symbol,traded_date,traded_time,QT,DQ,pc_DQ_TQ,avg_price\n")
    n=10
    fn=[symbols[i:i + n] for i in range(0, len(symbols), n)]
    pr = []
    for i in fn:
        print("symbols scraped",i)
        for j in range(0,2):
            p = multiprocessing.Process(target=get_data(i))
            pr.append(p)
            p.start()
        
        for pr in pr:
            pr.join()
        
    print('That took {} seconds'.format(time.time() - starttime))
    logging.info("full process completed")
    logging.info('That took {} seconds'.format(time.time() - starttime))
    
main()