import pandas as pd
#from tabulate import tabulate
import re,os,datetime,time,sys
from lxml import html
from cassandra.cluster import Cluster
import numpy as np
import redis
import gzip
import shutil
import subprocess 
import pysftp
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None  


os.chdir("D:\\Data_dumpers\\USD_INR\\")
redis_host = 'localhost'

cassandra_host = "172.17.9.51"
master_dir = "D:\\Data_dumpers\\Master\\"
processed_dir = "D:\\Data_dumpers\\USD_INR\\Processed\\"

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)


def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


# get USD INR daily file from bloomberg SFTP
def file_downloader(d):
    '''Func to download file from ftp'''
    
    # read holiday master
    holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                date_parser=dateparse, parse_dates={'date':[0]})       
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)    
    filename = 'getsnap_inr_daily.csv.{}'.format( ''.join(str(d).split("-")) )
    
    if d in list(holiday_master['date'].values):
        print '{} is holiday ; hence skip dumping'.format(d)
        return -1
    else:
        print '{} is working day; hence downloading file from SFTP'.format(d)
        while 1:
            try:
                with pysftp.Connection('sftp.bloomberg.com', username='dl789941', password='+cf,QPwXjKeG3M,N', cnopts=cnopts) as sftp:
                    print filename
                    sftp.get(filename)
        	    
                    print 'Success: File downlaoded'
        			# unzipp file 
                    try:	
                        
                        with open(filename,'r') as f_in, open('getsnap_inr_daily.csv','w') as f_out:
        
                            shutil.copyfileobj(f_in, f_out) 
                            f_in.close()
                            f_out.close()
                            print 'Success'
                            os.remove('getsnap_inr_daily.csv.{}'.format( ''.join(str(d).split("-")) ))
                        break    
                    except Exception as e:
                        print 'Excpetion ',e
            except IOError:
                print "File not found; sleep for 30 seconds before re-attempting"
                time.sleep(30)
            except Exception as e:
                print e
                
             
            
        

def main(d):
     
    if file_downloader(d)!=-1:
        
        
        usd_inr = open("getsnap_inr_daily.csv", 'r').readlines()
        date = pd.to_datetime(' '.join([ x for x in usd_inr if x.startswith("RUNDATE") ]).split("=")[1].strip("\n")).date()
        usd_inr = round(float(' '.join([ x for x in usd_inr if x.startswith("USDINR Curncy") ]).split("|")[5]),2)
        
        usd_inr = pd.DataFrame([[date, usd_inr]], columns=['date','usd_inr'])
        usd_inr.to_csv("usd_inr.csv", index=False)
        
        # dump to cassandra
        # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
        #cluster = Cluster([cassandra_host])
        cluster = cassandra_configs_cluster()

        # connect to your keyspace and create a session using which u can execute cql commands 
        session = cluster.connect('rohit')
        # CREATE A TABLE; dump bhavcopies to this table
        #define rows fetched from cassandra to be a pandas dataframe
        session.row_factory = pandas_factory
        session.default_fetch_size = None        
        
        session.execute('CREATE TABLE IF NOT EXISTS bloom_usd_inr (date DATE, usd_inr DECIMAL , PRIMARY KEY (date))')
        
        os.system("usd_inr.bat")
        shutil.move("getsnap_inr_daily.csv", processed_dir+"getsnap_inr_daily_{}.csv".format(d))
        #os.remove("getsnap_inr_daily.csv")
        
        r = redis.Redis(host=redis_host, port=6379) 
        r.set("bloom_usd_inr",1)
        
        # remarks of last updated record in cassandra 
        checker = session.execute("select * from bloom_usd_inr where date >= '{}' allow filtering".format(d-datetime.timedelta(days=10)))
        checker = checker._current_rows
        
        checker['date'] = checker['date'].apply(lambda row: row.date())
        checker.sort_values(by='date', inplace=True)
        
        r.set('bloom_usd_inr_remarks','USD INR updated for {}'.format(checker.tail(1)['date'].values[0]))
        
        

main(d = datetime.datetime.now().date()-datetime.timedelta(days=0))   # set date range here 


