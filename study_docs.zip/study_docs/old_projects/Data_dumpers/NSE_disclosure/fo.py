# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 18:41:57 2022

@author: backup
"""

import numpy as np
import time    
import pandas as pd  
import os
import sys
pd.options.display.float_format = '${:,.2f}'.format
data_dir=r'\\172.17.9.22\Users\krishna\geeta\order_trade\ORD'

user_id=pd.read_csv(os.path.join(data_dir,"Client_ctcl_codes.csv"))
nse_id=user_id['NSE-FO']

def reading_order_trade_files(date,nse_id):
        df4 = pd.read_csv(os.path.join(data_dir,"FO_ORD_LOG_{}_08081.CSV.gz".format(date)), compression='gzip')#,chunksize=1000000)
        
        
        
        
        df4.columns =['Trading_Member_ID', 'Branch_ID', 'User_ID', 'Market_Type', 'Book_Type', \
                     'OnStop_Indicator', 'Order_Number', 'Buy_Sell_Indicator', 'Instrument_Name', 'Symbol', 'Expiry_Date', \
                    'Strike_Price','Option_Type varchar', 'Volume_Original', 'Volume_Disclosed', 'Volume_Disclosed_Remaining', 'Min_Fill_All_Or_None', \
                    'Market_Price_Indicator', 'Limit_Price', 'Trigger_Price', 'Pro_Cli_Indicator', 'Client_AC_Number', 'Open_Close_Indicator',\
                    'Volume_Remaining', 'Special_Term', 'Good_Till_Date', 'Day_Indicator', 'Participant_Id', \
                    'Time', 'Activity_Type', 'Location_ID']# 'Serial_No'])
        
        #sample=df4.head(10000)
        
        
        df4.info()
        
        
        #df1_alphnum=df1[df1['Client_AC_Number'].str.isnumeric==True]
        df4['Limit_Price']=pd.to_numeric(df4['Limit_Price'], errors='coerce').fillna(0.0,downcast='infer')
        
        #print(type(df4["Limit_Price"].values[0]))
        
        non_numeric_columns = list(set(df4.columns)-set(df4._get_numeric_data().columns))
        for i in non_numeric_columns:
            df4[i] = df4[i].apply(lambda x : str(x).strip()) 
               
            
#        user_id=pd.read_csv(os.path.join(data_dir,"Client_ctcl_codes.csv"))
#        nse_id=user_id['NSE-FO']
           
        bkc_df=df4[df4['User_ID'].isin(nse_id.tolist())]
        bkc_df['Instrument_Name'].unique()
        bkc_df['Option_Type varchar'][bkc_df['Instrument_Name']=='FUTSTK']='XX'
        bkc_df['Option_Type varchar'][bkc_df['Instrument_Name']=='FUTIDX']='XX'
        
        d1=date[4:8]+"-"+date[2:4]+"-"+date[0:2]
        cm_trade=pd.read_csv(os.path.join(data_dir,"nsefo_bkcapi_{}.txt".format(d1)),sep=',',skiprows=None,header=None)
        #cm_trade=pd.read_csv(os.path.join(data_dir,"nsefo_bkcapi.txt"),sep=',',skiprows=None,header=None)
        
        cm_trade.columns=["TradeId","TradeStatus","InstrumentType","Symbol","Expiry","StrikePrice",
                                           "CallOrPut","TradingSymbol","Book_type","Book_type_name","Market_type",
                                           "UserId","Branch_id","Side","Quantity","Average","Pro_Client","Account",
                                           "Participant","Open_close_flag","Uncover_flag","Order_entry_time","Trade_time",
                                           "Exchange_Order_Id","CpCode","Order_entry_time1","CTCL code"]
        
        
        cm_trade = cm_trade[cm_trade['TradeStatus']==11]
        
        cm_trade=cm_trade[cm_trade['UserId'].isin(nse_id.tolist())]
        non_numeric_columns = list(set(cm_trade.columns)-set(cm_trade._get_numeric_data().columns))
        for i in non_numeric_columns:
            cm_trade[i] = cm_trade[i].apply(lambda x : str(x).strip())  
         
        
        cm_trade["InstrumentType"].unique()
        cm_trade["CallOrPut"][cm_trade["InstrumentType"]=='FUTSTK']='XX'
        cm_trade["CallOrPut"][cm_trade["InstrumentType"]=='FUTIDX']='XX'
        
        #import datetime
        #cm_trade["CallOrPut"].unique()
        #cm_trade["Expiry"] = cm_trade.apply(lambda row: datetime.datetime.strptime(row["Expiry"],"%d-%b-%Y").date(),axis=1)
        cm_trade["Expiry"] = cm_trade["Expiry"].apply(lambda x: x[:2]+"-"+ x[2:5].title()+"-"+x[-2:])
        return bkc_df,cm_trade
#cm_trade["StrikePrice"].isnull().sum()
#cm_trade["StrikePrice"].fillna(0.0)
#cm_trade.info()

def order_handling(grp):
    
    new_ord=grp[grp['Activity_Type']==''] #BLANK IS ONEW
    n=len(new_ord)
    if n!=0:
        new_ord['order_value']=new_ord['Limit_Price']*new_ord['Volume_Original']
        nov=new_ord['order_value'].sum()
    else:
        nov=0.0 
    mod_ord=grp[grp['Activity_Type']=='OMOD']
    m=len(mod_ord)
    if m!=0:
       mod_ord['order_value']=mod_ord['Limit_Price']*mod_ord['Volume_Original']
       mov=mod_ord['order_value'].sum()
    else:
       mov=0.0       
    cancel_ord=grp[grp['Activity_Type']=='OCXL']
    c=len(cancel_ord)
    if c!=0:
       cancel_ord['order_value']=cancel_ord['Limit_Price']*cancel_ord['Volume_Original']
       cov=cancel_ord['order_value'].sum()
    else:
        cov=0.0
   
    return pd.Series({'Count_newOrders':n,
                      'Count_modOrders':m,
                      'Count_cancelOrders':c,
                      'New_orderValue':nov,
                      'Mod_orderValue':mov,
                      'Cancel_orderValue':cov})
    
def modified_order_handling(grp):
    new_mod=grp[grp['Activity_Type']!='OCXL']#) & (grp['Activity_Type']=='OMOD') ]
    mod_ord=grp[grp['Activity_Type']=='OMOD']
    if len(mod_ord)!=0:
        m=len(mod_ord)
    
        buy_data=new_mod[new_mod['Buy_Sell_Indicator']=='B']
        if len(buy_data)!=0:
            buy_data['priority loss'] = np.where((buy_data['Limit_Price'] < buy_data['Limit_Price'].shift()) | ((buy_data['Volume_Original'] > buy_data['Volume_Original'].shift()) & (buy_data['Limit_Price'] == buy_data['Limit_Price'].shift())),"Yes","No")
            buy_count=buy_data[buy_data['priority loss']=="Yes"]
            count_mod_pri_loss=len(buy_count)
        else:   
            sell_data=new_mod[new_mod['Buy_Sell_Indicator']=='S']
            sell_data['priority loss'] = np.where((sell_data['Limit_Price'] > sell_data['Limit_Price'].shift()) | ((sell_data['Volume_Original'] > sell_data['Volume_Original'].shift()) & (sell_data['Limit_Price'] == sell_data['Limit_Price'].shift())),"Yes","No")
            sell_count=sell_data[sell_data['priority loss']=="Yes"]
            count_mod_pri_loss=len(sell_count)
            
        new_mod['Priority maintained']=np.where((new_mod['Limit_Price']==new_mod['Limit_Price'].shift()) & (new_mod['Volume_Original'] <= new_mod['Volume_Original'].shift()),"Yes","No")
        priority_main=new_mod[new_mod['Priority maintained']=='Yes']
        count_mod_pri_main=len(priority_main)
        
        mod_percent=((count_mod_pri_loss+count_mod_pri_main)*100)/m
    else: 
         return pd.Series({"count_of_mod":0.0,
                          "Priority_loss":0.0,
                         "Priority_maintained":0.0,
                         "mod_percent":0.0})
    
            
    return pd.Series({"count_of_mod":m,
                      "Priority_loss":count_mod_pri_loss,
                         "Priority_maintained":count_mod_pri_main,
                         "mod_percent":mod_percent})
    
    

    
def generating_data(bkc_df,cm_trade,date):
        bkc_df['Strike_Price']=pd.to_numeric(bkc_df['Strike_Price'], errors='coerce').fillna(0.0,downcast='infer')
        bkc_df['Strike_Price']=bkc_df['Strike_Price'].astype(float)
        bkc_df['Order_Number']=bkc_df['Order_Number'].astype(str)
        #bkc_df.info()
        order_df = bkc_df.groupby(by=['Client_AC_Number','Symbol','User_ID','Instrument_Name','Location_ID','Strike_Price',
                                      'Option_Type varchar','Expiry_Date']).apply(lambda grp:
                            order_handling(grp)).reset_index()
        
        cm_trade['StrikePrice'] = pd.to_numeric(cm_trade['StrikePrice'], errors='coerce').fillna(0.0,downcast='infer')
        trades_df = cm_trade.groupby(by=['Account','Symbol','UserId','InstrumentType','CTCL code',"Expiry","StrikePrice","CallOrPut"]).apply(lambda grp:
                        pd.Series({
                                'trade_count': len(grp),
                                'trade_qty':grp['Quantity'].sum(),
                                'trade_value': np.sum(grp['Average']*grp['Quantity']),
                                })).reset_index()    
        
        final1 = (order_df.groupby(by=['Client_AC_Number','Symbol','Instrument_Name','Strike_Price','Option_Type varchar',
                                       'Expiry_Date']).apply(lambda grp: pd.Series({                            
                                    'Count_newOrders': grp['Count_newOrders'].sum(),
                                    'Count_modOrders':grp['Count_modOrders'].sum(),
                                    'Count_cancelOrders':grp['Count_cancelOrders'].sum(),
                                     'New_orderValue':grp['New_orderValue'].sum(),
                                    'Mod_orderValue':grp['Mod_orderValue'].sum(),
                                    'Cancel_orderValue':grp['Cancel_orderValue'].sum()})).reset_index().rename(
                                    columns={'Client_AC_Number':'Account','Instrument_Name':'InstrumentType','Strike_Price':'StrikePrice',
                                             'Option_Type varchar':'CallOrPut','Expiry_Date':'Expiry'})).merge(
                trades_df.groupby(by=['Account','Symbol','InstrumentType','StrikePrice','CallOrPut','Expiry']).apply(lambda grp:
                            pd.Series({
                            'trade_count': np.sum(grp['trade_count']),
                            'trade_qty': np.sum(grp['trade_qty']),
                            'trade_value': np.sum(grp['trade_value']),
                            })).reset_index(), on=['Account','Symbol','InstrumentType','StrikePrice','CallOrPut','Expiry'],
                        how="outer")
            
        final2 = (order_df.groupby(by=['Client_AC_Number','Symbol','Instrument_Name','User_ID','Location_ID','Strike_Price',
                                       'Option_Type varchar','Expiry_Date']).apply(lambda grp: pd.Series({
                                    
                                    'Count_newOrders': grp['Count_newOrders'].sum(),
                                    'Count_modOrders':grp['Count_modOrders'].sum(),
                                    'Count_cancelOrders':grp['Count_cancelOrders'].sum(),
                                     'New_orderValue':grp['New_orderValue'].sum(),
                                    'Mod_orderValue':grp['Mod_orderValue'].sum(),
                                    'Cancel_orderValue':grp['Cancel_orderValue'].sum()})).reset_index().rename(columns={'Client_AC_Number':'Account',
                                    'User_ID':'UserId','Location_ID':'CTCL code','Instrument_Name':'InstrumentType','Strike_Price':'StrikePrice','Option_Type varchar':'CallOrPut','Expiry_Date':'Expiry'})).merge(
                trades_df.groupby(by=['Account','Symbol','InstrumentType','UserId','CTCL code','StrikePrice','CallOrPut','Expiry']).apply(lambda grp:
                            pd.Series({
                            'trade_count': np.sum(grp['trade_count']),
                            'trade_qty': np.sum(grp['trade_qty']),
                            'trade_value': np.sum(grp['trade_value']),
                            })).reset_index(), on=['Account','Symbol','InstrumentType','UserId','CTCL code','StrikePrice','CallOrPut','Expiry'], how="outer")
        
        #f1=final1.copy(deep=True)
        #f2=final2.copy(deep=True)
        final1["Order_Trade_Ratio"]=(final1['New_orderValue']+final1['Mod_orderValue']+final1['Cancel_orderValue'])/final1['trade_value']
        final2["Order_Trade_Ratio"]=(final2['New_orderValue']+final2['Mod_orderValue']+final2['Cancel_orderValue'])/final2['trade_value']
        final1=final1.rename(columns={'Account':'UCC','ExpiryDate':'Expiry','OptionType':'Call/Put','StrikePrice':'Strike','Count_newOrders':'Count of Orders Entered','Count_modOrders':'Count of Orders Modified','Count_cancelOrders':'Count of Orders Cancelled','New_orderValue':'Original Order Value (entry)',
                              'Mod_orderValue':'Modified Order Value','Cancel_orderValue':'Cancelled Order Value','trade_count':'Count of Trade','trade_qty':'Trade Qty','trade_value':'Trade Value','Order_Trade_Ratio':'Order Trade Ratio in Value Terms'})
        			
        final2=final2.rename(columns={'Account':'UCC','ExpiryDate':'Expiry','OptionType':'Call/Put','StrikePrice':'Strike','Count_newOrders':'Count of Orders Entered','Count_modOrders':'Count of Orders Modified','Count_cancelOrders':'Count of Orders Cancelled','New_orderValue':'Original Order Value (entry)',
                              'Mod_orderValue':'Modified Order Value','Cancel_orderValue':'Cancelled Order Value','trade_count':'Count of Trade','trade_qty':'Trade Qty','trade_value':'Trade Value','Order_Trade_Ratio':'Order Trade Ratio in Value Terms','CTCL code':'NNF Code'})
        			
        final2['NNF Code']=final2['NNF Code'].astype(str)
        
        value_columns = ['Count of Orders Entered','Count of Orders Modified','Count of Orders Cancelled','Original Order Value (entry)','Modified Order Value','Cancelled Order Value','Count of Trade','Trade Qty','Trade Value','Order Trade Ratio in Value Terms']  
        for i in value_columns:
            final1[i]=final1[i].fillna(0.0)
            final2[i]=final2[i].fillna(0.0)
            
            final1[i]=final1[i].round(2)
            final2[i]=final2[i].round(2)
    
        mod_data1 = bkc_df.groupby(by=['Client_AC_Number','Symbol','Order_Number','Instrument_Name','Strike_Price',
                                      'Option_Type varchar','Expiry_Date']).apply(lambda grp:
                             modified_order_handling(grp)).reset_index()

        mod_data11=mod_data1.groupby(by=['Client_AC_Number','Symbol','Instrument_Name','Strike_Price', 'Option_Type varchar','Expiry_Date']).apply(lambda grp:
                                         pd.Series({
                             "count_of_mod":grp['count_of_mod'].sum(),              
                            "Priority_loss":grp['Priority_loss'].sum(),
                             "Priority_maintained":grp['Priority_maintained'].sum()})).reset_index()
    
        mod_data11['mod_percent']= np.where(mod_data11['count_of_mod']!=0 ,(((mod_data11['Priority_loss']+mod_data11['Priority_maintained'])*100)/mod_data11['count_of_mod']).round(2),0.0)
        mod_data11.rename(columns={'Client_AC_Number':'UCC','ExpiryDate':'Expiry','Option_Type varchar':'CallOrPut','Strike_Price':'Strike','Instrument_Name':'InstrumentType'},inplace=True)    
        f1=final1.merge(mod_data11,on=['UCC','Symbol','InstrumentType','Expiry','CallOrPut','Strike'],how="outer")
        f1.drop(['count_of_mod'],axis=1,inplace=True)      
        f1=f1.rename(columns={'Priority_loss':'Count of Orders Modified with priority loss',
                              'Priority_maintained':'Count of Order Modified with prioity maintained',
                              'mod_percent':'Modification with Maintained/Lost Priority as a % of Total no. of modification'})
        
        mod_data2=bkc_df.groupby(by=['Client_AC_Number','Symbol','Instrument_Name','Strike_Price','Order_Number','Option_Type varchar','Expiry_Date','User_ID','Location_ID']).apply(lambda grp:
                             modified_order_handling(grp)).reset_index()
    
        mod_data22=mod_data2.groupby(by=['Client_AC_Number','Symbol','Instrument_Name','Strike_Price','User_ID','Option_Type varchar','Expiry_Date','Location_ID']).apply(lambda grp:
                                           pd.Series({
                                        "count_of_mod":grp['count_of_mod'].sum(),              
                                          "Priority_loss":grp['Priority_loss'].sum(),
                                         "Priority_maintained":grp['Priority_maintained'].sum()})).reset_index()
        
        mod_data22['mod_percent']= np.where(mod_data22['count_of_mod']!=0 ,(((mod_data22['Priority_loss']+mod_data22['Priority_maintained'])*100)/mod_data22['count_of_mod']).round(2),0.0)
        mod_data22.rename(columns={'Client_AC_Number':'UCC','User_ID':'UserId','Location_ID':'NNF Code','Expiry_Date':'Expiry','Option_Type varchar':'CallOrPut','Strike_Price':'Strike','Instrument_Name':'InstrumentType'},inplace=True)
        mod_data22['NNF Code']=mod_data22['NNF Code'].astype(str)
           
         
        f2=final2.merge(mod_data22,on=['UCC','Symbol','InstrumentType','UserId','NNF Code','Expiry','CallOrPut','Strike'],how="outer")
        f2.drop(['count_of_mod'],axis=1,inplace=True)          
        f2=f2.rename(columns={'Priority_loss':'Count of Orders Modified with priority loss',
                      'Priority_maintained':'Count of Order Modified with prioity maintained',
                      'mod_percent':'Modification with Maintained/Lost Priority as a % of Total no. of modification'})    
        
        f1=f1.fillna(0.0)
        f2=f2.fillna(0.0)
        
        #writer = pd.ExcelWriter(os.path.join(data_dir,"OrderTradedata_fo.xlsx"), engine='xlsxwriter')
        writer = pd.ExcelWriter(os.path.join(data_dir,"OrderTradedata_fo_{}.xlsx".format(date)), engine='xlsxwriter')
        f1.to_excel(writer, sheet_name='sheet1',index=False)
        f2.to_excel(writer, sheet_name='sheet2',index=False)
        writer.save()
        
        
def main():
   # date=input("Enter the date- ")
    date=sys.argv[1]
    bkc_df,cm_trade=reading_order_trade_files(date,nse_id)
    generating_data(bkc_df,cm_trade,date)
    print("file generated for {}".format(date))
    
main() 



