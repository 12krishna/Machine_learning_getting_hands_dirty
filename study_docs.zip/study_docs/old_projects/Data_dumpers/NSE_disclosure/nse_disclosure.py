# -*- coding: utf-8 -*-
"""
Created on Fri Dec 24 10:42:12 2021

@author: backup
"""

import pandas as pd
import datetime
import time
from selenium import webdriver
from bs4 import BeautifulSoup
#from selenium.webdriver.common.action_chains import ActionChains
#from selenium.webdriver.support.ui import Select
#from selenium.webdriver.chrome.options import Options
import os
os.chdir("D:\\Data_dumpers\\NSE_disclosure\\")
import email_utility
master_dir = "D:\\Data_dumpers\\Master\\"
file_dir="D:\\Data_dumpers\\NSE_disclosure\\"
output_dir="D:\\Data_dumpers\\NSE_disclosure\\output\\"
contacts_dir = "D:\\Emails\\Contacts\\"


def disclosure(d):
    options = webdriver.ChromeOptions()
    
    #chrome_driver_path = "../chromedriver.exe"
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    options.add_argument('--disable-blink-features=AutomationControlled')
    
    driver = webdriver.Chrome(master_dir+"chromedriver.exe", options=options)
    driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    
    
    driver.get('https://www.nseindia.com/companies-listing/corporate-filings-announcements')
    time.sleep(5)
    driver.maximize_window()
    #driver.execute_script("document.body.style.zoom='zoom 25%'")
    time.sleep(5)
    driver.find_element_by_link_text("1W").click()
    time.sleep(30)
    print("done")
    html=driver.page_source
    soup=BeautifulSoup(html,"lxml")
    #print(soup)
    table=soup.find("table",id="CFanncEquityTable")
    print(len(table))
    rows=table.find_all("tr")
    print(len(rows))
    default="Defaults on Payment of Interest/Principal"
    result=[]
    for g in rows[1:]:
        try:
            v=g.find_all("td")
            print(len(v))
            subject=v[2].text
            symbol=v[0].text
            cname=v[1].text
            details=v[3].text
            attach=v[4].find("a")['href']
            dat_tim=v[6].text
            result.append([symbol,subject,cname,details,attach,dat_tim]) 
        except Exception as e:
             print(e)
             
    announcements=pd.DataFrame(result,columns=["Symbol","Subject","Company Name","Details","Attachment","Date-Time"])
    maindf=announcements[announcements['Subject']==default]
    maindf=maindf.iloc[:,2:]
    
    maindf.to_excel(os.path.join(output_dir,"disclosure_{}.xlsx".format(d)),index=False)
    driver.close()
    excel_filename=os.path.join(output_dir, "disclosure_{}.xlsx".format(d))
    return excel_filename, maindf

def disclosure_html(maindf,d):


    _font_style = "calibri"
    
            
    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>
    html_string = "<html><head><style>{css_style}</style></head><body>".format(css_style = open(os.path.join(file_dir, "df_style.css"), 'r').read())
    html_string += '<p style=\"{}\">NSE Disclosure as on  {}</p><br>'.format(
                "color:black;font-weight: bold;font-family:{};font-size:10pt".format(_font_style), d)        
    
    maindf['Company Name'] = maindf[['Company Name','Attachment']].apply(lambda x: 
                                            '<a href="{}">{}</a>'.format(x['Attachment'], x['Company Name']), axis=1) 
    maindf.drop(columns=['Attachment'], inplace=True)
              
    result= maindf.to_html(classes='mystyle', index=False).replace(
                                                '<table border="1" class="dataframe mystyle">',
                                                '<table border="1" class="mystyle">')
    html_string += "<table><tr><td valign='top'>{}</td></tr></table>".format(result)
    html_string += "<br><br></body></html>"
        
    
    with open(os.path.join(output_dir, "disclosure_{}.html".format(d)),'w') as f:
        f.write(html_string)
    
    output_file = open(os.path.join(output_dir, "disclosure_{}.html".format(d)), 'r').read().replace("&lt;","<").replace("&gt;",">")
    output_file = output_file.replace("dataframe mystyle","mystyle")
    output_file = output_file.replace('<td>text','<td class="text">')
    
    with open(os.path.join(output_dir, "disclosure_{}.html".format(d)), 'w') as f:
        f.write(output_file)
        
    html_filename=os.path.join(output_dir, "disclosure_{}.html".format(d))
    return html_filename

def main():
    d=datetime.datetime.today().date()
    excel_filename, maindf=disclosure(d)
    html_filename = disclosure_html(maindf,d)
    email_utility.process_status_email(os.path.join(contacts_dir, "back.txt"), "Nse Disclosure {}".format(d), 
                                       [excel_filename], html_filename)

main()




