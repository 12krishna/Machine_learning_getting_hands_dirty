import urllib2
import datetime
from dateutil.relativedelta import relativedelta
import requests
import httplib, StringIO, zipfile
import os
import sys
import shutil
from six.moves.urllib.parse import urlparse
from dateutil import parser
import pandas as pd
import time 
import logging 
import redis
from cassandra.cluster import Cluster
os.chdir("D:\Data_dumpers\NSE_index_bhavcopy")


download_dir = "D:\\Data_dumpers\\NSE_index_bhavcopy\\Download\\"
master_dir = "D:\\Data_dumpers\\Master\\"
log_path = "D:\\Data_dumpers\\NSE_index_bhavcopy\\"
processed_dir = "D:\\Data_dumpers\\NSE_index_bhavcopy\\Processed\\"
options_dir = 'D:\\Options\\Deliverables\\bhavcopy\\'

redis_host = 'localhost'
cassandra_host = "172.17.9.51"
# log events in debug mode 
logging.basicConfig(filename=log_path+"NSE_indices_dumper.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

cluster = Cluster([cassandra_host])
logging.info('Cassandra Cluster connected...')
# connect to your keyspace and create a session using which u can execute cql commands 
session = cluster.connect('rohit')
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None



def validate(d,columnname):
    res = session.execute("select {} from index_bhavcopy where {}>='{}' allow filtering".format(columnname, columnname,
                          d-datetime.timedelta(days=15)))
    res = res._current_rows
    res.sort_values(by=columnname, inplace=True)
    res = res.iloc[-1][columnname]
    return res.date()

class nseConnect:
    headers = {'Host': 'www.nseindia.com',
               'Referer': 'https://www.nseindia.com/products/content/equities/indices/archieve_indices.htm'}
    
    url = "www.nseindia.com"

    #Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36
    #User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
    def connect(self):
        print "Connecting to exchange "
        response=''
        try:
            response = requests.head('http://' + self.url, timeout=(3, 180))
        except:
            response = requests.head('http://' + self.url)
        print "Connected "
               
        #response = requests.head('http://' + self.url)
        if response.status_code == 302:
            self.url = response.headers["Location"]
        isHttps = self.url.find("https") > -1
        self.url = self.url[self.url.find("//")+2:self.url.rfind("/")]
        if isHttps:
            self.conn = httplib.HTTPSConnection(self.url)
        else:
            self.conn = httplib.HTTPConnection(self.url)

    def disconnect(self):
        self.conn.close()

    def getFilename(self, date):
        [y, m, d] = self.convertDate(date)
        return "ind_close_all_%s%s%s.csv" % (d, m, y)

    def convertDate(self, date):
        y = date.strftime("%Y")
        m = date.strftime("%m")
        d = date.strftime("%d")
        return [y, m, d]

    def getReqStr(self, date):
        [y, m, d] = self.convertDate(date)
        return "/content/indices/%s" % (self.getFilename(date))

    def getResponse(self, reqstr):
        
        self.url = reqstr
        self.session = requests.Session()
        if self.headers:
            self.session.headers.update(self.headers)
        
        u = urlparse(self.url)
        self.session.headers.update({'Host': u.hostname})
        self.data = self.session.get(self.url)
        
        return self.data.status_code
    
        
      
def dump_index_bhavcopy():
    
    '''Func to dump the nse index bhavcopy data into cassandra'''
    
    '''replace values in column indexname with below given values''' 
    values_to_replace={
        'Nifty 50':'NIFTY',
        'Nifty Midcap 50':'NIFTYMID50',
        'Nifty Bank':'BANKNIFTY',
        'Nifty IT':'NIFTYIT',
        'Nifty Infrastructure':'NIFTYINFRA',
        'Nifty PSE':'NIFTYPSE',
        'Nifty CPSE':'NIFTYCPSE'
        }
    
    # r=root, d=directories, f = files
    '''append files one by one into one list'''
    for r, d, f in os.walk(download_dir):
        for file in f:
            
            df=pd.read_csv(download_dir+file)
            df.columns = df.columns.str.replace(' ','')
            df.rename(columns={'Change(%)':'Change_percent','Turnover(Rs.Cr.)':'Turnover_cr','P/E':'PbyE','P/B':'PbyB'},inplace=True)
        
            df['IndexName'] = df.IndexName.replace(values_to_replace)
            df["IndexDate"]=pd.to_datetime(df["IndexDate"], dayfirst=True).dt.date
            
            df = df[df['IndexName'].isin(values_to_replace.values())]
    
            df.to_csv("index_bhavcopy.csv ",index=False)
            session.execute("CREATE TABLE IF NOT EXISTS index_bhavcopy(IndexName TEXT,IndexDate DATE,OpenIndexValue FLOAT,HighIndexValue FLOAT,LowIndexValue FLOAT,ClosingIndexValue FLOAT,PointsChange FLOAT,Change_percent FLOAT,Volume FLOAT,Turnover_cr FLOAT,PbyE FLOAT,PbyB FLOAT,DivYield FLOAT,PRIMARY KEY (IndexName,IndexDate))")
            os.system("dump.bat")
            shutil.move(download_dir+file,processed_dir+file)
            os.remove("index_bhavcopy.csv")
    
    
     

def downloadCSV(c, d):
    
    filename = c.getFilename(d)
    reqstr = c.getReqStr(d)
    reqstr = "https://www.nseindia.com"+reqstr
    print reqstr
    
    print "Downloading %s ..." % (filename)
    
    # read holiday master
    holiday_master = pd.read_csv(master_dir+ 'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
    
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        responsecode = c.getResponse(reqstr) 
        
        while responsecode!= 200 and datetime.datetime.now().time() > datetime.time(17,0):
            # sleep for 2 min
            logging.info('{} is Working day : sleep for 2 minutes '.format(d))
            
            print 'Sleep for 2 min...'
            
            time.sleep(120)
        
            
            responsecode = c.getResponse(reqstr)
    elif len(holiday_master[holiday_master['date']==d])==1:
        print 'Holiday: skip for current date :{} '.format(d)
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1
            


    sdata = c.data.content
    if len(sdata) < 250:
        pass
        return -1    
    else:
        csv = open(download_dir+'{}'.format(filename), 'wb')
        csv.write(sdata)
        csv.close()
        
        shutil.copy("{}\{}".format(download_dir,filename), options_dir+filename[14:]) # copy to FNO bhavcopy download folder and dump in cassandra
        r = redis.Redis(host=redis_host, port=6379) 
        dump_index_bhavcopy()   # dump bhavcopy into index bhavcopy table cassandra
    	r.set('index_file_flag',1)
        r.set('index_file_remarks',"NSE Index file has been downloaded and dumped in cassandra for {}!".format(
                validate(d, 'indexdate')))
        r.set("market_snap_index",1)
        r.set("market_pos_index",1)
        
        
        # dump to cassandra
        #Cassandra_dumper.cassandra_dumper()
            
        return 1




def downloadCSVDate(c, date):
    [y, m, d] = convertDate(date)
    return downloadCSV(c, y, m, d)

def getUpdate(c):
    errContinous = 0
    d = datetime.date.today()
    decr = datetime.timedelta(days=1)
    while errContinous > -365 and (not os.path.exists(os.path.join(processed_dir,c.getFilename(d)))):
        if downloadCSV(c, d) > -1:
            errContinous = 0
        else:
            errContinous -= 1
        d -= decr




def main(args):
    c = nseConnect()
    c.connect()
    if args:
        if args[0] == "-update":
            getUpdate(c)
        
    c.disconnect()

if __name__ == "__main__":
    main(sys.argv[1:])
    session.shutdown()