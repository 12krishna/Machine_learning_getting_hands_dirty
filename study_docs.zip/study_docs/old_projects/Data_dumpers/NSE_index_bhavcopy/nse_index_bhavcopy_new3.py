#from urllib.request import urlopen
import datetime
#from dateutil.relativedelta import relativedelta
import requests
import http.client, zipfile
from io import StringIO
import os
import sys
import shutil
from six.moves.urllib.parse import urlparse
from dateutil import parser
import numpy as np
import pandas as pd
import time
import logging
import redis
from cassandra.cluster import Cluster

import requests, os



os.chdir("D:\\Data_dumpers\\NSE_index_bhavcopy\\")


download_dir = "D:\\Data_dumpers\\NSE_index_bhavcopy\\Download\\"
master_dir = "D:\\Data_dumpers\\Master\\"
log_path = "D:\\Data_dumpers\\NSE_index_bhavcopy\\"
processed_dir = "D:\\Data_dumpers\\NSE_index_bhavcopy\\Processed\\"
options_dir = 'D:\\Options\\Deliverables\\bhavcopy\\'
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'}


redis_host = 'localhost'
cassandra_host = "172.17.9.51"
# log events in debug mode
logging.basicConfig(filename=log_path+"NSE_indices_dumper.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def dateparse(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]

    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)

    return cluster



#cluster = Cluster([cassandra_host])
cluster = cassandra_configs_cluster()
logging.info('Cassandra Cluster connected...')
# connect to your keyspace and create a session using which u can execute cql commands
session = cluster.connect('rohit')
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None



def validate(d,columnname):
    res = session.execute("select {} from index_bhavcopy where {}>='{}' allow filtering".format(columnname, columnname,
                          d-datetime.timedelta(days=15)))
    res = res._current_rows
    res.sort_values(by=columnname, inplace=True)
    res = res.iloc[-1][columnname]
    return res.date()





def getFilename( date):
    [y, m, d] = convertDate(date)
    return "ind_close_all_%s%s%s.csv" % (d, m, y)

def convertDate( date):
    y = date.strftime("%Y")
    m = date.strftime("%m")
    d = date.strftime("%d")
    return [y, m, d]

def getReqStr( date):
    [y, m, d] = convertDate(date)
    return "/content/indices/%s" % (getFilename(date))





def dump_index_bhavcopy():

    '''Func to dump the nse index bhavcopy data into cassandra'''

    '''replace values in column indexname with below given values'''
    values_to_replace={
        'Nifty 50':'NIFTY',
        'Nifty Midcap 50':'NIFTYMID50',
        'Nifty Bank':'BANKNIFTY',
        'Nifty IT':'NIFTYIT',
        'Nifty Infrastructure':'NIFTYINFRA',
        'Nifty PSE':'NIFTYPSE',
        'Nifty CPSE':'NIFTYCPSE'
        }

    # r=root, d=directories, f = files
    '''append files one by one into one list'''
    for r, d, f in os.walk(download_dir):
        for file in f:

            df=pd.read_csv(download_dir+file)
            df.columns = df.columns.str.replace(' ','')
            df.rename(columns={'Change(%)':'Change_percent','Turnover(Rs.Cr.)':'Turnover_cr','P/E':'PbyE','P/B':'PbyB'},inplace=True)

            df['IndexName'] = df.IndexName.replace(values_to_replace)
            df["IndexDate"]=pd.to_datetime(df["IndexDate"], dayfirst=True).dt.date

            df = df[df['IndexName'].isin(values_to_replace.values())]
            df = df.replace("-",np.NaN)

            df.to_csv("index_bhavcopy.csv ",index=False)
            session.execute("CREATE TABLE IF NOT EXISTS index_bhavcopy(IndexName TEXT,IndexDate DATE,OpenIndexValue FLOAT,HighIndexValue FLOAT,LowIndexValue FLOAT,ClosingIndexValue FLOAT,PointsChange FLOAT,Change_percent FLOAT,Volume FLOAT,Turnover_cr FLOAT,PbyE FLOAT,PbyB FLOAT,DivYield FLOAT,PRIMARY KEY (IndexName,IndexDate))")
            os.system("dump3.bat")
            shutil.move(download_dir+file,processed_dir+file)
            os.remove("index_bhavcopy.csv")





def downloadCSV(d):

    filename = getFilename(d)
    reqstr = getReqStr(d)
    reqstr = "https://archives.nseindia.com"+reqstr
    print (reqstr)
    responsecode = ''
    print ("Downloading %s ..." % (filename))

    # read holiday master
    holiday_master = pd.read_csv(master_dir+ 'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)


    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        try:
            responsecode = requests.get(reqstr, headers=headers )
            print (responsecode.status_code)
        except Exception as e:
            print (e)
            responsecode=404

        while datetime.datetime.now().time() > datetime.time(17,0):

            print ('Sleep for 2 min...')
            time.sleep(120)
            try:
                responsecode = requests.get(reqstr, headers=headers )
                if responsecode.status_code==200:
                    break
            except Exception as e:
                print ("Response Exception / {}".format(e))


    elif len(holiday_master[holiday_master['date']==d])==1:
        return -1


    try:
        if len(responsecode.content) < 250:
            pass
            return -1
        else :

            csv = open(download_dir+'{}'.format(filename), 'wb')
            csv.write(responsecode.content)
            csv.close()

            shutil.copy("{}\{}".format(download_dir,filename), options_dir+filename[14:]) # copy to FNO bhavcopy download folder and dump in cassandra
            r = redis.Redis(host=redis_host, port=6379)
            dump_index_bhavcopy()   # dump bhavcopy into index bhavcopy table cassandra
            r.set('index_file_flag',1)
            r.set('index_file_remarks',"NSE Index file has been downloaded and dumped in cassandra for {}!".format(
                    validate(d, 'indexdate')))
            r.set("market_snap_index",1)
            r.set("market_pos_index",1)

            return 1

    except:
        print ("File is not a zip file ")
        return -1



def getUpdate():
    errContinous = 0
    d = datetime.date.today()
    decr = datetime.timedelta(days=1)
    while errContinous > -365 and (not os.path.exists(os.path.join("D:\\Data_dumpers\\NSE_index_bhavcopy\\Processed\\",getFilename(d)))):
        if downloadCSV(d) > -1:
            errContinous = 0
        else:
            errContinous -= 1
        d -= decr

def main(args):
    if args:
        if args[0] == "-update":
            getUpdate()


if __name__ == "__main__":
    main(sys.argv[1:])