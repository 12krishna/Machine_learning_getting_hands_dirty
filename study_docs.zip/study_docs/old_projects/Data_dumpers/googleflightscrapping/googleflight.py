# -*- coding: utf-8 -*-
"""
Created on Thu Oct 10 14:03:21 2019

@author: Administrator
"""

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait 
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.common.exceptions import TimeoutException
#from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime
import pandas as pd, shutil
import os 
from collections import OrderedDict


chrome_options = webdriver.ChromeOptions()
master_dir="D:\\Data_dumpers\\googleflightscrapping\\"
output_dir = "D:\\Data_dumpers\\googleflightscrapping\\Output\\"
email_dir = "D:\\Emails\\Output\\"


def get_text(tag_list):
    '''Gets list of text'''
    result = []
    for tag in tag_list:
        result.append(tag.getText())
    return result

def get_flight_details(url,origin,destination,date):
    
    driver = webdriver.Chrome("D:\Master\chromedriver.exe")
    driver.get(url)
    driver.implicitly_wait(60)
    WebDriverWait(driver, 10000)
    driver.implicitly_wait(100)
    time.sleep(20)
    soup=BeautifulSoup(driver.page_source, 'lxml')
    
    #print "soup",soup
    
    carrier = soup.find_all('div',{'class':'hF6lYb sSHqwe ogfYpf tPgKwe'})
    airlines = []
    for car in carrier:
        airlines.append(car.find_all('span')[-1].getText())
        
    
    # dept, arrival time
    dept_time = get_text(soup.find_all("div", class_="wtdjmc YMlIz ogfYpf tPgKwe"))
    arrival_time = get_text(soup.find_all("div", class_="XWcVob YMlIz ogfYpf tPgKwe"))
    
    # origin, destination
    origin = get_text(soup.find_all("div", class_="G2WY5c sSHqwe ogfYpf tPgKwe"))
    destination = get_text(soup.find_all("div", class_="c8rWCd sSHqwe ogfYpf tPgKwe"))
    
    
    # prices
    prices = get_text(list(OrderedDict.fromkeys(soup.find_all("div", 
                    class_=lambda value: value and value.startswith("YMlIz FpEdX")))))
   
    result = pd.DataFrame([airlines, dept_time, arrival_time, origin, destination, prices]).T
    result.columns= ['Airlines','Departure time','Arrival time','Origin','Destination','Prices']
    
    driver.quit()
    return result

def main(nd):
    
    d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    if d.weekday()!=4:
        return -1
    
    
    today_d = d
    origin_list=["BOM","BOM","BOM","BOM","DEL","DEL","DEL","DEL"]
    destination_list=["DEL","BLR","MAA","CCU","BOM","BLR","MAA","CCU"]
	
    d=datetime.datetime.now().date()+datetime.timedelta(days=7)
    print (d)
    final_details=[]
    for i in range(0,len(origin_list)):
        url="https://www.google.com/flights?hl=en#flt={}.{}.{};c:INR;e:1;a:AI,I5,G8,6E,SG,UK;sd:1;t:f;tt:o".format(origin_list[i],destination_list[i],d)
        final_df=get_flight_details(url,origin_list[i],destination_list[i],d)
        final_details.append(final_df)

    d=datetime.datetime.now().date()+datetime.timedelta(days=14)
    print (d)
    for i in range(0,len(origin_list)):
        url="https://www.google.com/flights?hl=en#flt={}.{}.{};c:INR;e:1;a:AI,I5,G8,6E,SG,UK;sd:1;t:f;tt:o".format(origin_list[i],destination_list[i],d)
        final_df=get_flight_details(url,origin_list[i],destination_list[i],d)
        final_details.append(final_df)

    d=datetime.datetime.now().date()+datetime.timedelta(days=30)
    print (d)
    for i in range(0,len(origin_list)):
        url="https://www.google.com/flights?hl=en#flt={}.{}.{};c:INR;e:1;a:AI,I5,G8,6E,SG,UK;sd:1;t:f;tt:o".format(origin_list[i],destination_list[i],d)
        final_df=get_flight_details(url,origin_list[i],destination_list[i],d)
        final_details.append(final_df)

    final_details=pd.concat(final_details, ignore_index=True)
    #final_details["price"] = final_details["price"].apply(lambda x: int( "".join(("".join(x.strip().split()[1:])).split(",")) ) )

    final_details.to_excel(output_dir+"airflights_{}.xlsx".format(today_d),index=False)
    shutil.copy(output_dir+"airflights_{}.xlsx".format(today_d), email_dir+"airflights_{}.xlsx".format(today_d) )

    #print("final_df",final_details)
    os.system("D:\\Emails\\Email.bat")  

main(nd=0)



