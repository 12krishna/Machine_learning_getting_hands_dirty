# -*- coding: utf-8 -*-

#from __future__ import print_function
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait 
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
#from selenium.common.exceptions import TimeoutException
#from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime
import pandas as pd, shutil
import os 
from collections import OrderedDict
 

chrome_options = webdriver.ChromeOptions()

master_dir="D:\\Master\\"
output_dir = "D:\\Data_dumpers\\googleflightscrapping\\Output\\"
email_dir = "D:\\Emails\\Output\\"


def get_text(tag_list):
    '''Gets list of text'''
    result = []
    for tag in tag_list:
        result.append(tag.getText())
    return result

destinations_dict = {"Mumbai":"BOM","New Delhi":"DEL","Bengaluru":"BLR","Chennai":"MAA","Kolkata":"CCU"}

def get_flight_details(url,origin,destination,today_d,date):
    
    return_date=date.strftime("%a, %b %d")
    input_date=today_d.strftime("%a, %b %d")

    driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))
    driver.get(url)
    # driver.implicitly_wait(60)
    # WebDriverWait(driver, 10000)
    # driver.implicitly_wait(100)
    time.sleep(5)
    while 1:
        try:
            element1=driver.find_element(by=By.CSS_SELECTOR, value=".II2One.j0Ppje.zmMKJ.LbIaRd")
            element1.clear(); time.sleep(1)
            element1.send_keys(origin[0],origin[1],origin[2], Keys.ENTER)
            time.sleep(5)
            #element1.click()
            #element1.send_keys(Keys.TAB)
            
            #element1.send_keys(Keys.TAB)
            driver.refresh()
            value=driver.find_element(by=By.CSS_SELECTOR, value=".II2One.j0Ppje.zmMKJ.LbIaRd").get_attribute("value")
            if destinations_dict[value]==origin:
                break
            else:
                time.sleep(2)
        except Exception as e:
            print (e)
       
    while 1:
        try:    
            element2=driver.find_element(by=By.XPATH, value="//input[@placeholder='Where to?']")
            element2.clear(); time.sleep(1)
            #element2.click()
            element2.send_keys(destination[0],destination[1],destination[2], Keys.ENTER)
            time.sleep(5)
            
            #element2.send_keys(Keys.COMMAND)
            
            element2.send_keys(Keys.TAB)
            driver.refresh()
            value=driver.find_element(by=By.XPATH, value="//input[@value='{}']".format(
                     [k for k,v in destinations_dict.items() if v == destination][0])).get_attribute("value")
    
            if destinations_dict[value]==destination:
                break
            else:
                time.sleep(2)
        except Exception as e:
            print (e)
            
    while 1:
        try:
        
            element3=driver.find_element(by=By.CSS_SELECTOR, value=".RKk3r.eoY5cb.j0Ppje")
            element3.clear();time.sleep(1); element3.send_keys(Keys.BACKSPACE)
            #element3.click()
            element3.send_keys(Keys.CLEAR,input_date, Keys.END+Keys.END+Keys.END+Keys.END+Keys.END, Keys.ENTER)
            time.sleep(5)
            element3.send_keys(Keys.TAB)
            driver.refresh()
            value=driver.find_element(by=By.CSS_SELECTOR, value=".RKk3r.eoY5cb.j0Ppje").get_attribute("value")
            value_date = datetime.datetime.strptime(" ".join([value.split(" ")[1], value.split(" ")[-1], str(date.year)]), "%b %d %Y").date()
            input_date1 = datetime.datetime.strptime(" ".join([input_date.split(" ")[1], input_date.split(" ")[-1], str(date.year)]), "%b %d %Y").date()
                  
            if value_date==input_date1:
                break
            else:
                time.sleep(2)
        except Exception as e:
            print(e)
    
    while 1:
        try:
                
            element4=driver.find_element(by=By.XPATH, value="//input[@placeholder='Return date']")
            element4.clear();time.sleep(1); element4.send_keys(Keys.BACKSPACE)
            #element4.click()
            element4.send_keys(Keys.CLEAR, return_date, Keys.END+Keys.END+Keys.END+Keys.END+Keys.END, Keys.ENTER)
            time.sleep(5)
            driver.refresh()
            value=driver.find_element(by=By.XPATH, value="//input[@placeholder='Return date']").get_attribute("value")
            value_date = datetime.datetime.strptime(" ".join([value.split(" ")[1], value.split(" ")[-1], str(date.year)]), "%b %d %Y").date()
            return_date1 = datetime.datetime.strptime(" ".join([return_date.split(" ")[1], return_date.split(" ")[-1], str(date.year)]), "%b %d %Y").date()
                    
            if value_date==return_date1:
                break
            else:
                time.sleep(2)
        except Exception as e:
              print (e)
              
    #driver.find_element(by=By.CSS_SELECTOR, value="span.VfPpkd-vQzf8d" ).click()
    # time.sleep(10)
    # driver.find_element_by_xpath("//span[contains(@class, 'VfPpkd-vQzf8d') and text()='Search']").click()
    
    WebDriverWait(driver, 30).until(EC.element_to_be_clickable(By.CSS_SELECTOR, 'VfPpkd-vQzf8d')).click()
    
    # time.sleep(30)
    # driver.find_element_by_xpath("//div[contains(@class, 'zISZ5c QB2Jof ')]").click()
    WebDriverWait(driver, 30).until(EC.element_to_be_clickable(By.CSS_SELECTOR, '.zISZ5c.QB2Jof')).click()
    
    #driver.execute_script()
    # javaScript = "document.getElementsByClassName('.II2One.j0Ppje.zmMKJ.LbIaRd')[0].value = 'BOM'"
    # driver.execute_script(javaScript)
   
    # my_string = "TEST";
     # elem = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, value=".II2One.j0Ppje.zmMKJ.LbIaRd")))
    # driver.execute_script("document.getElementByClassName('.II2One.j0Ppje.zmMKJ.LbIaRd').click()")
    # driver.execute_script("arguments[0].setAttribute('value', '" + my_string +"')", elem);
    
    # source1=driver.find_element_by_css_selector(".II2One.j0Ppje.zmMKJ.LbIaRd").click()
    # source1.click()
    # source1.send_keys("BOM")
    # destination=driver.find_element_by_xpath("//input[@placeholder='Where to?']")
    # date1=driver.find_element_by_css_selector(".RKk3r.eoY5cb.j0Ppje")
    # date2=driver.find_element_by_xpath("//input[@placeholder='Return date']")
   
    # x=soup.find_all('input',{'class':'II2One j0Ppje zmMKJ LbIaRd'})[0] #Mumbai
    # x.find("value")
    
    soup=BeautifulSoup(driver.page_source, 'lxml')
    carrier = soup.find_all('div',{'class':'hF6lYb sSHqwe ogfYpf tPgKwe'})
    airlines = []
    for car in carrier:
        airlines.append(car.find_all('span')[-1].getText())
        
    #y=soup.find_all('input',{'class':'RKk3r eoY5cb j0Ppje'})
    
    # dept, arrival time  
    dept_time = get_text(soup.find_all("div", class_="wtdjmc YMlIz ogfYpf tPgKwe"))
    arrival_time = get_text(soup.find_all("div", class_="XWcVob YMlIz ogfYpf tPgKwe"))
    
    # origin, destination
    origin = get_text(soup.find_all("div", class_="G2WY5c sSHqwe ogfYpf tPgKwe"))
    destination = get_text(soup.find_all("div", class_="c8rWCd sSHqwe ogfYpf tPgKwe"))
    
    
    # prices
    prices = get_text(list(OrderedDict.fromkeys(soup.find_all("div", 
                    class_=lambda value: value and value.startswith("YMlIz FpEdX")))))
   
    result = pd.DataFrame([airlines, dept_time, arrival_time, origin, destination, prices]).T
    result.columns= ['Airlines','Departure time','Arrival time','Origin','Destination','Prices']
    
    driver.quit()
    
    return result

# from datetime import date
# today = date.today()
# input_date= print(today.strftime("%a, %b %d"))

def main(nd):
    
    d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    # if d.weekday()!=4:
    #     return -1
    
    
    today_d = d
    origin_list=["BOM","BOM","BOM","BOM","DEL","DEL","DEL","DEL"]
    destination_list=["DEL","BLR","MAA","CCU","BOM","BLR","MAA","CCU"]
    
    
    
    d=datetime.datetime.now().date()+datetime.timedelta(days=7)
    print( d)
    final_details=[]
    for i in range(0,len(origin_list)):
        url="https://www.google.com/flights?hl=en#flt={}.{}.{};c:INR;e:1;a:AI,I5,G8,6E,SG,UK;sd:1;t:f;tt:o".format(origin_list[i],destination_list[i],d)
        final_df=get_flight_details(url,origin_list[i],destination_list[i],today_d,d)
        final_details.append(final_df)

    d=datetime.datetime.now().date()+datetime.timedelta(days=14)
    print( d)
    for i in range(0,len(origin_list)):
        url="https://www.google.com/flights?hl=en#flt={}.{}.{};c:INR;e:1;a:AI,I5,G8,6E,SG,UK;sd:1;t:f;tt:o".format(origin_list[i],destination_list[i],d)
        final_df=get_flight_details(url,origin_list[i],destination_list[i],today_d,d)
        final_details.append(final_df)

    d=datetime.datetime.now().date()+datetime.timedelta(days=30)
    print( d)
    for i in range(0,len(origin_list)):
        url="https://www.google.com/flights?hl=en#flt={}.{}.{};c:INR;e:1;a:AI,I5,G8,6E,SG,UK;sd:1;t:f;tt:o".format(origin_list[i],destination_list[i],d)
        final_df=get_flight_details(url,origin_list[i],destination_list[i],today_d,d)
        final_details.append(final_df)

    final_details=pd.concat(final_details, ignore_index=True)
    #final_details["price"] = final_details["price"].apply(lambda x: int( "".join(("".join(x.strip().split()[1:])).split(",")) ) )

    final_details.to_excel(output_dir+"airflights_{}.xlsx".format(today_d),index=False)
    shutil.copy(output_dir+"airflights_{}.xlsx".format(today_d), email_dir+"airflights_{}.xlsx".format(today_d) )

    #print("final_df",final_details)
    
    os.system("D:\\Emails\\Email.bat")  

main(nd=0)


