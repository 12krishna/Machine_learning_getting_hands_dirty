# -*- coding: utf-8 -*-
"""
Created on Fri Sep  2 09:25:17 2022

@author: SalomeF
"""

''' Google Flights webscraping for one way trips '''

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import time,datetime
import pandas as pd, shutil
import os
from collections import OrderedDict



chrome_options = webdriver.ChromeOptions()

# master_dir = "C:\\Users\\salomef\\Projects\\chromedriver\\"
# output_dir = "C:\\Users\\salomef\\Projects\\Google Flights - One way\\"

master_dir="D:\\Master\\"
output_dir = "D:\\Data_dumpers\\googleflightscrapping\\Output\\"
email_dir = "D:\\Emails\\Output\\"

def get_text(tag_list):
    '''Gets list of text'''
    result = []
    for tag in tag_list:
        result.append(tag.getText())
    return result

destinations_dict = {"Mumbai":"BOM","New Delhi":"DEL","Bengaluru":"BLR","Chennai":"MAA","Kolkata":"CCU"}

def get_flight_details(url,origin,destination,date):

    # return_date=date.strftime("%a, %b %d")
    #return_date=d.strftime("%a, %b %d")
    input_date=date.strftime("%a, %b %d")

    driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))
    driver.get(url)
    #time.sleep(5)
    WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".VfPpkd-kBDsod.UmgCUb")))


    driver.find_element_by_css_selector(".VfPpkd-kBDsod.UmgCUb").click()
  #  driver.find_element_by_class_name("VfPpkd-kBDsod.UmgCUb").click()
    li = driver.find_elements_by_css_selector(".uT1UOd")
    li[1].click() # one way

    places = driver.find_elements_by_css_selector('.II2One.j0Ppje.zmMKJ.LbIaRd')

    dates = driver.find_elements_by_css_selector('.RKk3r.eoY5cb.j0Ppje')


    while 1:
        try:
            places[0].clear(); time.sleep(1) # From
            places[0].send_keys(origin[0],origin[1],origin[2], Keys.ENTER)
            time.sleep(5)

            driver.refresh();time.sleep(5)
            places = driver.find_elements_by_css_selector('.II2One.j0Ppje.zmMKJ.LbIaRd')
            value = places[0].get_attribute("value")
            # value=driver.find_element(by=By.CSS_SELECTOR, value=".II2One.j0Ppje.zmMKJ.LbIaRd").get_attribute("value")
            if destinations_dict[value]==origin:
                break
            else:
                time.sleep(2)
        except Exception as e:
            print (e)

    places = driver.find_elements_by_css_selector('.II2One.j0Ppje.zmMKJ.LbIaRd')

    while 1:
        try:

            places[2].clear(); time.sleep(1) # Where to ?
            places[2].send_keys(destination[0],destination[1],destination[2], Keys.ENTER)
            time.sleep(5)

            # element2.send_keys(Keys.TAB)
            driver.refresh()
            time.sleep(5)
            places = driver.find_elements_by_css_selector('.II2One.j0Ppje.zmMKJ.LbIaRd')
            value = places[2].get_attribute("value")

            if destinations_dict[value]==destination:
                break
            else:
                time.sleep(2)
        except Exception as e:
            print (e)

    dates = driver.find_elements_by_css_selector('.RKk3r.eoY5cb.j0Ppje')
    while 1:
        try:

#            dates[0].clear(); time.sleep(5) # departure
#            dates[0].send_keys(Keys.BACKSPACE)
#            dates[0].send_keys(Keys.CLEAR,input_date, Keys.END+Keys.END+Keys.END+Keys.END+Keys.END)
#            dates[0].send_keys(Keys.ENTER)
#            time.sleep(5)

            dates[0].send_keys(Keys.CONTROL+"a")
            dates[0].send_keys(Keys.DELETE)
            dates[0].send_keys(Keys.CLEAR,input_date, Keys.END+Keys.END+Keys.END+Keys.END+Keys.END)
            dates[0].send_keys(Keys.ENTER)
            time.sleep(5)

            driver.refresh() ; time.sleep(5)
            dates = driver.find_elements_by_css_selector('.RKk3r.eoY5cb.j0Ppje')
            value = dates[0].get_attribute("value")

            value_date = datetime.datetime.strptime(" ".join([value.split(" ")[1], value.split(" ")[-1], str(date.year)]), "%b %d %Y").date()
            input_date1 = datetime.datetime.strptime(" ".join([input_date.split(" ")[1], input_date.split(" ")[-1], str(date.year)]), "%b %d %Y").date()

            if value_date==input_date1:
                break
            else:
                time.sleep(2)
        except Exception as e:
            print(e)

    # dates = driver.find_elements_by_css_selector('.RKk3r.eoY5cb.j0Ppje')
    # while 1:
    #     try:

    #         dates[1].send_keys(Keys.CONTROL + "a")
    #         dates[1].send_keys(Keys.DELETE)

    #         dates[1].send_keys(Keys.CLEAR, return_date, Keys.END+Keys.END+Keys.END+Keys.END+Keys.END, Keys.ENTER)
    #         dates[1].send_keys(Keys.ENTER)
    #         time.sleep(5)

    #         driver.refresh() ; time.sleep(5)
    #         dates = driver.find_elements_by_css_selector('.RKk3r.eoY5cb.j0Ppje')
    #         value = dates[1].get_attribute("value")
    #         # value=driver.find_element(by=By.XPATH, value="//input[@placeholder='Return date']").get_attribute("value")
    #         value_date = datetime.datetime.strptime(" ".join([value.split(" ")[1], value.split(" ")[-1], str(date.year)]), "%b %d %Y").date()
    #         return_date1 = datetime.datetime.strptime(" ".join([return_date.split(" ")[1], return_date.split(" ")[-1], str(date.year)]), "%b %d %Y").date()

    #         if value_date==return_date1:
    #             break
    #         else:
    #             time.sleep(2)
    #     except Exception as e:
    #           print (e)

    search = driver.find_element_by_class_name("xFFcie").click()
    time.sleep(30)

    soup=BeautifulSoup(driver.page_source, 'lxml')
    carrier = soup.find_all('div',{'class':'hF6lYb sSHqwe ogfYpf tPgKwe'})
    airlines = []
    for car in carrier:
        airlines.append(car.find_all('span')[-1].getText())

    # dept, arrival time
    dept_time = soup.find_all("div", class_="wtdjmc YMlIz ogfYpf tPgKwe")
    dept_time1 = [i.getText() for i in dept_time]

    arrival_time = soup.find_all("div", class_="XWcVob YMlIz ogfYpf tPgKwe")
    arrival_time1 = [i.getText() for i in arrival_time]

    # origin, destination
    origin = soup.find_all("div", class_="G2WY5c sSHqwe ogfYpf tPgKwe")
    origin1 = [i.getText() for i in origin]

    destination = soup.find_all("div", class_="c8rWCd sSHqwe ogfYpf tPgKwe")
    destination1 = [i.getText() for i in destination]

    prices = list(OrderedDict.fromkeys(soup.find_all("div",
                    class_=lambda value: value and value.startswith("YMlIz FpEdX"))))

    prices1 = [i.getText() for i in prices]

    result = pd.DataFrame([airlines, dept_time1, arrival_time1, origin1, destination1, prices1]).T
    result.columns= ['Airlines','Departure time','Arrival time','Origin','Destination','Prices']
    result['Departure Date'] = date



    driver.quit()
    print (result)
    return result


def main(nd):

    d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    today_d = d
    origin_list=["BOM","BOM","BOM","BOM","DEL","DEL","DEL","DEL"]
    destination_list=["DEL","BLR","MAA","CCU","BOM","BLR","MAA","CCU"]

    d=datetime.datetime.now().date()+datetime.timedelta(days=7)
    print( d)
    final_details=[]
    for i in range(0,len(origin_list)):
        url="https://www.google.com/flights?hl=en#flt={}.{}.{};c:INR;e:1;a:AI,I5,G8,6E,SG,UK;sd:1;t:f;tt:o".format(origin_list[i],destination_list[i],d)
        final_df=get_flight_details(url,origin_list[i],destination_list[i],d)
        final_details.append(final_df)

    d=datetime.datetime.now().date()+datetime.timedelta(days=14)
    print( d)
    for i in range(0,len(origin_list)):
        url="https://www.google.com/flights?hl=en#flt={}.{}.{};c:INR;e:1;a:AI,I5,G8,6E,SG,UK;sd:1;t:f;tt:o".format(origin_list[i],destination_list[i],d)
        final_df=get_flight_details(url,origin_list[i],destination_list[i],d)
        final_details.append(final_df)

    d=datetime.datetime.now().date()+datetime.timedelta(days=30)
    print( d)
    for i in range(0,len(origin_list)):
        url="https://www.google.com/flights?hl=en#flt={}.{}.{};c:INR;e:1;a:AI,I5,G8,6E,SG,UK;sd:1;t:f;tt:o".format(origin_list[i],destination_list[i],d)
        final_df=get_flight_details(url,origin_list[i],destination_list[i],d)
        final_details.append(final_df)

    final_details=pd.concat(final_details, ignore_index=True)
    final_details.to_excel(output_dir+"airflights-one_way_{}.xlsx".format(today_d),index=False)
    shutil.copy(output_dir+"airflights-one_way_{}.xlsx".format(today_d), email_dir+"airflights-one_way_{}.xlsx".format(today_d) )
    os.system("D:\\Emails\\Email.bat")

if __name__ == "__main__":
    main(nd=0)

