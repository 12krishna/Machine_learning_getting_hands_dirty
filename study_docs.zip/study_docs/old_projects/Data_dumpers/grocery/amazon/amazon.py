from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options 
from fake_useragent import UserAgent
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.common.exceptions import TimeoutException
#from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime
import pandas as pd
from googlesearch import search 
import os 
import random
from selenium.webdriver.common.proxy import Proxy,ProxyType
output_dir='D:\\Data_dumpers\\grocery\\amazon\\output\\'

def process_url(glist,url_start,grocery_list,d):
    web_url=[]
    ap=[]
    al=[]
    for i in range(0,len(url_start)):
        print "processing for url that starts with",url_start[i]
        for j in range(0,len(grocery_list)):
            query = url_start[i]+grocery_list[j]#query to search 
            print "query",query
            time.sleep(20)
            ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
            p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
            ip=ip+':'+p
            # Configure Proxy Option
            prox = Proxy()
            prox.proxy_type = ProxyType.MANUAL
            
            # Proxy IP & Port
            prox.http_proxy = ip
            prox.https_proxy = ip
            
            # Configure capabilities 
            capabilities = webdriver.DesiredCapabilities.CHROME
            prox.add_to_capabilities(capabilities)

            option = webdriver.ChromeOptions()
            option.add_argument('headless')

            for k in search(query+grocery_list[j], tld="co.in", num=1, stop=1, pause=80): 
                driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe",desired_capabilities=capabilities,chrome_options=option)
                print("url",k)
                web_url.append(k)
                if k.startswith("https://www.amazon.in/"):
                    if k.endswith("na")==False:
                        try:
                            driver.get(k)
                            driver.implicitly_wait(60)
                            driver.implicitly_wait(120)
                            soup=BeautifulSoup(driver.page_source, 'lxml')
                            amazon1 = soup.find('span',{'class':'a-size-medium a-color-price'})
                            amazon2=soup.find('span',{'class':'a-color-price'})
                            amazon3=soup.find('span',{'class':'a-size-medium a-color-price priceBlockBuyingPriceString'})
                            amazon4=soup.find('span',{'class':'a-size-medium a-color-price priceBlockDealPriceString'})
                            if amazon1!=None:
                                ap.append(amazon1.getText())
                            elif amazon2!=None:
                                ap.append(amazon2.getText())
                            elif amazon3!=None:
                                ap.append(amazon3.getText())
                            elif amazon4!=None:
                                ap.append(amazon4.getText())
                            driver.quit()
                            print "amazon price",ap
                        except:
                            ap.append('na')
                    else:
                        ap.append('na')
                    al.append(k)
           
#    all_url=pd.DataFrame(web_url)
#    all_url.to_excel(output_dir+"all_url_amazon_{}.xlsx".format(d),index=False)   
            
    al=pd.DataFrame(al,columns=["amazon_url"])
#    al.to_excel(output_dir+"amaurl_{}.xlsx".format(d),index=False)
    ap=pd.DataFrame(ap,columns=["amazon_price"])  
#    ap.to_excel(output_dir+"amaprice_{}.xlsx".format(d),index=False)
    
    final_list=[glist,al,ap]
#    print final_list
    final_df=reduce(lambda left,right:pd.merge(left,right,left_index=True, right_index=True,how="left"),final_list)
#    print final_df
    final_df.to_excel(output_dir+"grocery_amazon_{}.xlsx".format(d),index=False)
    
    return final_df
    

def amazon_main(d):
#    d=datetime.datetime.now().date()
    grocery_list=["Aashirvaad Multigrain Flour (1 kg)",
                  "Madhur sugar (1kg)",
                  "Devaaya rice (5 kg)",
                  "Fortune Sunflower Oil (5 ltr)",
                  "Tur dal private label (1 kg)",
                  "Solimo Premium Cashews (500 gm)",
                  "Cumin (100 gm)",
                  "Kellogg's Cornflakes - Original (875 gm)",
                  "Tropicana Orange 100% Juice, 1000ml",
                  "Parle G Biscuits (800 gm)",
                  "Hide and Seek Biscuits (120 gm)",
                  "Britannia Bourbon (150 gm)",
                  "Amul Butter (500 gm)",
                  "Amul Taaza Milk (1 ltr)",
                  "Brooke Bond Red Label (500 gm)",
                  "Nescafe Instant Coffee (50 gm jar)",
                  "Dove Intense Repair (340 ml)",
                  "Sunsilk thick and long (340 ml)",
                  "Pantene Silky Smooth care (675 ml)",
                  "Clinic Plus Strong & Long (650 ml)",
                  "Lux Fresh Splash (3x150 gm)",
                  "Dettol Cool Soap (3x75 gm)",
                  "Pears Soap (3x125 gm)",
                  "Lifebuoy (4x125 gm)",
                  "Rin detergent powder (1 kg)",
                  "Surf Excel Quick Wash (2 kg)",
                  "Tide Plus (2 kg)",
                  "Ariel Matic front load (1 kg)",
                  "Colgate calci-lock (150 gm)",
                  "Himalaya sparkling white herbal (150 gm)",
                  "Pepsodent germicheck (300 gm)"]
    
   

    glist=pd.DataFrame(grocery_list,columns=["grocery_items"])

    
    url_start=["https://www.amazon.in/"]
    
    final_df=process_url(glist,url_start,grocery_list,d)
    
    return final_df

#amazon_main()