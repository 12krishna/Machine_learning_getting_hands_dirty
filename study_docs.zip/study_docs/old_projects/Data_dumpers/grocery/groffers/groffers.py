from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options 
from fake_useragent import UserAgent
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.common.exceptions import TimeoutException
#from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime
import pandas as pd, shutil
from googlesearch import search 
import os 
import random
from selenium.webdriver.common.proxy import Proxy,ProxyType

output_dir='D:\\Data_dumpers\\grocery\\groffers\\output\\'
_url = "https://blinkit.com/"

def process_url(glist,url_start,grocery_list,d):
    web_url=[]
    gp=[]
    gl=[]
    for i in range(0,len(url_start)):
        print "processing for url that starts with",url_start[i]
        for j in range(0,len(grocery_list)):
            query = url_start[i]+grocery_list[j]#query to search 
            print "query",query
            time.sleep(20)
            
            ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
            p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
            ip=ip+':'+p
            
            # Configure Proxy Option
            prox = Proxy()
            prox.proxy_type = ProxyType.MANUAL
            
            # Proxy IP & Port
            prox.http_proxy = ip
            prox.https_proxy = ip
            
            # Configure capabilities 
            capabilities = webdriver.DesiredCapabilities.CHROME
            prox.add_to_capabilities(capabilities)

            option = webdriver.ChromeOptions()
            option.add_argument('headless')

            for k in search(query, tld="co.in", num=1, stop=1, pause=80): 
                driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe",desired_capabilities=capabilities,chrome_options=option)
                print("url",k)
                web_url.append(k)              
                if k.startswith(_url):
                    if k.endswith("na")==False:
                        try:
                            driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe")
                            driver.get(k)
                            driver.implicitly_wait(60)
                            driver.implicitly_wait(120)
                            soup=BeautifulSoup(driver.page_source, 'lxml')
                            groffers = soup.find('div',{'class':'css-901oao r-cqee49 r-1b1savu r-1b43r93 r-14yzgew r-1d4mawv'})
                            gp.append(groffers.getText())
                            driver.quit()
                            print "groffers price",gp
                        except:
                            gp.append('na')
                    else:
                        gp.append('na')
                    gl.append(k)
                else:
                     gl.append('na')
                     gp.append('na')
#    all_url=pd.DataFrame(web_url)
#    all_url.to_excel(output_dir+"all_url_{}.xlsx".format(d),index=False)   
            
    gl=pd.DataFrame(gl,columns=["groferrs_url"])
#    gl.to_excel(output_dir+"groferurl_{}.xlsx".format(d),index=False)
    gp=pd.DataFrame(gp,columns=["groffers_price"])
#    gp.to_excel(output_dir+"groferprice_{}.xlsx".format(d),index=False)
    
    final_list=[glist,gl,gp]
#    print final_list
    final_df=reduce(lambda left,right:pd.merge(left,right,left_index=True, right_index=True,how="left"),final_list)
#    print final_df
    final_df.to_excel(output_dir+"grocery_groffers_{}.xlsx".format(d),index=False)
    
    return final_df

def groffers_main(d):
#    d=datetime.datetime.now().date()
    grocery_list=["Aashirvaad Multigrain Flour (1 kg)",
                  "Madhur Sugar (1kg)",
                  "Devaaya rice (5 kg)",
                  "Fortune Sunflower Oil (5 ltr)",
                  "Tur dal (1 kg)",
                  "Cashew nut - private label (500 gm)",
                  "Cumin - private label (100 gm)",
                  "Kellogg's Cornflakes - Original (875 gm)",
                  "Tropicana 100% Orange Juice (1 ltr)",
                  "Parle G Biscuits (800 gm)",
                  "Hide and Seek Biscuits (120 gm)",
                  "Britannia Bourbon (150 gm)",
                  "Amul Butter (500 gm)",
                  "Amul Taaza Milk (1 ltr)",
                  "Brooke Bond Red Label (500 gm)",
                  "Nescafe Instant Coffee (50 gm jar)",
                  "Dove Intense Repair (340 ml)",
                  "Sunsilk thick and long (340 ml)",
                  "Pantene Silky Smooth care (675 ml)",
                  "Clinic Plus Strong & Long (650 ml)",
                  "Lux Fresh Splash (3x150 gm)",
                  "Dettol Cool Soap (3x75 gm)",
                  "Pears Soap (3x125 gm)",
                  "Lifebuoy (4x125 gm)",
                  "Rin detergent powder (1 kg)",
                  "Surf Excel Quick Wash (2 kg)",
                  "Tide Plus (2 kg)",
                  "Ariel Matic front load (1 kg)",
                  "Colgate calci-lock (150 gm)",
                  "Himalaya sparkling white herbal (150 gm)",
                  "Pepsodent germicheck (300 gm)"]

    glist=pd.DataFrame(grocery_list,columns=["grocery_items"])

    
    url_start=[_url]
    
    final_df=process_url(glist,url_start,grocery_list,d)
    
    return final_df
#main()