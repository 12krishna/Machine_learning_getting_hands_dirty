from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options 
#from fake_useragent import UserAgent
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.common.exceptions import TimeoutException
#from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime,re,os,random,shutil
from functools import reduce
import pandas as pd 
from googlesearch import search 
from selenium.webdriver.common.proxy import Proxy,ProxyType

output_dir='D:\\Data_dumpers\\grocery\\reliance\\output\\'

def process_url(glist,url_start,grocery_list,d):
    rp=[]
    rl=[]
    for i in range(0,len(url_start)):
        print("processing for url that starts with",url_start[i])
        for j in range(0,len(grocery_list)):
            query = url_start[i]+grocery_list[j]#query to search 
            print("query",query)
            time.sleep(20)
            
            ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
            p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
            ip=ip+':'+p
            
            # Configure Proxy Option
            prox = Proxy()
            prox.proxy_type = ProxyType.MANUAL
            
            # Proxy IP & Port
            prox.http_proxy = ip
            prox.https_proxy = ip
            
            # Configure capabilities 
            capabilities = webdriver.DesiredCapabilities.CHROME
            prox.add_to_capabilities(capabilities)

            option = webdriver.ChromeOptions()
            option.add_argument('headless')

            for k in search(query+grocery_list[j], tld="co.in", num=1, stop=1, pause=5): 
                driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe",desired_capabilities=capabilities,chrome_options=option)
                print("url",k)
                rl.append(k)
                if k.startswith("https://www.jiomart.com/"):
                    if k.endswith("na")==False:
                        driver.get(k)
                        driver.implicitly_wait(0)
                        driver.implicitly_wait(0)
                        soup=BeautifulSoup(driver.page_source, 'lxml')
                        
                        if grocery_list[j]=="Madhur Pure & Hygienic Sugar 1 Kg" or grocery_list[j]=="Devaaya rice (5 kg)" or grocery_list[j]=="Tur dal - private label (1 kg)" or grocery_list[j]=="good life cashews 100 gm" or grocery_list[j]=="Good Life Jeera Powder 100 gm" or grocery_list[j]=="Amul Butter (500 gm)" or grocery_list[j]=="Amul Taaza Milk (1 ltr)" or grocery_list[j]=="Nescafe Instant Coffee (50 gm jar)" or grocery_list[j]=="Pears Pure & Gentle Soap with Natural Oils 125 g (Pack of 3)" or grocery_list[j]=="Lifebuoy Total 10 Soap 125 g (Pack of 4)" or grocery_list[j]=="Surf Excel Quick Wash (2 kg)" or grocery_list[j]=="Ariel Matic Front Load Detergent Powder 1 kg":
                            check_string=soup.find('span',{'class':'final-price'})
                            try:
                                price=check_string.span.text
                                rp.append(price)
                                print(grocery_list[j],price)
                            except:
                                rp.append('na')
                                print("price not available")
                        else:
                            rp.append('na')
                            print("item not available")
                else:
                    rp.append('na')
                    print("link not available")
              
    rl=pd.DataFrame(rl,columns=["reliance_url"])
#    rl.to_excel(output_dir+"rilurl_{}.xlsx".format(d),index=False)
    rp=pd.DataFrame(rp,columns=["reliance_price"])
#    rp.to_excel(output_dir+"rilprice_{}.xlsx".format(d),index=False)

    final_list=[glist,rl,rp]
#    print (final_list)
    final_df=reduce(lambda left,right:pd.merge(left,right,left_index=True, right_index=True,how="left"),final_list)
#    print (final_df)
    final_df.to_excel(output_dir+"grocery_reliance_{}.xlsx".format(d),index=False)
    
    return final_df

def reliance_main(d):
#    d=datetime.datetime.now().date()
    grocery_list=["Aashirvaad Multigrain Flour (1 kg)",
                  "Madhur Pure & Hygienic Sugar 1 Kg",
                  "Devaaya rice (5 kg)",
                  "Fortune Sunflower Oil (5 ltr)",
                  "Tur dal - private label (1 kg)",
                  "good life cashews 100 gm",
                  "Good Life Jeera Powder 100 gm",
                  "Kellogg's Cornflakes - Original (875 gm)",
                  "Tropicana 100% Orange Juice 1 Ltr",
                  "Parle G Biscuits (800 gm)",
                  "Hide and Seek Biscuits (120 gm)",
                  "Britannia Bourbon (150 gm)",
                  "Amul Butter (500 gm)",
                  "Amul Taaza Milk (1 ltr)",
                  "Brooke Bond Red Label (500 gm)",
                  "Nescafe Instant Coffee (50 gm jar)",
                  "Dove Intense Repair (340 ml)",
                  "Sunsilk thick and long (340 ml)",
                  "Pantene Silky Smooth care (675 ml)",
                  "Clinic Plus Strong & Long (650 ml)",
                  "Lux Fresh Splash Bar Soap 150 gm (Pack of 3)",
                  "Dettol Cool Soap (3x75 gm)",
                  "Pears Pure & Gentle Soap with Natural Oils 125 g (Pack of 3)",
                  "Lifebuoy Total 10 Soap 125 g (Pack of 4)",
                  "Rin detergent powder (1 kg)",
                  "Surf Excel Quick Wash (2 kg)",
                  "Tide Plus (2 kg)",
                  "Ariel Matic Front Load Detergent Powder 1 kg",
                  "Colgate calci-lock (150 gm)",
                  "Himalaya sparkling white herbal (150 gm)",
                  "Pepsodent germicheck (300 gm)"]

    glist=pd.DataFrame(grocery_list,columns=["grocery_items"])

    
    url_start=["https://www.jiomart.com/"]
    
    final_df=process_url(glist,url_start,grocery_list,d)
    
    return final_df

#reliance_main(datetime.datetime.now().date())