# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 10:47:54 2021

@author: shashanks
"""

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options 
from bs4 import BeautifulSoup
import time,datetime,re,os,random,shutil
from functools import reduce
import pandas as pd 
from googlesearch import search
import time

output_dir='D:\\Data_dumpers\\grocery\\reliance\\output\\' 

def price():
    try:
        driver.implicitly_wait(10)    
        li=driver.find_element_by_class_name("final-price").text
        print((li))
        rp.append(li)
        
    except:
        print("na")
        rp.append("na")
        
options = Options()
options.headless = True        
driver = webdriver.Chrome("D:\\Data_dumpers\\Master\\chromedriver.exe", chrome_options=options)

grocery_list=["Aashirvaad Multigrain Flour (1 kg)",
                  "Madhur Pure & Hygienic Sugar 1 Kg",
                  "Devaaya rice (5 kg)",
                  "Fortune Sunflower Oil (5 ltr)",
                  "Tur dal - private label (1 kg)",
                  "cashews 100 gm",
                  "jeera powder 100 gm",
                  "Kellogg's Cornflakes - Original (875 gm)",
                  "Tropicana 100% Orange Juice 1 Ltr",
                  "Parle-G Original Glucose Biscuits 800 g",
                  "Hide and Seek Biscuits (120 gm)",
                  "Britannia Bourbon (150 gm)",
                  "Amul Butter (500 gm)",
                  "Amul Taaza Milk (1 ltr)",
                  "Red Label",
                  "Nescafe Instant Coffee (50 gm jar)",
                  "Dove Intense Repair (340 ml)",
                  "Sunsilk thick and long",
                  "Pantene Silky Smooth care (675 ml)",
                  "Clinic Plus Strong & Long (650 ml)",
                  "Lux Fresh Splash Bar Soap 150 gm (Pack of 3)",
                  "Dettol Cool Soap (3x75 gm)",
                  "Pears Pure & Gentle Soap with Natural Oils 125 g (Pack of 3)",
                  "Lifebuoy Total 10 Soap 125 g (Pack of 4)",
                  "Rin detergent powder (1 kg)",
                  "Surf Excel Quick Wash (2 kg)",
                  "Tide Plus (2 kg)",
                  "Ariel Matic Front Load Detergent Powder 1 kg",
                  "Colgate calci-lock (150 gm)",
                  "Himalaya sparkling white herbal (150 gm)",
                  "Pepsodent germicheck (300 gm)"]
    



glist=pd.DataFrame(grocery_list,columns=["grocery_items"])
url_start=["https://www.jiomart.com/"]


rp=[]
rl=[] 

for i in range(0,len(url_start)):
    print("processing for url that starts with",url_start[i])
    for j in range(0,len(grocery_list)):
        query = url_start[i]+grocery_list[j]#query to search 
        print("query",query)
        time.sleep(10)

        for k in search(query+grocery_list[j], tld="co.in", num=1, stop=1, pause=5): 
            print("url",k)
            rl.append(k)
            
            
            
def process_url():
    
        
    driver.get(rl[0])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Aashirvaad Whole')]" and "//*[contains(text(), '1 kg')]")
        element.click()
    except:
        pass
    price()
    
    driver.get(rl[1])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Madhur')]" and "//*[contains(text(), 'Sugar 1 kg')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[2])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Daawat Devaaya')]" and "//*[contains(text(), '5 kg')]")
    except:
        pass
    price()   
        
    
    driver.get(rl[3])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Fortune')]" and "//*[contains(text(), 'Sunflower')]" and "//*[contains(text(), ' 5 L')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[4])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Good Life Tur Dal 1 kg')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[5])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Cashews 100 g')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[6])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Cumin Powder 100 g')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[7])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'corn-flakes')]" and "//*[contains(text(), '875 g')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[8])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Tropicana Orange')]" and "//*[contains(text(), ' 1 L')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[9])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Parle-G Original Glucose ')]" and "//*[contains(text(), ' 800 g')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[10])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Hide & Seek')]" and "//*[contains(text(), ' 120 g')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[11])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Britannia-Bourbon')]" and "//*[contains(text(), ' 150 g')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[12])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Amul Butter 500 g')]")
        element.click()
    except:
        pass
    price()   
    
    
    driver.get(rl[13])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Amul Taaza')]" and "//*[contains(text(), ' 1 L')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[14])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Red Label')]" and "//*[contains(text(), ' 500 g')]")
        element.click()
    except:
        pass
    price()   
        
    driver.get(rl[15])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Nescafe')]" and "//*[contains(text(), ' 50 g')]")
        element.click()
    except:
        pass
    price()   
        
    driver.get(rl[16])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Dove')]" and "//*[contains(text(), 'Intense Repair')]" and "//*[contains(text(), '34')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[17])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Sunsilk')]" and "//*[contains(text(), 'Thick & Long')]" and "//*[contains(text(), '340')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[18])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Pantene')]" and "//*[contains(text(), 'Silky Smooth ')]" and "//*[contains(text(), '650')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[19])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Clinic Plus Strong')]" and "//*[contains(text(), ' 650')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[20])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Lux')]" and "//*[contains(text(), ' 150 g')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[21])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Dettol Cool')]" and "//*[contains(text(), '75')]" and "//*[contains(text(), '3')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[22])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Pears')]" and "//*[contains(text(), ' 125 g')]" and "//*[contains(text(), '3')]")
        element.click()
    except:
        pass
    price()   
        
    driver.get(rl[23])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Lifebuoy')]" and "//*[contains(text(), ' 125 g')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[24])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Rin')]" and "//*[contains(text(), '1 kg')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[25])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Surf Excel Quick Wash')]" and "//*[contains(text(), '2 kg')]")
        element.click()
    except:
        pass
    price()   
        
    try:
        driver.get(rl[26])
        driver.implicitly_wait(10)
    except:
        price()
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Tide Plus')]" and "//*[contains(text(), '2 kg')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[27])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Ariel')]" and "//*[contains(text(), 'Front')]" and "//*[contains(text(), '1 kg')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[28])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Colgate Strong Teeth')]" and "//*[contains(text(), ' 150 g')]")
        element.click()
    except:
        pass
    price()   
        
    
    driver.get(rl[29])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Himalaya')]" and "//*[contains(text(), 'Sparkling')]" and "//*[contains(text(), ' 150 g')]")
        element.click()
    except:
        pass
    price()   
    
    
    driver.get(rl[30])
    driver.implicitly_wait(10)
    try:
        element = driver.find_element_by_xpath("//*[contains(text(), 'Pepsodent Germi Check')]" and "//*[contains(text(), ' 300 g')]")
        element.click()
    except:
        pass
    price()
    

#d=datetime.datetime.now().date()
def reliance_main(d):
    process_url()
    global rl, rp
    rl=pd.DataFrame(rl,columns=["reliance_url"])
    #    rl.to_excel(output_dir+"rilurl_{}.xlsx".format(d),index=False)
    rp=pd.DataFrame(rp,columns=["reliance_price"])
    #    rp.to_excel(output_dir+"rilprice_{}.xlsx".format(d),index=False)
    
    final_list=[glist,rl,rp]
    #    print (final_list)
    final_df=reduce(lambda left,right:pd.merge(left,right,left_index=True, right_index=True,how="left"),final_list)
    #    print (final_df)
    final_df.to_excel(output_dir+"grocery_reliance_{}.xlsx".format(d),index=False)
    
    return final_df