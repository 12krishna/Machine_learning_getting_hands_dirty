from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options 
from fake_useragent import UserAgent
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.common.exceptions import TimeoutException
#from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime
import pandas as pd, shutil
from googlesearch import search 
import os 
import random
from selenium.webdriver.common.proxy import Proxy,ProxyType

def get_value(driver):
#    driver.implicitly_wait(60)
#    driver.implicitly_wait(120)
    soup=BeautifulSoup(driver.page_source, 'lxml')
    try:
        easydayd = soup.find('div',{'class':'DiscountPrice clearfix'}).getText()
        print "easydayd",easydayd
    except:
        easydayd=0
    try:
        easydayc = soup.find('div',{'class':'clearfix'}).getText()
        print "easydayc",easydayc
    except:
        easydayc=0
    try:
        easydaym=soup.find('div',{'class':'pdpPrice clearfix'}).getText()
        print "easydaym",easydaym
    except:
        easydaym=0
                        
    easyday_list=[easydayd,easydayc,easydaym]
    easyday_list=filter(lambda a: a != 0, easyday_list)
    easyday_list=min(easyday_list)
    
    print "easyday price",easyday_list
    
    return easyday_list

def process_url(glist,grocery_list,web_url,d):
   
    ep=[]
    el=[]
    for i in range(0,len(grocery_list)):
        time.sleep(10)
        ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
        p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
        ip=ip+':'+p
        # Configure Proxy Option
        prox = Proxy()
        prox.proxy_type = ProxyType.MANUAL
        # Proxy IP & Port
        prox.http_proxy = ip
        prox.https_proxy = ip            
        # Configure capabilities 
        capabilities = webdriver.DesiredCapabilities.CHROME
        prox.add_to_capabilities(capabilities)

        option = webdriver.ChromeOptions()
        option.add_argument('headless')
        driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe",desired_capabilities=capabilities,chrome_options=option)
        
        if web_url[i].startswith("https://shop.easyday.in/"):
#            if grocery_list[i]=="Aashirvaad Multigrain Flour (1 kg)":
#                ep.append('na')
            if grocery_list[i]=="Devaaya rice (5 kg)":
                print "getting rice"
                driver.get(web_url[i]) 
                driver.find_element_by_xpath('//*[@id="variantview"]').click()
                ep.append(get_value(driver))
                print "easy day price from function",ep
            elif grocery_list[i]=="Fortune Sunflower Oil (5 ltr)":
                print"getting oil"
                driver.get(web_url[i]) 
                driver.find_element_by_xpath('//*[@id="variantview"]').click()
                ep.append(get_value(driver))
                print "easy day price from function",ep    
            else: 
                print "getting others"
                driver.get(web_url[i]) 
                ep.append(get_value(driver))
        else:
            ep.append('na')
        el.append(web_url[i])
           
    el=pd.DataFrame(el,columns=["easyday_url"])
    el.to_excel("elurl_{}.xlsx".format(d),index=False)
    ep=pd.DataFrame(ep,columns=["easyday_price"])    
    ep.to_excel("elprice_easyday_{}.xlsx".format(d),index=False)

    final_list=[glist,el,ep]
#    print final_list
    final_df=reduce(lambda left,right:pd.merge(left,right,left_index=True, right_index=True,how="left"),final_list)
#    print final_df
    final_df.to_excel("grocery_{}.xlsx".format(d),index=False)
    

def main():
    d=datetime.datetime.now().date()
    
    web_url=['na',
             'https://shop.easyday.in/productDetails/Sugar---Double-Refined-Regular/UT709SS98DGRINFUR/3479',
             'https://shop.easyday.in/productDetails/Basmati-Rice---Devaaya/DA140RC33DNAINFUR/3479',
             'https://shop.easyday.in/productDetails/Sunflower-Oil---Refined/FO215EO69AYGINFUR/3479']

#    grocery_list=["Aashirvaad Multigrain Flour (1 kg)","Uttam Sugar 1kg",
#                  "Devaaya rice (5 kg)",
#                  "Fortune Sunflower Oil (5 ltr)","Tur dal - private label (1 kg)",
#                  "Cashew nut - private label (500 gm)","Cumin - private label (100 gm)",
#                  "Kellogg's Cornflakes - Original (875 gm)","Tropicana Orange Juice (1 ltr)",
#                  "Parle G Biscuits (800 gm)","Hide and Seek Biscuits (120 gm)",
#                  "Britannia Bourbon (150 gm)","Amul Butter (500 gm)",
#                  "Amul Taaza Milk (1 ltr)","Brooke Bond Red Label (500 gm)",
#                  "Nescafe Instant Coffee (50 gm jar)","Dove Intense Repair (340 ml)",
#                  "Sunsilk thick and long (340 ml)","Pantene Silky Smooth care (675 ml)",
#                  "Clinic Plus Strong & Long (650 ml)","Lux Fresh Splash (3x150 gm)",
#                  "Dettol Cool Soap (3x75 gm)","Pears Soap (3x125 gm)",
#                  "Lifebuoy (4x125 gm)","Rin detergent powder (1 kg)",
#                  "Surf Excel Quick Wash (2 kg)","Tide Plus (2 kg)",
#                  "Ariel Matic front load (1 kg)","Colgate calci-lock (150 gm)",
#                  "Himalaya sparkling white herbal (150 gm)","Pepsodent germicheck (300 gm)"]

    grocery_list=["Aashirvaad Multigrain Flour (1 kg)","Uttam Sugar 1kg",
                  "Devaaya rice (5 kg)",
                  "Fortune Sunflower Oil (5 ltr)"]
    
    glist=pd.DataFrame(grocery_list,columns=["grocery_items"])

    
    process_url(glist,grocery_list,web_url,d)
    
main()
