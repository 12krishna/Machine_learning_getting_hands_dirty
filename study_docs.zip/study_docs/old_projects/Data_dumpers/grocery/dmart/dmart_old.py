from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options 
from fake_useragent import UserAgent
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.common.exceptions import TimeoutException
#from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time,datetime
import pandas as pd, shutil
from googlesearch import search 
import os,re
import random
from selenium.webdriver.common.proxy import Proxy,ProxyType
output_dir="D:\\Data_dumpers\\grocery\\dmart\\output\\"

def process_url(glist,grocery_list,urll):
    web_url=[]
    dp=[]
    dl=[]

#    for i in range(0,len(url_start)):
#        print "processing for url that starts with",url_start[i]
    for j in range(0,len(grocery_list)):
#        query = url_start[i]+grocery_list[j]#query to search 
#            print "query",query
#            time.sleep(10)
#            ua = UserAgent()
#            user_agent = ua.random
        ip = '{}.{}.{}.{}'.format(*__import__('random').sample(range(0,255),4))
        p = '{}'.format(*__import__('random').sample(range(1000,8000),1))
        ip=ip+':'+p
        # Configure Proxy Option
        prox = Proxy()
        prox.proxy_type = ProxyType.MANUAL
        
        # Proxy IP & Port
        prox.http_proxy = ip
        #prox.socks_proxy = ip
        #prox.ssl_proxy = ip
        prox.https_proxy = ip
        
        # Configure capabilities 
        capabilities = webdriver.DesiredCapabilities.CHROME
        prox.add_to_capabilities(capabilities)
        option = webdriver.ChromeOptions()
        option.add_argument('headless')
#            option.add_argument('user-agent'=user_agent)

#            for k in search(query+grocery_list[j], tld="co.in", num=1, stop=1, pause=10): 
#            for k in range(0,len(urll)):
        driver = webdriver.Chrome("D:\Data_dumpers\Master\chromedriver.exe",desired_capabilities=capabilities,chrome_options=option)
        driver.implicitly_wait(60)
        driver.implicitly_wait(120)
        print("url",urll["dmart_url"][j])
        web_url.append(urll["dmart_url"][j])
        if urll["dmart_url"][j].startswith("https://www.dmart.in/"):
            if urll["dmart_url"][j].endswith("na")==False:
                try:
                    driver.get(urll["dmart_url"][j])
#                            print grocery_list[j]                            
                    if grocery_list[j]=="Aashirvaad Multigrain Flour (1 kg)" or grocery_list[j]=="Madhur sugar (1kg)" or grocery_list[j]=="Rin detergent powder (1 kg)" or grocery_list[j]=="Ariel Matic front load (1 kg)":
                        soup=BeautifulSoup(driver.page_source, 'lxml')
                        li=soup.find_all('a',{'title':'1 kg'})
                        print li
                        for link in li:
                            print(link.get('id'))
                        final_li=link.get('id')
                        final_li = re.sub('\s+','',final_li)
                        final_li=final_li.split('|')
                        val=final_li[3]
                        dp.append(val)
                        driver.quit() 
                        print "dmart ready price",dp
                        
                    if grocery_list[j]=="Fortune Sunflower Oil (5 ltr)":
                        soup=BeautifulSoup(driver.page_source, 'lxml')
                        li=soup.find_all('a',{'title':'5 L'})
                        print li
                        for link in li:
                            print(link.get('id'))
                        final_li=link.get('id')
                        final_li = re.sub('\s+','',final_li)
                        final_li=final_li.split('|')
                        val=final_li[3]
                        dp.append(val)
                        driver.quit()
                        print "dmart ready price",dp
                            
                    if grocery_list[j]=="Cumin - Premia (100 gm)":
                        soup=BeautifulSoup(driver.page_source, 'lxml')
                        li=soup.find_all('a',{'title':'100 gm'})
                        print li
                        for link in li:
                            print(link.get('id'))
                        final_li=link.get('id')
                        final_li = re.sub('\s+','',final_li)
                        final_li=final_li.split('|')
                        val=final_li[3]
                        dp.append(val)
                        driver.quit()
                        print "dmart ready price",dp
                                
                    if grocery_list[j]=="Brooke Bond Red Label (500 gm)":
                        soup=BeautifulSoup(driver.page_source, 'lxml')
                        li=soup.find_all('a',{'title':'500 gm'})
                        print li
                        for link in li:
                            print(link.get('id'))
                        final_li=link.get('id')
                        final_li = re.sub('\s+','',final_li)
                        final_li=final_li.split('|')
                        val=final_li[3]
                        dp.append(val)
                        driver.quit()
                        print "dmart ready price",dp
        
                    if grocery_list[j]=="Sunsilk thick and long (340 ml)":
                        soup=BeautifulSoup(driver.page_source, 'lxml')
                        li=soup.find_all('a',{'title':'340 ml'})
                        print li
                        for link in li:
                            print(link.get('id'))
                        final_li=link.get('id')
                        final_li = re.sub('\s+','',final_li)
                        final_li=final_li.split('|')
                        val=final_li[3]
                        dp.append(val)
                        driver.quit()
                        print "dmart ready price",dp    
                                
                    if grocery_list[j]=="Pantene Silky Smooth care (675 ml)":
                        soup=BeautifulSoup(driver.page_source, 'lxml')
                        li=soup.find_all('a',{'title':'650 ml'})
                        print li
                        for link in li:
                            print(link.get('id'))
                        final_li=link.get('id')
                        final_li = re.sub('\s+','',final_li)
                        final_li=final_li.split('|')
                        val=final_li[3]
                        dp.append(val)
                        driver.quit()
                        print "dmart ready price",dp    
                                
                    if grocery_list[j]=="Surf Excel Quick Wash (2 kg)":
                        soup=BeautifulSoup(driver.page_source, 'lxml')
                        li=soup.find_all('a',{'title':'2 kg'})
                        print li
                        for link in li:
                            print(link.get('id'))
                        final_li=link.get('id')
                        final_li = re.sub('\s+','',final_li)
                        final_li=final_li.split('|')
                        val=final_li[3]
                        dp.append(val) 
                        driver.quit()
                        print "dmart ready price",dp    
                                
                    if grocery_list[j]=="Colgate calci-lock (150 gm)":
                        soup=BeautifulSoup(driver.page_source, 'lxml')
                        li=soup.find_all('a',{'title':'150 gm'})
                        print li
                        for link in li:
                            print(link.get('id'))
                        final_li=link.get('id')
                        final_li = re.sub('\s+','',final_li)
                        final_li=final_li.split('|')
                        val=final_li[3]
                        dp.append(val)     
                        driver.quit()
                        print "dmart ready price",dp
                                
                    if grocery_list[j]== "Tur dal - Premia (1 kg)" or grocery_list[j]=="Hide and Seek Biscuits (120 gm)" or grocery_list[j]=="Dove Intense Repair (340 ml)" or grocery_list[j]== "Lux Fresh Splash (3x150 gm)" or grocery_list[j]=="Lifebuoy (4x125 gm)":
                        dp.append("na")
                        driver.quit()
                        print "dmart ready price",dp    
                    else:
                        dmart = soup.find('span',{'class':'pdp-price-panel__primary--price-dmart'})
                        dp.append(dmart.getText())
                        driver.quit()
                        print "dmart ready price",dp
                except:
                    dp.append('na')
                    print "na"
            else:
                dp.append('na')
                print "na"
        else:
            dp.append('na')
            print "na"
        dl.append(urll["dmart_url"][j])
 
#    all_url=pd.DataFrame(web_url)
#    all_url.to_excel(output_dir+"all_url.xlsx",index=False)   
            
    dl=pd.DataFrame(dl,columns=["dmart_url"])
#    dl.to_excel(output_dir+"dmaurl.xlsx",index=False)
    dp=pd.DataFrame(dp,columns=["dmart_price"])
#    dp.to_excel(output_dir+"dmaprice.xlsx",index=False)

    final_list=[glist,dl,dp]
#    print final_list
    final_df=reduce(lambda left,right:pd.merge(left,right,left_index=True, right_index=True,how="left"),final_list)
#    print final_df
    final_df.to_excel(output_dir+"grocery_dmart.xlsx",index=False)
    

def main():
    grocery_list=["Aashirvaad Multigrain Flour (1 kg)",
                 "Madhur sugar (1kg)",
                  "Devaaya rice (5 kg)",
                  "Fortune Sunflower Oil (5 ltr)",
                  "Tur dal - Premia (1 kg)",
                  "Cashew nut - Premia (500 gm)",
                  "Cumin - Premia (100 gm)",
                  "Kellogg's Cornflakes - Original (875 gm)",
                  "Tropicana Orange Juice (1 ltr)",
                  "Parle G Biscuits (800 gm)",
                  "Hide and Seek Biscuits (120 gm)",
                  "Britannia Bourbon (150 gm)",
                  "Amul Butter (500 gm)",
                  "Amul Taaza Milk (1 ltr)",
                  "Brooke Bond Red Label (500 gm)",
                  "Nescafe Instant Coffee (50 gm jar)",
                  "Dove Intense Repair (340 ml)",
                  "Sunsilk thick and long (340 ml)",
                  "Pantene Silky Smooth care (675 ml)",
                  "Clinic Plus Strong & Long (650 ml)",
                  "Lux Fresh Splash (3x150 gm)",
                  "Dettol Cool Soap (3x75 gm)",
                  "Pears Soap (3x125 gm)",
                  "Lifebuoy (4x125 gm)",
                  "Rin detergent powder (1 kg)",
                  "Surf Excel Quick Wash (2 kg)",
                  "Tide Plus (2 kg)",
                  "Ariel Matic front load (1 kg)",
                  "Colgate calci-lock (150 gm)",
                  "Himalaya sparkling white herbal (150 gm)",
                  "Pepsodent germicheck (300 gm)"]

    dmarturl=pd.read_excel('D:\Data_dumpers\grocery\dmart\dmart_url_link_information.xlsx')
    dmarturl.reset_index(drop=True,inplace=True)
#    k=dmarturl['dmart_url'][0]
    glist=pd.DataFrame(grocery_list,columns=["grocery_items"])
    print glist

    
#    url_start=["https://www.dmart.in/"]
    
#    process_url(glist,url_start,grocery_list,dmarturl)
    process_url(glist,grocery_list,dmarturl)
    
main()