import pandas as pd
import imp
import datetime

output_dir="D:\\Data_dumpers\\grocery\\output\\"
email_dir="D:\\Emails\\Output\\"
d=datetime.datetime.now().date()

grocerylist=["Aashirvaad Multigrain Flour (1 kg)",
             "Branded sugar (1 kg)",
             "Devaaya rice (5 kg)",
             "Fortune Sunflower Oil (5 ltr)",
             "Tur dal - private label (1 kg)",
             "Cashew nut - private label (500 gm)",
             "Cumin - private label (100 gm)",
             "Kellogg's Cornflakes - Original (875 gm)",
             "Tropicana Orange Juice (1 ltr)",
             "Parle G Biscuits (800 gm)",
             "Hide and Seek Biscuits (120 gm)",
             "Britannia Bourbon (150 gm)",
             "Amul Butter (500 gm)",
             "Amul Taaza Milk (1 ltr)",
             "Brooke Bond Red Label (500 gm)",
             "Nescafe Instant Coffee (50 gm jar)",
             "Dove Intense Repair (340 ml)",
             "Sunsilk thick and long (340 ml)",
             "Pantene Silky Smooth care (675 ml)",
             "Clinic Plus Strong & Long (650 ml)",
             "Lux Fresh Splash (3x150 gm)",
             "Dettol Cool Soap (3x75 gm)",
             "Pears Soap (3x125 gm)",
             "Lifebuoy (4x125 gm)",
             "Rin detergent powder (1 kg)",
             "Surf Excel Quick Wash (2 kg)",
             "Tide Plus (2 kg)",
             "Ariel Matic front load (1 kg)",
             "Colgate calci-lock (150 gm)",
             "Himalaya sparkling white herbal (150 gm)",
             "Pepsodent germicheck (300 gm)"]


amazon=imp.load_source('amazon.py', 'D:\\Data_dumpers\\grocery\\amazon\\amazon.py')
amazon=amazon.amazon_main(d)


bigbasket=imp.load_source('bigbasket.py', 'D:\\Data_dumpers\\grocery\\bigbasket\\bigbasket.py')
bigbasket=bigbasket.bigbasket_main(d)

flipkart=imp.load_source('flipkart.py', 'D:\\Data_dumpers\\grocery\\flipkart\\flipkart.py')
flipkart=flipkart.flipkart_main(d)

groffers=imp.load_source('groffers.py', 'D:\\Data_dumpers\\grocery\\groffers\\groffers.py')
groffers=groffers.groffers_main(d)

reliance=imp.load_source('reliance.py', 'D:\\Data_dumpers\\grocery\\reliance\\reliance.py')
reliance=reliance.reliance_main(d)

amazon["grocery_items"]=grocerylist
bigbasket["grocery_items"]=grocerylist
flipkart["grocery_items"]=grocerylist
groffers["grocery_items"]=grocerylist
reliance["grocery_items"]=grocerylist

final_list=[amazon,bigbasket,flipkart,groffers,reliance]

final_df=reduce(lambda left,right:pd.merge(left,right,on="grocery_items"),final_list)
l1=['amazon_price','bigbasket_price','flipkart_price','groffers_price','reliance_price']

final_df=final_df.replace('\n',' ', regex=True)

for i in range(len(l1)):
    final_df['{}'.format(l1[i])]=final_df['{}'.format(l1[i])].str.replace('^[^\d]*', '')

final_df=final_df.replace(r'^\s*$','na', regex=True)

final_df.to_excel(output_dir+"combined_price_for_online_websites_{}.xlsx".format(d), index=False)
import shutil, os
shutil.copy(output_dir+"combined_price_for_online_websites_{}.xlsx".format(d),
            email_dir+"combined_price_for_online_websites_{}.xlsx".format(d))
os.system("D:\\Emails\\Email.bat")

