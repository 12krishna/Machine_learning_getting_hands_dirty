# -*- coding: utf-8 -*-
"""
Created on Thu May 26 10:58:00 2022

@author: backup
"""

# Groceries : Big Basket & Dmart & Jiomart
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from googlesearch import search
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import time,datetime
import pandas as pd, shutil
import os

# master_dir = "C:\\Users\\salomef\\Projects\\Automating Pricing Sheet"
# output_dir='C:\\Users\\salomef\\Projects\\Automating Pricing Sheet\\bigbasket\\output_2'

output_dir='D:\\Data_dumpers\\grocery\\Umang\\output\\'
master_dir = "D:\\Data_dumpers\\Master"
curr_dir = "D:\\Data_dumpers\\grocery\\Umang\\"
email_dir = "D:\\Emails\\Output\\"
_bb_waittime = 100


opts = Options()
        
opts.add_argument('--blink-settings=imagesEnabled=false')


# driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"),chrome_options=opts)
# driver.get(url)

def big_basket(grocery_items):
    # df = pd.read_excel(curr_dir+"Bigbasket.xlsx")
    url = "https://www.bigbasket.com/"
    
    item_name = [] ; final_price = [] ; product_url =[]

    start = time.time() ; #start1 = datetime.now()

    #driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))
    driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"),chrome_options=opts)
    driver.get(url)
    #time.sleep(3)
    #grocery_items = grocery_items_bb
    
    while grocery_items != []:

        try:
            # driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))
            # driver.get(url)
            
            WebDriverWait(driver, _bb_waittime).until(EC.element_to_be_clickable((By.CLASS_NAME, "arrow-marker")))
            arrow = driver.find_element_by_class_name("arrow-marker")
            arrow.click()
            
            WebDriverWait(driver, _bb_waittime).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "span.btn.btn-default.form-control.ui-select-toggle")))
            arrow2 = driver.find_element_by_css_selector("span.btn.btn-default.form-control.ui-select-toggle")  #("//input[@class='ng-binding ng-scope']")
            
            arrow2.click() 
            #time.sleep(2)
            
            #input_bar = driver.find_element_by_css_selector("input.form-control.ui-select-search.ng-pristine.ng-valid.ng-empty.ng-touched")
            #input_bar = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CLASS_NAME, "btn btn-default form-control ui-select-toggle")))

            WebDriverWait(driver, _bb_waittime).until(EC.element_to_be_clickable((By.XPATH, "//input[@placeholder='Select your city']")))
            input_bar = driver.find_element_by_xpath("//input[@placeholder='Select your city']")
            driver.execute_script("arguments[0].click();", input_bar)
            
            input_bar.send_keys("Mumbai")
            input_bar.send_keys(Keys.ENTER)
            
            WebDriverWait(driver, _bb_waittime).until(EC.element_to_be_clickable((By.ID, "areaselect")))
            pincode_bar = driver.find_element_by_id("areaselect")
            pincode_bar.send_keys("400051")
            pincode_bar.send_keys(Keys.ENTER)
            
            #time.sleep(5)
            pincode_bar.send_keys(Keys.TAB,Keys.ENTER)
        
        except:
            continue
        
        for item in grocery_items:
            try:
                #WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.TAG_NAME, "input")))
                search = driver.find_element_by_tag_name("input") ; #time.sleep(5)
                driver.execute_script("arguments[0].click();", search)
                
                search.send_keys(item)
                search.send_keys(Keys.ENTER)
                #driver.implicitly_wait(60)
                time.sleep(5)
            except :
                 break
            soup = BeautifulSoup(driver.page_source, 'lxml')
            try:
                
                product = soup.find('a',{'class':'h-full'})
                name1 = product.getText()
                quantity = soup.find('div',{'class':'py-1'})
                if quantity is None:
                    name = name1
                else:
                    name2 = quantity.getText()
                    name = name1+name2
                
                item_name.append(name)
                
                try:
                    price = soup.find('span',{'class':'Label-sc-15v1nk5-0 Pricing___StyledLabel2-pldi2d-2 bLAufN bzzgfk'}).getText()
                except :
                    price = soup.find('span',{'class':'Label-sc-15v1nk5-0 Pricing___StyledLabel-pldi2d-1 bLAufN leKnJ'}).getText()
                
                price = price.strip('₹')
                final_price.append(price)
                
                
                link = "https://www.bigbasket.com" + product['href']
                product_url.append(link)
                
                
                grocery_items.remove(item)
                #time.sleep(3)
                continue
            
            except Exception as e:
                print("e : ",e)
                print("item error : ",item)
                if soup.find('div',{'class':'Breadcrumb___StyledDiv-sc-1jdzjpl-0 dbetCH slug___StyledBreadCrumbs-sc-1pgl3kl-0 deRfZF'}) is None:
                    item_name.append(item)
                    final_price.append('na')
                    product_url.append('na')
                    grocery_items.remove(item)
                    continue
                else:
                    
                    # driver.delete_all_cookies()
                    # driver.get(url)
                    # time.sleep(3)
                    break
                
        driver.delete_all_cookies()
        driver.get(url) 
        #time.sleep(2)
        

#        except Exception as e:
#            print("error in first try:",e)
#            break
 
#        driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))
#        driver.get(url)
    end = time.time() ; #end1 = datetime.now()
           
    # print("The time of execution of above program is :", end-start)   

    # t = end1-start1

    df_1 =  pd.DataFrame(list(zip(item_name, final_price, product_url)),
                   columns =['Product_name', 'Price (Rs.)','Product_url'])


    # df_1['Product_name'] = df_1['Product_name'].apply(lambda x: x.split('- Rs')[0])

    # df_1['Price (Rs.)'] = df_1['Price (Rs.)'].apply(lambda x: x.strip('MRP: Rs'))
    df_1['Website'] = "Bigbasket"
    return df_1

   
    
def dmart(grocery_items):
    # df = pd.read_excel(curr_dir+"Dmart.xlsx")
    url = "https://www.dmart.in"

    # grocery_items = grocery_items_dm 
    item_name = [] ; final_price = [] ; product_url =[]

    start = time.time() ; #start1 = datetime.now()

    driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))
    driver.get(url)
    #WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="myTable_next"]'))).click()
    while grocery_items != []:
        
        # time.sleep(2)
        # pincode = driver.find_element_by_id("pincodeInput")
        # pincode.click()
        # driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))
        # driver.get(url)
        WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.ID, "pincodeInput")))
        pincode = driver.find_element_by_id("pincodeInput")
        pincode.click()
        pincode.send_keys("400051")
        pincode.send_keys(Keys.ENTER)
        #time.sleep(3)
        # pincode.send_keys(Keys.TAB,Keys.ENTER)
        
        #time.sleep(3)
        WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.CLASS_NAME, "src-client-components-pincode-widget-__pincode-widget-module___pincode-list")))
        ul = driver.find_element_by_class_name("src-client-components-pincode-widget-__pincode-widget-module___pincode-list")
        ul.click()
    
        WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.XPATH, '//button[normalize-space()="START SHOPPING"]')))
        button = driver.find_element_by_xpath('//button[normalize-space()="START SHOPPING"]')
        button.click()
    
        #time.sleep(3)
        
        for item in grocery_items:
            WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.ID, "scrInput")))
            search = driver.find_element_by_id("scrInput")
            search.send_keys(item)
            search.send_keys(Keys.ENTER)
            time.sleep(5)
            #driver.implicitly_wait(10)
            #WebDriverWait(driver, 60).until(EC.presence_of_element_located((By.CLASS_NAME, 'src-client-app-search-landing-styles-__search-landing-module___searchHeaderDiv')))
            soup = BeautifulSoup(driver.page_source, 'lxml')
            
            try:
                name = soup.find('a',{'class':'src-client-components-product-card-vertical-card-__vertical-card-module___title'})
                       #soup.find('a',{'class':'src-client-components-product-card-vertical-card-__vertical-card-module___title'})
                
                
                x = name.getText()
                item_name.append(x)
                
                href = name['href']
                link = url + href
                product_url.append(link)
                
                price = soup.find('span',{'class':'src-client-components-product-card-vertical-card-__vertical-card-module___amount'})
                y = price.getText()
                final_price.append(y)
                
                grocery_items.remove(item)
            except Exception as e:
                print("e : ",e)
                #continue
                driver.delete_all_cookies()
                driver.get(url)
                
    
        driver.quit()
        if grocery_items != []:
            driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))
            driver.get(url)
    end = time.time() ;

    df_1 =  pd.DataFrame(list(zip(item_name, final_price, product_url)),
                   columns =['Product_name', 'Price (Rs.)','Product_url'])
    df_1['Website'] = "Dmart"
    return df_1

def jiomart(grocery_items):
    
    url = "https://www.jiomart.com"
    product_url =[] ; 
    item_name = [] ; final_price = [] 
    
    # grocery_items = grocery_items_jio
    
    for item in grocery_items:
        query = url+item  #query to search 
        print ("query",query)
        driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))
        for j in search(query, tld="co.in", num=1, stop=1, pause=10):
            print("url : ",j)
            product_url.append(j)
            
            if j.startswith("https://www.jiomart.com"):
                if j.endswith("na")==False:
                    try:                   
                        driver.get(j)
                        driver.implicitly_wait(5)
                        
                        soup=BeautifulSoup(driver.page_source, 'lxml')
                        name = soup.find('div',{'class':'title-section'}).getText()
                        price = soup.find('span',{'class':'price'}).getText()
                        
                        item_name.append(name)
                        final_price.append(price)
                        
                        driver.quit()
                    except Exception as e:
                        print("e : ",e)
                        
                        
    final_price = [i.strip("M.R.P: ₹  ") for i in final_price]
    
    df_1 =  pd.DataFrame(list(zip(item_name, final_price, product_url)),
                   columns =['Product_name', 'Price (Rs.)','Product_url'])
    
    df_1['Website'] = "Jiomart"
    return df_1  

    
def main():   
    
    df = pd.read_excel(curr_dir+"Groceries_Input.xlsx")
    
    #df = pd.read_excel("C:\\Users\\salomef\\Projects\\Automating Pricing Sheet\\Groceries_Input.xlsx") # input excel file

    grocery_items_bb = []
    grocery_items_dm = []
    grocery_items_jio = []

    for i,r in df.iterrows():
        if "https://www.bigbasket.com/" in r[2]:
            grocery_items_bb.append(r[1])

    for i,r in df.iterrows():
        if "https://www.dmart.in" in r[2]:
            grocery_items_dm.append(r[1])
            
    for i,r in df.iterrows():
        if "https://www.jiomart.com" in r[2]:
            grocery_items_jio.append(r[1])
            
    df_bb = big_basket(grocery_items_bb)
    df_dm = dmart(grocery_items_dm)
    df_jio = jiomart(grocery_items_jio)
    
    result = df_bb.append([df_dm,df_jio], ignore_index=True)
    
    result = result.drop_duplicates(subset=['Product_name'])
    
    d=datetime.datetime.now().date()
    result.to_excel(os.path.join(output_dir,"groceries_combined_{}.xlsx".format(d)))
    
    
    shutil.copy(output_dir+"groceries_combined_{}.xlsx".format(d),
                email_dir+"groceries_combined_{}.xlsx".format(d))
    
    os.system("D:\\Emails\\Email.bat")
    

main()






# df_bb = df_1  ; list1=[]

# for i,r in df_bb.iterrows():
#     if r[1] == 'na':
#         list1.append(list(r))

# df_2 = pd.DataFrame(list1, columns =['Product_name', 'Price (Rs.)','Product_url'])
# grocery_items_bb_nan = list(df_2['Product_name'])


# df_bb_nan = big_basket(grocery_items_bb_nan)

# df_new = df_bb[df_bb['Price (Rs.)'] != 'nan']
        

# df_new.to_excel("C:\\Users\\salomef\\Projects\\Automating Pricing Sheet\\df_new.xlsx")


#result = pd.read_excel("C:\\Users\\salomef\\Projects\\Automating Pricing Sheet\\Groceries\\Umang\\output\\groceries_combined_2022-05-31.xlsx")