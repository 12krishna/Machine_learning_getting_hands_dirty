import smtplib
#from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
#from email.mime.base import MIMEBase
#from email import encoders
import datetime
#import os
#import pandas as pd 
import redis
import time
import logging
import pandas as pd 

server = '172.17.9.144'; port = 25
redis_host = 'localhost'


contacts_dir = "D:\\Data_dumpers\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
master_dir = "D:\\Data_dumpers\\Master\\"

# log events in debug mode 
logging.basicConfig(filename="email_notification.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def data_dumper_notification(flag_string, length_string):
    '''Func to send daily emails after the data is dumped'''
    
    # fetch contacts from the file 
    emails = get_contacts(contacts_dir+'contacts.txt') # read contacts
    
    subject = "{}".format(flag_string)       
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()       # create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    msg.attach(MIMEText('{}'.format(length_string),'plain'))        
            
    # send the message via the server set up earlier.
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    del msg       
    # Terminate the SMTP session and close the connection
    s.quit()





def main(nd):
    
    logging.info("Email notification start: {} ".format( datetime.datetime.now()) )
    print "Email notification"
    r = redis.Redis(host=redis_host, port=6379) 
    counter = 0 
    
    # read holiday master
    holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
    date = datetime.datetime.today().date() - datetime.timedelta(nd)
    if len(holiday_master[holiday_master['date']==date])==1:
        logging.info('Holiday: skip for current date {} '.format(date))
        return -1 
      
    
    while counter < 28:   
        # get all the dumper flags from redis 
        fno_bhavcopy_flag = r.get('fno_bhavcopy_dumper')  
        cm_bhavcopy_flag = r.get('cm_bhavcopy_dumper')  
        bse_EQ_flag = r.get('bse_EQ_dumper')  
        bse_SCBSE_flag = r.get('bse_SCBSE_dumper')  
        nse_mto_flag = r.get('nse_mto_dumper')
        nse_index_flag = r.get('index_file_flag')
        options_db_update_flag = r.get('options_db_update_flag')
        FIIActualNumbers_flag = r.get('FIIActualNumbers_flag')
        FIIandDIIProvisionalNumbers_flag = r.get('FIIandDIIProvisionalNumbers_flag')
        FDerivativeActivity_flag = r.get('FDerivativeActivity_flag')
        MFActualNumbers_flag = r.get('MFActualNumbers_flag')
        nse_catturnover_flag = r.get("nse_catturnover_flag")
        bse_catturnover_flag = r.get("bse_catturnover_flag")
        market_turnover_flag = r.get("market_turnover")
        participant_wise_flag = r.get("participant_wise_flag")
        bloom_usd_inr = r.get("bloom_usd_inr")
        fno_factors = r.get("fno_factors")
        options_eod_computations = r.get("options_eod_computations")
        basis_dumper = r.get("basis_dumper_eod")
        fno_banstocks = r.get("fno_banstocks")
        
        
        logging.info('Parameters read from redis for email flag')
        
        if fno_bhavcopy_flag != None:            
            fno_bhavcopy_flag = int(fno_bhavcopy_flag)             
            if fno_bhavcopy_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('NSE FNO bhavcopy', r.get('fno_bhavcopy_dumper_lengths')) # send email                
                r.set('fno_bhavcopy_dumper',0) # reset activation flag
                r.set('fno_bhavcopy_dumper_lengths',0)
                counter += 1
                logging.info('NSE FNO bhavcopy download email sent!')
                print 'NSE FNO bhavcopy download email sent!'
                
        if cm_bhavcopy_flag != None:            
            cm_bhavcopy_flag = int(cm_bhavcopy_flag)              
            if cm_bhavcopy_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('NSE CM bhavcopy', r.get('cm_bhavcopy_dumper_lengths')) # send email                
                r.set('cm_bhavcopy_dumper',0) # reset activation flag
                r.set('cm_bhavcopy_dumper_lengths',0)
                counter += 1
                logging.info('NSE CM bhavcopy download email sent!')
                print 'NSE CM bhavcopy download email sent!'
        
        if bse_EQ_flag != None:            
            bse_EQ_flag = int(bse_EQ_flag)              
            if bse_EQ_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('BSE Equities file', r.get('bse_EQ_dumper_lengths')) # send email                
                r.set('bse_EQ_dumper',0) # reset activation flag
                r.set('bse_EQ_dumper_lengths',0)
                counter += 1
                logging.info('BSE equities bhavcopy download email sent!')
                print 'BSE equities bhavcopy download email sent!'
                
        if bse_SCBSE_flag != None:            
            bse_SCBSE_flag = int(bse_SCBSE_flag)              
            if bse_SCBSE_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('BSE Security wise delivery file', r.get('bse_SCBSE_dumper_lengths')) # send email                   
                r.set('bse_SCBSE_dumper',0) # reset activation flag
                r.set('bse_SCBSE_dumper_lengths',0)
                counter += 1
                logging.info('BSE security wise file download email sent!')
                print 'BSE security wise file download email sent!'
                
        if nse_mto_flag != None:            
            nse_mto_flag = int(nse_mto_flag)              
            if nse_mto_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('NSE Security wise delivery file', r.get('nse_mto_dumper_lengths')) # send email        
                r.set('nse_mto_dumper',0) # reset activation flag
                r.set('nse_mto_dumper_lengths',0)
                counter += 1  
                logging.info('NSE security wise file download email sent!')
                print 'NSE security wise file download email sent!'
        if nse_index_flag!= None:
            nse_index_flag = int(nse_index_flag)              
            if nse_index_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('NSE index file', r.get("index_file_remarks")) # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('index_file_flag',0)
                counter += 1  
                logging.info('NSE index file download email sent!')
                print 'NSE index file download email sent!'
                
        if options_db_update_flag!= None:
            options_db_update_flag = int(options_db_update_flag)              
            if options_db_update_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('Options db update', 'Stocks, futures, stock_options, index_options,beta_correlation, historical_volatility tables successfully updated for {} !'.format(date)) # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('options_db_update_flag',0)
                counter += 1  
                logging.info('Stocks, futures, stock_options, index_options,beta_correlation, historical_volatility tables successfully updated for {} !'.format(date))
                print 'Stocks, futures, stock_options, index_options,beta_correlation, historical_volatility tables successfully updated for {} !'.format(date)
            
        if FIIActualNumbers_flag!= None:
             FIIActualNumbers_flag = int(FIIActualNumbers_flag)              
             if FIIActualNumbers_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('FIIActualNumbers webscrapping', 'FIIActualNumbers has been scrapped!') # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('FIIActualNumbers_flag',0)
                counter += 1  
                logging.info('FIIActualNumbers webscrapping download email sent!')
                print 'FIIActualNumbers webscrappimng email sent!'
                
        if FIIandDIIProvisionalNumbers_flag!= None:
            FIIandDIIProvisionalNumbers_flag = int(FIIandDIIProvisionalNumbers_flag)              
            if FIIandDIIProvisionalNumbers_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('FIIandDIIProvisionalNumbers webscrapping', 'FIIandDIIProvisionalNumbers has been scrapped!') # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('FIIandDIIProvisionalNumbers_flag',0)
                counter += 1  
                logging.info('FIIandDIIProvisionalNumbers webscrapping download email sent!')
                print 'FIIandDIIProvisionalNumbers webscrappimng email sent!'
              
        if FDerivativeActivity_flag!= None:
             FDerivativeActivity_flag = int(FDerivativeActivity_flag)              
             if FDerivativeActivity_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('FDerivativeActivity webscrapping', 'FDerivativeActivity has been scrapped!') # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('FDerivativeActivity_flag',0)
                counter += 1  
                logging.info('FDerivativeActivity webscrapping download email sent!')
                print 'FDerivativeActivity webscrappimng email sent!'
        
        if MFActualNumbers_flag!= None:
             MFActualNumbers_flag = int(MFActualNumbers_flag)              
             if MFActualNumbers_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('MFActualNumbers webscrapping', 'MFActualNumbers has been scrapped!') # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('MFActualNumbers_flag',0)
                counter += 1  
                logging.info('MFActualNumbers webscrapping download email sent!')
                print 'MFActualNumbers webscrappimng email sent!'
                
                
        if nse_catturnover_flag!= None:
             nse_catturnover_flag = int(nse_catturnover_flag)              
             if nse_catturnover_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('NSE Category Turnover', r.get('nse_catturnover_remarks')) # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('nse_catturnover_flag',0)
                counter += 1  
                logging.info('NSE category turnover scrapping done!')
                print 'NSE category turnover scrapping done!'
                
                
        if bse_catturnover_flag!= None:
             bse_catturnover_flag = int(bse_catturnover_flag)              
             if bse_catturnover_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('BSE Category Turnover', r.get('bse_catturnover_remarks')) # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('bse_catturnover_flag',0)
                counter += 1  
                logging.info('BSE category turnover scrapping done!')
                print 'BSE category turnover scrapping done!'
                
                
        if market_turnover_flag!= None:
             market_turnover_flag = int(market_turnover_flag)              
             if market_turnover_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('Market Turnover', r.get('market_turnover_remarks')) # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('market_turnover',0)
                counter += 1  
                logging.info('Market turnover scrapping done!')
                print 'Market turnover scrapping done!'
                
        if participant_wise_flag!= None:
             participant_wise_flag = int(participant_wise_flag)              
             if participant_wise_flag ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('Participant wise OI and volume', r.get('participant_wise_remarks')) # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('participant_wise_flag',0)
                counter += 1  
                logging.info('Participant wise OI and Volume downloaded!')
                print 'Participant wise OI and Volume downloaded!'
                
                
                
                
        if bloom_usd_inr!= None:
             bloom_usd_inr = int(bloom_usd_inr)              
             if bloom_usd_inr ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('USD INR', r.get('bloom_usd_inr_remarks')) # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('bloom_usd_inr',0)
                counter += 1  
                logging.info('USD INR updated !')
                print 'USD INR value updated in db!'
                
        if fno_factors!= None:
             fno_factors = int(fno_factors)              
             if fno_factors ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('FNO Factors', r.get('fno_factors_remarks')) # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('fno_factors',0)
                counter += 1  
                logging.info('FNO factors dumped !')
                print 'FNO factors value updated in db!'
                
                
        if options_eod_computations!= None:
             options_eod_computations = int(options_eod_computations)              
             if options_eod_computations ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('Options EOD Computations', r.get('options_eod_computations_remarks')) # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('options_eod_computations',0)
                r.set("options_eod_computations_remarks",0)
                counter += 1  
                logging.info('Options EOD computations done for set events !')
                print 'Options EOD computations done for set events !'
                
        if basis_dumper!=None:
            basis_dumper = int(basis_dumper)              
            if basis_dumper ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('Basis EOD snapshot Cassandra', '') # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('basis_dumper_eod',0)
                
                counter += 1  
                logging.info('Basis EOD snapshot Cassandra !')
                print 'Basis EOD snapshot Cassandra !'
        
        
        
        if fno_banstocks!=None:
            fno_banstocks = int(fno_banstocks)              
            if fno_banstocks ==1 :
                # redis flag is active; thus file downloaded , send a email notification 
                data_dumper_notification('FNO ban stocks updated in cassandra', r.get('fno_banstocks_len')) # send email        
                #r.set('nse_mto_dumper',0) # reset activation flag
                r.set('fno_banstocks',0)
                r.set('fno_banstocks_len',0)
                
                counter += 1  
                logging.info('FNO ban stocks updated in cassandra !')
                print 'FNO ban stocks updated in cassandra !'
        
                
            
        if datetime.datetime.now().time() == datetime.time(23,30):
                break
            
            
        logging.info('Sleep for 200 sec...')
        print "Sleep for 2 minutes"
        time.sleep(200)
        
    logging.info('Email notification Exit: {} '.format(datetime.datetime.now()))
            
            
            


if __name__ == '__main__':
    main(0)

