
import urllib2
import datetime
from dateutil.relativedelta import relativedelta
import requests
import httplib, StringIO, zipfile
import os
import sys
import shutil
from dateutil import parser
from dateutil import parser
import pandas as pd
import time 
os.chdir("D:\\Data_dumpers\\NSE_CM_Equities\\")


download_dir = "D:\\Data_dumpers\\NSE_CM_Equities\\Download\\"
master_dir = "D:\\Data_dumpers\\Master\\"
data_dir = "D:\\Data_dumpers\\NSE_CM_Equities\\data\\"
options_dir = "D:\\Options\\Deliverables\\bhavcopy\\"
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'}
processed_dir = "D:\\Data_dumpers\\NSE_CM_Equities\\Processed_files\\"

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date





def convertDate( date):
    y = date.strftime("%Y")
    m = date.strftime("%b").upper()
    d = date.strftime("%d")
    return [y, m, d]


def getFilename( date):
        [y, m, d] = convertDate(date)
        return "cm%s%s%sbhav.csv" % (d, m, y)


def getReqStr( date):
    [y, m, d] = convertDate(date)
    return "/content/historical/EQUITIES/%s/%s/%s.zip" % (y, m, getFilename(date))







def downloadCSV(d):
    
    filename = getFilename(d)
    reqstr = getReqStr(d)
    reqstr = "https://archives.nseindia.com"+reqstr
    print reqstr
    responsecode = ''
    print "Downloading %s ..." % (filename)
    
    # read holiday master
    holiday_master = pd.read_csv(master_dir+ 'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
    
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        try:
            responsecode = requests.get(reqstr, headers=headers )   
            print responsecode.status_code
        except Exception as e:
            print e
            responsecode=404
              
        while datetime.datetime.now().time() > datetime.time(17,0):
           
            print 'Sleep for 2 min...'    
            time.sleep(120)    
            try:
                responsecode = requests.get(reqstr, headers=headers )  
                if responsecode.status_code==200:
                    break
            except Exception as e:
                print "Response Exception / {}".format(e)
        
            
           
    elif len(holiday_master[holiday_master['date']==d])==1:
        return -1
    
    
    try:
        # write a file 
        z = zipfile.ZipFile(StringIO.StringIO(responsecode.content))
        z.extractall(processed_dir)
    
        shutil.copy("Processed_files\{0}".format(filename), download_dir+filename) # copy to FNO bhavcopy download folder and dump in cassandra
        shutil.copy("Processed_files\{0}".format(filename), options_dir+filename) # copy to FNO bhavcopy download folder and dump in cassandra

        
        return 1
    
    except:
        print "File is not a zip file "
        return -1



def getUpdate():
    errContinous = 0
    d = datetime.date.today()
    decr = datetime.timedelta(days=1)
    while errContinous > -30 and (not os.path.exists(os.path.join("Processed_files",getFilename(d)))):
        if downloadCSV(d) > -1:
            errContinous = 0
        else:
            errContinous -= 1
        d -= decr

def main(args):
    if args:
        if args[0] == "-update":
            getUpdate()
    

if __name__ == "__main__":
    main(sys.argv[1:])