# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 10:25:17 2021

@author: shashanks
"""

import pandas as pd
#from dateutil import parser
import os
from cassandra.cluster import Cluster
import logging 
#from time import time
import shutil
from time import time 
from datetime import datetime
import redis
os.chdir("D:\\Data_dumpers\\NSE_CM_Equities\\")


download_dir = "D:\\Data_dumpers\\NSE_CM_Equities\\Download\\"
master_dir = "D:\\Data_dumpers\\Master\\"
log_path = "D:\\Data_dumpers\\NSE_CM_Equities\\"
output_dir = "D:\\Data_dumpers\\NSE_CM_Equities\\Output\\"
processed_dir = "D:\\Data_dumpers\\NSE_CM_Equities\\Processed_files\\"

redis_host = 'localhost'
cassandra_host = '172.17.9.51'

#equities_bhavcopy_dir = "D:\\Equities\\NSEDatabase-master\\"
# log events in debug mode 
logging.basicConfig(filename=log_path+"equities_bhavcopy.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


def cassandra_dumper():    
    
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()

    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')
    logging.info('Using rohit keyspace')
    
    # CREATE A TABLE; dump bhavcopies to this table
    session.execute('CREATE TABLE IF NOT EXISTS cm_bhavcopy (symbol varchar,series varchar,open decimal, high decimal, low decimal, close decimal,last decimal,prevclose decimal,tottrdqty decimal,tottrdval decimal,timestamp date,totaltrades decimal,isin varchar,key varchar, PRIMARY KEY (key, timestamp))')
      
    # Download files from NSE site
    os.system(log_path+"equities_bhavcopy3.bat")
    # walk through all the downlaoded bhavcopies in downlaods dir
    

    for r,d,f in os.walk(download_dir):

        logging.info('Traverse through each bhavcopy')
        for csv_file in f:
            #read each csv file 
            print (csv_file)        
            file_name = csv_file
            logging.info('Processing bhavcopy {0}...'.format(file_name))

            bhav_copy = pd.read_csv(download_dir + file_name, keep_default_na=False)  
            og_len = len(bhav_copy)
            # drop unnamed columns
            bhav_copy = bhav_copy.loc[:, ~bhav_copy.columns.str.startswith('Unnamed')]
            # convert to cassandra date format        
            bhav_copy['TIMESTAMP'] = pd.to_datetime(bhav_copy['TIMESTAMP'], format='%d-%b-%Y')
            # concat keys        
            bhav_copy['KEY'] = bhav_copy['SYMBOL']+'_'+bhav_copy['SERIES']

            # write processed bhav_copy to temp file
            bhav_copy.to_csv('temp.csv', index= False)
        
            
            # write csv file to cassandra db
            os.system(log_path+"dump3.bat ") 
            
            #get number of rows dumped into cassandra and original rows in file
            d = datetime.strftime(datetime.strptime( file_name[2:4]+' '+file_name[4:7]+' '+file_name[7:11],'%d %b %Y').date(), "%Y-%m-%d")
            
            c_len = session.execute('select count(*) from rohit.cm_bhavcopy where timestamp = \'{}\' allow filtering;'.format(d)).one()[0]
            
            print ('Number of rows in orginal file {},number of rows dumped in cassandra {}'.format(og_len,c_len))
            logging.info('{}: Number of rows in orginal file {}, number of rows dumped in cassandra {} '.format(d,og_len,c_len))
            # remove bhavcopy from download dir
            
            r = redis.Redis(host=redis_host, port=6379) 
            r.set('cm_bhavcopy_dumper', 1)
            
            r.set('cm_bhavcopy_dumper_lengths',
                  '{}: {} rows dumped in cassandra , whereas {} rows were present in original file'.format(d, c_len, og_len))
            
                
            
            # remove bhavcopy from download dir
            logging.info('Removed bhavcopy {0} from download dir'.format(file_name))
            # move to processed folder    
            shutil.move(download_dir + file_name, processed_dir+file_name)
            
            
           
    #os.remove('temp.csv') 
    logging.info('Shutdown cassandra session')
    session.shutdown()

        



start_time = time()

if __name__ == '__main__':
    cassandra_dumper()
    r = redis.Redis(host=redis_host, port=6379) 
    r.set('intrasector_div_flag', 1)   # flag for intrasector divergence 
    
    

end_time = time()

logging.info('Time taken to process :'.format(end_time - start_time))
print ("Execution time: {0} Seconds.... ".format(end_time - start_time))

