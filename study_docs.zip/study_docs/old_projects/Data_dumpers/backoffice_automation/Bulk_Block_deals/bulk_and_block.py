# -*- coding: utf-8 -*-
"""
Created on Thu Nov 18 16:27:54 2021

@author: backup
"""

import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

from zipfile import ZipFile
import requests 
import pandas as pd
import requests
import re
import os
from lxml import html
#!from selenium import webdriver
import time
import sys
#from selenium.webdriver.common.keys import Keys
#import parse
#from urllib import urlopen
from bs4 import BeautifulSoup
from selenium import webdriver
import shutil
import numpy as np
import requests,os,re,datetime,shutil,logging
import threading
os.chdir("C:\\Users\\backup\\")

server = '172.17.9.144'; port = 25

#output_dir = "D:\\Market_positioning\\Output\\"
contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'

 
log_path='C:\\Users\\backup\\New folder\\' 
data_dir=r'\\172.17.9.22\Users2\BackOfficeDataDownload' 
master_dir = "D:\\Data_dumpers\\Master\\"

logging.basicConfig(filename=log_path+"test_new.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails
           
def combine_html_excel(emails,subject):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
#    message = open("output.txt",'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    msg.attach(MIMEText('The file have been updated on \\172.17.9.22\\Users2\\BackOfficeDataDownload','plain'))    
    # add all attachments 

#    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 


def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)

#previous working date
def previous_working_day(d):
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d - datetime.timedelta(days=1)
            else:
                return d     


def Bse_bulk():
 #    d=datetime.datetime.now().date()-datetime.timedelta(days=nd)
 #    print (d)
     while True:
           url = "http://www.bseindia.com/markets/equity/EQReports/bulk_deals.aspx?expandable=3"
           driver = webdriver.Chrome(master_dir+"chromedriver.exe")
           driver.get(url)
           soup = BeautifulSoup(driver.page_source, 'lxml')
        
           with open('sebi.html','wb') as sfile:
               sfile.write(bytes(str(soup), encoding='utf-8'))
           print(soup.prettify())
          
           dfg=pd.read_html("sebi.html")
           k=pd.DataFrame(dfg)
           t=k[0][0]
           t.columns
           t.rename(columns={0:"Deal Date",1:"Security Code",2:"Security Name",3:"Client Name",4:"Deal Type",5:"Quantity",6:"Price"}, inplace=True)
           t.drop([0,1],axis=0,inplace=True)
           t["Deal Date"]=pd.to_datetime(t["Deal Date"])
           t["Deal Date"]=t["Deal Date"].dt.date
#           if t["Deal Date"].values[0]==d:
           t.to_csv(os.path.join(data_dir,"Bse_Bulk.csv"),index=False)
           
           driver.close()
           break
#           else:
              
#              time.sleep(240)
 #             print("sleep for 4 minutes")
#              driver.close()
     emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts
     subject = "Backoffice Automation BSE_Bulk"
        
     combine_html_excel(emails,subject)  
           
           
def Bse_block():
#     d=datetime.datetime.now().date()-datetime.timedelta(days=nd)
#     print (d)
     
     while True:
           url = "http://www.bseindia.com/markets/equity/EQReports/block_deals.aspx?expandable=3"

           driver = webdriver.Chrome(master_dir+"chromedriver.exe")
           driver.get(url)
           soup = BeautifulSoup(driver.page_source, 'lxml')
        
           with open('sebi.html','wb') as sfile:
               sfile.write(bytes(str(soup), encoding='utf-8'))
           print(soup.prettify())
          
           dfg=pd.read_html("sebi.html")
           k=pd.DataFrame(dfg)
           t1=k[0][0]
 #          t.columns
           t1.rename(columns={0:"Deal Date",1:"Security Code",2:"Security Name",3:"Client Name",4:"Deal Type",5:"Quantity",6:"Price"}, inplace=True)
           t1.drop([0,1],axis=0,inplace=True)
#           t["Deal Date"]=pd.to_datetime(t["Deal Date"])
#           t["Deal Date"]=t["Deal Date"].dt.date
#           if t["Deal Date"].values[0]==d:
           t1.to_csv(os.path.join(data_dir,"Bse_Block.csv"),index=False)
           
           driver.close()
           break
#           else:
              
#              time.sleep(240)
#              print("sleep for 4 minutes")
#              driver.close()
     emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts
     subject = "Backoffice Automation BSE_Block"
        
     combine_html_excel(emails,subject)
          
def Nse_bulk():  
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")           
    driver.get("https://archives.nseindia.com/content/equities/bulk.csv")
    time.sleep(5)
    
    shutil.move('C:\\Users\\backup\\Downloads\\bulk.csv', 
               os.path.join(data_dir,'Nse_bulk.csv'))
    time.sleep(5)
    driver.close()
    emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts
    subject = "Backoffice Automation NSE_Bulk"
        
    combine_html_excel(emails,subject)   
           
def Nse_block():  
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")           
    driver.get("https://archives.nseindia.com/content/equities/block.csv")
    
    time.sleep(5)
    shutil.move('C:\\Users\\backup\\Downloads\\block.csv', 
               os.path.join(data_dir,'Nse_block.csv'))
    time.sleep(5)
    driver.close()
    emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts
    subject = "Backoffice Automation NSE_Block"
        
    combine_html_excel(emails,subject)   
                      
def main(nd):
       
    d = datetime.datetime.now()-datetime.timedelta(nd)
    
    if process_run_check(d.date())== -1:
        return -1
    t1=threading.Thread(target=Bse_bulk)
    t2=threading.Thread(target=Bse_block)
    t3=threading.Thread(target=Nse_bulk)
    t4=threading.Thread(target=Nse_block)
    t1.start()
    t2.start()
    t3.start()
    t4.start()
    t1.join()
    t2.join()
    t3.join()
    t4.join()
    print("done")
if __name__ == "__main__":
    main(nd=0)
                           
           
           
           
           