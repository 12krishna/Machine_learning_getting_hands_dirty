# -*- coding: utf-8 -*-
"""
Created on Wed Oct 27 10:05:44 2021

@author: backup
"""
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

import re
import pandas as pd
from bs4 import BeautifulSoup
import os
import datetime
import time
from cassandra.cluster import Cluster
import logging
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
#from selenium.common.exceptions import TimeoutException
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.webdriver.common.by import By
import redis
import threading
os.chdir("C:\\Users\\backup\\")

server = '172.17.9.144'; port = 25


output_dir = "D:\\Market_positioning\\Output\\"
contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'

log_path='C:\\Users\\backup\\New folder\\' 
data_dir=r'\\172.17.9.22\Users2\BackOfficeDataDownload' 
master_dir = "D:\\Data_dumpers\\Master\\"

logging.basicConfig(filename=log_path+"test3.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")



def dateparse(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date


# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''

    if len(holiday_master[holiday_master['date']==d])==0:
        return 1

    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails            

def combine_html_excel(emails,subject):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
#    message = open("output.txt",'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    msg.attach(MIMEText('the file have been updated on \\172.17.9.22\\Users2\\BackOfficeDataDownload','plain'))    
    # add all attachments 

#    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()



def SEBI_MF_DERV():
        
    url="https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doMfd=yes&type=1"
    driver = webdriver.Chrome(master_dir+"chromedriver.exe") 
    driver.get(url)
    time.sleep(5)
    soup = BeautifulSoup(driver.page_source, 'lxml')


    with open('sebi.html','wb') as sfile:
        sfile.write(bytes(str(soup), encoding='utf-8'))
    print(soup.prettify())

    dfg=pd.read_html("sebi.html")
    k=pd.DataFrame(dfg)
#    k=df
    
    report1=k[0][0]
        
    report1['Trading Date']=pd.to_datetime(report1["Trading Date"] ,errors='coerce')
    report1 = report1[~report1['Trading Date'].isnull()]
    report1.dropna(axis=1, how='all', inplace=True)
    report1['Trading Date'] = report1['Trading Date'].dt.date

    final_report1=report1
    try:
        final_report1["Net Investment (Rs Crore)"]=final_report1["Net Investment (Rs Crore)"].str.replace('(',"-").str.replace(')',"").astype('float')
    except:
        print("error because bracket is missing if bracket is there than replace it with minus sign")

    final_report1["Gross Sales(Rs Crore)"]=final_report1["Gross Sales(Rs Crore)"].astype("float")
    final_report1["Gross Purchases(Rs Crore)"]=final_report1["Gross Purchases(Rs Crore)"].astype("float")
    final_report1.rename(columns={'Trading Date':'TradingDate'},inplace=True)
    final_report1.columns=['TradingDate','Debt_Equity','GrossPurchases','GrossSales','NetInvestment']
    final_report1.to_csv(os.path.join(data_dir,"SEBI_MF_DERV.csv"),index=False)
    driver.close()
    emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts
    subject = "Backoffice Automation SEBI_MF_DERV"
        
    combine_html_excel(emails,subject)
    
    
def Daily_trends_FPI(nd):
    d=datetime.datetime.now().date()-datetime.timedelta(days=nd)
    print (d)
    
    
    
    
    while True:
        url = "https://www.fpi.nsdl.co.in/web/Reports/Latest.aspx"
        driver = webdriver.Chrome(master_dir+"chromedriver.exe")
        driver.get(url)
        soup = BeautifulSoup(driver.page_source, 'lxml')
        
        with open('sebi.html','wb') as sfile:
            sfile.write(bytes(str(soup), encoding='utf-8'))
        print(soup.prettify())
        
        dfg=pd.read_html("sebi.html")
        k=pd.DataFrame(dfg)
        report2=k[0][0]
        
        report1=k[0][1] 
        report1.drop(5,axis=0,inplace=True)        
        report1.columns=["Reporting Date","Derivative Products","NO. Of Contracts(Buy)","Amount in Crore(Buy)","NO. Of Contracts(Sell)","Amount in Crore(Sell)","NO. Of Contracts(Open interest end of day)","Amount in Crore(Open interest end of day)"]
        report1["Reporting Date"]=pd.to_datetime(report1["Reporting Date"])
        report1["Reporting Date"]=report1["Reporting Date"].dt.date
        if report1["Reporting Date"].values[0]==d:            
            report1.to_csv(os.path.join(data_dir,"SEBI_FPI_DERV.csv"),index=False)
            
            
            report2.columns=["Reporting Date","Equity","Investment Route","Gross Purchases(Rs.Crore)","Gross Sales(Rs.Crore)","Net Investment(Rs.Crore)","Net Investment US ($) million","Conversion(1 USD TO INR)"]
            report2=report2[report2["Equity"]=="Equity"]
            
            report2.to_csv(os.path.join(data_dir,"SEBI_FPI_CASH.csv"),index=False)
            
            driver.close()
            break
        else:
            time.sleep(250)
            print("sleep for 4 minutes")
            driver.close()
    emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts
    subject = "Backoffice Automation SEBI_FPI Files"
       
    combine_html_excel(emails,subject)
                        

def main(nd):
     d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
     if process_run_check(d)== -1:
        return -1   
    
     t1=threading.Thread(target=SEBI_MF_DERV)
     t2=threading.Thread(target=Daily_trends_FPI,args=(nd,))
     t1.start()
     t2.start()
     t1.join()
     print("file1 downloaded")
     t2.join()
     print("files downloaded")
     
if __name__ == "__main__":
    main(nd=0)
  
    