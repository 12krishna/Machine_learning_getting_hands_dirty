"""
Created on Thu Oct 21 09:21:29 2021

@author: backup
"""
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


from zipfile import ZipFile
import requests 
import pandas as pd
import requests
import re
import os
from lxml import html
#!from selenium import webdriver
import time
import sys
#from selenium.webdriver.common.keys import Keys
#import parse
#from urllib import urlopen
from bs4 import BeautifulSoup
from selenium import webdriver
import shutil
import numpy as np
import requests,os,re,datetime,shutil,logging
import threading

server = '172.17.9.144'; port = 25



contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
#master_dir= "D:\\Master\\"
 
log_path="D:\\Data_dumpers\\backoffice_automation\\NSDL_CDSL_web\\" 
data_dir=r'\\172.17.9.22\Users2\BackOfficeDataDownload' 
master_dir = "D:\\Data_dumpers\\Master\\"
default_download_dir='C:\\Users\\backup\\Downloads\\'

logging.basicConfig(filename=log_path+"test1.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")



def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)

#previous working date
def previous_working_day(d):
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d - datetime.timedelta(days=1)
            else:
                return d     


def fetch_equity(nd):
    
    def convertDate(date):
        y = date.strftime("%Y")
        m = date.strftime("%m")
        d = date.strftime("%d")
        return [y, m, d]
    
    def getFilenamezip(date):
            [y, m, d] = convertDate(date)
        
            return 'Equity_Oriented_Funds_on_BSE_for_revised_STT_June_1_%s%s%s.zip'% (d, m, y)
        
    def getFilenamecsv(date):
            [y, m, d] = convertDate(date)
        
            return 'Equity_Oriented_Funds_on_BSE_for_revised_STT_June_1_%s%s%s.csv'% (d, m, y)
        
    for r,d,f in os.walk(data_dir):
          logging.info('Traverse through each file')
          for file in f:
             if file.startswith("Equity_Oriented_Funds_on_BSE_for_revised_STT"):
                 os.remove(os.path.join(data_dir,file))    
    d = datetime.date.today()-datetime.timedelta(nd)
    d1=previous_working_day(d)  
    # download Equity_Oriented_Funds_on_BSE_for_revised_STT_June_1.xls
    # https://www.bseindia.com/downloads1/Equity_Oriented_Funds_on_BSE_for_revised_STT_June_1.xls
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")           
    driver.get("https://www.bseindia.com/members/downloads.aspx")
    
    time.sleep(10)      
                    
    cl=driver.find_element_by_partial_link_text('Equity Oriented Fund')
    time.sleep(10)
    cl.click()
    time.sleep(20)
    driver.close()
    try:
        
        zf = ZipFile(default_download_dir+getFilenamezip(d1), 'r')
        zf.extractall(default_download_dir)
        zf.close()
        shutil.move(default_download_dir+getFilenamecsv(d1), 
               os.path.join(data_dir,getFilenamecsv(d1))) 
    except Exception as e:
        print(e)
        
        
def fetch_securities(nd):
    def convertDate(date):
        y = date.strftime("%Y")
        m = date.strftime("%m")
        d = date.strftime("%d")
        return [y, m, d]
    
    def getFilenamezip(date):
            [y, m, d] = convertDate(date)
        
            return 'ScripsonwhichSTTisnotlevied_%s%s%s.zip'% (d, m, y)
        
    def getFilenamecsv(date):
            [y, m, d] = convertDate(date)
        
            return 'ScripsonwhichSTTisnotlevied_%s%s%s.csv'% (d, m, y)    
    
    for r,d,f in os.walk(data_dir):
          logging.info('Traverse through each file')
          for file in f:
             if file.startswith("ScripsonwhichSTTisnot"):
                 os.remove(os.path.join(data_dir,file))

    d = datetime.date.today()-datetime.timedelta(nd)
    d1=previous_working_day(d)       
    # download Equity_Oriented_Funds_on_BSE_for_revised_STT_June_1.xls
    # https://www.bseindia.com/downloads1/Equity_Oriented_Funds_on_BSE_for_revised_STT_June_1.xls
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")           
    driver.get("https://www.bseindia.com/members/downloads.aspx")
    
             
          
    cl=driver.find_element_by_partial_link_text('securities on which STT')
    time.sleep(10)
    cl.click()
    time.sleep(20)
    driver.close()        
    try:
        
       zf = ZipFile(default_download_dir+getFilenamezip(d1), 'r')
       zf.extractall(default_download_dir)
       zf.close()    
       shutil.move(default_download_dir+getFilenamecsv(d1), 
               os.path.join(data_dir,getFilenamecsv(d1)))
    except Exception as e:
        print(e)


def fetch_CI_date(nd):
    
    def getFilename(date):
            [y, m, d] = convertDate(date)
        
            return 'CI%s%s%s.txt'% (d, m, y[2:]) 
        
    def convertDate(date):
            y = date.strftime("%Y")
            m = date.strftime("%m")
            d = date.strftime("%d")
            return [y, m, d]
    while 1:
        for r,d,f in os.walk(data_dir):
          logging.info('Traverse through each file')
          for file in f:
             if file.startswith("CI"):
                 os.remove(os.path.join(data_dir,file))

        d = datetime.date.today()-datetime.timedelta(nd)
        d1=previous_working_day(d)
        print("previous date",d1)
        
        driver = webdriver.Chrome(master_dir+"chromedriver.exe") 
        driver.get("https://www.bseindia.com/downloads/Help/file/scrip.zip")
        time.sleep(10)
        
        zf = ZipFile(default_download_dir+'scrip.zip', 'r')
        zf.extractall(default_download_dir)
        zf.close() 
        if os.path.exists(default_download_dir+"SCRIP\\"+getFilename(d1)):
             shutil.move(default_download_dir+'SCRIP\\'+getFilename(d1), 
               os.path.join(data_dir,getFilename(d1)))
             shutil.rmtree(default_download_dir+'SCRIP')
             shutil.move(default_download_dir+'scrip.zip','C:\\Users\\backup\\Documents\\scrip.zip')
             driver.close()
             break
        else:
            print("sleep for 2 minutes")
            driver.close()
            time.sleep(120)
        
    
def fetch_scrip_date(nd):
    
    def convertDate(date):
        y = date.strftime("%Y")
        m = date.strftime("%b")
        d = date.strftime("%d")
        return [y, m, d]

    
    def getFilename(date):
            [y, m, d] = convertDate(date)
        
            return 'SCRIP_%s%s%s.TXT'% (d, m, y[2:])   

    def convertDate(date):
            y = date.strftime("%Y")
            m = date.strftime("%m")
            d = date.strftime("%d")
            return [y, m, d]
    while 1:
        for r,d,f in os.walk(data_dir):
          logging.info('Traverse through each file')
          for file in f:
             if file.startswith("SCRIP_"):
                 os.remove(os.path.join(data_dir,file))
 
        d = datetime.date.today()-datetime.timedelta(nd)
        d1=previous_working_day(d)

        print("previous date",d1)
        driver = webdriver.Chrome(master_dir+"chromedriver.exe") 
        driver.get("https://www.bseindia.com/downloads/Help/file/scrip.zip")
        time.sleep(10)
        
        zf = ZipFile(default_download_dir+'scrip.zip', 'r')
        zf.extractall(default_download_dir)
        zf.close() 
        
        if os.path.exists(default_download_dir+"SCRIP\\"+getFilename(d1)):
             shutil.move(default_download_dir+'SCRIP\\'+getFilename(d1), 
               os.path.join(data_dir,getFilename(d1)))
             time.sleep(10)
             shutil.rmtree(default_download_dir)
             shutil.move(default_download_dir+'scrip.zip','C:\\Users\\backup\\Documents\\scrip.zip')
             driver.close()
             break
        else:
            print("sleep for 2 minutes")
            driver.close()
            time.sleep(120)
   
def clicking(self):
    tryAgain = True
    while True:
        try:
           time.sleep(40)
           self.click()
           break
        except Exception:
            if tryAgain:
                continue
def fetch_cdsl():
    driver = webdriver.Chrome(master_dir+"chromedriver.exe")           
    driver.get("https://www.cdslindia.com/publications/RegForeignInstInvstr.aspx?")
    element1 = driver.find_element_by_xpath("//input[@value='Show All']")
    clicking(element1)
    time.sleep(30)
    element2 = driver.find_element_by_xpath("//input[@value='Download as Excel']")
    clicking(element2)
    time.sleep(20)
    while 1:
        if os.path.exists(default_download_dir+'RegForeignInstututionalInvestors.xls') :
            shutil.move(default_download_dir+'RegForeignInstututionalInvestors.xls', 
               os.path.join(data_dir,'CDSL_FPI_List.xlsx'))
            break
        time.sleep(5)
        
    driver.close()
    df=pd.read_excel(os.path.join(data_dir,'CDSL_FPI_List.xlsx'))
    df.columns=["Sr No.","FII Applicant Name","Registration No.","Registration Valid upto","Address1","Address2","Address3","Country Name","Telephone No.","Fax No."]
    
    df["Registration Valid upto"]=df["Registration Valid upto"].str.replace(" 12:00:00 AM","")   
 
    df.to_excel(os.path.join(data_dir,'CDSL_FPI_List.xlsx'),index=False)

def fetch_nsdl():
    
        driver = webdriver.Chrome(master_dir+"chromedriver.exe")        
        driver.get("https://www.fpi.nsdl.co.in/web/Reports/RegisteredFIISAFPI.aspx")

        venue = driver.find_element_by_xpath('//a[@class="arrow arrow_Accrdion_Up"]')
        time.sleep(10)
        venue.click()
        venue1 = driver.find_element_by_xpath('//a[@class="clrblu"]')
        time.sleep(10)
        venue1.click()
        time.sleep(60)
    
    
        html =driver.page_source
        soup = BeautifulSoup(html, 'html.parser')
        name = soup.find_all("span",{"class":"fii_red"})#name
        client_type= soup.find_all("td",{"class":"left_row"})#registration number ,registration validity,client type
        telephone_no= soup.find_all("td",{"class":"right_row"})#address , country,telephone number
        #f_num   bers=[]
        f_name=[]
        f_client_type=[]
        f_telephone_no=[]
    
        
    
        for i in range(len(name)):
            f_name.append(name[i].text)
    
        for i in range(len(client_type)):
            print(client_type[i].text)
            f_client_type.append(client_type[i].text)#keep only 3 row
    
                    
    
        for i in range(len(telephone_no)):
            f_telephone_no.append(telephone_no[i].text)
    
    
        df=pd.DataFrame(f_client_type)
        df.rename(columns={0:"Registration_NO",1:"Registration_valid_upto",2:"Client_type",3:"Category"}, inplace=True)
        df['Registration_valid_upto'] = df['Registration_NO'].str.split('upto').str[1]
        df['Client_type'] = df['Registration_NO'].str.split('Category of').str[1]
        df['Client_type'] = df['Client_type'].str.split('Category').str[0]
        df['Category']=df['Registration_NO'].str.split('FPI').str[1]
        df['Registration_NO'] = df['Registration_NO'].str.split('No.').str[1]
        df['Registration_NO'] = df['Registration_NO'].str.split('Category').str[0]
        df = df.groupby(df.index // 2).agg(lambda D: D.dropna().astype(str).str.cat(sep=','))
        df = df.drop_duplicates(['Registration_NO'])
    
    
    
        df3=pd.DataFrame(f_telephone_no)
        df3.rename(columns={0:"Country_name", 1:"Telephone_no"},inplace=True)
        df3['Country_name'] = df3['Country_name'].str.split('Country Name ').str[1]
        df3.dropna(inplace=True)
        df3.reset_index(drop=True, inplace=True)
        df3['Telephone_no'] = " "
        df1=pd.DataFrame(f_telephone_no)
        df1.rename(columns={0:"Address"},inplace=True)
        df1['Address'] = df1['Address'].str.split('Address').str[1]
        df1.dropna(inplace=True)
        df1.reset_index(drop=True, inplace=True)
        df4 = df1.join(df3)
        df2=pd.DataFrame(f_name)
        df2.rename(columns={0:"Name"},inplace=True)
        nsdl=df2.join(df)
        final_nsdl=nsdl.join(df4)
        #final_nsdl.to_excel("C:\\Users\\Nityo\\Desktop\\clas\\{}.xlsx".format(a),index=False)
        final_nsdl.to_excel(os.path.join(data_dir,"NSDL_FPI_List.xlsx"),index=False)
        print ("generating nsdl_new")
        driver.close()

def NSE_Equity_Oriented_File(nd):
     def convertDate(date):
        y = date.strftime("%Y")
        m = date.strftime("%m")
        d = date.strftime("%d")
        return [y, m, d]
    
     def getFilename(date):
        [y, m, d] = convertDate(date)
        
        return "C_STT_IND_%s%s%s.csv" % (d, m, y)          
   
     def getReqStr(date):
        [y, m, d] = convertDate(date)           
        return "https://www1.nseindia.com/content/equities/%s" % (getFilename(date))
    
     for r,d,f in os.walk(data_dir):
          logging.info('Traverse through each file')
          for file in f:
             if file.startswith("NSE_Equity"):
                 os.remove(os.path.join(data_dir,file))
    
     d = datetime.date.today()-datetime.timedelta(nd)
     d1=previous_working_day(d)
     print(d1)
     while 1:
         try:
             r=requests.get(getReqStr(d1),timeout=30)
             print(r.status_code)
             if r.status_code==200:
                 print("success")        
                 break
         except Exception as e:
              print(e)
              print("sleep for 2 minutes")
              time.sleep(120)
         print("sleep for 2 minutes")
         time.sleep(120)                  
     driver = webdriver.Chrome(master_dir+"chromedriver.exe")        
     driver.get(getReqStr(d1))
     time.sleep(10)
     shutil.move(default_download_dir+getFilename(d1), 
                 os.path.join(data_dir,getFilename(d1)))     
     driver.close()
     for r,d,f in os.walk(data_dir):
          logging.info('Traverse through each file')
          for file in f:
             if file.startswith("C_STT_IND"):
                 os.rename(os.path.join(data_dir,file),os.path.join(data_dir,"NSE_Equity_Oriented_File.csv"))

def NSE_NO_STT(nd):
     def convertDate(date):
        y = date.strftime("%Y")
        m = date.strftime("%m")
        d = date.strftime("%d")
        return [y, m, d]
    
     def getFilename(date):
        [y, m, d] = convertDate(date)
        
        return "C_STT_%s%s%s.csv" % (d, m, y)          
   
     def getReqStr(date):
        [y, m, d] = convertDate(date)           
        return "https://www1.nseindia.com/content/equities/%s" % (getFilename(date))
    
     for r,d,f in os.walk(data_dir):
          logging.info('Traverse through each file')
          for file in f:
             if file.startswith("NSE_NO"):
                 os.remove(os.path.join(data_dir,file))
    
     d = datetime.date.today()-datetime.timedelta(nd)
     d1=previous_working_day(d)
     print(d1)
     while 1:
         try:
             r=requests.get(getReqStr(d1),timeout=30)
             print(r.status_code)
             if r.status_code==200:
                 print("success")        
                 break
         except Exception as e:
              print(e)
              print("sleep for 2 minutes")
              time.sleep(120)
     driver = webdriver.Chrome(master_dir+"chromedriver.exe")        
     driver.get(getReqStr(d1))
     time.sleep(10)
     shutil.move(default_download_dir+getFilename(d1), 
                 os.path.join(data_dir,getFilename(d1)))     
     driver.close()
     for r,d,f in os.walk(data_dir):
          logging.info('Traverse through each file')
          for file in f:
             if file.startswith("C_STT"):
                 os.rename(os.path.join(data_dir,file),os.path.join(data_dir,"NSE_NO_STT.csv"))


        
def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails
           
def combine_html_excel(emails,subject):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
#    message = open("output.txt",'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    msg.attach(MIMEText('All the files have been updated on \\172.17.9.22\\Users2\\BackOfficeDataDownload','plain'))    
    # add all attachments 

#    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()


def main(nd):
       
    d = datetime.datetime.now()-datetime.timedelta(nd)
    
    if process_run_check(d.date())== -1:
        return -1
    t1=threading.Thread(target= fetch_cdsl)
    t2=threading.Thread(target=fetch_nsdl)
    t3=threading.Thread(target=fetch_scrip_date,args=(nd,))
    t4=threading.Thread(target=fetch_CI_date,args=(nd,))
    t5=threading.Thread(target=fetch_equity,args=(nd,))
    t6=threading.Thread(target=fetch_securities,args=(nd,))
    t7=threading.Thread(target=NSE_Equity_Oriented_File,args=(nd,))
    t8=threading.Thread(target=NSE_NO_STT,args=(nd,))
    t1.start()
    t2.start()
    t3.start()
    t4.start()
    t5.start()
    t6.start()
    t7.start()
    t8.start()
    t1.join()
    t2.join()
    t3.join()
    t4.join()
    t5.join()
    t6.join()
    t7.join()
    t8.join()

    emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts
    subject = "Backoffice Automation Data"
        
    combine_html_excel(emails,subject)
    print("all files downloaded")
    
    #    fetch_cdsl()
#    fetch_nsdl()
#    fetch_scrip_date(nd)
#    fetch_CI_date(nd)
#    fetch_equity(nd)
#    fetch_securities(nd)
#    NSE_Equity_Oriented_File(nd)
#    NSE_NO_STT(nd)
    
if __name__ == "__main__":
    main(nd=0)
                       