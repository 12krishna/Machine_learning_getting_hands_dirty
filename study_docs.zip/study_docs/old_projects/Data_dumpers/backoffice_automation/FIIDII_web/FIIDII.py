# -*- coding: utf-8 -*-
"""
Created on Mon Oct 25 12:39:53 2021

@author: backup
"""
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

import pandas as pd
from bs4 import BeautifulSoup
import requests
import re
import os
from lxml import html
import datetime
import time
from cassandra.cluster import Cluster
from dateutil.parser import parse
import logging
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait 
import redis
import shutil
import threading


server = '172.17.9.144'; port = 25

output_dir = "D:\\Market_positioning\\Output\\"
contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'

master_dir = "D:\\Data_dumpers\\Master\\"
log_path='D:\\Data_dumpers\\backoffice_automation\\FIIDII_web\\' 
data_dir=r'\\172.17.9.22\Users2\BackOfficeDataDownload'

logging.basicConfig(filename=log_path+"test2.log",filemode="w",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails
               
def combine_html_excel(emails,subject):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
#    message = open("output.txt",'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    msg.attach(MIMEText('the file have been updated on \\172.17.9.22\\Users2\\BackOfficeDataDownload','plain'))    
    # add all attachments 

#    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()
 

def EXCHANGE_CASH_FII_DII(nd): 
       
        d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
        if process_run_check(d) == -1:
            return -1
#        logging.info('Parameters read from redis for FIIandDIIProvisionalNumbers_flag')
        
        
        
        while True:
            print("here")
            try:
                    
                url = "https://www1.nseindia.com/products/content/equities/equities/fii_dii_market_today.htm"
                driver = webdriver.Chrome(master_dir+"chromedriver.exe")
#                logging.info("download file")
                driver.get(url)
                
                driver.implicitly_wait(60)
                driver.implicitly_wait(100)
                WebDriverWait(driver, 10000)
                driver.implicitly_wait(100)
                time.sleep(20)
                
                
                
                soup = BeautifulSoup(driver.page_source, 'lxml')
               # print(soup.prettify())
            except Exception as e:
                print(e)
                print("Sleep for 30 seconds")
                driver.close()
                time.sleep(30)
                continue
    #        tree = html.parse("NSE - National Stock Exchange of India Ltd..html")
    #        raw_html=html.tostring(tree)
    #        soup = BeautifulSoup(raw_html, 'html.parser')
          
            column=soup.find_all('th')
            column_val=[]
            for i in range(len(column)):
                    #print column[i].text
                    column_val.append(column[i].text)
            column_val[1:6]
    
            row1=soup.find_all('tr')
            row_val1=[]
            for i in range(len(row1)):
                    #print row1[i].text
                    row_val1.append(row1[i].text)
            val1=pd.DataFrame(row_val1)
    
            val2=val1[0].str.split('\n', expand=True)
            val2.columns=['0','Category','Date','BuyValue','SellValue','NetValue','0']
            val2.drop(val2['0'],axis=1,inplace=True)
            val2.dropna(inplace=True)
            val2.drop(val2[val2.Category =="Category" ].index, inplace=True)
            #val2.drop(val2.index[[0,2]],axis=1,inplace=True)
            val2['Date'] =  pd.to_datetime(val2['Date'])
            val2['Date'] = val2['Date'].dt.date
            val2['Category'] = val2['Category'].str.strip()
            if val2["Date"].values[0]==d:
                val2 = val2[['Category','Date','BuyValue','NetValue','SellValue']]
                val2.to_csv(os.path.join(data_dir,"EXCHANGE_CASH_FII_DII.csv"),index=False)
                                
                driver.close()  
                break
            else:
                print('Sleep for 3 min')
                driver.close()
                time.sleep(120)
        emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts 'backoffice_automation.txt'
        subject = "Backoffice Automation Exchange_CASH_FII_DII"
        
        combine_html_excel(emails,subject)
    

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


#"https://archives.nseindia.com/content/FO_Latency_stats25102021.csv"
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''

    if len(holiday_master[holiday_master['date']==d])==0:
        return 1

    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1


#previous working date
def previous_working_day(d):
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d - datetime.timedelta(days=1)
            else:
                return d

def EXCHANGE_FNO_DERV_FPI(nd):
     def convertDate(date):
        y = date.strftime("%Y")
        m = date.strftime("%b")
        d = date.strftime("%d")
        return [y, m, d]
    
     def getFilename(date):
        [y, m, d] = convertDate(date)
        
        return "fii_stats_%s-%s-%s.xls" % (d, m, y)          
   
     def getReqStr(date):
        [y, m, d] = convertDate(date)           
        return "https://archives.nseindia.com/content/fo/%s" % (getFilename(date))
    
 
     try:
        for r,d,f in os.walk(data_dir):
              logging.info('Traverse through each file')
              for file in f:
                 if file.startswith("EXCHANGE_FNO_DERV"):
                    os.remove(os.path.join(data_dir,file))
                    logging.info("{} removed".format(file))
     except Exception as e:
              print(e)
              logging.info("{}".format(e))
      
     d = datetime.date.today()-datetime.timedelta(nd)
#     d1=previous_working_day(d)
     while 1:
         try:
             logging.info("checking status code")
             r=requests.get(getReqStr(d),timeout=30)
             print(r.status_code)
             time.sleep(120)
             if r.status_code==200:
                 print("success")        
                 break             
         except Exception as e:
              print(e)
              logging.info("{}".format(e))
              print("sleep for 2 minutes")
         time.sleep(120)
     driver = webdriver.Chrome("D:\\Data_dumpers\\Master\\chromedriver.exe")        
     driver.get(getReqStr(d))
     time.sleep(10)
     shutil.move('C:\\Users\\backup\\Downloads\\'+getFilename(d), 
                 os.path.join(data_dir,getFilename(d)))     
     driver.close()
     try:
         for r,d,f in os.walk(data_dir):
              logging.info('Traverse through each file')
              for file in f:
                 if file.startswith("fii_stats_"):
                     print(os.path.join(r,file))
                     logging.info("renaming {} to EXCHANGE_FNO_DERV_FPI_DERV.xls".format(file))
                     os.rename(os.path.join(data_dir,file),os.path.join(data_dir,"EXCHANGE_FNO_DERV_FPI.xls"))
     except Exception as e:
          print(e)
     emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts 'backoffice_automation.txt'
     subject = "Backoffice Automation Exchange_FNO_Derv_FPI"
        
     combine_html_excel(emails,subject)

              
def EXCHANGE_MF_DERV(nd):
     def convertDate(date):
        y = date.strftime("%Y")
        m = date.strftime("%m")
        d = date.strftime("%d")
        return [y, m, d]
    
     def getFilename(date):
        [y, m, d] = convertDate(date)
        
        return "cat_turnover_%s%s%s.xls" % (d, m, y[2:])          
   
     def getReqStr(date):
        [y, m, d] = convertDate(date)           
        return "https://www1.nseindia.com/archives/equities/cat/%s" % (getFilename(date))
    

     try:
         for r,d,f in os.walk(data_dir):
             logging.info('Traverse through each file')
             for file in f:
                if file.startswith("EXCHANGE_MF"):
                    os.remove(os.path.join(data_dir,file))
                    logging.info("{} removed".format(file))          
     except Exception as e:
              print(e)
              logging.info("{}".format(e))

     d = datetime.date.today()-datetime.timedelta(nd)
     d1=previous_working_day(d)
     print(d1)
     while 1:
         try:
             logging.info("checking status code")
             r=requests.get(getReqStr(d1),timeout=30)
             print(r.status_code)
             print("sleep for 2 minutes")
             time.sleep(10)
             if r.status_code==200:
                 print("success")        
                 break
         except Exception as e:
              print(e)
             # logging.info("{}".format(e))
         print("sleep for 2 minutes")
         time.sleep(120)
     driver = webdriver.Chrome("D:\\Data_dumpers\\Master\\chromedriver.exe")        
     driver.get(getReqStr(d1))
     time.sleep(10)
     shutil.move('C:\\Users\\backup\\Downloads\\'+getFilename(d1), 
                 os.path.join(data_dir,getFilename(d1)))     
     driver.close()
     try:
         for r,d,f in os.walk(data_dir):
              logging.info('Traverse through each file')
              for fi in f:
                 if fi.startswith("cat_turnover_"):
                     print(os.path.join(r,fi))
                     logging.info("renaming {} to EXCHANGE_MF_DERV.xls".format(fi))
                     os.rename(os.path.join(data_dir,fi),os.path.join(data_dir,"EXCHANGE_MF_DERV.xls"))
     except Exception as e:
            print(e)                
     time.sleep(5)
     emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts backoffice_automation.txt
     subject = "Backoffice Automation Exchange_MF_Derv"
        
     combine_html_excel(emails,subject)
         
            

def main(nd):
    d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    if process_run_check(d)== -1:
        return -1 
    t1=threading.Thread(target= EXCHANGE_CASH_FII_DII,args=(nd,)) 
    t2=threading.Thread(target=EXCHANGE_FNO_DERV_FPI,args=(nd,))
    t3=threading.Thread(target=EXCHANGE_MF_DERV,args=(nd,)) 
    t1.start()
    t2.start()
    t3.start()
    t1.join()
    t2.join()
    t3.join()
    print("all the files downloaded")
    

if __name__ == "__main__":
    main(nd=0)
    
    
    
    
