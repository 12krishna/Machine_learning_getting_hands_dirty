# -*- coding: utf-8 -*-
"""
Created on Mon Jun  6 18:35:28 2022

@author: backup
"""

import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

import pandas as pd
from bs4 import BeautifulSoup
import requests
import re
import os
from lxml import html
import datetime
import time
from cassandra.cluster import Cluster
from dateutil.parser import parse
import logging
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait 
import redis
import shutil
import threading


server = '172.17.9.144'; port = 25


contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'

master_dir = "D:\\Data_dumpers\\Master\\"
log_path='D:\\Data_dumpers\\backoffice_automation\\FIIDII_web\\' 
data_dir=r'\\172.17.9.22\Users2\BackOfficeDataDownload'
#data_dir='D:\\Data_dumpers\\backoffice_automation\\'
download_dir='C:\\Users\\backup\\Downloads\\'

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails
               
def combine_html_excel(emails,subject):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
#    message = open("output.txt",'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    msg.attach(MIMEText('the file have been updated on \\172.17.9.22\\Users2\\BackOfficeDataDownload','plain'))    
    # add all attachments 

#    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()
 
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


#"https://archives.nseindia.com/content/FO_Latency_stats25102021.csv"
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''

    if len(holiday_master[holiday_master['date']==d])==0:
        return 1

    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1


#previous working date
def previous_working_day(d):
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d - datetime.timedelta(days=1)
            else:
                return d

def convertDate(date):
        y = date.strftime("%Y")
        m = date.strftime("%m")
        d = date.strftime("%d")
        return [y, m, d]
    
def getFilename(date):
    [y, m, d] = convertDate(date)
    
    return "sec_list_%s%s%s.csv" % (d, m, y)          
   
def getReqStr(date):
    [y, m, d] = convertDate(date)           
    return "https://archives.nseindia.com/content/equities/%s" % (getFilename(date))


def CM_Price(d):
  d1=previous_working_day(d)
  print(d1)
  while 1:
    
      try:
         logging.info("checking status code")
         r=requests.get(getReqStr(d1),timeout=30)
         print(r.status_code)
         #print("sleep for 2 minutes")
         time.sleep(10)
         if r.status_code==200:
             print("success")        
             break
      except Exception as e:
          print(e)
             # logging.info("{}".format(e))
          print("sleep for 2 minutes")
          time.sleep(120)
  driver = webdriver.Chrome(os.path.join(master_dir,"chromedriver.exe"))        
  driver.get(getReqStr(d1))
  time.sleep(10)
  shutil.move(os.path.join(download_dir,getFilename(d1)), 
         os.path.join(data_dir,getFilename(d1)))     
  driver.close()
  emails = get_contacts(contacts_dir+'backoffice_automation.txt') # read contacts backoffice_automation.txt
  subject = "CM_PRICE_BAND COMPLETE LIST"      
  combine_html_excel(emails,subject)
         
def main(nd):
    d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    if process_run_check(d)== -1:
        return -1 
    
    CM_Price(d)

main(0)
















