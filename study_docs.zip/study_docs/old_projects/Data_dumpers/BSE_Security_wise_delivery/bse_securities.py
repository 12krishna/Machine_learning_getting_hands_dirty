#import urllib2
import datetime
from dateutil.relativedelta import relativedelta
import requests
import httplib, StringIO, zipfile
import os
import sys
from cassandra.cluster import Cluster
import logging
import pandas as pd 
from dateutil import parser
import time 
import redis

log_path = "D:\\Data_dumpers\\BSE_Security_wise_delivery\\"
security_processed_files = "D:\\Data_dumpers\\BSE_Security_wise_delivery\\Processed_files\\"
master_dir = "D:\\Data_dumpers\\Master\\"
redis_host = 'localhost'
cassandra_host = '172.17.9.51'

os.chdir(log_path)

# log events in debug mode 
logging.basicConfig(filename=log_path+"bse_securities.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


class bseConnect:
    headers = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
               'Accept':'application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5',
               'Accept-Encoding':'gzip,deflate,sdch',
               'Referer':'https://www.bseindia.com'}

    url = "www.bseindia.com"
    
    def connect(self):
        response = requests.head('https://' + self.url, timeout=(3,180))
        if response.status_code == 302:
            self.url = response.headers["Location"]
        
        self.url = self.url[self.url.find("//")+1:  ]
        self.conn = httplib.HTTPSConnection(self.url)
        print "Connection established"
       
            
            
    def disconnect(self):
        self.conn.close()

    def getFilename(self, date, flag):
        [y, m, d] = self.convertDate(date)
        if flag==0:
            ''' Equities filename'''
            return "EQ_ISINCODE_%s%s%s.CSV" % (d, m, y[2:])
        elif flag==1:
            '''Securities filename'''
            return "SCBSEALL%s%s.txt" % (d, m)
            
                   
        

    def convertDate(self, date):
        y = date.strftime("%Y")
        m = date.strftime("%m")
        d = date.strftime("%d")
        return [y, m, d]

    def getReqStr(self, date, flag):
        [y, m, d] = self.convertDate(date)
        
        if flag==0:
            # equities
            return "/download/BhavCopy/Equity/%s.ZIP" % (self.getFilename(date, flag)[:-4])
        elif flag==1:
            #securitites
            return "/BSEDATA/gross/%s/SCBSEALL%s%s.ZIP" % (y, d,m)
        

    def getResponse(self, reqstr):
        c = self.conn
        
        c.request("GET", reqstr, None, self.headers)
        response = c.getresponse()
        self.data = response.read()
        print response.status
        if response.status == 403:
            print "Response status is %s\tCould not download %s." % (response.status, reqstr)
            logging.info("Response status is %s\tCould not download %s." % (response.status, reqstr))
            print "%s" % (self.data)
            logging.info("%s" % (self.data))
            return -1
        elif response.status == 404:
            print "File not found\tCould not download %s." % (reqstr)
            logging.info("File not found\tCould not download %s." % (reqstr))
            return -1
        elif response.status != 200:
            print "Response status is %s \tCould not download %s." % (response.status, reqstr)
            logging.info("Response status is %s \tCould not download %s." % (response.status, reqstr))
            print "%s" % (self.data)
            logging.info("%s" % (self.data))
            return -1
        elif response.status==200:
            return response.status



    
def securities_cassandra_dumper(filename, date, session):
    '''Func to process securities file and dump to cassandra db'''

    # read txt file with delimeter into df
    df = pd.read_csv(filename, delimiter= "|")
    df['DATE']=date
    df.rename(columns={'DATE':'Traded_date'}, inplace=True)
    og_len = len(df)
    # write to temp csv to dump in cassandra db
    df.to_csv('temp1.csv', index = False)
    
    # dump csv to cassandra
    os.system(log_path+'securities_cassandra.bat')
    
    logging.info('Sucess: File dumped in cassandra - {}'.format(date))
    #get number of rows dumped into cassandra and original rows in file
    d = "{}-{}-{}".format(date.strftime("%Y"), date.strftime("%m"), date.strftime("%d") )
    
    c_len = session.execute('select count(*) from rohit.bse_security_wise_delivery where traded_date = \'{}\' allow filtering;'.format(d)).one()[0]
    print 'Number of rows in orginal file {},number of rows dumped in cassandra {}'.format(og_len,c_len)
    logging.info('{} : Number of rows in orginal file {}, number of rows dumped in cassandra {} '.format(d,og_len,c_len))
    # remove bhavcopy from download dir
            
    r = redis.Redis(host=redis_host, port=6379) 
    r.set('bse_SCBSE_dumper', 1)
    r.set('market_snap_bse_security', 1)
            
    r.set('bse_SCBSE_dumper_lengths',
                  '{}: {} rows dumped in cassandra , whereas {} rows were present in original file'.format(d,c_len,og_len))
    logging.info('Flags set for notification email.')
    
    
      
    
    
    
def filename_searcher(c,date):
    '''Func to lookup securities file in processed dir'''
    [y, m, d] = c.convertDate(date)
    
    filename = 'SCBSEALL%s%s%s.txt'%(d,m,y)
    if os.path.exists(os.path.join(security_processed_files, filename)):
        print 'File exist for {0}'.format(date)
        logging.info('File exist for {0}'.format(date))
        return True
    else:
        return False
    
    
def downloadCSV(c, date, flag, session):
    filename = c.getFilename(date, flag)
    reqstr = c.getReqStr(date, flag)
    [y, m, d] = c.convertDate(date)
    print reqstr
    print "Downloading %s ..." % (filename)
    logging.info("Downloading %s ..." % (filename))
    
    # read holiday master
    holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
    #responsecode = None
    if len(holiday_master[holiday_master['date']==date])==0:
        # working day so run until bhavcopy is downloaded
        
        #responsecode = c.getResponse(reqstr) 
        #print "Response code {}".format(responsecode)
        while datetime.datetime.now().time() > datetime.time(16,0):
            # sleep for 2 min
            logging.info('{} is Working day : sleep for 2 minutes '.format(date))
            print 'Sleep for 2 min...'
            time.sleep(120)
            try:
                responsecode = c.getResponse(reqstr)
                print "Response code {}, sleep".format(responsecode)
                if responsecode==200:
                    print "Response code {}, break".format(responsecode)
                    break
            except Exception as e:
                print "Exception occured for the request:  {}".format(e)
                
    elif len(holiday_master[holiday_master['date']==date])==1:
        logging.info('Holiday: skip for current date : ',date)
        return -1 
    
        
    try:
        #responsecode = c.getResponse(reqstr)
        sdata = StringIO.StringIO(c.data)
    
        z = zipfile.ZipFile(sdata)
        csv = z.read(z.namelist()[0])
        
    
    except Exception as e:
        print "%s" % (format(e))
        logging.info('{}- File not found, Error: {}'.format(date,e))
        return -1
    if not csv:
        print "Could not download %s." % (e.message)
        logging.info( "{}- Could not download {}" .format(date,e.message) )
        return -1
    else:        
        if flag == 1:
            fil = open(os.path.join(security_processed_files,'SCBSEALL%s%s%s.txt'%(d,m,y)), 'w')
            fil.write(csv)
            fil.close()
            # process and dump the csv file in cassandra db
            logging.info('Success: {} File downloaded '.format(date))
            securities_cassandra_dumper(os.path.join(security_processed_files,'SCBSEALL%s%s%s.txt'%(d,m,y)), date, session)  
            
            return 1

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster



def getUpdate(c):
    '''Func to downlaod files and dump to cassandra db'''
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()
    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')
    logging.info('Using rohit keyspace')
       
    # CREATE A TABLE; dump bhavcopies to this table for securities
    session.execute('CREATE TABLE IF NOT EXISTS bse_security_wise_delivery (traded_date date, scrip_code int, delivery_qty int, delivery_val bigint ,day_volume bigint, day_turnover bigint, delv_per decimal, PRIMARY KEY (scrip_code, traded_date))')
    logging.info('Creating security wise delivery')
    flag =1
    errContinous = 0
    d = datetime.date.today()-datetime.timedelta(days=0)
    decr = datetime.timedelta(days=1)   
     
    while errContinous > -365 and (not filename_searcher(c, d) ):
        print d
        if d == parser.parse('2016 01 01').date():
            logging.info('All files dumped till 2016/1/1')
            break
        if downloadCSV(c, d, flag, session) > -1:
            errContinous = 0
            logging.info('Success: {0}'.format(d))
        else:
            errContinous -= 1
        d -= decr
    
    cluster.shutdown() # close cassandra connection 
    

def main(args):
    c = bseConnect()
    c.connect()
    
    if args:
        if args[0] == "-update":
            getUpdate(c)        
        
    c.disconnect()

if __name__ == "__main__":
    main(sys.argv[1:])
