import pandas as pd 
import numpy as np
import requests,re,os,datetime,time,logging,redis,wget,urllib2
from cassandra.cluster import Cluster
from dateutil.parser import parse
from bs4 import BeautifulSoup
from lxml import html
from selenium import webdriver

os.chdir("D:\\Data_dumpers\\BSE_category_turnover\\")

cassandra_host = "172.17.9.51"
redis_host = 'localhost'

master_dir = "D:\\Data_dumpers\\Master\\"
processed_dir = "D:\\Data_dumpers\\BSE_category_turnover\\processed_dir\\"
#server = '172.17.9.149'; port = 25
#cassandra_host = "localhost"

logging.basicConfig(filename='test.log',
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


#cluster = Cluster([cassandra_host])
cluster = cassandra_configs_cluster()
logging.info('Cassandra Cluster connected...')
# connect to your keyspace and create a session using which u can execute cql commands 
session = cluster.connect('rohit')
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None    




def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
        
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print "working day wait file is getting downloaded"
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1
    
def BSE_turnover(nd):
    
    d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    print (d)
    if process_run_check(d)== -1:
        return -1
    url = "https://www.bseindia.com/markets/equity/EQReports/categorywise_turnover.aspx" #url to scrape
    driver = webdriver.Chrome('chromedriver.exe')
    driver.get(url)
    soup = BeautifulSoup(driver.page_source, 'lxml')
    print(soup.prettify())
#        tree = html.parse("C:\Users\devanshm\Desktop\devansh\scrapping\Categorywise Turnover.html")
#        raw_html=html.tostring(tree)
#        soup = BeautifulSoup(raw_html, 'html.parser')

    div = soup.find_all('td', class_="tableheading") #fetch table information
    row_val1=[]
    for i in range(len(div)):
        row_val1.append(div[i].text)
    
    div1 = soup.find_all('td', class_="tdcolumn") #fetch value information
    row_val2=[]
    for i in range(len(div1)):
        row_val2.append(div1[i].text)
        
    #keep only those values which are required and delete others
    del row_val1[1:11] 
    del row_val1[1:4]
    del row_val1[-6:]
    del row_val2[0:10]
    del row_val2[-20:]
        
    #the main df 
    val1=pd.DataFrame(columns=row_val1)
    #val1=pd.DataFrame(row_val1).T
    #val1.columns=val1.loc[0]
    #val1.drop(val1.index[0],inplace=True)
        
    #append rows in the main df
    for i in range(3):
        val1 = val1.append([{'Category':"Client"},{'Category':"NRI"},{'Category':"Proprietary"}], ignore_index=True)
            
    #add trading date
    row_val2=pd.DataFrame(row_val2)
    row_val2.columns=["values"]
    p=0
    c=0
    try:            
        for i in range(9):
            val1["Trade Date"][i]=row_val2["values"][p]
            if c >= 2:
                p=10
            if c >= 5:
                p=20
            c+=1
    
        row_val2.drop(row_val2.index[[[0,10,20]]],inplace=True)
        row_val2.reset_index(drop=True,inplace=True)
        
    except Exception as e:
        print "Error {}".format(e)
        row_val2.drop(row_val2.index[[[0,10]]],inplace=True)
        row_val2.reset_index(drop=True,inplace=True)
        
        
    #add values to column buy,sales and net
    val1.dropna(subset=['Trade Date'], inplace=True)
    c1=0
    for i in range(len(val1)):
        val1["Buy"][i]=row_val2["values"][c1]
        c1+=1
        val1["Sales"][i]=row_val2["values"][c1]
        c1+=1
        val1["Net"][i]=row_val2["values"][c1]
        c1+=1
    
    val1.rename(columns={"Trade Date":"Tradingdate"},inplace=True)   
    val1["Tradingdate"]=pd.to_datetime(val1["Tradingdate"], dayfirst=True).dt.date
    val1['Buy'] = (val1['Buy'].replace(',','', regex=True).astype(float))
    val1['Sales'] = (val1['Sales'].replace(',','', regex=True).astype(float))
    val1['Net'] = (val1['Net'].replace(',','', regex=True).astype(float))
        
    val1.to_csv("bseturnover.csv",index=False)
    val1.to_csv(processed_dir+"bseturnover_{}.csv".format(d),index=False)
    #create table if not exists
    session.execute("CREATE TABLE IF NOT EXISTS bse_category_turnover(Category TEXT,Tradingdate DATE,Buy FLOAT,Sales FLOAT,Net FLOAT, PRIMARY KEY (Category,Tradingdate))")
    os.system("bse_cat_turnover.bat")
    #os.remove("bseturnover.csv")
    driver.close()
    
    r = redis.Redis(host=redis_host, port=6379) 
    r.set('bse_catturnover_flag',1)
        
    checker = session.execute("select * from bse_category_turnover where tradingdate >= \'{}\' allow filtering;".format(
            datetime.datetime.now().date()- datetime.timedelta(days=10)))
    checker = checker._current_rows
    #checker.sort_values(by='traded_date', inplace=True)
            
            
            
    r.set("bse_catturnover_remarks",'Data dumped in bse_category_turnover table for {}'.format(
            checker.sort_values("tradingdate").tail(1)['tradingdate'].values[0]) )
           

    
BSE_turnover(0)