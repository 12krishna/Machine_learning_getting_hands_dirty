import requests 
import pandas as pd
from bs4 import BeautifulSoup
import re
import os
from lxml import html
import datetime
import time
from cassandra.cluster import Cluster
from dateutil.parser import parse
import logging
import numpy as np
import sys
from selenium import webdriver
from tabulate import tabulate
import redis

cassandra_host = "172.17.9.51"
#cassandra_host = "localhost"
redis_host = 'localhost'
server = '172.17.9.149'; port = 25
os.chdir("D:\\Data_dumpers\\FII_PI\\mfactualnumbers")

logging.basicConfig(filename='test.log',
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

cluster = Cluster([cassandra_host])
logging.info('Cassandra Cluster connected...')
# connect to your keyspace and create a session using which u can execute cql commands 
session = cluster.connect('rohit')
#session = cluster.connect('test_df')
logging.info('Using rohit keyspace')

# read holiday master
holiday_master = pd.read_csv('D:\\NSENotis\\Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
#holiday_master = pd.read_csv('C:\\Users\\devanshm\\Desktop\\devansh\\sebiscrapping\\Holidays_2019.txt', delimiter=',',
#                                 date_parser=dateparse, parse_dates={'date':[0]})    

holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
        
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
     
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        #print "working day wait file is getting downloaded"
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        #print ('Holiday: skip for current date :{} '.format(d))        
        return -1
    
#previous working date
def previous_working_day(d):
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d - datetime.timedelta(days=1)   
            else:
                return d
    
session.row_factory = pandas_factory
session.default_fetch_size = None

def mfactualnumbers(nd):
    d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    if process_run_check(d)== -1:
        return -1

    print(d)
    #get previous working date
    d=previous_working_day(d)
    print ("previous date",d)
    logging.info('Parameters read from redis for MFActualNumbers_flag')
    
    
    
    url = "https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doMfd=yes&type=2"
    driver = webdriver.Chrome('chromedriver.exe')
    driver.get(url)
    soup = BeautifulSoup(driver.page_source, 'lxml')
    
    
    with open('sebi.html','wb') as sfile:
        sfile.write(str(soup))
    print(soup.prettify())
    
#    table1 = soup.find_all('table')[0]
#    table2 = soup.find_all('table')[1]
#    df1 = pd.read_html(str(table1))
#    df2 = pd.read_html(str(table2))

#    print tabulate(df1[0],headers='keys',tablefmt='psql')
#    print tabulate(df2[0],headers='keys',tablefmt='psql')

#    df = pd.read_html(str(table))[0]
#    dfg=pd.read_html("SEBI _ Mutual Funds as on 07 Jun, 2019.html")
#    dfg=pd.read_html("https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doMfd=yes&type=2")
    dfg=pd.read_html("sebi.html")
    k=pd.DataFrame(dfg)
#    k=df
    report1=k[0][0]
    report2=k[0][1]
#    report1=pd.DataFrame(df1)
#    report2=pd.DataFrame(df2)
#    dfg.to_csv("test.csv")
    r_equity1=report1.loc[report1['Debt/Equity'].isin(["Equity"])][:-1]
    r_equity1['Trading Date']=pd.to_datetime(r_equity1["Trading Date"]).dt.date
    
    
    r_debt1=report1.loc[~report1['Debt/Equity'].isin(["Equity"])][:-2]
    r_debt1["Net Investment (Rs Crore)"]=r_debt1['Gross Sales(Rs Crore)']
    r_debt1['Gross Sales(Rs Crore)']=r_debt1['Gross Purchases(Rs Crore)']
    r_debt1['Gross Purchases(Rs Crore)']=r_debt1['Debt/Equity']
    r_debt1['Debt/Equity']=r_debt1['Trading Date']
    r_debt1["Trading Date"]=r_equity1["Trading Date"].values
    r_debt1["Trading Date"]=pd.to_datetime(r_debt1["Trading Date"]).dt.date
    final_report1=pd.concat([r_equity1,r_debt1])
    final_report1["Net Investment (Rs Crore)"]=final_report1["Net Investment (Rs Crore)"].str.replace('(',"-").str.replace(')',"").astype('float')
    final_report1["Gross Sales(Rs Crore)"]=final_report1["Gross Sales(Rs Crore)"].astype("float")
    final_report1["Gross Purchases(Rs Crore)"]=final_report1["Gross Purchases(Rs Crore)"].astype("float")
    final_report1.rename(columns={'Trading Date':'TradingDate'},inplace=True)
    final_report1.columns=['TradingDate','Debt_Equity','GrossPurchases','GrossSales','NetInvestment']
    final_report1.to_csv("MFActualNumbers1.csv",index=False)
    final_report1.to_csv("MFActualNumbers1_{}.csv".format(d),index=False)

    session.execute("CREATE TABLE IF NOT EXISTS MFActualNumbers_today(TradingDate DATE,Debt_Equity TEXT,GrossPurchases FLOAT,GrossSales FLOAT,NetInvestment FLOAT, PRIMARY KEY (TradingDate,Debt_Equity))")
    os.system("MFActualNumbers1.bat ")
    
    r_equity2=report2.loc[report2['Debt/Equity'].isin(["Equity"])]
    r_debt2=report2.loc[~report2['Debt/Equity'].isin(["Equity"])]
    r_debt2["Net Investment (Rs Crore)"]=r_debt2['Gross Sales(Rs Crore)']
    r_debt2['Gross Sales(Rs Crore)']=r_debt2['Gross Purchases(Rs Crore)']
    r_debt2['Gross Purchases(Rs Crore)']=r_debt2['Debt/Equity']
    r_debt2['Debt/Equity']=r_debt2['Period']
    r_debt2["Period"]=r_equity2["Period"].values
    final_report2=pd.concat([r_equity2,r_debt2])
    final_report2["Net Investment (Rs Crore)"]=final_report2["Net Investment (Rs Crore)"].astype('float')
    final_report2["Gross Sales(Rs Crore)"]=final_report2["Gross Sales(Rs Crore)"].astype("float")
    final_report2["Gross Purchases(Rs Crore)"]=final_report2["Gross Purchases(Rs Crore)"].astype("float")
    final_report2.columns=['Period','Debt_Equity','GrossPurchases','GrossSales','NetInvestment']
    final_report2.to_csv("MFActualNumbers2.csv",index=False)
    final_report2.to_csv("MFActualNumbers2_{}.csv".format(d),index=False)

    session.execute("CREATE TABLE IF NOT EXISTS MFActualNumbers_historical(Period TEXT,Debt_Equity TEXT,GrossPurchases FLOAT,GrossSales FLOAT,NetInvestment FLOAT, PRIMARY KEY (Period,Debt_Equity))")
    os.system("MFActualNumbers2.bat ")

    os.remove('sebi.html')  # delete downloaded html file 

#        file = open("output.txt","w") 
#        file.write("<html><head></head><body>")
#        file.write('<P><b><font face="Times New Roman" size={}>----Data is successfully stored for MFActualNumbers in cassandra-----</font></b></p>'.format(3.1))
#       file.write('</tbody></table> </body></html>')
#       file.close()
    cluster.shutdown()  #shutdown open cassandra instance 
    driver.close()  # close chrome driver instance 
    os.remove("MFActualNumbers1.csv")
    os.remove("MFActualNumbers2.csv")
    r = redis.Redis(host=redis_host, port=6379) 
    r.set('MFActualNumbers_flag',1)
    r.set('MFActualNumbers_flag1',1)

       
       
mfactualnumbers(nd=0)