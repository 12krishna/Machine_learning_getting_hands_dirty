# -*- coding: utf-8 -*-
"""
Created on Tue May  4 19:16:12 2021

@author: krishna
"""

import pandas as pd
from bs4 import BeautifulSoup
import os
import datetime
import time
from cassandra.cluster import Cluster
import logging
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
#from selenium.common.exceptions import TimeoutException
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.webdriver.common.by import By
import redis

cassandra_host = "172.17.9.51"
#cassandra_host = "localhost"
redis_host = 'localhost'
server = '172.17.9.149'; port = 25
os.chdir("D:\\Data_dumpers\\FII_PI\\mfactualnumbers")
processed_folder = "D:\\Data_dumpers\\FII_PI\\mfactualnumbers\\Processed\\"
master_dir="D:\\Data_dumpers\\Master\\"
logging.basicConfig(filename='test.log',
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def dateparse(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)


def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]

    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)

    return cluster


cluster = cassandra_configs_cluster()
#cluster = Cluster([cassandra_host])
logging.info('Cassandra Cluster connected...')
# connect to your keyspace and create a session using which u can execute cql commands
session = cluster.connect('rohit')
#session = cluster.connect('test_df')
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None


# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''

    if len(holiday_master[holiday_master['date']==d])==0:
        return 1

    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

#previous working date
def previous_working_day(d):
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d - datetime.timedelta(days=1)
            else:
                return d



def set_proxy_details():
    '''Func to set proxy for driver'''

    opts = Options()
    # Add headers
    user_agent =  ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) '
                   'AppleWebKit/537.36 (KHTML, like Gecko) '
                   'Chrome/39.0.2171.95 Safari/537.36')
    opts.add_argument(f'user-agent={user_agent}')
    # Remove the Automation Info
    opts.add_argument('--disable-infobars')
    #opts.add_argument("headless")
    opts.add_argument('--disable-gpu')
    opts.add_argument("--log-level=3")  # fatal


    driver = webdriver.Chrome(master_dir+"chromedriver.exe", chrome_options=opts)
    #driver.minimize_window()
    print ("Proxy details set for the session")
    return driver


def mfactualnumbers(nd):

    d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    if process_run_check(d)== -1:
        return -1

    print(f"processing for {d}")
    #get previous working date
    #d=previous_working_day(d)
    #print ("previous date",d)

    #url = "https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doMfd=yes&type=2"
    url = "https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doMfdTrendsSearch=yes"
    driver = set_proxy_details()
    driver.get(url)
    driver.execute_script("document.getElementById('date').value = '{}'".format(datetime.datetime.strftime(d,"%d-%m-%Y")))
    driver.find_elements_by_class_name("go-search")[0].click()
    time.sleep(15)

    soup = BeautifulSoup(driver.page_source, 'lxml')


    with open('sebi1.html','wb') as sfile:
        sfile.write(bytes(str(soup), encoding='utf-8'))
    print(soup.prettify())

    dfg=pd.read_html("sebi1.html")
    k=pd.DataFrame(dfg)
#    k=df
    report1=k[0][0]
    #report2=k[0][1]

    report1['Trading Date']=pd.to_datetime(report1["Trading Date"] ,errors='coerce')
    report1 = report1[~report1['Trading Date'].isnull()]
    report1.dropna(axis=1, how='all', inplace=True)
    report1['Trading Date'] = report1['Trading Date'].dt.date

    final_report1=report1
    try:
        final_report1["Net Investment (Rs Crore)"]=final_report1["Net Investment (Rs Crore)"].str.replace('(',"-").str.replace(')',"").astype('float')
    except:
        print("error because bracket is missing if bracket is there than replace it with minus sign")

    final_report1["Gross Sales(Rs Crore)"]=final_report1["Gross Sales(Rs Crore)"].astype("float")
    final_report1["Gross Purchases(Rs Crore)"]=final_report1["Gross Purchases(Rs Crore)"].astype("float")
    final_report1.rename(columns={'Trading Date':'TradingDate'},inplace=True)
    final_report1.columns=['TradingDate','Debt_Equity','GrossPurchases','GrossSales','NetInvestment']
    final_report1.to_csv("MFActualNumbers1.csv",index=False)
    final_report1.to_csv(processed_folder+"MFActualNumbers1_{}.csv".format(d),index=False)

    session.execute("CREATE TABLE IF NOT EXISTS MFActualNumbers_today(TradingDate DATE,Debt_Equity TEXT,GrossPurchases FLOAT,GrossSales FLOAT,NetInvestment FLOAT, PRIMARY KEY (TradingDate,Debt_Equity))")
    os.system("MFActualNumbers1.bat ")
    os.remove("MFActualNumbers1.csv")

    # MF historical data
    url="https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doMfd=yes&type=2"
    driver.delete_all_cookies()
    driver.get(url)
    time.sleep(5)
    soup = BeautifulSoup(driver.page_source, 'lxml')


    with open('sebi2.html','wb') as sfile:
        sfile.write(bytes(str(soup), encoding='utf-8'))
    print(soup.prettify())

    dfg=pd.read_html("sebi2.html")
    k=pd.DataFrame(dfg)
#    k=df
    try:
        report2=k[0][1]
        final_report2 = report2
        final_report2.columns=['Period','Debt_Equity','GrossPurchases','GrossSales','NetInvestment']
        final_report2.to_csv("MFActualNumbers2.csv",index=False)
        final_report2.to_csv(processed_folder+"MFActualNumbers2_{}.csv".format(d),index=False)

        session.execute("CREATE TABLE IF NOT EXISTS MFActualNumbers_historical(Period TEXT,Debt_Equity TEXT,GrossPurchases FLOAT,GrossSales FLOAT,NetInvestment FLOAT, PRIMARY KEY (Period,Debt_Equity))")
        os.system("MFActualNumbers2.bat ")
        os.remove("MFActualNumbers2.csv")

    except Exception as e:
        print ("Data not avaliable for historical MF ")
        print (e)



    '''
    r_equity2=report2.loc[report2['Debt/Equity'].isin(["Equity"])]
    r_debt2=report2.loc[~report2['Debt/Equity'].isin(["Equity"])]
    r_debt2["Net Investment (Rs Crore)"]=r_debt2['Gross Sales(Rs Crore)']
    r_debt2['Gross Sales(Rs Crore)']=r_debt2['Gross Purchases(Rs Crore)']
    r_debt2['Gross Purchases(Rs Crore)']=r_debt2['Debt/Equity']
    r_debt2['Debt/Equity']=r_debt2['Period']
    r_debt2["Period"]=r_equity2["Period"].values
    final_report2=pd.concat([r_equity2,r_debt2])
    final_report2["Net Investment (Rs Crore)"]=final_report2["Net Investment (Rs Crore)"].astype('float')
    final_report2["Gross Sales(Rs Crore)"]=final_report2["Gross Sales(Rs Crore)"].astype("float")
    final_report2["Gross Purchases(Rs Crore)"]=final_report2["Gross Purchases(Rs Crore)"].astype("float")
    final_report2.columns=['Period','Debt_Equity','GrossPurchases','GrossSales','NetInvestment']
    final_report2.to_csv("MFActualNumbers2.csv",index=False)
    final_report2.to_csv(processed_folder+"MFActualNumbers2_{}.csv".format(d),index=False)

    session.execute("CREATE TABLE IF NOT EXISTS MFActualNumbers_historical(Period TEXT,Debt_Equity TEXT,GrossPurchases FLOAT,GrossSales FLOAT,NetInvestment FLOAT, PRIMARY KEY (Period,Debt_Equity))")
    os.system("MFActualNumbers2.bat ")
    '''
    os.remove('sebi1.html')  # delete downloaded html file
    os.remove('sebi2.html')  # delete downloaded html file

    cluster.shutdown()  #shutdown open cassandra instance
    driver.close()  # close chrome driver instance

    r = redis.Redis(host=redis_host, port=6379)
    r.set('MFActualNumbers_flag',1)
    r.set('MFActualNumbers_flag1',1)

mfactualnumbers(nd=0)


'''
import calendar
for i in range(2019, 2020):
    for j in range(1,13):
        print (datetime.date(i,j,calendar.monthrange(i,j)[1]))

        mfactualnumbers(datetime.date(i,j,calendar.monthrange(i,j)[1]))

cluster.shutdown()  #shutdown open cassandra instance
'''
