import pandas as pd 
import numpy as np
import requests 
import re
import os
import datetime
import time
from cassandra.cluster import Cluster
from dateutil.parser import parse
import logging
from bs4 import BeautifulSoup
from lxml import html
import redis
import shutil

cassandra_host = "172.17.9.51"
redis_host = 'localhost'

master_dir = "D:\\Data_dumpers\\Master\\"
output_dir = "D:\\Data_dumpers\\FII_PI\\fianddi\\Output\\"
email_dir ="D:\\Emails\\Output\\"
market_snap = "D:\\Market_Snapshot\\"
market_pos = "D:\\Market_positioning\\"


logging.basicConfig(filename='test.log',
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


#cluster = Cluster([cassandra_host])
cluster = cassandra_configs_cluster()
logging.info('Cassandra Cluster connected...')
# connect to your keyspace and create a session using which u can execute cql commands 
session = cluster.connect('rohit')
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None
    

#holiday=pd.read_csv(master_dir+"Holidays_2019.txt")
#holiday["Dates"]=pd.to_datetime(holiday["Dates"]).dt.date
    
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
        
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

def previous_working_day(d):
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d - datetime.timedelta(days=1)   
            else:
                return d

#import all nessary data
def fetch_fiderivative(value,inr):
    
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    #session = cluster.connect('rohit')
    logging.info('Using rohit keyspace')
    #session.row_factory = pandas_factory
    #session.default_fetch_size = None
    # CREATE A TABLE; dump bhavcopies to this table
    logging.info("Reading data from cassandra")
    query=session.execute("SELECT reportingdate,idx_fut_buy_crore,idx_fut_sell_crore,idx_opt_buy_crore,idx_opt_sell_crore,stk_fut_buy_crore,stk_fut_sell_crore,stk_opt_buy_crore,stk_opt_sell_crore FROM rohit.fderivativeactivity where reportingdate='{}' ALLOW FILTERING".format(value))
    result = query._current_rows
    #calculation for corore to million
    IDXfut=(((result["idx_fut_buy_crore"]-result["idx_fut_sell_crore"])*10)/inr).round(1)
    IDXoptions=(((result["idx_opt_buy_crore"]-result["idx_opt_sell_crore"])*10)/inr).round(1)
    Stockfut=(((result["stk_fut_buy_crore"]-result["stk_fut_sell_crore"])*10)/inr).round(1)
    Stockoptions=(((result["stk_opt_buy_crore"]-result["stk_opt_sell_crore"])*10)/inr).round(1)
    
    return IDXfut,IDXoptions,Stockfut,Stockoptions

#import all nessary data
def fetch_fianddi(value,inr):
    
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    #session = cluster.connect('rohit')
    logging.info('Using rohit keyspace')
    #session.row_factory = pandas_factory
    #session.default_fetch_size = None
    # CREATE A TABLE; dump bhavcopies to this table 
    logging.info("Reading data from cassandra")
    query=session.execute("SELECT category,date,netvalue FROM rohit.fiianddiiprovisionalnumbers where date='{}' ALLOW FILTERING".format(value))
    result = query._current_rows
    #calculation for corore to million
    result['netvalue']=result['netvalue'].astype('float')
    result['netvalue'] = result['netvalue'].apply(lambda row: round(row*10/inr,1))
    FIIFPI = result[result['category']=='FII/FPI']['netvalue'].values[0]
    DII = result[result['category']=='DII']['netvalue'].values[0]
    #FIIFPI=((result['netvalue'][0]*10)/inr).round(1)
    #DII=((result['netvalue'][1]*10)/inr).round(1)
    
    return FIIFPI,DII

#import all nessary data
def fetch_equity_debt_fpi(value,inr):
    
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    #logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    #session = cluster.connect('rohit')
    #logging.info('Using rohit keyspace')
    #session.row_factory = pandas_factory
    #session.default_fetch_size = None
    # CREATE A TABLE; dump bhavcopies to this table
    logging.info("Reading data from cassandra")
    #query=session.execute("SELECT reportingdate,debt_s_e_net_million,debt_p_m_net_million FROM rohit.equity_debt_fpi Where reportingdate <= '{}' ALLOW FILTERING".format(value,inr))
    query=session.execute("SELECT reportingdate,debt_s_e_net_million,debt_p_m_net_million FROM rohit.equity_debt_fpi ALLOW FILTERING")
    result = query._current_rows
    result.sort_values(by="reportingdate",ascending=True,inplace=True)
    print "sorted result",result

    #calculation for corore to million
    yesterday=result[-1:]
    print "yesterday",yesterday
    yesterday1=float((yesterday["debt_s_e_net_million"]+yesterday["debt_p_m_net_million"]).sum().round(1))
    
    #yesterday["netinvestment"]=((yesterday["netinvestment"]*10)/inr).round(1)
    #yesterday=str(yesterday["netinvestment"])
    #yesterday=yesterday.split(' ',1)[1]
    #yesterday=yesterday.replace(" ","").split('\n')[0]
    #yesterday1=float(yesterday)
    
    week=result[-5:]
    print "week",week
    week1=float((week["debt_s_e_net_million"]+week["debt_p_m_net_million"]).sum().round(1))
    #week=(((week["netinvestment"].sum())*10)/inr).round(2)
    #week=float(week)
    
    month=result[-22:]
    print "month",month
    month1=float((month["debt_s_e_net_million"]+month["debt_p_m_net_million"]).sum().round(1))

    #month=(((month["netinvestment"].sum())*10)/inr).round(2)
    #month1=float(month)
        
    return yesterday1,week1,month1

#import all nessary data
def usd_to_inr(value):
    
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    #logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    #session = cluster.connect('rohit')
    #logging.info('Using rohit keyspace')
    #session.row_factory = pandas_factory
    #session.default_fetch_size = None
    # CREATE A TABLE; dump bhavcopies to this table
    logging.info("Reading data from cassandra")
    query=session.execute("SELECT * FROM rohit.bloom_usd_inr where date='{}'  ALLOW FILTERING".format(value))
    result = query._current_rows
    
    return result

def finalreport(nd):
    d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    #d=datetime.datetime.now().date()
    print d
    if process_run_check(d) == -1:
            return -1    
    
    r=redis.Redis(host=redis_host, port=6379) 
    FIIActualNumbers_flag = int(r.get('FIIActualNumbers_flag1') if r.get('FIIActualNumbers_flag1')!=None else 0   )
    FIIandDIIProvisionalNumbers_flag = int(r.get('FIIandDIIProvisionalNumbers_flag1') if r.get('FIIandDIIProvisionalNumbers_flag1')!=None else 0 )
    FDerivativeActivity_flag = int(r.get('FDerivativeActivity_flag1') if r.get('FDerivativeActivity_flag1')!=None else 0 )
    #MFActualNumbers_flag = int(r.get('MFActualNumbers_flag1') if r.get('MFActualNumbers_flag1')!=None else 0 ) 
    logging.info('Parameters read from redis for email flag1')
    while True:
        
        if FIIActualNumbers_flag==1 and FIIandDIIProvisionalNumbers_flag==1 and FDerivativeActivity_flag==1 :
            
            usdtoinr=usd_to_inr(d)
    #        print usdtoinr
            usdtoinr["usd_inr"]=usdtoinr["usd_inr"][0]
            inr=float(usdtoinr["usd_inr"][0])
            #month_char=datetime.datetime.strftime(d, '%b')
            #day_char=d.day
            #day_year=datetime.datetime.strftime(d, '%Y').lstrip('20')
            
            previousday=previous_working_day(d)
            day_char=previousday.day
            month_char=datetime.datetime.strftime(previousday, '%b')
            day_year=datetime.datetime.strftime(previousday, '%Y').lstrip('20')
    
    #       res = requests.get("https://www.nseindia.com/products/content/equities/equities/fii_dii_market_today.htm")
    #       soup = BeautifulSoup(res.content,'lxml')
    #       tree = html.parse("C:\Users\devanshm\Desktop\devansh\sebiscrapping\XE_ Convert USD_INR. United States Dollar to India Rupee.html")
    #       raw_html=html.tostring(tree)
    #       soup = BeautifulSoup(raw_html, 'html.parser')
    #       close=soup.find_all('strong')
    #       usd_inr=[]
    #       for i in range(len(close)):
    #       print close[i].text
    #       usd_inr.append(close[i].text)
    #       inr=float(usd_inr[1])
    #       inr=round(inr,2)
        
            IDXfut,IDXoptions,Stockfut,Stockoptions= fetch_fiderivative(d,inr)
            if IDXfut[0] <= 0:
                idx1="sold"
            else:
                idx1="bot"
        
            if IDXoptions[0] <= 0:
                idx2="sold"
            else:
                idx2="bot"
        
            if Stockfut[0] <= 0:
                stk1="sold"
            else:
                stk1="bot"
        
            if Stockoptions[0] <= 0:
                stk2="sold"
            else:
                stk2="bot"
            
            FIIFPI,DII= fetch_fianddi(d,inr)
            if FIIFPI <= 0:
                F1="sold"
            else:
                F1="bot"
        
            if DII <= 0:
                D1="sold"
            else:
                D1="bot"
    
            yesterday,week,month=fetch_equity_debt_fpi(d, inr)
            if yesterday <= 0:
                y1="sold"
            else:
                y1="bot"
    
            if week <= 0:
                w1="sold"
            else:
                w1="bot"
    
            if month <= 0:
                m1="sold"
            else:
                m1="bot"
            #generate output file to be sent via email
            file = open(output_dir+"output_{}.txt".format(d),"w") 
            file.write("<html><head></head><body>")
            file.write('<P><b><font face="Calibri" size={}>----FLOW YESTERDAY in FnO-----</font></b></p>'.format(3.1))
            file.write('<P><font face="Calibri" size={}>FII\'s {} $ {}mn worth of IDX fut.</font></p>'.format(3.1,idx1,abs(IDXfut[0])))
            file.write('<P><font face="Calibri" size={}>FII\'s {} $ {}mn worth of IDX options.</font></p>'.format(3.1,idx2,abs(IDXoptions[0])))
            file.write('<P><font face="Calibri" size={}>FII\'s {} $ {}mn worth of Stock fut.</font></p>'.format(3.1,stk1,abs(Stockfut[0])))
            file.write('<P><font face="Calibri" size={}>FII\'s {} $ {}mn worth of Stock options.</font></p>'.format(3.1,stk2,abs(Stockoptions[0])))
    
            file.write('<P><b><font face="Calibri" size={}>----FLOW YESTERDAY Provisional Cash-------</font></b></p>'.format(3.1))
            file.write('<P><font face="Calibri" size={}>FII\'s {} $ {}mn in cash.</font></p>'.format(3.1,F1,abs(FIIFPI)))
            file.write('<P><font face="Calibri" size={}>DII\'s {} $ {}mn in cash.</font></p>'.format(3.1,D1,abs(DII)))
            
            file.write('<P><b><font face="Calibri" size={}>-----FLOW ON {} {} {} in Debt Market -----</font></b></p>'.format(3.1,day_char,month_char,day_year))
            file.write('<P><font face="Calibri" size={}>FII\'s {} $ {}mn in Debt Market.</font></p>'.format(3.1,y1,abs(yesterday)))
            
            file.write('<P><b><font face="Calibri" size={}>----FLOW 1 Week in Debt Market-------</font></b></p>'.format(3.1))
            file.write('<P><font face="Calibri" size={}>FII\'s {} $ {}mn in Debt Market.</font></p>'.format(3.1,w1,abs(week)))
            
            file.write('<P><b><font face="Calibri" size={}>----FLOW 1 Month in Debt Market-------</font></b></p>'.format(3.1))
            file.write('<P><font face="Calibri" size={}>FII\'s {} $ {}mn in Debt Market.</font></p>'.format(3.1,m1,abs(month)))
            file.write('</tbody></table> </body></html>')
            file.close()
            shutil.copy(output_dir+"output_{}.txt".format(d), email_dir+"fidi_report_{}.txt".format(d) )
            
            # market snapshot 
            file = open(market_snap+"fidi_report.txt","w") 
            file.write("\n----FLOW YESTERDAY in FnO-----")
            file.write("\nFII's {} $ {}mn worth of IDX fut.".format(idx1,abs(IDXfut[0])))
            file.write("\nFII's {} $ {}mn worth of IDX options.".format(idx2,abs(IDXoptions[0])))
            file.write("\n\nFII's {} $ {}mn worth of Stock fut.".format(stk1,abs(Stockfut[0])))
            file.write("\nFII's {} $ {}mn worth of Stock options.".format(stk2,abs(Stockoptions[0])))
    
            file.write("\n\n----FLOW YESTERDAY Provisional Cash-----")
            file.write("\nFII's {} $ {}mn in cash.".format(F1,abs(FIIFPI)))
            file.write("\nDII's {} $ {}mn in cash.".format(D1,abs(DII)))
            file.close()
            
			# market positioning 
            file = open(market_pos+"fidi_report.txt","w") 
            file.write("\n----FLOW YESTERDAY in FnO-----")
            file.write("\nFII's {} $ {}mn worth of IDX fut.".format(idx1,abs(IDXfut[0])))
            file.write("\nFII's {} $ {}mn worth of IDX options.".format(idx2,abs(IDXoptions[0])))
            file.write("\n\nFII's {} $ {}mn worth of Stock fut.".format(stk1,abs(Stockfut[0])))
            file.write("\nFII's {} $ {}mn worth of Stock options.".format(stk2,abs(Stockoptions[0])))
            
            file.write("\n\n----FLOW YESTERDAY Provisional Cash-----")
            file.write("\nFII's {} $ {}mn in cash.".format(F1,abs(FIIFPI)))
            file.write("\nDII's {} $ {}mn in cash.".format(D1,abs(DII)))
            
            file.write('\n\n-----FLOW ON {} {} {} in Debt Market -----'.format(day_char,month_char,day_year))
            file.write('\nFII\'s {} $ {}mn in Debt Market.'.format(y1,abs(yesterday)))
            
            file.write('\n\n----FLOW 1 Week in Debt Market-------')
            file.write('\nFII\'s {} $ {}mn in Debt Market.'.format(w1,abs(week)))
            
            file.write('\n\n----FLOW 1 Month in Debt Market-------')
            file.write('\nFII\'s {} $ {}mn in Debt Market.'.format(m1,abs(month)))
            file.close()           
                  
            
            # reset after all process completed 
            r.set('FIIActualNumbers_flag1',0)
            r.set('FIIandDIIProvisionalNumbers_flag1',0)
            r.set('FDerivativeActivity_flag1',0)
            r.set('MFActualNumbers_flag1',0)
            break
        else:
            print 'Sleep for 120 sec'
            time.sleep(120)
            
            # update flags
            FIIActualNumbers_flag = int(r.get('FIIActualNumbers_flag1') if r.get('FIIActualNumbers_flag1')!=None else 0   )
            FIIandDIIProvisionalNumbers_flag = int(r.get('FIIandDIIProvisionalNumbers_flag1') if r.get('FIIandDIIProvisionalNumbers_flag1')!=None else 0 )
            FDerivativeActivity_flag = int(r.get('FDerivativeActivity_flag1') if r.get('FDerivativeActivity_flag1')!=None else 0 )
          
        




start_time = time.time()

if __name__ == '__main__':
    finalreport(nd=0)  # set (nd = timedelta) days here 
    
    #shutil.copy(output_dir+"output_{}.txt".format(datetime.datetime.now().date()), market_snap+"fidi_report.txt" )

end_time = time.time()


logging.info('Time taken to process :'.format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)