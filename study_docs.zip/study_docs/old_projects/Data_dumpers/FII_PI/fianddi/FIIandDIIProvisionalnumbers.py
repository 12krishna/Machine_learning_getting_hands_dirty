import pandas as pd
from bs4 import BeautifulSoup
import requests
import re
import os
from lxml import html
import datetime
import time
from cassandra.cluster import Cluster
from dateutil.parser import parse
import logging
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait 
import redis

#cassandra_host = "localhost" for running locally
cassandra_host = "172.17.9.51" 
redis_host = 'localhost'
os.chdir("D:\\Data_dumpers\\FII_PI\\fianddi")
master_dir="D:\\Data_dumpers\\Master\\"
processed_dir = "D:\\Data_dumpers\\FII_PI\\fianddi\\Processed\\"


logging.basicConfig(filename='test.log',
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster

cluster = cassandra_configs_cluster()
#cluster = Cluster([cassandra_host])
logging.info('Cassandra Cluster connected...')
# connect to your keyspace and create a session using which u can execute cql commands 
session = cluster.connect('rohit')
#session = cluster.connect('test_df')
logging.info('Using rohit keyspace')


def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    

#holiday_master = pd.read_csv('C:\\Users\\devanshm\\Desktop\\devansh\\sebiscrapping\\Holidays_2019.txt', delimiter=',',
#                                 date_parser=dateparse, parse_dates={'date':[0]})    


holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
        
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
  
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

session.row_factory = pandas_factory
session.default_fetch_size = None

def FIIandDIIProvisionalnumbers(nd): 
       
        d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
        if process_run_check(d) == -1:
            return -1
        logging.info('Parameters read from redis for FIIandDIIProvisionalNumbers_flag')
        
        
        
        while True:
            print("here")
            try:
                    
                url = "https://www1.nseindia.com/products/content/equities/equities/fii_dii_market_today.htm"
                driver = webdriver.Chrome('chromedriver.exe')
                logging.info("download file")
                driver.get(url)
                
                driver.implicitly_wait(60)
                driver.implicitly_wait(100)
                WebDriverWait(driver, 10000)
                driver.implicitly_wait(100)
                time.sleep(20)
                
                
                soup = BeautifulSoup(driver.page_source, 'lxml')
                print(soup.prettify())
            except Exception as e:
                print e
                print "Sleep for 30 seconds"
                driver.close()
                time.sleep(30)
                continue
    #        tree = html.parse("NSE - National Stock Exchange of India Ltd..html")
    #        raw_html=html.tostring(tree)
    #        soup = BeautifulSoup(raw_html, 'html.parser')
          
            column=soup.find_all('th')
            column_val=[]
            for i in range(len(column)):
                    #print column[i].text
                    column_val.append(column[i].text)
            column_val[1:6]
    
            row1=soup.find_all('tr')
            row_val1=[]
            for i in range(len(row1)):
                    #print row1[i].text
                    row_val1.append(row1[i].text)
            val1=pd.DataFrame(row_val1)
    
            val2=val1[0].str.split('\n', expand=True)
            val2.columns=['0','Category','Date','BuyValue','SellValue','NetValue','0']
            val2.drop(val2['0'],axis=1,inplace=True)
            val2.dropna(inplace=True)
            val2.drop(val2[val2.Category =="Category" ].index, inplace=True)
            #val2.drop(val2.index[[0,2]],axis=1,inplace=True)
            val2['Date'] =  pd.to_datetime(val2['Date'])
            val2['Date'] = val2['Date'].dt.date
            val2['Category'] = val2['Category'].str.strip()
            if val2["Date"].values[0]==d:
                val2 = val2[['Category','Date','BuyValue','NetValue','SellValue']]
                val2.to_csv("FIIandDIIProvisionalnumbers.csv",index=False)
                val2.to_csv(processed_dir+"FIIandDIIProvisionalnumbers_{}.csv".format(d),index=False)
                logging.info("create table")
                session.execute("CREATE TABLE IF NOT EXISTS FIIandDIIProvisionalnumbers(Category TEXT,Date date,BuyValue decimal,SellValue decimal,NetValue decimal, PRIMARY KEY (Category,Date))")
                logging.info("copy value into cassandra")
                os.system("dumper.bat")
                file = open("output.txt","w") 
                file.write("<html><head></head><body>")
                file.write('<P><b><font face="Times New Roman" size={}>----Data is successfully stored for FIIandDIIProvisonalNumbers in cassandra-----</font></b></p>'.format(3.1))
                file.write('</tbody></table></body></html>')
                file.close()
                cluster.shutdown()  #shutdown open cassandra instance 
                driver.close()  # close chrome driver instance 
                os.remove("FIIandDIIProvisionalnumbers.csv ")
                r = redis.Redis(host=redis_host, port=6379) 
                r.set('FIIandDIIProvisionalNumbers_flag',1)
                r.set('FIIandDIIProvisionalNumbers_flag1',1)
                r.set("market_snap_fidiprovnum",1)
                break
            else:
                print 'Sleep for 3 min'
                driver.close()
                time.sleep(120)
        
                #FIIandDIIProvisionalnumbers()
        



start_time = time.time()

if __name__ == '__main__':
    FIIandDIIProvisionalnumbers(nd=0)  # set dollar value and (nd = timedelta) days here 

end_time = time.time()


logging.info('Time taken to process :'.format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)



