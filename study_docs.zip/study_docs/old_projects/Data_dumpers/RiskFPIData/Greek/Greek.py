# -*- coding: utf-8 -*-
"""
Created on Fri Jan 28 12:27:34 2022

@author: backup
"""
import smtplib
#from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

import sys
import logging
import pandas as pd
import datetime
import os

data_directory=r'\\172.17.9.22\Users2\RiskDataDownload\BAN_Automation'
file_dir="D:\\Data_dumpers\\RiskFPIData\\Greek\\"
master_dir = "D:\\Data_dumpers\\Master\\"
data_dir=r'\\172.17.9.22\Users2\RiskDataDownload'
user_dir=r'\\172.17.9.22\Users2\RiskDataDownload\BAN_Automation\User_files'

server = '172.17.9.144'; port = 25

contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'


logging.basicConfig(filename=file_dir+"greek.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
     
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)
             
def next_working_day(d):
    d = d + datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d + datetime.timedelta(days=1)
            else:
                return d         

user=pd.read_excel(os.path.join(user_dir,'user_list_greek.xlsx'))
print(user.head())
print(user['User id'])
new_user=user['User id'].dropna()


def get_stock_list(d) :
      
     d1=next_working_day(d.date())
     directory1=datetime.datetime.strftime(d1,"%d%m%Y")
     f="fo_secban_{}.csv".format(datetime.datetime.strftime(d1,"%d%m%Y"))
     p=os.path.join(data_dir,directory1,f)
     while True:  
        if os.path.exists(p):
            logging.info('file exists for {}'.format(d1))
            ban=pd.read_csv(p)  
            break
       
     print(ban.columns[0])
     x=ban[ban.columns[0]].tolist()
     return x

def Greek(x,d):
    d1=next_working_day(d.date())
    directory1=datetime.datetime.strftime(d1,"%d%m%Y")
    path1=os.path.join(data_directory,directory1)
    if not os.path.exists(path1):          
       os.mkdir(path1)
    l1=[]
    l2=[]
    for i in x:
       for j in new_user:
         l1.append(i)
         l2.append(j)
    print(l1)
    print(l2)
    
    result=pd.DataFrame(list(zip(l2,l1)),columns=["User id","Symbol"])
    
    col_values={'IsAllowed':1,'Action':'','Check':'','Rule_ID':'','Req Parent ID':'ADMIN','Exchange':'NSE','Segment':'DERIVATIVE',
            'Instrument/Series':'ALL','Expiry':'ALL','Option type':'ALL','Strike1':'ALL','Strike2':'ALL','Carry Forward expiry':'NO',
            'Security Exchange':'','Contract Type':'BOTH','GSM':'ALL','Square Off':'ALL','Match Future':'','Product Type':'ALL',
            'Expiry2':'ALL','AllowedBanned Type':'BANNED'}
    
    for x in col_values:
         result[x]=col_values[x]
   
    result=result[['IsAllowed','Action','Check','Rule_ID','Req Parent ID','User id','Exchange','Segment',
            'Instrument/Series','Symbol','Expiry','Option type','Strike1','Strike2','Carry Forward expiry',
            'Security Exchange','Contract Type','GSM','Square Off','Match Future','Product Type',
            'Expiry2','AllowedBanned Type']]


    result.to_csv(os.path.join(path1,'GREEK_COMBINED_BAN_UPLOAD_{}.csv'.format(datetime.datetime.strftime(d1,"%d%m%Y"))),index=False)
    email_utility(get_contacts(contacts_dir+'omnesys.txt'), 
                   'GREEK_COMBINED_BAN_UPLOAD_{}.csv'.format(datetime.datetime.strftime(d1,"%d%m%Y")))

    #email_utility(get_contacts(contacts_dir+'back.txt'), 
     #              'GREEK_COMBINED_BAN_UPLOAD_{}.csv'.format(datetime.datetime.strftime(d1,"%d%m%Y")), 
      #                'GREEK_COMBINED_BAN_UPLOAD_{}.csv'.format(datetime.datetime.strftime(d1,"%d%m%Y")) ) 
def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails


def email_utility(emails, subject):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
    message = "file have been updated on path \\\\172.17.9.22\\Users2\\RiskDataDownload\\BAN_Automation"
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    
    
    
   # attachment = open(data_dir+fname,'rb')
    '''
    print fname
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(file_dir+fname, "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
    msg.attach(part)   
    '''
                    
    
    msg.attach(MIMEText(message,'plain'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()


def main(nd):
    d=datetime.datetime.today()-datetime.timedelta(nd)
    if process_run_check(d.date())== -1:
        return -1  
    y= get_stock_list(d)
    if len(y)!=0:
        Greek(y,d)
    
main(nd=0)
















