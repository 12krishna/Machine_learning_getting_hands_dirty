# -*- coding: utf-8 -*-
"""
Created on Tue Jan 11 11:36:20 2022

@author: backup
"""
import smtplib
#from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

import requests 
import pandas as pd
import requests
import re
import os
from lxml import html
#!from selenium import webdriver
import time
import sys
import datetime
#from selenium.webdriver.common.keys import Keys
#import parse
#from urllib import urlopen
from bs4 import BeautifulSoup
from selenium import webdriver
import shutil
import numpy as np
import requests,os,re,datetime,shutil,logging

server = '172.17.9.144'; port = 25

contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
user_dir=r'\\172.17.9.22\Users2\RiskDataDownload\BAN_Automation\User_files'
data_dir=r'\\172.17.9.22\Users2\RiskDataDownload'
data_directory=r'\\172.17.9.22\Users2\RiskDataDownload\BAN_Automation'
file_dir="D:\\Data_dumpers\\RiskFPIData\\omnesys\\"
master_dir = "D:\\Data_dumpers\\Master\\"

logging.basicConfig(filename=file_dir+"omnesys.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
     
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)
             
def next_working_day(d):
    d = d + datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d + datetime.timedelta(days=1)
            else:
                return d         
def get_stock_list(d) :
     ''' to get a list of stocks from fo_secban file''' 
     d1=next_working_day(d.date())
     directory1=datetime.datetime.strftime(d1,"%d%m%Y")
     f="fo_secban_{}.csv".format(datetime.datetime.strftime(d1,"%d%m%Y"))
     p=os.path.join(data_dir,directory1,f)
     while True:  
        if os.path.exists(p):
            logging.info('{} file exists '.format(f))
            time.sleep(180)
            ban=pd.read_csv(p)  
            break
       
     print(ban.columns[0])
     x=ban[ban.columns[0]].tolist()
     return x
def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails 

def email_utility(emails, subject):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
  #  message = open(file_dir+body_file,'rb').read()
    message = " omnesys blocking unblocking files have been updated on the path \\\\172.17.9.22\Users2\RiskDataDownload\Ban_Automation"
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    
    
    
   # attachment = open(data_dir+fname,'rb')
    '''
    print fname
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(file_dir+fname, "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
    msg.attach(part)   
    '''
                    
    
    msg.attach(MIMEText(message,'plain'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def blocking_unblocking(x,d):
     ''' it creates text files using stock list x'''
     
     d1=next_working_day(d.date())
     directory1=datetime.datetime.strftime(d1,"%d%m%Y")
     path1=os.path.join(data_directory,directory1)
     if not os.path.exists(path1):          
       os.mkdir(path1)
     user=pd.read_excel(os.path.join(user_dir,"User List_omnesys.xlsx"))
     print(user.head())
     print(user.columns)
     user.fillna(" ",inplace=True)

     for k in user.columns:
        l1=[]
        for i in user[k]:
            for j in x:
               if i!=" ":
                 l1.append("||{}|||||ALL|nse_fo|{}|||||Y||||".format(i,j))   
        df=pd.DataFrame(l1,columns=["RMS Blocking/UnBlocking"])
        if "COLO" in k:
            p=k.split(" ")
            print(p)
            print(len(p))
            if len(p)==2:
               y=p[1]+"_"+p[0]
               print(y)
               df.to_csv(os.path.join(path1,"BanScrips_{}_Blocking_{}.csv".format(y,datetime.datetime.strftime(d1,"%d%m%Y"))),index=False)
            else: 
                y=p[1]+"_"+p[0]+"2"
                print(y)
                df.to_csv(os.path.join(path1,"BanScrips_{}_Blocking_{}.csv".format(y,datetime.datetime.strftime(d1,"%d%m%Y"))),index=False)
        else:    
            df.to_csv(os.path.join(path1,"BanScrips_{}_Blocking_{}.csv".format(k,datetime.datetime.strftime(d1,"%d%m%Y"))),index=False)
        
 #       email_utility(get_contacts(contacts_dir+'back.txt'), 
 #                  "BanScrips_{}_Blocking_{}.txt".format(k,datetime.datetime.strftime(d1,"%d%m%Y")), 
 #                     "BanScrips_{}_Blocking_{}.txt".format(k,datetime.datetime.strftime(d1,"%d%m%Y"))) 

     for k in user.columns:
       l1=[]
       for i in user[k]:
           for j in x:
             if i!=" ":
               l1.append("||{}|||||ALL|nse_fo|{}|||||N||||".format(i,j))   
       df=pd.DataFrame(l1,columns=["RMS Blocking/UnBlocking"])
       if "COLO" in k:
            p=k.split(" ")
            print(p)
            print(len(p))
            if len(p)==2:
               y=p[1]+"_"+p[0]
               print(y)
               df.to_csv(os.path.join(path1,"BanScrips_{}_Unblocking_{}.csv".format(y,datetime.datetime.strftime(d1,"%d%m%Y"))),index=False)
            else: 
                y=p[1]+"_"+p[0]+"2"
                print(y)
                df.to_csv(os.path.join(path1,"BanScrips_{}_Unblocking_{}.csv".format(y,datetime.datetime.strftime(d1,"%d%m%Y"))),index=False)
       else:       
        df.to_csv(os.path.join(path1,"BanScrips_{}_Unblocking_{}.csv".format(k,datetime.datetime.strftime(d1,"%d%m%Y"))),index=False)
       
#       email_utility(get_contacts(contacts_dir+'back.txt'), 
#                   "BanScrips_{}_Unblocking_{}.txt".format(k,datetime.datetime.strftime(d1,"%d%m%Y")), 
#                      "BanScrips_{}_Unblocking_{}.txt".format(k,datetime.datetime.strftime(d1,"%d%m%Y"))) 
       
       
def main(nd):
    d=datetime.datetime.today()-datetime.timedelta(nd)
    d1=next_working_day(d.date())
    if process_run_check(d.date())== -1:
        return -1  
    y= get_stock_list(d)
    if len(y)!=0:       # if there are stocks in fo_secban file
        logging.info('some stocks are there for {} hence generating files'.format(d1))
        blocking_unblocking(y,d)
        email_utility(get_contacts(contacts_dir+'omnesys.txt'), 
                   "Omnesys BAN Files For {}".format(datetime.datetime.strftime(d1,"%d%m%Y")))
main(nd=0) 


