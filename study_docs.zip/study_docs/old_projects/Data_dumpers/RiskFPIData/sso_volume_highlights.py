# -*- coding: utf-8 -*-
"""
Created on Mon Feb  8 16:39:44 2021

@author: krishna
"""

import numpy as np
import pandas as pd
import sys, os, shutil
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from collections import OrderedDict

server = '172.17.9.149'; port = 25  # mailing server
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'


master_dir ="D:\\Master\\"
output_dir = os.getcwd()+"\\Output\\"
contacts_dir = "D:\\Emails\\Contacts\\"

sso_columns= {'Total Call Sum VOLUME':'Total Call Sum <br> VOLUME', 'Total Put sum VOLUME':'Total Put sum <br> VOLUME',
              'TOTAL (C+P)':'TOTAL <br> (C+P)', 'Total Call Sum(20DAvg)':'Total Call <br> Sum(20DAvg)', 
              'Total Put sum(20DAvg)':'Total Put <br> sum(20DAvg)','TOTAL (C+P)(20DAvg)':'TOTAL(C+P) <br> (20DAvg)',
              'Call Ratio (today/20D avg)':'Call Ratio <br> (T/20D avg)','Put Ratio (today/20D avg)':'Put Ratio <br> (T/20D avg)',
              'Total Ratio (today/20D avg)':'Total Ratio <br> (T/20D avg)' }


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails


def email_utility(emails, subject, filename ):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
    message = open(filename,'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
              
    '''       
    # add all attachments 
    for fname in attachments:
        print fname 
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(output_dir+fname, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
        msg.attach(part)   
     '''
    
    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()


def color_format_table(tables, d):
    
    
    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>       
    html_string = "<html><head><style>{css_style}</style></head><body>\
                    <p>{msg_string}</p>".format(css_style = open("df_style.css", 'r').read(), 
                                                msg_string="SSO Volume highlights for {}".format(d))
                    
    # OUTPUT AN HTML FILE
    output_file = open(output_dir+"sso_volumes.html", 'w')
    output_file.write(html_string)
    output_file.write("<br>")
    
    for key, table in tables.iteritems() :
        
        output_file.write("Stocks with Volumes {} than 20 days average volumes <br>".format(key))
        table.iloc[:, table.columns.str.contains("Ratio")] = table.iloc[:, table.columns.str.contains("Ratio")].round(2)
        table.iloc[:, 1:7] = table.iloc[:, 1:7].astype(int)
       
        table['Symbol'] = "text"+table['Symbol']  # hack to align text
        table.iloc[:, ~table.columns.str.contains("Symbol")] = table.iloc[:, ~table.columns.str.contains("Symbol")].applymap(lambda col: "num"+str(col) ) # hack to aligh numbers 
        table.rename(columns=sso_columns, inplace=True)
        table = table.to_html(classes='mystyle', index=False).replace(
                '<table border="1" class="dataframe mystyle">',
                '<table border="1" class="mystyle"> ')
        
        output_file.write(table)
        output_file.write("<br><br>")
        
        
        
    output_file.write("</body></html>")    
    output_file.close()    
    
    output_file = open(output_dir+"sso_volumes.html", 'r').read().replace("&lt;","<").replace("&gt;",">")
    output_file = output_file.replace("dataframe mystyle","mystyle")
    output_file = output_file.replace('<td>text','<td class="text">')    
    output_file = output_file.replace('<td>num','<td class="num">')
    
    with open(output_dir+"sso_volumes.html", 'w') as f:
        f.write(output_file)
        
        
"""
def sso_volume_trends(df, d):
    '''Func to get top 10 and bottom 10 stocks 
    as per total ce pe volume avg 20 days
    '''
    tables=OrderedDict()
    top10 = df[df['Total Ratio (today/20D avg)']>=2]
    top10.sort_values(by=['Total Ratio (today/20D avg)'], ascending=False, inplace=True)
    top10=top10.head(10)
    tables['Higher'] = top10
    
    bottom10 = df[df['Total Ratio (today/20D avg)']<=0.5]
    bottom10.sort_values(by=['Total Ratio (today/20D avg)'], ascending=True, inplace=True)
    bottom10=bottom10.head(10)
    tables['Lower'] = bottom10
    
    # fromat table in html and send email alert
    color_format_table(tables, d)
    email_utility(get_contacts(contacts_dir+"sso_volume_highlights.txt"), 
                  "SSO Volume Highlights", 
                  output_dir+"sso_volumes.html")

"""

def sso_volume_trends(df, d):
    '''Func to get top 10 and bottom 10 stocks 
    as per total ce pe volume avg 20 days
    '''
    tables=OrderedDict()
    df.sort_values(by=['Total Ratio (today/20D avg)'], ascending=False, inplace=True)
    
    top10 = df.head(10)
    #top10.sort_values(by=['Total Ratio (today/20D avg)'], ascending=False, inplace=True)
    #top10=top10.head(10)
    tables['Higher'] = top10
    
    bottom10 = df.tail(10)
    bottom10.sort_values(by=['Total Ratio (today/20D avg)'], ascending=True, inplace=True)
    #bottom10=bottom10.head(10)
    tables['Lower'] = bottom10
    
    # fromat table in html and send email alert
    color_format_table(tables, d)
    email_utility(get_contacts(contacts_dir+"sso_volume_highlights.txt"), 
                  "SSO Volume Highlights", 
                  output_dir+"sso_volumes.html")
    
