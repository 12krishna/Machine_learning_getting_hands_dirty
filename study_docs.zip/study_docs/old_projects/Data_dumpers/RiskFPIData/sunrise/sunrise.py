# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 17:53:57 2022

@author: backup
"""
import smtplib
#from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

import requests 
import pandas as pd
import requests
import re
import os
from lxml import html
#!from selenium import webdriver
import time
import sys
import datetime
#from selenium.webdriver.common.keys import Keys
#import parse
#from urllib import urlopen
from bs4 import BeautifulSoup
from selenium import webdriver
import shutil
import numpy as np
import requests,os,re,datetime,shutil,logging

server = '172.17.9.144'; port = 25

contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
user_dir=r'\\172.17.9.22\Users2\RiskDataDownload\BAN_Automation\User_files'
data_dir=r'\\172.17.9.22\Users2\RiskDataDownload'
data_directory=r'\\172.17.9.22\Users2\RiskDataDownload\BAN_Automation'
file_dir="D:\\Data_dumpers\\RiskFPIData\\sunrise\\"
master_dir = "D:\\Data_dumpers\\Master\\"

logging.basicConfig(filename=file_dir+"sunrise.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
     
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)
             
def next_working_day(d):
    d = d + datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d + datetime.timedelta(days=1)
            else:
                return d         
def get_stock_list(d) :
     ''' to get a list of stocks from fo_secban file''' 
     d1=next_working_day(d.date())
     directory1=datetime.datetime.strftime(d1,"%d%m%Y")
     f="fo_secban_{}.csv".format(datetime.datetime.strftime(d1,"%d%m%Y"))
     p=os.path.join(data_dir,directory1,f)
     while True:  
        if os.path.exists(p):
             print("file downloaded")
            logging.info('{} file exists '.format(f))
            time.sleep(180)
            ban=pd.read_csv(p)  
            break
        print("file not downloaded ,sleep for 2 minutes")
        time.sleep(120
     print(ban.columns[0])
     x=ban[ban.columns[0]].tolist()
     return x
def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails 

def email_utility(emails, subject):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
  #  message = open(file_dir+body_file,'rb').read()
    message = 'Sunrise blocking unblocking files have been updated on the path \\\\172.17.9.22\\Users2\\RiskDataDownload\\Ban_Automation'
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    
    
    
   # attachment = open(data_dir+fname,'rb')
    '''
    print fname
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(file_dir+fname, "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
    msg.attach(part)   
    '''
                    
    
    msg.attach(MIMEText(message,'plain'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def blocking_unblocking(x,d):
     ''' it creates text files using stock list x'''
     
     d1=next_working_day(d.date())
     directory1=datetime.datetime.strftime(d1,"%d%m%Y")
     path1=os.path.join(data_directory,directory1)
     if not os.path.exists(path1):          
       os.mkdir(path1)
     user=pd.read_excel(os.path.join(user_dir,"User_Family_List_sunrise.xlsx"))
     print(user.head())
     print(user.columns)
     user.fillna(" ",inplace=True)
     
     l1=[]
     for j in x:
            for i in user[user.columns[0]]:
                 l1.append([j,i])   
     df=pd.DataFrame(l1,columns=["Symbol","Template Name"])
     df1=pd.DataFrame(l1,columns=["Symbol","Template Name"])
     col_values={'Op Code':1,'Segment':2,'Instrument Type':'ALL','Series':'ALL','Expiry Date':'ALL',
                 'Strike Price':'ALL','Option Type':'ALL','Exchange Restricted':'YES','Broker Restricted':'NO','Order Side':'BOTH','Filler':'$'}
     for c in col_values:
         df[c]=col_values[c]
     df=df[['Op Code','Template Name','Segment','Instrument Type','Symbol','Series','Expiry Date','Strike Price','Option Type','Exchange Restricted','Broker Restricted','Order Side','Filler']]    
     df.to_csv(os.path.join(path1,"Blocking_BanScrip_Template_NSEDERV_{}.csv".format(datetime.datetime.strftime(d1,"%d%m%Y"))),index=False)
     
     col_values1={'Op Code':3,'Segment':2,'Instrument Type':'ALL','Series':'ALL','Expiry Date':'ALL',
                 'Strike Price':'ALL','Option Type':'ALL','Exchange Restricted':'YES','Broker Restricted':'NO','Order Side':'BOTH','Filler':'$'}
     for c in col_values1:
         df1[c]=col_values1[c]
     df1=df1[['Op Code','Template Name','Segment','Instrument Type','Symbol','Series','Expiry Date','Strike Price','Option Type','Exchange Restricted','Broker Restricted','Order Side','Filler']]    
     df1.to_csv(os.path.join(path1,"UnBlocking_BanScrip_Template_NSEDERV_{}.csv".format(datetime.datetime.strftime(d1,"%d%m%Y"))),index=False)
     
    
def main(nd):
    d=datetime.datetime.today()-datetime.timedelta(nd)
    d1=next_working_day(d.date())
    if process_run_check(d.date())== -1:
        return -1  
    y= get_stock_list(d)
    if len(y)!=0:       # if there are stocks in fo_secban file
        logging.info('some stocks are there for {} hence generating files'.format(d1))
        blocking_unblocking(y,d)
        email_utility(get_contacts(contacts_dir+'omnesys.txt'), #'omnesys.txt'
                   "Sunrise BAN Files For {}".format(datetime.datetime.strftime(d1,"%d%m%Y")))
main(nd=0) 


