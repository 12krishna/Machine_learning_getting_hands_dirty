# -*- coding: utf-8 -*-
"""
Created on Wed Aug 24 16:32:09 2022

@author: backup
"""

import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import numpy as np
import requests 
import pandas as pd
import requests
import re
import os
from lxml import html
#!from selenium import webdriver
import time
import sys
#from selenium.webdriver.common.keys import Keys
#import parse
#from urllib import urlopen
from bs4 import BeautifulSoup
from selenium import webdriver
import shutil
import numpy as np
import requests,os,re,datetime,shutil,logging
import threading

server = '172.17.9.144'; port = 25

contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'

log_path='C:\\Users\\backup\\New folder\\' 
data_dir="D:\\Data_dumpers\\RiskFPIData\\"
master_dir = "D:\\Data_dumpers\\Master\\"
#output_filepath = r'\\172.17.9.22\\Users2\\RiskDataDownload\\FPI_Red_Flag_Breach_List.xlsx'
output_filepath1 = r'\\172.17.9.22\\Users2\\RiskDataDownload\\fo_mktlot.csv'
_url_redflag = "https://www.fpi.nsdl.co.in/web/Reports/frmRedFlagList.aspx"
_url_thresholdlist = "https://www.fpi.nsdl.co.in/web/Reports/frmThresholdlist.aspx"

logging.basicConfig(filename=log_path+"riskftp.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def combine_html_excel(emails,subject):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
#    message = open("output.txt",'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    msg.attach(MIMEText('the file have been updated on \\172.17.9.22\\Users2\\RiskDataDownload','plain'))    
    # add all attachments 

#    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)

def email_utility(emails, subject, filename,fname ):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
    message = open(data_dir+filename,'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    
    attachment = open(data_dir+fname,'rb')
    print(fname)
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(data_dir+fname, "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
    msg.attach(part)   
    
                    
    
    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def color_format_table(table,d1):
    
    
    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>       
    html_string = "<html><head><style>{css_style}</style></head><body>\
                    <p>{msg_string}</p>".format(css_style = open(data_dir+"df_style.css", 'r').read(), 
                                                msg_string="Aggregate FPI Investment Limit By NSDL,{}".format(d1))
                    
    # OUTPUT AN HTML FILE
    output_file = open(data_dir+"data.html", 'w')
    output_file.write(html_string)
    output_file.write("<br>")
    
   # output_file.write("Stocks with Volumes  than 20 days average volumes <br>")
    
       
    #table['Sr. No.'] = "text"+table['Sr. No.']  # hack to align text
   # table.iloc[:, ~table.columns.str.contains("Sr. No.")] = table.iloc[:, ~table.columns.str.contains("Symbol")].applymap(lambda col: "num"+str(col) ) # hack to aligh numbers 
    
    table = table.to_html(classes='mystyle', index=False).replace(
                '<table border="1" class="dataframe mystyle">',
                '<table border="1" class="mystyle"> ')
        
    output_file.write(table)
    output_file.write("<br><br>")
    
        
        
    output_file.write("</body></html>")    
    output_file.close()    
    output_file = open(data_dir+"data.html", 'r').read().replace("&lt;","<").replace("&gt;",">")
    output_file = output_file.replace("dataframe mystyle","mystyle")
    output_file = output_file.replace('<td>text','<td class="text">')    
    output_file = output_file.replace('<td>num','<td class="num">')
    
    with open(data_dir+"data.html", 'w') as f:
        f.write(output_file)    

def red_flag():
    
       driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))        
       driver.get(_url_redflag)
       time.sleep(10)
       
       
       soup = BeautifulSoup(driver.page_source, 'lxml')
       #tables = soup.findAll("table")
       #dfs = pd.read_html("https://www.fpi.nsdl.co.in/web/Reports/frmRedFlagList.aspx")
       dfs = pd.read_html(driver.page_source)
       driver.close()
       print(dfs)
       p=dfs[0]
       text=p[0].tolist()
       t=text[0].split(" ")
       date=t[2:7]
       for i in range(len(date)):
           if date[i]=='LIST(Dissemination':
               date[i]='(Dissemination'
       print(date)
       d1=" ".join(date)
       first=dfs[1]
       second=dfs[2]
      
       
       first=first.drop(first.columns[[3,4,7]],axis=1)
       over=list(first.columns.levels[0])[0]
       first.columns=["Sr. No.","Scrip Name","ISIN","Current Level(%)","Investment Limit(%)","Date when Red Flag was Activated","Listed on Stock Exchange"]
       f = pd.DataFrame([[np.nan] * len(first.columns)], columns=first.columns) #  adding an empty row
       first = f.append(first, ignore_index=True)
       first=first.fillna("")
       first.iloc[0,2]=over
       
       
       second=second.drop(second.columns[[3,4,7]],axis=1)
       agg=list(second.columns.levels[0])[0]
       nodata=list(second.columns.levels[2])[0]
       second.columns=["Sr. No.","Scrip Name","ISIN","Current Level(%)","Investment Limit(%)","Date when Red Flag was Activated","Listed on Stock Exchange"]
       second=second.reindex(list(range(0, 2))).reset_index(drop=True) # adding two empty rows
       second=second.fillna("")
       second.iloc[0,2]=agg
       second.iloc[1,0]=nodata
       
       first=first.append(second)
       first.insert(1, "Category", "Red Flag")
       first.iloc[0,1]=''       
       driver1 = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))        
       driver1.get(_url_thresholdlist)
       time.sleep(10)

       #soup = BeautifulSoup(driver1.page_source, 'lxml')
       #tables = soup.findAll("table")
       #dfs = pd.read_html("https://www.fpi.nsdl.co.in/web/Reports/frmRedFlagList.aspx")
       bds = pd.read_html(driver1.page_source)
       driver1.close()
       
       breach_first=bds[1]
       over=list(breach_first.columns.levels[0])[0]
       breach_second=bds[2]
       breach_first=breach_first.drop(breach_first.columns[[3,4]],axis=1)
       breach_first.columns=columns=["Sr. No.","Scrip Name","ISIN","Date when Red Flag was Activated","Listed on Stock Exchange"]
       b = pd.DataFrame([[np.nan] * len(breach_first.columns)], columns=breach_first.columns) #  adding an empty row
       breach_first = b.append(breach_first, ignore_index=True)
       breach_first=breach_first.fillna("")
       breach_first.iloc[0,2]=over
       
     
       
      
       breach_second=breach_second.drop(breach_second.columns[[3,4,7]],axis=1)
       agg=list(breach_second.columns.levels[0])[0]
       nodata=list(breach_second.columns.levels[2])[0]
     
       breach_second.columns=["Sr. No.","Scrip Name","ISIN","Date when Red Flag was Activated","Listed on Stock Exchange"]
       breach_second=breach_second.reindex(list(range(0, 2))).reset_index(drop=True) # adding two empty rows
       breach_second=breach_second.fillna("")
       breach_second.iloc[0,2]=agg
       breach_second.iloc[1,0]=nodata
       breach_first=breach_first.append(breach_second)
       breach_first["Current Level(%)"]=""
       breach_first["Investment Limit(%)"]=""
       breach_first.insert(1, "Category","Breached")
       breach_first.iloc[0,1]=''
       
       breach_first=breach_first[["Sr. No.","Category","Scrip Name","ISIN","Current Level(%)","Investment Limit(%)","Date when Red Flag was Activated","Listed on Stock Exchange"]]
     
       final_data=pd.DataFrame()
       for x in [first,breach_first]:
           final_data=final_data.append(x)
        
       final_data["In/Out"]="" 
       final_data.to_excel(data_dir+"FPI_Red_Flag_Breach_List.xlsx",index=False) 
       
       color_format_table(final_data,d1)
       email_utility(get_contacts(contacts_dir+'Risk_fpi_data.txt'), 
                  "Red_flag_breach_list", 
                  "data.html","FPI_Red_Flag_Breach_List.xlsx")

def market_lot():
    url="https://archives.nseindia.com/content/fo/fo_mktlots.csv"
    x=requests.get(url)
    print(x.status_code)
    #print(x.content)
    open(output_filepath1, 'wb').write(x.content)
    
    emails = get_contacts(contacts_dir+'Risk_fpi_data.txt') # read contacts'Risk_fpi_data.txt'
    subject = "Market_lot_size"
        
    combine_html_excel(emails,subject)
       
       
      
def main(nd):
    d = datetime.datetime.now()-datetime.timedelta(nd)
    
    if process_run_check(d.date())== -1:
        return -1
    
    t1=threading.Thread(target=red_flag)
    t2=threading.Thread(target=market_lot) 
    t1.start()
    t2.start()
    t1.join()
    t2.join()

main(nd=0)        

