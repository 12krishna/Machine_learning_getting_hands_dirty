# -*- coding: utf-8 -*-
"""
Created on Thu Jan 20 13:16:40 2022

@author: backup
"""
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


import logging
import pandas as pd
#from tabulate import tabulate
import re,os,datetime,time,sys
import pysftp
import socks
import socket
from ftplib import FTP


file_dir="D:\\Data_dumpers\\RiskFPIData\\qty_freeze\\"
data_dir=r'\\172.17.9.22\Users2\RiskDataDownload'
master_dir = "D:\\Data_dumpers\\Master\\"
server = '172.17.9.144'; port = 25

contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'


logging.basicConfig(filename=file_dir+"qty_freeze.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
     
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)
             
def next_working_day(d):
    d = d + datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d + datetime.timedelta(days=1)
            else:
                return d  
            

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def email_utility(emails, subject, body_file,fname,nd):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
    message = open(file_dir+body_file,'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    
    d = datetime.datetime.now()-datetime.timedelta(nd)
    d1=next_working_day(d.date())
    directory1=datetime.datetime.strftime(d1,"%d%m%Y")
    
    
   # attachment = open(data_dir+fname,'rb')
    print fname
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(os.path.join(data_dir,directory1,fname), "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
    msg.attach(part)   
    
                    
    
    msg.attach(MIMEText(message,'plain'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()


def main(nd):
   d = datetime.datetime.now()-datetime.timedelta(nd)
    
   if process_run_check(d.date())== -1:
        return -1    
   d1=next_working_day(d.date())
   directory1=datetime.datetime.strftime(d1,"%d%m%Y")
   f="qty_freeze_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y"))
   p=os.path.join(data_dir,directory1)
   while True:
       if os.path.exists(os.path.join(p,f)): 
          logging.info('qty freeze file exists for date :{} '.format(d))
          time.sleep(10) 
          email_utility(get_contacts(contacts_dir+'qty_freeze.txt'), 
                     "NSE CM Qty Freeze File for {}".format(datetime.datetime.strftime(d1,"%d %b %Y").upper()), 
                       "qty_freeze_msg.txt",f,nd)
          break
      
main(nd=0)



