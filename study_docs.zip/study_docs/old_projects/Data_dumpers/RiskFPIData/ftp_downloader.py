# -*- coding: utf-8 -*-
"""
Created on Tue Jan  4 14:43:53 2022

@author: backup
"""
import logging
import pandas as pd
#from tabulate import tabulate
import re,os,datetime,time,sys
import pysftp
#import socks
#import socket
from ftplib import FTP
import threading
os.chdir('/home/hadoop/bo_ftp_downloader')
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None  
import Email_notifications

if sys.platform not in ('win32', 'cygwin', 'cli'):
    # linux env paths
    password_filepath = "/CMFOReport/scripts/"
    data_dir = '/BackOfficeDataDownload/'
    master_dir = "/home/hadoop/tca_project/master_files/"
    log_path = '/home/hadoop/bo_ftp_downloader/logs/'
else:
    # windows env paths
    os.chdir("C:\\Users\\backup\\")
    password_filepath = "C:\\Users\\backup\\New folder\\"
    master_dir = "D:\\Data_dumpers\\Master\\"
    log_path='C:\\Users\\backup\\'
    data_dir=r'\\172.17.9.22\Users2\BackOfficeDataDownload'  


_user_id = "08081"
_password = ""
_hostname = 'ftp.connect2nse.com'    
lines=open(os.path.join(password_filepath, "nsepwd.txt"),"r").readlines()
uname=_user_id
pword=lines[0].strip().split("=")[-1]
print uname, pword

'''
socks.set_default_proxy(socks.HTTP, 
                            "172.17.9.170", 8080,
                            username="geetav",  # use your username  krishnay
                            password="Pass@222"  # passowrd that you use for login to kotak system
                            )       
socket.socket = socks.socksocket
'''

logging.basicConfig(filename=log_path+"ftp.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")     
     
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
     
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)

                      
def ftp_proxy_downloader(path,filename):
    
    while True:
         ftp = FTP(_hostname)
         ftp.set_debuglevel(1) 
         ftp.login(
             user=_user_id,
             passwd=pword
               )       
         print ftp.pwd() # to check what is present working directory       
         ftp.cwd(path) 
         newf=ftp.nlst()
        # print(newf)
        # ftp.close()
        
         if filename in newf: 
                    try:
                       ftp.retrbinary("RETR " + filename, 
                               open(os.path.join(data_dir,filename), 'wb').write)    
                       ftp.close()  # dont forgpt to close the ftp connection after downloading all the files
                       break                                                    # handle all excpetions and errors and then close ftp connection
                    except Exception as e:
                              print("Error downloading {} file Error code : {}".format(filename, e))
                              logging.info("Error downloading {} file Error code : {}".format(filename, e))
         time.sleep(300)  
    #os.system("C:\\Users\\backup\\Desktop\\debug\\Email_notifications.bat {} {}".format('"{}"'.format(filename),
    #          '"Files have been updated on mentioned path: \\172.17.9.22\Users2\BackOfficeDataDownload"'))   
    Email_notifications.email_utility("{}".format(filename), 
        "Files have been updated on mentioned path: \\172.17.9.22\Users2\BackOfficeDataDownload")         
                
def ftp_proxy_downloader1(path,c,query):
    x=True
    while x:
         ftp = FTP(_hostname)
         ftp.set_debuglevel(1) 
         ftp.login(
             user=_user_id,
             passwd=pword
               )       
         print ftp.pwd() # to check what is present working directory       
         ftp.cwd(path)
 
         newf=ftp.nlst(query)
         #print(newf)
         #ftp.close()
         for f in newf: 
             if c in f:
                             
                 try:
                       ftp.retrbinary("RETR " + f, 
                               open(os.path.join(data_dir,f), 'wb').write)    
                       ftp.close()# dont forgpt to close the ftp connection after downloading all the files
                       x=False
                       break
                                                    # handle all excpetions and errors and then close ftp connection
                 except Exception as e:
                              print("Error downloading {} file Error code : {}".format(f, e))
                              logging.info("Error downloading {} file Error code : {}".format(f, e))
         time.sleep(300)               
       
    #os.system("C:\\Users\\backup\\Desktop\\debug\\Email_notifications.bat {} {}".format('"{}"'.format(f),
    #          '"Files have been updated on mentioned path: \\172.17.9.22\Users2\BackOfficeDataDownload"'))  
    Email_notifications.email_utility("{}".format(f), 
        "Files have been updated on mentioned path: \\172.17.9.22\Users2\BackOfficeDataDownload")         
    


def run_fun_at9(d):
    while True:
            if datetime.datetime.now().time() > datetime.time(9,0):                            
                 t1=threading.Thread(target=ftp_proxy_downloader,args=("/common/clearing","BSE_Scrip_Series_Mapping_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")),)) 
                 t2=threading.Thread(target=ftp_proxy_downloader,args=("/common/clearing","C_STT_IND_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")),)) 
                 t3=threading.Thread(target=ftp_proxy_downloader,args=("/common/clearing","C_STT_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")),))  
                 t4=threading.Thread(target=ftp_proxy_downloader,args=("/common/cmmkt","bulk{}.xls".format(datetime.datetime.strftime(d,"%d%m%Y")),))
                 t5=threading.Thread(target=ftp_proxy_downloader,args=("/common/ntneat","nnf_security.gz_{}".format(datetime.datetime.strftime(d,"%d%b%Y").upper()),))
                 t6=threading.Thread(target=ftp_proxy_downloader,args=("/common/C2N","security.gz",))
                 t7=threading.Thread(target=ftp_proxy_downloader,args=("/common/C2N","participant.gz",))
                 t8=threading.Thread(target=ftp_proxy_downloader1,args=("/common/clearing",datetime.datetime.strftime(d,"%b%Y").upper(),"C_STC_*",))
                 t1.start()
                 t2.start()
                 t3.start()
                 t4.start()
                 t5.start()
                 t6.start()
                 t7.start()
                 t8.start()
                 t1.join()
                 t2.join()
                 t3.join()
                 t4.join()
                 t5.join()
                 t6.join()
                 t7.join()
                 t8.join()
                 break
                 
def run_fun_at1(d):
    while True:
            if datetime.datetime.now().time() > datetime.time(13,0): 
                  t1=threading.Thread(target=ftp_proxy_downloader1,args=("/08081/Reports",datetime.datetime.strftime(d,"%d%m%Y"),"C_08081_T_FOBG_N*.csv.gz",))
                  t2=threading.Thread(target=ftp_proxy_downloader1,args=("/08081/Reports",datetime.datetime.strftime(d,"%d%m%Y"),"C_08081_T_FOBG_W*.csv.gz",))
                  t1.start()
                  t2.start()
                  t1.join()
                  t2.join()
                  break
    
def run_fun_at5(d):
    while True:
        if datetime.datetime.now().time() > datetime.time(17,0): 
             t1=threading.Thread(target=ftp_proxy_downloader,args=("/common/ntneat","security.gz",))              
             t2=threading.Thread(target=ftp_proxy_downloader,args=("/common/ntneat","participant.gz",)) 
             t3=threading.Thread(target=ftp_proxy_downloader,args=("/08081/PTA/Dnld","08081_C_PTA_{}_S01.csv.gz".format(datetime.datetime.strftime(d,"%d%m%Y")),) ) 
             t4=threading.Thread(target=ftp_proxy_downloader,args=("/08081/CEP/Dnld","08081_CLNTEPI_{}.S01".format(datetime.datetime.strftime(d,"%Y%m%d")),) )
             t1.start()
             t2.start()
             t3.start()
             t4.start()
             t1.join()
             t2.join()
             t3.join()
             t4.join()
             break
def run_fun_at6(d):
    while True:
        if datetime.datetime.now().time() > datetime.time(18,0):
             ftp_proxy_downloader("/08081/onlinebackup","{}_08081.txt.gz".format(datetime.datetime.strftime(d,"%d%m%Y")))
             break 
def run_fun_at7(d):  
    while True:
        if datetime.datetime.now().time() > datetime.time(19,0):
             t1=threading.Thread(target=ftp_proxy_downloader,args=("/08081/NSP","08081_T_NSP_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")),)) 
             t2=threading.Thread(target=ftp_proxy_downloader,args=("/08081/NSP","08081_NSP_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")),)) 
             t1.start()
             t2.start()
             t1.join()
             t2.join()
             break
def run_fun_at21(d):
    while True:
        if  datetime.datetime.now().time() > datetime.time(21,0):
             t1=threading.Thread(target=ftp_proxy_downloader,args=("/08081/Reports","MWST_08081_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")),))                        
             t2=threading.Thread(target=ftp_proxy_downloader,args=("/08081/Reports","C_SD01_08081_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")),))
             t1.start()
             t2.start()
             t1.join()
             t2.join()
             break
def run_fun_at20(d):
    while True:
        today_date=datetime.datetime.now().date()
        if today_date.day >20:
            ftp_proxy_downloader1("/08081/Accounts/Nsccl",datetime.datetime.strftime(d,"%Y%m%d"),"08081_NSCCLSEG*.pdf")
            break
def run_fun_at10(d): 
   while True: 
     if datetime.datetime.now().time() > datetime.time(22,0):
        ftp_proxy_downloader1("/08081/Reports",datetime.datetime.strftime(d,"%d%m%Y"),"C_08081_PTA_NONREPORTING*.csv")       
        break
     
def main(nd):
    
    
    d=datetime.datetime.today()-datetime.timedelta(nd)
    if process_run_check(d.date())== -1:
        return -1
    t1=threading.Thread(target=run_fun_at9,args=(d,))
    t2=threading.Thread(target=run_fun_at1,args=(d,))
    t3=threading.Thread(target=run_fun_at5,args=(d,))
    t4=threading.Thread(target=run_fun_at6,args=(d,))
    t5=threading.Thread(target=run_fun_at7,args=(d,))
    t6=threading.Thread(target=run_fun_at21,args=(d,))
    t7=threading.Thread(target=run_fun_at20,args=(d,))
    t8=threading.Thread(target=run_fun_at10,args=(d,))
    t1.start()
    t2.start()
    t3.start()
    t4.start()
    t5.start()
    t6.start()
    t7.start()
    t8.start()
    t1.join()
    t2.join()
    t3.join()
    t4.join()
    t5.join()              
    t6.join()
    t7.join()
    t8.join()
         
main(nd=0)


