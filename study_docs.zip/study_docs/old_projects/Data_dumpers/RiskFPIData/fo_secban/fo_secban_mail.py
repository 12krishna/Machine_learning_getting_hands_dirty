# -*- coding: utf-8 -*-
"""
Created on Fri Jan 28 17:16:52 2022

@author: backup
"""
import datetime
#import time
import os
import pandas as pd
import smtplib
#from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
#from email.mime.base import MIMEBase
#from email import encoders
import logging
import sys

server = '172.17.9.144'; port = 25
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
file_dir="D:\\Data_dumpers\\RiskFPIData\\fo_secban\\"
contacts_dir = "D:\\Emails\\Contacts\\"
master_dir = "D:\\Data_dumpers\\Master\\"
data_dir=r'\\172.17.9.22\Users2\RiskDataDownload'

logging.basicConfig(filename=file_dir+"fo_secban.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def email_utility(emails, subject, body_file):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
    message = open(file_dir+body_file,'r').read()

    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject


    
    msg.attach(MIMEText(message,'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
     
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)

def next_working_day(d):
    d = d + datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d + datetime.timedelta(days=1)
            else:
                return d  
            
def get_stock_list(d) :
     ''' it adds the stocks from fo_secban file to fo_secban_attach.txt and sends it as mail body message''' 
     d1=next_working_day(d.date())
     directory1=datetime.datetime.strftime(d1,"%d%m%Y")
     f="fo_secban_{}.csv".format(datetime.datetime.strftime(d1,"%d%m%Y"))
     p=os.path.join(data_dir,directory1,f)
     while True:  
        if os.path.exists(p):
            logging.info('file exists for {}'.format(d1))
            h=pd.read_csv(p)
            h.to_csv(file_dir+"fo_secban.tsv", sep='\t')  #index=False
            filenames=[file_dir+'fo_secban_msg.txt',file_dir+"fo_secban.tsv"] #os.path.join(data_dir,directory1,f)
            with open(file_dir+'fo_secban_attach.txt','w') as outfile:   #this will create fo_secban_attach.txt file by combining fo_secban.csv and fo_secban_msg.txt
                for fname in filenames:
                  with open(fname) as infile:
                    outfile.write("\n")
                    outfile.write(infile.read())
                    
            break
     email_utility(get_contacts(contacts_dir+'fo_secban_mail.txt'),
              'Securities in Ban For Trade Date {}:-F&O segment'.format(datetime.datetime.strftime(d1,"%d-%b-%Y").upper()),
              'fo_secban_attach.txt')

'''
filenames=[file_dir+'fo_secban_msg.txt',os.path.join(data_dir,'fo_secban_21012022.csv')]
with open(file_dir+'fo_secban_attach.txt','w') as outfile:
    for fname in filenames:
        with open(fname) as infile:
            outfile.write("\n")
            outfile.write(infile.read())
'''


def main(nd):
    d=datetime.datetime.today()-datetime.timedelta(nd)
    if process_run_check(d.date())== -1:
        return -1  
    get_stock_list(d)
    

main(nd=0)


