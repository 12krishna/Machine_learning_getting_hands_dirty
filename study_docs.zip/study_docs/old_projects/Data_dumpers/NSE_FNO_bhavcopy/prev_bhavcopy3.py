# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 10:08:59 2019
@author: krishna
"""

import pandas as pd, datetime, os, redis, time
import io
import pyarrow as pa
redis_host = "10.223.104.86"
proccessed_dir = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\Processed_folder\\"
master_dir = "D:\\Master\\"

def previous_working_day(d, holiday_master):
    '''Get previous wokring day'''

    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                print ("Holiday : ",d)
                d = d - datetime.timedelta(days=1)
            else:
                return d



def convertDate(date):
    y = date.strftime("%Y")
    m = date.strftime("%b").upper()
    d = date.strftime("%d")
    return [y, m, d]

def getFilename(date):
    [y, m, d] = convertDate(date)
    return "fo%s%s%sbhav.csv" % (d, m, y)


def dateparse(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date


holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

d = datetime.datetime.now().date()
d = previous_working_day(d, holiday_master)


while not os.path.exists(proccessed_dir+"{}".format(getFilename(d))):
    time.sleep(200)
    print ("Prev bhavcopy not present")
else:
    df = pd.read_csv(proccessed_dir+"{}".format(getFilename(d)))
    
    r = redis.Redis(host=redis_host, port=6379)
    
    context = pa.default_serialization_context()
    df_compressed = context.serialize(df).to_buffer().to_pybytes()

    res = r.set("prev_bhavcopy",df_compressed)
    if res == True:
        print ("Successfully published previous day bhavcopy to redis")
        
        
#df = context.deserialize(r.get("prev_bhavcopy"))  # read back from pyarrow