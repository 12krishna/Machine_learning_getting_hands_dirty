# -*- coding: utf-8 -*-
"""
Created on Mon Dec 30 11:14:41 2019

@author: krishna
"""
import datetime
import requests
import StringIO, zipfile
import os
import sys
import shutil
import pandas as pd
import time 
import logging 
import Cassandra_dumper
import redis

os.chdir("D:\\Data_dumpers\\NSE_FNO_bhavcopy\\")



download_dir = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\Download\\"
master_dir = "D:\\Data_dumpers\\Master\\"
log_path = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\"
processed_dir = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\Processed_folder\\"
ETL_dir = 'D:\\ETL\\Download\\'
options_dir = 'D:\\Options\\Deliverables\\bhavcopy\\'

redis_host = 'localhost'
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'}


# log events in debug mode 
logging.basicConfig(filename=log_path+"fnobhavcopy_dumper.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date
         
    
def convertDate(date):
    y = date.strftime("%Y")
    m = date.strftime("%b").upper()
    d = date.strftime("%d")
    return [y, m, d]


def getFilename(date):
    [y, m, d] = convertDate(date)
    return "fo%s%s%sbhav.csv" % (d, m, y)

    
def getReqStr(date):
    [y, m, d] = convertDate(date)
    return "/content/historical/DERIVATIVES/%s/%s/%s.zip" % (y, m, getFilename(date))

        

def downloadCSV(d):
    
    filename = getFilename(d)
    reqstr = getReqStr(d)
    reqstr = "https://archives.nseindia.com"+reqstr
    print reqstr
    responsecode = ''
    print "Downloading %s ..." % (filename)
    
    # read holiday master
    holiday_master = pd.read_csv(master_dir+ 'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
    
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        try:
            responsecode = requests.get(reqstr, headers=headers )   
            print responsecode.status_code
        except Exception as e:
            print e
            responsecode=404
            
        while datetime.datetime.now().time() > datetime.time(17,0):
            # sleep for 2 min
            logging.info('{} is Working day : sleep for 2 minutes '.format(d))
            
            print 'Sleep for 2 min...'
            
            time.sleep(120)
            try:
                responsecode = requests.get(reqstr, headers=headers )  
                if responsecode.status_code==200:
                    break
            except Exception as e:
                print "Response Exception / {}".format(e)
        
        
           
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1
    
    
    try:
        # write a file 
        z = zipfile.ZipFile(StringIO.StringIO(responsecode.content))
        z.extractall(processed_dir)
        # copy file to ETL and FNO download folder 
        df = pd.read_excel(master_dir+"Expiry_dates_master.xlsx")
        df.dropna(inplace=True)
        df['d'] = df.apply(lambda row: datetime.datetime.strptime("{}{}{}".format(row['Date'],
                                                                                      row['Month'], row['Year']),"%d%b%Y").date() , axis=1)
                   
        expiry_value = 0
        try:
            expiry_value = df[df['d']==d]['Expiry'].values[0]
            logging.info( "{}: is an expiry week".format(d) )
        except Exception as e:
            logging.info("{} is not an expiry week date; hence not copyiny to ETL folder for expiry rollover analysis".format(d))
                
        if expiry_value != 0:
            shutil.copy("Processed_folder\{0}".format(filename), ETL_dir+filename) # copy to ETL folder 
            r = redis.Redis(host=redis_host, port=6379) 
            r.set('expiry_report_flag',1) # expiry report flag
            logging.info('{} is and expiry day and hence run expiry report '.format(d))
    
        shutil.copy("Processed_folder\{0}".format(filename), download_dir+filename) # copy to FNO bhavcopy download folder and dump in cassandra
        shutil.copy("Processed_folder\{0}".format(filename), options_dir+filename) # copy to FNO bhavcopy download folder and dump in cassandra
        # dump to cassandra
        Cassandra_dumper.cassandra_dumper()
        
        return 1
    
    except:
        print "File is not a zip file "
        return -1
        

            

        
       

def getUpdate():
    errContinous = 0
    d = datetime.date.today()
    decr = datetime.timedelta(days=1)
    while errContinous > -30 and (not os.path.exists(os.path.join("Processed_folder",getFilename(d)))):
        if downloadCSV(d) > -1:
            errContinous = 0
        else:
            errContinous -= 1
        d -= decr



def main(args):
    if args:
        if args[0] == "-update":
            getUpdate()
    

if __name__ == "__main__":
    main(sys.argv[1:])