import urllib2
import datetime
from dateutil.relativedelta import relativedelta
import requests
import httplib, StringIO, zipfile
import os
import sys
import shutil
from six.moves.urllib.parse import urlparse
from dateutil import parser
import pandas as pd
import time 
import logging 
import Cassandra_dumper
import redis

download_dir = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\Download\\"
master_dir = "D:\\Data_dumpers\\Master\\"
log_path = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\"
processed_dir = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\Processed_folder\\"
ETL_dir = 'D:\\ETL\\Download\\'
options_dir = 'D:\\Options\\Deliverables\\bhavcopy\\'

redis_host = 'localhost'

# log events in debug mode 
logging.basicConfig(filename=log_path+"fnobhavcopy_dumper.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


class nseConnect:
    headers = {'Host': 'www.nseindia.com',
               'Referer': 'https://www.nseindia.com/products/content/equities/equities/eq_security.htm'}
    
    url = "www.nseindia.com"

    #Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36
    #User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
    def connect(self):
        response = requests.head('http://' + self.url)
        if response.status_code == 302:
            self.url = response.headers["Location"]
        isHttps = self.url.find("https") > -1
        self.url = self.url[self.url.find("//")+2:self.url.rfind("/")]
        if isHttps:
            self.conn = httplib.HTTPSConnection(self.url)
        else:
            self.conn = httplib.HTTPConnection(self.url)

    def disconnect(self):
        self.conn.close()

    def getFilename(self, date):
        [y, m, d] = self.convertDate(date)
        return "fo%s%s%sbhav.csv" % (d, m, y)

    def convertDate(self, date):
        y = date.strftime("%Y")
        m = date.strftime("%b").upper()
        d = date.strftime("%d")
        return [y, m, d]

    def getReqStr(self, date):
        [y, m, d] = self.convertDate(date)
        return "/content/historical/DERIVATIVES/%s/%s/%s.zip" % (y, m, self.getFilename(date))

    def getResponse(self, reqstr):
        
        self.url = reqstr
        self.session = requests.Session()
        if self.headers:
            self.session.headers.update(self.headers)
        
        u = urlparse(self.url)
        self.session.headers.update({'Host': u.hostname})
        self.data = self.session.get(self.url)
        
        return self.data.status_code
    
        
        

def downloadCSV(c, d):
    
    filename = c.getFilename(d)
    reqstr = c.getReqStr(d)
    reqstr = "https://www.nseindia.com"+reqstr
    
    print "Downloading %s ..." % (filename)
    
    # read holiday master
    holiday_master = pd.read_csv(master_dir+ 'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
    
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        responsecode = c.getResponse(reqstr) 
        while responsecode!= 200 and datetime.datetime.now().time() > datetime.time(17,0):
            # sleep for 2 min
            logging.info('{} is Working day : sleep for 2 minutes '.format(d))
            
            print 'Sleep for 2 min...'
            
            time.sleep(120)
        
            
            responsecode = c.getResponse(reqstr)
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1
            


    sdata = StringIO.StringIO(c.data.content)
    

    
    try:
        z = zipfile.ZipFile(sdata)
        csv = z.read(z.namelist()[0])
    except Exception as e:
        print "%s" % (format(e))
        logging.info('{}- File not found, Error: {}'.format(d,e))
        return -1
    if not csv:
        print "Could not download %s." % (e.message)
        logging.info( "{}- Could not download {}" .format(d,e.message) )
        return -1
    else:
        if not os.path.exists("data"):
            os.makedirs("data")
        fil = open(os.path.join("data",filename), 'w')
        fil.write(csv)
        fil.close()
        
        # copy file to ETL and FNO download folder 
        df = pd.read_excel(master_dir+"Expiry_dates_master.xlsx")
        df.dropna(inplace=True)
        df['d'] = df.apply(lambda row: datetime.datetime.strptime("{}{}{}".format(row['Date'],
                                                                                  row['Month'], row['Year']),"%d%b%Y").date() , axis=1)
        
        
        expiry_value = 0
        try:
            expiry_value = df[df['d']==d]['Expiry'].values[0]
            logging.info( "{}: is an expiry week".format(d) )
        except Exception as e:
            logging.info("{} is not an expiry week date; hence not copyiny to ETL folder for expiry rollover analysis".format(d))
            
        if expiry_value != 0:
            shutil.copy("data\{0}".format(filename), ETL_dir+filename) # copy to ETL folder 
            r = redis.Redis(host=redis_host, port=6379) 
            r.set('expiry_report_flag',1) # expiry report flag
            logging.info('{} is and expiry day and hence run expiry report '.format(d))

        shutil.copy("data\{0}".format(filename), download_dir+filename) # copy to FNO bhavcopy download folder and dump in cassandra
        shutil.copy("data\{0}".format(filename), options_dir+filename) # copy to FNO bhavcopy download folder and dump in cassandra
        # dump to cassandra
        Cassandra_dumper.cassandra_dumper()
        
        
        return 1

def downloadCSVDate(c, date):
    [y, m, d] = convertDate(date)
    return downloadCSV(c, y, m, d)

def getUpdate(c):
    errContinous = 0
    d = datetime.date.today()
    decr = datetime.timedelta(days=1)
    while errContinous > -30 and (not os.path.exists(os.path.join("data",c.getFilename(d)))):
        if downloadCSV(c, d) > -1:
            errContinous = 0
        else:
            errContinous -= 1
        d -= decr



def main(args):
    c = nseConnect()
    c.connect()
    if args:
        if args[0] == "-update":
            getUpdate(c)
        
    c.disconnect()

if __name__ == "__main__":
    main(sys.argv[1:])
