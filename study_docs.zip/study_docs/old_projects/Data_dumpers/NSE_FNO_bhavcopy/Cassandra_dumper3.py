import pandas as pd
#from dateutil import parser
import os
from cassandra.cluster import Cluster
import logging
#from time import time
import shutil
import redis
from datetime import datetime
import sys


download_dir = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\Download\\"
master_dir = "D:\\Data_dumpers\\Master\\"
log_path = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\"
#processed_dir = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\Processed_folder\\"

redis_host = 'localhost'
cassandra_host = '172.17.9.51'



# log events in debug mode
logging.basicConfig(filename=log_path+"fnobhavcopy_dumper.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")




def encoder(expiry_dt,expiry1,expiry2,expiry3,symbol,instrument,strike_pr,option_typ):
    if expiry_dt == expiry1:
        return 1
    elif expiry_dt == expiry2:
        return 2
    elif expiry_dt == expiry3:
        return 3
    else:
        logging.info('Expiry date {0} for /{1} / {2} / {3} / {4}/ was not found.'.format(expiry_dt,symbol,instrument,strike_pr,option_typ))
        return 0




def expiry_encodings(bhav_copy):
    '''Function for expiry encodings'''

    expiry_contract_dates = pd.read_excel(master_dir+'Expiry_contract_Master.xlsx')
    expiry_contract_dates.set_index('Date',inplace=True)
    expiry_contract_dates.index.name = 'TIMESTAMP'
    FINAL = bhav_copy.merge(expiry_contract_dates, on='TIMESTAMP')
    FINAL['Expiry_encodings'] = FINAL.apply(lambda row: '{0}_{1}_{2}_{3}_{4}'.format(row['SYMBOL'],row['INSTRUMENT'],
                                                                                     row['STRIKE_PR'],row['OPTION_TYP'],
                                                                                     encoder(row['EXPIRY_DT'],
                                                                                             row['Expiry1'],
                                                                                             row['Expiry2'],
                                                                                             row['Expiry3'],
                                                                                            row['SYMBOL'],row['INSTRUMENT'],
                                                                                            row['STRIKE_PR'],row['OPTION_TYP'])), axis =1)
    # Exclude expiry encodings with zero
    FINAL = FINAL[(FINAL.Expiry_encodings.str.endswith('1')) |
                  (FINAL.Expiry_encodings.str.endswith('2')) |
                  (FINAL.Expiry_encodings.str.endswith('3'))]

    FINAL.drop(columns=['Expiry1','Expiry2','Expiry3'], inplace= True)


    return FINAL

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]

    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)

    return cluster


def cassandra_dumper():


    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()

    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands
    session = cluster.connect('rohit')
    logging.info('Using rohit keyspace')

    # CREATE A TABLE; dump bhavcopies to this table
    session.execute('CREATE TABLE IF NOT EXISTS FNO_bhavcopy (SYMBOL VARCHAR,INSTRUMENT VARCHAR, EXPIRY_DT DATE, STRIKE_PR DECIMAL, OPTION_TYP VARCHAR, OPEN DECIMAL, HIGH DECIMAL,LOW DECIMAL, CLOSE DECIMAL, SETTLE_PR DECIMAL, CONTRACTS DECIMAL, VAL_INLAKH DECIMAL, OPEN_INT DECIMAL, CH_IN_OI DECIMAL, PRICE_DATE DATE, KEY VARCHAR, PRIMARY KEY (KEY, PRICE_DATE))')



    # walk through all the downlaoded bhavcopies in downlaods dir
    for r,d,f in os.walk(download_dir):
        # read master files for symbols
        logging.info('Reading master file for symbols')
        master_df = pd.read_excel(master_dir+'MasterData.xlsx')
        master_df = master_df['SYMBOL']


        # process every bhavcopy in expiry encodings format
        logging.info('Traverse through each bhavcopy')
        for csv_file in f:
            #read each csv file
            print (csv_file)
            file_name = csv_file
            logging.info('Processing bhavcopy {0}...'.format(file_name))

            bhav_copy = pd.read_csv(download_dir + file_name)
            bhav_copy.dropna(axis=1, inplace=True)
            og_len = len(bhav_copy)

            # convert to cassandra date format
            bhav_copy['EXPIRY_DT'] = pd.to_datetime(bhav_copy['EXPIRY_DT'], format='%d-%b-%Y')
            bhav_copy['TIMESTAMP'] = pd.to_datetime(bhav_copy['TIMESTAMP'], format='%d-%b-%Y')
            bhav_copy.set_index('SYMBOL', inplace= True)

            # Consider SYMBOL present in master file, exclude rest
            #master_df = pd.read_excel(master_dir+'MasterData.xlsx')
            #master_df = master_df['SYMBOL']
            logging.info('No match for {0} symbols in master file'.format(bhav_copy.loc[~bhav_copy.index.isin(master_df)].index))
            ignore_num = len(bhav_copy.loc[~bhav_copy.index.isin(master_df)])
            bhav_copy = bhav_copy.loc[bhav_copy.index.isin(master_df)]
            bhav_copy.reset_index(inplace=True)

            # Get expiry encodings
            bhav_copy = expiry_encodings(bhav_copy)
            bhav_copy.index

            # write processed bhav_copy to temp file
            bhav_copy.to_csv('temp.csv', index= False)

            # write csv file to cassandra db
            os.system(log_path+"dump3.bat ")
            print("python version {}".format(sys.version))
            # remove bhavcopy from download dir
            logging.info('Removed bhavcopy {0} from download dir'.format(file_name))
            # move the processed file to folder
            #shutil.move(download_dir + file_name, processed_dir+file_name)
            os.remove(download_dir + file_name)
            r = redis.Redis(host=redis_host, port=6379)
            r.set('fno_bhavcopy_dumper', 1)
            df = pd.read_excel(master_dir+"Expiry_dates_master.xlsx")
            df.dropna(inplace=True)
            df['d'] = df.apply(lambda row: datetime.strptime("{}{}{}".format(row['Date'],
                                                                                      row['Month'], row['Year']),"%d%b%Y").date() , axis=1)


            if df[(df['Expiry']=='E') & (df['d']==pd.Timestamp(bhav_copy['TIMESTAMP'].values[0]).date() )].empty!=True:
                r.set('ssf_oi_flag',0)
            else:
                r.set('ssf_oi_flag',1)
            r.set('fno_descriptive_flag',1) # flag set for running descriptive OI report
            r.set('market_snap_fno',1) # flag set for running descriptive OI report
            r.set("fno_factors_dump",1)


            #get number of rows dumped into cassandra and original rows in file
            d = datetime.strftime(datetime.strptime( file_name[2:4]+' '+file_name[4:7]+' '+file_name[7:11],'%d %b %Y').date(), "%Y-%m-%d")

            c_len = session.execute('select count(*) from rohit.FNO_bhavcopy where PRICE_DATE = \'{}\' allow filtering;'.format(d), timeout=None).one()[0]

            print ('Number of rows in orginal file {},number of rows dumped in cassandra {}, {} rows were skiped due to not present in master file'.format(og_len,c_len, ignore_num))
            logging.info('{}: Number of rows in orginal file {}, number of rows dumped in cassandra {}, {} rows skipped due to not present in master file '.format(d,og_len,c_len, ignore_num))


            r.set('fno_bhavcopy_dumper_lengths',
                  '{}: {} rows dumped in cassandra , whereas {} rows were present in original file, Number of rows skipped due to not present in master file - {}'.format(d, c_len, og_len, ignore_num))

#cassandra_dumper()
