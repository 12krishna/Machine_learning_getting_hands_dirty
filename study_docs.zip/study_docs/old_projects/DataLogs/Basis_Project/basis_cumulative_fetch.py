# -*- coding: utf-8 -*-
"""
Created on Mon Dec 30 16:56:55 2019

@author: krishna
"""
import pandas as pd
import numpy as np
import datetime,os,time,sys,shutil #redis
from cassandra.cluster import Cluster
from dateutil.parser import parse
from decimal import Decimal
import xlwings as xw
import redis 

master_dir = "D:\\DataLogs\\Master\\"

#cassandra_host = "172.17.9.51"
redis_host = "10.223.104.86"
# redis_host = "localhost"
os.chdir("D:\\DataLogs\\Basis_Project\\")


def cumulative_computation_func(r, today_files):
    '''Func to do cummulative compuation for any given month'''
    
    df = pd.DataFrame()  
    for f in today_files:
        df = df.append(pd.read_msgpack(r.get(f)))
    
    result = []
    g1_starttime= datetime.datetime.today().replace(hour=9, minute=15, second= 0)
    g1_endtime = datetime.datetime.today().replace(hour=10, minute=0, second=0)
    g2_starttime = datetime.datetime.today().replace(hour=15, minute=0, second=0)
    g2_endtime = datetime.datetime.today().replace(hour=15, minute=30, second=0)



    for gname, gelements in df.groupby(['Symbol']):
        print gname
        gelements = gelements[gelements['LTP_cash']!=0]
        if len(gelements)!=0:            
        
            sum_fa = gelements[gelements['FA/RA'] == 'FA']['cfvolume'].sum() # filter on fa
            sum_ra = gelements[gelements['FA/RA'] == 'RA']['cfvolume'].sum() # filter on ra    
            sum_short_futs = gelements['Short Futs'].sum() 
            sum_long_futs = gelements['Long Futs'].sum() 
            min_spread = gelements['spread_bps'].min()
            max_spread = gelements['spread_bps'].max()
            spread_bps_avg = gelements['spread_bps'].mean()
            quantile_5,quantile_50, quantile_95 = gelements['spread_bps'].quantile([0.05,0.5,0.95])

            opening_basis = gelements[(pd.to_datetime(gelements["time"]) >= g1_starttime ) &
                                      (pd.to_datetime(gelements["time"]) <= g1_endtime )]["spread_bps"].fillna(0).mean()
            closing_basis = gelements[(pd.to_datetime(gelements["time"]) >= g2_starttime) &
                                       (pd.to_datetime(gelements["time"]) <= g2_endtime)]["spread_bps"].fillna(0).mean()


            fa_average = gelements[gelements['FA/RA'] == 'FA']
            fa_average = np.sum(fa_average['spread_bps'] * fa_average['cfvolume']) / np.sum(
                fa_average['cfvolume'])  # weighted average

            ra_average = gelements[gelements['FA/RA'] == 'RA']
            ra_average = np.sum(ra_average['spread_bps'] * ra_average['cfvolume']) / np.sum(
                ra_average['cfvolume'])  # weighted average

            short_futs_avg = np.sum(gelements['Short Futs'] * gelements['spread_bps']) / np.sum(gelements['Short Futs'])
            long_futs_avg = np.sum(gelements['Long Futs'] * gelements['spread_bps']) / np.sum(gelements['Long Futs'])

            result.append([gname, sum_fa, sum_ra, round(sum_short_futs), round(sum_long_futs), round(min_spread),
                           round(max_spread), round(spread_bps_avg), round(quantile_5),round(quantile_50), round(quantile_95),
                           round(fa_average), round(ra_average),
                           round(short_futs_avg), round(long_futs_avg), round(opening_basis), round(closing_basis)])

    result = pd.DataFrame(result,
                          columns=['Symbol', 'FA', 'RA', 'Short Futs', 'Long Futs', 'Min', 'Max', 'Spread bps avg',
                                   '5%','50%', '95%',
                                   'fa avg', 'ra avg', 'Shortfuts avg', 'Longfuts avg', 'Opening_basis', 'Closing_basis'])
    result = result[result["Symbol"]!= 'AMARAJABAT']
    return result


def price_Oi_change(re):
    '''Func to get price and OI change for current month'''
   
    #os.chdir(cur_dir) # change dir to current excel front end dir 
 
    expiry_dates_master = pd.read_excel(master_dir+'Expiry_dates_master.xlsx')
    expiry_dates_master['date'] = expiry_dates_master.apply(lambda row: pd.to_datetime(str(row['Date'])+row['Month']+str(row['Year'])).date(),
                           axis=1)
    expiry_dates_master = expiry_dates_master[expiry_dates_master['Expiry']=='E']['date']
    # check for fo bhavcopy 
    #files = [f for f in os.listdir('.') if os.path.isfile(f) and f.startswith('fo')]
    #print files[0]
    #name = files[0][2:11]
    
    
    # read prev day bhavcopy from redis 
    df = pd.read_msgpack(re.get("prev_bhavcopy"))
    df['EXPIRY_DT'] = pd.to_datetime(df['EXPIRY_DT'], format='%d-%b-%Y').dt.date
    df['TIMESTAMP'] = pd.to_datetime(df['TIMESTAMP'], format='%d-%b-%Y').dt.date
        
    d = df['TIMESTAMP'][0]  
    
    
    df = df[df['INSTRUMENT']=='FUTSTK'][['SYMBOL','EXPIRY_DT','OPEN_INT']]
    df['EXPIRY_DT'] = df['EXPIRY_DT'].apply(lambda row: pd.to_datetime(row))
    res = pd.DataFrame()
    if d not in expiry_dates_master.values:
        res = df.sort_values(by='EXPIRY_DT').groupby(['SYMBOL'], sort=True).head(2)   # oi = m1+m2
        res = res.groupby(['SYMBOL']).agg({'OPEN_INT':'sum'}).reset_index()
    else:
        res = df.sort_values(by='EXPIRY_DT').groupby(['SYMBOL'], sort=True).tail(2)  # oi = m2+m3
        res = res.groupby(['SYMBOL']).agg({'OPEN_INT':'sum'}).reset_index()
    res.rename(columns={'SYMBOL':'Symbol'}, inplace=True)  
    
    
    
    # get close price and OI from redis dumped files 
    cp_oi_df = pd.DataFrame()
    for f in list(re.keys('price_oi_chg_*')):
        cp_oi_df = pd.concat([cp_oi_df, pd.read_msgpack(re.get(f))], axis=0)
    cp_oi_df = cp_oi_df.sort_values(by='time').groupby(['Symbol'],sort=True).last().reset_index()[['Symbol','time','ClosePrice','OI']]  # get futures LTP from dumped redis files
    
    # get LTP files from processed market files dumped in redis 
    d = datetime.date.today()
    today_files = ''.join(['0'+str(d.day) if len(str(d.day))==1 else str(d.day),'0'+str(d.month) if len(str(d.month))==1 else str(d.month),
                 str(d.year)])
    today_files = list(re.keys('{}*'.format(today_files)))
    
    
    today_files_m1 = [ x for x in today_files if x.endswith('_m1')]
    today_files_m2 = [ x for x in today_files if x.endswith('_m2')]
    ltp_df_m1 = pd.DataFrame()
    for f in today_files_m1:
        ltp_df_m1 = pd.concat([ltp_df_m1, pd.read_msgpack(re.get(f))], axis=0)
    ltp_df_m1 = ltp_df_m1.sort_values(by='time').groupby(['Symbol'],sort=True).last().reset_index()[['Symbol','LTP_fut']]  # get futures LTP from dumped redis files
    
    # next month
    ltp_df_m2 = pd.DataFrame()
    for f in today_files_m2:
        ltp_df_m2 = pd.concat([ltp_df_m2, pd.read_msgpack(re.get(f))], axis=0)
    ltp_df_m2 = ltp_df_m2.sort_values(by='time').groupby(['Symbol'],sort=True).last().reset_index()[['Symbol','LTP_fut']]  # get futures LTP from dumped redis files
    
    ltp_df = ltp_df_m1.merge(ltp_df_m2, on="Symbol", how="left", suffixes=('_m1', '_m2'))
    
       
    cp_oi_df = cp_oi_df.merge(ltp_df, on='Symbol', how='left')
    cp_oi_df = cp_oi_df.merge(res, on='Symbol', how='left')
    
    cp_oi_df['OPEN_INT'] = cp_oi_df['OPEN_INT'].fillna(0)
    cp_oi_df.dropna(subset=["OI"], inplace=True)
    
    # handle coporate actions here
    
    
    
    cp_oi_df['Px_chg'] = (cp_oi_df['LTP_fut_m1'] - cp_oi_df['ClosePrice'])/ cp_oi_df['ClosePrice']* 100
    cp_oi_df['OI_Chg_quantity'] = cp_oi_df['OI']- cp_oi_df['OPEN_INT']
    cp_oi_df['OI_chg'] = (cp_oi_df['OI_Chg_quantity'])/ cp_oi_df['OPEN_INT']* 100
    
    # round till 2 decimals 
    cp_oi_df['Px_chg'] = cp_oi_df['Px_chg'].round(2)
    cp_oi_df['OI_chg'] = cp_oi_df['OI_chg'].round(2)
    #cp_oi_df['OI_Chg ($mn)'] = cp_oi_df['OI_Chg ($mn)']*dollar_value/10000  # oi change mn dollars
    # dollar_value = 79.66
    if re.get('dollar_value')!=None:
        dollar_value = float(re.get('dollar_value'))
    print "dollar value used {}".format(dollar_value)

    cp_oi_df= cp_oi_df.loc[cp_oi_df["Symbol"]!= "GSPL"]
    cp_oi_df = cp_oi_df.loc[cp_oi_df["Symbol"] != "AMARAJABAT"]
    # convert into million dollars 
    cp_oi_df['OI_Chg ($mn)'] = cp_oi_df.apply(lambda row: int( row['OI_Chg_quantity']*row['LTP_fut_m1']/(1000000*dollar_value)) if row['OI_Chg_quantity']!=0 else 0,axis=1 ) 
    #result_m1['OI_Chg_quantity'] = result_m1['OI_Chg_quantity'].round()
       
    
    cp_oi_df = cp_oi_df[['Symbol','Px_chg','OPEN_INT','OI','OI_Chg_quantity','OI_chg','OI_Chg ($mn)','LTP_fut_m1','LTP_fut_m2']]
    
    return cp_oi_df



def final_format(today_files_m1,r,dollar_value,month ):
    
    print "cumulative computation started"
    result_m1 = cumulative_computation_func(r, today_files_m1)
    print "cumulative computation end"

    print "price_Oi_change  started"
    price_oi_chg_df = price_Oi_change(r)
    print "price_Oi_change  end"

    #price_oi_chg_df_m1 = price_oi_chg_df[price_oi_chg_df['Symbol'].isin(symbols_m1)]  # filter on set symbols 
    
    result_m1 = price_oi_chg_df.merge(result_m1, on='Symbol',how='left')  
    
    result_m1.set_index('Symbol', inplace=True)
    result_m1.dropna(how="all", inplace=True)
    result_m1.reset_index(inplace=True)
    # fa ra levels into million dollars 
    #result_m1.to_csv('debug.csv')
    result_m1['Arb_long ($mn)'] = result_m1.apply(lambda row: row['RA']*row['LTP_fut_{}'.format(month)]/(1000000*dollar_value) if row['RA']!=0 or row['RA']!=np.NaN else 0, axis=1 ) 
    #result_m1['FA'] = result_m1['FA'].round()
    result_m1['Arb_short ($mn)'] = result_m1.apply(lambda row: row['FA']*row['LTP_fut_{}'.format(month)]/(1000000*dollar_value) if row['FA']!=0 or row['FA']!=np.NaN else 0, axis=1 ) 
        
    #result_m1['RA'] = result_m1['RA'].round()
    result_m1['Non_Arb_long ($mn)'] = result_m1.apply(lambda row: row['Long Futs']*row['LTP_fut_{}'.format(month)]/(1000000*dollar_value) if row['Long Futs']!=0 or row['Long Futs']!=np.NaN else 0, axis=1 ) 
    #result_m1['Short Futs'] = result_m1['Short Futs'].round()
    result_m1['Non_Arb_short ($mn)'] = result_m1.apply(lambda row: row['Short Futs']*row['LTP_fut_{}'.format(month)]/(1000000*dollar_value) if row['Short Futs']!=0 or row['Short Futs']!=np.NaN else 0, axis=1 ) 
    #result_m1['Long Futs'] = result_m1['Long Futs'].round()
    result_m1[['OI_Chg ($mn)','Arb_short ($mn)','Arb_long ($mn)','Non_Arb_short ($mn)','Non_Arb_long ($mn)', 'Opening_basis', 'Closing_basis']] = result_m1[['OI_Chg ($mn)',
               'Arb_short ($mn)','Arb_long ($mn)','Non_Arb_short ($mn)','Non_Arb_long ($mn)', 'Opening_basis', 'Closing_basis']].round()
    result_m1 = result_m1[['Symbol','Px_chg','OPEN_INT','OI','OI_chg','OI_Chg_quantity','OI_Chg ($mn)',
                           'FA','Arb_short ($mn)','RA','Arb_long ($mn)','Short Futs','Non_Arb_short ($mn)',
                           'Long Futs','Non_Arb_long ($mn)','Min','Max','Spread bps avg','5%','50%','95%',
                           'Opening_basis', 'Closing_basis', 'fa avg','ra avg',
                           'Shortfuts avg','Longfuts avg']]
    
    return result_m1

    
def cumulative_result(flag):
    '''Func to display cummulative result for all the files'''
    
    r = redis.Redis(host=redis_host, port=6379)
    # r= redis.Redis(host="localhost", port=6379, db=1)
    # dollar_value = 79.66
    if r.get('dollar_value')!=None:
        dollar_value = float(r.get('dollar_value'))

    #endtime = str(wb.sheets[3].range('B2').value)
    # get all result files and filter on starttime and endtime 
    d = datetime.date.today()
    today_files = ''.join(['0'+str(d.day) if len(str(d.day))==1 else str(d.day),'0'+str(d.month) if len(str(d.month))==1 else str(d.month),
                 str(d.year)])
            
    today_files = list(sorted(r.keys('bpsresult_{}_*'.format(today_files))))
    today_files_m1 = list(sorted( [ x for x in today_files if x.endswith('m1')] ))  # filter on current month m1
    today_files_m2 = list(sorted( [ x for x in today_files if x.endswith('m2')] ))  # filter on next month m2
    
    # total Current month and next month cullumative logic here 
    today_files_cum = today_files_m1+today_files_m2 
    
    # current month     
    #result.reset_index(inplace=True)
    # but filter on symbol that are set by the user    
    result_m1 = final_format(today_files_m1,r,dollar_value,'m1' )
    
    if flag==0:
        # send only current month
        return result_m1, dollar_value
    elif flag==1 :
        # check for next month too
        if int(r.get('param_cumulative_flag_m2') if r.get('param_cumulative_flag_m2')!= None else 0 )==1:            
            try:
                result_m2 = final_format(today_files_m2,r,dollar_value,'m2' )
                return result_m1, result_m2, dollar_value
            except:
                print "Error in nexth month processing"
                return result_m1, dollar_value
        else:
            return result_m1, dollar_value
                
    elif flag==2:
        return final_format(today_files_cum,r,dollar_value,'m1' ), dollar_value
    
if __name__ == '__main__':
    cumulative_result(1)