# -*- coding: utf-8 -*-
"""
Created on Fri Jun 24 15:04:47 2022

@author: backup
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Oct 18 15:40:52 2021

@author: krishna
"""

import pandas as pd
import numpy as np
import datetime,os,time, shutil
from cassandra.cluster import Cluster
import warnings
warnings.filterwarnings("ignore")

master_dir = "D:\\DataLogs\\Master\\"
email_dir = "D:\\Emails\\Output\\"
output_dir = "D:\\DataLogs\\Basis_Project\\Output\\"
#output_dir = "C:\\Users\\backup\\Geeta\\"
drive = r"\\172.17.9.22\Users2\Derivatives Eod\EOD Confirms NAVNEET\GoldmanInput\Parindu\% ile Data"
drive2 = r"\\172.17.9.22\Users2\Derivatives Eod\EOD Confirms NAVNEET\GoldmanInput\Parindu_Common\% ile Data"
cassandra_host = "172.17.9.51"
#redis_host = "localhost"


# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):

    '''Pandas factory to determine cassandra data into python df'''
    return pd.DataFrame(rows, columns=colnames)



def dateparse(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]

    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)

    return cluster

# read holiday master
holiday_master = pd.read_csv(master_dir+ 'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

cluster = cassandra_configs_cluster()
session = cluster.connect('rohit')
query= "ALTER TABLE rohit.fno_basis WITH GC_GRACE_SECONDS = 0 ;"
rslt = session.execute(query,timeout=None)
#logging.info('Using test_df keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None

def previous_working_day(d):
    '''Get previous wokring day'''

    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                #print "Holiday : ",d
                d = d - datetime.timedelta(days=1)
            else:
                return d


def get_end_date(d,c):
    for i in range(0,c):
        prev=previous_working_day(d)
        d=prev
        #print d
    return d



def process_run_check(d):
    '''Func to check if the process should run on current day or not'''

    # check if working day or not
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded

        df = session.execute("select date from fno_basis where date='{}' allow filtering".format(d))
        df = df._current_rows

        while datetime.datetime.now().time() > datetime.time(16,0) and df.empty==True:
            print ('Sleep for 2 min...')
            time.sleep(1)
            df = session.execute("select date from fno_basis where date='{}' allow filtering".format(d))
            df = df._current_rows

        return 1

    elif len(holiday_master[holiday_master['date']==d])==1:
         print ('Holiday: skip for current date :{} '.format(d))
         return -1


def fetch_data(d):
    
    result = pd.DataFrame()
    startdate = d-datetime.timedelta(days=100)
    enddate = d
    while 1:
        print startdate, enddate
        temp_df = session.execute("select symbol,date,percentile_5,percentile_50,percentile_95,spread_bps_avg,Opening_basis, Closing_basis from fno_basis \
                         where date>'{}' and date <='{}' allow filtering".format(startdate, enddate),timeout=None)
        temp_df = temp_df._current_rows
        enddate = startdate
        startdate = startdate-datetime.timedelta(days=100)
        if temp_df.empty==True:
            print "Loaded all data from table; exit code"
            break
        else:
            result = result.append(temp_df, ignore_index=True)
            
    return result

def fetch_data_next(d):
    
    result = pd.DataFrame()
    startdate = d-datetime.timedelta(days=100)
    enddate = d
    while 1:
        print startdate, enddate
        temp_df = session.execute("select symbol,date,percentile_5,percentile_50,percentile_95,spread_bps_avg, Opening_basis, Closing_basis from fno_basis_next \
                         where date>'{}' and date <='{}' allow filtering".format(startdate, enddate),timeout=None)
        temp_df = temp_df._current_rows
        enddate = startdate
        startdate = startdate-datetime.timedelta(days=100)
        if temp_df.empty==True:
            print "Loaded all data from table; exit code"
            break
        else:
            result = result.append(temp_df, ignore_index=True)
            
    return result            

import psycopg2
import datetime
from project_status_update import project_status_rt as udt
update_db= udt.postgres_updations()


def main(nd):

    d = datetime.datetime.now().date()-datetime.timedelta(days=nd)
    #prev_d = get_end_date(d,60)
    update_db.update_status("Basis %ile EOD_Parindu")
    if process_run_check(d)==-1:
        update_db.update_lastruntime("Basis %ile EOD_Parindu")
        return -1
    #df = session.execute("select symbol,date,percentile_5,percentile_95,spread_bps_avg from fno_basis \
    #                     where date>='{}' and date <='{}' allow filtering".format(prev_d, d))
    #df = df._current_rows
    # get entire data
    df = fetch_data(d)
    df.replace({None:np.nan},inplace=True)
    df.fillna(value=0, inplace=True)
    df = df[~df['symbol'].isin(['FINNIFTY','NIFTY','BANKNIFTY'])]
    df['date'] = df['date'].apply(lambda row: row.date())
    df.sort_values(by=['date'], ascending=True, inplace=True)
    df[['percentile_5','percentile_50','percentile_95']] = df[['percentile_5','percentile_50','percentile_95']].astype(float)
    df['spread_bps_avg'] = df['spread_bps_avg'].astype(int)

    # apply name change corporate action
    ca = pd.read_excel(master_dir+'Corporate_actions.xlsx')
    ca.dropna(subset=['Old_symbol','New_symbol'], inplace=True)
    for _, row in ca.iterrows():
         df['symbol'].replace(row['Old_symbol'], row['New_symbol'], inplace=True)


    # output sheet
    df1 = df[['symbol','date','percentile_5']].pivot_table(index='symbol', columns='date', values='percentile_5')
    df1 = df1[df1.columns[::-1]]
    df2 = df[['symbol','date','percentile_50']].pivot_table(index='symbol', columns='date', values='percentile_50')
    df2 = df2[df2.columns[::-1]]
    df3 = df[['symbol','date','percentile_95']].pivot_table(index='symbol', columns='date', values='percentile_95')
    df3 = df3[df3.columns[::-1]]
    df4 = df[['symbol','date','spread_bps_avg']].pivot_table(index='symbol', columns='date', values='spread_bps_avg')
    df4 = df4[df4.columns[::-1]]
    df5 = df[['symbol', 'date', 'opening_basis']].pivot_table(index='symbol', columns='date', values='opening_basis')
    df5 = df5[df5.columns[::-1]]
    df6 = df[['symbol', 'date', 'closing_basis']].pivot_table(index='symbol', columns='date', values='closing_basis')
    df6 = df6[df6.columns[::-1]]



    #temp=df1.copy(deep=True)
    #temp=temp.astype(str)
    #temp = temp.applymap(lambda col: col.replace('.0',''))
    #temp.to_excel(writer, sheet_name='5%')
   
    
    # high low
    #df1 = pd.DataFrame(df1.iloc[:,:5].min(axis=1)).reset_index(); df1.columns=['symbol','Low']
    #df2 = pd.DataFrame(df2.iloc[:,:5].max(axis=1)).reset_index(); df2.columns=['symbol','High']

    #df = pd.merge(df1, df2, on='symbol', how='inner')
    #df.to_excel(writer, index=False, sheet_name='5days_high_low')
    #save data
   
    dn=fetch_data_next(d)
    dn= dn[~dn['symbol'].isin(['FINNIFTY','NIFTY','BANKNIFTY'])]
    dn['date'] = dn['date'].apply(lambda row: row.date())
    dn.sort_values(by=['date'], ascending=True, inplace=True)
    dn.fillna(value=0, inplace=True)
    dn[['percentile_5','percentile_50','percentile_95']] = dn[['percentile_5','percentile_50','percentile_95']].astype(float)
    dn['spread_bps_avg'] = dn['spread_bps_avg'].astype(int)
    
    for _, row in ca.iterrows():
     dn['symbol'].replace(row['Old_symbol'], row['New_symbol'], inplace=True)

    dn1 = dn[['symbol','date','percentile_5']].pivot(index='symbol', columns='date', values='percentile_5')
    dn1.columns=dn1.columns.astype(str)
    dn1.columns=dn1.columns+"_next"
    
    dn2 = dn[['symbol','date','percentile_50']].pivot(index='symbol', columns='date', values='percentile_50')
    dn2.columns=dn2.columns.astype(str)
    dn2.columns=dn2.columns+"_next"
    
    dn3 = dn[['symbol','date','percentile_95']].pivot(index='symbol', columns='date', values='percentile_95')
    dn3.columns=dn3.columns.astype(str)
    dn3.columns=dn3.columns+"_next"
    
    dn4 = dn[['symbol','date','spread_bps_avg']].pivot(index='symbol', columns='date', values='spread_bps_avg')
    dn4.columns=dn4.columns.astype(str)
    dn4.columns=dn4.columns+"_next"

    dn5 = dn[['symbol', 'date', 'opening_basis']].pivot_table(index='symbol', columns='date', values='opening_basis')
    dn5.columns=dn5.columns.astype(str)
    dn5.columns = dn5.columns + "_next"

    dn6 = dn[['symbol', 'date', 'closing_basis']].pivot_table(index='symbol', columns='date', values='closing_basis')
    dn6.columns=dn6.columns.astype(str)
    dn6.columns = dn6.columns + "_next"
     
    
    
    df1.columns=df1.columns.astype(str)
    df2.columns=df2.columns.astype(str)
    df3.columns=df3.columns.astype(str)
    df4.columns = df4.columns.astype(str)
    df5.columns = df5.columns.astype(str)
    df6.columns = df6.columns.astype(str)
    
    merge1 = df1.merge(dn1, left_index=True, right_index=True, how='outer')
    merge2 = df2.merge(dn2, left_index=True, right_index=True, how='outer')
    merge3 = df3.merge(dn3, left_index=True, right_index=True, how='outer')
    merge4 = df4.merge(dn4, left_index=True, right_index=True, how='outer')
    merge5 = df5.merge(dn5, left_index=True, right_index=True, how='outer')
    merge6 = df6.merge(dn6, left_index=True, right_index=True, how='outer')
    
    merge1.sort_index(axis=1,ascending=False, inplace=True)
    merge2.sort_index(axis=1,ascending=False, inplace=True)
    merge3.sort_index(axis=1,ascending=False, inplace=True)
    merge4.sort_index(axis=1, ascending=False, inplace=True)
    merge5.sort_index(axis=1, ascending=False, inplace=True)
    merge6.sort_index(axis=1, ascending=False, inplace=True)

    writer = pd.ExcelWriter(os.path.join(output_dir,"Basis_EOD_{}.xlsx".format(d)))
    merge1.to_excel(writer, sheet_name='5%')
    merge2.to_excel(writer, sheet_name='50%')
    merge3.to_excel(writer, sheet_name='95%')
    merge4.to_excel(writer, sheet_name='spread_bps_avg')
    merge5.to_excel(writer, sheet_name='Opening_bps_avg')
    merge6.to_excel(writer, sheet_name='Closing_bps_avg')
    writer.save()
    writer.close()
    
    shutil.copy(os.path.join(output_dir,"Basis_EOD_{}.xlsx".format(d)),
                os.path.join(email_dir,"Basis_EOD_{}.xlsx".format(d)))
    shutil.copy(os.path.join(output_dir,"Basis_EOD_{}.xlsx".format(d)),
                os.path.join(drive, "%TILE DATA.xlsx"))
    shutil.copy(os.path.join(output_dir, "Basis_EOD_{}.xlsx".format(d)),
                os.path.join(drive2, "%TILE DATA.xlsx"))
    update_db.update_lastruntime("Basis %ile EOD_Parindu")


if __name__=='__main__':
     main(0)
     





