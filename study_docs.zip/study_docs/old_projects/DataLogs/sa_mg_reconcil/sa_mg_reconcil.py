# -*- coding: utf-8 -*-
"""
Created on Thu May 25 16:03:39 2023

@author: backup
"""

import sys
import os
import json
import requests
import datetime
import logging
import time
#from datetime import datetime, timedelta
import pandas as pd
import psycopg2
import datetime
import mailer

os.chdir("D:\\DataLogs\\sa_mg_reconcil\\")
master_dir = "D:\\DataLogs\\Master\\"
log_path="D:\\DataLogs\\sa_mg_reconcil\\"
dnld_dir='D:\\DataLogs\\sa_mg_reconcil\\download\\'
clientmaster_path=r"\\172.17.9.22\KSApps\KSTPS\Output\RiskDataDownload\\"

# data_dir=r'\\172.17.9.22\Users\Rupesh'  # output dir for storing files for client
# log_path=r'\\172.17.9.22\Users\Rupesh'
# master_dir = "D:\\DataLogs\\Master\\"


logging.basicConfig(filename=log_path+"apidwnld.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")     

console = logging.StreamHandler()
console.setLevel(logging.INFO)
# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)
logging.info("Start process")

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
     
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)
             
def next_working_day(d):
    '''Func to get next working day'''
    d = d + datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d + datetime.timedelta(days=1)
            else:
                return d    
             
def get_token():
  '''It gets token from the url
    using requests module and writes it in token.txt file in token_dir'''
    
  while True:  
    login_url = "https://www.connect2nse.com/extranet-api/login/1.0"
    
    payload = json.dumps({
        "memberCode":"08081",
        "loginId":"EXTRANETINST2",
        "password":"Rtgi8sMSOMEs3ijGSi_b9A=="
        })
#"password":"9KjQ0jQAo9t6PabTo7qLYg=="    
    headers = {
        "Content-Type":"application/json",
        "Cookie":"HttpOnly"
        }
    
   
    try:
        response = requests.request("POST",login_url,headers=headers,data=payload)
        response_json = response.json()
        if (response_json['responseCode'])[0] == '601':
            logging.info("We have received a success response code")
            rcvd_token = response_json['token']
            
            with open(os.path.join(log_path,'token.txt'),'w') as writer:
                writer.write(f"{rcvd_token}")
                logging.info(f"Received token is {rcvd_token}")
                
            writer.close()
            break
        # else:
        #     logging.error(f"We have received a {response_json['responseCode']} response code")
        #     logging.warning("Won't be able to proceed further.")
            
    
    except Exception as e:
          print(e)
          # logging.error(f"We have received a {response_json['responseCode']} response code")
          # logging.warning("Won't be able to proceed further.")
          time.sleep(10)
          
        
def read_token():
    '''It reads the token from token.txt file present in token_dir'''
    with open(os.path.join(log_path,'token.txt'),'r') as f:
        return f.readline()
 
    
def _verifyfile(lastUpdated):
    lastUpdated_dt = lastUpdated.split("T")[0]  
    return lastUpdated_dt
   
def get_file(d,d1,token,segment,folder,filename):
    '''it gets the response of the url where url is formed using segment and 
    folder and if the status code of the response is 200 then it checks if today’s 
    filename is present or not,if file is present then it returns the filename'''
    
   # url = f"https://www.connect2nse.com/extranet-api/common/content/1.0?segment={segment}&filename={filename}"
    dk=datetime.datetime.strftime(d,"%Y-%m-%d")
    
    if '08081' in filename:
          url = f"https://www.connect2nse.com/extranet-api/member/content/1.0?segment={segment}&folderPath=/{folder}"
    else:    
        url = f"https://www.connect2nse.com/extranet-api/common/content/1.0?segment={segment}&folderPath=/{folder}"
        #url = f"https://www.connect2nse.com/extranet-api/common/content/1.0?segment={segment}&folderPath=/"

    payload = {}
    
    headers = {
        "Cookie":"HttpOnly",
        "Authorization":f"Bearer {token}"
        }
    try:
        response = requests.request("GET", url, headers=headers, data=payload)
    except Exception as e:
        print(e)
        return -1
   # response_json = response.json()
    print(response.status_code)
    if response.status_code==200:
         response_json = response.json()
         for i in response_json['data']:   
            if i['name'].startswith(filename) and dk in i['lastUpdated'] : # checking date in lastupdated for the files having no date in it.
                print(f"{filename} present")
                return filename
                #timestamp = i['lastUpdated']
         else:
             print(f"{filename} not present yet")
             return -1 
    else:
        print(response.status_code)
      #  print(f"{filename} not available")
        return -1    
       
def dnld_file(token,segment,folder,filename,path,files_dict,d):
    '''it gets the response of the url where url is formed using segment and folder and if the status 
    code of the response is 200 then it downloads the file in data_dir and removes the filename from 
    files_dict and then it returns the files_dict'''
    
    if '08081' in filename:
         url = f"https://www.connect2nse.com/extranet-api/member/file/download/1.0?segment={segment}&folderPath=/{folder}&filename={filename}"

    else:
        url = f"https://www.connect2nse.com/extranet-api/common/file/download/1.0?segment={segment}&folderPath=/{folder}&filename={filename}"
    #url = f"https://www.connect2nse.com/extranet-api/common/file/download/1.0?segment={segment}&folderPath=/&filename={filename}"

   # payload = {}
    
    headers = {
        "Cookie":"HttpOnly",
        "Authorization":f"Bearer {token}"
        }
    
    response_json = requests.request("GET", url, headers=headers)
    print(response_json)
    print(response_json.status_code)
    if response_json.status_code==200:
        try:
            logging.info(f"Intiating file download of {filename}")
            open(os.path.join(path,filename),'wb').write(response_json.content)
            print(f"{filename} saved")
            logging.info("File download success at %s", (datetime.datetime.now()).strftime("%c"))
            dnld_status = "Success"
            
            file_dnld_size = (os.stat(os.path.join(path,filename))).st_size
            print(dnld_status,filename,file_dnld_size)
            time.sleep(10)
            files_dict.pop(filename)
            print(f'{filename} downloaded')
            sa_mg_reconcil.df_reconcillation(d)
           
        except Exception as e:
            print(e.args)
            print(f"error downloading file ,{e}")
            logging.info(f"{filename} File download failed at %s",(datetime.datetime.now()).strftime("%c"))
            dnld_status = "Failed"
            time.sleep(30)
    
    return files_dict

def main(nd):
    '''It iterates over files_dict and for each file in the files_dict it reads
    the token and downloads file and once the files_dict is empty it stops'''
    d=datetime.datetime.today().date()-datetime.timedelta(nd)
    print (d)  
    if process_run_check(d) == -1:
        print ("holiday; skipping for current day")
        return -1
    
    logging.info("Start processing {}".format(d))
    d1=next_working_day(d)  
    logging.info("Next working day {}".format(d1))
    
    while True: 
            if os.path.exists(os.path.join(clientmaster_path,'10.223.104.51_{}.mnm.csv'.format(d.strftime("%d%b%Y")))):
                print ("clientmaster file present") 
                break            
            else :
                print ("clientmaster file not present in path")
                print ("Sleep for 5 min")
                time.sleep(300) 
        
    risk_path=os.path.join(dnld_dir,datetime.datetime.strftime(d,"%d%m%Y"))
    
    if not os.path.exists(risk_path):          
       os.mkdir(risk_path)
       logging.info("Writing files to path {}".format(risk_path))
         # EXTRANET_dnld/FO/Reports/ F_SA04_08081_ddmmyyyy.lis.gz
    files_dict={"F_SA04_08081_{}.lis.gz".format(datetime.datetime.strftime(d,"%d%m%Y")):["FO","Reports"],
                "C_SA04_08081_{}.lis.gz".format(datetime.datetime.strftime(d,"%d%m%Y")):["CM","Reports"],
                "F_MG13_08081_{}.lis.gz".format(datetime.datetime.strftime(d,"%d%m%Y")):["FO","Reports"],
                "C_MG13_08081_{}.lis.gz".format(datetime.datetime.strftime(d,"%d%m%Y")):["CM","Reports"]
                }
    
    logging.info("Downloading files from ftp; file count {}".format(len(files_dict)))
    
    tn=datetime.datetime.now()

    while len(files_dict)!=0:
        
        print("--------------------------new iterate--------------------")
        logging.info("--------------------------new iterate--------------------")
        for f in list(files_dict):#.keys():
                print(f)
                get_token()
                token=read_token()
                filename= get_file(d,d1,token,files_dict[f][0],files_dict[f][1],f)
                if filename!=-1:
                    print("sleep for 2 minutes")
#                    time.sleep(120)
                    get_token()
                    token=read_token()
                    files_dict = dnld_file(token,files_dict[f][0],files_dict[f][1],f,risk_path,files_dict,d)
                    mailer.df_reconcillation(d)
#                    update_db.update_lastruntime("sa_mg_reconcil")
        tn=datetime.datetime.now()       
        logging.info("sleep for 30 min") 
        print("sleep for 30 min")                     
        time.sleep(1800)
        
    
        
if __name__=='__main__':
    main(0)