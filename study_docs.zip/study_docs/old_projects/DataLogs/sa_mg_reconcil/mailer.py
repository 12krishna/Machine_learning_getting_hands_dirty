# -*- coding: utf-8 -*-
"""
Created on Fri Jun  2 17:25:58 2023

@author: RupeshR
"""

import pandas as pd
import datetime,time
import os,logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
#import nse_api_downloader

#from project_status_update import project_status_rt as udt
#update_db= udt.postgres_updations()

os.chdir("D:\\DataLogs\\sa_mg_reconcil\\")

master_dir = "D:\\DataLogs\\Master\\"
log_path="D:\\DataLogs\\sa_mg_reconcil\\"
contacts_dir='D:\\DataLogs\\sa_mg_reconcil\\'
clientmaster_path=r"\\172.17.9.22\KSApps\KSTPS\Output\RiskDataDownload\\"
dnld_dir="D:\\DataLogs\\sa_mg_reconcil\\download\\"
output_dir="D:\\DataLogs\\sa_mg_reconcil\\"

# os.chdir("X:\\DataLogs\\sa_mg_reconcil\\")
# master_dir = "X:\\DataLogs\\Master\\"
# log_path="X:\\DataLogs\\sa_mg_reconcil\\Log_foldr\\"
# contacts_dir='X:\\DataLogs\\sa_mg_reconcil\\Output'
# clientmaster_path=r"\\172.17.9.22\KSApps\KSTPS\Output\RiskDataDownload"
# dnld_dir="X:\\DataLogs\\sa_mg_reconcil\\download"
# output_dir="X:\\DataLogs\\sa_mg_reconcil\\Output"


server = '172.17.9.149'; port = 25

mgheader=['Trade date','Client Code','SPAN Margin','Filler','Extreme Loss Margin',
	'Delivery margin','Consolidated crystallized obligation Margin','Total margin',
	'Peak Intra-day margin','Client/Proprietary Flag']	

saheader=['Date','Indicator','Client/UCC Code','Minimum Margin Required',
            'Total Cash Collateral','Total Non-Cash Collateral','Excess Collateral of other segment',	
            'Total value of Collateral','Short Allocation']

todays_date= datetime.datetime.now().date().strftime("%Y%m%d")

logging.basicConfig(filename=os.path.join(log_path,"test_{}.log".format(todays_date)),filemode="w",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")
def dateparse(date):
    '''Func to convert to date time format  '''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date 

holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 



def df_reconcillation(d):
    '''Lookup of client codes in downloaded files on bkc omnesys client master
    '''
    client_master=pd.read_csv(os.path.join(clientmaster_path,'10.223.104.51_{}.mnm.csv'.format(d.strftime("%d%b%Y"))), encoding= 'unicode_escape',header= 0,error_bad_lines=False, delimiter=';')
    client_master=client_master[client_master['54003']=='Activated']
    filedate=datetime.datetime.strftime(d,"%d%m%Y")
    data_dir=os.path.join(dnld_dir,filedate)
    
    if not os.path.exists(data_dir):          
       os.mkdir(data_dir)
    print(data_dir)    
    count=0
    files = [f for f in os.listdir(data_dir)]
    count = len(files)  
    for file in files:
        
        if 'SA04' in file and filedate in file:
            print(file)
            print(count)
            df = pd.read_csv(os.path.join(data_dir,file), compression='gzip' , names=saheader, index_col=False)
            df_reconcil= df.merge(client_master, left_on=['Client/UCC Code'], right_on = ['54001'], how='inner')[df.columns]
            df_reconcil= df_reconcil[df_reconcil['Client/UCC Code'] != '08081']
            print(df_reconcil)
            send_mail(df_reconcil,d,file)
            os.remove(os.path.join(data_dir,file))
                
        elif 'MG13' in file and filedate in file:
            print(file)
            print(count)
            df = pd.read_csv(os.path.join(data_dir,file), compression='gzip' , names=mgheader, index_col=False)
            df_reconcil= df.merge(client_master, left_on=['Client Code'], right_on = ['54001'], how='inner')[df.columns]
            df_reconcil= df_reconcil[df_reconcil['Client Code'] != '08081']
            print(df_reconcil)
            send_mail(df_reconcil,d,file)
            os.remove(os.path.join(data_dir,file)) 
            
        else:
            print(f'Check number of files in {data_dir}.It must be 4.')
            logging.info(f'Check number of files in {data_dir}.It must be 4.')

def send_mail(df, d, file):
    subject = '{} Reconcillation {}'.format(file[:6], d)
    message = '{} common records found in file reconcillation excluding both deactivated accounts and client code 08081'.format('No' if df.empty else '')
    emails = get_contacts(os.path.join(contacts_dir, 'contactscm.txt')) if 'F' not in file else get_contacts(os.path.join(contacts_dir, 'contactsfo.txt'))
    attachment_path = os.path.join(output_dir, '{}_{}.xlsx'.format(file[:6], d))
    MY_ADDRESS = 'KIERiskAnalytics@kotak.com'

    if df.empty:
        process_email(emails=emails, subject=subject, message=message,MY_ADDRESS=MY_ADDRESS)
    else:
        df.to_excel(attachment_path, index=False)
        process_email(emails=emails, subject=subject, attachments=attachment_path,message=message,MY_ADDRESS=MY_ADDRESS)

    logging.info('Descriptive email was sent for {} common records'.format('no' if df.empty else ''))
    print('Descriptive email was sent for {} common records'.format('no' if df.empty else ''))
    
def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """
    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def process_email(**kwargs):  
    '''Function to send email with attachements'''
    MY_ADDRESS = kwargs['MY_ADDRESS']
    print(MY_ADDRESS)
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    s = smtplib.SMTP(host=server, port=port)    
    msg = MIMEMultipart()# create a message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    try:
        msg['Cc']=','.join(kwargs['emails'][1])
    except:
        print ("Problem with CC or BCC")
    msg['Subject']= kwargs['subject']
    if 'attachments' in kwargs.keys():  
        attachment = kwargs['attachments']
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(attachment, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(attachment.split("\\")[-1] ))
        msg.attach(part) 
    message = kwargs['message']
    msg.attach(MIMEText(message, 'plain'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    s.quit()
