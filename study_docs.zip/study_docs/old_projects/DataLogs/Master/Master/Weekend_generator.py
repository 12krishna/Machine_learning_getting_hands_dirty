from datetime import date, timedelta
import pandas as pd

def allsundays(year):
    d = date(year, 1, 1)                   
    d += timedelta(days = 6 - d.weekday())  # First Sunday
    while d.year == year:
        yield d
        d += timedelta(days = 7)
    
def allsaturdays(year):
    d = date(year, 1, 1)                   
    d += timedelta(days = (5 - d.weekday() + 7) % 7)  # First saturday
    while d.year == year:
        yield d
        d += timedelta(days = 7)
    
def weekend_generator(year):
    '''Func to generate dates for weekends'''


    all_weekends = []
    for d in allsaturdays(year):
        all_weekends.append(d)

    df = pd.DataFrame(all_weekends, columns=['weekends'])
    df['remark'] = 'Saturday'

    all_weekends = []
    for d in allsundays(year):
        all_weekends.append(d)

    df1 = pd.DataFrame(all_weekends, columns=['weekends'])
    df1['remark'] = 'Sunday'

    df = df.append(df1, ignore_index=True)
    df.sort_values(by=['weekends'],inplace=True)


    df['weekends'] = df['weekends'].apply(lambda row : row.strftime("%d-%m-%Y"))

    df.to_csv("weekends.csv", index=False)
    
weekend_generator(2022)