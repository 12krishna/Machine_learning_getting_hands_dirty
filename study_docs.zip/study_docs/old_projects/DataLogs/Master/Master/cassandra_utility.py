from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
import pandas as pd
import logging
import sys
import os


logging.basicConfig(
        level=logging.INFO,
        format='%(name)-12s: %(levelname)-8s %(message)s',
        stream=sys.stderr )

#log = logging.getLogger("Cassandra-Util")

#from decimal import Decimal
#import datetime


class CassandraUtil():
    '''
    Utility func to perform cassandra operations 
    e.g. cassandra auth, read, write
    '''
    
    def __init__(self, host, username, password, keyspace):
        self.username = username
        self.password = password
        self.keyspace = keyspace
        self.host = host
        
        
    def pandas_factory(self, colnames, rows):
        ''' Define a pandas factory to read the cassandra data into pandas dataframe: '''
    
        return pd.DataFrame(rows, columns=colnames)
    
    def connect(self):
        '''Func to make cassandra auth connection
        cassandra session object using which read and write operations can be performed'''     
        try:
                
            auth_provider= PlainTextAuthProvider(username=self.username, password=self.password)
            self.cluster = Cluster(self.host, auth_provider=auth_provider)
            self.session = self.cluster.connect(self.keyspace)
            
            logging.info("Connected to Cassandra cluster instance on {} ".format(self.host))
            
        except Exception as e:
            logging.error("Could not connect to cassandra instance on {}".format(self.host))
            logging.error("Error -> {}".format(e))
            
    def close(self):
        '''Close cssandra session connection '''
        
        try:
                
            self.cluster.close()
            logging.info("({}) Connection closed ".format(self.host))
            
        except Exception as e:
            logging.error("Unable to close connection ")
            logging.error("Error -> {}".format(e))
        
    
    def set_pandas_factory(self):
        '''Func to define return format of read values from table as pandas df'''
        
        self.session.row_factory = self.pandas_factory
        self.session.default_fetch_size = None
        
        logging.info("Casandra Read format set to Pandas Factory")
        
        
    def read(self, query ):
        '''Func to read data from cassandra table 
        Arguments: select query to be performed '''
        
        try:
                
            result = self.session.execute(query= query, timeout=None)
            result = result._current_rows
            
            logging.info("Data fetched successfully \n {} rows fetched ".format(len(result)))
            
            return result
        except Exception as e:
            logging.error("Error while fetching data from cassandra ")
            logging.error("Error -> {}".format(e))
            print e
            return -1
        
        
    def write_csv(self, filepath):
        '''Func that calls batch file to dump csv data into cassandra; 
        Arguments: filepath of the batch file for dumping csv data
        '''
        
        if os.system(filepath)==0:
            logging.info("Data successfully written to cassandra table")
        else:
            logging.error("Error in dumping csv data")
            
        
   