# -*- coding: utf-8 -*-
"""
Created on Tue Mar 23 11:24:46 2021

@author: krishna
"""

import pandas as pd

master_dir="D:\\Master\\"

newdf = pd.read_excel(master_dir+"bse500raw.xlsx")
newdf.rename(columns={'ISIN No.':'ISIN','Scrip Code':'BSE Code'}, inplace=True)
scripmaster = pd.read_csv(master_dir+"scripmaster.csv", names = ['NseSymbol','BseSymbol','UnnamedField3',
                                'Company Name','UnnamedField5','UnnamedField6','ISIN','RICNse','Sedol',
                                'RICBse','UnnamedField11','BseTicker','NseTicker','UnnamedField14','NfoTicker'],
                        encoding="ISO-8859-1",header=None)

df = newdf.merge(scripmaster, on=['ISIN'], how='left')
df = df[['BSE Code','NseSymbol','RICBse','BseTicker','ISIN']]
df['Series'] = 'EQ'
df['BseTicker'] = df['BseTicker']+" IN"
df.rename(columns={'RICBse':'Reuters','BseTicker':'Bloomberg','NseSymbol':'NSE Symbol','ISIN':'ISIN NO'}, inplace=True)
df.to_excel(master_dir+"BSE_500_tickers.xlsx", index=False)