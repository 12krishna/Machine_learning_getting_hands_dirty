# -*- coding: utf-8 -*-
"""
Created on Thu Jun  1 15:12:07 2023

@author: Administrator
"""

import os
import pandas as pd
import numpy as np
import datetime
from dateutil.relativedelta import relativedelta
import time
from collections import OrderedDict
import sys
import logging
import warnings
warnings.filterwarnings("ignore")
import ConfigParser
from cassandra.cluster import Cluster
import email_utility
# load config details
config_parser = ConfigParser.ConfigParserUtility(os.path.join(os.getcwd(), "config.txt"))
config_props_dict = config_parser.parse_configfile()


server = '172.17.9.149'; port = 25
MY_ADDRESS = 'MLPFixReport@kotak.com'
_font_style = "calibri"
_header_style = "color:firebrick;font-weight: bold;font-family:{};font-size:10pt".format(_font_style)

# log events in debug mode 
logging.basicConfig(filename=config_props_dict['log_dir'].strip()+"fixorders_test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(os.path.join(config_props_dict['master_dir'].strip(),"config.txt"),'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(os.path.join(config_props_dict['master_dir'].strip(), 'Holidays_2019.txt'), delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print ("working day wait file is getting downloaded")
        return 1   
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1
    
def read_instrument():
    
    instru = pd.read_csv(os.path.join(config_props_dict['instru_dir'].strip(), "instrument.csv"))
    instru = instru[(instru['ExchangeSegment']=='NSE')]
    
    # get nse symbols
    scripmaster = pd.read_csv(os.path.join(config_props_dict['scripmaster_dir'].strip(), "scripmaster.csv"), 
                              names = ['Symbol','BseSymbol','UnnamedField3','Company Name','UnnamedField5','UnnamedField6',
                                       'ISIN','RICNse','Sedol','RICBse','UnnamedField11','BseTicker','NseTicker','UnnamedField14','NfoTicker'] )
    scripmaster = scripmaster[['Symbol','NseTicker']]
    instru = instru.merge(scripmaster, on=['Symbol'], how='left')
    instru = instru[['Symbol', 'NseTicker','PreviousClose']]
    instru.dropna(inplace=True)
    instru['NseTicker'] = instru['NseTicker'].apply(lambda row: row[1:])
    logging.info("Instrument file read successfully ...")
    
    return instru

 
def is_data_available(session, tablename, columnname, d):
    
    rows = session.execute("select {} from  {} where  {}>='{}' allow filtering;".format( 
            columnname, tablename,columnname, d - datetime.timedelta(days=7)), timeout=None) 
    rows = rows._current_rows
    rows = rows[columnname].drop_duplicates()
    if d in rows.values:
        print ("Data present in {}".format(tablename))
        return 1
    else :
        print ("Data not present for {}".format(tablename))
        return -1
    
def check_data(session, tables, d):
    
    for table, columnname in tables.items():
        while True:
            check = is_data_available(session, table, columnname, d)
            if check==-1:   # provide tablename, columnname and date 
                print ("Sleep for 1 min")
                time.sleep(60)
            elif check==1:
                break             
    
    return 1


    
def fetch_security_delivery(d, tag115):
    
    #cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()
    
    session = cluster.connect('rohit')
    session.row_factory = pandas_factory
    session.default_fetch_size = None    
    
    # check if today's data is present in cassandra table
    check_data(session, {"nse_security_wise_delivery": "trade_date"}, d.date())
    # get security data
    del_df = session.execute("select * from  {} where  {}='{}' allow filtering;".format( 
            "nse_security_wise_delivery","trade_date", d.date()), timeout=None)._current_rows
    del_df = del_df[del_df['series']=='EQ']
    del_df = del_df[['name_of_security', 'quantity_traded','deliverable_quantity_gross_client_level','deliverable_quantity_to_traded_quantity_percent']]
    del_df.columns = ['Symbol', 'Traded Qty', 'Delivered Qty', 'Delivery %']
    del_df['Traded Qty'] = del_df['Traded Qty'].astype(int)
    del_df['Delivered Qty'] = del_df['Delivered Qty'].astype(int)
    del_df['Delivery %'] = del_df['Delivery %'].astype(float)
    
    # get instrument file
    instru = read_instrument()
    
    df = pd.read_csv(os.path.join(config_props_dict['output_dir'].strip(), "ETSOrders.txt"))
    email_tagwise_dict = {}
    for t115 in tag115:
        temp = df[df['Tag115']==t115][['Symbol']].drop_duplicates()
        temp.columns = ['NseTicker']
        if temp.empty==False:
            temp = temp.merge(instru, on=['NseTicker'], how="left")
            temp = temp.merge(del_df, on=['Symbol'], how="left")
            email_tagwise_dict[t115] = temp
                        
    return email_tagwise_dict, d
        
def write_html_data(html_string, tag115, d):
    
    outputpathfile = os.path.join(config_props_dict['delivery_output'].strip(), "output_{}_{}.html".format(tag115, d))
    
    with open(outputpathfile,'w') as f:
        f.write(html_string)

    output_file = open(outputpathfile, 'r').read().replace("&lt;","<").replace("&gt;",">")
    output_file = output_file.replace("dataframe mystyle","mystyle")
    output_file = output_file.replace('<td>text','<td class="text">')

    with open(outputpathfile, 'w') as f:
        f.write(output_file)
        
    return outputpathfile

    

def gen_output(email_tagwise_dict, d):
    
    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>
            
    # format output and create excel file
    for tag115, table in email_tagwise_dict.items():
        df = table.copy(deep=True)
        df.drop(columns=['Symbol', 'PreviousClose'], inplace=True)
        df.rename(columns={'NseTicker':'BBG'}, inplace=True)
        df['Delivery %'] = df['Delivery %'].fillna(0).apply(lambda row: f"{int(round(float(row)))}%" )
        for col in ['Traded Qty', 'Delivered Qty']:
            df[col] = df[col].fillna(0).astype(int)
            df[col] = np.where((df[col]>=10000) & (df[col]<=999000), df[col].apply(lambda row: f"{int(round(row/1000, 0))}k"),
                              np.where(df[col]>=10**6, df[col].apply(lambda row: f"{round(row/10**6, 2)}mn"), 
                                df[col].apply(lambda row: str(row))))
        df['BBG'] = "text"+df['BBG']
    
        # send email
        # output
        msg_string = '<div style="font-family:{};font-size:10pt">\
            <p style=\"{}\">{} - Security wise delivery</p>'.format(_font_style, _header_style,tag115)
        df = df.to_html(classes='mystyle', index=False).replace(
                                            '<table border="1" class="dataframe mystyle">',
                                            '<table border="1" class="mystyle">')    
        msg_string += "<table><tr><td valign='top'>{}</td></tr></table>".format(df)
        
        msg_string = "<html><head><style>{css_style}</style></head><body>".format(css_style = open(os.path.join(config_props_dict['css_style_dir'].strip(),
                                          "df_style.css"), 'r').read()) + msg_string + "</body></html>"
                                         
        #create html file
        outputpathfile = write_html_data(msg_string, tag115, d)
        # send html email
        email_utility.process_status_email(contactspath = os.path.join(os.getcwd(), "contacts.txt"),
                                           subject = f"{tag115} security delivery", 
                                           msg_body = outputpathfile)
        
    
def main(nd):
    
    d = datetime.datetime.now()-datetime.timedelta(nd)

    if process_run_check(d.date()) == -1:
        #update_db.update_lastruntime("ets_desk_orders")
        return -1

    email_tagwise_dict, d = fetch_security_delivery(d, tag115=['AXISSOR', 'HDFCMFSOR'])
    # gen output
    gen_output(email_tagwise_dict, d.date())
    
if __name__=="__main__":
    main(0)
