from cx_Freeze import setup, Executable 


options = {'build_exe': {'packages': ['pkg_resources._vendor','numpy'],
                         'include_files':['D:\Anaconda\Lib\site-packages\mkl_intel_thread.dll']
                         } }

setup(name = "disk_usage" , 
       version = "1.0" , 
       description = "" ,
       options = options,  
       executables = [Executable("disk_usage.py")])