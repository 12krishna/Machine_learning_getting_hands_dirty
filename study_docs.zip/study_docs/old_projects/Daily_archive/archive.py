import os 
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from string import Template
server = '172.17.9.149'; port = 25
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'



def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """
    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails





def process_status_email():
    '''Func to send daily emails after the data is dumped'''
    
    emails = get_contacts('D:\\Daily_archive\\contacts.txt') # read contacts
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)    
    

    # set up the SMTP server
    s = smtplib.SMTP(server, port)    
    # For each contact, send the email:
    #message = message_template.substitute(PERSON_NAME=email[0].title())
        
        
    msg = MIMEMultipart('alternative')       # create a message       
    
        # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])    
            
    msg['Subject']="Daily archive"
            
    # add in the message body
    msg.attach(MIMEText("D drive successfully archived on 141 server. \n Source \\172.17.9.182\\D: \n Destination \\172.17.9.141\\Archive_Data\\KITS\\Windows_backup\\172.17.9.182\\ \n\n Postgres backup for NSE-FNO db done!","plain"))   
    #msg.attach(MIMEText('This is an auto generated email!', 'plain'))
   
    # send the message via the server set up earlier.
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    del msg
        
    # Terminate the SMTP session and close the connection
    s.quit()


# take postgres dump 
postgres_check = os.system("D:\\Daily_archive\\pgsql_backup\\backup.bat")
print "postgress"
print postgres_check
# take pc dump    
check = os.system("D:\\Daily_archive\\archive_data.bat")

print "Status"
print check 
if int(check)==0 and int(postgres_check)==0:
    print "Successfully backup for PC and postgres"
    process_status_email()
    
