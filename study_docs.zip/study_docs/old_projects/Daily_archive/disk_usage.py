import psutil, pandas as pd, smtplib, os, time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from string import Template
server = '172.17.9.149'; port = 25
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'


#os.chdir('D:\Daily_archive')
#curr_dir = os.getcwd()


def read_template(filename):
    """
    Returns a Template object comprising the contents of the 
    file specified by filename.
    """
    
    with open(filename, 'r') as template_file:
        template_file_content = template_file.read()
    return Template(template_file_content)

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """
    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def process_status_email(email_id):
    '''Func to send daily emails after the data is dumped'''
    
    # read the message file
    message_template = open("disk_usage.txt",'rb').read()
    message_template = message_template.replace('<th>','<th style="text-align: center; background-color:#4682B4; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<th colspan="3" halign="left">','<th colspan="3" style="text-align: center; background-color:#4682B4; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<th colspan="2" halign="left">','<th colspan="2" style="text-align: center; background-color:#4682B4; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<th colspan="4" halign="left">','<th colspan="4" style="text-align: center; background-color:#4682B4; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<tbody>','<tbody style="text-align: right; font-family: Calibri; border-color:#FFFFFF;">')
    #message_template = message_template.replace('</table></body><html>','</table></div></body><html>')
    
    emails = get_contacts('contacts.txt') # read contacts
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)    
    

    # set up the SMTP server
    s = smtplib.SMTP(server, port)    
    # For each contact, send the email:
    #message = message_template.substitute(PERSON_NAME=email[0].title())
        
        
    msg = MIMEMultipart('alternative')       # create a message       
    
        # setup the parameters of the message
    msg['From']=email_id
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])    
            
    msg['Subject']="Disk usage 172.17.9.182"
            
    # add in the message body
    msg.attach(MIMEText(message_template, 'html'))   
    #msg.attach(MIMEText('This is an auto generated email!', 'plain'))
   
    # send the message via the server set up earlier.
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    del msg
        
    # Terminate the SMTP session and close the connection
    s.quit()


def highlight_greaterthan(s, threshold, column):
    is_max = pd.Series(data=False, index=s.index)
    is_max[column] = s.loc[column] >= threshold
    return ['background-color: red' if is_max.any() else '' for v in is_max]






def disk_usage():
    '''Func to get the disk usage status'''
    
    params = open("params.txt", "r").readlines()
    email_id = MY_ADDRESS; threshold = 70
    try:
        email_id = params[0].split(":")[1].strip()
    except:
        pass
    try:
        threshold = int(params[1].split(":")[1].strip())
    except:
        pass
    
    
       
    
    
    result = []
    for part in psutil.disk_partitions():
        if part.fstype == "NTFS":             
            device = part.device
            usage = psutil.disk_usage(part.mountpoint)
            total, used, free, percent = usage.total, usage.used, usage.free, usage.percent
            total, used = "{} {}".format(round(total/1073741824, 3), "GB"), "{} {}".format(round(used/1073741824,3), "GB")
            if free < 1:
                free = "{} {}".format(round(free/1048576,3), "MB") 
            else:
                free = "{} {}".format(round(free/1073741824,3), "GB")
            
            result.append([device, total, used, free, percent])
    result = pd.DataFrame(result, columns=['Drive','Total','Used','Free','Percent used'])
    
    # highlight 
    result = result.style.apply(highlight_greaterthan, threshold=threshold, column=['Percent used'], axis=1)
    
    
    
    
    
    with open('disk_usage.txt', 'wb') as f:
            f.write('<html><head>')
            f.write('</head><body>')
            f.write("<br>***Disk Usage***<br><br>")        
            #f.write('<br>Output<br><br>')
            f.write(result.hide_index().render())
            f.write('</body><html>')
            f.close()
            
    process_status_email(email_id)
            
        
start_time = time.time()

if __name__ == '__main__':
    disk_usage()  # set dollar value and (nd = timedelta) days here 
    
        

end_time = time.time()

print "Execution time: {0} Seconds.... ".format(end_time - start_time)

