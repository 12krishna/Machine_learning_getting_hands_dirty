# -*- coding: utf-8 -*-
"""
Created on Mon May 31 09:55:10 2021

@author: krishna
"""

import numpy as np
import pandas as pd
import os, sys, time
import xlwings as xw
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import datetime
#import logging
import win32api
import re

server = '172.17.9.144'; port = 25

excel_front_end_path = "BO_Sales_EOD.xlsm"
output_dir = os.getcwd()
# for validating an Email
regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'


class Trades_EOD():

    def __init__(self):

        # mock caller for debugging
        xw.Book(excel_front_end_path).set_mock_caller()
        # book instance for reading values from excel file
        self.wb = xw.Book.caller()

        #self.sales_client_mappings = self.get_sales_client_mappings()
        self.read_master()
        self.trades = self.read_trades_file()


    def read(self, sheet_name, cell):

        temp = pd.DataFrame( self.wb.sheets[sheet_name].range(cell).expand('table').value )  # gets contents
        temp.dropna(inplace=True)
        temp.columns = temp.iloc[0,:]
        temp = temp.iloc[1:,:]

        return temp


    def read_master(self):
        '''
        Func to read email mappings
        sales person master
        '''

        # read emails
        emails = self.read("EmailMappings", "A1")
        self.email_id_dict = dict(zip(emails['SALES PERSON'].values.tolist(),
                                      emails['Email_id'].values.tolist()))

        # read sales person master
        sales_person_master = self.read('SalesPersonMaster','A1')

        salesp_final = pd.DataFrame()
        salesp_final = sales_person_master[~sales_person_master['SALES PERSON'].str.contains("/")]
        for salesp in sales_person_master[sales_person_master['SALES PERSON'].str.contains("/")]['SALES PERSON'].unique():
            temp = sales_person_master[sales_person_master['SALES PERSON']==salesp]
            for sp in [s.strip() for s in salesp.split("/")]:
                temp['SALES PERSON'] = sp
                salesp_final = salesp_final.append(temp, ignore_index=True)

        self.sales_person_master = salesp_final

        # read From address and cc address
        self._from_addr = self.wb.sheets['EmailMappings'].range('D2').value
        self._cc_addr = (self.wb.sheets['EmailMappings'].range('E2').value).split(",")



    def read_trades_file(self):
        '''Func to read daily
        positions file EOD
        '''

        # get postions
        df = self.read('Trades','A4')

        df[['Family Code','Direction','Scrip Name']] = df[['Family Code','Direction','Scrip Name']].applymap(lambda row: row.strip())
        df['Direction'] = df['Direction'].str.lower()
        df['Rate'] = (df['Turnover']*10**7)/df['Quantity']
        nse,bse = df[df['Exchange']=='NSE'], df[df['Exchange']=='BSE']
        df = nse.merge(bse, on=['Family Code','Family Name','Direction','Scrip Name'], how='outer', suffixes=('_NSE','_BSE'))
        df['B/S'] = np.where(df['Direction']=='buy','B','S')
        df[['Quantity_NSE','Rate_NSE','Turnover_NSE','Quantity_BSE','Rate_BSE','Turnover_BSE']] = df[['Quantity_NSE','Rate_NSE',
                      'Turnover_NSE','Quantity_BSE','Rate_BSE','Turnover_BSE']].fillna(0)
        df['Total'] = df['Quantity_NSE'] + df['Quantity_BSE']
        df['Avg Rate'] = (df['Quantity_NSE']*df['Rate_NSE'] + df['Quantity_BSE']*df['Rate_BSE'])/df['Total']
        df['TO'] = df['Turnover_NSE'] + df['Turnover_BSE']
        df = df[['Family Code', 'Family Name','Scrip Name','B/S','Quantity_NSE','Rate_NSE',
                 'Quantity_BSE','Rate_BSE','Total','Avg Rate','TO']]


        return df


    def filter_client_trades(self, fcode):

        return self.trades[self.trades['Family Code'].isin(fcode)]

    def send_emails(self):


        for salesp in list(set(self.sales_person_master['SALES PERSON'].values)):
            print (salesp)

            # check if email avialable
            check = self.sales_person_master[self.sales_person_master['SALES PERSON']==salesp]

            if check.empty==False:
                # get email ids
                email_ids = []
                try:
                    email_id = str(self.email_id_dict[salesp])
                    if(re.search(regex, email_id)):
                        email_ids.append(self.email_id_dict[salesp])
                    else:
                        print("Not a valid email; Skipping for {} having email id {}".format(salesp, email_id))
                        continue
                except Exception as e:
                    print "Error for {}".format(salesp)
                    print(e)
                    continue

                print(email_ids)

                # filter trades and send email
                trades = self.filter_client_trades(check['FAMILY CODE'].values.tolist())
                trades = trades[['Family Name','Scrip Name','B/S','Quantity_NSE','Rate_NSE','Quantity_BSE','Rate_BSE',
                                 'Total','Avg Rate','TO']]
                trades.columns = ["Client","Scrips","B/S","Qty","NSE Rate","Qty","BSE Rate","Total","Avg Rate","TO"]

                if trades.empty==False:
                    trades.to_excel(os.path.join(output_dir,"temp.xlsx"), index=False)
                    #send email
                    try:
                        self.email_utility([email_ids], "temp.xlsx", "Sales EOD file")
                    except Exception as e:
                        print(e)


        failed_trades = self.trades[~self.trades['Family Code'].isin(
                            self.sales_person_master['FAMILY CODE'].values.tolist())]

        if failed_trades.empty==False:
            # no recipient for family code
            failed_trades.to_excel(os.path.join(output_dir,"error.xlsx"), index=False)
            try:
                self.email_utility([self._cc_addr], "error.xlsx", "(Error) Sales EOD file")
            except Exception as e:
                print(e)



    def email_utility(self, sales_emails, filename, subject):
        '''Func to send daily report emails excel,
        text or html attachment emails or combination of any formats'''

        # get total email recipients
        rcpt = []
        for email in sales_emails+[self._cc_addr]:
            for i in email:
                rcpt.append(i)

        # set up the SMTP server
        s = smtplib.SMTP(host=server, port=port)

        msg = MIMEMultipart()# create a message
        # setup the parameters of the message, to cc emails
        msg['From']=self._from_addr
        msg['To']=','.join(sales_emails[0])
        try:
            msg['Cc'] = ",".join(self._cc_addr)
        except:
            pass

        '''
        try:
            msg['Cc']=','.join(kwargs['emails'][1])
            msg['Bcc']=','.join(kwargs['emails'][2])
        except:
            print ("Problem with CC or BCC")
        '''

        msg['Subject']= subject + " {}".format(datetime.datetime.now().date())


        # attachments to the email

        part = MIMEBase('application', "vnd.ms-excel")
        with open(os.path.join(output_dir,filename), "rb") as f:
            data = f.read()

        part.set_payload(data)
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="{}"'.format("Sales EOD File.xlsx"))
        msg.attach(part)

        '''
        if 'text_email' in kwargs.keys():
            # read html message file
            message = open(kwargs['text_email'],'rb').read()
            msg.attach(MIMEText(message, 'plain'))
        '''

        s.sendmail(self._from_addr, rcpt, msg.as_string())

        s.quit()

        os.remove(os.path.join(output_dir,filename))


def main():

    trades_obj = Trades_EOD()
    trades_obj.send_emails()

    win32api.MessageBox(trades_obj.wb.app.hwnd, "BO Sales email sent!","Success !")
    


if __name__ == "__main__":
    main()

