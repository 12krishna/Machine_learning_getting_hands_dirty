from cx_Freeze import setup, Executable 


options = {'build_exe': {'packages': ['numpy'],
                         'include_files':['D:\Anaconda\Lib\site-packages\mkl_intel_thread.dll']
                         } }

setup(name = "BO_sales_EOD" , 
       version = "2.0" , 
       description = "" ,
       options = options,  
       executables = [Executable("BO_sales_trade_email.py")])