# -*- coding: utf-8 -*-
"""
Created on Mon May 31 09:55:10 2021

@author: krishna
"""

import numpy as np
import pandas as pd
import os, sys, time
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import datetime
import logging
import win32api
import win32com.client
import re

server = '172.17.9.144'; port = 25 # email server for sdending emails inside and outside kotak domain

excel_front_end_path = "BO_Sales_EOD.xlsm"
output_dir = os.getcwd()
# for validating an Email
regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'
trades_dir = os.getcwd()


logging.basicConfig(filename=os.path.join(os.path.join(output_dir,"Logs"), 
                                          "test_{}.log".format(datetime.datetime.now().date())),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


class Trades_EOD():

    def __init__(self):

        self.read_master()
        self.trades = self.read_trades_file()

    def read(self, sheet_name, cell):

        temp = pd.DataFrame( self.wb.sheets[sheet_name].range(cell).expand('table').value )  # gets contents
        temp.dropna(inplace=True)
        temp.columns = temp.iloc[0,:]
        temp = temp.iloc[1:,:]

        return temp

    def read_master(self):
        '''
        Func to read email mappings
        sales person master
        '''
        # read emails
        try:
            #emails = pd.read_excel("EmailMappings.xlsx")
            #emails.dropna(inplace=True)
            emails = self.password_cracker("EmailMappings.xlsx")
            print "Email mappings file read successfully."
            logging.info("Email mappings file read successfully.")
        except Exception as e:
            logging.error("Error reading email mappings file\nError {}".format(e))
            print e
            print "Error reading email mappings"
            time.sleep(2)
            
        # read From address and cc address
        self._from_addr = emails[emails['SALES PERSON']=='From_addr']['Email_id'].values[0]
        self._error_addr = (emails[emails['SALES PERSON']=='Error_addr']['Email_id'].values[0]).split(",")
        try:
            self._cc_addr = (emails[emails['SALES PERSON']=='Cc_addr']['Email_id'].values[0]).split(",")
            logging.info("CC address set.")
        except Exception as e:
            self._cc_addr = []
            logging.info("No cc emails set")
            print e
            print "No cc address found"
            time.sleep(1)
            
        self.email_id_dict = dict(zip(emails['SALES PERSON'].values.tolist(),
                                      emails['Email_id'].values.tolist()))

        # read sales person master
        try:
            sales_person_master = pd.read_excel(os.path.join(os.getcwd(),"SALES PERSON MASTER.xlsx"))
            sales_person_master.dropna(inplace=True)
            logging.info("Sales person master file read successfully...")
        except Exception as e:
            print e
            print "Error reading sales person master; file format issue"
            logging.error("Error reading sales person master file \nError {}".format(e))
            time.sleep(2)
        
        salesp_final = pd.DataFrame()
        salesp_final = sales_person_master[~sales_person_master['SALES PERSON'].str.contains("/")]
        for salesp in sales_person_master[sales_person_master['SALES PERSON'].str.contains("/")]['SALES PERSON'].unique():
            temp = sales_person_master[sales_person_master['SALES PERSON']==salesp]
            for sp in [s.strip() for s in salesp.split("/")]:
                temp['SALES PERSON'] = sp
                salesp_final = salesp_final.append(temp, ignore_index=True)

        self.sales_person_master = salesp_final
        logging.info("Successfully read email and sales person master files")
        print "Successfully read email and sales person master files"


    def read_trades_file(self):
        '''Func to read daily
        positions file EOD
        '''

        while 1:
                
            if os.path.exists(os.path.join(trades_dir, "Sample Positions.xlsx")):
                    
                # get postions
                try:
                    df = pd.read_excel(os.path.join(trades_dir, "Sample Positions.xlsx"))
                    df.dropna(inplace=True)
                    if "Family Code" not in df.columns:
                        df.columns = df.iloc[0,:]
                        df = df.iloc[1:,:]

                    logging.info("Sample positions for today read ...")
                    break
                except Exception as e:
                    print "Error in reading positions file"
                    print e
                    logging.error("Error reading Sample positions file\n Error : {e}".format(e))
                    time.sleep(3)
            else:
                print "Sample Positions.xlsx file not present on {}".format(os.getcwd())
                time.sleep(60)
                logging.info("Sample positions file not present, sleep for 1 min")
                
        #df = self.read('Trades','A4')

        df[['Family Code','Direction','Scrip Name']] = df[['Family Code','Direction','Scrip Name']].applymap(lambda row: row.strip())
        df['Direction'] = df['Direction'].str.lower()
        df['Rate'] = (df['Turnover']*10**7)/df['Quantity']
        nse,bse = df[df['Exchange']=='NSE'], df[df['Exchange']=='BSE']
        df = nse.merge(bse, on=['Family Code','Family Name','Direction','Scrip Name'], how='outer', suffixes=('_NSE','_BSE'))
        df['B/S'] = np.where((df['Direction']=='buy')|(df['Direction']=='b'),'B','S')
        df[['Quantity_NSE','Rate_NSE','Turnover_NSE','Quantity_BSE','Rate_BSE','Turnover_BSE']] = df[['Quantity_NSE','Rate_NSE',
                      'Turnover_NSE','Quantity_BSE','Rate_BSE','Turnover_BSE']].fillna(0)
        df['Total'] = df['Quantity_NSE'] + df['Quantity_BSE']
        df['Avg Rate'] = (df['Quantity_NSE']*df['Rate_NSE'] + df['Quantity_BSE']*df['Rate_BSE'])/df['Total']
        df['TO'] = df['Turnover_NSE'] + df['Turnover_BSE']
        df = df[['Family Code', 'Family Name','Scrip Name','B/S','Quantity_NSE','Rate_NSE',
                 'Quantity_BSE','Rate_BSE','Total','Avg Rate','TO']]

        logging.info("Success reading sample positions file")
        print "Success reading sample positions file"    
    
        return df


    def filter_client_trades(self, fcode):

        return self.trades[self.trades['Family Code'].isin(fcode)]

    def send_emails(self):


        for salesp in list(set(self.sales_person_master['SALES PERSON'].values)):
            #print (salesp)
            #logging.info("Processing trades for {}".format(salesp))
            # check if email avialable
            check = self.sales_person_master[self.sales_person_master['SALES PERSON']==salesp]

            if check.empty==False:
                # get email ids
                email_ids = []
                try:
                    email_id = str(self.email_id_dict[salesp])
                    if(re.search(regex, email_id)):
                        email_ids.append(self.email_id_dict[salesp])
                        logging.info("Valid email parsed")
                    else:
                        #print "Not a valid email; Skipping for {} having email id {}".format(salesp, email_id)
                        #logging.error("Not a valid email; Skipping for {} having email id {}".format(salesp, email_id))
                        continue
                except Exception as e:
                    #print "Error for {}".format(salesp)
                    print(e)
                    #logging.error("User {} entry not found in email master...".format(salesp))
                    continue

                #print(email_ids)

                # filter trades and send email
                trades = self.filter_client_trades(check['FAMILY CODE'].values.tolist())
                trades = trades[['Family Name','Scrip Name','B/S','Quantity_NSE','Rate_NSE','Quantity_BSE','Rate_BSE',
                                 'Total','Avg Rate','TO']]
                trades.columns = ["Client","Scrips","B/S","Qty","NSE Rate","Qty","BSE Rate","Total","Avg Rate","TO"]

                if trades.empty==False:
                    trades.to_excel(os.path.join(output_dir,"temp.xlsx"), index=False)
                    logging.info("trades filtered")
                    #send email
                    try:
                        logging.info("Sending email")
                        self.email_utility([email_ids], "temp.xlsx", "Test Sales")
                        #logging.info("Email sent to user {}".format(email_ids))
                        #print "Email sent to user {}".format(email_ids)
                    except Exception as e:
                        print(e)
                        logging.error("Email failed \nError {}".format(e))


        failed_trades = self.trades[~self.trades['Family Code'].isin(
                            self.sales_person_master['FAMILY CODE'].values.tolist())]

        if failed_trades.empty==False:
            # no recipient for family code
            failed_trades.to_excel(os.path.join(output_dir,"error.xlsx"), index=False)
            logging.info("Error email sending...")
            try:
                self.email_utility([self._error_addr], "error.xlsx", "(Error) Sales EOD file")
                #logging.info("Error email was sent successfully to {}...".format(self._error_addr))
            except Exception as e:
                print(e)
                logging.error("Error sending email (Error category)")



    def email_utility(self, sales_emails, filename, subject):
        '''Func to send daily report emails excel,
        text or html attachment emails or combination of any formats'''

        # get total email recipients
        rcpt = []
        for email in sales_emails+[self._cc_addr]:
            for i in email:
                rcpt.append(i)

        # set up the SMTP server
        s = smtplib.SMTP(host=server, port=port)

        msg = MIMEMultipart()# create a message
        # setup the parameters of the message, to cc emails
        msg['From']=self._from_addr
        msg['To']=','.join(sales_emails[0])
        try:
            msg['Cc'] = ",".join(self._cc_addr)
        except:
            pass

        '''
        try:
            msg['Cc']=','.join(kwargs['emails'][1])
            msg['Bcc']=','.join(kwargs['emails'][2])
        except:
            print ("Problem with CC or BCC")
        '''

        msg['Subject']= subject + " {}".format(datetime.datetime.now().date())


        # attachments to the email

        part = MIMEBase('application', "vnd.ms-excel")
        with open(os.path.join(output_dir,filename), "rb") as f:
            data = f.read()

        part.set_payload(data)
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="{}"'.format("Sales EOD File.xlsx"))
        msg.attach(part)

        '''
        if 'text_email' in kwargs.keys():
            # read html message file
            message = open(kwargs['text_email'],'rb').read()
            msg.attach(MIMEText(message, 'plain'))
        '''
        
        s.sendmail(self._from_addr, rcpt, msg.as_string())
        s.quit()
        os.remove(os.path.join(output_dir,filename))

    def password_cracker(self, filename):
        '''Func to crack excel password'''
        #win32com to crack password 
        xlApp = win32com.client.Dispatch("Excel.Application")
        print "Password cracking attempt ; curr dir {}".format(os.getcwd())
        xlwb = xlApp.Workbooks.Open(os.path.join(os.getcwd(),filename), True, True, None, 'SP#1', 'SP#1')
        print "Success"
                                    # xlwb = xlApp.Workbooks.Open(filename)
        xlws = xlwb.Sheets(1) # counts from 1, not from 0
        content = xlws.Range("A:B").Value 
        # Transfer content to pandas dataframe
        dataframe = pd.DataFrame(list(content))
        dataframe.dropna(how='all', inplace=True)
        # create header
        dataframe.columns = dataframe.iloc[0]
        dataframe = dataframe.reindex(dataframe.index.drop(0))
        xlwb.Close()
        
        return dataframe  


def main():

    trades_obj = Trades_EOD()
    trades_obj.send_emails()
    print("\n\nSuccess: Emails sent")
    logging.info("All emails were sent")
    try:
        os.remove(os.path.join(trades_dir, "Sample Positions.xlsx"))
        print "Sample positions file deleted for today"
        logging.info("Sample positions file deleted for today")
    except Exception as e:
        print e
        logging.error("File could not be deleted...")
    time.sleep(5)
    

if __name__ == "__main__":
    main()