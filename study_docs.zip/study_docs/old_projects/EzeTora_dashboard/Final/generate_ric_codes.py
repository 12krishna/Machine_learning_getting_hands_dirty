import pandas as pd
import os
from utils import reading_components
from generation import ric_code_genration, files_genration
import logging
import datetime
import psycopg2
import datetime
from project_status_update import project_status_rt as udt
update_db= udt.postgres_updations()

update_db.update_status("generate_ric_codes")

todays_date= datetime.datetime.now().date().strftime("%Y%m%d")
try:
    os.makedirs(os.path.join(os.getcwd(), "Log_foldr", todays_date))
except:
    print ("Error Creating Dir: Cant create dir when already Present")
    pass
log_path=os.path.join(os.getcwd(),"Log_foldr", todays_date)


logging.basicConfig(filename=os.path.join(log_path,"starwar_fil_genration.log"),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")



#reading json configs
json_name= os.path.basename(__file__).split(".")[0] + ".json"
json_dict= reading_components.config_json(json_name)
logging.info("Reading Json Components and deriving all paths")

#reading required input files
master_path= json_dict["path"]["master"]
data_path= json_dict["path"]["data_path"]
fut_code= json_dict["optn_fut_code"]["month_fut_code"]
opt_code= json_dict["optn_fut_code"]["month_opt_code"]
month_code= json_dict["optn_fut_code"]["month_int_code"]

logging.info("Reading today's contact.txt")
contract = pd.read_csv(os.path.join(data_path,"contract.txt"), sep="|", skiprows= 1, header=None )
contract.dropna(axis=1, how='all', inplace= True)
contract.columns = list(range(0,contract.shape[1]))
# contract= contract.iloc[:,[3,5,6,7,48]]
contract= contract.iloc[:,[3,6,7,48]]
contract = contract[contract[3].notna()]
# contract["jiffy_days"]= ((contract[5])/86400).astype(int)
# contract["expiry_jiffy"]= contract["jiffy_days"].apply(lambda x: datetime.date(1980, 1,1)+ datetime.timedelta(days=x))
# contract.drop([5,"jiffy_days"], axis=1, inplace=True)
logging.info("len of contacts {}".format(contract.shape[0]))

logging.info("Reading scripmaster...")
scripmaster = pd.read_csv(os.path.join(data_path,"scripmaster.csv"), header=None,encoding='cp1252')
scripmaster = scripmaster.iloc[:,[0,7]]
scripmaster= scripmaster.drop_duplicates()
scripmaster= scripmaster[scripmaster[0].notna()]

logging.info("Index Ric...")
indx_ric= pd.read_csv(os.path.join(data_path,"index_ric.txt"),  sep="|",header=None)
indx_ric.columns = ["ric", "indx"]




##################################################################################################################
# calling generation.py and starting the process
##################################################################################################################

logging.info("Seprating Stocks and index in different variable from main file")

fil_g = files_genration(indx_ric, scripmaster, contract)
df= fil_g.final_df_creation()
stock_df= fil_g.ric_code_stock()
indx_df= fil_g.ric_code_indx()


logging.info("For a given contact file for today having shape : {}, {} row is stock informnation and {} is of"
             "index".format(contract.shape[0], stock_df.shape[0], indx_df.shape[0]))


ric_g = ric_code_genration(indx_ric, scripmaster, contract, fut_code, opt_code,month_code)
indx_ric_df= ric_g.indx_df_process()
logging.info("Preprocessing..len of index rows after preprocessing is {} comparted to previos rows {}".format(indx_ric_df.shape[0], indx_df.shape[0]))
stock_ric_df = ric_g.stock_df_process()
logging.info("Preprocessing..len of stock rows after preprocessing is {} comparted to previos rows {}".format(stock_ric_df.shape[0], stock_df.shape[0]))


final_df= pd.concat([indx_ric_df,stock_ric_df], axis=0)
logging.info("Final View: Initial rows {} vs Final rows {} ".format(contract.shape[0], final_df.shape[0]))

dic_source = fil_g.generate_dico_source()
dic_source['NSE SYMBOL']= final_df["strike_detail"]
dic_source["Reuters"] = final_df["Reuters"]
dic_source.to_csv(os.path.join(master_path, "Output","ric_source.csv" ), index= False)

logging.info("Process is finised and csv file has ben dumped in the given resp folder")
logging.shutdown()

update_db.update_lastruntime("generate_ric_codes")

