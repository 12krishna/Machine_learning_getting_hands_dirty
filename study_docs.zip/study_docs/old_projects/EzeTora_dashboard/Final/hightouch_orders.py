# -*- coding: utf-8 -*-
"""
Created on Thu Apr 21 18:23:19 2022

@author: krishna
"""

import os, shutil
import re
import pandas as pd
import numpy as np
import string
import simplefix
from decimal import Decimal
import datetime
from dateutil.relativedelta import relativedelta
import time
from collections import OrderedDict
import sys
import logging
import warnings
import redis
warnings.filterwarnings("ignore")

#_dma_accounts = ['MCPDAD','MCPDAR']
server = '172.17.9.149'; port = 25
MY_ADDRESS = 'MLPFixReport@kotak.com'
_redis_ip = "10.223.104.61" #UAT->"10.223.105.69", PROD-> "10.223.104.61"
_redis_port = 6379
_dma_accountids = ['MCPDAD','MCPDAR']
# set dependency paths here
if sys.platform not in ('win32', 'cygwin', 'cli'):
    output_dir = '/ExchangeFIXTrades_DP/' # r"\\172.17.9.22\Users\ExchangeFIXBOTrades"
    vwap_dir = "/LogReports/Vwap/"
    bhav_dir = "/home/hadoop/GenInstrument/dataFiles/"
    input_dir = "/home/hadoop/EzeTora_dashboard/"
else:
    output_dir = r"\\172.17.9.22\Users\ExchangeFIXTrades_DP"
    vwap_dir = r"\\172.17.9.51\LogReport\Vwap"
    bhav_dir = "D:\\MLP_ExFIX\\"
    input_dir = "D:\\EzeTora_dashboard\\"
    
# log events in debug mode 
logging.basicConfig(filename="fixorders_hightouch.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

ex_final_cols = ['TradeId','TradeStatus','InstrumentType','Symbol','Expiry','TradingSymbol','Side','Quantity','Average','Account',
                   'Trade_time','Exchange_Order_Id','LotSize','Quantity_Lots','Value']
fix_final_cols = ['MsgType','ClientOrdID','Og_ClientOrdID','ParentOrdID','OrderQty','Account','LastFillTime','ExecutionTime',
                  'RICNse','Symbol','Side','LastPx','LastQty','tag167','tag150','tag39','tag200','ExchTradeId','LotSize','NseSymbol']
cal_months_list = [ (datetime.datetime(2000,1,1)+relativedelta(month=i)).strftime("%b") for i in range(1,13)]    
monthly_codes_fut = OrderedDict(zip(cal_months_list, ['F','G','H','J','K','M','N','Q','U','V','X','Z']))
monthly_call_options = OrderedDict(zip(cal_months_list, [c for c in map(chr, xrange(ord('A'), ord('M')))]))
monthly_put_options = OrderedDict(zip(cal_months_list, [c for c in map(chr, xrange(ord('M'), ord('Y')))]))    
_hightouch_sessions = []
_arrival_pct = 1.005


class FileReader():
    '''Class to read input file 
    keeps running track of file offset
    '''
    def __init__(self, filename, schema):
        self.offset = 0
        self.filename = filename
        self.input_schema = schema
    def read(self, delimiter):
        # read file and process output
        if self.input_schema==None:
            # file with header
            prev_file =  pd.read_csv(self.filename, delimiter=delimiter, 
                                     skiprows=self.offset, converters={i: str for i in range(0, 100)}, 
                                     low_memory=False)# read prev updated file
            self.offset+=len(prev_file)
            return prev_file
        else:
            # file without header; needs file schema
            prev_file =  pd.read_csv(self.filename, header=None, names= self.input_schema,
                                     delimiter=delimiter, skiprows=self.offset, converters={i: str for i in range(0, 100)},
                                     low_memory=False)# read prev updated file
            self.offset+=len(prev_file)
            return prev_file


class OrderMonitoring(object):
    '''UL FIX order monitoring
    '''
    def __init__(self):
        # get tail file reader
        self.expr_4_4 = r'8=FIX\.4\.4.*?[10=\d+\|]$'       # pattern to recognize line with valid excution or order line ;
                                        #match line with pattern 8=FIX.4.2 and ending with 10=number|
        self.expr_4_2 = r'8=FIX\.4\.2.*?[10=\d+\|]$'
        self.px_trunc_pattern = re.compile("^\d+\.\d\d\d\d|^-\d+\.\d\d\d\d")
        self.manual_bookings_cols = ['TRANSTYPE','ORDERID','ACTION','SYMBOL','QTY','PRICE','TD','SD','CNBR','TYP','EXECBROKER','tag1',
                                     'TRADETYPE','STRATEGY']
        self.mlp_recon_cols = ['ClOrdID','Side','Symbol','Trading Tag/Tag1','OrderQty Lots','Executed Qty Lots','Sent on FIX Lots',
                               'Executed minus Order','Executed minus FIX sent','Price Executed','Price Sent Via FIX','Price Gap',
                               'TradeTime','Minutes Back','Order Status']
        self.redis_client = redis.StrictRedis(host=_redis_ip, port=_redis_port, db=0)
        self.sleg_schema = ['ClientOrdID','TradeId','Account','Symbol','Side','MaturityMonthYear','TrackIds']
        self.mleg_schema = ['ClientOrdID','TradeId','Account','Symbol','Side','MaturityMonthYear','L1_Side','L2_Side','L1_MaturityMonthYear',
                             'L2_MaturityMonthYear','TrackIds']
        #'NseAllocatedAvg','NseAllocatedLots','NseAllocatedQty','NseAllocatedVal'
        #'NseSentAvg','NseSentLots','NseSentQty','NseSentVal'
        # read vwap file
        self.vwap_curve = self.read_vwapcurve_file()
        self.prev_close = self.load_bhavcopy()
        self.session_names = pd.DataFrame()
        self.trade_account_ids = self.load_tradeaccounts()
        self._sessionnames = pd.read_csv(os.path.join(input_dir, "Ordermaster_eze_tora.csv"))['Session'].values.tolist()
        
    def load_bhavcopy(self):
        '''
        Reads bhavcopy and gets close prices for all futures contract
        :return: dataframe
        '''
        df = pd.read_csv(os.path.join(bhav_dir, "fobhav.csv"))
        df = df[df['INSTRUMENT'].str.startswith("FUT")][['SYMBOL','EXPIRY_DT','CLOSE']]
        df['EXPIRY_DT'] = df['EXPIRY_DT'].apply(lambda row: datetime.datetime.strptime(row, 
                                              "%d-%b-%Y").strftime("%Y%m") )
        df.columns = ['NseSymbol','expiry','close']
        #df['expiry'] = df['expiry'].astype(int)
        return df
        
    def read_vwapcurve_file(self):
        '''
        Reads VWAP curve file from \\172.17.9.51\LogReport\VWAP
        :return: dataframe
        '''
        vwap_df = pd.read_csv(os.path.join(vwap_dir, "VolumeCurves5min.csv"))
        vwap_df['Volumes'] = vwap_df['Volumes'].apply(lambda row: [ int(re.findall("\d+", x)[0]) for x in row.split(',')]) 
        
        return vwap_df
            
    def load_tradeaccounts(self):
        '''
        load trade accounts from csv file
        :return: dataframe
        '''
        
        accounts_df = pd.read_csv(os.path.join(os.getcwd(), "HT_accountids.csv"))
        result = pd.DataFrame()
        for col in accounts_df.columns:
            temp = accounts_df[[col]]
            temp['Accountname'] = col
            temp.columns = ['Account','Accountname']
            result = result.append(temp, ignore_index=True)
        result.dropna(subset=['Account'], inplace=True)
            
        return result 
    
    def flattern(self, A):
        rt = []
        for i in A:
            if isinstance(i,list): rt.extend(self.flattern(i))
            else: rt.append(i)
        return rt
        
        
    def redis_zset_reader(self, keyname, legtype):
        '''
        func to read high touch trades from redis
        '''
        
        stime = time.time()
        
        result = []
        for  hm_key,_ in self.redis_client.zscan_iter(keyname):
            # get value dict for hmap key from zset
            result.append(self.redis_client.hgetall(hm_key))
                        
        result = pd.DataFrame(result)
        if result.empty==True:
            return pd.DataFrame(columns = self.sleg_schema if legtype=='FUT' else self.mleg_schema)
        
        result = result[result['SecurityType']==legtype] # get only futures order
        if legtype=='FUT':
            result = result[self.sleg_schema]
        elif legtype=='MLEG':
            result = result[self.mleg_schema]
            result['L1_Side'] = np.where(result['Side']=='1','BUY',np.where(result['Side']=='2','SELL',''))
            result['L2_Side'] = np.where(result['Side']=='1','BUY',np.where(result['Side']=='2','SELL',''))
            
        result['ClientOrdID'] = result['ClientOrdID'].apply(lambda row: row if "_" not in str(row) else row.split("_")[1] ) # session_clid
        
        result['Side'] = np.where(result['Side']=='1','BUY',np.where(result['Side']=='2','SELL',''))
        
        print "Reading zset values from redis time {}".format(time.time()-stime)
        logging.info("Redis data rows {}".format(len(result)))
        logging.info("Reading zset values from redis time {}".format(time.time()-stime))
        
        return result
        
        
    def load_redis_data(self):
        
        result = pd.DataFrame()
        # get redis data for single leg
        # get redis parentord id, clid against account symbol
        redis_df = self.redis_zset_reader("ParentOrdersOMM",'FUT') # single leg trades
        redis_df = redis_df[['TrackIds','Symbol','Side','MaturityMonthYear','ClientOrdID','TradeId']]
        redis_df.columns = ['Account','Symbol','Side','Expiry','ClientOrdID','ParentOrdID']
        result = result.append(redis_df, ignore_index=True)
        
        # get mleg data     
        
        redis_df = self.redis_zset_reader("ParentOrdersOMMML",'MLEG')
        if redis_df.empty==False:
            print "Multi leg orders present...."
            logging.info("Multi leg orders present....")
            #print redis_df
            redis_df = redis_df[['TrackIds','Symbol','L1_Side','L1_MaturityMonthYear','L2_Side','L2_MaturityMonthYear','ClientOrdID','TradeId']]
            redis_df = redis_df[['TrackIds','Symbol','L1_Side','L1_MaturityMonthYear','ClientOrdID','TradeId']].rename(
                    columns={'L1_Side':'Side','L1_MaturityMonthYear':'Expiry'}).append(redis_df[['TrackIds','Symbol','L2_Side',
                            'L2_MaturityMonthYear','ClientOrdID','TradeId']].rename(columns={'L2_Side':'Side','L2_MaturityMonthYear':'Expiry'}), ignore_index=True)
            redis_df.columns = ['Account','Symbol','Side','Expiry','ClientOrdID','ParentOrdID']
            result = result.append(redis_df, ignore_index=True)
         
        self.redis_df = result
        
        
    
    def get_ric_code(self, row):
        '''
        gets RIC code from expiry, symbol sent by the client
        :return: string
        '''
        
        expiry = monthly_codes_fut[datetime.datetime.strptime(row['Expiry'], "%Y%m").strftime("%b")] + datetime.datetime.strptime(
                                    row['Expiry'], "%Y%m").strftime("%Y")[-1]        
        try:              
            ric = row['RIC'] # initialize
            if '-' in row['RIC']:
                # multi leg RIC code
                ric = row['RIC'].split("-")[0][:-2]
                ric = ric + expiry + ":NS"
            else:
                # single leg
                ric = row['RIC'] + expiry + ":NS" if row['RIC'] in ['NBN','NIF'] else row['RIC'].split(":")[0] + expiry + ":NS"
            return ric
        except Exception as e:
            print "Error while constructing RIC code; \nError {}".format(e)
            logging.error("Error while constructing RIC code; \nError {}".format(e))
            return row['RIC']
    
    def missing_file_uploader(self, df):
        '''
        func to write all missing records in FIX; but
        present in exchange
        '''
        df['TRANSTYPE'] = "N"
        df['TD'] = df['Trade_time'].apply(lambda row: datetime.datetime.strptime(row, "%d %b %Y %H:%M:%S").strftime('%d-%b-%Y').upper() )
        df['SD'] = ''; df['CNBR'] = ''; df['TYP'] = 'EQ'; df['EXECBROKER'] = ''; df['TRADETYPE'] = ''; df['STRATEGY'] = ''
        
        # get tag167 from fix order file
        df = df.merge(self.fixorders_df[['ParentOrdID','Instrument']], on=['ParentOrdID'], how="left")
        
        df = df[df['Instrument']!='MLEG'].append(df[df['Instrument']=='MLEG'].groupby(
                    by=['ClientOrdID'],sort=False).apply(lambda grp: self.leg_side(grp)))
        df.sort_index(axis=0, inplace=True)
        df.rename(columns = {'ClientOrdID':'ORDERID', 'Side':'ACTION','RIC':'SYMBOL','Quantity_Lots':'QTY',
                             'Account':'tag1','Average':'PRICE'}, inplace=True)
        # reload session names ; consider open orders
        self.session_names = self.session_names.append(self.fixorders_df[['ParentOrdID','Tag49']].rename(columns={'Tag49':'tag56'}),
                                                       ignore_index=True).drop_duplicates()
        df = df.merge(self.session_names, on=['ParentOrdID'], how="left", suffixes=("","_y"))
        df.loc[df['tag56'].isnull(), 'tag56'] = df['tag56_y']
        df['ORDERID'] = df['tag56'].astype(str) + "_" + df['ORDERID'].astype(str)
        
        df=df[self.manual_bookings_cols+['TradeId','LotSize','leg','Exchange_Order_Id','Expiry']]
        df['PRICE'] = df['PRICE'].astype(str).apply(lambda row: row if len(self.px_trunc_pattern.findall(row))==0 else \
                                          self.px_trunc_pattern.findall(row)[0]) # truncate number using regex pattern upto 4 decimal points
        df['Exchange'] = 'NFO'
        
        df.to_csv(os.path.join(output_dir, "missingfills_uploader_ht.csv"), index=False)
    


    def missing_fix_trades(self, df):
        '''Func to get missing fix trades 
        as per client manual booking format
        :return: dataframe
        '''
        
        if 'leg' not in df.columns:
            df['leg'] = np.nan
            
        df['Expiry'] = df['Expiry'].astype(str)
        if df[df['ClientOrdID'].isnull()].empty==False:
            # get clid and parent ord id for missing in fix fills
            df = df.merge(self.redis_df[['Account','Symbol','Side','Expiry','ClientOrdID','ParentOrdID']].drop_duplicates(), 
                          on=['Account','Symbol','Side','Expiry'], how="left", suffixes=('','_y'))
            for col in ['ClientOrdID','ParentOrdID']:
                df.loc[df[col].isnull(), col] = df['{}_y'.format(col)]
                df.drop(columns=['{}_y'.format(col)], inplace=True)
        
        print "Length of cliid null in missing fix trades function {}".format(len(df['ClientOrdID'].isnull()))
        df.dropna(subset=['ClientOrdID'], inplace=True)
        if df.empty==True:
            return pd.DataFrame()
        
        self.read_fixorders_file()  
        df = df.drop(columns=['Account']).merge(self.fixorders_df[['ParentOrdID','Account','RIC']], 
                    on=['ParentOrdID'], how="left")
        # get ric codes as per manual booking format
        #df['RIC'] = df[['RIC','Expiry']].apply(lambda row: self.get_ric_code(row), axis=1)
        df['Expiry1'] = df['Expiry'].apply(lambda row: datetime.datetime.strptime(row, "%Y%m").date()) # to get  min of expiry date
        df[['Quantity_Lots','Average','Quantity']] = df[['Quantity_Lots','Average','Quantity']].apply(pd.to_numeric, errors='coerce').fillna(0) 
        
        try:
            self.missing_file_uploader(df.copy(deep=True))
        except Exception as e:
            print "Error while generating missing fills on FIX ; {}".format(e)        
        
        try:
            df = df.groupby(by=['ClientOrdID','Side'], sort=False).apply(lambda grp: pd.Series({
                    "SYMBOL":grp['Symbol'].values[0], "QTY":grp['Quantity_Lots'].sum(), "PRICE":str(np.average(grp['Average'], 
                    weights=grp['Quantity'].astype(int)) if np.sum(grp['Quantity'].astype(int))!=0 else '0.0000'), 
                    "TD": grp['Trade_time'].min(), 'tag1': grp['Account_fix'].values[0], 'ParentOrdID': grp['ParentOrdID'].values[-1]
                    })).reset_index()
        except Exception as e:
            print "Error in missing records {}".format(e)
            df = df.groupby(by=['ClientOrdID','Side'], sort=False).apply(lambda grp: pd.Series({
                    "SYMBOL":grp['Symbol'].values[0], "QTY":grp['Quantity_Lots'].sum(), "PRICE":str(np.average(grp['Average'], 
                    weights=grp['Quantity'].astype(int)) if np.sum(grp['Quantity'].astype(int))!=0 else '0.0000'), "TD": grp['Trade_time'].min(), 'tag1': grp['Account'].values[0],
                    'ParentOrdID': grp['ParentOrdID'].values[-1]
                    })).reset_index()
            
        # handle multiple replace orders        
        df = df.groupby(by=['ParentOrdID','Side'], sort=False).apply(lambda grp: pd.Series({
                'ClientOrdID':grp['ClientOrdID'].values[-1], 'PRICE': str(np.average(grp['PRICE'].astype(float), weights=grp['QTY'].astype(int)) if np.sum(grp['QTY'].astype(int))!=0 else '0.0000'), 
                'QTY': grp['QTY'].sum(), 'TD': grp['TD'].values[-1], 'tag1': grp['tag1'].values[-1], 'SYMBOL': grp['SYMBOL'].values[-1]
                })).reset_index()
        
        df['TRANSTYPE'] = "N"
        #df['TD'] = df['TD'].apply(lambda row: datetime.datetime.strptime(row, "%d %b %Y %H:%M:%S").strftime('%d-%b-%Y').upper() )
        try:
            df['TD'] = df['TD'].fillna(df[~df['TD'].isnull()]['TD'].values[0]).apply(lambda row: row.upper() )
        except Exception as e:
            print "TD error {}".format(e)
            logging.error("TD error {}".format(e))
            df['TD'] = datetime.datetime.now().strftime('%d-%b-%Y').upper()
        
        df['SD'] = ''; df['CNBR'] = ''; df['TYP'] = 'EQ'; df['EXECBROKER'] = ''; df['TRADETYPE'] = ''; df['STRATEGY'] = ''
        df.rename(columns = {'ClientOrdID':'ORDERID', 'Side':'ACTION'}, inplace=True)
        df=df[self.manual_bookings_cols]
        df['Matching'] = "MISMATCH"
        df['PRICE'] = df['PRICE'].apply(lambda row: row if len(self.px_trunc_pattern.findall(row))==0 else \
                                          self.px_trunc_pattern.findall(row)[0]) # truncate number using regex pattern upto 4 decimal points
    
        return df
    
    def matching_fix_trades(self, df):
        
        #df['Expiry1'] = df['Expiry'].apply(lambda row: datetime.datetime.strptime(row, "%Y%m").date()) # to get  min of expiry date
        df[['Quantity_Lots','Average','Quantity']] = df[['Quantity_Lots','Average','Quantity']].apply(pd.to_numeric, errors='coerce').fillna(0) 
        
        df = df.groupby(by=['ClientOrdID','Side']).apply(lambda grp: pd.Series({
                    "SYMBOL":grp['RICNse'].values[0], "QTY":grp['Quantity_Lots'].sum(), "PRICE":np.average(grp['Average'], 
                    weights=grp['Quantity_Lots'].astype(int) if np.sum(grp['Quantity_Lots'].astype(int))!=0 else 0), "TD": grp['TD'].min(), 'tag1': grp['Account_fix'].values[0],
                    'ParentOrdID': grp['ParentOrdID'].values[-1]
                    })).reset_index()
        
        # handle multiple replace orders        
        df = df.groupby(by=['ParentOrdID','Side']).apply(lambda grp: pd.Series({
                'ClientOrdID':grp['ClientOrdID'].values[-1], 'PRICE': str(np.average(grp['PRICE'], weights=grp['QTY']) if np.sum(grp['QTY'])!=0 else '0.0000'), 
                'QTY': grp['QTY'].sum(), 'TD': grp['TD'].values[-1], 'tag1': grp['tag1'].values[-1], 'SYMBOL': grp['SYMBOL'].values[-1]
                })).reset_index()
                
        df['TRANSTYPE'] = "N"
        df['TD'] = df['TD'].apply(lambda row: row.upper() )
        df['SD'] = ''; df['CNBR'] = ''; df['TYP'] = 'EQ'; df['EXECBROKER'] = ''; df['TRADETYPE'] = ''; df['STRATEGY'] = ''
        df.rename(columns = {'ClientOrdID':'ORDERID', 'Side':'ACTION'}, inplace=True)
        df=df[self.manual_bookings_cols]
        df['Matching'] = "MATCH"
        df['PRICE'] = df['PRICE'].apply(lambda row: row if len(self.px_trunc_pattern.findall(row))==0 else \
                                          self.px_trunc_pattern.findall(row)[0]) # truncate number using regex pattern upto 4 decimal points
        return df
    
    def get_open_orders(self):
        '''
        get orders that are open and awaiting execution
        '''
        
        temp = self.fixorders_df
        mask_condition = (temp['ExecutedQty']==0)
        df = temp[mask_condition][['ClientOrdID','Side','RIC','Symbol','OrderQty','Account','LastFillTime',
                 'State','OrdType','LimitPrice','expiry']]
        df.columns = ['ClOrdID','Side','Symbol','NseSymbol','OrderQty Lots','Trading Tag/Tag1',
                      'TradeTime','Order Status','OrdType','LimitPrice','expiry']
        for col in ['Executed Qty Lots','Sent on FIX Lots','Price Executed','Price Sent Via FIX','Price Gap']:
            df[col] = 0
        df['Executed minus Order'] = df['Executed Qty Lots'] - df['OrderQty Lots']
        df['Executed minus FIX sent'] = df['Executed Qty Lots'] - df['Sent on FIX Lots']
        df['Minutes Back'] = pd.to_datetime(df['TradeTime'], errors="coerce").apply(lambda row: 
                                (datetime.datetime.now() - row).total_seconds()/60 if str(row)!='NaT' else 0)
        
        return df
    
    def read_fixorders_file(self):
        
        fixorders_df = pd.read_csv(os.path.join(output_dir, "fix_orders.txt"))
        #fixorders_df = fixorders_df[(fixorders_df['Tag21']==3)&(fixorders_df['State']!='Rejected')]
        fixorders_df = fixorders_df[(fixorders_df['Algorithm']=='None')]
        fixorders_df.loc[fixorders_df['State'].isin(['Cancelled','DoneForTheDay']), 'OrderQty'] = fixorders_df['ExecutedQty']
        
        self.fixorders_df = fixorders_df
        
    def get_status(self, row):
        '''
        get status of order fills
        '''
        if row['Executed minus FIX sent']>0:
            return 'Unsent on fix'
        elif row['Executed minus Order']<0:
            return 'Incomplete'
        elif row['Executed minus Order']>0:
            return 'Excess Executed'
        elif row['Price Gap']>0:
            return 'Wrong Price'
        else:
            return 'Match'
        
    def replace_orders_mlprecon(self, grp):
        
        rt = grp.tail(1)#grp[grp['Executed Qty Lots']==grp['Executed Qty Lots'].max()].tail(1)
        rt['Price Executed'] = str(np.average(grp['Price Executed'].astype(float), weights=grp['Executed Qty Lots'].astype(int)) if np.sum(grp['Executed Qty Lots'].astype(int))!=0 else '0.0000')
        rt['Price Sent Via FIX'] = str(np.average(grp['Price Sent Via FIX'].astype(float), weights=grp['Sent on FIX Lots'].astype(int)) if np.sum(grp['Sent on FIX Lots'].astype(int))!=0 else '0.0000')
        rt['Executed Qty Lots'] = grp['Executed Qty Lots'].sum()
        rt['Sent on FIX Lots'] = grp['Sent on FIX Lots'].sum()
        
        rt['Executed minus Order'] = rt['Executed Qty Lots'] - rt['OrderQty Lots']
        rt['Executed minus FIX sent'] = rt['Executed Qty Lots'] - rt['Sent on FIX Lots']
        rt['Price Gap'] = rt[['Price Executed','Price Sent Via FIX']].apply(lambda row: float(row['Price Executed'])-float(row['Price Sent Via FIX']), axis=1)
        rt['TradeTime'] = rt['TradeTime']
        return rt
                
    def vwap_summation(self, symbol, stime, etime, order_qty):
        '''
        gets summation of qty as per vwap curve
        btwn stime and etime
        :return: float
        '''
        try:
            stime_index = int((pd.to_datetime(stime)-pd.to_datetime('9:15:00')).total_seconds()/(60*5))
            etime_index = int((pd.to_datetime(etime)-pd.to_datetime('9:15:00')).total_seconds()/(60*5))
            curr_index = int((datetime.datetime.now()-pd.to_datetime('9:15:00')).total_seconds()/(60*5))
            curr_index = 75 if curr_index>75 else curr_index
            #print symbol, stime_index, etime_index, curr_index
            temp = self.vwap_curve[self.vwap_curve['Symbol']==symbol]['Volumes'].tolist()[0][
                    stime_index-1 if stime_index!=0 else stime_index :etime_index]
            total_vol = np.sum(temp)
            #print symbol, order_qty, total_vol, temp
            if curr_index>=stime_index:
                return round(np.sum([(float(i)/total_vol)*order_qty for i in temp[:(curr_index-stime_index)+1]]))
            else:
                return 0.0
            #a = np.sum(self.vwap_curve[self.vwap_curve['Symbol']==symbol]['Volumes'].tolist()[0][stime_index:curr_index])
            #b = np.sum(self.vwap_curve[self.vwap_curve['Symbol']==symbol]['Volumes'].tolist()[0][stime_index:etime_index])
            
            #return float(a)/float(b)
                    
        except Exception as e:
            #print "Symbol not found in VWAP curves file...Error : {}".format(e)
            logging.error("Symbol not found in VWAP curves file...Error : {}".format(e))
            return 0.0
    
    def twap_deviation(self, row):
        '''
        func to get TWAP deviations for algo
        i.e. expected TWAP quantity vs actual by algo
        :return: float
        '''
        now = datetime.datetime.now()
        if now.time()<pd.to_datetime(row['StartTime']).time():
            return 0.0
        elif now.time()<=datetime.time(15,30):
            return row['OrderQty Lots']*(((now if pd.to_datetime(row['EndTime'])>now else pd.to_datetime(row['EndTime'])) -\
                      pd.to_datetime(row['StartTime']))/(pd.to_datetime(row['EndTime']) - pd.to_datetime(row['StartTime'])))
        else:
            return row['OrderQty Lots']*((pd.to_datetime(row['EndTime']) - pd.to_datetime(row['StartTime']))/\
                                        (pd.to_datetime(row['EndTime']) - pd.to_datetime(row['StartTime'])))
            
    def deviation_from_prevclose(self, df):
        '''
        gets deviation of executed price 
        against close price from bhavcopy
        :return: dataframe
        '''
        df['expiry_temp'] = df['expiry'].apply(lambda s: str(s).split(".")[0] )
        df = df.merge(self.prev_close.rename(columns={'expiry':'expiry_temp'}), 
                                             on=['NseSymbol','expiry_temp'], how="left")
        df.loc[df['OrdType']=='LMT', 'LMT from prevClose %'] = (df['LimitPrice']-df['close'])/df['close']*100
        df.drop(columns=['expiry_temp'], inplace=True)
        
        return df
        
    
    def get_algo_deviations(self, df, pre_open_flag):
        '''func to get algo deviations
        for various parameters; closeprice, arrival price, TWAP, VWAP
        :return: dataframe        
        '''
        if pre_open_flag==1:
            df = df.merge(self.fixorders_df[['ClientOrdID','Algorithm']].drop_duplicates().rename(columns={'ClientOrdID':'ClOrdID'}),
                          on=['ClOrdID'], how="left")
            for col in ['Expected Exec in lots','Slippage in Lots','Slippage in %','LMT from prevClose %',
                        'Arrival px','LTP vs Arrival px %','avg px vs Arrival px %']:
                df[col] = 0
            return df
                        
        # read vwap file
        df = df.merge(self.fixorders_df[['ParentOrdID','StartTime','EndTime','Algorithm']].drop_duplicates(), 
                      on=['ParentOrdID'], how="left")
        
        if df[df['Algorithm'].isnull()].empty==False:
            df = df.merge(self.fixorders_df[['ClientOrdID','Side','Algorithm','StartTime','EndTime']].drop_duplicates().rename(
                    columns={'ClientOrdID':'ClOrdID'}), on=['ClOrdID','Side'], how='left', suffixes=('','_y'))
            for col in ['Algorithm','StartTime','EndTime']:
                df.loc[df[col].isnull(), col] = df['{}_y'.format(col)]
                df.drop(columns=['{}_y'.format(col)], inplace=True)
       
        # expected qty only for TWAP algos
        #df.loc[df['Algorithm']=='TWAP' ,'Expected Exec in lots'] = df.apply(lambda row: row['OrderQty Lots']*( 
        #                                (datetime.datetime.now()-pd.to_datetime(row['StartTime']))/\
        #                                (pd.to_datetime(row['EndTime'])-pd.to_datetime(row['StartTime']))) , axis=1)
        stime=time.time()
        if "TWAP" in df['Algorithm'].values:
            temp = df[df['Algorithm']=='TWAP']
            temp.loc[temp['Algorithm']=='TWAP' ,'Expected Exec in lots'] = temp.apply(lambda row: self.twap_deviation(row) , axis=1)
            df = df[df['Algorithm']!='TWAP'].append(temp, ignore_index=True)
        print "TWAP calc time {}".format(time.time()-stime)
        # expected qty for VWAP algos
        stime=time.time()
        df.loc[df['Algorithm']=='VWAP' ,'Expected Exec in lots'] = df.apply(lambda row: 
            self.vwap_summation(row['NseSymbol'], row['StartTime'], row['EndTime'], row['OrderQty Lots']) , axis=1)
        print "VWAP calc time {}".format(time.time()-stime)
        df['Expected Exec in lots'] = pd.to_numeric(df['Expected Exec in lots'], errors='coerce').fillna(0).astype(int)
        df.loc[df['Algorithm'].isin(['VWAP','TWAP']), 'Slippage in Lots'] = df['Executed Qty Lots'] - df['Expected Exec in lots']
        df['Slippage in %'] = df.apply(lambda row: (row['Slippage in Lots']/row['Expected Exec in lots'])*100 if row['Expected Exec in lots']!=0 else 0, axis=1)
        df['Slippage in Lots'] = df['Slippage in Lots'].fillna(0)
        
        # get lmt order deviation from previous close
        df = self.deviation_from_prevclose(df)
        
        return df
        
    def get_arrival_price(self, df):
        '''
        gets arrival price based on first fill recieved via FIX
        :return: dataframe
        '''
        primary_key = ['ClientOrdID','Side']
        arrival_price = df.groupby(by=primary_key,sort=False).apply(lambda grp: 
                            grp[grp['LastQty']>=1]['LastPx'].values[0] if grp[grp['LastQty']>=1].empty==False else np.nan ).reset_index()
        arrival_price.columns = primary_key + ['Arrival px']
        df = df.merge(arrival_price, on=primary_key, how="left")
        
        df['LTP vs Arrival px %'] = df[['LastPx','Arrival px']].apply(lambda row: 
                                (row['LastPx'] - row['Arrival px'])/row['Arrival px']*100 if row['LastPx']!=0 else 0,axis=1)
        df['LTP vs Arrival px %'] = np.where(df['Side']=='BUY', df['LTP vs Arrival px %']*-1, df['LTP vs Arrival px %']) 
        #mask_condition = ((df['Side']=='BUY')&(df['arrival_temp']>=0.5) | (df['Side']=='SELL')&(df['arrival_temp']<=0.5*-1))
        #df['vs Arrival px %'] = np.where(mask_condition, True, False)
        #df.drop(columns=['arrival_temp'], inplace=True)
        
        return df
    
    def price_truncator(self, df, colname):
        '''
        func to truncate number upto 4 decimal places;
        e.g. 4.56789 -> 4.5678
        :return: dataframe
        '''
        df[colname] = df[colname].apply(lambda row: row if len(self.px_trunc_pattern.findall(row))==0 else \
                                          self.px_trunc_pattern.findall(row)[0]) # truncate number using regex pattern upto 4 decimal points 
        return df
      
    def mlp_recon_format(self, df):
        
        df['Expiry'] = df['Expiry'].astype(str)
        if df[df['ClientOrdID'].isnull()].empty==False:
            # get clid and parent ord id for missing in fix fills
            df = df.merge(self.redis_df[['Account','Symbol','Side','Expiry','ClientOrdID','ParentOrdID']].drop_duplicates(), 
                          on=['Account','Symbol','Side','Expiry'], how="left", suffixes=('','_y'))
            for col in ['ClientOrdID','ParentOrdID']:
                df.loc[df[col].isnull(), col] = df['{}_y'.format(col)]
                df.drop(columns=['{}_y'.format(col)], inplace=True)
        
        print "{} rows found without matching clid in redis".format(len(df[df['ClientOrdID'].isnull()]))
        logging.info("{} rows found without matching clid in redis".format(len(df[df['ClientOrdID'].isnull()])))
        
        df.dropna(subset=['ClientOrdID'], inplace=True)
        
        # get client ord id against the parent ord id
        self.read_fixorders_file()
        df = df.drop(columns=['Account','Account_fix']).merge(self.fixorders_df[['ParentOrdID','ClientOrdID','Account',
                    'RIC','OrderQty','State','OrdType','LimitPrice','expiry','tag610_1','tag610_2']], on=['ParentOrdID'],
                        how="left", suffixes=("","_order"))
        
        # replace cancel orders with executed qty in order qty
        #df.loc[df['State']=='Cancelled', 'OrderQty'] = df['OrderQty_order']
        df['OrderQty'] = df['OrderQty_order']; df.drop(columns=['OrderQty_order'], inplace=True)
        for col in ['ClientOrdID']:
            df.loc[df[col].isnull(), col] = df["{}_order".format(col)]
            df.drop(columns=['{}_order'.format(col)], inplace=True)
        
        
        df[['LastPx','LastQty','OrderQty','Quantity','Quantity_Lots','Average']] = df[['LastPx','LastQty','OrderQty','Quantity',
                              'Quantity_Lots','Average']].apply(pd.to_numeric, errors='coerce').fillna(0)
        
        # handle trades present in FIX; but not in exchange
        if df[df['Side'].isnull()].empty==False:
            df.loc[(df['Symbol'].isnull())&(df['Side'].isnull())&(df['Average']==0), "Side"] = df['Side_fix']
            df['Side'] = np.where(df['Side']=='B','BUY',np.where(df['Side']=='S','SELL',df['Side']))
        
        # get arrival price for all fills
        df = self.get_arrival_price(df)
        '''
        # get RIC for present in exchange but not in FIX
        df = df.merge(self.instru[['Symbol','expiry','RICNse']].rename(columns={'expiry':'Expiry'}), 
                      on=['Symbol','Expiry'], how="left", suffixes=("","_y"))
        df.loc[df['RICNse'].isnull(), "RICNse"] = df['RICNse_y']        
        '''
        #df.sort_values(by=['LastFillTime'], inplace=True)
        df = df.groupby(by=['ClientOrdID','Side'],sort=False).apply(lambda grp: pd.Series({ 'ParentOrdID':grp['ParentOrdID'].values[0],
                'OrderQty Lots': grp['OrderQty'].values[-1], "Executed Qty Lots": np.sum(grp['Quantity_Lots']), 
                'Sent on FIX Lots': np.sum(grp['LastQty']), 'Trading Tag/Tag1': grp['Account'].values[0], 'Symbol':grp['RIC'].values[0] if str(grp['RICNse'].values[0])=='nan' else grp['RICNse'].values[0],
                "Price Executed": np.average(grp['Average'], weights=grp['Quantity_Lots']) if np.sum(grp['Quantity_Lots'])!=0 else 0.0,
                'Price Sent Via FIX': np.average(grp['LastPx'], weights=grp['LastQty']) if np.sum(grp['LastQty'])!=0 else 0.0,                                
                'TradeTime': grp['Trade_time'].values[-1], 'TradeTime1': grp['LastFillTime'].values[-1], 'NseSymbol': grp['Symbol'].values[-1],
                'OrdType': grp['OrdType'].values[-1], 'LimitPrice': grp['LimitPrice'].values[-1],'expiry':grp['expiry'].values[0],
                'Arrival px': grp['Arrival px'].values[0],
                'LTP vs Arrival px %': grp['LTP vs Arrival px %'].values[-1]
                })).reset_index()
        
        df['avg px vs Arrival px %'] = df[['Arrival px','Price Executed']].apply(lambda row: 
                                (float(row['Price Executed']) - row['Arrival px'])/row['Arrival px']*100 if float(row['Price Executed'])!=0 else 0,axis=1)
        df['avg px vs Arrival px %'] = np.where(df['Side']=='BUY', df['avg px vs Arrival px %']*-1, df['avg px vs Arrival px %']) 
    
        df.loc[df['TradeTime'].isnull(), 'TradeTime'] = df['TradeTime1']; df.drop(columns=['TradeTime1'], inplace=True)
        
        df['Executed minus Order'] = df['Executed Qty Lots'] - df['OrderQty Lots']
        df['Executed minus FIX sent'] = df['Executed Qty Lots'] - df['Sent on FIX Lots']
        
        df.rename(columns={'ClientOrdID':'ClOrdID'}, inplace=True)
        
        #df['Price Executed'] = df['Price Executed'].apply(lambda row: row if len(self.px_trunc_pattern.findall(row))==0 else \
        #                                  self.px_trunc_pattern.findall(row)[0]) # truncate number using regex pattern upto 4 decimal points 
        #df['Price Sent Via FIX'] = df['Price Sent Via FIX'].apply(lambda row: row if len(self.px_trunc_pattern.findall(row))==0 else \
        #                                  self.px_trunc_pattern.findall(row)[0]) # truncate number using regex pattern upto 4 decimal points
        #for colname in ['Price Executed','Price Sent Via FIX']:
        #    self.price_truncator(df, colname)
        
        #df['Price Gap'] = df[['Price Executed','Price Sent Via FIX']].apply(lambda row: float(row['Price Executed'])-float(row['Price Sent Via FIX']), axis=1)
        
        # handle multiple replace orders
        df = df.groupby(by=['ParentOrdID','Side'],sort=False).apply(lambda grp: self.replace_orders_mlprecon(grp))
        df.reset_index(drop=True, inplace=True)        
        #df = df[self.mlp_recon_cols]
        
        #df['Price Executed'] = df['Price Executed'].apply(lambda row: row if len(self.px_trunc_pattern.findall(row))==0 else \
        #                                  self.px_trunc_pattern.findall(row)[0]) # truncate number using regex pattern upto 4 decimal points 
        #df['Price Sent Via FIX'] = df['Price Sent Via FIX'].apply(lambda row: row if len(self.px_trunc_pattern.findall(row))==0 else \
        #                                  self.px_trunc_pattern.findall(row)[0]) # truncate number using regex pattern upto 4 decimal points
        for colname in ['Price Executed','Price Sent Via FIX']:
            self.price_truncator(df, colname)
        
        df['Price Gap'] = df[['Price Executed','Price Sent Via FIX']].apply(lambda row: float(row['Price Executed'])-float(row['Price Sent Via FIX']), axis=1)
              
        # get order status from fix
        df = df.merge(self.fixorders_df[['ParentOrdID','State']].rename(columns={'State':'Order Status'}).drop_duplicates(), 
                      on=['ParentOrdID'], how="left")
        df['Minutes Back'] = pd.to_datetime(df['TradeTime'], errors="coerce").apply(lambda row: 
                                (datetime.datetime.now() - row).total_seconds()/60 if str(row)!='NaT' else 0)
        # get open orders
        self.read_fixorders_file()
        open_orders = self.get_open_orders()
        if open_orders.empty==False:
            print "Open orders with no execution present..."
            logging.info("Open orders with no execution present...")
            open_orders = open_orders[self.mlp_recon_cols+["NseSymbol","expiry"]]
            df = df.append(open_orders, ignore_index=True)
                
        # status
        df['Status'] = df.apply(lambda row: self.get_status(row), axis=1)
        
        # get vwap twap deviations
        df = self.get_algo_deviations(df,0)
        
        df = df[self.mlp_recon_cols+['Status','Algorithm','Expected Exec in lots','Slippage in Lots',
                'Slippage in %','LMT from prevClose %','Arrival px','LTP vs Arrival px %','avg px vs Arrival px %']].rename(columns={'Algorithm':'Algo'})
        df = df.reindex(df[['Executed minus FIX sent','Slippage in Lots','Minutes Back']].abs().sort_values(
                by=['Executed minus FIX sent','Slippage in Lots','Minutes Back'], ascending=[False,False,True]).index)
        mask_condition = df['Order Status'].isin(['Completed','Cancelled','DoneForTheDay'])
        df.loc[mask_condition, ['LTP vs Arrival px %','Slippage in %','Slippage in Lots']] = 0
        df.loc[mask_condition, 'Expected Exec in lots'] = df['Executed Qty Lots']
       
        
        return df
        
    def agg_fix_fills(self, df):
        '''
        func to agg fix fills to trade level
        '''
        
        df = df.groupby(by=['ParentOrdID','Side']).apply(lambda grp: pd.Series({
                'SYMBOL': grp['RICNse'].values[-1], 'NseSymbol': grp['NseSymbol'].values[-1], 'Expiry': grp['tag200'].values[-1],
                'tag167': grp['tag167'].values[-1], 'Account_fix': grp['Account'].values[-1], 'OrderQty': grp['OrderQty'].values[-1],
                'ClientOrdID': grp['ClientOrdID'].values[-1], 'Qty': grp['LastQty'].sum(), 
                'AvgPx': round(np.average(grp['LastPx'], weights=grp['LastQty']*Decimal('1.0')) if np.sum(grp['LastQty'])!=0 else 0.0,8),
                'TradeTime': grp['LastFillTime'].values[-1]
                    })).reset_index()
        
        return df
        

    def fix_vs_exchange(self, ex_df, fix_df):
        '''
        func to agg orders between fix and exchange
        leg by leg
        '''
        
        self.load_redis_data() # reloads HT orders details from redis; loads data for both single and mleg orders
        
        # get track ids/exchange account for fix from redis data
        fix_df = fix_df.merge(self.redis_df[['ParentOrdID','Account']].drop_duplicates(), on=['ParentOrdID'], how="left")
        fix_df.rename(columns={'NseSymbol':'Symbol'}, inplace=True)
        #fix_df['Expiry'] = fix_df['Expiry'].astype(str)
        fix_df['Side'] = np.where(fix_df['Side']=='B','BUY',np.where(fix_df['Side']=='S','SELL',''))
        # merge fix and exchange data
        df = ex_df.merge(fix_df, on=['Account','Symbol','Side','Expiry'], how="outer", suffixes=('','_fix'), indicator=True)
        df[['Quantity_Lots','Qty','Average','AvgPx']] = df[['Quantity_Lots','Qty','Average','AvgPx']].fillna(0)
        df['Diff_qty'] = df['Quantity_Lots'] - df['Qty'] # exchange minus fix qty
        df['Diff_avgpx'] = df['Average'] - df['AvgPx'] # exchanfe avgprice - fix avgpx
               
        df.to_csv("ht_mergeddata.csv", index=False)
        
        return df
        
    def write_output(self, result, mlp_recon_df):
        
        # write output files
        if result.empty==False:
            #result['CNBR'] = result['tag1']; result['tag1']=''
            result.to_csv(os.path.join(output_dir, "manual_bookings_ht.txt"), index=False)
        else:
            pd.DataFrame(columns=self.manual_bookings_cols+['Matching']).to_csv(os.path.join(output_dir, 
                        "manual_bookings_ht.txt"), index=False)
        if mlp_recon_df.empty==False:
            mlp_recon_df.to_csv(os.path.join(output_dir, "recon_format_ht.txt"), index=False)
        else:
            pd.DataFrame(columns=self.mlp_recon_cols).to_csv(os.path.join(output_dir, "recon_format_ht.txt"), index=False)
        
    def pre_open_trades(self):
        # if no trade has happened in exchange show only open orders
        #get open orders
        self.read_fixorders_file()
        open_orders = self.get_open_orders()
        if open_orders.empty==False:
            open_orders['Status'] = 'null'
            open_orders = self.get_algo_deviations(open_orders,1)
            open_orders = open_orders[self.mlp_recon_cols+['Status','Algorithm','Expected Exec in lots','Slippage in Lots',
                                      'Slippage in %']].rename(columns={'Algorithm':'Algo'})
            open_orders.to_csv(os.path.join(output_dir, "recon_format_ht.txt"), index=False)
        else:
            pd.DataFrame(columns=self.mlp_recon_cols+['Status','Algorithm','Expected Exec in lots','Slippage in Lots',
                                      'Slippage in %']).to_csv(os.path.join(output_dir, "recon_format_ht.txt"), index=False)
        
        pd.DataFrame(columns=self.manual_bookings_cols+['Matching']).to_csv(os.path.join(output_dir, 
                    "manual_bookings_ht.txt"), index=False)
        
    def leg_side(self, leg):
        '''
        func to get the leg indicator of the multi leg orders
        1 - > first leg; 2 - > second leg
        :return: string
        '''
        leg.loc[leg['Side']==leg['Side'].values[0], 'leg' ] = '1'
        leg.loc[leg['Side']!=leg['Side'].values[0], 'leg' ] = '2'
        
        return leg

    def leg_indicator(self, fix_df):
        '''
        gets leg indicator for all the orders
        blank for single leg futures
        :return: dataframe
        '''
        stime = time.time()
                    
        # highlight none mleg orders
        fix_df['leg'] = np.nan
        temp_mleg = fix_df[['ClientOrdID','Side']].drop_duplicates()
        temp_mleg = temp_mleg[temp_mleg.duplicated(subset=['ClientOrdID'])]['ClientOrdID'].values.tolist()
        if len(temp_mleg)>0:
            fix_df.loc[(fix_df['tag167'].astype(str)=='None') & (fix_df['ClientOrdID'].isin(temp_mleg)), 'tag167'] = 'MLEG'
            # identify individual legs
            fix_df = fix_df[fix_df['tag167']!='MLEG'].append(fix_df[fix_df['tag167']=='MLEG'].groupby(
                    by=['ClientOrdID'],sort=False).apply(lambda grp: self.leg_side(grp)))
            fix_df.sort_index(axis=0, inplace=True)
        print "Getting leg indicator time {}".format(time.time()-stime)
            
        return fix_df
    
    def drop_non_algo(self, fix_df):
        
        # read fix order file to get algo info
        self.read_fixorders_file()
        fix_df = fix_df.merge(self.fixorders_df[['ParentOrdID','Algorithm']].drop_duplicates(), on=['ParentOrdID'], how="left")
        #fix_df['Algorithm'] = fix_df['Algorithm'].fillna("None")
        fix_df.dropna(subset=['Algorithm'], inplace=True)
        return fix_df
    
    def find_missing_fills(self, ex_df, fix_df):
        '''
        func to compare FIX and exchange trades
        fill by fill and generates all output files
        returns none if there are no trade fills till time
        '''
        
        self.load_redis_data()
        fix_df = self.drop_non_algo(fix_df)
        
        stime = time.time()
        if (ex_df.empty==True) or (fix_df.empty==True):
            print "No trade fills found..."
            try:
                self.pre_open_trades()
            except Exception as e:
                print e
                logging.error("Error while getting pre-open open orders; \nError: {}".format(e))
            return
        
        # get mleg data; leg indicator
        fix_df = self.leg_indicator(fix_df)
        # maintain fix leg session names
        self.session_names = self.session_names.append(fix_df[['ParentOrdID','tag56']], ignore_index=True).drop_duplicates()
        #self.read_fixorders_file()
        #self.session_names = self.session_names.append(self.fixorders_df[['ParentOrdID','tag56']], ignore_index=True).drop_duplicates()
        
        # get fills executed in exchange but where not sent to client on fix
        df = ex_df.merge(fix_df, on=['TradeId'], how="outer", suffixes=('','_fix'), indicator=True)
        # dump merged file
        df.dropna(how='all', axis=1).to_csv(os.path.join(output_dir, "merged_fills_ht.csv"), index=False)
        df.drop_duplicates(subset=['TradeId'], inplace=True)
        matching_df = df[df['_merge']=='both']  # trades are matching in both exchange and FIX sent to client
        matching_df.dropna(how='all', axis=1, inplace=True)
        result = pd.DataFrame()
        if matching_df.empty==False:
            try:
                # get matching fills
                result = result.append(self.matching_fix_trades(matching_df))
            except Exception as e:
                print "Error while getting matching fills; Error {}".format(e)
                logging.error("Error while getting matching fills; Error {}".format(e))
                
        # trades not sent to client; but executed in exchange  
        missing_fix_df = df[df['_merge']=='left_only'] 
        #missing_fix_df.dropna(how='all', axis=1, inplace=True)
        if missing_fix_df.empty==False:
            try:
                print "Missing trades in client FIX...."
                result = result.append(self.missing_fix_trades(missing_fix_df))
            except Exception as e:
                print "Error while getting missing fills in FIX; Error {}".format(e)
                logging.error("Error while getting missing fills in FIX; Error {}".format(e))
                
        # trades not present in exchange but are there in FIX            
        missing_exch_df = df[df['_merge']=='right_only']
        missing_exch_df.dropna(how="all", axis=1, inplace=True)
        print "{} rows missing in Exchange but present in FIX".format(len(missing_exch_df))
        logging.info("{} rows missing in Exchange but present in FIX".format(len(missing_exch_df)))
        
        # get MLP recon format
        mlp_recon_df = self.mlp_recon_format(df.copy(deep=True))
        
        self.write_output(result, mlp_recon_df)         
        print "Time to find missing trades {}".format(time.time()-stime)
        logging.error("Time to find missing trades {}".format(time.time()-stime))
        
            
def main():
        
    #check_mount()
    #d = datetime.datetime.now()-datetime.timedelta(0) #datetime.date(2022,3,30)
    orders_obj = OrderMonitoring()
    
    #reload_time = time.time()
    while True:
        try:
            ex_df = pd.read_csv(os.path.join(output_dir, "exchangefills_HT.txt"), converters={i: str for i in range(0, 100)})
            ex_df['Average'] = ex_df['Average'].astype(float)
            ex_df = ex_df[ex_df['TradeStatus']=='11']; ex_df.drop_duplicates(inplace=True)
            #ex_df = ex_df[(ex_df['InstrumentType'].str.startswith("FUT")) & (~ex_df['Account'].isin(_dma_accountids))]
            
            fix_df = pd.read_csv(os.path.join(output_dir, "fix_tradefills.txt"), converters={i: str for i in range(0, 100)})
            fix_df = fix_df[fix_df['session'].isin(orders_obj._sessionnames)]
            fix_df['LastPx'] = fix_df['LastPx'].apply(lambda x: Decimal(x))
            fix_df.drop(columns=['TradeId'], inplace=True)
            fix_df.rename(columns={'ExchTradeId':'TradeId'}, inplace=True)
            #fix_df['LastPx'] = fix_df['LastPx'].astype(float)
            # get missing fills
            orders_obj.find_missing_fills(ex_df.copy(deep=True), fix_df.copy(deep=True))
        except Exception as e:
            logging.error(e)
            print e
            
        if datetime.datetime.now().time()>=datetime.time(17,25):
            print "Proccess done for the day !"
            logging.info("Proccess done for the day !")
            break
        
        time.sleep(5)
            
       
if __name__=="__main__":
    main()
