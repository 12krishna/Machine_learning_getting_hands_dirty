# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 10:45:40 2022

@author: krishna
"""

import os
import re
import pandas as pd
import numpy as np
import string
import simplefix
import datetime
from dateutil.relativedelta import relativedelta
import time
from collections import OrderedDict
import sys
import logging
import warnings
import ConfigParser
warnings.filterwarnings("ignore")
#from dateutil.relativedelta import relativedelta

# load config details
config_parser = ConfigParser.ConfigParserUtility(os.path.join(os.getcwd(), "config.txt"))
config_props_dict = config_parser.parse_configfile()

  
# log events in debug mode 
logging.basicConfig(filename=os.path.join(config_props_dict["log_dir"].strip(), "mlp_fixfills.log"),
                        level=logging.DEBUG, filemode='w',
                        format="%(asctime)s:%(levelname)s:%(message)s")

cal_months_list = [ (datetime.datetime(2000,1,1)+relativedelta(month=i)).strftime("%b") for i in range(1,13)]    
monthly_codes_fut = OrderedDict(zip(cal_months_list, ['F','G','H','J','K','M','N','Q','U','V','X','Z']))
monthly_call_options = OrderedDict(zip(cal_months_list, [c for c in map(chr, range(ord('A'), ord('M')))]))
monthly_put_options = OrderedDict(zip(cal_months_list, [c for c in map(chr, range(ord('M'), ord('Y')))]))


class TailFileReader():
    '''Class to read input file 
    keeps running track of file offset
    '''
    def __init__(self, filename):
        self.offset = 0
        self.filename = filename
        #self.input_schema = schema
    def read(self):
        # read file and process output
        prev_file =  open(os.path.join(config_props_dict["ul_path"].strip(),'{}'.format(self.filename)), 'r', encoding='cp1252')# read prev updated file
        prev_file = prev_file.readlines()[self.offset:]
        self.offset+=len(prev_file) # update the offset
        logging.info("curr len{} , file offset {}".format(len(prev_file), self.offset))
        return prev_file
        
    
class ULFIXOrders(object):
    '''UL FIX order monitoring
    '''
    def __init__(self, filename):
        
        self.expr_4_4 = r'8=FIX\.4\.4.*?[10=\d+\|]$'       # pattern to recognize line with valid excution or order line ;
                                        #match line with pattern 8=FIX.4.2 and ending with 10=number|
        self.expr_4_2 = r'8=FIX\.4\.2.*?[10=\d+\|]$'
        self.instrument = self.read_instrument()
        self.tail_filereader = TailFileReader(filename) # obj to read file in tail mode
        self.executions_cols = ['Tag115','Tag128','Tag129','MsgType','ClientOrdID','Og_ClientOrdID','ParentOrdID','OrderQty','Account','TradeId',
                                'tag19','tag48','LastFillTime','ExecutionTime','Symbol','LastPx','LastQty','Side','tag56','Session','tag167','tag75',
                                'tag150','tag39','tag200','tag442','tag20','tag21','Duplicates','tag201','tag461','tag58']   
        self.executions_df = pd.DataFrame()
        self.account_ids_cols = ['MsgType','ParentOrdID','tag1','Side','Symbol','Session','ClientOrdID']
        self.account_ids = pd.DataFrame(columns=self.account_ids_cols)
        self.edma_parentordids = pd.DataFrame(columns=['ParentOrdID','Symbol','Side'])
        self.disconnected_cols = ['MsgType','ParentOrdID','ClientOrdID','Og_ClientOrdID','TradeId','tag19']
        self.disconnected_df = pd.DataFrame(columns=self.disconnected_cols)
        
                    
        
    def read_instrument(self):
        
        instru = pd.read_csv(os.path.join(config_props_dict["instru_dir"].strip(),"instrument.csv"))
        instru = instru[(instru['InstrumentType'].isin(['FUTIDX','FUTSTK']))&(instru['ScripType']=='NORMAL')]
        instru['expiry'] = instru['ExpiryDate'].apply(lambda row: row.split("-")[-1]+row.split("-")[1])
        
        #replace to previus expiry
        #instru.loc[instru['expiry']=='202204','expiry']='202203'
        #instru.loc[instru['expiry']=='202205','expiry']='202204'
        #instru.loc[instru['expiry']=='202206','expiry']='202205'
        
        # get nse symbols
        scripmaster = pd.read_csv(os.path.join(config_props_dict["scripmaster_dir"].strip(), "scripmaster.csv"), encoding = "cp1252",
                                  names = ['Symbol','BseSymbol','UnnamedField3','Company Name','UnnamedField5','UnnamedField6',
                                           'ISIN','RICNse','Sedol','RICBse','UnnamedField11','BseTicker','NseTicker','UnnamedField14','NfoTicker'] )
        scripmaster = scripmaster[['Symbol','RICNse']]
        scripmaster = scripmaster.append(pd.DataFrame([['NIFTY','NIF'], ['BANKNIFTY','NBN']], columns=['Symbol','RICNse']))
        instru = instru.merge(scripmaster, on=['Symbol'], how='left')
        instru = instru[['Symbol', 'RICNse','expiry','LotSize','PreviousClose']].rename(columns={'Symbol':'NseSymbol','expiry':'tag200'})
        instru['RICNse']=instru['RICNse'].str.replace('.',':')
        instru.dropna(inplace=True)
        logging.info("Instrument file read successfully ...")
        return instru
        
    def read_session_tags(self):
        
        df = pd.read_csv(os.path.join(config_props_dict["input_dir"].strip(), "Ordermaster_eze_tora.csv"))
        df['FIX Version'] = df['FIX Version'].astype(str)
        self.sessions_4_4 = list(set(df[(df['FIX Version']=='4.4')]['Session'].values.astype(str)))
        self.sessions_4_2 = list(set(df[(df['FIX Version']=='4.2')]['Session'].values.astype(str)))
        
        self.tags_4_4 = list(set(df[(df['FIX Version']=='4.4')]['Tag115'].values.astype(str)))
        # changes as per dymon and tora
        self.tags_4_2 = list(set(df[(df['FIX Version']=='4.2')&(df['Session']=='I_EZE')]['Tag115'].values.astype(str))) + list(set(
                                    df[(df['FIX Version']=='4.2')&(df['Session']=='I_TORA')]['Tag116'].values.astype(str)))
        #df.rename(columns={'Tag1':'ClientName','Algo Tag':'Algorithm'}, inplace=True)
        df.rename(columns={'Tag1':'ClientName'}, inplace=True)
        
        df.fillna("None", inplace=True)
        
        return df   
    
    def parse_bytes(self, msg, tag):
        
        if str(msg.get(tag))!='None':
            return str(msg.get(tag).decode("utf-8"))
        else:
            return "None"
    
    def process_message(self, rx, line, flag="execution"):
        '''
        gets tags using fix parser
        '''
        
        x = rx[0].replace('|','\x01').replace(" \x01 "," | ")
        parser = simplefix.FixParser()
        parser.append_buffer(x)
        msg = parser.get_message()
        #print "here"
        #print msg.get(128)
        if flag=="execution":
            
            return ",".join([self.parse_bytes(msg, tag) for tag in [115, 128, 129, 35, 11, 41, 37, 38, 1, 17, 19, 48, 52, 60, 55, 31, 32, 54, 56]])\
                        + "," + line.split(" ")[3].replace("[",'').replace("]",'')\
                        + "," + ",".join([self.parse_bytes(msg, tag) for tag in [167, 75, 150, 39, 200, 442, 20, 21, 43, 201, 461,58]])
        
        elif flag=="downstream":
            
            return ",".join([self.parse_bytes(msg, tag) for tag in [35, 37, 1, 54, 55]]) \
                    + "," + line.split("(")[0].split("[")[-1].replace("]","").strip() \
                    + "," + ",".join([self.parse_bytes(msg, tag) for tag in [11]])
        
        elif flag=='disconnected':
            
            return ",".join([self.parse_bytes(msg, tag) for tag in [35, 37, 11, 41, 17, 19]])
        
        
    def handle_possible_duplicates(self, df):
        '''
        func to handle possible duplicates 
        sent during fix disconnection
        if 43=Y exists check & if trade is not present in disconnected lines
        then drop those duplicate trades
        :returns: DataFrame
        '''
        
        return df.drop(index=df[((df['Duplicates']=='Y') & \
                    ~(df['TradeId'].isin(self.disconnected_df['TradeId'].values.tolist())))].index)
        
        
    def flattern(self, A):
        '''
        flatterns nested list
        '''
        rt = []
        for i in A:
            if isinstance(i,list): rt.extend(self.flattern(i))
            else: rt.append(i)
        return rt
    '''
    def process_edma_fills(self, temp):
        
        print ("EDMA fills present...")
        temp = temp.merge(self.edma_parentordids.rename(columns={'Symbol':'Symbol_edma'}), 
                          on=['ParentOrdID', 'Side'], how="left")
        temp.loc[temp['ParentOrdID'].str.lower().str.startswith("edma"), "NseSymbol"] = temp['Symbol_edma']
        temp.drop(columns=['Symbol_edma'], inplace=True)
        # replace EDMA parent ord ids
        temp = temp.merge(self.account_ids[['ClientOrdID','ParentOrdID']],
                          on=['ClientOrdID'], how="left", suffixes=("","_edma"))
        temp.loc[(temp['ParentOrdID'].str.lower().str.startswith("edma"))&\
                 (~temp['ParentOrdID_edma'].isnull()), "ParentOrdID"] = temp['ParentOrdID_edma']
        temp.drop(columns=['ParentOrdID_edma'], inplace=True)
        
        return temp
    '''
    def process_edma_fills(self, temp):
        
        temp['temp_clordid'] = temp['ClientOrdID'].apply(lambda row: str(row).split("_",2)[-1] )
        temp = temp.merge(self.account_ids[['ClientOrdID','ParentOrdID','Symbol']].rename(
                columns={'ClientOrdID':'temp_clordid'}).drop_duplicates(subset=['temp_clordid']),
                          on=['temp_clordid'], how="left", suffixes=('','_edma'))
        temp.loc[temp['ParentOrdID'].str.lower().str.startswith("edma"), 'ParentOrdID'] = temp['ParentOrdID_edma']
        temp['NseSymbol'] = temp['Symbol_edma']
        
        return temp
    
    
    def prefix_session(self, df):
        
        #Prefix session; to handle duplicate client ord in same session
        df['ClientOrdID'] = df['Session'].astype(str)+"_"+df['ClientOrdID'].astype(str)
        if 'Og_ClientOrdID' in df.columns:
            df['Og_ClientOrdID'] = df['Session'].astype(str)+"_"+df['Og_ClientOrdID'].astype(str)
        
        return df

    def gen_executions(self, executions, account_ids, disconnected_lines):
        '''
        func to get exeuction fills
        '''
        
        if len(disconnected_lines)>0:
            print ("FIX disconnection messages present...")
            self.disconnected_df = self.disconnected_df.append(pd.DataFrame(disconnected_lines, columns=self.disconnected_cols), ignore_index=True)
            
        if len(account_ids)>0:
            temp = pd.DataFrame(account_ids, columns=self.account_ids_cols)
            temp = temp[temp['ParentOrdID']!='None']
            '''
            edma_parentordids = temp[temp['ParentOrdID'].str.lower().str.startswith("edma")][['ParentOrdID','Symbol'
                                     ,'Side']].drop_duplicates()
            edma_parentordids = edma_parentordids[~edma_parentordids['Symbol'].str.contains("-")]# drop MLEG summary fills
            edma_parentordids['Side'] = np.where(edma_parentordids['Side'].astype(str)=='1','B','S')
            '''
            temp.drop_duplicates(subset=['ParentOrdID','ClientOrdID'], inplace=True)
            temp = temp[~temp['ParentOrdID'].str.lower().str.startswith("edma")]
            temp['ClientOrdID'] = temp['ClientOrdID'].apply(lambda c: str(c).split("_",1)[-1] )
            #temp['ClientOrdID'] = temp['Session'].astype(str)+"_"+temp['ClientOrdID'].astype(str)
            
            self.account_ids = self.account_ids.append(temp, ignore_index=True).drop_duplicates()
            #self.edma_parentordids = self.edma_parentordids.append(edma_parentordids, ignore_index=True).drop_duplicates()
        
        if len(executions)>0:
            print ("Fill lines read {}".format(len(executions)))
            temp = pd.DataFrame(executions, columns=self.executions_cols)
            temp = self.prefix_session(temp)
            # ignore summary record for multi-leg orders
            temp = temp[temp['tag442']!='3']
            temp['Side'] = temp['Side'].astype(str).str.strip()
            temp['Side'] = np.where(temp['Side']=='1','B','S')
            if temp[temp['Duplicates']=='Y'].empty==False:
                # handle duplicate messages
                temp = self.handle_possible_duplicates(temp)
                
            # get RIC tickers for symbols based on tag55 and expiry tag 200
            if temp.empty==False:
                
                time_zone = 'IST'       
                for dcol in ['LastFillTime','ExecutionTime']:
                    if time_zone=='IST':
                        temp[dcol] = pd.to_datetime(temp[dcol],errors="coerce") + datetime.timedelta(hours=5,minutes=30)
                    else:
                        temp[dcol] = pd.to_datetime(temp[dcol],errors="coerce") 
                            
                temp['RICNse'] = temp[['Symbol','tag200','tag167','ClientOrdID','Account','TradeId']].apply(lambda row: 
                    self.ric_code_gen(row['Symbol'], row['tag200'], row['tag167']), axis=1)
                    
                temp['ExchTradeId'] = temp['TradeId'].apply(lambda row: row[8:].split("N")[0] if "N" in row else row)
                # get nse symbol from downstreams for EDMA
                '''
                if temp[temp['ParentOrdID'].str.lower().str.startswith("edma")].empty==False:
                    print("Orders present...")
                    temp = self.process_edma_fills(temp)
                '''
                temp = self.process_edma_fills(temp)
                
                #temp['NseSymbol'] = temp[['ParentOrdID','Symbol']].apply(lambda row: row['ParentOrdID'].split("_")[1] if len(row['ParentOrdID'].split("_"))>=2 else row['Symbol'], axis=1)
                
                temp['RICNse'] = temp['RICNse'].apply(lambda row: row[:-3] if len(re.findall(":NS",row))>1 else row)
                # get lot size
                temp = temp.merge(self.instrument[['LotSize','NseSymbol','tag200']], on=['NseSymbol','tag200'], how='left')
                temp.loc[temp['Tag128']=='None', 'Tag128'] = temp['Tag129']
                temp = temp[['Tag115', 'Tag128', 'MsgType', 'ClientOrdID', 'Og_ClientOrdID', 'ParentOrdID', 'OrderQty', 'Account',
                              'TradeId', 'tag48', 'LastFillTime', 'ExecutionTime', 'Symbol', 'LastPx', 'LastQty', 'Side', 'tag56',
                               'Session', 'tag167', 'tag75', 'tag150', 'tag39', 'tag200', 'tag442', 'RICNse', 'ExchTradeId', 'LotSize',
                               'NseSymbol','tag19','tag20','tag21','tag201','tag461','tag58']]
                temp['tag58'] = temp['tag58'].str.replace(",", "") 
            self.executions_df = self.executions_df.append(temp, ignore_index=True)
            print ("Total fill line shape till now {}".format(self.executions_df.shape))


    def filter_trades(self):
        '''
        func to get only executions/fills
        from fix file
        '''
        
        # get session and tags
        try:
            self.input_table = self.read_session_tags()
        except Exception as e:
            print (e)
        
        stime = time.time()
        records = self.tail_filereader.read() # read last records appeneded in file
        print ("File read time {}".format(time.time()-stime))
        executions = []
        disconnected_lines = []
        account_ids = []
        stime = time.time()
        sessions = self.input_table['Session'].values.tolist()
        tags = list(set(self.flattern(self.input_table[['Tag115','Tag116']].values.tolist())))
        tags.remove("None")
        if len(records)>0:
            for line in records:
                try:
                    # process fix records 
                    rx = re.findall(self.expr_4_2, line) if "FIX.4.2" in line else re.findall(self.expr_4_4, line)
                    if ("(disconnected)" in line) and rx:
                        # maintain disconnected messages to backtrack and find duplicate messages
                        #curr_session = [s for s in self.sessions_4_2 if s in line] if "8=FIX.4.2" in line else [s for s in self.sessions_4_4 if s in line]
                        disconnected_lines.append(self.process_message(rx, line, 'disconnected').split(","))
                        
                    elif rx:
                        #curr_session = [x for x,y in zip(sessions, [ s in line for s in sessions]) if y==True]
                        #curr_session = curr_session[0] if len(curr_session)>0 else None
                        if (("O_KITSOM" in line) or ("O_KITSETSFO" in line)) and ("FIX.4.4" in line) and ("150=" in line):
                            # get exchange account id
                            account_ids.append(self.process_message(rx, line, 'downstream').split(","))
                            continue
                        
                        # check if any of session present 
                        if np.any([ s in line for s in sessions]):
                            if ('35=8' in rx[0]) and (np.any([ "128={}".format(t) in rx[0] or "129={}".format(t) in rx[0] for t in tags]) or ("I_CITAFUT" in line)):
                                executions.append((self.process_message(rx, line).split(",")))
                except Exception as e:
                    print(e)
                
                    
        print ("Loop time {}".format(time.time()-stime))
        
        self.gen_executions(executions, account_ids, disconnected_lines)
        
    def process_records(self):
        
        self.executions_df=self.executions_df[self.executions_df['tag150'].isin(['1','2','F'])]
        print ("Lenght of df contianing f and h {}".format(len(self.executions_df)))
        if self.executions_df.empty==True:
            print ("Exit ..........")
            return -1
                
        # handling trade bursts
        for index, row in self.executions_df[self.executions_df['tag20']=='1'].iterrows():
            self.executions_df.drop(index=self.executions_df[self.executions_df['TradeId']==row['tag19']].index, inplace=True)
            self.executions_df.drop(index=index, inplace=True)
       
        #self.executions_df = self.executions_df[self.executions_df['tag442']!='3']
        
        #df1['TradeDate'] = df1['TradeDate'].apply(lambda row: row.strftime("%Y/%m/%d %H:%M:%S") )
        #if len(self.executions_df) > 0:
        #    .to_csv(outpath+f_prefix+"_"+filename.split("_")[-1], index=False) # client output
        #    df2 = df1.copy(deep=True); df2['Price']=df2['Price'].astype(float)
        #    df2 = df2.groupby(by=['Account','Symbol','Side'], as_index=False).apply(lambda grp: agg_trade(grp)).reset_index()
        self.dump_data(os.path.join(config_props_dict["output_dir"].strip(), "fix_tradefills.txt"))
    
    def dump_data(self, filename):
        
        # debug dump data
        while 1:
            try:
                self.executions_df.to_csv(filename, index=False)
                break
            except Exception as e:
                print (e)
                print ("File in use")
                logging.error("File in use {}".format(e))
    
    
    def agg_trade(self, grp):
        '''Func to agg trade '''
        q=np.sum(grp['Quantity'])
        return pd.Series({
                      'Quantity':q , 
                      'Price': round( np.average(grp['Price'], 
                                                   weights=grp['Quantity']) if q!=0 else grp['Price'].values[-1] , 2)
                      #'ClientOrderId': grp['ClientOrderId'].values[-1] 
                      })
                  
    def ric_code_gen(self, tag55, tag200, tag167):
        '''func to get RIC code for FNO
        '''
        
        try:
            ric_root = tag55.split(":")
            
            if tag167=='FUT':
                expiry = monthly_codes_fut[datetime.datetime.strptime(tag200, "%Y%m").strftime("%b")] + datetime.datetime.strptime(
                                    tag200, "%Y%m").strftime("%Y")[-1]
                if ric_root[0] in ['NIF','NBN','NTS']:
                    return ric_root[0]+expiry
                else:
                    return ric_root[0][:-2]+expiry+":"+ric_root[1]
                    
            elif tag167=='OPT':
                # options
                #print "Options RIC construction logic not set yet....................................................."
                return tag55
            elif tag167=='MLEG':
                #print "Multi leg order, constructing single leg RIC {}".format(tag55)
                if tag55[:-2] in ['NIF','NBN','NTS']: # index
                    return tag55
                else:
                    return tag55+":NS"
            else:
                return tag55
        except Exception as e:
            print (e)
            print (tag55)
            
            return tag55
        
   
def process(ulfix_obj):
    
    ulfix_obj.filter_trades() # read all fix executions fill by fill
    ulfix_obj.process_records()
    
    
def dateparse_d(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date

# read holiday master
holiday_master = pd.read_csv(os.path.join(config_props_dict['holiday_dir'].strip(), 'Holidays_2019.txt'),
                             delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):

    '''Func to check if the process should run on current day or not'''
    if len(holiday_master[holiday_master['date']==d])==0:
        print ("Start process for working day")
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        print ('Holiday: skip for current date :{} '.format(d))
        return -1
    
def main(nd):
    
    d = datetime.datetime.now() - datetime.timedelta(days=nd) # change date as per desiered
        
    if process_run_check(d.date()) == -1:
        update_db.update_lastruntime("eze_Fixfills_52")
        return -1
    
    if datetime.datetime.now().time()<=datetime.time(8,5):
        # reset file
        pd.DataFrame(columns=['Tag115', 'Tag128', 'MsgType', 'ClientOrdID', 'Og_ClientOrdID', 'ParentOrdID', 'OrderQty', 
            'Account','TradeId', 'tag48', 'LastFillTime', 'ExecutionTime', 'Symbol', 'LastPx', 'LastQty', 'Side', 'tag56',
            'Session', 'tag167', 'tag75', 'tag150', 'tag39', 'tag200', 'tag442', 'RICNse', 'ExchTradeId', 'LotSize',
            'NseSymbol','tag19','tag20','tag21','tag201','tag461','tag58']).to_csv(os.path.join(config_props_dict["output_dir"].strip(), "fix_tradefills.txt"), index=False)
                
    print ("Start processing for {} .....................".format(d))
    
    # create ULFIX class object
    ulfix_obj = ULFIXOrders("{}.txt".format(datetime.datetime.strftime(d,"%Y%m%d")))
    while True:
        try:                
            
            process(ulfix_obj)
            #print ("Sleep for 1 seconds...")
            #time.sleep(5)
            if datetime.datetime.now().time()>=datetime.time(18,0):
                print ("Proccess done for the day !") 
                process(ulfix_obj)
                update_db.update_lastruntime("eze_Fixfills_52")
                break
            
        except Exception as e:
            print (e)
            logging.error("Error {}\nReloading ....".format(e))
            ulfix_obj = ULFIXOrders("{}.txt".format(datetime.datetime.strftime(d,"%Y%m%d")))
            #process(ulfix_obj, tags, sessions)
            time.sleep(1)
    
      

import psycopg2
import datetime
from project_status_update import project_status_rt as udt
update_db= udt.postgres_updations()


if __name__=='__main__':
    update_db.update_status("eze_Fixfills_52")
    main(0)
