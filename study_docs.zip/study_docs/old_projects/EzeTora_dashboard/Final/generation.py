import numpy as np
import pandas as pd
import re
from datetime import datetime
from math import ceil
import ast

class files_genration:

	def __init__(self, indx_ric_df, scrip_df, contact_df):
		"""
		The class file generation helps to generate the required files such as indx file and stock files
		"""
		self.indx_ric_df = indx_ric_df
		self.scrip_mastr_df = scrip_df
		self.contracts_df = contact_df

	def final_df_creation(self) -> pd.DataFrame:
		"""
		this function will generate the required datafarme using contact and script_master datafarme, preprocess
		:return: dataframe
		"""
		final_df = self.contracts_df.merge(self.scrip_mastr_df,how="left" ,left_on=3, right_on=0)
		final_df.drop(0, axis=1, inplace=True)
		final_df[6] = final_df[6] / 100
		# final_df.columns = ["underelying_asset", "strick_price", "side", "strike_detail", "expiry_date", "ric_code"]
		final_df.columns = ["underelying_asset", "strick_price", "side", "strike_detail", "ric_code"]
		return final_df

	def ric_code_stock(self)-> pd.DataFrame:
		"""
		scrip master file doesnt have ric codes for indxs, hence if ric code is not empty, it means its a stock detail
		"""
		final_ddf = self.final_df_creation()
		stck_df = final_ddf.loc[~final_ddf["ric_code"].isna(), :].reset_index(drop=True)
		stck_df["ric_code"]= stck_df["ric_code"].astype(str)
		stck_df["ric_code"] = stck_df["ric_code"].apply(lambda x: x.split(".")[0] if x != "nan" else "nan")
		return  stck_df

	def ric_code_indx(self)-> pd.DataFrame:
		"""
		scrip master file doesnt have ric codes for indxs, hence if ric code is empty, it means its a indx detail
		"""
		final_ddf = self.final_df_creation()
		indx_df = final_ddf.loc[final_ddf["ric_code"].isna(), :].reset_index(drop=True)
		indx_df = indx_df.merge(self.indx_ric_df, how="left", left_on="underelying_asset", right_on="indx")
		indx_df["ric_code"]= indx_df["ric_code"].fillna(indx_df["ric"])
		# indx_df= indx_df[["underelying_asset", "strick_price", "side", "strike_detail", "expiry_date", "ric_code"]]
		indx_df = indx_df[["underelying_asset", "strick_price", "side", "strike_detail", "ric_code"]]
		return indx_df

	def generate_dico_source(self)-> pd.DataFrame:
		"creating empty dataframe having column names "
		dico_source= pd.DataFrame(columns=["BSE CODE","NSE SYMBOL","Description","ISIN Code","Bloomberg code","Reuters","SedolCode",
		                      "Currency",	"Asset class","Closing price","Strike Price","Maturity Date","Put/Call","Lot Size"
								])
		return dico_source

	# def __str__(self):
	# 	print("This classes helps us to generate the required files such as indx file and stock files")


class ric_code_genration(files_genration):

	def __init__(self,indx_ric_df, scrip_df, contact_df, fut_json_code: dict, optn_json_code:dict, month_int_code:dict):
		"""
		This code helps ito create Ric code for the given script details present in contracts file

		:param indx_ric_df: dataframe having indx rics
		:param scrip_df: masterscrip.csv
		:param contact_df: contracts.csv
		:param fut_json_code: Fututre json
		:param optn_json_code: Option Json
		:param month_int_code: Months int copde which is present in json
		"""
		self.month_fut_code = fut_json_code
		self.month_opt_code = optn_json_code
		self.month_int_code = month_int_code
		files_genration.__init__(self, indx_ric_df, scrip_df, contact_df)

	def create_ric(self, df: pd.DataFrame)-> pd.DataFrame:
		"""

		:param df: will be needing ric strt stock name , optin or fut column ( CE,PE,FUT), EXPIRY DATE,
		:return: column having ric+strike_price+month_code+year_code_":NS"
		"""
		df["Reuters"] =""
		df.loc[((df["side"] == "CE") | (df["side"] == "PE")), ["Reuters"]] = df["ric_code"] + df["strike_prices_all"] + df["month_code"]  + ".NS"
		df.loc[(df["side"] == "FUT"), ["Reuters"]] = df["ric_code"] + df["strike_prices_all"] + df["month_code"] + str(datetime.today().year)[-1] + ":NS"
		return df


	def append_month_code(self,df: pd.DataFrame)-> pd.DataFrame:
		"""

		:param df: could be a Stock df or indx df
		:return: dataframe
		"""
		df["month_code"]= ""
		# df["month_code"]= np.where(df["side"]=="CE",
		#                            self.month_opt_code[df["expiry_month"]]["CE"],
		#                         np.where(df["side"]=="PE", self.month_opt_code[df["expiry_month"]]["PE"],
		#                              self.month_fut_code[df["expiry_month"]]
		#                                     )
		#                                 )

		for i in range(0, df.shape[0]):
			if df.loc[i,["side"]].item()== "CE":
				df.loc[i,["month_code"]]= self.month_opt_code[ str(df.loc[i,["expiry_month"]].item())]["CE"]
			elif df.loc[i,["side"]].item()== "PE":
				df.loc[i,["month_code"]]= self.month_opt_code[ str(df.loc[i,["expiry_month"]].item())]["PE"]
			else:
				df.loc[i, ["month_code"]] = self.month_fut_code[str(df.loc[i, ["expiry_month"]].item())]
		return df

	def stock_df_process(self):
		"""
		1st will filter the stocks from contacts.csv and then will run this code
		:return:
		"""

		stck_df= files_genration.ric_code_stock(self)
		string_lst = stck_df["strike_detail"].apply(lambda x: re.findall("(?i)[a-z|&|-]+", x))
		num_list = stck_df["strike_detail"].apply(lambda x: re.findall("[0-9|.]+", x))

		month_exp= stck_df["strike_detail"].apply(lambda x: re.findall("(?i)[a-z|&|-]+", x)[1][:3])
		date_strik_price = stck_df["strike_detail"].apply(lambda x: re.findall("\d*\.\d+|\d+", x))
		date_strik_price= date_strik_price.apply(lambda x : x+([""]) if len(x)<2 else x)

		strk_pr= date_strik_price.apply(lambda x: x[1])
		exp_dt= date_strik_price.apply(lambda x: x[0])
		stck_df["strike_prices_all"]= pd.DataFrame(strk_pr)
		stck_df["exp_dt"] = pd.DataFrame(exp_dt)

		stck_df["expiry_month"]= pd.DataFrame(month_exp)
		stck_df["side"] = np.where(stck_df["side"]=="XX","FUT",stck_df["side"] )

		stck_df= self.append_month_code(stck_df)
		stck_df_opt = stck_df.loc[~stck_df["side"].str.contains("FUT"),:]
		stck_df_fut = stck_df.loc[stck_df["side"].str.contains("FUT"), :]
		stck_df_opt["strike_prices_all"]= pd.to_numeric(stck_df_opt["strike_prices_all"])
		stck_df_opt["strike_prices_all"] = stck_df_opt["strike_prices_all"]*100
		stck_df_opt["strike_prices_all"]= stck_df_opt["strike_prices_all"].astype(int).astype(str)
		stck_df_opt["strike_prices_all"]= stck_df_opt["strike_prices_all"].apply(lambda x: "0" * (6 - len(x)) + x if len(x) < 6 else x[:6])
		stck_df = pd.concat([stck_df_opt, stck_df_fut], axis=0)

		stck_df= self.create_ric(stck_df)
		stck_df = stck_df[['underelying_asset', 'strike_detail', 'Reuters']]

		return stck_df


	def week_of_month(self,dt):
		""" Returns the week of the month for the specified date.
		"""
		self.dt= dt

		first_day = dt.replace(day=1)

		dom = dt.day
		adjusted_dom = dom + first_day.weekday()

		return int(ceil(adjusted_dom / 7.0))

	def weekly_exp_handlng(self, df:pd.DataFrame):
		self.df= df
		num_list= df["strike_detail"].apply(lambda x: re.findall("[0-9|.]+", x))
		for row_num in range(0,len(num_list)):
			if len(num_list[row_num])==1:
				df.loc[row_num,["year"]] = num_list[row_num][0][:2]    #year in foirm of 22,23
				month_day = num_list[row_num][0][2:].split(str(df.loc[row_num,["strick_price"]].item()))[0]
				df.loc[row_num,["day"]]  = month_day[-2:][1] if str(month_day[-2:]).startswith("0") else month_day[-2:]
				df.loc[row_num,["month"]]= month_day[:-2]

				df.loc[row_num,['date']]= datetime(int("20"+df.loc[row_num,["year"]].item()),int( df.loc[row_num,["month"]].item()), int(df.loc[row_num,["day"]].item() )).date()
				df.loc[row_num,["week_of_month"]] = self.week_of_month(datetime(int("20"+df.loc[row_num,["year"]].item()),int( df.loc[row_num,["month"]].item()), int(df.loc[row_num,["day"]].item() )).date())
		return df

	def nod_month_handling(self,df):
		df= self.df
		for indx in range(len(df)):
			if len(df["expiry_month"][indx])==1:
				num_list = re.findall("[0-9]+", df["strike_detail"][indx])
				df.loc[indx, ['year']]= num_list[0]
				df.loc[indx, ['day']]= num_list[1][:2]
				
				df.loc[indx, ['expiry_month']]= np.where(df["expiry_month"][indx]=="O", "OCT", np.where(df["expiry_month"][indx]=="N",
				                                "NOV", np.where(df["expiry_month"][indx]=="D", "DEC",df["expiry_month"][indx] )))
				df.loc[indx, ['month']]= list(self.month_int_code.keys())[list(self.month_int_code.values()).index(df["expiry_month"][indx])]
				df.loc[indx, ['date']] = datetime(int("20" + df.loc[indx, ["year"]].item()),int(df.loc[indx, ["month"]].item()),int(df.loc[indx, ["day"]].item())).date()
				df.loc[indx, ["week_of_month"]] = self.week_of_month(datetime(int("20" + df.loc[indx, ["year"]].item()), int(df.loc[indx, ["month"]].item()),int(df.loc[indx, ["day"]].item())).date())
		return df


	def aplha_month(self,df, month_code_json):
		self.df = df

		for row_num in range(0,len(df)):
			if len(df.loc[row_num,["month_alpha"]].item())==3:
				df.loc[row_num,["expiry_month"]] =df.loc[row_num, ["month_alpha"]].item()[1]
			else:
				df.loc[row_num, ["expiry_month"]] = self.month_int_code[str(df.loc[row_num, ["month"]].item())]
		return df

	def aplha_fut_month(self,df, month_code_json):
		self.df = df

		for row_num in range(0,len(df)):
			if df.loc[row_num,["month_alpha"]].item()[1] !="FUT":
				df.loc[row_num,["expiry_month"]] =df.loc[row_num, ["month_alpha"]].item()[1][:3]
			else:
				df.loc[row_num, ["expiry_month"]] = self.month_int_code[str(df.loc[row_num, ["month"]].item())]
		return df





	def which_week_of_month(self, df):
		self.df = df

		for row_num in range(0,len(df)):
			if str(df.iloc[row_num,8]) != "nan":
				df.loc[row_num,["week_of_month"]]= self.week_of_month()

	def create_ric_indx(self,df, fut:bool):
		self.df= df
		self.fut= fut

		for row_num in range(0,len(df)):
			if str(df.loc[row_num,["week_of_month"]].item()) != "nan":
				sp = "0"+str(df.loc[row_num,["strick_price"]].item()) if len(str(df.loc[row_num,["strick_price"]].item()))< 5 else str(df.loc[row_num,["strick_price"]].item())
				rc =  df.loc[row_num,["ric_code"]].item()
				wom =str(int(round(df.loc[row_num,["week_of_month"]].item())))
				mon_cod= df.loc[row_num,["month_code"]].item()
				if self.fut==True:
					df.loc[row_num,["Reuters"]] = rc+ wom +"W" + mon_cod+str(datetime.today().year)[-1]
				else:
					df.loc[row_num, ["Reuters"]] = rc + wom + "W" + sp + mon_cod + str(datetime.today().year)[-1] + ".NS"
			else:
				sp = "0" + str(df.loc[row_num, ["strick_price"]].item()) if len(str(df.loc[row_num, ["strick_price"]].item())) < 5 else str(df.loc[row_num, ["strick_price"]].item())
				rc = df.loc[row_num, ["ric_code"]].item()
				mon_cod = df.loc[row_num, ["month_code"]].item()
				if self.fut ==True:
					df.loc[row_num, ["Reuters"]] = rc + mon_cod + str(datetime.today().year)[-1]
				else:
					df.loc[row_num, ["Reuters"]] = rc + sp + mon_cod + str(datetime.today().year)[-1] + ".NS"
		return df

	# def month_code_indx(self,df):
	# 	self.df =df
	# 	for row_num in tqdm(range(0,len(df))):
	# 		if df.loc

	def indx_fut_handling(self, df):
		self.df = df
		num_list = df["strike_detail"].apply(lambda x: str(re.findall("[0-9]+", x)[0]))
		week_list = df["strike_detail"].apply(lambda x: str(re.findall("[0-9]+", x)))
		str_list =pd.DataFrame(df["strike_detail"].apply(lambda x: re.findall("(?i)[a-z|&|-]+", x)[1].split("FUT") [0] if len(re.findall("(?i)[a-z|&|-]+", x)[1])>3 else re.findall("(?i)[a-z|&|-]+", x)[1]))

		#df["month_alpha"]= pd.DataFrame(str_list)
		for row_num in range(0,len(num_list)):
			if len(num_list[row_num])>2:
				df.loc[row_num,["year"]] = num_list[row_num][:2]    #year in foirm of 22,23
				month_day = num_list[row_num][2:]
				df.loc[row_num,["day"]]  = month_day[-2:][1] if str(month_day[-2:]).startswith("0") else month_day[-2:]
				df.loc[row_num,["month"]]= month_day[:-2]

				df.loc[row_num,['date']]= datetime(int("20"+df.loc[row_num,["year"]].item()),int( df.loc[row_num,["month"]].item()), int(df.loc[row_num,["day"]].item() )).date()
				df.loc[row_num,["week_of_month"]] = self.week_of_month(datetime(int("20"+df.loc[row_num,["year"]].item()),int( df.loc[row_num,["month"]].item()), int(df.loc[row_num,["day"]].item() )).date())

		for row_num in range(0,len(week_list)):
			if len(ast.literal_eval(week_list[row_num]))>1:
				df.loc[row_num, ["year"]] = ast.literal_eval(week_list[row_num])[0]
				df.loc[row_num,["day"]] = ast.literal_eval(week_list[row_num])[1]
				# df.loc[row_num, ["month"]] = np.where(df["strike_detail"][row_num][-6] ==
				df.loc[row_num,["expiry_month"]] = np.where(df["strike_detail"][row_num][-6] == "O", "OCT",np.where(df["strike_detail"][row_num][-6] == "N", "NOV",np.where(df["strike_detail"][row_num][-6] == "D","DEC",df["strike_detail"][row_num][-6] )))
				df.loc[row_num, ['month']]= list(self.month_int_code.keys())[list(self.month_int_code.values()).index(df["expiry_month"][row_num])]
				df.loc[row_num,['date']]= datetime(int("20"+df.loc[row_num,["year"]].item()),int( df.loc[row_num,["month"]].item()), int(df.loc[row_num,["day"]].item() )).date()
				df.loc[row_num,["week_of_month"]] = self.week_of_month(datetime(int("20"+df.loc[row_num,["year"]].item()),int( df.loc[row_num,["month"]].item()), int(df.loc[row_num,["day"]].item() )).date())
		return df


	def indx_df_process(self):

		"""
		:return: with the help of all the func we will handle all the senarios of index
		"""
		indx_df= files_genration.ric_code_indx(self)
		indx_df["side"] = np.where(indx_df["side"] == "XX", "FUT", indx_df["side"])
		indx_df["strick_price"] = indx_df["strick_price"].astype(int)

		indx_df = indx_df[~indx_df.underelying_asset.str.contains("NSETEST")]
		indx_fut = indx_df.loc[(indx_df["side"] == "FUT"), :].reset_index(drop=True)
		indx_opt= indx_df.loc[~(indx_df["side"] == "FUT"),:].reset_index(drop=True)


		indx_fut = self.indx_fut_handling(indx_fut)
		indx_fut["month_alpha"] = pd.DataFrame(indx_fut["strike_detail"].apply(lambda x: re.findall("(?i)[a-z|&|-]+", x)))
		indx_fut =self.aplha_fut_month(indx_fut, self.month_int_code) #indx_fut["expiry_month"].apply(lambda x: x.strftime("%b").upper() if(len(x)<3) else x)
		indx_fut["expiry_month"]= np.where(indx_fut["expiry_month"]=="O", "OCT", np.where(indx_fut["expiry_month"]=="N", "NOV", np.where(indx_fut["expiry_month"]=="D","DEC",indx_fut["expiry_month"])))
		indx_fut = self.append_month_code(indx_fut)
		indx_fut = self.create_ric_indx(indx_fut, fut=True)

		indx_opt = self.weekly_exp_handlng(indx_opt)
		indx_opt["month_alpha"] = pd.DataFrame(indx_opt["strike_detail"].apply(lambda x: re.findall("(?i)[a-z|&|-]+", x)))
		indx_opt = self.aplha_month(indx_opt, self.month_int_code)
		# indx_opt ["week_of_month"]= int(indx_opt ["week_of_month"])
		indx_opt= self.nod_month_handling(indx_opt)
		# indx_opt["expiry_month"]= np.where(indx_opt["expiry_month"]=="O", "OCT", np.where(indx_opt["expiry_month"]=="N",
		#                                 "NOV", np.where(indx_opt["expiry_month"]=="D", "DEC",indx_opt["expiry_month"] )))
		indx_opt = self.append_month_code(indx_opt)
		indx_opt = self.create_ric_indx(indx_opt, fut= False)

		indx_opt = indx_opt[['underelying_asset', 'strike_detail', 'Reuters']]
		indx_fut = indx_fut[['underelying_asset', 'strike_detail', 'Reuters']]

		df= pd.concat([indx_opt,indx_fut], axis=0)
		return df

	# def __str__(self):
	# 	print("This Class will process the files to generate the Reuters formatted data")






