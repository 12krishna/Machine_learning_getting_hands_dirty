# -*- coding: utf-8 -*-
"""
Created on Fri Jul 22 14:15:44 2021

@author: krishna
"""

import os, shutil
import re
import pandas as pd
import numpy as np
import simplefix
import datetime
from dateutil.relativedelta import relativedelta
import time
from collections import OrderedDict
import sys
import logging
import warnings
warnings.filterwarnings("ignore")
import cassandra_utility
#import socket
import ConfigParser

# load config details
config_parser = ConfigParser.ConfigParserUtility(os.path.join(os.getcwd(), "config.txt"))
config_props_dict = config_parser.parse_configfile()
        
# log events in debug mode 
logging.basicConfig(filename=os.path.join(config_props_dict["log_dir"].strip(), "fixorders_test.log"),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

session_wise_tag_dict = {"I_TORA":{"order":"116", "execution":"129"},
                         "I_EZE":{"order":"115", "execution":"128"}}

final_cols = ['ParentOrdID', 'ClientOrdID', 'Og_ClientOrdID', 'Tag115', 'Account', 'Algorithm', 'Side', 'Symbol', 'RIC', 'Instrument',
              'expiry', 'tag610_1', 'tag610_2', 'tag624_1','tag624_2','OptionType', 'OrderQty', 'OrdType', 'LimitPrice', 'ExecutedQty', 'AvgPx', 'PendingQty',
              'LastQty1', 'LastQty2', 'LastAvgPx', 'ArrivalTime', 'StartTime', 'EndTime', 'LastFillTime', 'tag150', 'tag39', 'State',
               'Tag50', 'POV %', 'Cumm value Cr','Cumm value $mn', 'Tag21','tag1','Tag49','ParentOrdID_edma','adv']

cal_months_list = [ (datetime.datetime(2000,1,1)+relativedelta(month=i)).strftime("%b") for i in range(1,13)]
monthly_codes_fut = OrderedDict(zip(cal_months_list, ['F','G','H','J','K','M','N','Q','U','V','X','Z']))
monthly_call_options = OrderedDict(zip(cal_months_list, [c for c in map(chr, range(ord('A'), ord('M')))]))
monthly_put_options = OrderedDict(zip(cal_months_list, [c for c in map(chr, range(ord('M'), ord('Y')))]))

class TailFileReader():
    '''Class to read input file
    keeps running track of file offset
    '''
    def __init__(self, filename):
        self.offset = 0
        self.filename = filename
        #self.input_schema = schema
    def read(self):
        # read file and process output
        prev_file =  open(os.path.join(config_props_dict["ul_path"].strip(),'{}'.format(self.filename)), 'r', encoding='cp1252')# read prev updated file
        prev_file = prev_file.readlines()[self.offset:]
        self.offset+=len(prev_file) # update the offset
        logging.info("curr len{} , file offset {}".format(len(prev_file), self.offset))
        return prev_file


class ULFIXOrders(object):
    '''UL FIX order monitoring
    '''
    def __init__(self, filename):
        # get tail file reader
        self.input_table = self.read_inputfiles()
        self.pinpoint_sessions = self.input_table[self.input_table['Session'].str.startswith("I_BLP")]['Session'].values.tolist()
        self.expr_4_4 = r'8=FIX\.4\.4.*?[10=\d+\|]$'       # pattern to recognize line with valid excution or order line ;
                                        #match line with pattern 8=FIX.4.2 and ending with 10=number|
        self.expr_4_2 = r'8=FIX\.4\.2.*?[10=\d+\|]$'

        self.instrument, self.options_instrument, self.mw_mleg_instru = self.read_instrument()
        self.tail_filereader = TailFileReader(filename) # obj to read file in tail mode
        self.orders = pd.DataFrame(columns=['Algorithm','Value in Rs Cr'])
        self.last_total = 0
        self.last_multiple = 1
        self.order_cols = ['Session','MsgType','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','OrdType','LimitPrice',
                                  'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'Remarks', 'Algorithm',
                                  'Ticker', 'ArrivalTime','Tag115','tag9271','167','200','Tag21','Tag116','Tag57','Tag50',
                                  'Tag49','Tag56','OptionType','Strike',"POV %", "tag610_1", "tag610_2",'tag624_1','tag624_2']
        self.exec_cols = ['Session','MsgType','ClientOrdID','Og_ClientOrdID','ClientName','tag150','tag39','tag151','tag14','AvgPx','Symbol','OrdType','LimitPrice',
                                  'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'Remarks', 'Algorithm',
                                  'Ticker', 'ExecutionTime','Tag128','tag9271','167','200','LastFillTime','OptionType','ParentOrdID',
                                  'LastPx','LastQty','tag442','tag17','Duplicates']
        # enriched final batch data for orders and execution
        self.order_final_cols = self.order_cols+['RIC','RICNse','expiry','LotSize', 'PreviousClose','value']
        self.exec_final_cols = self.exec_cols

        self.orders_df = pd.DataFrame(columns = self.order_final_cols)
        self.executions_df = pd.DataFrame(columns = self.exec_final_cols)

        # mleg
        self.mleg_orders = pd.DataFrame(columns = ['Session', 'MsgType','ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'RIC','RICNse', 'OrdType',
                                'LimitPrice', 'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'Remarks', 'Algorithm',
                                 'Ticker', 'ArrivalTime', 'Tag115', 'tag9271', '167', '200', 'Tag21', 'Tag116', 'Tag57', 'Tag50', 'Tag49',
                                  'Tag56', 'OptionType', 'POV %', 'tag610_1', 'tag610_2', 'tag624_1','tag624_2','expiry', 'Symbol', 'Cumm value'])
        self.mleg_executions = pd.DataFrame(columns = ['Session', 'MsgType', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'tag150',
                                'tag39', 'tag151', 'tag14', 'AvgPx', 'RICNse', 'OrdType', 'LimitPrice', 'Side', 'SecurityExchange',
                                 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'Remarks', 'Algorithm', 'Ticker', 'ExecutionTime', 'Tag128',
                                 'tag9271',  '167', '200', 'LastFillTime', 'OptionType', 'ParentOrdID', 'LastPx', 'LastQty', 'tag442','tag17',
                                 'expiry', 'Symbol', 'LotSize', 'PreviousClose'])
        self.mleg_executions_summary = pd.DataFrame(columns = ['ParentOrdID', 'ClientOrdID', 'Og_ClientOrdID', 'tag39', 'tag150', 'AvgPx'])
        # maintain exchnage traded account id from O_KITSETS downstream sessions
        self.exch_accountids = pd.DataFrame()
        self.exch_accountids_cols = ['Session','MsgType','ParentOrdID','tag1','Side','Symbol','RIC','ClientOrdID']
        self.rejection_master = pd.DataFrame()
        self.disconnected_cols = ['Session','MsgType','ParentOrdID','ClientOrdID','Og_ClientOrdID','TradeId','tag19']
        self.disconnected_df = pd.DataFrame(columns=self.disconnected_cols)

        # creating cassandra session to fetch data
        self.cassandra_obj = cassandra_utility.Cassandra_utility()
        # get dollars value
        self.dollar_value = self.get_dollar_value()
        self.daily_adv = self.get_futures_adv()
        
        
    def get_dollar_value(self):
        '''
        func to get dollar value
        from cassandra table bloom_usd_inr
        '''
        print ("Getting dollar value from cassandra")
        result = self.cassandra_obj.read("SELECT * from bloom_usd_inr where date>='{}' allow filtering".format(
                datetime.datetime.now().date()-datetime.timedelta(days=7)), 'date')
        result = float(round(result.tail(1)['usd_inr'].values[0],2))
        print (f"Dollar value {result}")
        return result

    def get_futures_adv(self):
        '''
        func to get average daily volumes
        for futures contract; for last 30 days
        '''

        df = pd.read_csv(os.path.join(config_props_dict["adv_dir"].strip(), "daily_advs.csv"))
        df['expiry'] = df['expiry_dt'].apply(lambda row: "".join(row.split("-")[:-1]) )
        df = df[['symbol','expiry','volume']]
        df.columns = ['Symbol','expiry','adv']
        
        return df
            
    def flattern(self, A):
        '''
        flatterns nested list
        '''
        rt = []
        for i in A:
            if isinstance(i,list): rt.extend(self.flattern(i))
            else: rt.append(i)
        return rt
    
    def read_inputfiles(self):
        
        df = pd.read_csv(os.path.join(config_props_dict["input_dir"].strip(), "Ordermaster_eze_tora.csv"))
        df['FIX Version'] = df['FIX Version'].astype(str)
        self.sessions_4_4 = list(set(df[(df['FIX Version']=='4.4')]['Session'].values.astype(str)))
        self.sessions_4_2 = list(set(df[(df['FIX Version']=='4.2')]['Session'].values.astype(str)))
        self.tags_4_4 = list(set(df[(df['FIX Version']=='4.4')]['Tag115'].values.astype(str)))
        self.tags_4_2 = list(set(self.flattern(df[(df['FIX Version']=='4.2')][['Tag115','Tag116']].values.astype(str).tolist())))
        self.tags_4_2.remove("nan")
        #df.rename(columns={'Tag1':'ClientName','Algo Tag':'Algorithm'}, inplace=True)
        df.rename(columns={'Tag1':'ClientName'}, inplace=True)
        
        df.fillna("None", inplace=True)
        
        return df
    
    
    def read_instrument(self):

        print("Reading instrument files...")
        instru = pd.read_csv(os.path.join(config_props_dict["instru_dir"].strip(), "instrument.csv"))
        cash_close = instru[instru['ExchangeSegment']=='NSE'][['Symbol','PreviousClose']].drop_duplicates().dropna()
        options_master = instru[instru['InstrumentType'].isin(['OPTSTK','OPTIDX'])]
        options_ric = pd.read_csv(os.path.join(config_props_dict["ric_code_dir"].strip(), "ric_source.csv"))[['NSE SYMBOL','Reuters']]
        options_ric.columns = ['TradingSymbol','RICNSE']
        options_master = options_master.merge(options_ric, on=['TradingSymbol'], how='left')
        
        instru = instru[(instru['InstrumentType'].isin(['FUTIDX','FUTSTK']))&(instru['ScripType']=='NORMAL')]
        instru['expiry'] = instru['ExpiryDate'].apply(lambda row: row.split("-")[-1]+row.split("-")[1])
        
        #replace to previus expiry
        #instru.loc[instru['expiry']=='202210','expiry']='202209'
        #instru.loc[instru['expiry']=='202211','expiry']='202210'
        #instru.loc[instru['expiry']=='202212','expiry']='202211'

        # get nse symbols
        scripmaster = pd.read_csv(os.path.join(config_props_dict["scripmaster_dir"].strip(), "scripmaster.csv"), encoding = "cp1252",
                                  names = ['Symbol','BseSymbol','UnnamedField3','Company Name','UnnamedField5','UnnamedField6',
                                           'ISIN','RICNse','Sedol','RICBse','UnnamedField11','BseTicker','NseTicker','UnnamedField14','NfoTicker'] )
        scripmaster = scripmaster[['Symbol','RICNse','NfoTicker','NseTicker']]
        scripmaster = scripmaster.append(pd.DataFrame([['NIFTY','NIF','NZ'], ['BANKNIFTY','NBN','AF']], 
                                                      columns=['Symbol','RICNse','NfoTicker']))
        instru = instru.merge(scripmaster, on=['Symbol'], how='left')
        instru = instru[['Symbol','TradingSymbol', 'NfoTicker','NseTicker','RICNse','expiry','LotSize','PreviousClose','ExpiryDate']]
        instru['RICNse']=instru['RICNse'].str.replace('.',':')
        instru.dropna(inplace=True, subset=['NfoTicker','RICNse'])
        instru['NseTicker'] = instru['NseTicker'].fillna('').apply(lambda row: row[1:] if row!='' else row)
        
        instru = instru.merge(cash_close, on=['Symbol'], how="left", suffixes=('','_cash'))
        instru['ExpiryDate'] = instru['ExpiryDate'].apply(lambda row: datetime.datetime.strptime(row, "%d-%m-%Y"))
        instru['bloom_monthcode'] = instru['ExpiryDate'].apply(lambda row: monthly_codes_fut[row.strftime("%b")] + str(row.year)[-1])
        instru['NfoTicker'] = instru[['NfoTicker','bloom_monthcode']].apply(lambda row: row['NfoTicker']+"=" + \
                              row['bloom_monthcode'] + " IS Equity" , axis=1).apply(
                                      lambda row: "".join(row.split("=")).replace("IS Equity",'Index') if row.startswith("NZ=") or row.startswith("AF=") else row )
        instru['NseTicker'] = instru[['NseTicker','Symbol']].apply(lambda row: row['NseTicker']+" IS Equity" \
                              if row['Symbol'] not in ['NIFTY','BANKNIFTY','FINNIFTY'] else row['NseTicker'], axis=1)
        instru['RICNse'] = instru[['RICNse','bloom_monthcode']].apply(lambda row: row['RICNse'].split(":NS")[0] + row['bloom_monthcode'] + ":NS" \
                              if row['RICNse'] not in ['NBN','NIF'] else row['RICNse']+row['bloom_monthcode'] , axis=1)
        instru.drop(columns=['ExpiryDate','bloom_monthcode'], inplace=True)
        instru['NseCash'] = instru['NseTicker'].apply(lambda row: row.split(" IS ")[0]+" IN" )
        
        # schonfeld futures
        instru_schonfeld = instru.copy(deep=True)
        instru_schonfeld['NfoTicker'] = instru_schonfeld['NfoTicker'].apply(lambda row: row.replace(" Equity",'') if row.lower().endswith("equity") \
                                            else row.replace(" Index",'') )
        
        # options master
        scripmaster.dropna(subset=['NfoTicker'], inplace=True)
        options_master = options_master.merge(scripmaster[['Symbol','NfoTicker','RICNse']], on=['Symbol'], how="left")
        options_master['ExpiryDate'] = options_master['ExpiryDate'].apply(lambda row: datetime.datetime.strptime(row, "%d-%m-%Y"))
        options_master['bloom_option_ticker'] = options_master['NfoTicker'].astype(str) + " IS " + options_master['ExpiryDate'].dt.month.astype(str) +\
                    "/"+options_master['ExpiryDate'].dt.day.astype(str)+"/"+ options_master['ExpiryDate'].dt.year.astype(str).str[-2:] + \
                    " " + options_master['OptionType'].str[0] + options_master['StrikePrice'].apply(lambda row: re.sub("\.0$", "", str(row))) + " Equity"
        # options RIC logic
        #options_master['ric_options_ticker'] = options_master[['RICNse','ExpiryDate','StrikePrice',
        #              'OptionType']].apply(lambda row: self.options_ric(row) , axis=1)
                
        options_master = options_master[['bloom_option_ticker','TradingSymbol','Symbol','ExpiryDate','StrikePrice','OptionType','LotSize','PreviousClose','RICNSE']]
        options_master['ExpiryDate'] = pd.to_datetime(options_master['ExpiryDate'], format='%Y-%m-%d %H:%M:%S').apply(lambda row: 
                                            datetime.datetime.strftime(row, "%Y%m%d"))
        
        logging.info("Instrument file read successfully ...")
        final = pd.DataFrame()
        # futures
        for col in ['NfoTicker','RICNse']:
            final = final.append(instru[[col,'TradingSymbol','Symbol','expiry','LotSize','PreviousClose']].rename(columns={col:'Ticker'}), ignore_index=True)
        # schonfeld futures
        final = final.append(instru_schonfeld[['NfoTicker','TradingSymbol','Symbol','expiry','LotSize','PreviousClose']].rename(
                    columns={'NfoTicker':'Ticker'}), ignore_index=True)
        
        final['Series'] = "FUT"
        # cash
        for col in ['NseTicker','NseCash']:
            temp = instru[[col,'TradingSymbol','Symbol','PreviousClose_cash']].rename(columns={col:'Ticker', 'PreviousClose_cash':'PreviousClose'})
            temp['LotSize'] = 1; temp['Series'] = 'CS'
            final = final.append(temp[['Ticker','Symbol','LotSize','PreviousClose','Series']].drop_duplicates(),ignore_index=True)
        # options
        options_master['Series'] = 'OPT'
        options_master.columns = ['Ticker','TradingSymbol','Symbol','expiry','Strike','OptionType','LotSize','PreviousClose','RICNse','Series']
        options_master['OptionType'] = options_master['OptionType'].str.replace("CE","1").replace("PE","0")
        
        final = final.append(options_master[['Ticker','TradingSymbol','Symbol','expiry','Strike','OptionType','LotSize','PreviousClose','Series']], ignore_index=True)
        final.drop_duplicates(subset=['Ticker'], inplace=True)
        final['temp'] = final['Ticker'].str.lower()
        
        # monthly options contracts for MW
        monthly_index = options_master[options_master['Symbol'].isin(["NIFTY",'BANKNIFTY'])]
        re_patterns = {'NZ IS':'NIFTY', 'AF IS':'NSEBANK', ' Equity':''}
        monthly_index['Ticker'] = monthly_index['Ticker'].replace(re_patterns, regex=True)
        
        options_master = options_master.append(monthly_index, ignore_index=True)
        
        # MW mleg instru master
        mw_mleg_instru = final[(final['Ticker'].str.contains("=")) & (final['Ticker'].str.lower().str.contains("is equity"))]
        mw_mleg_instru['Ticker'] = mw_mleg_instru['Ticker'].apply(lambda row: row.split("=")[0] if "=" in row else row)    
        
        return final, options_master, mw_mleg_instru


    def ric_code_gen(self, tag55, tag167):
        '''func to get RIC code for FNO
        '''

        try:
            if (tag55.lower().endswith(" in")) or (tag55.lower().endswith(" is equity")) or (tag55.lower().endswith(" index")):
                # bloomberg code in tag55/48
                return tag55
            
            ric_root = tag55.split(":")
            if (tag167=='FUT') or (tag167=='MLEG'):
            #if (tag167.startswith("F")) or (tag167.startswith("M")):
                
                if ric_root[0][:-2] in ['NIF','NBN','NTS']:
                    return ric_root[0][:-2]
                else:
                    return ric_root[0][:-2]+":NS"
                    
            elif (tag167=='OPT'):
                
                return tag55
            else:
                return tag55
            
        except Exception as e:
            print (e)
            print (tag55)
            
            return tag55
        
    
    def parse_bytes(self, msg, tag):

        msg_response = msg.get(tag[0], tag[1]) if type(tag)==list else msg.get(tag)
        if str(msg_response)!='None':
            return str(msg_response.decode("utf-8"))
        else:
            return "None"

    def fixparse_message(self, curr_session, line, exec_type, fix_version):

        rx = ''
        if ("8=FIX.4.2" in line): # (fix_version=="4.2"):
            rx = re.findall(self.expr_4_2, line)
        elif ("8=FIX.4.4" in line): #(fix_version=="4.4") :
            rx = re.findall(self.expr_4_4, line)
            
        x = rx[0].replace('|','\x01').replace(" \x01 "," | ") #string.replace(rx[0], '|','\x01')       
        parser = simplefix.FixParser()
        parser.append_buffer(x)
        msg = parser.get_message()
        
        if exec_type == 'order':
                
            return curr_session + "," + ",".join([self.parse_bytes(msg, tag) for tag in [35, 11, 41, 1, 55, 40, 44, 54,
                                                  100, 9251, 9252, 38, 9270]]) + "," + self.parse_bytes(msg, 58).replace(',',' ')\
                    + "," + ",".join([self.parse_bytes(msg, tag) for tag in [9250, 9272, 52, 115, 9271, 167, 200, 21, 116, 57,
                                      50, 49, 56, 201,202, 9260, 610, [610,2], 624, [624,2]]])
        elif exec_type == 'execution':
                
            return curr_session + "," + ",".join([self.parse_bytes(msg, tag) for tag in [35, 11, 41, 1, 150, 39, 151, 14, 6, 55,
                                                  40, 44, 54, 100, 9251, 9252, 38, 9270]]) + "," + self.parse_bytes(msg, 58).replace(',',' ')\
                    + "," + ",".join([self.parse_bytes(msg, tag) for tag in [9250, 9272, 60, 128, 9271, 167, 200, 52, 201, 37, 31,
                                      32, 442, 17, 43]])
        elif exec_type == 'downstream':
            # gets exchnage downstream account id
            return curr_session + "," +",".join([self.parse_bytes(msg, tag) for tag in [35, 37, 1, 54, 55, 48, 11]])
            
        elif exec_type == 'disconnected':
            return curr_session + "," +",".join([self.parse_bytes(msg, tag) for tag in [35, 37, 11, 41, 17, 19]])
                       
            
                    
    def filter_tag(self, curr_session, line, tag, exec_type, fix_version):
        
        rx = re.findall(self.expr_4_2, line) if "FIX.4.2" in line else re.findall(self.expr_4_4, line)
        if exec_type == "order":
            # client orders recieved    
            if tag!=None:
                #if np.any([ "115={}".format(t) in line for t in tag]):
                if np.any([ "115={}".format(t) in rx[0] or "116={}".format(t) in rx[0] for t in tag]):
                    return self.fixparse_message(curr_session, line, exec_type, fix_version)
                else:
                    return None
            else:
                return self.fixparse_message(curr_session, line, exec_type, fix_version)
            
        elif exec_type == 'execution':
            if tag!=None:
                #if np.any([ "128={}".format(t) in line for t in tag]):
                if np.any([ "128={}".format(t) in rx[0] or "129={}".format(t) in rx[0] for t in tag]):
                    return self.fixparse_message(curr_session, line, exec_type, fix_version)
                else:
                    return None
            else:
                return self.fixparse_message(curr_session, line, exec_type, fix_version)
                

    def filter_sessions_tags(self, line, exec_type):
        
        if (exec_type=='execution') and (("O_KITSETS" in line) or ("O_KITSOM" in line)) \
                and (("49=KTKMLPF" in line) or ("49=FIXOM" in line) ):
            # get exchange account id 
            return 0, self.fixparse_message("O_KITSETS", line, "downstream", "4.2" if "8=FIX.4.2" in line else "4.4" )
        
        if ("I_CITAFUT" in line):
            return None, self.fixparse_message([s for s in self.sessions_4_4 if s in line][0], line, exec_type, "4.4")
                
        #line = row
        if len(self.sessions_4_2+self.sessions_4_4)>0:
            # check if any of session present 
            if "8=FIX.4.2" in line:
                curr_session = [s for s in self.sessions_4_2 if s in line]
                if len(curr_session)>0:
                    return 1, self.filter_tag(curr_session[0], line, self.tags_4_2, exec_type, "4.2")
                else:
                    return 1, None
                
            if "8=FIX.4.4" in line:
                curr_session = [s for s in self.sessions_4_4 if s in line]
                if len(curr_session)>0:
                    return 1, self.filter_tag(curr_session[0], line, self.tags_4_4, exec_type, "4.4")
                else:
                    return 1, None
            return 1,None
            
        else:
            return 1, None
        
    def get_mleg_canceldetails(self, df):
        
        temp = self.mleg_orders.append(df, ignore_index=True)
        cols = ['OrdType','LimitPrice','Side','SecurityExchange','StartTime','EndTime','167','tag610_1','tag610_2']
        for index, row in df[df['MsgType']=='F'].iterrows():
            #temp1 = temp[(temp['ClientOrdID']==row['Og_ClientOrdID'])&(temp['MsgType']!='F')].tail(1)
            #df.loc[index, cols] = temp.loc[(temp['MsgType']!='F')&(temp['ClientOrdID']==row['Og_ClientOrdID'])][cols].values[-1].tolist()
            try:
                df.loc[index, cols] = temp.loc[(temp['MsgType']!='F')&(temp['ClientOrdID']==row['Og_ClientOrdID'])][cols].values[-1].tolist()
            except Exception as e:
                print (e)
        
        return df
    
    def handle_possible_duplicates(self, df):
        '''
        func to handle possible duplicates 
        sent during fix disconnection
        '''
        
        return df.drop(index=df[((df['Duplicates']=='Y') & \
                    ~(df['tag17'].isin(self.disconnected_df['TradeId'].values.tolist())))].index)
        
        
    def impute_cancel_orders(self, result):
        
        cols = ['ClientName','OrdType','LimitPrice','SecurityExchange','OrderQty','RIC','Algorithm']
        temp = result[result['MsgType']=='F'].merge(result[~(result['MsgType']=='F')][['ClientOrdID']+cols].rename(
                columns={'ClientOrdID':'Og_ClientOrdID'}), on=['Og_ClientOrdID'], how='left' ,suffixes=("","_y"))
        temp.loc[temp['MsgType']=='F', cols] = temp[[col+"_y" for col in cols]].values
        temp.drop(columns=[col+"_y" for col in cols], inplace=True)
        result = result[result['MsgType']!='F'].append(temp, ignore_index=True)
        
        return result
        
    
    def format_data(self, result, dtimecols):
        
        logging.info("func format data; df len {}".format(len(result)))
        time_zone = 'IST'       
        for dcol in dtimecols:
            if time_zone=='IST':
                result[dcol] = pd.to_datetime(result[dcol],errors="coerce") + datetime.timedelta(hours=5,minutes=30)
            else:
                result[dcol] = pd.to_datetime(result[dcol],errors="coerce") 
                    
        result[['OrdType','Side']] = result[['OrdType','Side']].astype(str)
        result.loc[result['OrdType'] == '1', 'OrdType'] = 'MKT'
        result.loc[result['OrdType'] == '2', 'OrdType'] = 'LMT'
        result.loc[result['Side'] == '1', 'Side'] = 'BUY'
        result.loc[result['Side'] == '2', 'Side'] = 'SELL'
        if "tag624_1" in result.columns.tolist():
            result.loc[result['tag624_1'].astype(str) == '1', 'tag624_1'] = 'BUY'
            result.loc[result['tag624_1'].astype(str) == '2', 'tag624_1'] = 'SELL'
            result.loc[result['tag624_2'].astype(str) == '1', 'tag624_2'] = 'BUY'
            result.loc[result['tag624_2'].astype(str) == '2', 'tag624_2'] = 'SELL'
        result.loc[(result['167']=='OPT') & (result['OptionType'] == '0'), 'OptionType'] = 'PE'
        result.loc[(result['167']=='OPT') & (result['OptionType'] == '1'), 'OptionType'] = 'CE'  
        # get exchnage segment
        result.loc[(result['167']=='OPT')&(result['SecurityExchange']=='None'), 'SecurityExchange'] = result['Symbol'].apply(
                lambda row: str(row).split(".")[-1] )
                
        result.loc[(result['SecurityExchange'] == 'NS')|(result['SecurityExchange'] == 'XNSE'), 'SecurityExchange'] = 'NSE'
        result.loc[(result['SecurityExchange'] == 'BO')|(result['SecurityExchange'] == 'XBSE'), 'SecurityExchange'] = 'BSE'
        result['expiry'] = result['200']
        
        if 'ExecutionTime' in dtimecols:
            result['LastQty'] = pd.to_numeric(result['LastQty'], errors='coerce').fillna(0).astype(float).round(0).astype(int)  # handle float quantity issue
            self.rejection_master = self.rejection_master.append(result[result['MsgType']=='9'])
            
            if result[result['Duplicates']=='Y'].empty==False:
                print ("Possible duplicates present in executions...")
                # handle duplicate messages
                result = self.handle_possible_duplicates(result)
    
        result['temp'] = result[['Session','ClientOrdID']].apply(lambda row: row['Session'].split("_")[-1]+"_"+row['ClientOrdID'], axis=1)
        result = result.merge(self.exch_accountids[['ClientOrdID','RIC']].rename(columns={'ClientOrdID':'temp'}), 
                              on=['temp'], how="left").drop(columns=['temp'])
        print (result.shape)
        
        # handle cancel orders
        if "ExecutionTime" not in dtimecols:
            result = self.impute_cancel_orders(result)
        
        '''
        # call RIC gen method
        if "Tag115" in result.columns.astype(str).values.tolist():
            result.loc[(~result['Tag115'].isin(['MLP']))&(~result['Session'].isin(self.pinpoint_sessions)), "Symbol"] = result[['Symbol','167']].apply(
                                lambda row: self.ric_code_gen(row['Symbol'], row['167']), axis=1)
        elif "Tag128" in result.columns.astype(str).values.tolist():
            result.loc[(~result['Tag128'].isin(['MLP']))&(~result['Session'].isin(self.pinpoint_sessions)), "Symbol"] = result[['Symbol','167']].apply(
                                lambda row: self.ric_code_gen(row['Symbol'], row['167']), axis=1)
        # get symbol only for options
        result.loc[(result['167']=='OPT')&(result['Session']!='I_BLPOPT'), 'Symbol'] = result['RIC'].apply(lambda s: s if s in ['NBN','NIF'] else str(s)+":NS")
        '''   
        # get lots size 
        #mleg_result = result[result['167']=='MLEG'].copy(deep=True)
        mleg_result = result[(result['167'].str.startswith("M"))].copy(deep=True)
        print ("MLEG shape ",mleg_result.shape)
        if mleg_result.empty==False:
            #mleg_result['Symbol'] = mleg_result['Symbol'].apply(lambda row: 
            #                            row.split("-")[0][:-2]+":NS" if '-' in row else row[:-2]+":NS")
            '''
            def mleg_symbol_construct(ticker):
                if "-" in ticker:
                    return ticker.split("-")[0][:-2]+":NS"
                elif '-' not in ticker and ticker.endswith(":NS"):
                    return ticker.split(":")[0][:-2]+":NS"
                else:
                    return ticker[:-2]+":NS"
                
            mleg_result['Symbol'] = mleg_result['Symbol'].apply(lambda row: mleg_symbol_construct(row))
                        
            mleg_result['Symbol'] = mleg_result['Symbol'].apply(lambda row: row[:-3] if row in ['NBN:NS','NIF:NS'] else row)
            '''
            # orders 
            mleg_orders = mleg_result[~mleg_result['MsgType'].isin(['8','9'])].rename(columns={'Symbol':'RICNse'})
            
            if mleg_orders.empty==False:
                # get expiry info for mleg F orders
                mleg_orders = self.get_mleg_canceldetails(mleg_orders.copy(deep=True))
                mleg_orders['Ticker'] = mleg_orders['RICNse'].apply(lambda row: row.split("=")[0] if "=" in row else row)
                mleg_orders = mleg_orders.merge(self.mw_mleg_instru.rename(columns={'expiry':'tag610_1', "LotSize":"LotSize1",
                                   "PreviousClose":'PrevClose1'}).drop_duplicates(), on=['Ticker','tag610_1'], how='left')
                mleg_orders = mleg_orders.merge(self.mw_mleg_instru[['Ticker','expiry','PreviousClose','LotSize']].rename(
                    columns={'expiry':'tag610_2',"PreviousClose":'PrevClose2','LotSize':'LotSize2'}).drop_duplicates(), 
                        on=['Ticker','tag610_2'], how='left')
                mleg_orders[['OrderQty1','LotSize1','LotSize2','LimitPrice','PrevClose1','PrevClose2']] = mleg_orders[['OrderQty',
                           'LotSize1','LotSize2','LimitPrice','PrevClose1','PrevClose2']].apply(pd.to_numeric, errors='coerce',axis=1)
                mleg_orders[['OrderQty1','LotSize1','LotSize2','LimitPrice','PrevClose1','PrevClose2']] = mleg_orders[['OrderQty1',
                           'LotSize1','LotSize2','LimitPrice','PrevClose1','PrevClose2']].fillna(0)
                            
                #mleg_orders['OrderQty1'] = mleg_orders['OrderQty'].apply(pd.to_numeric, errors='coerce')
                #mleg_orders['OrderQty1'] = mleg_orders['OrderQty1'].fillna(0)
                mleg_orders['Cumm value'] = np.where(mleg_orders['OrdType']=='LMT',
                                        mleg_orders['OrderQty1'].astype(int)*mleg_orders['LotSize1']*mleg_orders['LimitPrice'] +\
                                        mleg_orders['OrderQty1'].astype(int)*mleg_orders['LotSize2']*mleg_orders['LimitPrice'],
                                        mleg_orders['OrderQty1'].astype(int)*mleg_orders['LotSize1']*mleg_orders['PrevClose1'] +\
                                        mleg_orders['OrderQty1'].astype(int)*mleg_orders['LotSize2']*mleg_orders['PrevClose2'])
                mleg_orders['Cumm value'] = mleg_orders['Cumm value'].fillna(0)
                mleg_orders.drop(columns=['OrderQty1','LotSize1','LotSize2','PrevClose1','PrevClose2'], inplace=True)
            
                print ("MLEG orders present ....")
                logging.info("MLEG orders present ....")
                self.mleg_orders = self.mleg_orders.append(mleg_orders, ignore_index=True)
            
            mleg_executions = mleg_result[mleg_result['MsgType'].isin(['8','9'])].rename(columns={'Symbol':'RICNse'})
            
            if mleg_executions.empty==False:
                mleg_executions['Ticker'] = mleg_executions['RICNse'].apply(lambda row: row.split("=")[0] if "=" in row else row).apply(lambda row: row.split("-")[0] if "-" in row else row)
                mleg_executions = mleg_executions.merge(self.mw_mleg_instru[['Ticker','Symbol','expiry','PreviousClose','LotSize']].drop_duplicates(),
                                                        on=['Ticker','expiry'], how="left")
            
                mleg_executions_summary = mleg_executions[mleg_executions['tag442']=='3']
                mleg_executions_summary.sort_values(by=['LastFillTime'],kind='mergesort', inplace=True)
                mleg_executions_summary = mleg_executions_summary.groupby(by=['ParentOrdID','ClientOrdID'], as_index=False,
                														sort=False).last()
                # get symbol, lotsize and prev close by parentord id
                temp = self.mleg_executions.append(mleg_executions, ignore_index=True)
                temp = temp[temp['tag442']!='3'].groupby(by=['ParentOrdID'], as_index=False, sort=False).last()
                mleg_executions_summary = mleg_executions_summary.merge(temp[['ParentOrdID','Symbol','LotSize','PreviousClose']], 
                                                                        on=['ParentOrdID'], how='left',suffixes=('','_y'))
                mleg_executions_summary[['Symbol','LotSize','PreviousClose']] = mleg_executions_summary[['Symbol_y','LotSize_y','PreviousClose_y']]
                mleg_executions_summary.drop(columns=['Symbol_y','LotSize_y','PreviousClose_y'], inplace=True)
                #try:
                #    mleg_executions_summary.drop(columns=['LastFillTime'], inplace=True)
                #except Exception as e:
                #    print e
                mleg_executions = mleg_executions[mleg_executions['tag442']!='3']
            
                if mleg_executions_summary.empty==False:
                    self.mleg_executions_summary = self.mleg_executions_summary.append(mleg_executions_summary, ignore_index=True)
                    self.mleg_executions_summary.drop_duplicates(subset=['ParentOrdID','ClientOrdID','Og_ClientOrdID'], 
                                                                 keep='last', inplace=True)
                print ("MLEG executions present ....")
                logging.info("MLEG executions present ....")
                self.mleg_executions = self.mleg_executions.append(mleg_executions, ignore_index=True)
        
        if 'ExecutionTime' in dtimecols:
            return result
        
        #result=result[result['167']!='MLEG']
        result = result[~result['167'].str.startswith("M")]
        print ("Single leg ", result.shape)
        result['temp'] = result['Symbol']; result['Symbol'] = result['Symbol'].str.lower()
        dymon_options_sessions_mask = (result['Session'].isin(self.input_table[self.input_table['Tag115']=='DYMON']['Session'].values.tolist()))&(result['167']=='OPT')
        temp = self.options_instrument[['RICNse','Symbol','LotSize','PreviousClose','TradingSymbol']]
        temp['RICNse'] = temp['RICNse'].str.lower()
        result = (result[~dymon_options_sessions_mask].rename(columns={'Symbol':'RICNse'}).merge(self.instrument[['temp','Symbol','LotSize','PreviousClose',
                    'TradingSymbol']].rename(columns={"temp":"RICNse"}), on=['RICNse'], how='left')).append(
                result[dymon_options_sessions_mask].rename(columns={'Symbol':'RICNse'}).merge(temp, on=['RICNse'], how="left"))
        cols = list(result.columns)
        cols.remove("temp"); cols.remove("Ticker")
        result['RICNse'] = result['temp']
        df1 = result[result['Symbol'].isnull()].dropna(axis=1, how="all")
        
        
        if df1.empty==False:
            try:
                for dcol in ['StartTime','EndTime','ArrivalTime','LastFillTime']:
                    if dcol not in df1.columns.values.astype(str).tolist():
                        df1[dcol] = pd.NaT 
                
                
                # for I_BLPFUT sessions get lotsize and close prices
                df2 = df1[df1['Session'].isin([i for i in self.pinpoint_sessions if i.endswith('FUT')])].merge(
                        self.instrument[['Symbol','expiry','LotSize','PreviousClose','TradingSymbol']].drop_duplicates(subset=['Symbol',
                                       'expiry']).rename(columns={'Symbol':'RICNse'}), on=['RICNse','expiry'], how="left")
                df2['Symbol'] = df2['RICNse']; df2['RIC'] = df2['RICNse']; df2=df2[cols]
                
                # for I_BLPOPT get lotsize and close prices
                df3 = df1[(df1['Session'].isin(self.input_table[self.input_table['Agg Client Name']=='PINPOINT'][
                        'Session'].values.tolist())) & (df1['167']=='OPT')]
                opt_temp = self.options_instrument[['Symbol','TradingSymbol','expiry','Strike','OptionType','LotSize', 
                                                    'PreviousClose']].rename(columns={'Symbol':'RICNse'})
                opt_temp['expiry'] = opt_temp['expiry'].apply(lambda row: row[:-2])
                opt_temp['Strike'] = opt_temp['Strike'].apply(lambda row: str(row).split(".")[0] if str(row).endswith(".0") else str(row) )
                opt_temp['OptionType'] = np.where(opt_temp['OptionType']=='0', "PE", "CE")
                
                df3 = df3.merge(opt_temp, on=['RICNse','expiry','Strike','OptionType'],how="left")
                df3['Symbol'] = df3['RICNse']; df3['RIC'] = df3['RICNse']; df3 = df3[cols]
                
                result = result[~result['Symbol'].isnull()].append([df2, df3], ignore_index=True)
                
                df4 = df1[df1['Session']=='I_BLPHYB']
                
                if df4.empty==False:
                    print("Handling MW options")
                    # handle weekly options for MW
                    opt_temp = self.options_instrument[['Symbol','expiry','Strike','OptionType','LotSize','PreviousClose','TradingSymbol']].drop_duplicates(
                            subset=['Symbol','expiry','Strike','OptionType']).rename(columns={'Symbol':'RIC'})
                    opt_temp.loc[opt_temp['OptionType']=='1', 'OptionType'] = 'CE'; opt_temp.loc[opt_temp['OptionType']=='0', 'OptionType'] = 'PE'
                    opt_temp['Strike'] = opt_temp['Strike'].astype(str)
                    opt_temp.loc[opt_temp['Strike'].str.endswith('.0'), 'Strike'] = opt_temp['Strike'].str.replace(".0$", '', regex=True)
                    opt_temp = opt_temp.drop_duplicates(subset=['RIC','expiry','OptionType','Strike']).rename(columns={'expiry':'expiry_temp'})
                    opt_temp.loc[~opt_temp['RIC'].isin(['NIFTY','BANKNIFTY','MIDCPNIFTY']), 'expiry_temp'] = opt_temp['expiry_temp'].apply(lambda row: str(row)[:-2])
                    
                    
                    df4['expiry_temp'] = df4[['RICNse', 'expiry']].apply(lambda row: pd.to_datetime(re.search(r"\d{2}/\d{2}/\d{2}", row['RICNse']).group()).strftime("%Y%m%d") if "Index" in row['RICNse'] 
                                                                                           else row['expiry'], axis=1)
                    df4 = df4.merge(opt_temp, on=['RIC','expiry_temp','OptionType','Strike'], how="left")
                    df4['Symbol'] = df4['RICNse']; df4['RIC'] = df4['RICNse']; df4=df4[cols]
                    
                    result = result.append(df4, ignore_index=True)
                    print("MW options done...")
                '''
                df1 = df1[~df1['Session'].isin(self.pinpoint_sessions)].merge(self.instrument[['NfoTicker','Symbol','LotSize',
                          'PreviousClose']].rename(columns={'NfoTicker':'RICNse'}),on=['RICNse'], how='left')
                if (df1[df1['RICNse'].isnull()].empty==False)or(df1[df1['Symbol'].isnull()].empty==False):
                    # check on bloomberg symbols
                    df1 = df1[df1['Symbol'].isnull()].dropna(axis=1)
                    df1 = (df1[(df1['RICNse'].str.endswith(" IN"))|(df1['167']=='CS')].merge(self.instrument[['NseCash','Symbol','LotSize',
                               'PreviousClose_cash']].rename(columns={'PreviousClose_cash':'PreviousClose'}).drop_duplicates(
                                subset=["NseCash"]).rename(columns={'NseCash':'RICNse'}), on=['RICNse'], how="left")).append(
                        df1[df1['167']=='OPT'].merge(self.options_instrument[['bloom_option_ticker','Symbol','LotSize',
                           'PreviousClose']].rename(columns={'bloom_option_ticker':'RICNse'}), on=['RICNse'], how="left"))
                    # check for cash bloomberg symbols
                    #df1 = df1.merge(self.instrument[['NseTicker','PreviousClose']].rename(columns={'NseTicker':'RICNse'}),
                    #                on=['RICNse'], how="left")
                    for dcol in ['StartTime','EndTime','ArrivalTime','LastFillTime']:
                        if dcol not in df1.columns.values.astype(str).tolist():
                            df1[dcol] = pd.NaT 
                                                        
                if 'RIC' not in df1.columns:
                    df1['RIC'] = df1['RICNse']
                    df1 = df1[cols]
                else:
                    df1 = df1[cols]
                    
                df1.dropna(inplace=True, subset=['RICNse'])
                '''
                
            except Exception as e:
                print (e)
                logging.error(e)
                result = result[~result['Symbol'].isnull()]
        '''    
        if mleg_result.empty==False:
            result = result.append(mleg_result, ignore_index=True)
        ''' 
        result[['LotSize','OrderQty','LimitPrice','PreviousClose']] = result[['LotSize','OrderQty','LimitPrice',
                                                                          'PreviousClose']].apply(pd.to_numeric, errors='coerce')
        
        #result[['LotSize','OrderQty']] = result[['LotSize','OrderQty']].astype(int)
        #result['LimitPrice'] = pd.to_numeric(result['LimitPrice'], errors='coerce')
        #result['PreviousClose'] = pd.to_numeric(result['PreviousClose'], errors='coerce')
        #result.to_csv("batch.csv", index=False)
        try:
            result.loc[result['OrdType']=='LMT', 'value'] = result['LotSize'].fillna(0).astype(int)*result['OrderQty'].fillna(0).astype(int)*result['LimitPrice'].fillna(0).astype(float)
            result.loc[result['OrdType']=='MKT', 'value'] = result['LotSize'].fillna(0).astype(int)*result['OrderQty'].fillna(0).astype(int)*result['PreviousClose'].fillna(0).astype(float)
        except Exception as e:
            logging.error(e)
            result['value'] = 0.0
            print (e)
            print (dtimecols)
        
        print (result.shape)
        logging.info("func format data; result shape".format(result.shape))
        
        return result
        
    def prepare_order_executions(self, order, execution, exch_accountids, disconnected_lines):
        
        if len(disconnected_lines)>0:
            print ("FIX disconnection messages present...")
            self.disconnected_df = self.disconnected_df.append(pd.DataFrame(disconnected_lines, columns=self.disconnected_cols), ignore_index=True)
            
        if len(exch_accountids)>0:
            exch_accountids = pd.DataFrame(exch_accountids, columns = self.exch_accountids_cols)
            # drop UL move orders
            exch_accountids = exch_accountids[~exch_accountids['ClientOrdID'].str.lower().str.startswith('ulmove')]
            #exch_accountids = exch_accountids[(exch_accountids['tag1'].isin(_dma_accounts))].drop_duplicates(subset=['ParentOrdID'])
            exch_accountids.drop_duplicates(subset=['ParentOrdID'], keep='last', inplace=True)
            exch_accountids.loc[(exch_accountids['RIC']=='None')&(exch_accountids['Symbol']!='None'), 'RIC'] = exch_accountids['Symbol']
            #update global
            self.exch_accountids = (self.exch_accountids.append(exch_accountids, ignore_index=True)).drop_duplicates(subset=['ParentOrdID'])
        
        if len(order)>0:
            order = self.format_data(pd.DataFrame(order, columns=self.order_cols), ["ArrivalTime","StartTime","EndTime"])[self.order_final_cols]
            order['LotSize'] = pd.to_numeric(order['LotSize'], errors='coerce').fillna(1)
            order['PreviousClose'] = pd.to_numeric(order['PreviousClose'], errors='coerce').fillna(0)

            # update global
            self.orders_df = self.orders_df.append(order, ignore_index=True)
        if len(execution)>0:
            execution = self.format_data(pd.DataFrame(execution, columns=self.exec_cols), ["ExecutionTime","StartTime",
                                         "LastFillTime"])[self.exec_final_cols]
            execution[['tag151','tag14','AvgPx']] = (execution[['tag151','tag14','AvgPx']].apply(pd.to_numeric, errors='coerce')).fillna(0)

            # update global
            self.executions_df = self.executions_df.append(execution, ignore_index=True)

        
    def read_records(self):

        # read master input
        try:
            self.input_table = self.read_inputfiles()
        except Exception as e:
            print ("Issue reading FIX file",e)
        stime = time.time()
        records = self.tail_filereader.read()
        print ("File read time {}".format(time.time()-stime))
        order = []
        execution = []
        exch_accountids = []
        disconnected_lines = []
        # parse fix records
        stime = time.time()
        if len(records)>0:
            for line in records:
                try:
                    #if ("SCHONFELDUAT44" in line) and ("35=D" in line):
                    #    break
                    rx = re.findall(self.expr_4_2, line) if "FIX.4.2" in line else re.findall(self.expr_4_4, line)
                    if ("disconnected" in line) and rx:
                        # maintain disconnected messages to backtrack and find duplicate messages
                        curr_session = [s for s in self.sessions_4_2 if s in line] if "8=FIX.4.2" in line else [s for s in self.sessions_4_4 if s in line]
                        disconnected_lines.append(self.fixparse_message(curr_session[0], line, 'disconnected', '4.2').split(","))
                    else:                            
                        if ('35=D' in line) or ('35=G' in line) or ('35=F' in line) or ('35=AB' in line) or ('35=AC' in line):
                            # get order FIX parse msg
                            _, temp = self.filter_sessions_tags(line, "order")
                            if temp!=None:
                                order.append(temp.split(","))
                        elif (('35=8' in line) or ('35=9' in line)):  # ignore summary fills for MLEG i.e. 442=3
                            # get execution FIX parse msg
                            flag, temp = self.filter_sessions_tags(line, "execution")
                            if flag==0:
                                exch_accountids.append(temp.split(",")) # maintains exchange traded account ids
                                continue  #line can either be O_KITS session or I_MLP session; hence continue looping if O_KITS
                            if temp!=None:
                                execution.append(temp.split(","))
                except Exception as e:
                    print (e, line)

        print ("Loop time {}".format(time.time()-stime))
        
        self.prepare_order_executions(order, execution, exch_accountids, disconnected_lines)



    def debug_dump_data(self, df, filename):

        # debug dump data
        while 1:
            try:
                df.to_csv(filename, index=False)
                break
            except Exception as e:
                print (e)
                print ("File in use")
                logging.error("File in use {}".format(e))


    def agg_sum(self, grp, qtycol):

        grp = grp.groupby(by=['Algorithm'], as_index=False, sort=False).agg({'value':'sum',
                         qtycol:'sum'})
        grp['value'] = grp['value']/10**7
        return grp

    def order_summary(self, grp, flag):

        tag21 = grp['Tag21'].values[0]
        algo = grp['Algorithm'].values[0]
        instru = grp['167'].values[0]
        max_ord_lot = grp['OrderQty'].max()
        max_ord_value = grp[grp['OrderQty']==grp['OrderQty'].max()].head(1)
        if max_ord_value['OrdType'].values[0]=='LMT':
            max_ord_value = round(max_ord_value['OrderQty']*max_ord_value['LimitPrice']*max_ord_value['LotSize']/10**7,4)
        else:
            max_ord_value = round(max_ord_value['OrderQty']*max_ord_value['PreviousClose']*max_ord_value['LotSize']/10**7,4)


        if flag==0:
            # new order
            executed = grp[((grp['tag150']=='F')&(grp['tag39']=='2'))|(grp['tag150']=='3')]
            pending = grp[((grp['tag150']=='F')&(grp['tag39']=='1'))|((grp['tag150']=='0')&(grp['tag39']=='0'))]

            return pd.Series({'Instrument':instru,'Algo-NonAlgo':algo,'Tag 21':tag21,
                              'Cumm Orders':len(grp),'Cumm value Cr':round(grp['Cumm value'].sum()/10**7,4),
                              'Executed Orders':len(executed),'Executed value Cr': round(grp['Executed value'].sum()/10**7,4),
                              'Pending Orders':len(pending),'Pending value Cr': round(grp['Pending value'].sum()/10**7,4) if len(pending)>0 else 0.0,
                              'Max Order Lots':max_ord_lot, 'Max Order Value Cr':max_ord_value
                              })
        elif flag==1:
            # modifyReplace/Cancel orders
            executed = grp[((grp['MsgType']=='F')&(grp['tag39']=='4'))| # cancel confirm
                            ((grp['MsgType'].isin(['G','AC']))&(grp['tag150'].isin(['F','3']))&(grp['tag39'].isin(['2','3'])))]# replace executed

            pending = grp[((grp['MsgType']=='F')&(grp['tag39']=='6'))| # pending cancel
                            ((grp['MsgType'].isin(['G','AC']))&(grp['tag150'].isin(['E','1','F']))&(grp['tag39'].isin(['E','5','1'])))]# pending replace scenarios


            return pd.Series({'Instrument':instru,'Algo-NonAlgo':algo,'Tag 21':tag21,
                              'Cumm Orders':len(grp),'Cumm value Cr':round(grp['Cumm value'].sum()/10**7,4),
                              'Executed Orders':len(executed),'Executed value Cr': round(grp['Executed value'].sum()/10**7,4),
                              'Pending Orders':len(pending),'Pending value Cr': round(grp['Pending value'].sum()/10**7,4) if len(pending)>0 else 0.0,
                              'Max Order Lots':max_ord_lot, 'Max Order Value Cr':max_ord_value
                              })

    def value_calc(self, df):

        df['Cumm value'] = np.where(df['OrdType']=='LMT',
               df['OrderQty']*df['LotSize']*df['LimitPrice'],
               df['OrderQty']*df['LotSize']*df['PreviousClose'])
        df['Executed value'] = df['tag14']*df['LotSize']*df['AvgPx']
        df['Pending value'] = np.where(df['OrdType']=='LMT', df['tag151']*df['LotSize']*df['LimitPrice'],
                                           df['tag151']*df['LotSize']*df['PreviousClose'])

        return df

    def merge_inputmaster(self, df):

        input_table = self.input_table.drop(columns=['FIX Version','Algo Tag'])
        input_table.rename(columns={'Tag1':'ClientName'}, inplace=True)
        for _, row in input_table.iterrows():
            temp = pd.DataFrame(row)
            temp.columns = [0]
            temp = temp[temp[0]!='None'].T
            df = df.merge(temp, on=[col for col in temp.columns.tolist() if col!="Agg Client Name"], how="left", suffixes=("","_y"))
            if "Agg Client Name_y" in df.columns:
                df.loc[~df['Agg Client Name_y'].isnull(), "Agg Client Name"]=df['Agg Client Name_y']
                df.drop(columns=['Agg Client Name_y'], inplace=True)

        return df

    def getOrderState(self, row):
        '''Func to get order current status'''

        state = 'null'
        if ((str(row['tag150'])=='F') and (str(row['tag39'])=='1')) or ((str(row['tag150'])=='1') and (str(row['tag39'])=='1')):
            state = 'PartialFill'
        elif ((str(row['tag150'])=='F') and (str(row['tag39'])=='2')) or ((str(row['tag150'])=='2') and (str(row['tag39'])=='2')):
            state = 'Completed'
        elif (str(row['tag150'])=='3') or (str(row['tag39'])=='3'):
            state = "DoneForTheDay"
        elif (str(row['tag150'])=='4') or (str(row['tag39'])=='4'):
            state = "Cancelled"
        elif (str(row['tag150'])=='A') or (str(row['tag39'])=='A'):
            state = "PendingNew"
        elif (str(row['tag150'])=='E') or (str(row['tag39'])=='E'):
            state = "PendingReplace"
        elif (str(row['tag150'])=='9') or (str(row['tag39'])=='9'):
            state = "Suspended"
        elif (str(row['tag150'])=='8') or (str(row['tag39'])=='8'):
            state = "Rejected"
        elif (str(row['tag150'])=='7') or (str(row['tag39'])=='7'):
            state = "Stopped"
        elif (str(row['tag150'])=='6') or (str(row['tag39'])=='6'):
            state = "PendingCancel"
        elif (str(row['tag150']) in ['5']):
            state = "Replaced"
        elif (str(row['tag150']) in ['G']):
            state = "TradeCorrect"
        elif (str(row['tag150']) in ['H']):
            state = "TradeCancel"
        elif (str(row['tag150']) in ['D']):
            state = "Restated"
        elif (str(row['tag150'])=='0'):
            state = "Open"
        
        return state

    def get_mleg_last_qty_avpgpx(self, df):

        try:
            last_qty_avgpx = df.sort_values(by=['LastFillTime']).groupby(by=['ClientOrdID','Symbol','Side_exec'], sort=False).apply(
                                lambda grp: pd.Series({
                                        "LastQty": grp['LastQty'].astype(int).sum(),
                                        "LastPx": np.average(grp['LastPx'].astype(float), weights=grp['LastQty'].astype(int)) if grp['LastQty'].astype(int).sum() else 0
                                        })).reset_index()
            last_qty_avgpx = last_qty_avgpx.groupby(by=['ClientOrdID'], sort=False).apply(
                                lambda grp: pd.Series({
                                        "LastQty1":grp['LastQty'].values[0],"LastQty2": grp['LastQty'].values[1] \
                                        if len(grp)>1 else 0,
                                        "LastAvgPx": round((grp['LastPx'].values[0]+grp['LastPx'].values[1])/2, 4) \
                                        if len(grp)>1 else grp['LastPx'].values[0]
                                        }) ).reset_index()
        except Exception as e:
            # Exception if there is no fills for current streams
            print ("Error {}; len of null qunatities {}".format(e, len(df[df['LastQty'].isnull()])))
            last_qty_avgpx = pd.DataFrame(columns=['ClientOrdID','LastQty1','LastQty2','LastAvgPx'])

        return last_qty_avgpx

    def get_single_leg(self, grp):

        grp = grp[grp['expiry_exec']==min(grp['expiry_exec'])]
        grp.sort_values(by=['LastFillTime'], inplace=True)
        grp = grp.tail(1)

        return grp
    
    def prefix_session(self, df):
        
        #Prefix session; to handle duplicate client ord in same session
        if df.empty==False:
            df['ClientOrdID'] = df['Session'].astype(str)+"_"+df['ClientOrdID'].astype(str)
            if 'Og_ClientOrdID' in df.columns:
                df['Og_ClientOrdID'] = df['Session'].astype(str)+"_"+df['Og_ClientOrdID'].astype(str)
            
        return df

    def compute_orders(self):

        logging.info("Computing order...")
        orders_df = self.orders_df[['Session','MsgType','ClientOrdID','Og_ClientOrdID','Symbol','RICNse','OrdType','LimitPrice',
                                    'Side','OrderQty','Algorithm','167','expiry','LotSize','PreviousClose','ClientName',
                                    'Tag115','Tag21','Tag116','Tag57','Tag50','Tag49','Tag56','OptionType','StartTime',
                                    'EndTime','ArrivalTime',"POV %"]]
        # replace None tag115
        orders_df.loc[orders_df['Tag115']=='None', 'Tag115'] = orders_df['Tag116']
        executions_df = self.executions_df[['Session','MsgType','ClientOrdID','Og_ClientOrdID','tag150','tag39','tag151','tag14',
                                         'AvgPx','Symbol','Side','OrdType','Algorithm','LastFillTime','ParentOrdID','LastPx',
                                         'LastQty','tag17']]
        #result['tag17'] = result['tag17'].apply(lambda row: row[8:].split("N")[0] if "N" in row else row )
        # prefix sessions
        orders_df = self.prefix_session(orders_df.copy(deep=True))
        executions_df = self.prefix_session(executions_df.copy(deep=True))
        rejection_master = self.prefix_session(self.rejection_master.copy(deep=True))
        mleg_orders = self.prefix_session(self.mleg_orders.copy(deep=True))
        mleg_executions = self.prefix_session(self.mleg_executions.copy(deep=True))
        if self.mleg_executions_summary.empty==False:
            mleg_executions_summary = self.prefix_session(self.mleg_executions_summary.copy(deep=True))
        
    
        # check if 35=D has any G or F orders
        modify_cancel = orders_df[(orders_df['MsgType'].isin(['G','F']))]
        modify_cancel['LimitPrice'] = modify_cancel['LimitPrice'].fillna('None')
        for col in ['167', 'Tag21','OrdType','LimitPrice','POV %']:
            temp = orders_df[(orders_df[col].astype(str)!='None')&(orders_df['ClientOrdID'].isin(
                modify_cancel[modify_cancel[col].astype(str)=='None']['Og_ClientOrdID'].values.tolist()))][['ClientOrdID',col]].rename(
                columns={'ClientOrdID':'Og_ClientOrdID'})
            temp.drop_duplicates(inplace=True)
            modify_cancel =  modify_cancel.merge(temp,on=['Og_ClientOrdID'], how="left", suffixes=("","_y"))
            modify_cancel.loc[modify_cancel[col].astype(str)=='None', col] = modify_cancel['{}_y'.format(col)]
            modify_cancel.drop(columns=['{}_y'.format(col)], inplace=True)
        modify_cancel['LimitPrice'] = modify_cancel['LimitPrice'].astype(float)
        org_orders = orders_df[~(orders_df['ClientOrdID'].isin(modify_cancel['ClientOrdID'])) &\
                                    ~(orders_df['ClientOrdID'].isin(modify_cancel['Og_ClientOrdID']))]

        # dont update cancel arrival time
        modify_cancel_temp = modify_cancel[modify_cancel['MsgType']=='F']
        if modify_cancel_temp.empty==False:
            modify_cancel_temp = modify_cancel_temp.merge(orders_df[orders_df['MsgType']=='D'][['ClientOrdID','ArrivalTime']].rename(
                                    columns={"ClientOrdID":"Og_ClientOrdID"}), on=['Og_ClientOrdID'], how="left", suffixes=("","_temp"))
            #modify_cancel_temp['ArrivalTime'] = modify_cancel_temp['ArrivalTime_temp']
            modify_cancel_temp.loc[~modify_cancel_temp['ArrivalTime_temp'].isnull(), "ArrivalTime"] = modify_cancel_temp['ArrivalTime_temp']
            modify_cancel_temp.drop(columns=['ArrivalTime_temp'], inplace=True)
            modify_cancel = modify_cancel[modify_cancel['MsgType']!='F'].append(modify_cancel_temp, ignore_index=True)

        innertable_cols = ['ParentOrdID','ClientOrdID','Og_ClientOrdID','Tag115','ClientName','tag17','Algorithm',
                           'Side','Symbol','RICNse','167','expiry',
                           'OptionType','OrderQty','OrdType','LimitPrice','tag14','AvgPx','tag151','ArrivalTime',
                           'StartTime','EndTime','LastFillTime','Tag50','POV %','Cumm value','tag150','tag39',
                           'Tag21','Tag49']
        final = pd.DataFrame()
        if org_orders.empty==False:
            print ("Orders that dont have G/F from client\nCalculating pending, fills")
            # check for open orders, pending ack, filled orders
            org_orders = org_orders.merge(executions_df, on=['ClientOrdID'], how='left', suffixes=('','_exec'))

            # drop rejected orders
            rejected_orders = org_orders[(org_orders['tag39']=='8')]
            if rejected_orders.empty==False:
                rejected_orders = rejected_orders.groupby(by=['ClientOrdID'], as_index=False, sort=False).last()
                rejected_orders = self.value_calc(rejected_orders.copy(deep=True))
                org_orders = org_orders[~org_orders['ClientOrdID'].isin(rejected_orders['ClientOrdID'])] # drop rejected from processing
                rejected_orders = self.merge_inputmaster(rejected_orders)[innertable_cols]
                rejected_orders['State'] = "Rejected"
                final = rejected_orders


            org_orders = org_orders[(org_orders['tag39']!='8')&(org_orders['MsgType_exec']!='9')]
            org_orders = org_orders.groupby(by=['ClientOrdID'], as_index=False, sort=False).last()

            cumm_df = self.value_calc(org_orders.copy(deep=True))
            cumm_df = self.merge_inputmaster(cumm_df)[innertable_cols]
            #cumm_df = cumm_df[innertable_cols]
            if cumm_df.empty==False: # handle case if there are orders but no exeuction fills before 9:15:00
                cumm_df['State'] = cumm_df[['tag150','tag39']].apply(lambda row: self.getOrderState(row), axis=1)
                final = final.append(cumm_df, ignore_index=True)

        if modify_cancel.empty==False:
            print ("Modify/Replace/Cancel (Tag G/F) order exists for 35=D")

            # check if order has modify/replace and check for our ack/confirmation
            modify = modify_cancel.merge(executions_df, on=['ClientOrdID'], how='left', suffixes=('','_exec'))
            # get missing expiry
            if modify[modify['expiry']=='None'].empty==False:
                modify = modify.merge(self.executions_df[['ParentOrdID','200']].drop_duplicates(subset=['ParentOrdID']), 
                                      on=['ParentOrdID'], how="left", suffixes=('','_mexpiry'))
                modify.loc[modify['expiry']=='None', 'expiry'] = modify['200']           
            
            # get missing data from rejection master
            modify = modify.merge(rejection_master[['ClientOrdID','MsgType']], on=['ClientOrdID'], how='left', suffixes=('','_master'))
            rejected_ids = modify[(modify['MsgType_exec']=='9') | (modify['MsgType_master']=='9')][['ClientOrdID','Og_ClientOrdID']]
            print ("{} lines rejected ...".format(len(rejected_ids)))
            replace_cancel = modify[(modify['MsgType_exec']!='9') | (modify['MsgType_master']!='9')]
            
            for clientorderid in rejected_ids['Og_ClientOrdID'].values: # modify rejected by us
                # bring back original D/G order
                if clientorderid not in replace_cancel['ClientOrdID'].values:
                    temp = orders_df[orders_df['ClientOrdID']==clientorderid].merge(executions_df,
                                                         on=['ClientOrdID'], how='left', suffixes=('','_exec'))
                    replace_cancel = temp.append(replace_cancel, ignore_index=True)

            replace_cancel = replace_cancel[~(replace_cancel['ClientOrdID'].isin(rejected_ids['ClientOrdID'].values.tolist()))&\
                                            ~(replace_cancel['MsgType_master'].astype(str)=='9')]
            replace_cancel = replace_cancel[replace_cancel['MsgType_exec']=='8'].groupby(by=['ClientOrdID'], sort=False,
                                           as_index=False).last()
            replace_cancel.sort_values(by=['LastFillTime'], inplace=True)
            replace_cancel = replace_cancel.groupby(by=['ParentOrdID'], as_index=False, sort=False).last()


            replace_cancel = self.value_calc(replace_cancel.copy(deep=True))

            #replace_cancel = replace_cancel.merge(self.input_table.drop_duplicates(subset=['Session','Tag115']), on=['Session','Tag115'], how="left")
            replace_cancel = self.merge_inputmaster(replace_cancel)[innertable_cols]
            if replace_cancel.empty==False:
                replace_cancel['State'] = replace_cancel[['tag150','tag39']].apply(lambda row: self.getOrderState(row), axis=1)
                final = final.append(replace_cancel, ignore_index=True)

        mleg_final = pd.DataFrame()

        try:
            # check for MLEG orders
            if mleg_orders.empty==False:
                print ("Processing Mleg orders")
                logging.info("Processing Mleg orders")
                modify_cancel = mleg_orders[(mleg_orders['MsgType'].isin(['AC','F']))]

                modify_cancel['LimitPrice'] = modify_cancel['LimitPrice'].fillna('None')
                for col in ['167', 'Tag21','OrdType','LimitPrice','POV %']:
                    temp = mleg_orders[(mleg_orders[col].astype(str)!='None')&(mleg_orders['ClientOrdID'].isin(
                        modify_cancel[modify_cancel[col].astype(str)=='None']['Og_ClientOrdID'].values.tolist()))][['ClientOrdID',col]].rename(
                        columns={'ClientOrdID':'Og_ClientOrdID'})
                    temp.drop_duplicates(inplace=True)
                    modify_cancel =  modify_cancel.merge(temp,on=['Og_ClientOrdID'], how="left", suffixes=("","_y"))
                    modify_cancel.loc[modify_cancel[col].astype(str)=='None', col] = modify_cancel['{}_y'.format(col)]
                    modify_cancel.drop(columns=['{}_y'.format(col)], inplace=True)
                modify_cancel['LimitPrice'] = modify_cancel['LimitPrice'].astype(float)

                # dont update cancel arrival time
                modify_cancel_temp = modify_cancel[modify_cancel['MsgType']=='F']
                if modify_cancel_temp.empty==False:
                    modify_cancel_temp = modify_cancel_temp.merge(mleg_orders[mleg_orders['MsgType']=='AB'][['ClientOrdID','ArrivalTime']].rename(
                                            columns={"ClientOrdID":"Og_ClientOrdID"}), on=['Og_ClientOrdID'], how="left", suffixes=("","_temp"))
                    modify_cancel_temp['ArrivalTime'] = modify_cancel_temp['ArrivalTime_temp']
                    modify_cancel_temp.drop(columns=['ArrivalTime_temp'], inplace=True)
                    modify_cancel = modify_cancel[modify_cancel['MsgType']!='F'].append(modify_cancel_temp, ignore_index=True)


                org_orders = mleg_orders[~(mleg_orders['ClientOrdID'].isin(modify_cancel['ClientOrdID'])) &\
                                        ~(mleg_orders['ClientOrdID'].isin(modify_cancel['Og_ClientOrdID']))]

                if org_orders.empty==False:
                    print ("35=AB with no AC or F orders")
                    org_orders = org_orders.merge(mleg_executions, on=['ClientOrdID'], how='left', suffixes=('','_exec'))
                    # drop rejected orders
                    rejected_orders = org_orders[(org_orders['tag39']=='8')]

                    summary_rejection = mleg_executions_summary[(mleg_executions_summary['tag39']=='8')|
                            (mleg_executions_summary['tag150']=='8')][['ClientOrdID','Og_ClientOrdID','ParentOrdID','tag39',
                            'tag150','AvgPx','LastFillTime']] if mleg_executions_summary.empty==False else pd.DataFrame()

                    if summary_rejection.empty==False:
                        print ("Order rejections present in summary")
                        rejected_summary = summary_rejection.merge(org_orders, on=['ClientOrdID'], how="left", suffixes=("","_summary"))
                        rejected_summary = rejected_summary.groupby(by=['ClientOrdID'], as_index=False, sort=False).last()
                        #rejected_summary = self.value_calc(rejected_summary.copy(deep=True))
                        org_orders = org_orders[~org_orders['ClientOrdID'].isin(rejected_summary['ClientOrdID'])] # drop rejected from processing
                        rejected_summary = self.merge_inputmaster(rejected_summary)[innertable_cols+['tag610_1','tag610_2','tag624_1','tag624_2']]
                        rejected_summary['LastQty1'] = 0; rejected_summary['LastQty2'] = 0; rejected_summary['LastAvgPx'] = 0
                        rejected_summary['State'] = "Rejected"
                        print ("{} orderes rejected ".format(rejected_summary.shape[0]))
                        mleg_final = mleg_final.append(rejected_summary, ignore_index=True)


                    if rejected_orders.empty==False:
                        print ("Order rejections for MLEG present....")
                        rejected_orders = rejected_orders.groupby(by=['ClientOrdID'], as_index=False, sort=False).last()
                        #rejected_orders = self.value_calc(rejected_orders.copy(deep=True))
                        org_orders = org_orders[~org_orders['ClientOrdID'].isin(rejected_orders['ClientOrdID'])] # drop rejected from processing
                        rejected_orders = self.merge_inputmaster(rejected_orders)[innertable_cols+['tag610_1','tag610_2','tag624_1','tag624_2']]
                        rejected_orders['LastQty1'] = 0; rejected_orders['LastQty2'] = 0; rejected_orders['LastAvgPx'] = 0
                        rejected_orders['State'] = "Rejected"
                        mleg_final = mleg_final.append(rejected_orders, ignore_index=True)


                    org_orders = org_orders[(org_orders['tag39']!='8')&(org_orders['MsgType_exec']!='9')]
                    if org_orders.empty==True:
                        print ("No mleg order to procss further...")
                    else:
                        # get MLEG last qty and px
                        last_qty_avgpx = self.get_mleg_last_qty_avpgpx(org_orders.copy(deep=True))
                        org_orders1 = org_orders[org_orders['MsgType_exec'].isnull()] # orders with no executions currently

                        if org_orders1[org_orders1['ParentOrdID'].isnull()].empty==False:
                            # for non executed orders get parent ord id from mleg summary
                            org_orders1 = org_orders1.merge(mleg_executions_summary[['ClientOrdID','ParentOrdID','tag150','tag39']],
                                                        on=['ClientOrdID'], how='left', suffixes=('','_x'))
                            for col in ['ParentOrdID','tag150','tag39']:
                                org_orders1.loc[org_orders1[col].isnull(), col] = org_orders1['{}_x'.format(col)]
                                org_orders1.drop(columns = ['{}_x'.format(col)], inplace=True)

                        org_orders2 = org_orders[~org_orders['MsgType_exec'].isnull()] # orders with exeuctions
                        org_orders = org_orders2.groupby(by=['ClientOrdID'], as_index=False, sort=False).apply(lambda grp: self.get_single_leg(grp))
                        org_orders = pd.concat([org_orders1, org_orders2], ignore_index=True)
                        org_orders['expiry'] = org_orders['expiry_exec']
                        org_orders = org_orders.groupby(by=['ClientOrdID'], as_index=False, sort=False).last()
                        org_orders = org_orders.merge(last_qty_avgpx, on=['ClientOrdID'], how="left")

                        org_orders[['LotSize','OrderQty','tag151','tag14','AvgPx','PreviousClose','LimitPrice']] = (org_orders[['LotSize','OrderQty',
                                  'tag151','tag14','AvgPx','PreviousClose','LimitPrice']].apply(pd.to_numeric, errors='coerce')).fillna(0)

                        #cumm_df = self.value_calc(org_orders.copy(deep=True))
                        cumm_df = org_orders.copy(deep=True)
                        #cumm_df = cumm_df.merge(self.input_table.drop_duplicates(subset=['Session','Tag115']), on=['Session','Tag115'], how="left")
                        cumm_df = self.merge_inputmaster(cumm_df)[innertable_cols+['tag610_1','tag610_2','tag624_1','tag624_2', 'LastQty1','LastQty2','LastAvgPx']]
                        if cumm_df.empty==False:# if executions than append in mleg_final df
                            cumm_df['State'] = cumm_df[['tag150','tag39']].apply(lambda row: self.getOrderState(row), axis=1)
                            mleg_final = mleg_final.append(cumm_df, ignore_index=True)


                if modify_cancel.empty==False:
                    print ("Modify/Replace,Cancel (Tag AC/F) order exists for 35=AB")
                    logging.info("Modify/Replace,Cancel (Tag AC/F) order exists for 35=AB")
                    # check if order has modify/replace and check for our ack/confirmation
                    '''
                    modify = (modify_cancel[modify_cancel['MsgType']!='F'].merge(mleg_executions, on=['ClientOrdID'], how='left',
                                  suffixes=('','_exec'))).append(modify_cancel[modify_cancel['MsgType']=='F'].merge(
                                      mleg_executions_summary, on=['ClientOrdID'], how='left', suffixes=('','_exec')),
                                        ignore_index=True, sort=False)
                    '''
                    # for single leg present merge on mleg executions; else use summary fills
                    sleg_df = modify_cancel[modify_cancel['ClientOrdID'].isin(mleg_executions['ClientOrdID'].values.tolist())]
                    summaryleg_df = modify_cancel[~modify_cancel['ClientOrdID'].isin(mleg_executions['ClientOrdID'].values.tolist())]
                    modify = (sleg_df.merge(mleg_executions, on=['ClientOrdID'], how='left',
                                  suffixes=('','_exec'))).append(summaryleg_df.merge(
                                      mleg_executions_summary, on=['ClientOrdID'], how='left', suffixes=('','_exec')),
                                        ignore_index=True, sort=False)

                    # check from rejection master if any client ord id was rejected
                    modify = modify.merge(rejection_master[['ClientOrdID','MsgType']], on=['ClientOrdID'], how='left', suffixes=('','_master'))

                    rejected_ids = modify[(modify['MsgType_exec']=='9')|(modify['MsgType_master']=='9')][['ClientOrdID','Og_ClientOrdID']]
                    print ("{} lines rejected in multi-leg orders".format(len(rejected_ids)))
                    replace_cancel = modify[(modify['MsgType_exec']!='9')|(modify['MsgType_master']!='9')]

                    for clientorderid in rejected_ids['Og_ClientOrdID'].values: # modify rejected by us
                        # bring back original D/G order
                        if clientorderid not in replace_cancel['ClientOrdID'].values:
                            temp = mleg_orders[mleg_orders['ClientOrdID']==clientorderid].merge(mleg_executions,
                                                                 on=['ClientOrdID'], how='left', suffixes=('','_exec'))
                            replace_cancel = temp.append(replace_cancel, ignore_index=True)
                    # drop rejected replace orders
                    replace_cancel = replace_cancel[~(replace_cancel['ClientOrdID'].isin(rejected_ids['ClientOrdID'].values.tolist()))&\
                                                    ~(replace_cancel['MsgType_master'].astype(str)=='9')]
                    replace_cancel = replace_cancel[replace_cancel['MsgType_exec']=='8'].groupby(by=['ClientOrdID'],
                                                   as_index=False, sort=False).last()
                    replace_cancel.sort_values(by=['LastFillTime'], inplace=True)

                    # get MLEG last qty and px
                    last_qty_avgpx = self.get_mleg_last_qty_avpgpx(replace_cancel.copy(deep=True))

                    #replace_cancel = replace_cancel.groupby(by=['ClientOrdID'], as_index=False).apply(lambda grp: self.get_single_leg(grp))
                    #replace_cancel['expiry'] = replace_cancel['expiry_exec']
                    replace_cancel = replace_cancel.groupby(by=['ParentOrdID'], as_index=False, sort=False).last()
                    replace_cancel = replace_cancel.merge(last_qty_avgpx, on=['ClientOrdID'], how="left")

                    #replace_cancel = self.value_calc(replace_cancel.copy(deep=True))

                    #replace_cancel = replace_cancel.merge(self.input_table.drop_duplicates(subset=['Session','Tag115']), on=['Session','Tag115'], how="left")
                    replace_cancel = self.merge_inputmaster(replace_cancel)[innertable_cols +['tag610_1','tag610_2','tag624_1','tag624_2','LastQty1','LastQty2','LastAvgPx']]
                    if replace_cancel.empty==False:
                        replace_cancel['State'] = replace_cancel[['tag150','tag39']].apply(lambda row: self.getOrderState(row), axis=1)
                        mleg_final = mleg_final.append(replace_cancel, ignore_index=True)

        except Exception as e:
            print ("Error in multi leg calculations...")
            print (e)
            logging.info("Error in multi leg calculations...\nError {}".format(e))



        final = final.append(mleg_final, ignore_index=True, sort=False)
        for col in ['LastQty1','LastQty2','LastAvgPx','tag610_1','tag610_2','tag624_1','tag624_2']:
            if col not in final.columns:
                final[col] = 0

        # prepare final order file
        self.final_processing(final)


    def ric_gen(self, ric, expiry):
        try:
            return ric.split(":NS")[0]+monthly_codes_fut[expiry.strftime("%b")]+expiry.strftime("%Y")[-1]+":NS"

        except Exception as e:
            print (e)
            return ric

    def final_processing(self, final):
        
        exch_accountids = self.prefix_session(self.exch_accountids.copy(deep=True))
        if self.mleg_executions_summary.empty==False:
            mleg_executions_summary = self.prefix_session(self.mleg_executions_summary.copy(deep=True))
        
        if final.empty==False:
            final[['LastQty1','LastQty2','LastAvgPx']] = final[['LastQty1','LastQty2','LastAvgPx']].fillna(0)
            final.rename(columns={'ClientName':'Account','167':'Instrument','tag14':'ExecutedQty','tag151':'PendingQty'}, inplace=True)
            final = final[['ParentOrdID','ClientOrdID','Og_ClientOrdID','Tag115','Account','Algorithm','Side','Symbol','RICNse',
                           'Instrument','expiry','tag610_1','tag610_2','tag624_1','tag624_2','OptionType','OrderQty','OrdType',
                           'LimitPrice','ExecutedQty','AvgPx','PendingQty','LastQty1','LastQty2','LastAvgPx','ArrivalTime','StartTime','EndTime','LastFillTime','tag150','tag39',
                           'State','Tag50','POV %','Cumm value','Tag21','Tag49']]
            
            '''
            temp = final[~final['State'].isin(['Rejected','Cancelled','Completed','DoneForTheDay'])]
            temp.sort_values(by=['State'], inplace=True)
            #temp = temp.append(final[final['State'].isin(['Rejected','Completed','DoneForTheDay'])], ignore_index=True)
            final = temp.copy(deep=True)
            '''
            
            temp = final[~final['State'].isin(['Completed','DoneForTheDay','Cancelled','null'])]
            temp.sort_values(by=['State'], inplace=True)
            temp = temp.append(final[final['State'].isin(['Completed','DoneForTheDay','Cancelled','null'])], ignore_index=True)
            final = temp.copy(deep=True)


            final.loc[(final['StartTime'].astype(str)=="None")|(final['StartTime'].astype(str)=="NaT"), "StartTime"] = final['ArrivalTime']
            final['StartTime'] = final['StartTime'].apply(lambda row: datetime.datetime.strftime(row, "%H:%M:%S"))
            final['StartTime'] = final['StartTime'].apply(lambda row: str(datetime.time(9,15)) \
                 if datetime.datetime.strptime(row, "%H:%M:%S").time() <datetime.time(9,15) else row)
            final.loc[(final['EndTime'].astype(str)=="None")|(final['EndTime'].astype(str)=="NaT"), "EndTime"] = datetime.datetime.now().replace(hour=15,minute=30,second=0)
            final['EndTime'] = final['EndTime'].apply(lambda row: datetime.datetime.strftime(row, "%H:%M:%S"))
            #final.dropna(subset=['ParentOrdID'], inplace=True)
            final['POV %'] = final['POV %'].str.lower().str.replace("n.","", regex=True).replace(np.nan, "")


            final.loc[(final['Instrument'].str.startswith("F")), "Instrument"] = "FUT"
            final.loc[(final['Instrument'].str.startswith("M")), "Instrument"] = "MLEG"

            final['Cumm value'] = final['Cumm value'].apply(lambda row: 0 if str(row)=='nan' else row/10**7)
            final['Cumm value $mn'] = final['Cumm value'].apply(lambda row: (row*10)/self.dollar_value if row!=0 else 0)
            final.rename(columns={'Cumm value':'Cumm value Cr'}, inplace=True)
            # merge avgpx for MLEG orders from summary fills
            if final[final['Instrument']=='MLEG'].empty==False:
                final = final.merge(mleg_executions_summary[['ParentOrdID','AvgPx']].drop_duplicates(
                        subset=['ParentOrdID']), on=['ParentOrdID'], how="left", suffixes=("","_mleg"))
                final.loc[final['Instrument']=='MLEG', 'AvgPx'] = final['AvgPx_mleg']
                final.drop(columns=['AvgPx_mleg'], inplace=True)

            final.dropna(inplace=True, subset=['ParentOrdID'])
            # handle parent ord id for EDMA orders
            # replace EDMA parent ord ids
            final['Clid_temp'] = final['ClientOrdID'].apply(lambda row: re.sub("I_", "", str(row), count=1) ) # remove I_
            final['ParentOrdID_edma'] = final['Clid_temp'].apply(lambda row: self.exch_accountids[self.exch_accountids['ClientOrdID'].str.endswith(row)]).apply(
                                            lambda row_df: row_df['ParentOrdID'].values[0] if row_df.empty==False else np.nan)
            
            #final = final.merge(exch_accountids[['ClientOrdID','ParentOrdID']],
            #                  on=['ClientOrdID'], how="left", suffixes=("","_edma"))
            
            #final.loc[(final['ParentOrdID'].str.lower().str.startswith("edma"))&\
            #         (~final['ParentOrdID_edma'].isnull()), "ParentOrdID"] = final['ParentOrdID_edma']
            #final.drop(columns=['ParentOrdID_edma'], inplace=True)

            # merge exchange account ids
            #final = final.merge(exch_accountids[['ParentOrdID','tag1']].drop_duplicates(subset=['ParentOrdID']),
            #                    on=['ParentOrdID'], how="left")
            final = final.merge(exch_accountids[['ParentOrdID','tag1']].drop_duplicates(subset=['ParentOrdID']).rename(
                    columns={'ParentOrdID':'ParentOrdID_edma'}), on=['ParentOrdID_edma'], how="left")
            
            final[['tag610_1','tag610_2']] = final[['tag610_1','tag610_2']].fillna("")
            #self.debug_dump_data(final, os.path.join(output_dir1, "FIXOrderMonitoring.txt"))
            '''
            # get RIC with expiry months
            final['tempexpiry'] = final['expiry'].astype(str)
            final = final.merge(self.instrument[['Symbol','RICNse','expiry']].rename(columns={
                            'expiry':'tempexpiry'}), on=['Symbol','tempexpiry'], how="left")
            
            final['tempexpiry'] = final['tempexpiry'].apply(lambda row: row if ((str(row)=='None') or (str(row)=='nan') or \
                                         (str(row)=='NaN')) else datetime.datetime.strptime(str(row), "%Y%m"))
            
            #final['RIC'] = final.apply(lambda row: row['RICNse'].split(":NS")[0]\
            #                      +monthly_codes_fut[row['tempexpiry'].strftime("%b")]+row['tempexpiry'].strftime("%Y")[-1]+":NS" if "-" not in row['RICNse'] else row['RICNse'], axis=1)
            final.loc[final['RIC'].isnull(), 'RIC'] = final['RICNse'].str.replace(":NS", "")
            final.loc[final['Tag115']!='PINPOINT', 'RIC'] = final.apply(lambda row: self.ric_gen(row['RIC'], row['tempexpiry']) if "-" not in row['RIC'] else row['RIC'], axis=1)
            '''
            final.rename(columns={'RICNse':'RIC'}, inplace=True)
            final.loc[final['ParentOrdID_edma'].isnull(), "ParentOrdID_edma"] = final['ParentOrdID'] # impute missing parentor_edma
            final = final.merge(self.daily_adv, on=['Symbol', 'expiry'], how='left')

            # get tag115 for None a.k.a citadel
            final['Session'] = final['ClientOrdID'].apply(lambda row: "_".join(row.split("_")[:2]) if str(row)!='None' else row)
            final.loc[(final['Session'].isin(self.input_table[self.input_table['Agg Client Name']=='CITADEL']['Session'].values.tolist())) & (final['Tag115']=='None'), 'Tag115'] = 'CITADEL'
                        
            final = final[final_cols]
            self.debug_dump_data(final, os.path.join(config_props_dict["output_dir"].strip(), "fix_orders.txt"))
            
        else:
            #self.debug_dump_data(pd.DataFrame(columns=final_cols), os.path.join(output_dir1, "FIXOrderMonitoring.txt"))
            self.debug_dump_data(pd.DataFrame(columns=final_cols), os.path.join(config_props_dict["output_dir"].strip(), "fix_orders.txt"))
        
        
    def format_table(self, table):

        table.iloc[:, table.columns.str.endswith("Orders")]=table.iloc[:,
                        table.columns.str.endswith("Orders")].applymap(lambda row: str(int(row)))
        table = table.applymap(str)
        table = table.T

        return table



def process(ulfix_orders_obj, flag):

    s=time.time()
    # process
    ulfix_orders_obj.read_records()
    print ("File offset {}".format(ulfix_orders_obj.tail_filereader.offset))
    print ("Read time {}".format(time.time() -s))
    ulfix_orders_obj.compute_orders()
    #ulfix_orders_obj.email_alert(result.copy(deep=True), flag)
    print ("total processing time {}".format(time.time() -s))
    logging.info("total processing time {}".format(time.time() -s))


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

"""
def email_utility(emails, subject, message):

    '''Func to send mount error alert'''

    # get total recipients
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)

    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)

    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject

    msg.attach(MIMEText('{}'.format(message),'plain'))

    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()
"""
'''
def detect_mount_and_email():

    failed_mounts = []
    for dir_name in [output_dir1,"/FIXReport/",mleg_drive]:
        if os.path.ismount(dir_name) == False:
            print "Mount doesnt exist {} ".format(dir_name)
            failed_mounts.append(dir_name)

    if len(failed_mounts)>0:
        print "Mount error"
        email_utility(get_contacts(contacts_dir+"mount_alert_emails.txt"), 
                      '({}) Mount error Alert for MLP Excel orders sheet!'.format(socket.gethostbyname(socket.gethostname())), 
                      "Please check following mount dir \n\n{}".format('\n '.join(failed_mounts)) ) 

        logging.info("Mount error alert sent ")
        return -1
    else:
        return 1

def check_mount():
    # check if all mount dir exist
    while True:
        if detect_mount_and_email()==-1:
            print "Mounting Error"
            logging.info("Mounting Error")
            time.sleep(240)
        else:
            print "Mount in place"
            logging.info("Mount in place")
            break
'''

def dateparse_d(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date

# read holiday master
holiday_master = pd.read_csv(os.path.join(config_props_dict['holiday_dir'].strip(), 'Holidays_2019.txt'),
                             delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):

    '''Func to check if the process should run on current day or not'''
    if len(holiday_master[holiday_master['date']==d])==0:
        print ("Start process for working day")
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        print ('Holiday: skip for current date :{} '.format(d))
        return -1



def main(nd):

    #check_mount()
    d = datetime.datetime.now()-datetime.timedelta(nd)
    
    if process_run_check(d.date()) == -1:
        update_db.update_lastruntime("FixOrders")
        return -1

    print("Start...")
    
    if datetime.datetime.now().time()<=datetime.time(8,5):
        # reset file
        pd.DataFrame(columns=['ParentOrdID', 'ClientOrdID', 'Og_ClientOrdID', 'Tag115', 'Account', 'Algorithm', 'Side', 'Symbol', 'RIC', 'Instrument',
              'expiry', 'tag610_1', 'tag610_2', 'tag624_1','tag624_2','OptionType', 'OrderQty', 'OrdType', 'LimitPrice', 'ExecutedQty', 'AvgPx', 'PendingQty',
              'LastQty1', 'LastQty2', 'LastAvgPx', 'ArrivalTime', 'StartTime', 'EndTime', 'LastFillTime', 'tag150', 'tag39', 'State',
               'Tag50', 'POV %', 'Cumm value Cr','Cumm value $mn', 'Tag21','tag1','Tag49','ParentOrdID_edma','adv']).to_csv(os.path.join(config_props_dict["output_dir"].strip(), "fix_orders.txt"), index=False)
        
    ulfix_orders_obj = ULFIXOrders("{}.txt".format(datetime.datetime.strftime(d,"%Y%m%d")))
    last_input_table = ulfix_orders_obj.input_table
    exception_flag = 0
    reload_time = time.time()
    while True:
        try:
            if (exception_flag == 1) or (time.time() - reload_time)>=5*60:
                print ("Reloading, ul fix parser object......")
                ulfix_orders_obj = ULFIXOrders("{}.txt".format(datetime.datetime.strftime(d,"%Y%m%d")))
                last_input_table = ulfix_orders_obj.input_table
                exception_flag = 0
                reload_time = time.time()
                
            if last_input_table.equals(ulfix_orders_obj.input_table) :
                process(ulfix_orders_obj,"None")
                #print ("Sleep for 1 seconds...")
                #time.sleep(1)
                if datetime.datetime.now().time()>=datetime.time(18,0):
                    print ("Proccess done for the day !")
                    process(ulfix_orders_obj, "End")
                    break
            else:
                print ("Reloading, as input master file is new......")
                ulfix_orders_obj = ULFIXOrders("{}.txt".format(datetime.datetime.strftime(d,"%Y%m%d")))
                last_input_table = ulfix_orders_obj.input_table
                process(ulfix_orders_obj,"None")
        except Exception as e:
            print (e)
            logging.error("Error {}\nReloading ....".format(e))
            exception_flag =1
        

import psycopg2
import datetime
from project_status_update import project_status_rt as udt
update_db= udt.postgres_updations()
update_db.update_status("FixOrders")

if __name__=="__main__":
    main(0)
    update_db.update_lastruntime("FixOrders")
