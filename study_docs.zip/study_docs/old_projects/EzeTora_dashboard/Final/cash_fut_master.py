# -*- coding: utf-8 -*-
"""
Created on Mon Oct 13 19:25:07 2020

@author: krishna
"""
from __future__ import print_function
import numpy as np
import pandas as pd
import datetime
import os
import xlrd
import zipfile
from cassandra.cluster import Cluster
import sys
import time
import logging
import warnings
import smtplib
#from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import socket
import shutil
from project_status_update import project_status_rt as udt
update_db= udt.postgres_updations()
 
warnings.filterwarnings("ignore")

# set paths here
if sys.platform not in ('win32', 'cygwin', 'cli'):
    os.chdir("/home/hadoop/GenInstrument/")
    print("Linux environment depdendet paths set")
    log_path='/home/hadoop/GenInstrument/'
    output_dir = '/KITSBOARD/'
    dividend_dir = ""
    master_dir = "/home/hadoop/master/"
    msci_path = master_dir
    contacts_dir = "/home/hadoop/GenInstrument/"
    lots_file_dir = "/REPORTING/" #r"\\172.17.9.22\Users2\backoffice\Derv\189 REPORTING\PR FILE_INDEX IISL"
    lots_archive_dir = "/REPORTING/PR FILE_INDEX IISL/old files/" #r"\\172.17.9.22\Users2\backoffice\Derv\189 REPORTING\PR FILE_INDEX IISL\old files"
    instrument_dir = "/Output/"
    scripmaster_dir = "/home/hadoop/GenInstrument/dataFiles/"
else:
    print("Windows environment path set")
    log_path = "D:\\redis_pubsub\\"
    output_dir = "D:\\redis_pubsub\\confluent\\cash_fut_arb\\output\\"
    dividend_dir = "D:\\redis_pubsub\\confluent\\cash_fut_arb\\"
    master_dir = "D:\\Master\\"
    msci_path = "D:\\redis_pubsub\\confluent\\cash_fut_arb\\output\\"
    contacts_dir = ""
    lots_file_dir = r"\\172.17.9.22\Users2\backoffice\Derv\189 REPORTING\PR FILE_INDEX IISL"
    lots_archive_dir = r"\\172.17.9.22\Users2\backoffice\Derv\189 REPORTING\PR FILE_INDEX IISL\old files"
    instrument_dir = master_dir
    scripmaster_dir = master_dir
    
    
server = '172.17.9.149'; port = 25  # mailing server
MY_ADDRESS = 'KITS.reports@kotak.com'
pp_symbols = ['AIRTELPP']

# define logging for the file system at debug or higher level
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    datefmt='%m-%d %H:%M',
                    filename=log_path+'test.log')
#logging.basicConfig(level=logging.DEBUG, format='%(relativeCreated)6d %(threadName)s %(message)s')
# define a Handler which writes INFO messages or higher to the sys.stderr
console = logging.StreamHandler()
console.setLevel(logging.INFO)
# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)
logging.info("Start process")

header=False
# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails


def email_utility(emails, subject, message):

    '''Func to send mount error alert'''

    # get total recipients
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)

    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)

    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject

    msg.attach(MIMEText('{}'.format(message),'plain'))

    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def detect_mount_and_email(mount_dir_list):

    failed_mounts = []
    for dir_name in mount_dir_list:
        if os.path.ismount(dir_name) == False:
            print ("Mount doesnt exist {} ".format(dir_name))
            failed_mounts.append(dir_name)

    if len(failed_mounts)>0:
        print ("Mount error")
        email_utility(get_contacts(contacts_dir+"contacts.txt"),
                      '({}) Mount error Alert!'.format(socket.gethostbyname(socket.gethostname())),
                      "Please check following mount dir \n\n{}".format('\n '.join(failed_mounts)) )

        logging.info("Mount error alert sent ")
        return -1
    else:
        return 1


def check_mount(lots_file_dir):
    # check if all mount dir exist
    while True:
        if detect_mount_and_email(lots_file_dir)==-1:
            print ("Mounting Error")
            logging.info("Mounting Error")
            time.sleep(240)
        else:
            print ("Mount in place")
            logging.info("Mount in place")
            break


def corp_actions_factor(bhav_copy):    
    '''Func to perfrom CA factor adjustments ; takes input datecolumn name and '''
    
    # perform CA actions for Stocks with name change
    ca = pd.read_csv(master_dir+"Corporate_actions.csv")
    if ca.empty==True:
        print("No corp actions; proceed as is")
        return bhav_copy
        
    ca['Date'] = ca['Date'].apply(lambda d: pd.to_datetime(d).date())
    ca = ca[ca['Date']>=bhav_copy['Date'][0]]
    
    if ca.empty==True:
        print("No corp actions; proceed as is")
        return bhav_copy
        
    for _, row in ca.iterrows():
        if str(row['Old_symbol'])!='nan':
            print ("Name changed from {} for {}".format(row['Old_symbol'], row['New_symbol']))
            bhav_copy.loc[bhav_copy['Symbol']==row['Old_symbol'], 'Symbol'] = row['New_symbol']
        elif str(row['Factor'])!='nan':
            print ("Ca factor {} for {}".format(row['Factor'], row['Symbol']))
            bhav_copy.loc[bhav_copy['Symbol']==row['Symbol'], 'CLOSE_PRICE'] = bhav_copy['CLOSE_PRICE']/row['Factor']
            bhav_copy.loc[bhav_copy['Symbol']==row['Symbol'], 'ISSUE_CAP'] = bhav_copy['ISSUE_CAP']*row['Factor']
            
    return bhav_copy



def index_close(indexname, date):
    
    cluster = cassandra_configs_cluster()
    session = cluster.connect('rohit')
    #logging.info('Using test_df keyspace')
    session.row_factory = pandas_factory
    session.default_fetch_size = None
    
    query=session.execute("SELECT indexname, indexdate, closingindexvalue from index_bhavcopy \
                          where indexname='{}' and indexdate<='{}' and indexdate>='{}' \
                          allow filtering;".format(indexname, date, date-datetime.timedelta(days=10)))
    result=query._current_rows
    result['indexdate'] = result['indexdate'].apply(lambda row: row.date())
    result.sort_values(by='indexdate', inplace=True)
    close = round(result.tail(1)['closingindexvalue'].values[0], 2)
    print("previous index closing value {}".format(close))
    return close 



def get_index_constituents_file(d, fileprefix):
    
    # read open position file from network drive and read bod file
    date=d
    lots = pd.DataFrame()
    for i in range(7):
        filepath = os.path.join(lots_file_dir,'PR FILE_INDEX IISL', "{}_{}{}{}.zip".format(
                        fileprefix, d.year,"%02d"%d.month, "%02d"%d.day))
        if os.path.exists(filepath):
            
            zf = zipfile.ZipFile(filepath)
            
            lots = pd.read_csv(zf.open(''.join([ f for f in zf.namelist() if f.startswith('bod') and f.endswith('.csv') ]) ))
            print ("Using file {} for reading index consti".format(d))
            break
        else:
            print("not found : {} ".format(filepath))
            d = d - datetime.timedelta(days=1)
        
    d=date
    # if not find inside old files 
    if lots.empty==True:
        print ('Looking backdated files')
        for i in range(200):
            print (d)
            if os.path.exists(os.path.join(lots_archive_dir, "{}_{}{}{}.zip".format(
                                fileprefix, d.year,"%02d"%d.month, "%02d"%d.day))):
                
                zf = zipfile.ZipFile(os.path.join(lots_archive_dir,"{}_{}{}{}.zip".format(
                                        fileprefix, d.year,"%02d"%d.month, "%02d"%d.day)))
                
                lots = pd.read_csv(zf.open(''.join([ f for f in zf.namelist() if f.startswith('bod') and f.endswith('.csv') ]) ))
                print ("Using file {} for reading index consti".format(d))
                break
            else:
                d=d-datetime.timedelta(days=1)           
            
    lots = lots[['SYMBOL','DATE','CLOSE_PRICE','ISSUE_CAP','INVESTIBLE_FACTOR','CAP_FACTOR','WEIGHTAGE']].rename(
                    columns={'SYMBOL':'Symbol','DATE':'Date'})    
    lots['Date'] = lots['Date'].apply(lambda x: pd.to_datetime(x, format='%d-%m-%Y').date())
    lots = corp_actions_factor(lots)
    lots['WEIGHTAGE'] = lots['WEIGHTAGE'].apply(lambda x : round(x/100,4))
    lots['market_cap'] = lots['CLOSE_PRICE']*lots['ISSUE_CAP']*lots['INVESTIBLE_FACTOR']*lots['CAP_FACTOR']
   
    return lots

'''
def read_dividend_input(process_d):  
    
    try:
        # read daily dividend file
        dividend=pd.DataFrame()
        try:
            dividend = pd.read_excel(r"\\172.17.9.21\Agent\Ojas Shah\Dividend\Dividend List.xlsx", sheet_name='Div.Scrwise', skiprows=1)
        except Exception as e:
            print ("Sheet name 'Div.Scrwise' not present/ Error {} \n\nReading default 2nd sheet".format(e))
            logging.info("Sheet name 'Div.Scrwise' not present/ Error {} \n\nReading default 2nd sheet".format(e))
            dividend = pd.read_excel(r"\\172.17.9.21\Agent\Ojas Shah\Dividend\Dividend List.xlsx", sheet_name=1, skiprows=1)
        
        dividend = dividend.iloc[:,2:-3]
        dividend['EX-DIV DATE'] = pd.to_datetime(dividend['EX-DIV DATE'], errors='coerce')
        dividend.dropna(subset=['EX-DIV DATE'], inplace=True)
        dividend.iloc[:, :2] = dividend.iloc[:, :2].apply(lambda col: col.str.strip() if col.dtype=='object' else col) 
        dividend['EX-DIV DATE'] = dividend['EX-DIV DATE'].dt.date
        dividend = dividend[(dividend['EX-DIV DATE'] > process_d) & (dividend['MONTH'].str.startswith(process_d.strftime("%b").upper()))]
        dividend = dividend.iloc[:, [0,4]]
        dividend.columns= ['Symbol','Dividend']
        dividend['Dividend'] = pd.to_numeric(dividend['Dividend'], errors='coerce' )
        dividend.dropna(subset=['Dividend'], inplace=True)

        
        logging.info("Dividend file successfully read; number of symbols present {}".format(len(set(dividend['Symbol']))))
        return dividend[['Symbol','Dividend']]
    
    except Exception as e:
        print ("Error reading dividend file")
        logging.info("Error reading dividend file; Error {}".format(e))
        return pd.DataFrame(columns=['Symbol','Dividend'])
   
'''

""" 
def process_ETF_master(etf_name_dict):
    '''Process ETF creation units'''

    try:
        xls = xlrd.open_workbook("D:\\redis_pubsub\\confluent\\cash_fut_arb\\CreationFiles.xls", on_demand=True)
        sheets_dictlist = [ {[sheet for sheet in xls.sheet_names() if etf in str.lower(sheet)][0]:etf} \
                                     for etf in etf_name_dict.keys()] 
    except Exception as e:
        logging.error("Error in reading creation units excel file, Error message : {} ".format(e))
        
    etf_components = pd.DataFrame()
    
    for etf in sheets_dictlist:
        print ("Reading creation units for {}".format(list(etf.values())[0]))
        temp = pd.read_excel("D:\\redis_pubsub\\confluent\\cash_fut_arb\\CreationFiles.xls",  # thse are creation files of various ETF
                             sheet_name=list(etf.keys())[0])
        temp = temp.iloc[1:,:]
        etf_df = temp[['Symbol','Quantity']].dropna()
        etf_df['Quantity'] = etf_df['Quantity'].astype(int)
        etf_df['Weight'] = etf_df['Quantity']/sum(etf_df['Quantity'])
        etf_df['Weight'] = etf_df['Weight'].round(4)
        etf_df['ETF'] = etf_name_dict[list(etf.values())[0]]
        logging.info("Total {} no of symbols were found in {}".format(len(etf_df), list(etf.values())[0]))
        
        cash_component = temp.loc[temp['Symbol'].str.startswith("CASH COMPONENT", na=False)]['Value'].values[0]
        basket_units = temp.loc[temp['Symbol'].str.startswith("BASKET UNITS", na=False)]['Value'].values[0]
        etf_df['cash_component'] = cash_component
        etf_df['basket_units'] = basket_units
    
        etf_components = etf_components.append(etf_df, ignore_index=True)
        
    # output 
    etf_components = etf_components[['Symbol','Quantity','Weight','ETF','cash_component','basket_units']]
    etf_components.to_csv(output_dir+"etf_components.csv",index=False, header=header)
    logging.info("ETF components file generated")
""" 


# upload master file for pairmaster
def master_table(d, indices_list, etf_name_dict):
    '''Reads a csv file and creates ksql topic for the same''' 
    
    # get lot size from instrument file
    instru = pd.read_csv(os.path.join(instrument_dir, "instrument.csv"))
    pp_shares = instru[instru['Symbol'].isin(pp_symbols)]
    pp_shares['NseSecurityCode'] = pp_shares['NseSecurityCode'].apply(lambda x: str(int(x)) if str(x)!='nan' else str(x))
    
#    instru.columns = ['SecurityCode','UnderLyingSecurityCode','TradingSymbol','ScripType','ExchangeSegment','Symbol',
#                      'Series','InstrumentType','ExpiryDate','StrikePrice','OptionType','LotSize','VolumeFreezeQty',
#                      'TickSize','LowerCircuitPrice','UpperCircuitPrice','OrderPlaced_','NseSecurityCode',
#                      'BseSecurityCode','CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode','FarMonthFutureSecurityCode',
#                      'CurrentMonthNextMonthSpreadSecurityCode','NextMonthFarMonthSpreadSecurityCode','CurrentMonthFarMonthSpreadSecurityCode',
#                      'IsCurrentMonthContract','IsNextMonthContract','IsFarMonthContract','IsCurrentMonthNextMonthSpreadContract',
#                      'IsNextMonthFarMonthSpreadContract','IsCurrentMonthFarMonthSpreadContract','ISIN','PreviousClose']    
#    
    #etf_df = instru[instru['Symbol'].isin(etf_name_dict.values())]    
    instru = instru.dropna(subset=['CurrentMonthFutureSecurityCode'])
    #instru = instru.append(etf_df, ignore_index=True)
    
    nifty_bn = instru[instru['Symbol'].isin(indices_list)][['Symbol','UnderLyingSecurityCode']].drop_duplicates().head(3)
    
    master = instru[['Symbol','NseSecurityCode','BseSecurityCode','CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode',
                     'FarMonthFutureSecurityCode','CurrentMonthNextMonthSpreadSecurityCode','NextMonthFarMonthSpreadSecurityCode',
                     'CurrentMonthFarMonthSpreadSecurityCode']]
    master.drop_duplicates(inplace=True)
    #etf_df = master[master['Symbol'].isin(etf_name_dict.values())]
    #master.dropna(subset=['CurrentMonthFarMonthSpreadSecurityCode'], inplace=True)
    #master = master.append(etf_df, ignore_index=True)
    
    master[['NseSecurityCode','BseSecurityCode','CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode',
        'FarMonthFutureSecurityCode']] = master[['NseSecurityCode','BseSecurityCode','CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode',
                                         'FarMonthFutureSecurityCode']].applymap(lambda x: str(int(x)) if str(x)!='nan' else str(x))
    
    instru = instru[['SecurityCode','LotSize']]
    instru['SecurityCode'] = instru['SecurityCode'].astype(str)
    instru['SecurityCode'] = instru['SecurityCode'].str.strip()
    instru.drop_duplicates(inplace=True)
    #instru.dropna(subset=['SecurityCode'], inplace=True)
    # explode lots size for all security codes
    for l in [['NseSecurityCode','LotSize_nse'], ['BseSecurityCode','LotSize_bse'], 
              ['CurrentMonthFutureSecurityCode','LotSize_m1'], ['NextMonthFutureSecurityCode','LotSize_m2'], ['FarMonthFutureSecurityCode','LotSize_m3'],
              ['CurrentMonthNextMonthSpreadSecurityCode','LotSize_m12'], ['NextMonthFarMonthSpreadSecurityCode','LotSize_m23'], ['CurrentMonthFarMonthSpreadSecurityCode','LotSize_m13']]:
        
        master = master.merge(instru.rename(columns={'SecurityCode':l[0],'LotSize':l[1]}), on=l[0], how='left' )
    
    # nifty bn cash codes
    for index in indices_list:
        try:
            master.loc[master['Symbol']==index, 'NseSecurityCode'] = nifty_bn[nifty_bn['Symbol']==index]['UnderLyingSecurityCode'].values[0]
            master.loc[master['Symbol']==index, 'BseSecurityCode'] = nifty_bn[nifty_bn['Symbol']==index]['UnderLyingSecurityCode'].values[0]
        except Exception as e:
            print(e)      
    master.fillna(0, inplace=True)
    lotsize_colnames = [ col for col in master.columns if col.startswith("LotSize")]
    master[lotsize_colnames] = master[lotsize_colnames].astype(int)


    # Get constituents and free float market cap
    constituents = pd.DataFrame()
    for fileprefix, index in {'NIFTY_50':'NIFTY','NIFTY_BANK':'BANKNIFTY'}.items():
        temp = get_index_constituents_file(d, fileprefix)
        temp['index'] = index
        temp['Free_float_market_cap'] = temp['market_cap'].sum()
        temp['index_close'] = index_close(index,temp['Date'][0])
        
        constituents = constituents.append(temp, ignore_index=True)
    
    # output
    master = master[['Symbol','NseSecurityCode','BseSecurityCode','CurrentMonthFutureSecurityCode',
                     'NextMonthFutureSecurityCode','FarMonthFutureSecurityCode','CurrentMonthNextMonthSpreadSecurityCode',
                     'NextMonthFarMonthSpreadSecurityCode','CurrentMonthFarMonthSpreadSecurityCode','LotSize_m1',
                     'LotSize_m2','LotSize_m3']]
    #dividend = read_dividend_input(d)
    #master = master.merge(dividend, on='Symbol', how='left')
    #master['Dividend'] = master['Dividend'].fillna(0.0)
    #master['Dividend'] = 0
    #master.fillna(0, inplace=True)
    # get futures berg code
    scripmaster = pd.read_csv(scripmaster_dir+"scripmaster.csv", 
                                  names = ['Symbol','BseSymbol','UnnamedField3','Company Name','UnnamedField5','UnnamedField6',
                                           'ISIN','RICNse','Sedol','RICBse','UnnamedField11','BseTicker','NseTicker','UnnamedField14','NfoTicker'] )
    scripmaster = scripmaster[['Symbol','NseTicker']]
    scripmaster.dropna(inplace=True)
    scripmaster['Symbol'] = scripmaster['Symbol'].str.strip()
    scripmaster['NseTicker'] = scripmaster['NseTicker'].str.strip()
    scripmaster = scripmaster[(scripmaster['NseTicker']!='')]
    scripmaster['NseTicker'] = scripmaster['NseTicker'].apply(lambda x: x[1:])
    
    master = master.merge(scripmaster, on=['Symbol'])    
    master.loc[master['CurrentMonthFarMonthSpreadSecurityCode']==0, 'CurrentMonthFarMonthSpreadSecurityCode'] = master['CurrentMonthFutureSecurityCode'] + " " + master['FarMonthFutureSecurityCode']
    master = master[['Symbol','NseSecurityCode','BseSecurityCode','CurrentMonthFutureSecurityCode',
                     'NextMonthFutureSecurityCode','FarMonthFutureSecurityCode','CurrentMonthNextMonthSpreadSecurityCode',
                     'NextMonthFarMonthSpreadSecurityCode','CurrentMonthFarMonthSpreadSecurityCode','NseTicker','LotSize_m1',
                     'LotSize_m2','LotSize_m3']]
    pp_shares = pp_shares[['Symbol','NseSecurityCode','BseSecurityCode','CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode','FarMonthFutureSecurityCode',
            'CurrentMonthNextMonthSpreadSecurityCode','NextMonthFarMonthSpreadSecurityCode','CurrentMonthFarMonthSpreadSecurityCode']].merge(scripmaster, on=['Symbol'])
    
    temp = master.append(pp_shares, ignore_index=True)[['Symbol','NseSecurityCode','BseSecurityCode','CurrentMonthFutureSecurityCode',
                     'NextMonthFutureSecurityCode','FarMonthFutureSecurityCode','CurrentMonthNextMonthSpreadSecurityCode',
                     'NextMonthFarMonthSpreadSecurityCode','CurrentMonthFarMonthSpreadSecurityCode','NseTicker','LotSize_m1',
                     'LotSize_m2','LotSize_m3']]
    temp[['LotSize_m1','LotSize_m2','LotSize_m3']] = temp[['LotSize_m1','LotSize_m2','LotSize_m3']].fillna(1).applymap(int)
    temp.to_csv(output_dir+"masterArb.csv", index=False, header=header)
    
    master = master[['Symbol','NseSecurityCode','BseSecurityCode','CurrentMonthFutureSecurityCode',
                     'NextMonthFutureSecurityCode','FarMonthFutureSecurityCode','CurrentMonthNextMonthSpreadSecurityCode',
                     'NextMonthFarMonthSpreadSecurityCode','CurrentMonthFarMonthSpreadSecurityCode','NseTicker']]
    
    # msci
    msci = pd.read_csv(os.path.join(msci_path, "msci_constituents.csv"), header=None, names=['BBG','Symbol','weightage','index'])
    master_msci = master[master['Symbol'].isin(msci['Symbol'].astype(str).values.tolist())]
    master_msci.to_csv(output_dir+"masterMSCI.csv", index=False, header=header)
    
    # index constituents for NIFTY, BANKNIFTY   
    constituents = constituents[['Symbol','Date','CLOSE_PRICE','ISSUE_CAP','INVESTIBLE_FACTOR','CAP_FACTOR',
                                 'WEIGHTAGE','market_cap','index','Free_float_market_cap','index_close']]
    constituents['Symbol_multiplier'] = constituents['ISSUE_CAP']*constituents['INVESTIBLE_FACTOR']*constituents['CAP_FACTOR']
    constituents = constituents.append(pd.DataFrame([['NIFTY',constituents['Date'].values[0],1,1,1,1,1,1,'0',1,1,1],
                                                     ['BANKNIFTY',constituents['Date'].values[0],1,1,1,1,1,1,'0',1,1,1]], 
                                        columns=constituents.columns.tolist()), ignore_index=True)
    constituents.to_csv(output_dir+"index_constituents.csv", index=False, header=header)
        
    master = master[master['Symbol'].isin(constituents['Symbol'].astype(str).values.tolist())]
    master.to_csv(output_dir+"masterIndex.csv", index=False, header=header)
        

def main():
    
    while 1:
        try:                
            d = datetime.datetime.now().date()
            logging.info("Processing for date {}".format(d))
            check_mount([lots_file_dir])
            
            # etf names to track for indicators
            etf_name_dict = {'etf nifty bees':'NIFTYBEES','etf bank bees':'BANKBEES','cpse etf':'CPSEETF'}
            # indices to track
            indices_list = ['NIFTY','BANKNIFTY','FINNIFTY']
            # get master files and index constituents
            master_table(d, indices_list, etf_name_dict)
            # get ETF constituents
            #process_ETF_master(etf_name_dict)
            email_utility(get_contacts(contacts_dir+"contacts.txt"),
                      "KITSBOARD Master files",
                      "{} \n KITSBOARD master files updated by python process running on {}".format(
                              datetime.datetime.now(), socket.gethostbyname(socket.gethostname())))
            shutil.copy('/Output/PairMaster.csv',output_dir+'PairMaster.csv')
            update_db.update_lastruntime("cash_fut_master")
            break
        except Exception as e:
            print (e)
            logging.error(e)
        time.sleep(60)
            
            
            
                
stime = time.time()
if __name__=='__main__':
    update_db.update_status("cash_fut_master")
    main()
    
print ("Processing time {}".format(time.time()-stime))
