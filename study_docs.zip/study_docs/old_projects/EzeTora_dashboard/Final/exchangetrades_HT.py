# -*- coding: utf-8 -*-
"""
Created on Tue Jul  5 16:28:14 2022

@author: krishna
"""

import time
import os, shutil
import sys
import numpy as np
import pandas as pd
import datetime
import logging
import warnings
import redis
from Trades import TradesAggregate
import ConfigParser
#sys.path.insert(0, '/home/hadoop/ULOrdersRealtime/')
#from Trades import TradesAggregate
warnings.filterwarnings("ignore")

# load config details
config_parser = ConfigParser.ConfigParserUtility(os.path.join(os.getcwd(), "config.txt"))
config_props_dict = config_parser.parse_configfile()

'''
DYMON -> ZRFA
POLYMER -> ZRLH
PINPOINT -> ZRWW
SCHONFELD -> ZXJV
CITADEL -> ZXNA
BALYASNY -> ZPPY
OPTIMAS -> ZXOG
'''
    
account_keyname = ["TradeAccountsOMM.{}".format(family) for family in [str.strip(code) for code in config_props_dict["exch_accountids_ht"].split(",")] ]
_redis_ip = [str.strip(i) for i in config_props_dict["exch_accountids_ht_redis_ip"].split(",")] #UAT -> ["10.223.105.99"]
_redis_port = int(config_props_dict["exch_accountids_ht_redis_port"].strip())
_appendmode = 0
logging.basicConfig(filename=os.path.join(config_props_dict["log_dir"].strip(),"ex_alltrades_lt.log"),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

class ExchangeTradesReader(object):
    
    def __init__(self):
        
        # default dropcopy path
        self.ipfilepath = config_props_dict["dropcopy_dir"].strip()
        self._Output_cols = ['Account','Exchange','TradingSymbol','Symbol','InstrumentType','Expiry','StrikePrice','CallOrPut','Side',
              'Quantity','Average','Value','CpCode','Quantity_Lots']
        self._fills_cols = ['TradeId', 'TradeStatus', 'InstrumentType', 'Symbol', 'Expiry', 'StrikePrice', 'CallOrPut', 
                            'TradingSymbol', 'Side', 'Quantity', 'Average', 'Account','Trade_time', 'Exchange_Order_Id',
                            'Exchange', 'Value', 'TradeId_side', 'LotSize', 'Quantity_Lots','TD']
        self._Filenames=[["nsecm1.txt"],["nsefo1.txt","nsefo2.txt"],["bsecm.csv"]]
        
    def read_params(self, filetype):
        
        if filetype=='notis':
            # notis params
            self._Filenames=[["nsecm_bkcapi.txt"],["nsefo_bkcapi.txt"],["bsecm.csv"]]
            self.ipfilepath = config_props_dict["notis_dir"].strip()
        elif filetype=='alias':
            # alias params
            self._Filenames=[["nsecm1.txt"],["nsefo1.txt"],["bsecm.csv"]]
            self.ipfilepath = config_props_dict["alias_dir"].strip()
        elif filetype=='dropcopy':
            self._Filenames=[["nsecm1.txt"],["nsefo1.txt","nsefo2.txt"],["bsecm.csv"]]
            self.ipfilepath = config_props_dict["dropcopy_dir"].strip()
        
            
                

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date
        
        
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
    
    # read holiday master
    holiday_master = pd.read_csv(os.path.join(config_props_dict["holiday_dir"].strip(),'Holidays_2019.txt'), delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)    
    
    
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1
        

def write_file(filepath, temp):
    global _appendmode
    # writes data in append mode
    if _appendmode==0:
        temp = temp.to_csv(index=False,sep=",")
    else:
        temp = temp.to_csv(index=False,sep=",", header=False)
    while True:
        try:                        
            #f = open(r"\\172.17.9.94\TradeFile\nsecm_bkcapi.txt","ab",8192*1024*20) 
            f=open(filepath, "w" if _appendmode==0 else 'a', 8192*1024*20)
            f.writelines(temp)
            f.flush()
            os.fsync(f.fileno())                 
            f.close()
            break
        except Exception as e:
            print ("File write error : Error {}".format(e))
            time.sleep(5)
            
    _appendmode=1
            
    
def load_lot_size():
    
    df=pd.read_csv(os.path.join(config_props_dict["instru_dir"].strip(), "instrument.csv"))
    #df=pd.read_csv("D:\\Trades_tally\\FNO\\Dropcopy\\instrument.csv")
    
    return df[df['ExchangeSegment']=='NFO'][['TradingSymbol','LotSize']]
   

class FileReader():
    '''Class to read input file 
    keeps running track of file offset
    '''
    def __init__(self, filename_list, schema, input_dir):
        self.offset = [0,0] if type(filename_list)==list else [0] # dynamic list to maintain the offset of tail file reader
        self.filename_list = filename_list # can read multiple files in list of same format
        self.input_schema = schema # file schema to be read
        self.input_dir = input_dir
        
    def read(self, delimiter):
        # read file and process output
        result = pd.DataFrame()
        for i, _file in enumerate(self.filename_list): # enumerate in order to maintain the index of file reader in list
            print (os.path.join(self.input_dir,_file))
            prev_file =  pd.read_csv(os.path.join(self.input_dir,'{}'.format(_file)), header=None, names= self.input_schema,
                                     delimiter=delimiter, skiprows=self.offset[i], converters={i: str for i in range(0, 100)},
                                     low_memory=False)# read prev updated file
            if prev_file.empty==False:
                result = result.append(prev_file, ignore_index=True,sort=None)
                
            self.offset[i]+=len(prev_file) # maintains the offset of file reader in tail mode
        
        return result
       

def reload_filepaths(exchfilereader_obj):
    
    ipfileflag, ipfilename = open(os.path.join(config_props_dict["flag_dir"].strip(), "ipexch_flag_ht.txt"), "r").read().strip().split(" ") # read input file
    
    if (ipfileflag=='1'):
        print ("Change in exchange input file preference by the user; reloading the object...")
        print ("Loading {} object; and reading {} file".format(ipfilename, ipfilename))
        exchfilereader_obj.read_params(ipfilename)
        # set flag to zero
        try:
            with open(os.path.join(config_props_dict["flag_dir"].strip(), "ipexch_flag_ht.txt"), "w") as f:
                f.write("0 {}".format(ipfilename))
                
        except Exception as e:
            print (e)
            return exchfilereader_obj, ipfilename
        
    return exchfilereader_obj, ipfilename


def flattern(A):
    rt = []
    for i in A:
        if isinstance(i,list): rt.extend(flattern(i))
        else: rt.append(i)
    return rt
"""
def load_tradeaccounts():
    '''
    load trade accounts from csv file
    '''
    
    account_ids = pd.read_csv(os.path.join(os.getcwd(), "HT_accountids.csv"))
    account_ids = list(set(flattern(account_ids.values.tolist())))
    try:
        account_ids.remove(np.nan)
    except Exception as e:
        print (e)
        
    return account_ids 
"""

def load_tradeaccounts():
    '''
    load trade accounts from redis
    '''
    result = []
    
    for redis_ip in _redis_ip:
        print(redis_ip)
        redis_client = redis.StrictRedis(host=redis_ip, port=_redis_port, db=0,charset="utf-8", decode_responses=True)
        stime = time.time()
        for keyname in account_keyname:
            print(f"Leading exchange ids from key {keyname}")
            try:
                for key,_ in redis_client.zscan_iter(keyname):
                    result.append(redis_client.hgetall(key))
        
                print ("Accoount ids read time from redis {}".format(time.time()-stime))
            except Exception as e:
                print (e);
                # load last updated csv
            
    result = pd.DataFrame(result)
    result.to_csv("account_ids.csv", index=False)
    #result = pd.read_csv("account_ids.csv")
            
    return result['account_code'].values.tolist()



 
def main():
     
    # check for running process condition
    d = (datetime.datetime.now()-datetime.timedelta(days=0)).date()
    if datetime.datetime.now().time()<=datetime.time(9,15):
        # reset file
        pd.DataFrame(columns='TradeId,TradeStatus,InstrumentType,Symbol,Expiry,StrikePrice,CallOrPut,TradingSymbol,\
        Book_type,Book_type_name,Market_type,UserId,Branch_id,Side,Quantity,Average,Pro_Client,Account,Participant,\
        Open_close_flag,Uncover_flag,Order_entry_time,Trade_time,Exchange_Order_Id,CpCode,Order_entry_time1,CTCL code,\
        Exchange,Value,TradeId_side,LotSize,Quantity_Lots,TD'.split(",")).to_csv(
            os.path.join(config_props_dict["output_dir"].strip(), "exchangefills_HT.txt"), index=False)
        
        pd.DataFrame(columns='Account,Exchange,TradingSymbol,Symbol,InstrumentType,Expiry,StrikePrice,CallOrPut,\
        Side,Quantity,Average,Value,CpCode,LotSize,Quantity_Lots,TD'.split(",")).to_csv(
            os.path.join(config_props_dict["output_dir"].strip(), "exchangetrades_HT.txt"), index=False)
        
    
    if process_run_check(d) == -1:
        logging.info('Exit: Holiday.')
        return -1   
    else:
        logging.info("Start processing for working day !")
    
    # load lot sizes for today
    lot_sizes = load_lot_size()
    # load low touch account ids
    _accountids = load_tradeaccounts()
    #_accountids = ['KPOLY1']
    # load account ids for mlp
    #account_ids = pd.read_excel(os.path.join(accountid_dir, "Millennium client codes.xlsx"))
    # trade agg object
    trades = TradesAggregate() # trade aggregator
    exchfilereader_obj = ExchangeTradesReader()
        
    # file objects that keep track of offset and reads data in tail fashion
    nsecm_file_obj = FileReader(exchfilereader_obj._Filenames[0], trades.input_schema_nsecm, exchfilereader_obj.ipfilepath)
    bsecm_file_obj = FileReader(exchfilereader_obj._Filenames[2], trades.input_dcschema_bsecm, exchfilereader_obj.ipfilepath)
    nsefo_file_obj = FileReader(exchfilereader_obj._Filenames[1], trades.input_dcschema_nsefo, 
                                exchfilereader_obj.ipfilepath) # defaults on dropcopy files
    
    #batch_data=pd.DataFrame()
    btime=time.time()
    reload_time = time.time(); filereloader = 0
    processing_time = 0
    while 1:
        
        try: 
            filereloader, _ = open(os.path.join(config_props_dict["flag_dir"].strip(), "ipexch_flag_ht.txt"), "r").read().strip().split(" ")
               
            if processing_time>2 or (time.time()-btime>=2):
                if (time.time()-reload_time>=300) or filereloader=='1':
                    global _appendmode
                    _appendmode = 0
                    # file objects that keep track of offset and reads data in tail fashion
                    logging.info("Reloading objects.....")
                    print("Reloading objects.....")
                    rtime = time.time()
                    #del trades; del nsecm_file_obj; del bsecm_file_obj; del nsefo_file_obj
                    trades = TradesAggregate()
                    exchfilereader_obj, ipfilename = reload_filepaths(exchfilereader_obj)
                    
                    nsecm_file_obj = FileReader(exchfilereader_obj._Filenames[0], trades.input_schema_nsecm, exchfilereader_obj.ipfilepath)
                    
                    if ipfilename=='dropcopy':
                        nsefo_file_obj = FileReader(exchfilereader_obj._Filenames[1], trades.input_dcschema_nsefo, exchfilereader_obj.ipfilepath)
                        bsecm_file_obj = FileReader(exchfilereader_obj._Filenames[2], trades.input_dcschema_bsecm, exchfilereader_obj.ipfilepath)
                    else:
                        nsefo_file_obj = FileReader(exchfilereader_obj._Filenames[1], trades.input_schema_nsefo, exchfilereader_obj.ipfilepath)
                        bsecm_file_obj = FileReader(exchfilereader_obj._Filenames[2], trades.input_schema_bsecm, exchfilereader_obj.ipfilepath)
                        
                    #bsecm_file_obj = FileReader(_Filenames[2], trades.input_schema_bsecm)
                    reload_time=time.time()   
                    print ("Reloading time {}".format(time.time()-rtime))               
                
                print ("Start processing batch.........................")
                
                s=time.time()
                
                nsecm_ctcl_list, nsefo_ctcl_list, bsecm_ctcl_list = None,None,None#load_ctcl_setup(trades)
                #account_ids = pd.read_excel(os.path.join(accountid_dir, "Millennium client codes.xlsx")) # reload account ids
                ftime = time.time()
                # read new records in file, pre-process and aggregate trades for every iteration
                nsecm_df = nsecm_file_obj.read(delimiter=',')
                bsecm_df = bsecm_file_obj.read(delimiter='|')
                nsefo_df = nsefo_file_obj.read(delimiter=',')
                print ("File reading time {}".format(time.time()-ftime))
                
                ftime = time.time()
                try:
                    if nsecm_df.empty==False:
                        print("processing nse cm")
                        nsecm_df = trades.pre_process(nsecm_df, 'NSE-CM', nsecm_ctcl_list)
                        nsecm_df = nsecm_df[nsecm_df['Account'].isin(_accountids)][['TradeId','TradeStatus','InstrumentType','Symbol','Expiry','StrikePrice','CallOrPut','TradingSymbol',
                                            'Side','Quantity','Average','Account','TradeTime','ExchangeOdrId','Exchange','Value','TradeId_side']].rename(columns={
                                            'ExchangeOdrId':'Exchange_Order_Id','TradeTime':'Trade_time'})
                except Exception as e:
                    print(e)
                    nsecm_df = pd.DataFrame()
                try:                        
                    if bsecm_df.empty==False:
                        print("Processing bse cm")
    
                        bsecm_df = trades.pre_process(bsecm_df, 'BSE-CM', bsecm_ctcl_list)
                        bsecm_df = bsecm_df[bsecm_df['Account'].isin(_accountids)][['TradeId','TradeStatus','InstrumentType','Symbol','Expiry','StrikePrice','CallOrPut',
                                            'TradingSymbol','Side','Quantity','Average','Account','TradeModificationTime','OrderId','Exchange','Value','TradeId_side']].rename(
                                            columns={'ScripGroup':'InstrumentType','TradeModificationTime':'Trade_time','OrderId':'Exchange_Order_Id'})
                        bsecm_df['Trade_time'] = datetime.datetime.now().strftime("%d %b %Y") +" "+ bsecm_df['Trade_time'].astype(str) 
                except Exception as e:
                    print(e)
                    bsecm_df = pd.DataFrame()
                    
                if nsefo_df.empty==False:
                    print("Processing nse fo ")
                    nsefo_df = trades.pre_process(nsefo_df, 'NSE-FO', nsefo_ctcl_list)
                    nsefo_df = nsefo_df[nsefo_df['Account'].isin(_accountids+['ERROR'])]
                print ("File pre-processing time {}".format(time.time()-ftime))
            
                nsefo_df.drop_duplicates(inplace=True)
                nsecm_df.drop_duplicates(inplace=True)
                bsecm_df.drop_duplicates(inplace=True)
                
                temp = pd.concat([nsefo_df, nsecm_df, bsecm_df], axis=0)                
                temp.loc[temp['InstrumentType']=='0', 'InstrumentType'] = 'EQ'
                
                if temp.empty==False:
                    temp = temp[temp['TradeStatus']==11]
                    temp = temp.merge(lot_sizes, on=['TradingSymbol'], how='left')
                    temp.loc[(temp['Exchange'].isin(['NSE-CM','BSE-CM'])), 'LotSize'] = 1
                    temp.loc[(temp['Exchange']=='NSE-FO') & (temp['LotSize']>0), 'Quantity_Lots'] = temp['Quantity']/temp['LotSize']
                    temp['Quantity_Lots'] = temp['Quantity_Lots'].fillna(0).astype(int)
                    temp.loc[temp['Side'].astype(str).isin(['1','B']), 'Side'] = 'BUY'
                    temp.loc[temp['Side'].astype(str).isin(['2','S']), 'Side'] = 'SELL'
                    temp['Expiry'] = temp['Expiry'].apply(lambda row: datetime.datetime.strptime(row, "%d%b%Y").strftime("%Y%m") if row!='XX' else 'XX')
                    temp['TD'] = temp['Trade_time'].apply(lambda row: datetime.datetime.strptime(row, "%d %b %Y %H:%M:%S").strftime("%d-%b-%Y"))
                    write_file(os.path.join(config_props_dict["output_dir"].strip(), "exchangefills_HT.txt"), temp[exchfilereader_obj._fills_cols])
                
                
                '''
                update_flag=0
                #if nsecm_df.empty!=True:
                #    print("Processing records for NSE-CM")
                #    trades.process_records(nsecm_df, 'NSE-CM')
                #    update_flag=1
                if nsefo_df.empty!=True:
                    print("Processing records for NSE-FO")
                    trades.process_records(nsefo_df, 'NSE-FO')
                    update_flag=1
                #if bsecm_df.empty!=True:
                #    print("Processing records for BSE-CM")
                #    trades.process_records(bsecm_df, 'BSE-CM')
                #    update_flag=1
                    
                if update_flag==1:
                    print("Updates in trade agg; writing file to user dir")
                    output = trades.result.groupby(by=['Exchange'], as_index=False).apply(lambda grp: trades.format_output(grp, grp.name))
                    
                    # add lot sizes to end
                    output = output.merge(lot_sizes, on=['TradingSymbol'], how='left')
                    output.loc[(output['Exchange'].isin(['NSE-CM','BSE-CM'])), 'LotSize'] = 1
                    output.loc[(output['Exchange']=='NSE-FO') & (output['LotSize']>0), 'Quantity_Lots'] = output['Quantity']/output['LotSize']
                    output['Quantity_Lots'] = output['Quantity_Lots'].astype(int)
                    output.sort_values(by=['Account','Exchange','TradingSymbol'], inplace=True)
                    #output['Quantity_Lots'] = output[['Quantity','LotSize']].apply(lambda row: row['Quantity']/row['LotSize'] if row['LotSize']>0 else row['Quantity'], axis=1)
                    output['Expiry'] = output['Expiry'].apply(lambda row: datetime.datetime.strptime(row, "%d%b%Y").strftime("%Y%m") )
                    # split trades according to the account mappings
                    #user_trade_splits(output)
                    output['TD'] = temp['TD'].values[-1]
                    output.to_csv(os.path.join(output_dir, "exchangetrades_HT.txt"), index=False)
                '''
                processing_time = time.time()-s
                print("Batch processing time {}".format(processing_time))
                btime=time.time()    
            
        except Exception as e:
            time.sleep(5)
            print (e)
            
        if datetime.datetime.now().time()>=datetime.time(16,30):
            print("End process for current day...")
            logging.info("End process for current day...")
            break
    
            
import psycopg2
import datetime
from project_status_update import project_status_rt as udt
update_db= udt.postgres_updations()
update_db.update_status("Exchangetrades_HT")

if __name__=='__main__':
    main()
    update_db.update_lastruntime("Exchangetrades_HT")
