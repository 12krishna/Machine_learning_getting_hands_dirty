# -*- coding: utf-8 -*-
"""
Created on Tue Aug  2 11:02:17 2022

@author: krishna
"""

from cassandra.cluster import Cluster
import os, sys
import pandas as pd
import datetime


# set dependency paths here
if sys.platform not in ('win32', 'cygwin', 'cli'):
    master_dir = '/home/hadoop/master/'
else:
    master_dir = "D:\\Master\\"

def dateparse(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date


class Cassandra_utility(object):
    '''
    class to perform read/write
    operations on cassandra table
    '''

    def __init__(self):
        self.session = self.connect()


    def connect(self):

        cluster = self.cassandra_configs_cluster()
        session = cluster.connect('rohit')
        #logging.info('Using test_df keyspace')
        session.row_factory = self.pandas_factory
        session.default_fetch_size = None
        return session


    # Define a pandas factory to read the cassandra data into pandas dataframe:
    def pandas_factory(self, colnames, rows):

        '''Pandas factory to determine cassandra data into python df'''
        return pd.DataFrame(rows, columns=colnames)

    def cassandra_configs_cluster(self):

        f = open(os.path.join(master_dir,"config.txt"),'r').readlines()
        f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]

        from cassandra.auth import PlainTextAuthProvider

        auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
        cluster = Cluster([f[0]], auth_provider=auth_provider)

        return cluster

    def read(self, query, datecol):

        query=self.session.execute(query, timeout=None)
        result=query._current_rows

        result[datecol] = result[datecol].apply(lambda row: row.date())
        result.sort_values(by=datecol, inplace=True)

        return result


    def read_fnobhavcopy(self, fdate, tdate, datecol):

        result = pd.DataFrame()
        if fdate!=None:
            while fdate<=tdate:
                try:
                    print (f"Getting date for {fdate}")
                    for instru in ['FUTSTK','FUTIDX']:
                        df = self.session.execute(f"select * from fno_bhavcopy where instrument='{instru}' and\
                                                  {datecol}='{fdate}' allow filtering",
                                         timeout=None)._current_rows
                        if df.empty==False:
                            print(f"No of rows fetched {len(df)}")
                            result = result.append(df, ignore_index=True)
                        else:
                            print(f"Data not present for {fdate}")
                        fdate = fdate + datetime.timedelta(days=1)
                except Exception as e:
                    print(e)

        print (f"No of rows fetched {len(result)}")
        return result

