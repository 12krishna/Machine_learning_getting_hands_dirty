# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 16:44:05 2020

@author: devanshm
"""

import gzip,string,re,os,glob,simplefix,datetime,logging, shutil
import pandas as pd 
#import numpy as np
from dateutil import relativedelta
os.chdir("D:\\ExtractUL_data_monthly\\")

output_dir='D:\\ExtractUL_data_monthly\\Output\\' #contains final output
#download_dir='C:\\Users\\devanshm\\Desktop\\FIX Feb Orders\\check\\' #contains ul data
raw_files='D:\\ExtractUL_data_monthly\\RawFiles\\' #contain intermediate processing files
log_dir='D:\\ExtractUL_data_monthly\\log\\' #contains log files
email_dir = "D:\\Emails\\Output\\"
ul_files_dir = r"\\172.17.9.141\Backup\UL\10.223.104.74"


logging.basicConfig(filename=log_dir+"extract_gz{}.log".format(datetime.datetime.now().date()),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def getkeys():#fuction to get key pairs from csv filr
    kf=pd.read_csv('ChgdClients.csv') #keywords file
#    kf.columns=["tag49","tag56","tag1","tag115","tag116","result"]
    kf.columns=["tag49","tag56","tag1","tag115","tag116"]
    kf=kf[["tag49","tag56","tag1","tag115","tag116"]]
    logging.info("read csv file sucessfully")
    
    kf=kf.applymap(str)

    kf[["tag49","tag56","tag1","tag115","tag116"]]=kf[["tag49","tag56","tag1","tag115","tag116"]].astype(str)
    kf["tag49"] = kf["tag49"].apply(lambda x: x.split('.')[0])
    kf["tag56"] =  kf["tag56"].apply(lambda x: x.split('.')[0])
    kf["tag1"] = kf["tag1"].apply(lambda x: x.split('.')[0])
    kf["tag115"] =  kf["tag115"].apply(lambda x: x.split('.')[0])
    kf["tag116"] =  kf["tag116"].apply(lambda x: x.split('.')[0])
    kf[["tag49","tag56","tag1","tag115","tag116"]]=kf[["tag49","tag56","tag1","tag115","tag116"]].replace('nan','None')
    
    logging.info("keys generated")
    
    return kf


def get_dataframe_2(d,m,y):#function to get dataframe from the gz files for fix .2
    expr = r'8=FIX\.4\.2.*?10=\d+\|'
   
    #files1=glob.glob(r"\\172.17.9.141\Archive_Data\UL\10.223.104.71\*.gz")
    files1=glob.glob(os.path.join(ul_files_dir, "*.gz"))
#    files1=glob.glob(download_dir+r"*.gz")

#    print"all .gz files",files1
    files2=[]
    if m < 10:
        month='0'+str(m)
    else:
        month=str(m)

    year=str(y)
    ep=r'-{}-{}'.format(month,year)
    for k in files1:
#        print k
        if "BridgeLogs" in k:
            logging.info("got files for the current month")
            if (ep in k) and (ep in k):
                files2.append(k)
            else:
                logging.info("not a month i am looking for {}".format(k))
        
    logging.info("reading .gz files")
    tempfile1_name =raw_files+"tempfile1_{}_{}".format(d,m)+".csv"
    tempfile1 = open(tempfile1_name, 'w')
    for f in files2:
        with gzip.open(f, "rb") as f1:
            print "files extracted from .gz file",f1
            logging.info("processing for file {}".format(f1))
            data = f1.readlines()
            for line in data:
                if re.findall(expr, line):
                    rx = re.findall(expr, line)
                    if '35=D' in rx[0]:
                        logging.info("ul data {}".format(rx[0]))
                        x = string.replace(rx[0], '|','\x01').replace("PROG","").replace("pi","").replace("ct","").replace("st","")
#                        print "value",x

                        parser = simplefix.FixParser()
                        parser.append_buffer(x)
                        msg = parser.get_message()
                        try:
                          
                            s=msg.get(35)
                        except:
                            s=0
                        if s==0:
                            logging.info("ignore")
                        else:
                            logging.info("writing values")
                            tempfile1.write(str(msg.get(115)) + "," +str(msg.get(38)) + "," + str(msg.get(55)) + "," + str(msg.get(1)) + "," + str(msg.get(116)) + "," + str(msg.get(44))+ "," + str(msg.get(49))+ "," + str(msg.get(56))+ "," + str(msg.get(52)))
                            tempfile1.write("\n")
                            

    tempfile1.close()
    logging.info('done and csv file generated sucessfully')
    
def get_dataframe_4(d,m,y):#function to get dataframe from the gz files for fix .4
    expr = r'8=FIX\.4\.4.*?10=\d+\|'
   
    #files1=glob.glob(r"\\172.17.9.141\Archive_Data\UL\10.223.104.71\*.gz")
    files1 = glob.glob(os.path.join(ul_files_dir, "*.gz"))
#    files1=glob.glob(download_dir+r"*.gz")

#    print"all .gz files",files1
    files2=[]
    if m < 10:
        month='0'+str(m)
    else:
        month=str(m)

    year=str(y)
    ep=r'-{}-{}'.format(month,year)
    for k in files1:
#        print k
        if "BridgeLogs" in k:
            logging.info("got files for the current month")
            if (ep in k) and (ep in k):
                files2.append(k)
            else:
                logging.info("not a month i am looking for {}".format(k))

            
    logging.info("reading .gz files")
    tempfile1_name =raw_files+"tempfile2_{}_{}".format(d,m)+".csv"
    tempfile1 = open(tempfile1_name, 'w')
    for f in files2:
        with gzip.open(f, "rb") as f1:
            print "files extracted from .gz file",f1
            logging.info("processing for file {}".format(f1))
            data = f1.readlines()
            for line in data:
                if re.findall(expr, line):
                    rx = re.findall(expr, line)
                    if '35=D' in rx[0]:
                        logging.info("ul data {}".format(rx[0]))
                        x = string.replace(rx[0], '|','\x01').replace("PROG","").replace("pi","").replace("ct","").replace("st","") 
#                        print "value",x
                        parser = simplefix.FixParser()
                        parser.append_buffer(x)
                        msg = parser.get_message()
                        try:
                            
                            s=msg.get(35)
                        except:
                            s=0
                        if s==0:
                            logging.info("ignore")
                        else:
                            logging.info("writing values")
                            tempfile1.write(str(msg.get(115)) + "," +str(msg.get(38)) + "," + str(msg.get(55)) + "," + str(msg.get(1)) + "," + str(msg.get(116)) + "," + str(msg.get(44))+ "," + str(msg.get(49))+ "," + str(msg.get(56))+ "," + str(msg.get(52)))
                            tempfile1.write("\n")
                            

    tempfile1.close()
    logging.info('done and csv file generated sucessfully')
    
def concat_files(d,m):#concat both .2 and .4 files into one dataframe
    df=pd.read_csv(raw_files+"tempfile1_{}_{}.csv".format(d,m))
    df.columns=["onbehalfCompID","OrderQty","Symbol","Account","onbehalfSubID","Price","SenderCompID","TargetCompID","date"]
    df1=pd.read_csv(raw_files+"tempfile2_{}_{}.csv".format(d,m))
    df1.columns=["onbehalfCompID","OrderQty","Symbol","Account","onbehalfSubID","Price","SenderCompID","TargetCompID","date"]
    df3=pd.concat([df,df1],axis=0,verify_integrity=False,ignore_index=True)
    df3.reset_index(drop=True,inplace=True)
    df3.to_csv(raw_files+"final_output_{}_{}.csv".format(d,m),index=False)
    
def generate_output(kf,d,m):#function to generate file of clients who are sending orders
    df=pd.read_csv(raw_files+"final_output_{}_{}.csv".format(d,m))
    df.columns=["onbehalfCompID","OrderQty","Symbol","Account","onbehalfSubID","Price","SenderCompID","TargetCompID","date"]
    #115,38,55,1,116,44,49,56
    kf.columns=["SenderCompID","TargetCompID","Account","onbehalfCompID","onbehalfSubID"]
  
    tag49=kf.loc[kf["SenderCompID"].isin(df["SenderCompID"])]
    tag56=tag49.loc[tag49["TargetCompID"].isin(df["TargetCompID"])]
    tag1=tag56.loc[tag56["Account"].isin(df["Account"])]
    tag115=tag56.loc[tag56["onbehalfCompID"].isin(df["onbehalfCompID"])]
    tag116=tag56.loc[tag56["onbehalfSubID"].isin(df["onbehalfSubID"])]
    
    p1=pd.merge(tag49,tag56,how="outer")
    p2=pd.merge(p1,tag1,how="outer")
    p3=pd.merge(p2,tag115,how="outer")
    p4=pd.merge(p3,tag116,how="outer")
   
    p4.reset_index(drop=True,inplace=True)
    p4["comkeys"]=p4["SenderCompID"]+p4["TargetCompID"]+p4["Account"]+p4["onbehalfCompID"]+p4["onbehalfSubID"]
    p4["comkeys"]=p4["comkeys"].apply(lambda x: x.replace('None',''))
    p4.drop_duplicates(subset ="comkeys",keep ='first', inplace = True)
    p4.reset_index(drop=True,inplace=True)
    
    t1=p4.loc[~p4["SenderCompID"].isin(['None'])]
    t2=p4.loc[~p4["TargetCompID"].isin(['None'])]
    t3=p4.loc[~p4["Account"].isin(['None'])]
    t4=p4.loc[~p4["onbehalfCompID"].isin(['None'])]
    t5=p4.loc[~p4["onbehalfSubID"].isin(['None'])]  

    l1=df.loc[df["SenderCompID"].isin(t1["SenderCompID"])]
    l2=l1.loc[l1["TargetCompID"].isin(t2["TargetCompID"])]
    l3=l2.loc[l2["Account"].isin(t3["Account"])]
    l4=l2.loc[l2["onbehalfCompID"].isin(t4["onbehalfCompID"])]
    l5=l2.loc[l2["onbehalfSubID"].isin(t5["onbehalfSubID"])]
  
    q1=pd.merge(l1,l2,how="outer")
    q2=pd.merge(q1,l3,how="outer")
    q3=pd.merge(q2,l4,how="outer")
    q4=pd.merge(q3,l5,how="outer")
    
    q4.reset_index(drop=True,inplace=True)
    q4["date"]=q4["date"].apply(lambda x: x.split('.')[0])
    q4["date"]=q4["date"].astype(str)
    q4['date']= pd.to_datetime(q4['date'])
    q4['date'] = q4['date'].dt.date
    q4[["onbehalfCompID","OrderQty","Symbol","Account","onbehalfSubID","Price","SenderCompID","TargetCompID","date"]]=q4[["onbehalfCompID","OrderQty","Symbol","Account","onbehalfSubID","Price","SenderCompID","TargetCompID","date"]].astype(str)
    q4=q4[["onbehalfCompID","OrderQty","Symbol","Account","onbehalfSubID","Price","SenderCompID","TargetCompID","date"]]
    logging.info("final output generated")
    q4.sort_values(by="date",ascending=False,inplace=True)
    q4.reset_index(drop=True,inplace=True)
    q4.to_csv(output_dir+"client_sending_orders_{}_{}.csv".format(d,m),index=False)

def generate_ns(kf,d,m):#function to generate file of clients who are not sending orders
    df=pd.read_csv(output_dir+"client_sending_orders_{}_{}.csv".format(d,m))

    df=df[["SenderCompID","TargetCompID","Account","onbehalfCompID","onbehalfSubID"]]
    kf.columns=["SenderCompID","TargetCompID","Account","onbehalfCompID","onbehalfSubID"]
    
    tag49=kf.loc[~kf["SenderCompID"].isin(df["SenderCompID"])]
    tag56=kf.loc[~kf["TargetCompID"].isin(df["TargetCompID"])]
    tag1=kf.loc[~kf["Account"].isin(df["Account"])]
    tag115=kf.loc[~kf["onbehalfCompID"].isin(df["onbehalfCompID"])]
    tag116=kf.loc[~kf["onbehalfSubID"].isin(df["onbehalfSubID"])]

    q1=pd.concat([tag49,tag56,tag1,tag115,tag116],axis=0)
        
    q1["comkeys"]=q1["SenderCompID"]+q1["TargetCompID"]+q1["Account"]+q1["onbehalfCompID"]+q1["onbehalfSubID"]
    q1["comkeys"]=q1["comkeys"].apply(lambda x: x.replace('None',''))

    q1.drop_duplicates(subset="comkeys",inplace = True)
    q1.reset_index(drop=True,inplace=True)
    
    
    q1=q1[["SenderCompID","TargetCompID","Account","onbehalfCompID","onbehalfSubID"]]
    q1.to_csv(output_dir+"client_not_sending_orders_{}_{}.csv".format(d,m),index=False)
    logging.info("final output generated for client not sending orders")       

    

def main():
   d=datetime.datetime.now().date() - relativedelta.relativedelta(months=1)                    #-datetime.timedelta(months=1)
   
   m=d.month #change month here
   y=d.year  #change year here
   kf=getkeys() 
   get_dataframe_2(d,m,y)
   get_dataframe_4(d,m,y)
   concat_files(d,m)
   generate_output(kf,d,m)
   generate_ns(kf,d,m)
   
   # move o/p files to email dir to send an auto email
   shutil.move(output_dir+"client_sending_orders_{}_{}.csv".format(d,m), email_dir+"client_sending_orders_{}_{}.csv".format(d,m))
   shutil.move(output_dir+"client_not_sending_orders_{}_{}.csv".format(d,m), email_dir+"client_not_sending_orders_{}_{}.csv".format(d,m))

   
   
main()