import pandas as pd
import os

def is_non_zero_file(fpath):  
    return os.path.isfile(fpath) and os.path.getsize(fpath) > 0

inputfile = "D:\\bsecm.csv"
outputfile = "D:\\BR_bse_all_cash_10SEP.txt"

id_list = [4,6,9,10,17,26,27,30,31,35,36,37,43,44,46,251,253,254,256,258,260,264,301,718,1005,1004,1006,1007,1008,1009,1010,1011,1012,1013,1014,1015,1017]

if(is_non_zero_file(inputfile) == True):
    df = pd.read_csv(inputfile,header=None,names=["memberid","terminalid","scripcode","scripname","fillprice","fillsize","tradestatus","filler","tradeexetime","date","clientid","transactionid","transactiontype","buysell","tradeid","cpcode","isin","group","settlementno","ordertimestamp","aopoflags","locationid","trademodtime"],sep="|")
    if df.count > 0:
        df_filtered = df[df['terminalid'].isin(id_list)]
        df_filtered.to_csv(outputfile, index=False, header=False,sep="|")
