# -*- coding: utf-8 -*-
"""
Created on Tue Jul  6 16:07:05 2021

@author: krishna
"""

#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
#from collections import OrderedDict
import time
#from dateutil import parser
import os
import rollover_newformula as Utility_functions_new
import logging
import datetime
import warnings
warnings.filterwarnings("ignore")


master_dir = 'D:\\Master\\'
download_dir = 'D:\\ETL\\Download\\'
bhavcopy_dir = "D:\\Data_dumpers\\NSE_FNO_bhavcopy\\Processed_folder\\"
output_dir = 'D:\\ETL\\Output\\'
log_path = "D:\\ETL\\"
email_dir = "D:\\Emails\\Output\\"
redis_host = 'localhost'

cassandra_host = "172.17.9.51"

logging.basicConfig(filename=log_path+"test_new.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def dateparse(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date

def get_maxOI(dates_list):

    master = pd.read_excel(master_dir + 'MasterData.xlsx')
    master.set_index(keys='SYMBOL', inplace=True)
    master = master[master['IsActiveFNO']==True]  # filter on active fno stocks
    master = master[['BloomCode', 'IsNifty', 'Sector', 'Type']]

    result = pd.DataFrame()
    for date in dates_list:
        print(date)
        temp = pd.read_csv(bhavcopy_dir+"fo{}bhav.csv".format(date.strftime("%d%b%Y").upper()))
        temp = temp[temp['INSTRUMENT'].isin(['FUTSTK','FUTIDX'])]

        temp = temp.join(master, on='SYMBOL')
        #ignore fut weekly
        monthly_exp = temp[temp['Type']=='SSF']['EXPIRY_DT'].unique()
        temp = temp[temp['EXPIRY_DT'].isin(monthly_exp)]

        # create Pivot table
        temp = temp.pivot_table(values=['OPEN_INT', 'SETTLE_PR'], index=['SYMBOL', 'Sector', 'IsNifty', 'Type'],
                                        columns='EXPIRY_DT', aggfunc={'SETTLE_PR': np.sum,
                                                                      'OPEN_INT': np.sum})
        temp.fillna(0, inplace=True)

        # calculate product-near and product-far
        data = pd.DataFrame([map(round, temp['OPEN_INT'].iloc[:, 0] * temp['SETTLE_PR'].iloc[:, 0] +\
                                 temp['OPEN_INT'].iloc[:, 1] * temp['SETTLE_PR'].iloc[:, 1] +\
                                 temp['OPEN_INT'].iloc[:, 2] * temp['SETTLE_PR'].iloc[:, 2])]).T
        data.index = temp.index
        data.columns = ["OI"]
        if result.empty==True:
            result = data.copy(deep=True)
        else:
            result = result.merge(data, right_index=True, left_index=True)

    result['Max_OI'] = result.max(axis=1)
    result = result[['Max_OI']]
    #result.reset_index(inplace=True)

    return result





def main_processor(expiry, month, year, file_name,name, dollar_value, maxOI):
    # if valid Expiry date process and generate reports
    # Remove duplicate rows if any in master files

    Utility_functions_new.drop_duplicate_rows('RollData_new.xlsx')
    Utility_functions_new.drop_duplicate_rows('Indices_dump_new.xlsx')
    Utility_functions_new.drop_duplicate_rows('Unrolled_dumped_new.xlsx')

    # Dataframe with product far, near and rollover values
    logging.info('Calling bhavcopy processor function...')
    data, master = Utility_functions_new.bhavcopy_processor_new(file_name, maxOI)
    logging.info('Calling Sector rollovers...')
    result = Utility_functions_new.sector_rollovers(data)

    # Dump data
    logging.info('Calling rollover_data_dumper function for dumping to master files...')
    dumper, indices_rollover, unrolled_dumper = Utility_functions_new.rollover_data_dumper(data, master, result, expiry,
                                                                                       month, year, name, dollar_value)

    # get top and low stocks from grt than avg sheet
    logging.info('Calling greater than average function...')
    grt_avg_top_stocks, grt_avg_low_stocks = Utility_functions_new.greaterthanAverage(expiry, month, year)
    # get top unrolled OI stocks
    unrolled_OI_top_stocks = {}; average_unrolled ='';
    if expiry == 'E':
        logging.info('Unrolled_OI is not calculated for expiry day...')
        average_unrolled = Utility_functions_new.unrolled_OI_Calculator(expiry, month, year,0)
        pass
    else:
        # calculate unrolled OI
        logging.info('Calculating unrolled_OI for {0}'.format(expiry))
        unrolled_OI_top_stocks, average_unrolled = Utility_functions_new.unrolled_OI_Calculator(expiry, month, year,1)
    # increased activity
    increased_activity = []
    if expiry in ['E-5', 'E-4', 'E-3']:
        logging.info('Skip: Increased activity.')
        pass
    else:
        # calculate increased activity
        logging.info('Calculating increased activity for {0}'.format(expiry))
        increased_activity = Utility_functions_new.increased_activity_calc(expiry, month, year)


    # get top 2 leading and lagging sectors
    logging.info('Get leading and lagging sectors...')
    leading_sectors, lagging_sectors, avg_indices = Utility_functions_new.leading_lagging_sectors(expiry, month, year)

    # call final print
    logging.info('Final report generation...')
    Utility_functions_new.print_final_report(expiry, avg_indices, increased_activity, leading_sectors, lagging_sectors,
                                         grt_avg_top_stocks, grt_avg_low_stocks, unrolled_OI_top_stocks, name, month, year, average_unrolled)

    # Update master files
    logging.info('Dump results to master dump files...')
    Utility_functions_new.append_df_to_excel('RollData_new.xlsx', df=dumper, header=None, index=False)
    Utility_functions_new.append_df_to_excel('Indices_dump_new.xlsx', df=indices_rollover, header=None, index=False)
    Utility_functions_new.append_df_to_excel('Unrolled_dumped_new.xlsx', df=unrolled_dumper, header=None, index=False)



def main(d, dollar_value, expiry, month, year, file_name,name):

    print ("{} Start processing rollovers as per new formula...".format(d))

    df = pd.read_excel(master_dir+"Expiry_dates_master.xlsx")
    df.dropna(inplace=True)
    df['d'] = df.apply(lambda row: datetime.datetime.strptime("{}{}{}".format(row['Date'],
                                                          row['Month'], row['Year']),"%d%b%Y").date() , axis=1)

    maxOI = get_maxOI(df[(df['Month']==d.strftime("%b").upper())&(df['Year']==d.year)&(df['d']<=d)]['d'].values.tolist())

    try:

        main_processor(expiry, month, year, file_name,name, dollar_value, maxOI)

    except Exception as e:
        print (e)



