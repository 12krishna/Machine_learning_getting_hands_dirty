# Converting python file to executable file
#from distutils.core import setup
#import py2exe
#import sys
#sys.setrecursionlimit(5000)

#setup(console=['Expiry.py'])




from cx_Freeze import setup, Executable 


options = {'build_exe': {'packages': ['numpy'], 'include_files':['X:\Anaconda\Lib\site-packages\mkl_intel_thread.dll']} }

setup(name = "Expiry" , 
       version = "1.0" , 
       description = "" ,
       options = options,  
       executables = [Executable("Expiry.py")])