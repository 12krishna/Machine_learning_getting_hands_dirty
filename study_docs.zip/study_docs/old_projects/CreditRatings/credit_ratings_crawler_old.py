# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 19:58:52 2022

@author: krishna
"""

import sys
# import requests
from selenium import webdriver
import openpyxl
import requests
import re, os, datefinder, datetime, time
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys

#from selenium.common.exceptions import TimeoutException
import pandas as pd
from collections import OrderedDict
#from selenium.webdriver.common.action_chains import ActionChains

os.chdir("D:\\CreditRatings\\")
import email_utility
master_dir = "D:\\Master\\"
output_dir = "D:\\CreditRatings\\Output\\"
contacts_dir = "D:\\Emails\\Contacts\\"

_font_style = "calibri"
_header_style = "color:firebrick;font-weight: bold;font-family:{};font-size:10pt".format(_font_style)

class WebScrapper():
    '''
    implements credit ratings alerts
    from various rating websites
    '''

    def __init__(self):

        self._cirsil_url = "https://www.crisil.com/en/home/our-businesses/ratings/rating-rationale.html"
        self._care_url = "https://www.bseindia.com/sensex/code/16"
        self.driver = self.set_proxy_details()
        self.action_keywords = {'UPGRADE':'UPGRADE','DOWNGRADE':'DOWNGRADE','REVISE':'REVISE','MIGRATE':'MIGRATE'}
        self.crisil_keywords = ['finance','bank','payment','payments','finserv','financial','nbfc','financier',
                                  'financiers','banking','microfinance','mfi','loans', 'loan', 'capital', 'securities',
                                  'fintech', 'insurance', 'fincorp']

    def set_proxy_details(self):
        '''Func to set proxy for driver'''

        opts = Options()
        # Add headers
        user_agent =  ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) '
                       'AppleWebKit/537.36 (KHTML, like Gecko) '
                       'Chrome/39.0.2171.95 Safari/537.36')
        opts.add_argument(f'user-agent={user_agent}')
        # Remove the Automation Info
        opts.add_argument('--disable-infobars')
        #opts.add_argument("headless")
        opts.add_argument('--disable-gpu')
        opts.add_argument("--log-level=3")  # fatal
        opts.add_argument('--blink-settings=imagesEnabled=false')
        #opts.add_argument('--no-sandbox')
        #opts.add_argument('--disable-dev-shm-usage')
        
        
        driver = webdriver.Chrome(master_dir+"chromedriver.exe", chrome_options=opts)
        driver.set_page_load_timeout(30)

        #driver.minimize_window()
        print ("Proxy details set for the session")
        return driver
        
    def flattern(self, A):
        rt = []
        for i in A:
            if isinstance(i,list): rt.extend(self.flattern(i))
            else: rt.append(i)
        return rt
    
    def excel_writer(self, df_dicts, filename):
        '''
        appends data in multiple sheets
        '''
        writer = pd.ExcelWriter(output_dir+filename)
        
        for key, value in df_dicts.items():
            value.to_excel(writer,sheet_name = key, index=False )
        
        writer.save()
        writer.close()
   
    
    def crisil_rating_actions(self, url):
        '''
        Gets rating actions table dataframe
        '''
        
        self.driver.get(url)
        time.sleep(2)
        table = BeautifulSoup(self.driver.page_source, 'html.parser').select_one("table#NameTableSecTableId")
        table = pd.read_html(str(table))[1]
        pattern = re.compile(".*Debentures.*|.*Bond.*|.*Certificate of Deposits.*|.*Commercial Paper.*|.*Debt.*")
        if len(list(filter(pattern.match, table.iloc[:,0].values.tolist()))) >0:
            # handle Debentures case
            temp = pd.DataFrame()
            for _, row in table.iterrows():
                if ("Debentures" in row[0]) | ("Bond" in row[0]) | ("Certificate of Deposits" in row[0]) | ("Commercial Paper" in row[0]) | ("Debt" in row[0]):
                    temp = temp.append(pd.DataFrame([[row[0].split("Crore")[0]+"Crore", row[1]]], 
                                                      columns=[re.sub('[!,*)@#%(&$_?.^]+', '',row[0].split("Crore")[-1]).strip(), '{} rating'.format(
                                                               re.sub('[!,*)@#%(&$_?.^]+', '',row[0].split("Crore")[-1]).strip())]))
                else:
                    row = pd.DataFrame(row).T
                    temp = temp.append(pd.DataFrame([self.flattern(row.iloc[:, 1:].values.tolist())] ,
                                columns=[ re.sub('[!,*)@#%(&$_?.^]+', '', col).strip() for col in row.iloc[:,0].values.tolist()]) )
            return temp
        else:
            return pd.DataFrame([self.flattern(table.iloc[:, 1:].values.tolist())] ,
                                columns=[ re.sub('[!,*)@#%(&$_?.^]+', '', col).strip() for col in table.iloc[:,0].values.tolist()] )
        
    def html_file_format(self, outputpathfile, html_string):
        
        with open(outputpathfile,'w') as f:
            f.write(html_string)
    
        output_file = open(outputpathfile, 'r').read().replace("&lt;","<").replace("&gt;",">")
        output_file = output_file.replace("dataframe mystyle","mystyle")
        output_file = output_file.replace('<td>text','<td class="text">')
    
        with open(outputpathfile, 'w') as f:
            f.write(output_file)
    
        
    def crisil_final_data_format(self, df, sdate):
        
        df.drop(columns=['rating temp'], inplace=True)
        df.rename(columns={'Rating Date':'Total'}, inplace=True); df['Total']=df['Total'].astype(str)
        df.fillna("", inplace=True)
        crore_columnnames = [ col for col in df.columns if len(df[df[col].str.startswith("Rs")])>0 ]
        df['Rating Rationale Title'] = df['Rating Rationale Title'].apply(lambda row: " ".join(row.split(":")))
        df['Total'] = 0.0
        for col in crore_columnnames:
            df[col] = df[col].apply(lambda s: re.findall("\d+\.\d+|\d+", str(s))).apply(
                      lambda s: 0.0 if len(s)==0 else float(s[0]))
            df['Total'] += df[col]
            df[col] = df[col].apply(lambda s: f"Rs. {s} Crore")
            
        df.sort_values(by=['Total'], inplace=True, ascending=False)
        df = df[df['Rating']==''].append(df[df['Rating']!=''])
        df = df.replace("Rs. 0.0 Crore", "")
        df['Total'] = df['Total'].apply(lambda s: f"Rs. {s} Crore")
        
        df_dict = OrderedDict() # final data;
        df_dict['all_data'] = df.copy(deep=True)
        # get rating changes
        df_dict['rating_changes'] = df[(df['Rating'].isin(self.action_keywords.keys()))|(df['Company Name'].str.lower().str.contains(
                                '|'.join(self.crisil_keywords), regex=True, na=False))].copy(deep=True)
                                #[['Company Name', 'Rating','Rating link',
                                #'Rating Date','Rating Rationale Title','Cooperation']]
        
        # save data in excel
        self.excel_writer(df_dict, filename="crisil_output_{}.xlsx".format(sdate))
        
        # write html table for email body
        pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>
        html_string = "<html><head><style>{css_style}</style></head><body>".format(css_style = open(os.path.join(os.getcwd(), "df_style.css"), 'r').read())
        html_string += '<p style=\"{}\">Crisil Ratings as on {}</p><br>'.format(
                "color:black;font-weight: bold;font-family:{};font-size:10pt".format(_font_style), sdate)
        
        rating_changes_df = df_dict['rating_changes'].copy(deep=True)
        rating_changes_df = rating_changes_df[['Company Name','Rating Rationale Title','Rating link','Rating','Cooperation',
                                               'Total','Total Bank Loan Facilities Rated','Long Term Rating','Short Term Rating']]
        # embed hyperlink
        rating_changes_df['Company Name'] = rating_changes_df[['Company Name','Rating link']].apply(lambda x: 
                                            '<a href="{}">{}</a>'.format(x['Rating link'], x['Company Name']), axis=1)
        rating_changes_df.drop(columns=['Rating link'], inplace=True)
        if len(rating_changes_df)==len(rating_changes_df[rating_changes_df['Cooperation']=='']):
            rating_changes_df.drop(columns=['Cooperation'], inplace=True)
               
        rating_changes_df = rating_changes_df.to_html(classes='mystyle', index=False).replace(
                                                    '<table border="1" class="dataframe mystyle">',
                                                    '<table border="1" class="mystyle">')
        
        html_string += "<table><tr><td valign='top'>{}</td></tr></table>".format(rating_changes_df)
        html_string += "<br><br></body></html>"
        
        html_file = output_dir+"crisil_{}.html".format(sdate)
        self.html_file_format(html_file, html_string)
        
        return html_file, os.path.join(output_dir, "crisil_output_{}.xlsx".format(sdate))


        
    
    def crisil_ratings(self, startdate):
        '''
        Gets ratings from start date;
        based on relevant keywords
        '''
        
        #starting_date = input("Enter the date in DDMM format")
        #year = datetime.datetime.today().year
        #starting_date1=datetime.date(year, int(starting_date[2:]),int(starting_date[0:2] ))
        starting_date1 = startdate
        self.driver.get(self._cirsil_url)
        time.sleep(5)
        while 1:
            try:
                WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located((By.CSS_SELECTOR, 
                                             "a.forward-arrow.load-more-commonratingresult")))                  
                break
            except Exception as e:
                print(f"Error {e}")
                self.driver.switch_to.window(self.driver.current_window_handle)
                #self.driver.find_element_by_tag_name("body").click()
                #self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);") # handle scroll until exception delay
                self.driver.find_element_by_tag_name("html").send_keys(Keys.END)
                
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);") # handle scroll until exception delay
        #time.sleep(4)
        pg=self.driver.page_source
        soup=BeautifulSoup(pg)
        all_rows = soup.find_all('ul',class_="clearfix")
                
        # iterate until strating date arrives
        while(1):
            date = all_rows[-1].find_all("li")[-1].find("span").text # get last record date
            all_dates=datefinder.find_dates(date)
            for k in all_dates:
              rating_date = k.date()
              print(rating_date)
            if (rating_date>=starting_date1):
                load_button = self.driver.find_element_by_css_selector('a.forward-arrow.load-more-commonratingresult') 
                self.driver.execute_script("arguments[0].click();", load_button)
                #load_button.click()
                time.sleep(10)
                pg=self.driver.page_source
                soup=BeautifulSoup(pg)
                all_rows = soup.find_all('ul',class_="clearfix")
            else:    
                break
                
        # get the page source
        pg=self.driver.page_source
        soup=BeautifulSoup(pg,'lxml')
        all_rows = soup.find_all('ul',class_="clearfix")
        
        # get all divs in dataframe
        row_list = []
        for row in all_rows:
            cols = row.find_all("li")
            try:
                row_list.append([cols[0].find("span").text, cols[1].find("span").text, 
                                 "https://www.crisil.com"+cols[1].find("a").get("href"),
                                 list(datefinder.find_dates(cols[2].find("span").text))[-1].date()])
            except Exception as e:
                print(e)
        df = pd.DataFrame(row_list, columns=['Company Name','Rating Rationale Title','Rating link','Rating Date'])
        df = df[df['Rating Date']>=starting_date1] # get data from starting date
        pattern = "|".join(self.action_keywords.keys())
        df['Rating'] = df['Rating Rationale Title'].apply(lambda s: re.search(pattern=pattern, 
                          string=s, flags=re.IGNORECASE)).apply(lambda s: '' if s==None else self.action_keywords[s.group(0).upper()])
        df['Cooperation'] = df['Rating Rationale Title'].apply(lambda s: re.search(pattern="Issuer Not Cooperating", string=s,
                                  flags=re.IGNORECASE)).apply(lambda s: '' if s==None else s.group(0))
        df.loc[~df['Rating'].isin(self.action_keywords.keys()), 'Cooperation'] = ''
        #self.driver.quit()
        
        df['rating temp'] = range(len(df))
        
        # getting rating actions
        #self.driver_ra = self.set_proxy_details() 
        # reset cookies
        self.driver.delete_all_cookies()
        rating_actions_df = pd.DataFrame()
        for _, row in df.iterrows():
            # get rating details
            try:
                print(row['rating temp'])
                temp = self.crisil_rating_actions(row['Rating link'])
                temp['rating temp'] = row['rating temp']
                rating_actions_df = rating_actions_df.append(temp, ignore_index=True)
                time.sleep(1)
            except Exception as e:
                print (e, row['Rating link'])
                
        df = df.merge(rating_actions_df, on=['rating temp'], how="left")
        # format data
        html_filename, excel_filename = self.crisil_final_data_format(df, starting_date1)
        
        self.driver.delete_all_cookies()
        
        return html_filename, excel_filename
        
        
    def care_ratings(self):
        '''
        Func to get ratings from CARE
        '''
        
        pass
        
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date
      


def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
    
    # read holiday master
    holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                     date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)        
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        #logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))     
        return -1
    
    
def main():
    
    d = datetime.datetime.now().date()-datetime.timedelta(days=0)
    #if process_run_check(d) == -1:
    #    print('Exit: Its an holiday.')
    #    return -1	 
    
    crawler_obj = WebScrapper()
    # get crisil ratings
    html_filename, excel_filename = crawler_obj.crisil_ratings(d)
    #crawler_obj.driver.close()
    crawler_obj.driver.quit()
    # send email
    email_utility.process_status_email(os.path.join(contacts_dir, "credit_ratings.txt"), "Crisil Ratings {}".format(d), 
                                       [excel_filename], html_filename)
    
   
    
    
if __name__=='__main__':
    main()