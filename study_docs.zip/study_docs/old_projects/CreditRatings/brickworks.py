# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 14:59:12 2022

@author: SalomeF
"""

#from html_table_parser.parser import HTMLTableParser
from collections import OrderedDict
import numpy as np
import pandas as pd
import re
from selenium import webdriver
import datetime
import time
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import openpyxl
import requests
import os
os.chdir("D:\\CreditRatings\\")
import email_utility

master_dir = "D:\\Master\\"
output_dir = "D:\\CreditRatings\\Output\\"
contacts_dir = "D:\\Emails\\Contacts\\"


brick_keywords = ['finance','bank','payment','payments','finserv','financial','nbfc','financier',
                          'financiers','banking','microfinance','mfi','loans', 'loan', 'capital', 'securities',
                          'fintech', 'insurance', 'fincorp']
action_keywords = {'UPGRADE':'UPGRADE','DOWNGRADE':'DOWNGRADE','REVISE':'REVISE','MIGRATE':'MIGRATE'}
brickworks_url = "https://www.brickworkratings.com/PressRelease.aspx"


_font_style = "calibri"
_header_style = "color:firebrick;font-weight: bold;font-family:{};font-size:10pt".format(_font_style)



def brickworks_rating_action(link, driver):

    # for i in df.Link:
    #     if '.pdf' not in i:
    #         print(i)
    #driver = webdriver.Chrome(os.path.join(master_dir,"chromedriver.exe"))
    #driver.get(link)
    # reset cookies
    driver.delete_all_cookies()
    driver.get(link)
    web_page = driver.page_source
    soup = BeautifulSoup(web_page,'html.parser')
    title = soup.find('p',class_="main_sub").text
    df_2 = pd.DataFrame()
    if 'assigns' not in title:
        
        table = soup.find_all('table',class_="table table-bordered bwrtable")[0]
        head = table.find_all('thead',class_="thead-light")
        body = table.find_all('tbody')
        
        for i in head:
            tr_h = i.find_all('tr')
            th_h = i.find_all('th')
        value=[]
        for td_no, data in enumerate(tr_h[0].find_all('th')): # check for colspan in the first row of header
          #  print ( data.get("colspan"))
            value.append(data.get("colspan")) # colspan value will be appended in value list
        a = len(tr_h) # number of rows in header
        b = len(tr_h[0].find_all('th')) # number of cols in 1st row of header
        
        val_key = [0 if x is None else x for x in value]  # convert None to 0 in value list
        val_key1= [int(x) for x in val_key] # convert rest str to int
        
        list1 = []
        for i in range(a):
            list1.append([]) # a no. of lists will be created in list1
            
        for j in range(b) :
           # print(i,j)
            
            for i in range(a):
                list1[i].append({tr_h[i].find_all('th')[j].text : val_key1[j] })
                    
        columns = []            
        list2 = []             
        for dicts in list1[1]:
            for k,v in dicts.items():
                list2.append(k)
                     
        for dicts in list1[0]:
            for key, value in dicts.items():
                # print(value)
                if value > 1:
                   # print(key)
                    for i in range(2):
                        columns.append(key + list2[0])
                        list2.pop(0)
                        list2
                    
                else:
                    columns.append(key)
                
        Facilities = ""
        list3 = [] ; count = 0
        list4=[]
        for t in body:
            tr_b= t.find_all('tr')
            for i in tr_b:
                td = i.find_all('td') 
                td_1 = i.find('td') # find 1st td in each tr
                r = td_1.get("rowspan")
#                print("td : ",td)
#                print("td_1 : ",td_1)
#                print(r)# find rowspan of td
                r1= 0 if r is None else int(r) 
                if r1 > 1:
                    Facilities = tr_b[0].find_all('td')[0].text
                    count = r1    
                if count >=1:
                    list4.append(Facilities) 
                    for j in range(len(td)):
                        list4.append(i.find_all('td')[j].text) 
                    count -=1
                else:
                    for j in range(len(td)):
                        list4.append(i.find_all('td')[j].text) 
                
                if len(list4)>len(columns):
                      list4.pop(0)                             
                      list3.append(list4)
                      list4=[]  
                else:
                    list3.append(list4)
                    list4=[] 
                
                    
        for i in list3:
            if "(" in i[1] or "(" in i[2]:
                #print(i[1],i[2])
                i.clear()
            if 'Grand Total' in i:
                i.clear()
                
            # for j in i:
            #     print(j)
            #     if "(" in j:
            #           #print(j)
            #           #list3.remove(i)
            #           i.clear()
                     
                     # print(x)
                     # list3.pop(x)
                     
        res = [ele for ele in list3 if ele != []]  
       
        df_1 = pd.DataFrame(res,columns=columns)
        # pandas df containing the data from the table in the link
    
#def brickworks_rating_action(df_1):
 
        l1=[]  ; l2=[]   
        for i in df_1['Facilities**']:
            l1.append(i.strip(' '))        
        for i in df_1['Tenure']:
            l2.append(i.strip(' '))
        
        res2 = [i + j for i, j in zip(l1, l2)]
        
        res3=[]
        for i in res2:
            res3.append(i+'Amt_Prev')
            res3.append(i+'Amt_Present')
            res3.append(i+'Rating_Prev')
            res3.append(i+'Rating_Present')
            
        res4 = [i.replace(' ','') for i in res3 ]
        res6 = [i.replace('\n\n',' ').replace('\n','_') for i in res4]
        print('len: res 6: ',len(res6))   
        
        newdf_1= df_1[df_1.columns[pd.Series(df_1.columns).str.contains("Rating")]]  
        newdf_2= df_1[df_1.columns[pd.Series(df_1.columns).str.contains("Amount")]]
        
        concat_1 = pd.concat([newdf_2, newdf_1],axis=1)
        
        row_df_2 =[]
        for m in range(len(concat_1)):
            for n,p in enumerate(concat_1):
                #print(m,n)
                #print(concat_1.iloc[m,n])
                row_df_2.append(concat_1.iloc[m,n])
                
        #row_strip2 = [i.replace('\n',' ').replace(' ','') for i in row]
        
        df_2 = pd.DataFrame(columns=res6) 
        df_2.loc[len(df_2.index)] = row_df_2
        
        #df_2 = pd.DataFrame(row_df_2, columns=res6)
        
        print('SHAPE :',df_2.shape)
        
    return df_2, driver
    


#abc = brickworks_rating_action('http://bcrisp.in///BLRHTML/HTMLDocument/ViewRatingRationaleReview?id=68563')


def brickworks_rating(starting_date):
    
    driver = webdriver.Chrome(os.path.join(master_dir,"chromedriver.exe"))
    driver.get(brickworks_url)
    time.sleep(5)
     #starting_date=datetime.date(2022,5,30)
    brick_starting_date = str(datetime.datetime.strptime(str(starting_date),"%Y-%m-%d" ).strftime("%Y-%m-%d"))
    
    starting_box = driver.find_element_by_class_name("col-md-8").find_element_by_tag_name("input")
    driver.execute_script('arguments[0].setAttribute("value", "%s")' % brick_starting_date, starting_box)
    
    ending_box = driver.find_element_by_id("ContentPlaceHolder1_txtToDate")
    driver.execute_script('arguments[0].setAttribute("value", "%s")' % brick_starting_date, ending_box)
    
    search_button = driver.find_element_by_id("ContentPlaceHolder1_btnSearch")
    search_button.click()
    time.sleep(10)
    
    # soup
    
    pg = driver.page_source
    soup = BeautifulSoup(pg,'lxml')
    ratings_table = soup.find('table',class_="table table-bordered table3",id="ContentPlaceHolder1_gvData")
    
    
    try:
        no_of_pages = int(len(soup.find('tr',class_="pagination-ys").find('tr').find_all('td')))
    except:
        no_of_pages = 1
        
    row_list=[]
    
    if no_of_pages>=1:
        
        for i in range(1,no_of_pages+1):
            
            if (i==1):   
                # tbody = ratings_table.find('tbody')                    # first page data extraction
               
                all_rows = ratings_table.find_all('tr')  # find all rows from the ratings_table
                
                for row in all_rows:
                    # row.select('tr:not(tr > table)')
                    all_columns = row.find_all('td')
                    if (len(all_columns)==3):           # if 3 <tds> in <tr>
                        
                        row_list.append([all_columns[1].text,all_columns[2].text,all_columns[2].find('a')['href']])
                       
                    elif (len(all_columns)==2):        # if 2 <tds> in <tr>
                        
                        row_list.append([all_columns[0].text,all_columns[1].text,all_columns[1].find('a')['href']])
                        
                      
            else:
                driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")
                driver.find_element_by_xpath("//tr[@class='pagination-ys']//tbody").find_element_by_link_text(str(i)).click()
                time.sleep(10)
                pg = driver.page_source
                soup = BeautifulSoup(pg,'lxml')
                ratings_table = soup.find('table',class_="table table-bordered table3",id="ContentPlaceHolder1_gvData")
                all_rows = ratings_table.find_all('tr')
                
                for row in all_rows:
                    all_columns = row.find_all('td')
                    if (len(all_columns)==3):
                        
                        try:
                            href = all_columns[2].find('a')['href']
                        except:None   
                        
                        row_list.append([all_columns[1].text,all_columns[2].text,href])
                        
                        
                        
                    elif (len(all_columns)==2):
                       
                        try:
                            href = all_columns[1].find('a')['href']
                        except:None 
                        row_list.append([all_columns[0].text, all_columns[1].text,href])
                                  
    
    df = pd.DataFrame(row_list, columns=['Company Name','Title','Link'])
    
    
    
    # import numpy as np
    # df["gender"] = np.where(df["gender"] == "female", 0, 1)
    # df["Link"] = np.where(df["Link"] == i, s, i)
    
    for i in df.Link:
        if '.pdf' in i:
            
            # print(i)
               
           s = 'https://www.brickworkratings.com/' + i
           # print(s)
           df['Link'].mask(df['Link'] == i, s, inplace=True)
           
           # df["Link"] = np.where(df["Link"] == i, s, i)
           # #df.loc[df["Link"] == "{}", "Link"] = 1
           # # df['Link'].replace({"{}": "{}"}, inplace=True)
           # # df["Link"].replace({"{}": "{}"}.format(i,x), inplace=True)
           
           # # df['Link'].replace({"{}":"{}"}.format(i,x))
          
           # df['Link'] = df['Link'].str.replace(i,s)
           
    
    
    pattern = "|".join(action_keywords.keys())    
    df['Rating'] = df['Title'].apply(lambda s: re.search(pattern=pattern, 
                      string=s, flags=re.IGNORECASE)).apply(lambda s: '' if s==None else action_keywords[s.group(0).upper()]) 
    
    def filter_rows_by_values(df, col, values):
        return df[~df[col].isin(values)]
    df = filter_rows_by_values(df, "Company Name", ["1"])
    df['rating temp'] = range(len(df))
    
    
    # df_3 = pd.DataFrame()
    # rating_actions_df = pd.DataFrame() 
    
    frames = []
    for _, row in df.iterrows():
        if '.pdf' not in row['Link']:
            
            #print(row['Link'])
            #print(f"{row['Link']}")
            try:
                table_2, driver = brickworks_rating_action(row['Link'], driver)
                time.sleep(1)
            except Exception as e:
                print("e : ",e)
                print("link : ",row['Link'])
                
            #table_2 = brickworks_rating_action(row['Link']) # df_2 for that particular link
            table_2['rating temp'] = row['rating temp']
            #rating_action_df.append(table_2)
            #df_3 = pd.concat([df_3, table_2], axis=0)
            print(table_2.shape)
            frames.append(table_2)
            
    result1 = pd.concat(frames)
            #rating_actions_df = rating_actions_df.append(table_2, ignore_index=True)
            #time.sleep(1)
    df = df.merge(result1, on=['rating temp'], how="left")
    df.drop("rating temp", axis=1, inplace=True)
    
    
    
    total_prev_df = df[df.columns[pd.Series(df.columns).str.contains("_Amt_Prev")]]
    total_pres_df = df[df.columns[pd.Series(df.columns).str.contains("_Amt_Present")]]
    total_prev_df = total_prev_df.replace(np.nan,0)
    total_pres_df = total_pres_df.replace(np.nan,0)
   
    a = len(total_prev_df.columns)
    b = len(total_pres_df.columns)
    
    
    Total_Prev =[]
    add = 0
    for _,r in total_prev_df.iterrows():  
         for i in range(a):
             #print(float(r[i]))
             add = add + float(r[i])
         Total_Prev.append(add)
         add=0
      
    Total_Present =[]
    add = 0
    for _,r in total_pres_df.iterrows():  
         for i in range(b):
             #print(float(r[i]))
             add = add + float(r[i])
         Total_Present.append(add)
         add=0
    

    df['Total_Previous']=  Total_Prev
    df['Total_Present'] = Total_Present
    
    df = df.replace('\n','', regex=True) 
    driver.quit()
    return df
  

def excel_writer( df_dicts, filename):
    '''
    appends data in multiple sheets
    '''
    writer = pd.ExcelWriter(output_dir+filename)
    pre_columns = ['Company Name','Rating','Title','Total_Previous','Total_Present']
    for key, table_df in df_dicts.items():
        table_df = table_df[ pre_columns + [col for col in table_df.columns if col not in pre_columns]]
        table_df.to_excel(writer,sheet_name = key, index=False )
    
    writer.save()
    writer.close()

    return output_dir+filename

# email part :
def html_file_format(outputpathfile, html_string):
        
        with open(outputpathfile,'w') as f:
            f.write(html_string)
    
        output_file = open(outputpathfile, 'r').read().replace("&lt;","<").replace("&gt;",">")
        output_file = output_file.replace("dataframe mystyle","mystyle")
        output_file = output_file.replace('<td>text','<td class="text">')
    
        with open(outputpathfile, 'w') as f:
            f.write(output_file)

def rating_into_html(Rating_Rationale_df, starting_date1):
    
    pre_columns = ['Company Name','Rating','Title','Total_Previous','Total_Present']
    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>
    html_string = "<html><head><style>{css_style}</style></head><body>".format(css_style = open(os.path.join(os.getcwd(), "df_style.css"), 'r').read())
    html_string += '<p style=\"{}\">Brickworks Ratings as on {}</p><br>'.format(
                "color:black;font-weight: bold;font-family:{};font-size:10pt".format(_font_style), starting_date1)        

    Rating_Rationale_df['Company Name'] = Rating_Rationale_df[['Company Name','Link']].apply(lambda x: 
                                            '<a href="{}">{}</a>'.format(x['Link'], x['Company Name']), axis=1) 
    Rating_Rationale_df.drop(columns=['Link'], inplace=True) 
    Rating_Rationale_df = Rating_Rationale_df[pre_columns + [col for col in Rating_Rationale_df.columns if col not in pre_columns]]
        
    result= Rating_Rationale_df.to_html(classes='mystyle', index=False).replace(
                                                    '<table border="1" class="dataframe mystyle">',
                                                    '<table border="1" class="mystyle">')
    html_string += "<table><tr><td valign='top'>{}</td></tr></table>".format(result)
    html_string += "<br><br></body></html>"
        
    html_file = os.path.join(output_dir, "brickworks_rating_{}.html".format(starting_date1))
    html_file_format(html_file, html_string)
    
    return html_file


def main(nd):
        
    d = datetime.datetime.now().date()-datetime.timedelta(days=nd)
    df = brickworks_rating(d)
    df.sort_values(by=['Total_Present'], inplace=True, ascending=False)
    df_dict = OrderedDict() # final data;     
    df_dict['all_data'] = df.copy(deep=True)
    df_dict['rating_changes'] = df[(df['Rating'].isin(action_keywords.keys()))]
    
    brick_starting_date = str(datetime.datetime.strptime(str(d),"%Y-%m-%d" ).strftime("%Y-%m-%d"))
    
    xfilename = excel_writer(df_dict, filename="bricks_output_{}.xlsx".format(brick_starting_date))
        
    rating_changes_df = df_dict['rating_changes'].copy(deep=True)   
    
    rating_changes_df = rating_changes_df.replace(np.nan, '', regex=True)
             
    html_filename = rating_into_html(rating_changes_df,d)
    
    # send email
    email_utility.process_status_email(os.path.join(contacts_dir, "credit_ratings.txt"), "Brickworks Ratings {}".format(d), 
        [xfilename], html_filename)
    
  
    
main(nd=0)