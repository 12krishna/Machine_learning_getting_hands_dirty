# -*- coding: utf-8 -*-
"""
Created on Thu Apr 21 16:15:27 2022

@author: backup
"""

import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

import sys
# import requests
from selenium import webdriver
import openpyxl
import requests
import re, os, datefinder, datetime, time
from bs4 import BeautifulSoup
from selenium import webdriver
import datetime
import time
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import openpyxl
import requests
import os
import pandas as pd
import logging

server = '172.17.9.144'; port = 25

contacts_dir = "D:\\Emails\\Contacts\\"
output_dir = "D:\\CreditRatings\\Output\\"
master_dir = "D:\\Data_dumpers\\Master\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
log_path='D:\\CreditRatings\\' 

logging.basicConfig(filename=log_path+"india_rating.log",filemode="w",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def email_utility(emails, subject,fname,filename):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
   # message = open(filename,'rb').read()
   
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    if filename!="":
      message = open(filename)
      part2 = MIMEText(message.read(), 'html')
      msg.attach(part2)                
    #msg.attach(MIMEText(message,'html'))
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(fname,'rb').read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
    msg.attach(part) 
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()


def html_file_format(outputpathfile, html_string):
        
        with open(outputpathfile,'w') as f:
            f.write(html_string)
    
        output_file = open(outputpathfile, 'r').read().replace("&lt;","<").replace("&gt;",">")
        output_file = output_file.replace("dataframe mystyle","mystyle")
        output_file = output_file.replace('<td>text','<td class="text">')
    
        with open(outputpathfile, 'w') as f:
            f.write(output_file)
        logging.info("html table generated")

def rating_into_html(nd,Rating_Rationale_df,fname):
    logging.info("generating html table")
    starting_date1= datetime.datetime.now().date() - datetime.timedelta(days=nd)
    _font_style = "calibri"

    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>
    html_string = "<html><head><style>{css_style}</style></head><body>".format(css_style = open(os.path.join("D:\\CreditRatings", "df_style.css"), 'r').read())
    html_string += '<p style=\"{}\">India Ratings as on {}</p><br>'.format(
                "color:black;font-weight: bold;font-family:{};font-size:10pt".format(_font_style), starting_date1)        

    Rating_Rationale_df['Company Name'] = Rating_Rationale_df[['Company Name','Rating Link']].apply(lambda x: 
                                            '<a href="{}">{}</a>'.format(x['Rating Link'], x['Company Name']), axis=1) 
    Rating_Rationale_df.drop(columns=['Rating Link'], inplace=True)
    Rating_Rationale_df=Rating_Rationale_df[['Company Name','Total']]
    Rating_Rationale_df.columns.name=''
    print(Rating_Rationale_df.columns)    
    result= Rating_Rationale_df.to_html(classes='mystyle', index=False).replace(
                                                    '<table border="1" class="dataframe mystyle">',
                                                    '<table border="1" class="mystyle">')
    html_string += "<table><tr><td valign='top'>{}</td></tr></table>".format(result)
    html_string += "<br><br></body></html>"
        
    html_file = os.path.join(output_dir, "india_rating_{}.html".format(starting_date1))
    html_file_format(html_file, html_string)
    email_utility(get_contacts(contacts_dir+'credit_ratings.txt'), "India Rating",fname, html_file)
    logging.info("email sent")

def india_rating(nd):
 Rating_keywords=["Migrates","Upgrades","Downgrades","Reassigns","Assigns","Affirms","Rates","Revises","Maintains","Withdraws"]   
 stop_keywords=["at","to","in"]
 action_keywords={'UPGRADE':'UPGRADE','DOWNGRADE':'DOWNGRADE','REVISE':'REVISE','MIGRATE':'MIGRATE'}
 crisil_keywords = ['finance','bank','payment','payments','finserv','financial','nbfc','financier',
                                  'financiers','banking','microfinance','mfi','loans', 'loan', 'capital', 'securities',
                                  'fintech', 'insurance', 'fincorp']     
 #os.chdir("D:\Data_dumpers\CM_FO\credit ratings")
 starting_date1= datetime.datetime.now().date() - datetime.timedelta(days=nd)
 inrating_date = datetime.datetime.strptime(str(starting_date1),"%Y-%m-%d" ).strftime("%d %b %Y")
 
 chrome_options = webdriver.ChromeOptions()
 chrome_options.add_argument('--headless')
 chrome_options.add_argument('--no-sandbox')
 chrome_options.add_argument('--disable-dev-shm-usage') 
  

 def page_data():
    final_df=pd.DataFrame()
    table=soup.find('table',{'class':'table'})
    rows=table.find_all("tr")
    global newdf
  #  print(rows)
  #  count=1
    for row in rows:
       date=row.find('span',{"class":"effect-date"}).text
       if date==inrating_date: 
            cname=row.find('a',{"class":"blackcolor"}).text
            print(cname)
            try:
                cname=cname.replace("  "," ")
                cname=cname.strip()
                r=driver.find_element_by_link_text(cname)                   
                r.click()            
                window_after = driver.window_handles[1]
                driver.switch_to.window(window_after)
                time.sleep(10)
                print(driver.current_url)
                try:
                    driver.get(driver.current_url)
                    time.sleep(5)
                    html=driver.page_source
                    print("read html")
                    tables = pd.read_html(html)
                    data=tables[0]
                    print(data)               
                    data.columns=data.iloc[0]
                   # if data.columns[-1]=='Rating Action':
                    if 'Action' in data.columns[-1]:    
                        data=data.iloc[:,:-1]
                        data=data[1:]
                        data=data.iloc[:,[0,-2,-1]]
                        g=data.groupby(data.columns[0])
                        data[data.columns[0]]+=g.cumcount().add(1).astype(str).radd('_').mask(g[data.columns[0]].transform('count')==1,'')
                        cols=data.columns
                        for c in cols:
                           if "Rating" in c:
                              data.rename({c:"Rating"},axis=1,inplace=True)
                           if "Issue" in c or "Principal" in c or "Outstanding" in c:
                              data[c]=data[c].fillna("INR0")
                              data[c]=data[c].replace("-","INR0")
                              if any(data[c].str.contains("INR")):
                                data[c]=data[c].apply(lambda x: x.split("INR")[1]) 
                              try:
                                data[c]=data[c].apply(lambda x: x.split('(')[0])
                                data[c]=data[c].str.replace(',', '')
                              except Exception as e:
                                print(e)  
                           if "million" in c:
                               try:
                                 data[c]=data[c].apply(lambda x: float(x)*0.1)
                               except Exception as e:
                                   print(e)
                           if "billion" in c:
                               try:
                                 data[c]=data[c].apply(lambda x: float(x)*100)
                               except Exception as e:
                                   print(e)
                        data=data.reset_index() 
                        data.drop(["index"],axis=1,inplace=True)        
                        newdf=data.iloc[:,0:2]  
                        newdf=newdf.T      
                        newdf.columns=newdf.iloc[0]  
                        newdf=newdf[1:]   
                        newdf=newdf.reset_index()
                        newdf.drop([0],axis=1,inplace=True) 
                        newdf["Total"]=newdf.sum(axis=1)
                        newdf["Total"]=newdf["Total"].apply(lambda x:round(x,2))
                        for c in newdf.columns[:-1]: 
                           newdf[c]=newdf[c].apply(lambda x:f'Rs. {x} Crore')
                        for i in range(len(data[data.columns[0]])):
                           newdf["{}_{}".format(data[data.columns[0]][i],data.columns[2])]=data[data.columns[2]][i]
                        newdf["cname"]=cname
                        if "’" in cname: 
                          cname=cname.split("’")[0] 
                        if " and " in cname:
                           ke=cname.split(" and ")[1].split(" ")[0]
                           if ke in Rating_keywords:
                             cname=cname.split(ke)[1]
                           else:
                             for i in cname.split(" "):
                               if i in Rating_keywords:
                                cname=cname.split(i)[1]
                                break
                        else:        
                          for i in cname.split(" "):
                            if i in Rating_keywords:
                             cname=cname.split(i)[1]
                             break                     
                        for i in cname.split(" "):
                            if i in stop_keywords:
                              cname=cname.split(" {} ".format(i))[0]
                              break    
                        newdf["Company Name"]=cname        
                       # newdf["Company Name"]=' '.join(cname.split(' ')[3:]) 
                        newdf["Rating Link"]=driver.current_url 
                        driver.close()
                        time.sleep(2)
                    else:
                        driver.close()
                        time.sleep(2)
                        driver.switch_to.window(window_before)
                       # count+=1  
                        continue
                except Exception as e:
                    print(e) 
                    driver.close()
                    time.sleep(2)
                    driver.switch_to.window(window_before)
                    continue
            except Exception as e:
              print(e)                    
              time.sleep(2)
              continue
            driver.switch_to.window(window_before)
            final_df=pd.concat([final_df,newdf])
            print("done")                     
       #else:
       #     break
      # driver.switch_to.window(window_before)
      # final_df=pd.concat([final_df,newdf])
      # print("done") 
    return final_df
 driver = webdriver.Chrome(os.path.join(master_dir, 'chromedriver'))#,options=chrome_options)
 time.sleep(1)
 url_list=["https://www.indiaratings.co.in/listing/rac/sector/Corporates",
           "https://www.indiaratings.co.in/listing/rac/sector/Financial%20Institutions",
           "https://www.indiaratings.co.in/listing/rac/sector/Infrastructure",
           "https://www.indiaratings.co.in/listing/rac/sector/Public%20Finance",
           "https://www.indiaratings.co.in/listing/rac/sector/Structured%20Finance"]
# indirating_url="https://www.indiaratings.co.in/listing/rac/sector/Corporates"
 fdf=pd.DataFrame()
 for url in url_list:
     logging.info("starting process for {}".format(url))
     driver.get(url)
     window_before = driver.window_handles[0]
     time.sleep(10)     
     pg = driver.page_source
     soup = BeautifulSoup(pg,'html.parser')  
     x=page_data()
   #  driver.quit()
    # while True:
 
   #  driver = webdriver.Chrome('D:\\Data_dumpers\\Master\\chromedriver')#,options=chrome_options)
    # time.sleep(1)
    # indirating_url="https://www.indiaratings.co.in/listing/rac/sector/Corporates"
    # driver.get(url)
     window_before = driver.window_handles[0]
     time.sleep(10) 
     while True:
       time.sleep(60)  
       n=driver.find_element_by_class_name("pagination-next")
       n.click()
       time.sleep(5)
       pg = driver.page_source
       soup = BeautifulSoup(pg,'html.parser')
       table=soup.find('table',{'class':'table'})
       rows=table.find_all("tr")
       print(rows[0]) 
       date=rows[0].find('span',{"class":"effect-date"}).text
       if date==inrating_date:
              print(date) 
              y=page_data()
              x=pd.concat([x,y])            
       else:
             print('no matching date')
             break  
     fdf=pd.concat([fdf,x])                                 
 driver.quit()       
 fdf['Rating Rationale Title']=''
 try:
  for j in fdf["cname"]:
      for ke in action_keywords:
          if ke.title() in j:
              print(ke)
              fdf['Rating Rationale Title'][fdf['cname']==j]=ke
            
      for ke in crisil_keywords:
          if ke.title() in j:
              print(ke)
              fdf['Rating Rationale Title'][fdf['cname']==j]=ke
            
  fdf.drop(['cname'],axis=1,inplace=True)            
  inserted_cols = ['Company Name','Rating Link','Total','Rating Rationale Title']
  cols = ([col for col in inserted_cols if col in fdf] 
            + [col for col in fdf if col not in inserted_cols])
  fdf =fdf[cols]
  fdf.sort_values(by=['Total'], inplace=True, ascending=False)
  fdf['Total'] = fdf['Total'].apply(lambda s: f"Rs. {s} Crore")
  fdf = fdf[fdf['Rating Rationale Title']!=''].append(fdf[fdf['Rating Rationale Title']==''])    
  Rating_Rationale_df=fdf[fdf['Rating Rationale Title']!=""]
  if Rating_Rationale_df.shape[0]!=0:
       Rating_Rationale_df=Rating_Rationale_df[Rating_Rationale_df['Rating Rationale Title'].isin(crisil_keywords)].append(Rating_Rationale_df[Rating_Rationale_df['Rating Rationale Title'].isin(action_keywords.keys())])
       Rating_Rationale_df=Rating_Rationale_df.dropna(axis='columns', how='all')
       Rating_Rationale_df.fillna("",inplace=True)             
       writer=pd.ExcelWriter(os.path.join(output_dir,"india_rating_{}.xlsx".format(starting_date1)),engine='xlsxwriter')    
       fdf.to_excel(writer,sheet_name="all_data",index=False)
       logging.info("data saved in excel file") 
       Rating_Rationale_df.to_excel(writer,sheet_name='Rating',index=False)
       writer.save()
       rating_into_html(nd,Rating_Rationale_df,os.path.join(output_dir,"india_rating_{}.xlsx".format(starting_date1)))
  else:
        print("No keyword matching for rating")       
        writer=pd.ExcelWriter(os.path.join(output_dir,"india_rating_{}.xlsx".format(starting_date1)),engine='xlsxwriter')    
        fdf.to_excel(writer,sheet_name="all_data",index=False) 
        logging.info("saved data in excel file")
        writer.save()
        email_utility(get_contacts(contacts_dir+'credit_ratings.txt'), "India Rating",
                      os.path.join(output_dir,"india_rating_{}.xlsx".format(starting_date1)),filename="")
        logging.info("email sent")
 except Exception as e:
        print(e)
        logging.info(e)
      
india_rating(0) 
