# -*- coding: utf-8 -*-
"""
Created on Wed May 11 16:02:50 2022

@author: SalomeF
"""
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import logging
from collections import OrderedDict
import numpy as np, pandas as pd, re
from tabula import read_pdf
import urllib.request
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait 
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import pandas as pd
from selenium import webdriver
import datetime
import time
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import openpyxl
import requests
import os
#from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
#from selenium.webdriver.common.by import By

os.chdir("D:\\CreditRatings\\")
contacts_dir = "D:\\Emails\\Contacts\\"
output_dir = "D:\\CreditRatings\\Output\\"
master_dir = "D:\\Data_dumpers\\Master\\"

#os.environ['HTTP_PROXY']="http://IBIE%5Csalomef:Pass%40123@172.17.9.170:8080"
#os.environ['HTTPS_PROXY']="http://IBIE%5Csalomef:Pass%40123@172.17.9.170:8080"

icra_url = "https://www.icra.in/Rationale/Index"
action_keywords = {'UPGRADE':'UPGRADE','DOWNGRADE':'DOWNGRADE','REVISE':'REVISE','MIGRATE':'MIGRATE'}
#output_dir = "C:\\Users\\backup\\"
server = '172.17.9.144'; port = 25
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
log_path='D:\\CreditRatings\\' 

logging.basicConfig(filename=log_path+"Icra.log",filemode="w",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def email_utility(emails, subject, fname,filename):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
   # message = open(filename,'rb').read()
   
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    
    message = open(filename)
    part2 = MIMEText(message.read(), 'html')
    msg.attach(part2)                
    #msg.attach(MIMEText(message,'html'))

    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(os.path.join(output_dir,fname),'rb').read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
    msg.attach(part) 
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def excel_writer( df_dicts, filename):
    '''
    appends data in multiple sheets
    '''
    writer = pd.ExcelWriter(output_dir+filename)
    
    for key, value in df_dicts.items():
        value.to_excel(writer,sheet_name = key, index=False )
    
    writer.save()
    writer.close()


def icra_rating(nd):
    
    driver = webdriver.Chrome(os.path.join(master_dir, "chromedriver.exe"))
    driver.get(icra_url)
    time.sleep(10)
    
    starting_date = datetime.datetime.now().date()-datetime.timedelta(days=nd)
    icra_date = str(datetime.datetime.strptime(str(starting_date),"%Y-%m-%d" ).strftime("%d %b %Y"))
    
    starting_box = driver.find_element_by_id("FromDate")
    starting_box.clear() ; time.sleep(1)
    starting_box.send_keys(icra_date, Keys.ENTER)
    
    ending_box = driver.find_element_by_id("ToDate")
    ending_box.clear() ; time.sleep(1)
    ending_box.send_keys(icra_date, Keys.ENTER)
    
    search_button = driver.find_element_by_id("btnSearch")
    search_button.click()
    
    time.sleep(10)
    pg = driver.page_source
    soup = BeautifulSoup(pg,'lxml')
    
    try:
        next_pg = soup.find('div',class_="pagination")
        li = next_pg.find_all('li')
        no_of_pages = len(li) - 1
        
    except :
        no_of_pages = 1
    
    row_list=[]
    
    if no_of_pages>=1:
        for i in range(1,no_of_pages+1):
            
            if (i==1):   
                a = soup.find_all('div',class_="list-nw")
                for i in a:
                
                     j=i.find_all('p')[2].text.replace(" – ",":")            
                    
                     row_list.append([i.find('p').text, j.split(':')[1], 
                                     'https://www.icra.in/' + i.find_all('p')[3].find('a')['href'],
                                     i.find_all('p')[3].find('span').text.replace('/','').strip(' ')])
    
            else:
                WebDriverWait(driver, 60).until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".PagedList-skipToNext")))
                next_pg_button=driver.find_element(by=By.CSS_SELECTOR, value=".PagedList-skipToNext")
                next_pg_button.click()
                time.sleep(10)
                
                pg = driver.page_source
                soup = BeautifulSoup(pg,'lxml')
                
                a = soup.find_all('div',class_="list-nw")
                
                for i in a:
                    j=i.find_all('p')[2].text.replace(" – ",":")  
                    row_list.append([i.find('p').text,j.split(':')[1], 
                                    'https://www.icra.in/' + i.find_all('p')[3].find('a')['href'],
                                    i.find_all('p')[3].find('span').text.replace('/','').strip(' ')])
                    
    
    df = pd.DataFrame(row_list, columns=['Company Name','Title','Link','Date'])     # main dataframe with 4 columns  

    pattern = "|".join(action_keywords.keys())    
    df['Rating'] = df['Title'].apply(lambda s: re.search(pattern=pattern, 
                      string=s, flags=re.IGNORECASE)).apply(lambda s: '' if s==None else action_keywords[s.group(0).upper()]) 
    driver.quit()         
    return df



    
    
# =============================================================================
# df = icra_rating(nd)
# df_dict = OrderedDict() # final data;
# df_dict['all_data'] = df.copy(deep=True)
# df_dict['rating_changes'] = df[(df['Rating'].isin(action_keywords.keys()))]
# =============================================================================
    
#starting_date = datetime.datetime.now().date()-datetime.timedelta(days=nd)
#icra_starting_date = str(datetime.datetime.strptime(str(starting_date),"%Y-%m-%d" ).strftime("%Y-%m-%d"))

#excel_writer(df_dict, filename="icra_output_{}.xlsx".format(icra_starting_date))





# email part :
def html_file_format(outputpathfile, html_string):
        
        with open(outputpathfile,'w') as f:
            f.write(html_string)
    
        output_file = open(outputpathfile, 'r').read().replace("&lt;","<").replace("&gt;",">")
        output_file = output_file.replace("dataframe mystyle","mystyle")
        output_file = output_file.replace('<td>text','<td class="text">')
    
        with open(outputpathfile, 'w') as f:
            f.write(output_file)
        logging.info("html table generated")     

def rating_into_html(nd):
    df = icra_rating(nd)
    df_dict = OrderedDict() # final data;
    df_dict['all_data'] = df.copy(deep=True)
    df_dict['rating_changes'] = df[(df['Rating'].isin(action_keywords.keys()))]
    
    rating_changes_df = df_dict['rating_changes'].copy(deep=True)  
    rating_changes_df = rating_changes_df.replace(np.nan, '', regex=True)
    
    starting_date = datetime.datetime.now().date()-datetime.timedelta(days=nd)
    icra_starting_date = str(datetime.datetime.strptime(str(starting_date),"%Y-%m-%d" ).strftime("%Y-%m-%d"))

    excel_writer(df_dict, filename="icra_output_{}.xlsx".format(icra_starting_date))
    logging.info("data saved in excel")
    starting_date1= datetime.datetime.now().date() - datetime.timedelta(days=nd)
    _font_style = "calibri"
    logging.info("generating html table")
    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>
    html_string = "<html><head><style>{css_style}</style></head><body>".format(css_style = open(os.path.join("D:\\CreditRatings", "df_style.css"), 'r').read())
    html_string += '<p style=\"{}\">Icra Ratings as on {}</p><br>'.format(
                "color:black;font-weight: bold;font-family:{};font-size:10pt".format(_font_style), starting_date1)        

    rating_changes_df['Company Name'] =  rating_changes_df[['Company Name','Link']].apply(lambda x: 
                                            '<a href="{}">{}</a>'.format(x['Link'], x['Company Name']), axis=1) 
    rating_changes_df.drop(columns=['Link'], inplace=True)
    rating_changes_df=rating_changes_df[["Company Name","Title","Rating"]]     
    result=  rating_changes_df.to_html(classes='mystyle', index=False).replace(
                                                    '<table border="1" class="dataframe mystyle">',
                                                    '<table border="1" class="mystyle">')
    html_string += "<table><tr><td valign='top'>{}</td></tr></table>".format(result)
    html_string += "<br><br></body></html>"
        
    html_file =os.path.join(output_dir, "icra_rating_{}.html".format(starting_date1))
    html_file_format(html_file, html_string)
    
   # return html_file, os.path.join(output_dir, "icra_output_{}.xlsx".format(icra_starting_date))
    email_utility(get_contacts(contacts_dir+"credit_ratings.txt"), "Icra_Rating", "icra_output_{}.xlsx".format(icra_starting_date),html_file)
    logging.info("email sent")
    

#rating_changes_df = df_dict['rating_changes'].copy(deep=True)  

#rating_changes_df = rating_changes_df.replace(np.nan, '', regex=True)
         
rating_into_html(0)
