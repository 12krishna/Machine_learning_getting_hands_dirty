# -*- coding: utf-8 -*-
"""
Created on Tue Aug  2 15:15:43 2022

@author: SalomeF
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 19:58:52 2022

@author: krishna
"""

import sys
# import requests
from selenium import webdriver
import openpyxl
import requests
import re, os, datefinder, datetime, time
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import logging

#from selenium.common.exceptions import TimeoutException
import pandas as pd
from collections import OrderedDict
#from selenium.webdriver.common.action_chains import ActionChains

os.chdir("D:\\CreditRatings\\")
import email_utility
master_dir = "D:\\Master\\"
output_dir = "D:\\CreditRatings\\Output\\"
contacts_dir = "D:\\Emails\\Contacts\\"

log_path='D:\\CreditRatings\\' 

logging.basicConfig(filename=log_path+"care.log",filemode="w",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


_font_style = "calibri"
_header_style = "color:firebrick;font-weight: bold;font-family:{};font-size:10pt".format(_font_style)

class WebScrapper():
    '''
    implements credit ratings alerts
    from various rating websites
    '''

    def __init__(self):
        
        self._care_url = "https://www.careratings.com/issuer-and-related-insights.aspx"
        self.driver = self.set_proxy_details()
        self.action_keywords = {'UPGRADE':'UPGRADE','DOWNGRADE':'DOWNGRADE','REVISE':'REVISE','MIGRATE':'MIGRATE'}
        self.sector_keywords = ['finance','bank','payment','payments','finserv','financial','nbfc','financier',
                                  'financiers','banking','microfinance','mfi','loans', 'loan', 'capital', 'securities',
                                  'fintech', 'insurance', 'fincorp']

    def set_proxy_details(self):
        '''Func to set proxy for driver'''

        opts = Options()
        # Add headers
        user_agent =  ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) '
                       'AppleWebKit/537.36 (KHTML, like Gecko) '
                       'Chrome/39.0.2171.95 Safari/537.36')
        opts.add_argument(f'user-agent={user_agent}')
        # Remove the Automation Info
        opts.add_argument('--disable-infobars')
        #opts.add_argument("headless")
        opts.add_argument('--disable-gpu')
        opts.add_argument("--log-level=3")  # fatal
        #opts.add_argument('--blink-settings=imagesEnabled=false')
        #opts.add_argument('--no-sandbox')
        #opts.add_argument('--disable-dev-shm-usage')
        
        
        driver = webdriver.Chrome(master_dir+"chromedriver.exe", chrome_options=opts)
        driver.set_page_load_timeout(30)

        #driver.minimize_window()
        print ("Proxy details set for the session")
        return driver
        
    def flattern(self, A):
        rt = []
        for i in A:
            if isinstance(i,list): rt.extend(self.flattern(i))
            else: rt.append(i)
        return rt
    
    def excel_writer(self, df_dicts, filename):
        '''
        appends data in multiple sheets
        '''
        writer = pd.ExcelWriter(output_dir+filename)
        
        for key, value in df_dicts.items():
            value.to_excel(writer,sheet_name = key, index=False )
        
        writer.save()
        writer.close()
   
    
    def html_file_format(self, outputpathfile, html_string):
        
        with open(outputpathfile,'w') as f:
            f.write(html_string)
    
        output_file = open(outputpathfile, 'r').read().replace("&lt;","<").replace("&gt;",">")
        output_file = output_file.replace("dataframe mystyle","mystyle")
        output_file = output_file.replace('<td>text','<td class="text">')
    
        with open(outputpathfile, 'w') as f:
            f.write(output_file)
        
        logging.info("html table generated")
        
    def login_to_care(self, sdate):
        
        care_starting_date = datetime.datetime.strptime(str(sdate),"%Y-%m-%d" ).strftime("%m/%d/%Y")

        self.driver.get(self._care_url)
        time.sleep(2)
        # enter starting date
        
        start_date = self.driver.find_element_by_xpath("//input[@placeholder='Select Date From']")
        start_date.click()
        start_date.send_keys(Keys.CONTROL, "a")
        start_date.send_keys(Keys.BACKSPACE)
        start_date.send_keys(str(care_starting_date))
        logging.info("enter start date {}".format(care_starting_date))

        # enter ending date
        end_date = self.driver.find_element_by_xpath("//input[@placeholder='Select Date To']")
        end_date.click()
        end_date.send_keys(Keys.CONTROL, "a")
        end_date.send_keys(Keys.BACKSPACE)
        end_date.send_keys(str(care_starting_date))
        logging.info("enter end date {}".format(care_starting_date))
        # enter captcha
        captcha_code_box = self.driver.find_element_by_class_name("side-menu-inner").find_element_by_id("captcha")
        captcha_code = str(captcha_code_box.get_attribute('value'))
        print(captcha_code)
        logging.info("enter captcha {}".format(captcha_code))
        time.sleep(2)
        captcha_box = self.driver.find_element_by_class_name("side-menu-inner").find_element_by_id("txtImg")
        captcha_box.click()
        captcha_box.send_keys(Keys.CONTROL, "a")
        captcha_box.send_keys(Keys.BACKSPACE)
        captcha_box.send_keys(captcha_code)
        self.driver.find_element_by_id("lnkbtnSearch").click() # click on search button to get all records
        time.sleep(4)
        
        return
       
    def rating_into_html(self, starting_date1,rating_df):
        '''Func to create html email body'''
        logging.info("generating html table")
        _font_style = "calibri"
        
        pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>
        html_string = "<html><head><style>{css_style}</style></head><body>".format(css_style = open(os.path.join("D:\\CreditRatings", "df_style.css"), 'r').read())
        html_string += '<p style=\"{}\">Care edge Ratings as on {}</p><br>'.format(
                    "color:black;font-weight: bold;font-family:{};font-size:10pt".format(_font_style), starting_date1)        
        
        rating_df['Company Name'] = rating_df[['Company Name','Rating Link']].apply(lambda x: 
                                                '<a href="{}">{}</a>'.format(x['Rating Link'], x['Company Name']), axis=1) 
        rating_df.drop(columns=['Rating Link'], inplace=True)
        
        
        rating_df['PDF_LINK'] = 'PDF LINK'
        rating_df['PDF_LINK'] = rating_df[['PDF_LINK','PDF Link']].apply(lambda x:
                                                '<a href="{}">{}</a>'.format(x['PDF Link'], x['PDF_LINK']), axis=1)
            
        rating_df.drop(columns=['PDF Link'], inplace=True)
        
        rating_df=rating_df[['Company Name','Total','PDF_LINK']]             
        result= rating_df.to_html(classes='mystyle', index=False).replace(
                                                    '<table border="1" class="dataframe mystyle">',
                                                    '<table border="1" class="mystyle">')
        html_string += "<table><tr><td valign='top'>{}</td></tr></table>".format(result)
        html_string += "<br><br></body></html>"
            
        html_file = os.path.join(output_dir, "care_{}.html".format(starting_date1))
        self.html_file_format(html_file, html_string)
    
    
    
    def care_ratings(self, sdate):
        '''
        Func to get ratings from CARE
        '''
        # login to care ratings
        self.login_to_care(sdate)
        pg = self.driver.page_source
        soup = BeautifulSoup(pg,'lxml')
        total_pages = soup.find('center').find_all("li")
        no_of_pages = 0
        for page in total_pages:
            no_of_pages+=1
        finaldf=pd.DataFrame()
        if (no_of_pages >=3):
            for j in range(0,no_of_pages-2):
                page_button = self.driver.find_element_by_id("dlPaging_liClass_" + str(j))
                page_button.click()
                time.sleep(4)
                pg = self.driver.page_source
                final_soup = BeautifulSoup(pg,'lxml')
                all_companies = final_soup.find('div',class_='tab-pane fade show active',id='ratings').find_all('div',class_="press-release-list ext-pdf")
            
                for i in all_companies:
                    # df=pd.DataFrame()
                    cname= i.find('h4').text
                    logging.info("company name: {}".format(cname))
                    clink = "https://www.careratings.com/" + i.find('a')['href']
                    hl=requests.get(clink).content 
                    soupd=BeautifulSoup(hl,'lxml')
                    plink="https://www.careratings.com/"+soupd.find('div',id='pressRelease').find_all("a")[0]['href']
                    print(plink)
                    df_list=pd.read_html(hl)
                    mydf=df_list[0]
                    g=mydf.groupby(mydf.columns[0])
                    mydf[mydf.columns[0]]+=g.cumcount().add(1).astype(str).radd('_').mask(g[mydf.columns[0]].transform('count')==1,'')
                    newdf=mydf.iloc[:,0:2]
                    newdf=newdf.T
                    newdf.columns=newdf.iloc[0]
                    newdf=newdf[1:]
                    newdf=newdf.reset_index()
                    newdf.drop(["index"],axis=1,inplace=True)                             
                    for j in newdf.columns:
                        newdf[j]=newdf[j]/10
                    newdf["Total"]=newdf.sum(axis=1)
                    newdf["Total"]=newdf["Total"].apply(lambda x:round(x,2)) 
                    for j in newdf.columns[:-1]:               
                      newdf[j] = newdf[j].apply(lambda s: f"Rs. {s} Crore")
                      #  newdf[j].astype(float).round(2)        
                    for i in range(len(mydf[mydf.columns[0]])):
                        newdf["{}_{}".format(mydf[mydf.columns[0]][i],mydf.columns[2])]=mydf[mydf.columns[2]][i]     
                    newdf["Rating Link"]=clink
                    newdf["Company Name"]=cname
                    newdf["PDF Link"]=plink
                    print(clink)
                    print(newdf)
                    finaldf=pd.concat([finaldf,newdf])
                    
        finaldf['Rating']=""        
        for j in finaldf["Company Name"]:   
            for ke in self.sector_keywords:
                if ke in j.lower():
                    print(ke)
                    finaldf['Rating'][finaldf['Company Name']==j]=ke
        
        inserted_cols = ['Company Name','PDF Link','Rating Link','Total','Rating']
        cols = ([col for col in inserted_cols if col in finaldf] 
                    + [col for col in finaldf if col not in inserted_cols])
        finaldf =finaldf[cols]
        finaldf.sort_values(by=['Total'], inplace=True, ascending=False)
        finaldf['Total'] = finaldf['Total'].apply(lambda s: f"Rs. {s} Crore")
        finaldf = finaldf[finaldf['Rating']!=''].append(finaldf[finaldf['Rating']==''])
        finaldf.drop_duplicates(keep='first', inplace=True)
        rating_df=finaldf[finaldf['Rating']!=""]
        #if rating_df.shape[0]!=0:
        rating_df=rating_df.dropna(axis='columns', how='all')
        rating_df.fillna("",inplace=True)
       # rating_df.drop(['Rating'],axis=1,inplace=True)
       # finaldf.drop(['Rating'],axis=1,inplace=True)
        writer=pd.ExcelWriter(os.path.join(output_dir,"care_rating_{}.xlsx".format(sdate)),engine='xlsxwriter')    
        finaldf.to_excel(writer,sheet_name="all_data",index=False)   
        rating_df.to_excel(writer,sheet_name='Rating',index=False)
        writer.save()
        logging.info("excel file created")
        self.rating_into_html(sdate,finaldf)
        return os.path.join(output_dir, "care_{}.html".format(sdate)), \
                os.path.join(output_dir,"care_rating_{}.xlsx".format(sdate))
# =============================================================================
#         else:
#             print("No keyword matching for rating")
#             finaldf.drop(['Rating'],axis=1,inplace=True)
#             writer=pd.ExcelWriter(os.path.join(output_dir,"care_rating_{}.xlsx".format(sdate)),engine='xlsxwriter')    
#             finaldf.to_excel(writer,sheet_name="all_data",index=False)   
#             writer.save()
#             
#             with open(os.path.join(output_dir, "care_{}.html".format(sdate)),'w') as f:
#                 f.write("<html><body></body></html>")
#             
#             return os.path.join(output_dir, "care_{}.html".format(sdate)), \
#                     os.path.join(output_dir,"care_rating_{}.xlsx".format(sdate))
# =============================================================================

        
        
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date
      


def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
    
    # read holiday master
    holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                     date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)        
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))     
        return -1
    
    
def main(nd):
    
    d = datetime.datetime.now().date()-datetime.timedelta(days=nd)
    #if process_run_check(d) == -1:
    #    print('Exit: Its an holiday.')
    #    return -1	 
    
    crawler_obj = WebScrapper()
    try:
        # get care ratings
        html_filename, excel_filename = crawler_obj.care_ratings(d)
        #crawler_obj.driver.close()
        crawler_obj.driver.quit()
    except Exception as e:
        print(e)
        logging.info("error {}".format(e))
        crawler_obj.driver.quit()
    # send email
    email_utility.process_status_email(os.path.join(contacts_dir, "credit_ratings.txt"), "Care Ratings {}".format(d), 
                                       [excel_filename], html_filename)
    logging.info("email sent")
    
   #"credit_ratings.txt"
        
if __name__=='__main__':
    main(0)