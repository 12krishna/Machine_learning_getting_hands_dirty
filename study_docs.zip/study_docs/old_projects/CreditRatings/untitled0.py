# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 17:54:50 2022

@author: Administrator
"""

!apt-get update
!apt install chromium-chromedriver
!cp /usr/lib/chromium-browser/chromedriver/usr/bin
!pip install selenium
import sys
sys.path.insert(0,'/usr/lib/chromium-browser/chromedriver')
!pip install datefinder
#!pip uninstall chromedriver_binary
#!pip install chromedriver-binary==95.0.4638.69

from selenium import webdriver
import datetime
import time
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import openpyxl
import requests
import os

output_workbook = openpyxl.Workbook()
all_data = output_workbook.create_sheet("all_data")
greater_than_50 = output_workbook.create_sheet("greater_than_50")
greater_than_250 = output_workbook.create_sheet("greater_than_250")
output_workbook.save("care_ratings.xlsx") 

all_data.cell(row=1,column=1).value = "Company Name"
all_data.cell(row=1,column=2).value = "Industry"
all_data.cell(row=1,column=3).value = "Date"
all_data.cell(row=1,column=4).value = "HTML Link"
all_data.cell(row=1,column=5).value = "PDF Link"
all_data.cell(row=1,column=6).value = "Rated Amount"
starting_date = input("Enter the date in DDMM format")
year = datetime.datetime.today().year
starting_date1=datetime.date(year, int(starting_date[2:]),int(starting_date[0:2] ))

care_starting_date = datetime.datetime.strptime(str(starting_date1),"%Y-%m-%d" ).strftime("%m/%d/%Y")

fchrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')
driver = webdriver.Chrome('chromedriver', options=chrome_options)
time.sleep(1)
care_rating_url = "https://www.careratings.com/issuer-and-related-insights.aspx"
driver.get(care_rating_url)
time.sleep(1.5)


starting_box = driver.find_element_by_class_name("side-menu-inner").find_element_by_tag_name("input")
starting_box.click()
starting_box.send_keys(Keys.CONTROL, "a")
starting_box.send_keys(Keys.BACKSPACE)

starting_box.send_keys(str(care_starting_date))

captcha_code_box = driver.find_element_by_class_name("side-menu-inner").find_element_by_id("captcha")
captcha_code = str(captcha_code_box.get_attribute('value'))
print(captcha_code)
time.sleep(1)
captcha_box = driver.find_element_by_class_name("side-menu-inner").find_element_by_id("txtImg")
captcha_box.click()
captcha_box.send_keys(Keys.CONTROL, "a")
captcha_box.send_keys(Keys.BACKSPACE)
captcha_box.send_keys(captcha_code)
search_button = driver.find_element_by_id("lnkbtnSearch")
search_button.click()
time.sleep(4)
pg = driver.page_source
soup = BeautifulSoup(pg,'lxml')
total_pages = soup.find('center').find_all("li")
no_of_pages = 0
for page in total_pages:
    no_of_pages+=1
row_tracker =2
if (no_of_pages >=3):
    for j in range(0,no_of_pages-2):
        page_button = driver.find_element_by_id("dlPaging_liClass_" + str(j))
        page_button.click()
        time.sleep(4)
        pg = driver.page_source
        final_soup = BeautifulSoup(pg,'lxml')
        all_companies = final_soup.find('div',class_='tab-pane fade show active',id='ratings').find_all('div',class_="press-release-list ext-pdf")
        
        for i in all_companies:
            all_data.cell(row=row_tracker,column=1).value = i.find('h4').text
            all_data.cell(row=row_tracker,column=2).value = i.find('div',class_='content').find('p').text
            all_data.cell(row=row_tracker,column=3).value = i.find('p',class_='date').text.replace(" ","").replace("\n","").replace('\t','')
            all_data.cell(row=row_tracker,column=4).value = "https://www.careratings.com/" + i.find('a')['href']
            all_data.cell(row=row_tracker,column=5).value = "https://www.careratings.com/" + i.find('a',class_='pdf-link')['href']
            
            row_tracker+=1
output_workbook.save("care_ratings.xlsx")            
last_row = all_data.max_row+1
counter_50 =1
counter_250=1
for i in range(2,last_row):           
     
    web_page = requests.get(all_data.cell(row=i,column=4).value)
    soup = BeautifulSoup(web_page.content,"lxml")
    relevant_table = soup.find('table',class_='table')
    # print(relevant_table)
    #ashleshprint(all_data.cell(row=i,column=4).value)
    try:
        currency = relevant_table.find('thead').find('span').text
        if currency.upper().find("MILLION")>=0:
            multiplication_factor = 0.1
        elif currency.upper().find("BILLION")>=0:
            multiplication_factor = 100
        relevant_rows = relevant_table.find('tbody').find_all('tr')
        total_rated_amount = 0
        for row in relevant_rows:
            rated_amount = float(row.find_all('td')[1].text)
            if isinstance (rated_amount,float) or isinstance (rated_amount,int):
                total_rated_amount+=rated_amount
        all_data.cell(row=i,column=6).value = total_rated_amount*multiplication_factor
        #print(all_data.cell(row=i,column=3).value)
        if (total_rated_amount*multiplication_factor > 249.9):
            greater_than_250.cell(row=counter_250,column=1).value = all_data.cell(row=i,column=1).value
            greater_than_250.cell(row=counter_250,column=2).value = all_data.cell(row=i,column=2).value
            greater_than_250.cell(row=counter_250,column=3).value = all_data.cell(row=i,column=6).value
            greater_than_250.cell(row=counter_250,column=4).value = all_data.cell(row=i,column=5).value
            greater_than_250.cell(row=counter_250,column=7).value = '=sum(1+2)'
            greater_than_250.cell(row=counter_250,column=5).value = '=HYPERLINK("{}", "{}")'.format(all_data.cell(row=i,column=5).value, all_data.cell(row=i,column=1).value)
            greater_than_250.cell(row=counter_250,column=6).value = "test1"            
            counter_250+=1
        elif (total_rated_amount*multiplication_factor > 49.9):
            greater_than_50.cell(row=counter_50,column=1).value = all_data.cell(row=i,column=1).value
            greater_than_50.cell(row=counter_50,column=2).value = all_data.cell(row=i,column=2).value
            greater_than_50.cell(row=counter_50,column=3).value = all_data.cell(row=i,column=6).value
            greater_than_50.cell(row=counter_50,column=4).value = all_data.cell(row=i,column=5).value
            greater_than_50.cell(row=counter_50,column=5).value = '=HYPERLINK("{}", "{}")'.format(all_data.cell(row=i,column=5).value, all_data.cell(row=i,column=1).value)
            greater_than_50.cell(row=counter_50,column=6).value = "test2"
            counter_50+=1
    except:
            greater_than_250.cell(row=counter_250,column=1).value = all_data.cell(row=i,column=1).value
            greater_than_250.cell(row=counter_250,column=2).value = all_data.cell(row=i,column=2).value
            greater_than_250.cell(row=counter_250,column=3).value = "Check Yourself"
            greater_than_250.cell(row=counter_250,column=4).value = all_data.cell(row=i,column=5).value
            greater_than_250.cell(row=counter_250,column=7).value = '=sum(3+4)'
            greater_than_250.cell(row=counter_250,column=5).value = '=HYPERLINK("{}", "{}")'.format(all_data.cell(row=i,column=5).value, all_data.cell(row=i,column=1).value)
            greater_than_250.cell(row=counter_250,column=6).value = "test3"            
            counter_250+=1        
output_workbook.save("care_ratings.xlsx")
#os.startfile("care_ratings.xlsx")   

from google.colab import files
files.download('care_ratings.xlsx')