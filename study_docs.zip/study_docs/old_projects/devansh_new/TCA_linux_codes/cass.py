# -*- coding: utf-8 -*-
"""
Created on Sat Feb  5 15:28:39 2022

@author: Administrator
"""

import pandas as pd
from datetime import datetime,timedelta
import logging
import numpy as np
from cassandra.cluster import Cluster
#from time import time
import time


def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open("/home/hadoop/master/config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster

cluster = cassandra_configs_cluster()

logging.info('Cassandra Cluster connected...')
session = cluster.connect('rohit')
#connect to your keyspace and create a session using which u can execute cql commands 
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None


def getData(session,exchange,order_date):
    while 1:
            
        try:
            print session, exchange, order_date
            query='SELECT * FROM quotedata WHERE token(exchange,date)=token(\'{}\',\'{}\') ALLOW FILTERING;'.format(exchange,order_date)
            rows = session.execute(query, timeout = None)
            rows = rows._current_rows
            return(rows)
        except Exception as e:
            print e
            time.sleep(5)     
            

result = pd.DataFrame()
d=datetime.now()
m = d.date().month

while not d.date().year==2021:
    for exchange in ['IS','IB']:
        df_f = getData(session,exchange,d.date())
        if df_f.empty==False:
            result = result.append(df_f, ignore_index=True)
    d=d-timedelta(days=1)
    
    if m!=d.date().month:
        result.to_csv("/home/hadoop/cass_data/data_{}_{}.csv".format(d.date().month, d.date().year), index=False, header=False)
        result = pd.DataFrame()
        m=d.date().month
    
    