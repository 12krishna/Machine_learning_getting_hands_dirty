# -*- coding: utf-8 -*-
"""
Created on Sun Apr 11 11:28:42 2021

@author: krishna
"""


import os
import numpy as np
import pandas as pd
import string
import simplefix
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from time import time, sleep
import re

input_dir="D:\\IOIOrderProcessing\\New folder\\fno\\"
expr = r'8=FIX\.4\.2.*?[10=\d+\\\x01\n|]$'

def filter_trades():
    
    start_time = time()
    subdirs_list = [f for r,d,f in os.walk(input_dir)][0]
     
    tempfile1 = open("D:\\devansh_new\\TCA_linux_codes\\response.csv", "w")
    tempfile2 = open("D:\\devansh_new\\TCA_linux_codes\\order.csv", "w")
    
    for i in subdirs_list:
        file_name = i
        print file_name
        f = open(input_dir+file_name,'r')
        if f.mode == 'r':
            content = f.readlines()
            
            for line in content:
                if re.findall(expr, line):   
                    rx = re.findall(expr, line)
                    
                    if (('35=8') in rx[0] ) or (('35=9') in rx[0] ): #response
                        x = string.replace(rx[0], '|','\x01')
                        parser = simplefix.FixParser()
                        parser.append_buffer(x)
                        msg = parser.get_message()
                        tempfile1.write(str(msg.get(11)) + "," + str(msg.get(35)) + "," + str(msg.get(55)) + "," + str(msg.get(49)) + "," + str(msg.get(52)) + "," + str(msg.get(60)) ) 
                        tempfile1.write("\n")
                    
                    elif (('35=D' in rx[0]) or ('35=G' in rx[0])): #order
                        x = string.replace(rx[0], '|','\x01')
                        parser = simplefix.FixParser()
                        parser.append_buffer(x)
                        msg = parser.get_message()
                        tempfile2.write(str(msg.get(11)) + "," + str(msg.get(35)) + "," + str(msg.get(55)) + "," + str(msg.get(49)) + "," + str(msg.get(52)) + "," + str(msg.get(60)) ) 
                        tempfile2.write("\n")
                        
        f.close()
        
    tempfile1.close()
    tempfile2.close()
                

    print 'Order and execution file aka temp1 and temp2 files generated successfully...'
                
    end_time = time()
    print "Execution time: {0} Seconds.... ".format(end_time - start_time)
    
    
def main():
    
    filter_trades()
    
    writer = pd.ExcelWriter("D:\\devansh_new\\TCA_linux_codes\\"+"Output.xlsx")
    
    df = pd.read_csv("D:\\devansh_new\\TCA_linux_codes\\response.csv")
    df.columns = ['tag11','tag35','tag55','tag49','tag52','tag60']
    df1 = pd.read_csv("D:\\devansh_new\\TCA_linux_codes\\order.csv")
    df1.columns = ['tag11','tag35','tag55','tag49','tag52','tag60']
    
    df1.to_excel(writer, index=False, sheet_name="Order")
    df.to_excel(writer, index=False, sheet_name="Response")
    
    df = df[['tag11','tag52']].merge(df1[['tag11','tag52']], on='tag11', how='left', suffixes=("_response","_order"))
    df[['tag52_response','tag52_order']] = df[['tag52_response','tag52_order']].applymap(lambda col: pd.to_datetime(col))
    df['latency_microseconds'] = df['tag52_response'] - df['tag52_order']
    df['latency_microseconds'] = df['latency_microseconds'].apply(lambda row: row.total_seconds())
    
    df.to_excel(writer, index=False, sheet_name="Latency")
    
    stat = df[df['latency_microseconds']>=0.000000][['latency_microseconds']]
    stat = pd.DataFrame(stat.describe()).T
    stat.to_excel(writer, sheet_name="Stats")
    
    writer.save()
    writer.close()
    
main()
    
