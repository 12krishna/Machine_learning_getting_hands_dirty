# -*- coding: utf-8 -*-
"""
Created on Tue Jun  8 14:06:54 2021

@author: Administrator
"""


from cassandra.cluster import Cluster
import pandas as pd
import datetime,time

master_dir="D:\\Master\\"

# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster

cluster = cassandra_configs_cluster()
session = cluster.connect('rohit')
#logging.info('Using test_df keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None

# for normal queries
rows = session.execute("select distinct branch_id, user_id, date  from spreadlog where date='{}' allow filtering;".format(d))
rows = rows._current_rows
    

# as per token a.k.a parition key of table
result=pd.DataFrame()
for i in range(1,365):
    d=datetime.date(2021,03,16)-datetime.timedelta(i)
    print d
    rows = session.execute("select distinct branch_id, user_id, date  from spreadlog where date='{}' allow filtering;".format(d))
    rows = rows._current_rows
    for _, distinct in rows.iterrows():
        print distinct['branch_id'],distinct['user_id'],distinct['date']
        temp = session.execute("select * from spreadlog where token(branch_id, user_id, date)=token({},{},'{}') \
                               and date='{}' allow filtering;".format(distinct['branch_id'],distinct['user_id'],distinct['date'], d))
        temp = temp._current_rows
        result=result.append(temp, ignore_index=True)
    
    if d==datetime.date(2020,12,1):
        break
    time.sleep(2)


