# -*- coding: utf-8 -*-
"""
Created on Mon Feb 14 11:48:35 2022

@author: backup
"""

import logging
import pandas as pd
#from tabulate import tabulate
import re,os,datetime,time,sys
import pysftp
#import socks
#import socket
from ftplib import FTP
import threading
os.chdir('/home/hadoop/bo_ftp_downloader')
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None  
import Email_notifications

if sys.platform not in ('win32', 'cygwin', 'cli'):
    # linux env paths
    password_filepath = "/CMFOReport/scripts/"
    data_dir = '/BackOfficeDataDownload/'
    master_dir = "/home/hadoop/tca_project/master_files/"
    log_path = '/home/hadoop/bo_ftp_downloader/logs/'
else:
    # windows env paths
    os.chdir("C:\\Users\\backup\\")
    password_filepath = "C:\\Users\\backup\\New folder\\"
    master_dir = "D:\\Data_dumpers\\Master\\"
    log_path='C:\\Users\\backup\\'
    data_dir=r'\\172.17.9.22\Users2\BackOfficeDataDownload'  



_user_id = "08081"
_password = ""
_hostname = 'ftp.connect2nse.com'    
lines=open(os.path.join(password_filepath, "nsepwd.txt"),"r").readlines()
uname=_user_id
pword=lines[0].strip().split("=")[-1]
print uname, pword
'''
socks.set_default_proxy(socks.HTTP, 
                            "172.17.9.170", 8080,
                            username="geetav",  # use your username  krishnay
                            password="Pass@333"  # passowrd that you use for login to kotak system
                            )       
socket.socket = socks.socksocket
'''
logging.basicConfig(filename=log_path+"ftp.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")     

console = logging.StreamHandler()
console.setLevel(logging.INFO)
# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)
logging.info("Start process")

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
     
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)

  
     
def ftp_proxy_downloader(d):
    ds=datetime.datetime.now()
    dt="23:00:00"
    files_dict={"BSE_Scrip_Series_Mapping_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")):"/common/clearing","C_STT_IND_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")):"/common/clearing",
       "C_STT_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")):"/common/clearing","bulk{}.xls".format(datetime.datetime.strftime(d,"%d%m%Y")):"/common/cmmkt",
       "nnf_security.gz_{}".format(datetime.datetime.strftime(d,"%d%b%Y").upper()):"/common/ntneat","security.gz":"/common/C2N","participant.gz":"/common/C2N",
       'C_STC_{}*'.format(datetime.datetime.strftime(d,"%b%Y").upper()):"/common/clearing","C_08081_T_FOBG_N*_{}.csv.gz".format(datetime.datetime.strftime(d,"%d%m%Y")):"/08081/Reports",
       "C_08081_T_FOBG_W*_{}.csv.gz".format(datetime.datetime.strftime(d,"%d%m%Y")):"/08081/Reports","security.gz":"/common/ntneat","participant.gz":"/common/ntneat",
       "08081_C_PTA_{}_S01.csv.gz".format(datetime.datetime.strftime(d,"%d%m%Y")):"/08081/PTA/Dnld","08081_CLNTEPI_{}.S01".format(datetime.datetime.strftime(d,"%Y%m%d")):"/08081/CEP/Dnld",
       "08081_T_NSP_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")):"/08081/NSP","08081_NSP_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")):"/08081/NSP",
       "MWST_08081_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")):"/08081/Reports","C_SD01_08081_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")):"/08081/Reports",
        "{}_08081.txt.gz".format(datetime.datetime.strftime(d,"%d%m%Y")):"/08081/onlinebackup","C_08081_PTA_NONREPORTING_{}_*.csv".format(datetime.datetime.strftime(d,"%d%m%Y")):"/08081/Reports",
        "08081_NSCCLSEG_{}_*.pdf".format(datetime.datetime.strftime(d,"%Y%m%d")):"/08081/Accounts/Nsccl"}
    
    while len(files_dict)!=0 or ds.strftime("%H:%M:%S")<dt:
        
             ftp = FTP(_hostname)
             ftp.set_debuglevel(1) 
             ftp.login(
              user=_user_id,
               passwd=pword
               )
             for f in list(files_dict.keys()):
                logging.info("inside ftp")
                ds=datetime.datetime.now()
                print(ds) 
                print ftp.pwd() # to check what is present working directory       
                ftp.cwd(files_dict[f]) 
                newf=ftp.nlst(f)
                if len(newf)==1:
                    logging.info("{} file exists".format(newf[0]))
                    try:
                        ftp.retrbinary("RETR " + newf[0], 
                               open(os.path.join(data_dir,newf[0]), 'wb').write)
                        logging.info("{} file stored".format(newf[0]))
                        Email_notifications.email_utility("{}".format(newf[0]), 
                                "Files have been updated on mentioned path: \\172.17.9.22\Users2\BackOfficeDataDownload")            
                        files_dict.pop(f)
                       
                    except Exception as e:
                              print("Error downloading {} file Error code : {}".format(newf[0], e))
                              logging.info("Error downloading {} file Error code : {}".format(newf[0], e))   
            
             ftp.close()
         
def main(nd):
    
    
    d=datetime.datetime.today()-datetime.timedelta(nd)
    if process_run_check(d.date())== -1:
        return -1
    ftp_proxy_downloader(d)
    
main(nd=0)         

         
