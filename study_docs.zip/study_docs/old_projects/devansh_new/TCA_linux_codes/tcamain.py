import pandas as pd
import datetime,time,re,os
from order_generation_split1 import split1
from order_generation_split2 import split2
from TCA_params_compute import tca_calc
from dumpinpostgress import dump_in_postgres
import shutil
import logging
#import order_generation_split1,order_generation_split2,TCA_17_9,dumpinpostgress,tcasplit,tcasamplefinal
master_dir = "/home/hadoop/tca_project/master_files/"
source_dir1 = "/home/hadoop/tca_project/temp_files/"
source_dir2 = "/home/hadoop/tca_project/order_files/"
dstn_dir = "/home/hadoop/tca_project/processed_files/"

log_path = "/home/hadoop/tca_project/tca_logs/"

logging.basicConfig(filename=log_path +"test_{}.log".format(datetime.datetime.now().date()),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        print "Start process for working day"
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        print 'Holiday: skip for current date :{} '.format(d)
        return -1
    
def previous_working_day(d):
    '''Get previous wokring day'''
    
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                #print "Holiday : ",d
                d = d - datetime.timedelta(days=1)                
            else:
                return d    

def main():
    
       
    d=datetime.datetime.now().date()#-datetime.timedelta(days=4)#todays date
    	#tag115list=["KMAMCALG","FRANKLINTRT"] #tag115 list
    

    if process_run_check(d) == -1:
        return -1    
    d=previous_working_day(d)
    
    #d1=datetime.datetime.now().date()-datetime.timedelta(days=1)    #previous days date
    #d=datetime.date(2021,8,17)
    logging.info("TCA Start process for {}".format(d))
    files1 = os.listdir(source_dir1)
    for f in files1:
        print "Moving " + f
        logging.info("Moving " + f)
        shutil.move(source_dir1+f,dstn_dir+f)

    files2 = os.listdir(source_dir2)
    for f in files2:
        print "Moving " + f
        logging.info("Moving " + f)
        shutil.move(source_dir2+f,dstn_dir+f)

	
	#d=datetime.datetime.now().date()-datetime.timedelta(days=1)
    print "date",d
    print datetime.datetime.now()
    logging.info("Current time: {}".format(datetime.datetime.now()))
    split1()  
    logging.info("Success: Split 1")
    split2()
    logging.info("Success: Split 2")
    tca_calc(d)
    logging.info("Success: TCA param computations")
    dump_in_postgres(d.strftime('%Y%m%d'))
    logging.info("Success: Data dumping")
    	#gen_daily_report(d)
	#gen_monthly_report(d,d1,tag115list)
    
main()
