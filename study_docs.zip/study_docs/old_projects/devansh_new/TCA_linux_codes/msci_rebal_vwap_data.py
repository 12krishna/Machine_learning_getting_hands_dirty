# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 10:29:31 2021

@author: krishna
"""

import pandas as pd
import datetime
import logging
import numpy as np
from cassandra.cluster import Cluster
import time
import os
from collections import OrderedDict 

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open("D:\\Master\\config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster

#cluster = Cluster(['172.17.9.51'])
cluster = cassandra_configs_cluster()

logging.info('Cassandra Cluster connected...')
session = cluster.connect('rohit')
#connect to your keyspace and create a session using which u can execute cql commands 
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None


def getData(session,exchange,symbol,date):
    print session, exchange, symbol
    query='SELECT * FROM quotedata WHERE token(exchange,date)=token(\'{1}\',\'{2}\') and symbol=\'{0}\' ALLOW FILTERING;'.format(symbol,exchange,date)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    return(rows)    


# missing timeframes
time_keys = pd.DataFrame(pd.timedelta_range(start=str(datetime.time(9,0)), end=str(datetime.time(16,0)), freq = '60s')[:-1], columns=['time'])
time_keys['time'] = time_keys.apply(lambda row: str(row['time']).split(' ')[-1], axis=1)
       

# handle missing time
def handle_missing_time(result):
        
    temp = pd.DataFrame()
    for gname, gelements in result.groupby(['symbol']):
        t = time_keys.merge(gelements, on='time',how='left')
        t['symbol'] = gname
        t['volume'] = t['volume'].fillna(0)
        t['vwap'] = t['vwap'].fillna(method='bfill')
        temp = temp.append(t)

    return temp



def vwaptable(session,exchange,symbol,date):
    print session, exchange, symbol
    query='SELECT * FROM vwapdata WHERE token(exchange,symbol)=token(\'{}\',\'{}\') and date=\'{}\' limit 1 ALLOW FILTERING;'.format(
                                        exchange, symbol, date)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    return(rows)
    
'''    
stocks = pd.read_csv("C:\\Users\\krishna\\Downloads\\ind_nifty500list.csv")
bloom = pd.read_excel("D:/Master/BSE_500_tickers.xlsx")[['NSE Symbol','Bloomberg']]
bloom.columns= ['Symbol','Bloomberg']
bloom['Bloomberg'] = bloom['Bloomberg'].apply(lambda row: row.split(" ")[0]) 
stocks = stocks.merge(bloom, on=['Symbol'], how='left')
stocks = stocks[['Symbol','Bloomberg']]


missing = []
for _, row in stocks.iterrows():
    if getData(session, 'IS', row['Bloomberg']).empty==True:
        print "data not found {} ".format(row['Symbol'])
        missing.append([row['Symbol'], 'IS'])
    
    if getData(session, 'IB', row['Bloomberg']).empty==True:
        print "data not found {} ".format(row['Symbol'])
        missing.append([row['Symbol'], 'IB'])
    
''' 
       


def main():
    
    stocks = pd.read_excel("D:\\devansh_new\\TCA_linux_codes\\Book32.xlsx")
    stocks.dropna(how='all', axis=0, inplace=True)
    stocks['Date of Flow']=stocks['Date of Flow'].dt.date

        
    missing=[]
    for d in stocks['Date of Flow'].unique():
        result = pd.DataFrame()    
        for _, row in stocks[stocks['Date of Flow']==d].iterrows():
            
            df = getData(session, 'IS', row['BBG'], row['Date of Flow'])
        
            if df.empty==True:
                print "Data not found for {} {}".format(row['BBG'], row['Date of Flow'])
                missing.append([row['BBG'], row['Date of Flow']])
                time.sleep(5)
                
            else:
                df['date'] = df['date'].apply(lambda row: row.date())
                df['time'] = df['time'].apply(lambda row: row.time())
                df['dtime'] = df['date'].astype(str)+" "+df['time'].astype(str)
                df['dtime'] = df['dtime'].apply(lambda row: pd.to_datetime(row) )
                df = df.groupby(['symbol',pd.Grouper(key='dtime',freq='60s', 
                                                sort=True)]).apply(lambda grp: pd.Series({
                                'vwap': np.average(grp['price'], weights=grp['volume']) if np.sum(grp['volume'])>0 else np.nan,
                                'volume':np.sum(grp['volume'])}) ).reset_index() 
        
                df['dtime'] = df['dtime'].dt.time
                df['dtime'] = df['dtime'].astype(str)
                df.rename(columns={'dtime':'time'}, inplace=True)
                df = df[['symbol','time','volume','vwap']]
           
                result = result.append(df, ignore_index=True)
            
        
        # handle missing time
        result = handle_missing_time(result.copy(deep=True))    
        writer = pd.ExcelWriter("D:\\devansh_new\\out\\Output_{}.xlsx".format(d))
        
        total_vol = result.groupby(by=['symbol'])['volume'].sum().reset_index()
        result = result.merge(total_vol, on=['symbol'], how='left', suffixes=('','_sum'))
        result['ratio'] = result[['volume','volume_sum']].apply(lambda row: round(row['volume']/row['volume_sum']*100, 2) if row['volume_sum']!=0 else 0, axis=1)
        
        df1 = result[['time', 'symbol','ratio']]
        df2 = result[['time', 'symbol','volume']]
        df3 = result[['time', 'symbol','vwap']]
        
        df1 = df1.pivot(index='time', columns='symbol', values='ratio')
        df2 = df2.pivot(index='time', columns='symbol', values='volume')
        df3 = df3.pivot(index='time', columns='symbol', values='vwap')
        
        df1.to_excel(writer, sheet_name='%vol_min')    
        df2.to_excel(writer, sheet_name='vol_min')  
        df3.to_excel(writer, sheet_name='vwap')
        
        writer.save()
        writer.close()
        
    
    
def main1():
        
    # get quote data
    stocks = pd.read_excel("D:\\devansh_new\\TCA_linux_codes\\NAMES.xlsx", header=None)
    stocks['symbol'] = stocks[0].apply(lambda row: row.split(' ')[0])
    stocks['exchange'] = stocks[0].apply(lambda row: row.split(' ')[1])   
    stocks.loc[stocks['symbol']=='INDUSTOW','symbol'] = 'BHIN' 
    missing = []
    for d in [datetime.date(2020,6,19), datetime.date(2020,9,18)]:
        writer = pd.ExcelWriter("D:\\devansh_new\\out\\OutputNames_{}.xlsx".format(d))
        result=pd.DataFrame()    
        for _, row in stocks.iterrows():
            df = getData(session, row['exchange'], row['symbol'], d)
            if df.empty==True:
                print "Data not found for {}".format(row['symbol'])
                missing.append([row['symbol'], d])
                time.sleep(5)
            else:
                df['date'] = df['date'].apply(lambda row: row.date())
                df['time'] = df['time'].apply(lambda row: row.time())
                df['dtime'] = df['date'].astype(str)+" "+df['time'].astype(str)
                df['dtime'] = df['dtime'].apply(lambda row: pd.to_datetime(row) )
                df = df.groupby(['symbol',pd.Grouper(key='dtime',freq='60s', 
                                                sort=True)]).apply(lambda grp: pd.Series({
                                'vwap': np.average(grp['price'], weights=grp['volume']) if np.sum(grp['volume'])>0 else np.nan ,
                                'volume':np.sum(grp['volume'])}) ).reset_index() 
        
                df['dtime'] = df['dtime'].dt.time
                df['dtime'] = df['dtime'].astype(str)
                df.rename(columns={'dtime':'time'}, inplace=True)
                df = df[['symbol','time','volume','vwap']]
           
                result = result.append(df, ignore_index=True)
            
        
        # handle missing time
        result = handle_missing_time(result.copy(deep=True))    
        
        total_vol = result.groupby(by=['symbol'])['volume'].sum().reset_index()
        result = result.merge(total_vol, on=['symbol'], how='left', suffixes=('','_sum'))
        result['ratio'] = result[['volume','volume_sum']].apply(lambda row: round(row['volume']/row['volume_sum']*100, 2) if row['volume_sum']!=0 else 0, axis=1)
        
        df1 = result[['time', 'symbol','ratio']]
        df2 = result[['time', 'symbol','volume']]
        df3 = result[['time', 'symbol','vwap']]
        
        df1 = df1.pivot(index='time', columns='symbol', values='ratio')
        df2 = df2.pivot(index='time', columns='symbol', values='volume')
        df3 = df3.pivot(index='time', columns='symbol', values='vwap')
        
        df1.to_excel(writer, sheet_name='%vol_min')    
        df2.to_excel(writer, sheet_name='vol_min')  
        df3.to_excel(writer, sheet_name='vwap')
        
        writer.save()
        writer.close()
            
        
main()
main1()