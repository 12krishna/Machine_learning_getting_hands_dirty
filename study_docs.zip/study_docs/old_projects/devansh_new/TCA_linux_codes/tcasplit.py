#import libraires
import logging,datetime,psycopg2
import pandas as pd
import numpy as np
from sqlalchemy import create_engine

'''data paths'''
output_dir='D:\\devansh_new\\Output\\'
master_dir ="D:\\Master\\"
email_dir="D:\\Emails\\Output\\"

def dateparse(date):    
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
    
def last_working(d):
    while  True:
            if d in holiday_master["date"].values:
                print "Holiday : ",d
                d = d - datetime.timedelta(days=1)                
            else:
                return d  




def highlight_vals_c1(row, cols):
    a1,a2= cols
    styles = {col: '' for col in row.index}
    
    if row[a1] >= 0 and row[a2] >= 0:
    
        styles[a1] = 'background-color: %s' % '#98fb98'
        styles[a2] = 'background-color: %s' % '#98fb98'
    
    else:
        
        styles[a1] = 'background-color: %s' % '#FF9999'
        styles[a2] = 'background-color: %s' % '#FF9999'
   
    return styles

'''function to generate summary report'''

def color_r_g_b(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    if val > 25:
        color = '#98fb98' 
    elif val>=20 and val<=25:
        color='blue' 
    else:
        color='#FF9999'
    return 'background-color: %s' % color

'''function to get the output in required excel format'''
def get_tca_split(tca):
#     tca=pd.read_excel(master_dir+"output_{}.xlsx".format(d.strftime('%Y%m%d')),sheet_name='complete_output')#read file
    
    #add column names to the newlist
    newlist=[]
    newlist=tca.columns
    
    #get column name ends with bse and nse and append them to the respective list
    bselist=[]
    nselist=[]
    for i in range(0,len(newlist)):
        if newlist[i].endswith('Bse'):
            bselist.append(newlist[i])
        if newlist[i].endswith('Nse'):
            nselist.append(newlist[i])
    
    print "Bselist",bselist
    print "Nselist",nselist
    #create pairlist and append row to it based on sor is y or n and security exchange is bse or nse
    pairlist=[]
    for col,row in tca.iterrows():
        if row["SOR"]=="Y":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType',
                        'LimitPrice','Side','SecurityExchange','StartTime','EndTime','OrderQty','SOR','NSEExecutedQty',
                        'NSEExecutedQty','NSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapNse','IntervalVwapLimitNse','DayVwapLimitNse','DayVwapNse','DayTwapNse','IntervalTwapNse',
                        'IntervalTwapLimitNse','DayTwapLimitNse','Pwp20Nse','Pwp20LimitNse','AvgTradeSizeNse','IntervalVolNse',
                        'IntervalVolLimitNse','DayVolNse','DayVolLimitNse','volExecNse_intervalVolNse',
                        'volExecNse_intervalVolLimitNse','volExecNse_DayVolNse','volExecNse_DayVolLimitNse','ArrivalPrice']]
            result["SecurityExchange"]="NSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result) 
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                        'SecurityExchange','StartTime','EndTime','OrderQty','SOR','BSEExecutedQty','BSEExecutedQty',
                        'BSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapBse','IntervalVwapLimitBse','DayVwapLimitBse','DayVwapBse','DayTwapBse','IntervalTwapBse',
                        'IntervalTwapLimitBse','DayTwapLimitBse','Pwp20Bse','Pwp20LimitBse','AvgTradeSizeBse','IntervalVolBse',
                        'IntervalVolLimitBse','DayVolBse','DayVolLimitBse','volExecBse_intervalVolBse','volExecBse_intervalVolLimitBse',
                        'volExecBse_DayVolBse', 'volExecBse_DayVolLimitBse','ArrivalPrice']]
            result["SecurityExchange"]="BSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
        
        if row["SOR"]=='N' and row["SecurityExchange"]=="NSE":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType',
                        'LimitPrice','Side','SecurityExchange','StartTime','EndTime','OrderQty','SOR','NSEExecutedQty',
                        'NSEExecutedQty','NSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapNse','IntervalVwapLimitNse','DayVwapLimitNse','DayVwapNse','DayTwapNse','IntervalTwapNse',
                        'IntervalTwapLimitNse','DayTwapLimitNse','Pwp20Nse','Pwp20LimitNse','AvgTradeSizeNse','IntervalVolNse',
                        'IntervalVolLimitNse','DayVolNse','DayVolLimitNse','volExecNse_intervalVolNse',
                        'volExecNse_intervalVolLimitNse','volExecNse_DayVolNse','volExecNse_DayVolLimitNse','ArrivalPrice']]
            result["SecurityExchange"]="NSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
    
        if row["SOR"]=='N' and row["SecurityExchange"]=="BSE":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                        'SecurityExchange','StartTime','EndTime','OrderQty','SOR','BSEExecutedQty','BSEExecutedQty',
                        'BSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapBse','IntervalVwapLimitBse','DayVwapLimitBse','DayVwapBse','DayTwapBse','IntervalTwapBse',
                        'IntervalTwapLimitBse','DayTwapLimitBse','Pwp20Bse','Pwp20LimitBse','AvgTradeSizeBse','IntervalVolBse',
                        'IntervalVolLimitBse','DayVolBse','DayVolLimitBse','volExecBse_intervalVolBse','volExecBse_intervalVolLimitBse',
                        'volExecBse_DayVolBse', 'volExecBse_DayVolLimitBse','ArrivalPrice']]
            result["SecurityExchange"]="BSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
            
    final_df=pd.DataFrame(pairlist)
    final_df.columns=['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                      'SecurityExchange','StartTime','EndTime','OrderQty','SOR','QuantityExecuted','ExecutedQty',
                      'AvgPx','Remarks','Algorithm','LastFillTime','ArrivalTime',
                      'IntervalVwap','IntervalVwapLimit','DayVwapLimit','DayVwap','DayTwap','IntervalTwap',
                      'IntervalTwapLimit','DayTwapLimit','Pwp','PwpLimit','AvgTradeSize','IntervalVol',
                      'IntervalVolLimit','DayVol','DayVolLimit','volExec_intervalVol','volExec_intervalVolLimit',
                      'volExec_DayVol','volExec_DayVolLimit','ArrivalPrice']
    
    final_write=final_df[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                      'SecurityExchange','StartTime','EndTime','OrderQty','SOR','QuantityExecuted','ExecutedQty',
                      'AvgPx','Remarks','Algorithm','LastFillTime','ArrivalTime',
                      'IntervalVwap','IntervalVwapLimit','DayVwapLimit','DayVwap','DayTwap','IntervalTwap',
                      'IntervalTwapLimit','DayTwapLimit','Pwp','PwpLimit','AvgTradeSize','IntervalVol',
                      'IntervalVolLimit','DayVol','DayVolLimit','volExec_intervalVol','volExec_intervalVolLimit',
                      'volExec_DayVol','volExec_DayVolLimit','ArrivalPrice']]
    
#     final_df_r.reset_index(drop=True,inplace=True)
    final_write.reset_index(drop=True,inplace=True)
#     final_write.to_excel(master_dir+'final_tca_split_{}.xlsx'.format(d.strftime('%Y%m%d')),index=False)

    return final_write #final_df_r,

def f(x):
    d = {}
    d['PWPvalues'] = (x['PWPvalues']).sum()
    d['values'] = (x['values']).sum()
    d['VWAPvalues'] = (x['VWAPvalues']).sum()
    d['TWAPvalues'] = (x['TWAPvalues']).sum()
    d['TradeId']=x['TradeId'].values[0]
    d['IntervalVolLimitPWPvalues']=x[x["PWPvalues"]>0]['IntervalVolLimit'].sum()
    d['IntervalVolLimit']=x['IntervalVolLimit'].sum()
    d['QuantityExecuted']=x['QuantityExecuted'].sum()
    d['SecurityExchange']=x['SecurityExchange'].values[0]                                                                           
    d['Date']=x['Date'].values[0]                                                                         
    d['ClientName']=x['ClientName'].values[0]                                                                              
    d['Symbol']=x['Symbol'].values[0]                                                                 
    d['Side']=x['Side'].values[0]                                                               
    d['ArrivalPrice']=x['ArrivalPrice'].values[0]                                                                                                                                            
    return pd.Series(d, index=['PWPvalues','values', 'VWAPvalues','TWAPvalues','TradeId','IntervalVolLimitPWPvalues',
                               'IntervalVolLimit',
                               'QuantityExecuted','SecurityExchange','Date','ClientName','Symbol','Side','ArrivalPrice'])


def generate_summary(final_write,d):
    df=final_write
    df['Start Time'] = pd.to_datetime(df['StartTime'])
    df['Date'] = df['Start Time']
    df['values'] = df['AvgPx']*df['QuantityExecuted']
    df['VWAPvalues'] = df['IntervalVwapLimit']*df['IntervalVolLimit']
    df['TWAPvalues'] = df['IntervalTwapLimit']*df['IntervalVolLimit']
    df['PWPvalues'] = df['PwpLimit']*df['IntervalVolLimit']
    df['uniquetdse'] = df['TradeId']+df['SecurityExchange']
    
    #df = df[df['QuantityExecuted']!=0]
    
#    combined_group = df.groupby('uniquetdse', as_index=False).agg({'TradeId':'first','IntervalVolLimit':'sum','QuantityExecuted':'sum','values':'sum', 'VWAPvalues':'sum', 'TWAPvalues':'sum', 'PWPvalues':'sum', 'SecurityExchange':'first','Date':'first', 'ClientName':'first', 'Symbol':'first', 'Side':'first', 'ArrivalPrice':'first'})
    combined_group = df.groupby('uniquetdse', as_index=False).apply(f)
    print combined_group
    
    combined_group['wt_AvgPx'] = combined_group['values']/combined_group['QuantityExecuted']
    combined_group['wt_VWAP'] = combined_group['VWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_TWAP'] = combined_group['TWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_PWP'] = combined_group['PWPvalues']/combined_group['IntervalVolLimitPWPvalues']
    combined_group.fillna(0, inplace=True)
    combined_group.sort_values(by='Date', inplace=True)
    combined_group.drop(['values', 'VWAPvalues', 'TWAPvalues', 'PWPvalues'], axis=1, inplace=True)

    # calculating parameters
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
    combined_group['wtTWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_TWAP'])/combined_group['wt_TWAP'])*10000
    combined_group['wtPWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_PWP'])/combined_group['wt_PWP'])*10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice'])/combined_group['ArrivalPrice'])*10000
    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)

    # BUY side parameters
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtTWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtPWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtArrPx_vs_AvgPx']

    # SELL side parameters
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtTWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtPWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtArrPx_vs_AvgPx']

    # Difference parameters
    combined_group['VWAP_Value_Difference'] = (combined_group['wtVWAP_vs_AvgPx']*combined_group['wt_VWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['TWAP_Value_Difference'] = (combined_group['wtTWAP_vs_AvgPx']*combined_group['wt_TWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP_Value_Difference'] = (combined_group['wtPWP_vs_AvgPx']*combined_group['wt_PWP']*combined_group['QuantityExecuted'])/10000
    combined_group['ArrPx_Value_Difference'] = (combined_group['wtArrPx_vs_AvgPx']*combined_group['ArrivalPrice']*combined_group['QuantityExecuted'])/10000
    
    combined_group = combined_group[['TradeId','SecurityExchange','ClientName','QuantityExecuted', 'Symbol', 'Side', 'Date', 'wt_AvgPx', 'wt_VWAP', 'wtVWAP_vs_AvgPx', 'VWAP_Value_Difference', 'wt_TWAP', 'wtTWAP_vs_AvgPx', 'TWAP_Value_Difference', 'wt_PWP', 'wtPWP_vs_AvgPx', 'PWP_Value_Difference', 'ArrivalPrice', 'wtArrPx_vs_AvgPx', 'ArrPx_Value_Difference']]
    combined_group[['wt_AvgPx', 'wt_VWAP', 'wtVWAP_vs_AvgPx', 'VWAP_Value_Difference', 'wt_TWAP', 'wtTWAP_vs_AvgPx', 'TWAP_Value_Difference', 'wt_PWP', 'wtPWP_vs_AvgPx', 'PWP_Value_Difference', 'ArrivalPrice', 'wtArrPx_vs_AvgPx', 'ArrPx_Value_Difference']]=combined_group[['wt_AvgPx', 'wt_VWAP', 'wtVWAP_vs_AvgPx', 'VWAP_Value_Difference', 'wt_TWAP', 'wtTWAP_vs_AvgPx', 'TWAP_Value_Difference', 'wt_PWP', 'wtPWP_vs_AvgPx', 'PWP_Value_Difference', 'ArrivalPrice', 'wtArrPx_vs_AvgPx', 'ArrPx_Value_Difference']].astype(float).round(4)
    combined_group = combined_group[combined_group['QuantityExecuted']!=0]
    combined_group.columns = combined_group.columns.str.replace('_',' ')
    
    
    c1=combined_group[['wtVWAP vs AvgPx','VWAP Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['wtVWAP vs AvgPx','VWAP Value Difference']), axis=1)
    c2=combined_group[['wtTWAP vs AvgPx','TWAP Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['wtTWAP vs AvgPx','TWAP Value Difference']), axis=1)
    c3=combined_group[['wtPWP vs AvgPx','PWP Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['wtPWP vs AvgPx','PWP Value Difference']), axis=1)
    c4=combined_group[['wtArrPx vs AvgPx','ArrPx Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['wtArrPx vs AvgPx','ArrPx Value Difference']), axis=1)
    
    o1=combined_group[['TradeId','ClientName','QuantityExecuted','Symbol','Side','Date','SecurityExchange','wt AvgPx','wt VWAP']]
    o2=combined_group[['wt TWAP']]
    o3=combined_group[['wt PWP']]
    o4=combined_group[['ArrivalPrice']]
    
    writer = pd.ExcelWriter(output_dir+'tca_split_{}.xlsx'.format(d.strftime('%Y%m%d')),engine='xlsxwriter')

    #final_write.to_excel(writer,sheet_name='complete_output',startrow=0 , startcol=0,index=False)
    
    o1.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=0,index=False)
    c1.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=9,index=False)

    o2.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=11,index=False)
    c2.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=12,index=False)

    o3.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=14,index=False)
    c3.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=15,index=False)

    o4.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=17,index=False)
    c4.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=18,index=False)

    writer.save()
    writer.close()

def get_postgress_data(d):
    #get latest date from database
    conn = psycopg2.connect(database="NSE-FNO",
                            user="postgres",
                             password="kotak@123", 
                             host="172.17.9.182", 
                             port="5432")
    cur=conn.cursor()
#     r = cur.fetchall()[0][0]
    cur.execute("select * from tca_split where date ='{}';".format(d)) 
    df = cur.fetchall()
    df = pd.DataFrame(df)
    return df



def process_check(d):
    '''Function to load all masters and process check criteria'''

    if len(holiday_master[holiday_master['date']==d])==0 :
        print "Today is working day, start process "
        return 1
    else:  
        print "Skip process; holiday"
        return -1







def split_report_main(d):
    
#    d=datetime.datetime.now().date()
#    if process_check(d)==-1:
#        return -1
#    d = d - datetime.timedelta(days=nd)
    # get last working day 
#    d = last_working(d)   
    
    print "processing for day {} ".format(d)
    pdf = get_postgress_data(d) #get the data from postgress
    pdf.columns=["TradeId","ClientOrdID","Og_ClientOrdID","ClientName","Symbol","Series","Ticker","OrdType",
                 "LimitPrice","Side","SecurityExchange","StartTime","EndTime","OrderQty",
                 "SOR","QuantityExecuted","AvgPx","NSEExecutedQty","BSEExecutedQty","NSEExecutedAvg","BSEExecutedAvg",
                 "Remarks","Algorithm","LastFillTime","ArrivalTime","Tag115","IntervalVwap","IntervalVwapNse",
                 "IntervalVwapBse","IntervalVwapLimit","AvgPx_vs_IntervalVwapLimit","IntervalVwapLimitNse",
                 "IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap",
                 "DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse",
                 "IntervalTwapBse","IntervalTwapLimit","AvgPx_vs_IntervalTwapLimit","IntervalTwapLimitNse",
                 "IntervalTwapLimitBse","DayTwapLimit","DayTwapLimitNse","DayTwapLimitBse","AvgPx_vs_IntervalVwap",
                 "AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit","AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","AvgPx_vs_DayTwapLimit",
                 "AvgPx_vs_Pwp","Pwp20Nse","Pwp20Bse","Pwp20","Pwp20Limit","AvgPx_vs_PwpLimit","Pwp20LimitNse",
                 "Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse",
                 "IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse",
                 "DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse","volExecBse_intervalVolBse",
                 "volExec_vs_IntervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse",
                 "volExec_vs_IntervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse",
                 "volExec_vs_DayVol","volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_vs_DayVolLimit",
                 "ArrivalPriceNse","ArrivalPriceBse","ArrivalPrice","AvgPx_vs_ArrivalPx","Pwp10Nse","Pwp10Bse","Pwp10",
                 "Pwp10Limit","Pwp10LimitNse","Pwp10LimitBse","Pwp15Nse","Pwp15Bse","Pwp15","Pwp15Limit","Pwp15LimitNse",
                 "Pwp15LimitBse","Pwp25Nse","Pwp25Bse","Pwp25","Pwp25Limit","Pwp25LimitNse","Pwp25LimitBse",
                 "Pwp30Nse","Pwp30Bse","Pwp30","Pwp30Limit","Pwp30LimitNse","Pwp30LimitBse","unique_id","date"]
    final_write=get_tca_split(pdf)
    # generate_summary(final_write,d)
    generate_summary(final_write,d)
    import shutil
    shutil.copy(output_dir+'tca_split_{}.xlsx'.format(d.strftime('%Y%m%d')), 
                    email_dir+'tca_split_{}.xlsx'.format(d.strftime('%Y%m%d')))
    
    
    

#main()


#split_report_main(d)  # set date range here 
split_report_main(datetime.datetime.now().date()-datetime.timedelta(days=3))  # set date range here 