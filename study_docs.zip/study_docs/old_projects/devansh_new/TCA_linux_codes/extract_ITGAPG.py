# -*- coding: utf-8 -*-
"""
Created on Mon Feb  1 10:49:17 2021

@author: krishna
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Jan 10 17:12:32 2019

@author: krishna
"""
import os
import re
import pandas as pd
import numpy as np
import string
import simplefix
from datetime import datetime, timedelta
from time import time
#import logging
filelist = list()

input_path='/UL_DATA/'
outpath = '/home/hadoop/tca_project/temp_files/'
#log_path = "/home/hadoop/tca_project/tca_logs/"

#input_path='D:\\devansh_new\\TCA_linux_codes\\UL_DATA\\'
#outpath='D:\\devansh_new\\TCA_linux_codes\\UL_DATA\\'
expr = r'8=FIX\.4\.2.*?[10=\d+\|]$'       # pattern to recognize line with valid excution or order line ;
                                        #match line with pattern 8=FIX.4.2 and ending with 10=number|


def split1():
    start_time = time()
    subdirs_list = [r[1] for r in os.walk(input_path)]
    for i in subdirs_list[0]:
        filelist.append(input_path + i + '/' + i[17:21] + i[14:16] + i[11:13] + '.txt')
     
    for i in filelist:
        file_name = i
        print file_name
        f = open(file_name,'r')
        if f.mode == 'r':
            content = f.readlines()
        
            base = os.path.basename(file_name)
            tempfile1_name = "extractedfile1_" + str(os.path.splitext(base)[0]) +".csv"
            tempfile2_name = "extractedfile2_" + str(os.path.splitext(base)[0]) +".csv"
            tempfile1 = open(outpath + tempfile1_name, 'w')
            tempfile2 = open(outpath + tempfile2_name, 'w')
            for line in content:
                if re.findall(expr, line):   
                    rx = re.findall(expr, line)
                    if 'I_ITGETS' in line:  # if 49=base and 56=client ; msg send as response
                        if ('35=8' in rx[0]) or ('35=9' in rx[0]):
                            #print line
                            x = string.replace(rx[0], '|','\x01')
                            parser = simplefix.FixParser()
                            parser.append_buffer(x)
                            msg = parser.get_message()
                            #print "here"
                            #print msg.get(128)
                            tempfile1.write(" ".join(line.split(" ")[:2])+","+str(msg.get(128))+","+str(msg.get(35)) + ","+str(msg.get(39)) + "," + \
                                            str(msg.get(11)) + "," + str(msg.get(41)) + "," + str(msg.get(52)) + "," + 
                                            str(msg.get(60))) 
                            tempfile1.write("\n")    
                            
                                
                    elif '115=ITGAPG' in rx[0]:   # if 49=client and 56=base ; msg recieved as order
                        if (('35=D' in rx[0]) or ('35=G' in rx[0]) or ('35=F' in rx[0])):
                            x = string.replace(rx[0], '|','\x01')
                            parser = simplefix.FixParser()
                            parser.append_buffer(x)
                            msg = parser.get_message()
                            tempfile2.write(" ".join(line.split(" ")[:2])+","+str(msg.get(128))+","+str(msg.get(35)) + ","+str(msg.get(39)) + "," + str(msg.get(11)) + "," + str(msg.get(41)) + "," + str(msg.get(52)) + "," + str(msg.get(60))  ) 
                            tempfile2.write("\n")    
                            
                                
            f.close()
    
            tempfile1.close()
            tempfile2.close()
                
                

            print 'Order and execution file aka temp1 and temp2 files generated successfully...'
                
    end_time = time()
    print "Execution time: {0} Seconds.... ".format(end_time - start_time)


def merge():
    
    df=pd.read_csv(outpath+"extractedfile1_20210129.csv", header=None, names=['datetime','128',
                                                                            '35','39','11','41','52','60'])
    df['11']="ITGETS_"+df['11'].astype(str)
    df1=pd.read_csv(outpath+"extractedfile2_20210129.csv", header=None, names=['datetime','128',
                                                                            '35','39','11','41','52','60'])
    
    temp=df1.merge(df[['11','35','39','52','60']], on=['11'], how='left', suffixes=("","_y"))
    temp.sort_values(by=['11'], inplace=True)
    temp.to_csv(outpath+"final.csv", index=False)
    
    
    
    
    '''
    f=open("final1.csv", 'a')
    for _, row in df1.iterrows():
        temp = (pd.DataFrame(row).T).merge(df[['11','35','39','52','60']], on=['11'], how='left', suffixes=('','_y'))
        itemp = temp.iloc[0:1,~temp.columns.str.endswith("_y")]
        temp = temp.iloc[:,temp.columns.str.endswith("_y")]
        temp.dropna(inplace=True, subset=['35_y','39_y'])
        break
        if temp.empty!=True:
            for _, irow in temp.iterrows():
                t = pd.DataFrame(irow).T.rename(columns={'52_y':"52_"+irow['39_y'], '60_y':"60_"+irow['39_y'] })
                t.reset_index(inplace=True, drop=True)
                t=t.iloc[:,-2:]
                itemp = pd.concat([itemp, t], axis=1)
                
       
        itemp = itemp.to_csv(header=False,index=False,sep=",")
        f.writelines(itemp)
        f.flush()
        os.fsync(f.fileno())                 
    f.close()
    '''                 
    


split1()
merge()