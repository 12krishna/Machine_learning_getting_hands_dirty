import pandas as pd
from datetime import datetime,timedelta
import logging
import numpy as np
from cassandra.cluster import Cluster
from time import time
import os
from collections import OrderedDict 
inputcolnames=["TradeId","ClientOrdID", "Og_ClientOrdID", "ClientName","Symbol","Series","Ticker","OrdType","LimitPrice","Side",
               "SecurityExchange","StartTime","EndTime","OrderQty","SOR","QuantityExecuted","AvgPx","NSEExecutedQty","BSEExecutedQty",
               "NSEExecutedAvg","BSEExecutedAvg","Remarks","Algorithm","LastFillTime", "ArrivalTime","Tag115","tag9271"]

#orderpath contains the path of the order file
#orderpath="D:\\devansh_new\\TCA_linux_codes\\orderfiles\\"
orderpath="/home/hadoop/tca_project/recomputefinal/"
log_path = "/home/hadoop/tca_project/tca_logs/"
market_start="09:00:00"
market_end="16:00:00"
#outpath contains the path of where the new order file with calclated parameters has to be stored 
#outpath="D:\\devansh_new\\TCA_linux_codes\\"
outpath="/home/hadoop/tca_project/output_files1/"

#for fetching data from cassandra put flag=1
flag=1

#data="/home/kotakalgo/TCA/Marketdata/"

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open("/home/hadoop/master/config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


logging.basicConfig(filename=log_path+"test_{}.log".format(datetime.now().date()),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")




#cluster = Cluster(['172.17.9.51'])
cluster = cassandra_configs_cluster()

logging.info('Cassandra Cluster connected...')
session = cluster.connect('rohit')
#connect to your keyspace and create a session using which u can execute cql commands 
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None

#print(df_temp.head())
#order=pd.read_csv(orderpath+'orders.csv',names=inputcolnames)
# log events in debug mode 


#order["Series"]=order["DisplaySymbol"]
#order=order.drop(['Tag1','Trader','NewAmendOrCancel','TimeInForce','Account','HandlInst','TransactTime','Price1','Price1Part','Slices','IC_DripSize','IC_DripPrice','IC_DiscloseQtyPercent','IC_Mode','IC_OrderQty','HD_MinGrabSize','HD_MaxParticipationPer','HD_Price','HD_Mode','HD_OrderQty','LDR_DiscloseQtyPercent','LDR_Limit','LDR_Price2','LDR_Diff','LDR_OrderQty','LDR_Slices','MPOV_OrderType','MPOV_Limit','MPOV_LimitPartPer','MPOV_Price1','MPOV_Price1PartPer','MPOV_SliceQty','MPOV_SliceInterval','MPOV_GDPPrice','MPOV_GDQPer','MPOV_GDPDripSize','MPOV_BlockQty','MPOV_OrderQty','MPOV_Mode','MPOV_Volume','TWAP_OrderType','TWAP_Limit','TWAP_LimitPartPer','TWAP_GDPPrice','TWAP_GDQPer','TWAP_BlockQty','TWAP_Slices','TWAP_OrderQty','TWAP_GDPDripSize','VWAP_OrderType','VWAP_Limit','VWAP_LimitPartPer','VWAP_GDPPrice','VWAP_GDQPer','VWAP_BlockQty','VWAP_Slices','VWAP_OrderQty','VWAP_GDPDripSize','FLT_Limit','FLT_Size','FLT_MinChaseSize','FLT_NumTicks','FLT_MinGrabSize','FLT_Grab','FLT_DiscloseQtyPercent','FLT_OrderQty','Name','OrdStatus','TraderOrClient','Entered','AlgoSliceSeconds','Ccy','QuantitySentToOMS','NSEExecutedVal','BSEExecutedVal','LastPx','Earned','PROCESSING_','State','DisplaySymbol','RefVol','ConsideredVol','MinParticipationPer','MaxTgtParticipation','MinTgtParticipation','RefVolSet','PrevVol','LimitExecShrs','LimitExecVal','LimitAvg','Price1ExecShrs','Price1ExecVal','Price1Avg','Price2ExecShrs','Price2ExecVal','Price2Avg','GDPExecShrs','GDPExecVal','GDPAvg','GDPEnabled','GDPStopped','TWAPEnabled','MinPrice1Part','MinPrice2Part','MaxTgtPrice1Part','MinTgtPrice1Part','MaxTgtPrice2Part','MinTgtPrice2Part','Price1ConsideredVol','Price2ConsideredVol','GDPConsideredVol','LimitBlockTrades','Price1BlockTrades','Price2BlockTrades','GDPBlockTrades','CurrLimitPart','CurrPrice1Part','CurrPrice2Part','CurrGDPPart','AlgoQuantity','MissedShares','LastSlice','LastSize','PrevSlice','TotalConsidered','SentQty','RemainingQty','PerCompleted','Bid','Ask','BidSize','AskSize','LTP','VolumeTraded','ClosePrice','SymbolSfx','ScripGroup','MaturityMonthYear','MaturityDay','SecurityType','OptAttribute','PutOrCall','StrikePrice','TickSize','LotSize','SecurityCode','SliceQty','CummSliceQty','TraderGroup','ConsideredVolMinusGDP','Price1ConsideredVolMinusGDP','Price2ConsideredVolMinusGDP','GDPConsideredVolMinusGDP','ExDestination','NSESecurityExchange','NSESymbol','NSEAccount','NSEScripGroup','NSESecurityCode','NSELotSize','NSETickSize','BSESecurityExchange','BSESymbol','BSEAccount','BSEScripGroup','BSESecurityCode','BSELotSize','BSETickSize','BSEPostFactor','NSEPostFactor','NSEDisplaySymbol','BSEDisplaySymbol','NSEReject','BSEReject','OnBehalfOfCompID','Randomize','OrderQtyInLots','QuantityExecutedInLots','RemainingQtyInLots'],axis=1)


def getbse_nse_close(bse_df,nse_df,sccode):
    bse_df=bse_df.loc[bse_df["symbol"].isin(['{}'.format(sccode)])] 
    bse_df.reset_index(drop=True,inplace=True)
    ltp_bse=bse_df["prevclose"][0]
                
    nse_df=nse_df.loc[nse_df["symbol"].isin(['{}'.format(sccode)])] 
    nse_df.reset_index(drop=True,inplace=True)
    ltp_nse=nse_df["prevclose"][0]
    if ltp_bse !=0:
        ltp=ltp_bse
    else:
        ltp=ltp_nse
        print ltp
    return float(ltp)

#function to extract startTime,endTime and Date in seperate date and time format from dateTime format
def timeformat(start,end):
    
    #start=start.astype(str)
    #logging.info('Date time conversion to a well-defined format...')
    startTime=pd.to_datetime(start, format='%Y %m %d %H:%M:%S')
    d=startTime.date()
    
    startTime=datetime.time(startTime)
    endTime=pd.to_datetime(end,format='%Y %m %d %H:%M:%S') 
    endTime=datetime.time(endTime)
    return(startTime,endTime,d)
#function to filter the data within startTime and endTime passed as parameters
def filterTime(startTime,endTime,symbol,df):
    #call to timeformat function to get date and time seperately
    if not df.empty:
        a=timeformat(startTime,endTime)
        start=a[0]
        end=a[1]
        d=a[2]
        #logging.info('Filtering data within startTime and endTime...')
        df_f = df.loc[df["symbol"]==symbol]
        if not df_f.empty:
            df_f['date'] = df_f.loc[:,'date'].astype(str)
            df_f['date'] = pd.to_datetime(df_f.loc[:,'date'],format='%Y %m %d %H:%M:%S')
            df_f['date'] = df_f.apply(lambda row: row['date'].date(),axis=1)
            #df_f["date"]=df_f["date"].date()
            #logging.info('Filtering data of a particular dated order...')
            df_f = df_f[df_f.date==d]
            if not df_f.empty:
                #print("drtd",df_f.time)
                df_f.loc[:,'time'] = df_f.loc[:,'time'].map(lambda x: str(x)[:-10])
                df_f.loc[:,'time'] = df_f.loc[:,'time'].astype(str)
                df_f.loc[:,'time'] = pd.to_datetime(df_f['time'],format='%H:%M:%S')
                df_f.loc[:,'time']=df_f['time'].apply(datetime.time)
                logging.info('Filtering data within a particular time interval...')
                df_f=df_f.loc[(df_f['time']>=start)&(df_f['time']<end)]
                #print df_f
            else:
                df_f=df_f
    else:
        df_f=df
    return(df_f)
#function to calculate vwap of the dataframe data passed
def calcvwap(df):
    if df.empty:
        vwap=0.0
    else:
        try:
                vwap=(df["price"]*df["volume"]).sum()/df["volume"].sum()
        except(df["volume"].sum()==0.0):
                vwap=0.0
    return(vwap)
#function to calculate twap of the df passed
def calctwap(df):
    if df.empty:
        twap=0.0
    else:
        try:
            twap=df["price"].sum()/df.shape[0]
        except(df.shape[0]==0):
            twap=0.0
    return(twap)
#function to calculate overall vwap   
def vwap(symbol,startTime,endTime,l,limit,side,df):
    logging.info('Call to the function for filtering the time in a particular interval')
    if df.empty:
        vwap=0.0
    else:
        df_f=filterTime(startTime,endTime,symbol,df)
        vwap=calcvwap(df_f)
    return(vwap)
#function to calculate overall twap  
def twap(symbol,startTime,endTime,l,limit,side,df):
    if df.empty:
        twap=0.0
    else:
        df_f=filterTime(startTime,endTime,symbol,df)
        twap=calctwap(df_f)
    return(twap)
#function to calculate vwap of NSE data      
def vwapNse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:    
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IS"]
        vwapNse=calcvwap(dfEx)
    else:
        vwapNse=0.0
        
    return(vwapNse)
#function to calculate twap of NSE data        
def twapNse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty: 
        df_f=filterTime(startTime,endTime,symbol,df)
        if not df_f.empty:
            dfEx=df_f[df_f.exchange=="IS"]
            twapNse=calctwap(dfEx)
        else:
            twapNse=0.0
    else:
        twapNse=0.0
    return(twapNse)
#function to calculate twap of BSE data      
def twapBse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        if not df_f.empty:  
            dfEx=df_f[df_f.exchange=="IB"]
            twapBse=calctwap(dfEx)
        else:
            twapBse=0.0
    else:
        twapBse=0.0
    return(twapBse)
#function to calculate vwap of BSE data  
def vwapBse(symbol,startTime,endTime,l,limit,side,df):
    logging.info("Vwap for Bse....")
    if not df.empty:  
        df_f=filterTime(startTime,endTime,symbol,df)
        if not df_f.empty:   
            dfEx=df_f[df_f.exchange=="IB"]
            vwapBse=calcvwap(dfEx)
        else:
            vwapBse=0.0
    else:
        vwapBse=0.0
    return(vwapBse)


#function to calculate overall volume  
def vol(symbol,startTime,endTime,df,exchange):
    vol=0.0
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        if exchange!='None':
            df_f = df_f[df_f.exchange==exchange]
        vol = 0.0 if df_f.empty else df_f["volume"].sum()
    else:
        vol=0.0
    return(vol)



    
def pwp_wt_avg_func(df, symbol, exchange, startTime, endTime, endflag, pwpPara):
    
    if exchange!='None':        
        if endflag==1:
            df=filterTime(startTime,' '.join([endTime.split(" ")[0],'15:30:00.000']),symbol,df)
            df=df[df.exchange==exchange]
        else:
            df=filterTime(startTime,endTime,symbol,df)
            df=df[df.exchange==exchange]
    else:
        if endflag==1:
            df=filterTime(startTime,' '.join([endTime.split(" ")[0],'15:30:00.000']),symbol,df)
        else:
            df=filterTime(startTime,endTime,symbol,df)
                   
    if not df.empty:
        df["cum_vol"]=df.volume.cumsum()
        df['prev_cum_sum'] = df['cum_vol'].shift(1)
        df = df.fillna(0)
        
        df['new_vol'] = np.where(df['cum_vol'] > pwpPara,pwpPara-df['prev_cum_sum'],df['volume'])
        df['new_vol'] = np.where(df['new_vol'] > 0,df['new_vol'],0)
        df = df[df['new_vol'] > 0]
        
        return (df["price"]*df["new_vol"]).sum(), df["new_vol"].sum()
        
    else:
        return 0,0 
    
   



def pwp_calc(grp, df):
    
    new_grp = pd.DataFrame()
    for index,row in grp.iterrows():        
        #startTime=pd.to_datetime(row["StartTime"], format='%Y %m %d %H:%M:%S')        
        temp_filtered = grp[grp["Og_ClientOrdID"] == row["ClientOrdID"]]
        if ((row['Tot_QuantityExecuted'] >= row['OrderQty']) and (len(temp_filtered)==0)):
            row["EndTime"] = row["LastFillTime"]
        new_grp = new_grp.append(row, ignore_index=True)
    
    # get all pwp parameters 
    pwp_dict = OrderedDict()
    for i in ['','Nse','Bse','Limit','LimitNse','LimitBse']:      
        if i.endswith('Nse'):
            # NSE PWP params
            pwp_dict['Pwp10'+i]=new_grp["NSE_Tot_QuantityExecuted"].values[-1]*10
            pwp_dict['Pwp15'+i]=int(float(new_grp["NSE_Tot_QuantityExecuted"].values[-1])*6.67)
            pwp_dict['Pwp20'+i]=new_grp["NSE_Tot_QuantityExecuted"].values[-1]*5
            pwp_dict['Pwp25'+i]=new_grp["NSE_Tot_QuantityExecuted"].values[-1]*4
            pwp_dict['Pwp30'+i]=int(float(new_grp["NSE_Tot_QuantityExecuted"].values[-1])*3.34)         
            
        elif i.endswith('Bse'):
            # BSE pwp params
            pwp_dict['Pwp10'+i]=new_grp["BSE_Tot_QuantityExecuted"].values[-1]*10
            pwp_dict['Pwp15'+i]=int(float(new_grp["BSE_Tot_QuantityExecuted"].values[-1])*6.67)
            pwp_dict['Pwp20'+i]=new_grp["BSE_Tot_QuantityExecuted"].values[-1]*5
            pwp_dict['Pwp25'+i]=new_grp["BSE_Tot_QuantityExecuted"].values[-1]*4
            pwp_dict['Pwp30'+i]=int(float(new_grp["BSE_Tot_QuantityExecuted"].values[-1])*3.34)
        else:
            pwp_dict['Pwp10'+i]=new_grp["Tot_QuantityExecuted"].values[-1]*10
            pwp_dict['Pwp15'+i]=int(float(new_grp["Tot_QuantityExecuted"].values[-1])*6.67)
            pwp_dict['Pwp20'+i]=new_grp["Tot_QuantityExecuted"].values[-1]*5
            pwp_dict['Pwp25'+i]=new_grp["Tot_QuantityExecuted"].values[-1]*4
            pwp_dict['Pwp30'+i]=int(float(new_grp["Tot_QuantityExecuted"].values[-1])*3.34)
            
    pwp_dict_market = OrderedDict({ key:pwp_dict[key] for key in pwp_dict.keys() if 'Limit' not in key })
    pwp_dict_limit =  OrderedDict({ key:pwp_dict[key] for key in pwp_dict.keys() if 'Limit' in key })    
    
    # market pwp params
    logging.info("Market pwp param computation for {}".format(new_grp['Ticker'].values[0]))
    for pwpkey,pwpvalue in pwp_dict_market.items():  
        result = []; remaining_vol=pwpvalue   
        for index, row in new_grp.iterrows():            
            if remaining_vol!=0:
                values, vol = pwp_wt_avg_func(df[df['symbol']==row['Ticker']],row['Ticker'],
                                'IS' if pwpkey.endswith('Nse') else 'IB' if pwpkey.endswith('Bse') else 'None' ,
                                row['StartTime'], row['EndTime'],row['endflag'], remaining_vol)
                result.append([values,vol])
                remaining_vol = remaining_vol-vol
        result = pd.DataFrame(result, columns=['values','vol'])
        pwp=0.0
        try:
            pwp = result['values'].sum()/result['vol'].sum()
        except:
            logging.info("Exception : div by zero ; pwp param computation for {}".format(new_grp['Ticker'].values[0]))
        new_grp[pwpkey] = pwp
      
    
    # limit pwp params
    logging.info("Market pwp param computation for {}".format(new_grp['Ticker'].values[0]))
    for pwpkey,pwpvalue in pwp_dict_limit.items():  
        result = []; remaining_vol=pwpvalue   
        for index, row in new_grp.iterrows():                        
            if remaining_vol!=0:
                # filter on limit order
                df_f=df[df['symbol']==row['Ticker']]
                if row['OrdType']=='LMT':
                    if row['Side']=="BUY":
                        df_f=df.loc[df['price']<=float(row['LimitPrice'])]
                    else:
                        df_f=df.loc[df['price']>=float(row['LimitPrice'])]
                         
                
                values, vol = pwp_wt_avg_func(df_f,row['Ticker'],
                                'IS' if pwpkey.endswith('Nse') else 'IB' if pwpkey.endswith('Bse') else 'None' ,
                                row['StartTime'], row['EndTime'],row['endflag'], remaining_vol)
                result.append([values,vol])
                remaining_vol = remaining_vol-vol
        result = pd.DataFrame(result, columns=['values','vol'])
        pwp=0.0
        try:
            pwp = result['values'].sum()/result['vol'].sum()
        except:
            logging.info("Exception : div by zero ; pwp param computation for {}".format(new_grp['Ticker'].values[0]))
        new_grp[pwpkey] = pwp
       
        
    return new_grp
    
    
       
    
    
#function to return arrival price of NSE data
def getnse_close(nse_df,sccode,curr_date):
    nse_df=nse_df.loc[nse_df["symbol"].isin(['{}'.format(sccode)])]
    nse_df.reset_index(drop=True,inplace=True)
    
    try:
        ltp=nse_df["prevclose"][0]
        return float(ltp)        
    except :
        print "Data not present for {} in  EQ series; fetch data from BE series".format(sccode)
        logging.info("Data not present for {} in  EQ series; fetch data from BE series".format(sccode))
        query_oi = session.execute("SELECT * FROM cm_bhavcopy where timestamp ='{}' and series='BE' and symbol='{}' ALLOW FILTERING".format(curr_date,sccode))
        query_oi = query_oi._current_rows
        ltp = query_oi['prevclose'][0]
        return float(ltp)
        
        
    

def getbse_close(bse_df,sccode):
    bse_df=bse_df.loc[bse_df["sc_code"].isin(['{}'.format(sccode)])]
    bse_df.reset_index(drop=True,inplace=True)
    ltp=bse_df["prevclose"][0]
    #print ltp
    return float(ltp)
    
def ltp(symbol,startTime,endTime,arrivalTime,sccode,l,limit,side,df,nse_df,bse_df):
    m_s="09:15:00"
    m_s=datetime.strptime(m_s,'%H:%M:%S').time()
    market_s="09:00:00"
    market_s=datetime.strptime(market_s,'%H:%M:%S').time()
    #print "start time {} and arrival time {}".format(startTime,arrivalTime)
    curr_date = datetime.strptime(startTime,'%Y-%m-%d %H:%M:%S.%f').date()
    market_s = datetime.combine(curr_date,market_s)
    m_s = datetime.combine(curr_date,m_s)
    st= datetime.strptime(startTime, '%Y-%m-%d %H:%M:%S.%f') #start time 
    at= datetime.strptime(arrivalTime, '%Y-%m-%d %H:%M:%S.%f') #arrivaltime
    
    print "start time {} and arrival time {}".format(st,at)
    if at <=  market_s:
        ltp=getbse_nse_close(bse_df,nse_df,sccode)
    elif (at > market_s and at<=m_s):
        if df.empty:
            ltp=getbse_nse_close(bse_df,nse_df,sccode)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange.isin(["IS","IB"])]
            if dfEx.empty:
                ltp=getbse_nse_close(bse_df,nse_df,sccode)
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                #print ltp_df
                ltp=ltp_df.iloc[0]["price"]
    elif (at > m_s):
        if df.empty :
            ltp=getbse_nse_close(bse_df,nse_df,sccode)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange.isin(["IS","IB"])]
            if dfEx.empty:
                ltp=getbse_nse_close(bse_df,nse_df,sccode)
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                #print ltp_df
                ltp=ltp_df.iloc[0]["price"]
    else:
        ltp=0.0
    #print "---",ltp
    return float(ltp)  

def ltpNse(symbol,startTime,endTime,arrivalTime,sccode,l,limit,side,df,nse_df):
    m_s="09:15:00"
    m_s=datetime.strptime(m_s,'%H:%M:%S').time()
    market_s="09:00:00"
    market_s=datetime.strptime(market_s,'%H:%M:%S').time()
    #print startTime, endTime, arrivalTime
    #st= datetime.strptime(startTime, '%Y-%m-%d %H:%M:%S').time() #start time 
    curr_date = datetime.strptime(startTime,'%Y-%m-%d %H:%M:%S.%f').date()
    market_s = datetime.combine(curr_date,market_s)
    m_s = datetime.combine(curr_date,m_s)
    at= datetime.strptime(arrivalTime, '%Y-%m-%d %H:%M:%S.%f') #arrivaltime
    if at<=market_s:
        ltp=getnse_close(nse_df,sccode,curr_date)
    elif at>market_s and at<=m_s:
        if df.empty:
            ltp=getnse_close(nse_df,sccode,curr_date)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange=="IS"]
            if dfEx.empty:
                ltp=getnse_close(nse_df,sccode,curr_date)
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                ltp=ltp_df.iloc[0]["price"]    
    elif (at > m_s): 
        if df.empty:
            ltp=getnse_close(nse_df,sccode,curr_date)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange=="IS"]
            if dfEx.empty:
                ltp=getnse_close(nse_df,sccode,curr_date)
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                ltp=ltp_df.iloc[0]["price"]
    else:
        ltp=0.0
    return float(ltp)

def ltpBse(symbol,startTime,endTime,arrivalTime,sccode,l,limit,side,df,bse_df):
    m_s="09:15:00"
    m_s=datetime.strptime(m_s,'%H:%M:%S').time()
    market_s="09:00:00"
    
    market_s=datetime.strptime(market_s,'%H:%M:%S').time()
    curr_date = datetime.strptime(startTime,'%Y-%m-%d %H:%M:%S.%f').date()
    market_s = datetime.combine(curr_date,market_s)
    m_s = datetime.combine(curr_date,m_s)
#    st= datetime.strptime(startTime, '%Y-%m-%d %H:%M:%S').time() #start time 
    at= datetime.strptime(arrivalTime, '%Y-%m-%d %H:%M:%S.%f') #arrivaltime
    if at<=market_s:
        ltp=getbse_close(bse_df,sccode)
    elif at>market_s and at<=m_s:
        if df.empty:
            ltp=getbse_close(bse_df,sccode)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange=="IB"]
            if dfEx.empty:
                ltp=0.0
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                ltp=ltp_df.iloc[0]["price"]
    
    elif (at > m_s):
        if df.empty:
            ltp=getbse_close(bse_df,sccode)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange=="IB"]
            if dfEx.empty:
                ltp=0.0
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                ltp=ltp_df.iloc[0]["price"]
    else:
        ltp=0.0
    return float(ltp)

    
def averageTradeSize(symbol,startTime,endTime,l,limit,side,df,exchange):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        if exchange!='None':
            df_f=df_f[df_f.exchange==exchange]
        if df_f.empty:
            AvgTradeSize=0.0
        else:
            try:
                AvgTradeSize=df_f["volume"].sum()/df_f.shape[0]
            except(df_f.shape[0]==0):
                AvgTradeSize=0.0
    else:
        AvgTradeSize=0.0
    return(AvgTradeSize)
    


#define rows fetched from cassandra to be a pandas dataframe
def getData(session,exchange,symbol,order_date):
    print session, exchange, symbol, order_date
    query='SELECT * FROM quotedata WHERE token(exchange,date)=token(\'{1}\',\'{2}\') and symbol=\'{0}\' ALLOW FILTERING;'.format(symbol,exchange,order_date)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    return(rows)
    
def myround(x, prec=2, base=.05):
  return round(base * round(float(x)/base),prec)

def fetch_nse_bhavcopy_cassandra(date):
    logging.info("Read data from cm_bhavcopy for {}".format(date))
    query_oi = session.execute("SELECT * FROM cm_bhavcopy where timestamp ='{}' and series='EQ' ALLOW FILTERING".format(date))
    query_oi = query_oi._current_rows
    logging.info("Successfully read")
    return query_oi

def fetch_bse_bhavcopy_cassandra(date):
    logging.info("Read data from bse_bhavcopy for {}".format(date))
    query_oi = session.execute("SELECT * FROM bse_bhavcopy where trading_date ='{}' ALLOW FILTERING".format(date))
    query_oi = query_oi._current_rows
    logging.info("Successfully read")
    return query_oi

def final_output(flag,outpath,market_start,market_end,d):
#    d=datetime.now().date() - timedelta(days=1)
    nse_df=fetch_nse_bhavcopy_cassandra(d)
    bse_df=fetch_bse_bhavcopy_cassandra(d)
    for r, d, f in os.walk(orderpath):
        for file in f:
            file_name = os.path.join(r, file)
            print(file_name)
            logging.info("Reading order file {}".format(file_name))
            base = os.path.basename(file_name)[6:14]
            print(file_name, base)
            start_my = time()
            order=pd.read_csv(file_name)
            noOfRows=order.shape[0]
            colnames=["IntervalVwap","IntervalVwapNse","IntervalVwapBse","IntervalVwapLimit","AvgPx_vs_IntervalVwapLimit",
                      "IntervalVwapLimitNse","IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap",
                      "DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse","IntervalTwapBse",
                      "IntervalTwapLimit","AvgPx_vs_IntervalTwapLimit","IntervalTwapLimitNse","IntervalTwapLimitBse","DayTwapLimit",
                      "DayTwapLimitNse","DayTwapLimitBse","AvgPx_vs_IntervalVwap","AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit",
                      "AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","AvgPx_vs_DayTwapLimit","AvgPx_vs_Pwp","Pwp20Nse","Pwp20Bse","Pwp20",
                      "Pwp20Limit","AvgPx_vs_PwpLimit","Pwp20LimitNse","Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize",
                      "IntervalVolNse","IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit",
                      "DayVolNse","DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse",
                      "volExecBse_intervalVolBse","volExec_vs_IntervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse",
                      "volExec_vs_IntervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse","volExec_vs_DayVol",
                      "volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_vs_DayVolLimit","ArrivalPriceNse","ArrivalPriceBse",
                      "ArrivalPrice","AvgPx_vs_ArrivalPx","Pwp10Nse","Pwp10Bse","Pwp10","Pwp10Limit","Pwp10LimitNse","Pwp10LimitBse",
                      "Pwp15Nse","Pwp15Bse","Pwp15","Pwp15Limit","Pwp15LimitNse","Pwp15LimitBse","Pwp25Nse","Pwp25Bse","Pwp25",
                      "Pwp25Limit","Pwp25LimitNse","Pwp25LimitBse","Pwp30Nse","Pwp30Bse","Pwp30","Pwp30Limit","Pwp30LimitNse",
                      "Pwp30LimitBse"]
            col=inputcolnames+colnames
            result = pd.DataFrame()
            report_result = pd.DataFrame()
            n=np.zeros((noOfRows,len(colnames)))
            dummyDf=pd.DataFrame(n,columns=colnames)
            #print dummyDf.shape[0]
            order['tmp']=1
            dummyDf['tmp']=1
            orders= order.merge(dummyDf, on='tmp',how='outer',left_index=True, right_index=True)
            orders = orders.drop('tmp', axis=1)
            orders.fillna(0.0)
            #orders = orders[orders['SOR']=="N"]
        		
            grouped_orders = orders.groupby('TradeId', as_index=False).agg({'QuantityExecuted':'sum','NSEExecutedQty':'sum',
                                           'BSEExecutedQty':'sum'})
            grouped_orders.rename(columns={'QuantityExecuted':'Tot_QuantityExecuted','NSEExecutedQty':'NSE_Tot_QuantityExecuted',
                                           'BSEExecutedQty':'BSE_Tot_QuantityExecuted'}, inplace=True)
            final_orders = orders.merge(grouped_orders, on='TradeId', how='left')
            final_orders.sort_values(['Symbol','TradeId','EndTime'], inplace=True)
            
            # get the last occurance of the order            
            temp = final_orders.groupby(['TradeId'],as_index=False).tail(1)
            temp['endflag'] = 1
            final_orders = final_orders.merge(temp[['endflag']], how='left', left_index=True, right_index=True)
            final_orders['endflag'].fillna(0, inplace=True)
            
            # get quote data for all tickers 
            starttime = time()
            df_f = pd.DataFrame()
            for ticker in final_orders['Ticker'].unique():  
                d = pd.to_datetime(final_orders[final_orders['Ticker']==ticker]['StartTime'].values[0]).date()
                df_f = df_f.append(getData(session,"IS",ticker,d), ignore_index=True)
                df_f = df_f.append(getData(session,"IB",ticker,d), ignore_index=True)
            df_f["price"] = df_f["price"].apply(myround)
            print "Quote data retrival time {}".format(time()-starttime)
            logging.info("Quote data retrival time {}".format(time()-starttime))
            
            
            # perform pwp calc on groupby trade id 
            starttime = time()
            pwp_df = final_orders.groupby(['TradeId'],as_index=False).apply(lambda grp: pwp_calc(grp, df_f))
            final_orders = pwp_df[list(final_orders.columns)]
            print "All PWP data calc time {}".format(time()-starttime)
            logging.info("All PWP data calc time {}".format(time()-starttime))
            
            starttime = time()
            for index,row in final_orders.iterrows():
                print row['Ticker']
                df = df_f[df_f['symbol']==row['Ticker']]
                startTime=pd.to_datetime(row["StartTime"], format='%Y %m %d %H:%M:%S')
                #Extracting the date of the order
                try:
                    d=startTime.date()
                    d=d.strftime('%Y-%m-%d')
                except ValueError:
                    correctDate=False
                    print("Date error",str(correctDate))              
                
                
                t1=d+" "+market_start
                t2=d+" "+market_end
                
                if df.empty:
                    logging.info("DataFile is Empty...")
                    print("no data present for {}".format(row['Ticker']))
                else:
                    #print df.head()
                    #calculating all the parameters and storing them in the respective variables
                    IntervalVolNse=vol(row["Ticker"],row["StartTime"],row["EndTime"],df,'IS')
                    IntervalVolBse=vol(row["Ticker"],row["StartTime"],row["EndTime"],df,'IB')
                    IntervalVwap=vwap(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalTwap=twap(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalVwapBse=vwapBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalVwapNse=vwapNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalTwapNse=twapNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalTwapBse=twapBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                                        
                    DayVol=vol(row["Ticker"],t1,t2,df,'None')
                    DayVolNse=vol(row["Ticker"],t1,t2,df,'IS')
                    DayVolBse=vol(row["Ticker"],t1,t2,df,'IB')
                    DayVwapNse=vwapNse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayVwapBse=vwapBse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayTwapNse=twapNse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayTwapBse=twapBse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayVwap=vwap(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayTwap=twap(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalVol=vol(row["Ticker"],row["StartTime"],row["EndTime"],df,'None')
                    if(row["SecurityExchange"] == "NSE"):
                        ArrivalPriceNse=ltpNse(row["Ticker"],row["StartTime"],row["EndTime"],row["ArrivalTime"],row["Symbol"],row["OrdType"],row["LimitPrice"],row["Side"],df,nse_df)
                        ArrivalPriceBse=ArrivalPriceNse
                        ArrivalPrice=ArrivalPriceNse
                    else:
                        ArrivalPriceBse=ltpBse(row["Ticker"],row["StartTime"],row["EndTime"],row["ArrivalTime"],row["Symbol"],row["OrdType"],row["LimitPrice"],row["Side"],df,bse_df)
                        ArrivalPriceNse=ArrivalPriceBse
                        ArrivalPrice=ArrivalPriceBse
                         #calculating all the limit adjucted parameter by filtering the dataframe within limit
                    if(row["OrdType"]=="LMT"):
                        if row["Side"]=="BUY":
                            dfInLimit=df.loc[df['price']<=float(row["LimitPrice"])]
                        else:
                            dfInLimit=df.loc[df['price']>=float(row["LimitPrice"])]
                            #print dfInLimit.head()
                        IntervalVolLimitNse=vol(row["Ticker"],row["StartTime"],row["EndTime"],dfInLimit,'IS')
                        IntervalVolLimitBse=vol(row["Ticker"],row["StartTime"],row["EndTime"],dfInLimit,'IB')
                        IntervalVwapLimit=vwap(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalTwapLimit=twap(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalVwapLimitNse=vwapNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalVwapLimitBse=vwapBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalTwapLimitNse=twapNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalTwapLimitBse=twapBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayVolLimitNse=vol(row["Ticker"],t1,t2,dfInLimit,'IS')
                        DayVolLimitBse=vol(row["Ticker"],t1,t2,dfInLimit,'IB')
                        DayVolLimit=vol(row["Ticker"],t1,t2,dfInLimit,'None')
                        DayVwapLimit=vwap(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayVwapLimitNse=vwapNse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayTwapLimit=twap(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayVwapLimitBse=vwapBse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayTwapLimitNse=twapNse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayTwapLimitBse=twapBse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        
                           
                        AvgTradeSizeNse=averageTradeSize(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],
                                                         row["LimitPrice"],row["Side"],dfInLimit,'IS')
                        AvgTradeSizeBse=averageTradeSize(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],
                                                         row["LimitPrice"],row["Side"],dfInLimit,'IB')
                        AvgTradeSize=averageTradeSize(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],
                                                      row["LimitPrice"],row["Side"],dfInLimit,'None')
                        IntervalVolLimit=vol(row["Ticker"],row["StartTime"],row["EndTime"],dfInLimit,'None')
                        #If order type is market order then else condition works and limit adjusted parameters will be equal to interval parameters
                    else:
                        IntervalVolLimitNse=IntervalVolNse
                        IntervalVolLimitBse=IntervalVolBse
                        IntervalVwapLimitNse=IntervalVwapNse
                        IntervalVwapLimitBse=IntervalVwapBse
                        IntervalTwapLimitNse=IntervalTwapNse
                        IntervalTwapLimitBse=IntervalTwapBse
                        IntervalVwapLimit=IntervalVwap
                        IntervalTwapLimit=IntervalTwap
                        DayVolLimitNse=DayVolNse
                        DayVolLimitBse=DayVolBse
                        DayVolLimit=DayVol
                        DayVwapLimit=DayVwap
                        DayVwapLimitNse=DayVwapNse
                        DayVwapLimitBse=DayVwapBse
                        DayTwapLimit=DayTwap
                        DayTwapLimitNse=DayTwapNse
                        DayTwapLimitBse=DayTwapBse
                        
                        
                        AvgTradeSizeNse=averageTradeSize(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],
                                                         row["LimitPrice"],row["Side"],df,'IS')
                        AvgTradeSizeBse=averageTradeSize(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],
                                                         row["LimitPrice"],row["Side"],df,'IB')
                        AvgTradeSize=averageTradeSize(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],
                                                      row["LimitPrice"],row["Side"],df,'None')
                        IntervalVolLimit=IntervalVol
                        #if SOR 'Y' then giving both the NSE and BSE parameters values calculated above  
                    if(row["SOR"]=="Y"):
                        row["IntervalVolNse"]=IntervalVolNse
                        row["IntervalVwapNse"]=IntervalVwapNse
                        row["IntervalTwapNse"]=IntervalTwapNse
                        row["ArrivalPriceNse"]=ArrivalPriceNse
                        
                        
                        
                        row["IntervalVolLimitNse"]=IntervalVolLimitNse
                        row["IntervalVolLimitBse"]=IntervalVolLimitBse
                        row["IntervalVolBse"]=IntervalVolBse
                        row["IntervalVwapBse"]=IntervalVwapBse
                        row["IntervalTwapBse"]=IntervalTwapBse
                        row["AvgTradeSizeNse"]=AvgTradeSizeNse
                        row["AvgTradeSizeBse"]=AvgTradeSizeBse
                        row["ArrivalPriceBse"]=ArrivalPriceBse
                        row["IntervalVwapLimitNse"]=IntervalVwapLimitNse
                        row["IntervalVwapLimitBse"]=IntervalVwapLimitBse
                        row["IntervalTwapLimitNse"]=IntervalTwapLimitNse
                        row["IntervalTwapLimitBse"]=IntervalTwapLimitBse
                        #if SOR 'N' and order exchange is NSE then giving NSE parameters values calculated above  
                    elif(row["SOR"]=="N" and df.loc[df["exchange"]=="IS"].shape[0]>0 and (row["SecurityExchange"]=="NSE")):
                        row["IntervalVolNse"]=IntervalVolNse
                        row["IntervalVolLimitNse"]=IntervalVolLimitNse
                        row["AvgTradeSizeNse"]=AvgTradeSizeNse
                        
                       
                        
                        row["IntervalVwapNse"]=IntervalVwapNse
                        row["IntervalTwapNse"]=IntervalTwapNse
                        row["ArrivalPriceNse"]=ArrivalPriceNse
                        row["IntervalVwapLimitNse"]=IntervalVwapLimitNse
                        row["IntervalTwapLimitNse"]=IntervalTwapLimitNse
                        #if SOR 'N' and order exchange is BSE then giving BSE parameters values calculated above  
                    elif(row["SOR"]=="N" and df.loc[df["exchange"]=="IB"].shape[0]>0 and (row["SecurityExchange"]=="BSE")):
                        row["IntervalVolBse"]=IntervalVolBse
                        row["IntervalVolLimitBse"]=IntervalVolLimitBse
                        row["AvgTradeSizeBse"]=AvgTradeSizeBse
                        row["IntervalTwapBse"]=IntervalTwapBse
                        row["IntervalVwapBse"]=IntervalVwapBse
                        row["IntervalVwapLimitBse"]=IntervalVwapLimitBse
                        row["IntervalTwapLimitBse"]=IntervalTwapLimitBse
                        row["ArrivalPriceBse"]=ArrivalPriceBse
                        
                        
                    #storing parameters in order file column  which will be present irrespective of SOR value
                    row["IntervalVwap"]=IntervalVwap
                    row["IntervalVwapLimit"]=IntervalVwapLimit
                    row["IntervalTwapLimit"]=IntervalTwapLimit
                    row["IntervalTwap"]=IntervalTwap
                    row["IntervalVolLimit"]=IntervalVolLimit
                    row["IntervalVol"]=IntervalVol
                    row["AvgTradeSize"]=AvgTradeSize
                    row["ArrivalPrice"]=ArrivalPrice
                    row["DayVolLimitNse"]=DayVolLimitNse
                    row["DayVolLimitBse"]=DayVolLimitBse
                    row["DayVolLimit"]=DayVolLimit
                    
                    
                    row["DayVwap"]=DayVwap
                    row["DayTwap"]=DayTwap
                    row["DayVwapNse"]=DayVwapNse
                    row["DayVwapBse"]=DayVwapBse
                    row["DayTwapNse"]=DayTwapNse
                    row["DayTwapBse"]=DayTwapBse
                    row["DayVwapLimitNse"]=DayVwapLimitNse
                    row["DayVolLimit"]=DayVolLimit
                    row["DayVol"]=DayVol
                    row["DayVolNse"]=DayVolNse
                    row["DayVolBse"]=DayVolBse
                    row["DayVwapLimit"]=DayVwapLimit
                    row["DayVwapLimitBse"]=DayVwapLimitBse
                    row["DayTwapLimit"]=DayTwapLimit
                    row["DayTwapLimitNse"]=DayTwapLimitNse
                    row["DayTwapLimitBse"]=DayTwapLimitBse
                    #row["AvgPx"]=float(row["AvgPx"])
                    #execution volume percent of interval volume 
                    if row["IntervalVol"]!=0.0:
                        row["volExec_vs_IntervalVol"]=((row["QuantityExecuted"]*1.0)/row["IntervalVol"])*100.0  #calculating volumeExecuted by order vs volume in that interval
                    if row["IntervalVolNse"]!=0.0:
                        row["volExecNse_intervalVolNse"]=((row["NSEExecutedQty"]*1.0)/row["IntervalVolNse"])*100.0
                        #print row["volExecNse_intervalVolNse"]
                    if row["IntervalVolBse"]!=0.0:
                        row["volExecBse_intervalVolBse"]=(float(row["BSEExecutedQty"])/row["IntervalVolBse"])*100.0
                        #print row["volExecBse_intervalVolBse"]
                    if row["IntervalVolLimit"]!=0.0:
                        row["volExec_vs_IntervalVolLimit"]=((row["QuantityExecuted"]*1.0)/row["IntervalVolLimit"])*100.0  #calculating volumeExecuted by order vs volume in that interval
                        #print row["volExec_intervalVol"]
                    if row["IntervalVolLimitNse"]!=0.0:
                        row["volExecNse_intervalVolLimitNse"]=(float(row["NSEExecutedQty"])/row["IntervalVolLimitNse"])*100.0
                        #print row["volExecNse_intervalVolNse"]
                    if row["IntervalVolLimitBse"]!=0.0:
                        row["volExecBse_intervalVolLimitBse"]=(float(row["BSEExecutedQty"])/row["IntervalVolLimitBse"])*100.0
                        #print row["volExecBse_intervalVolBse"]
                    #percentage calculation quantity executed vs Days vol parameters
                    if row["DayVol"]!=0.0:
                        row["volExec_vs_DayVol"]=(float(row["QuantityExecuted"])/row["DayVol"])*100.0
                    if row["DayVolNse"]!=0.0:
                        row["volExecNse_DayVolNse"]=(float(row["NSEExecutedQty"])/row["DayVolNse"])*100.0
                    if row["DayVolBse"]!=0.0:
                        row["volExecBse_DayVolBse"]=(float(row["BSEExecutedQty"])/row["DayVolBse"])*100.0
                    if row["DayVolLimit"]!=0.0:
                        row["volExec_vs_DayVolLimit"]=(float(row["QuantityExecuted"])/row["DayVolLimit"])*100.0
                    if row["DayVolLimitNse"]!=0.0:
                        row["volExecNse_DayVolLimitNse"]=(float(row["NSEExecutedQty"])/row["DayVolLimitNse"])*100.0
                    if row["DayVolLimitBse"]!=0.0:
                        row["volExecBse_DayVolLimitBse"]=(float(row["BSEExecutedQty"])/row["DayVolLimitBse"])*100.0
                    #calculting values of avgPrice vs calculated parameters vwap,twap
                    #print "Interval VWAP:",row["IntervalVwap"],row["AvgPx"],
                    if row["Side"]=="BUY":
                        if row["IntervalVwap"]!=0.0:
                            row["AvgPx_vs_IntervalVwap"]=(float(row["IntervalVwap"]-row["AvgPx"])/row["IntervalVwap"])*10000
                        if row["IntervalVwapLimit"]!=0.0:
                            row["AvgPx_vs_IntervalVwapLimit"]=((row["IntervalVwapLimit"]-row["AvgPx"])/row["IntervalVwapLimit"])*10000
                        if row["DayVwap"]!=0.0:
                            row["AvgPx_vs_DayVwap"]=((row["DayVwap"]-row["AvgPx"])/row["DayVwap"])*10000
                        if row["DayVwapLimit"]!=0.0:
                            row["AvgPx_vs_DayVwapLimit"]=((row["DayVwapLimit"]-row["AvgPx"])/row["DayVwapLimit"])*10000
        
                        if row["IntervalTwap"]!=0.0:
                            row["AvgPx_vs_IntervalTwap"]=((row["IntervalTwap"]-row["AvgPx"])/row["IntervalTwap"])*10000
                        if row["IntervalTwapLimit"]!=0.0:
                            row["AvgPx_vs_IntervalTwapLimit"]=((row["IntervalTwapLimit"]-row["AvgPx"])/row["IntervalTwapLimit"])*10000
                        if row["DayTwap"]!=0.0:
                            row["AvgPx_vs_DayTwap"]=((row["DayTwap"]-row["AvgPx"])/row["DayTwap"])*10000
                        if row["DayTwapLimit"]!=0.0:
                            row["AvgPx_vs_DayTwapLimit"]=((row["DayTwapLimit"]-row["AvgPx"])/row["DayTwapLimit"])*10000
                        
                        if row["Pwp20"]!=0.0:
                            row["AvgPx_vs_20Pwp"]=((row["Pwp20"]-row["AvgPx"])/row["Pwp20"])*10000
                        if row["Pwp20Limit"]!=0.0:
                            row["AvgPx_vs_20PwpLimit"]=((row["Pwp20Limit"]-row["AvgPx"])/row["Pwp20Limit"])*10000
                            
                        if row["Pwp10"]!=0.0:
                            row["AvgPx_vs_10Pwp"]=((row["Pwp10"]-row["AvgPx"])/row["Pwp10"])*10000
                        if row["Pwp10Limit"]!=0.0:
                            row["AvgPx_vs_10PwpLimit"]=((row["Pwp10Limit"]-row["AvgPx"])/row["Pwp10Limit"])*10000
                            
                        if row["Pwp15"]!=0.0:
                            row["AvgPx_vs_15Pwp"]=((row["Pwp15"]-row["AvgPx"])/row["Pwp15"])*10000
                        if row["Pwp15Limit"]!=0.0:
                            row["AvgPx_vs_15PwpLimit"]=((row["Pwp15Limit"]-row["AvgPx"])/row["Pwp15Limit"])*10000
                        
                        if row["Pwp25"]!=0.0:
                            row["AvgPx_vs_25Pwp"]=((row["Pwp25"]-row["AvgPx"])/row["Pwp25"])*10000
                        if row["Pwp25Limit"]!=0.0:
                            row["AvgPx_vs_25PwpLimit"]=((row["Pwp25Limit"]-row["AvgPx"])/row["Pwp25Limit"])*10000
                        
                        if row["Pwp30"]!=0.0:
                            row["AvgPx_vs_30Pwp"]=((row["Pwp30"]-row["AvgPx"])/row["Pwp30"])*10000
                        if row["Pwp30Limit"]!=0.0:
                            row["AvgPx_vs_30PwpLimit"]=((row["Pwp30Limit"]-row["AvgPx"])/row["Pwp30Limit"])*10000
                            
                        if row["ArrivalPrice"]!=0.0:
                            #print "Arrival price:" +  str(row["ArrivalPrice"]) + "|" + str(row["AvgPx"]) + "|" + str(type(row["ArrivalPrice"])) + "|" + str(type(row["AvgPx"]))
                            row["AvgPx_vs_ArrivalPx"]=(float(row["ArrivalPrice"]-row["AvgPx"])/row["ArrivalPrice"])*10000
                    else:
                        if row["DayVwap"]!=0.0:
                            row["AvgPx_vs_DayVwap"]=((-row["DayVwap"]+row["AvgPx"])/row["DayVwap"])*10000
                        if row["IntervalVwap"]!=0.0:
                            row["AvgPx_vs_IntervalVwap"]=(float(-row["IntervalVwap"]+row["AvgPx"])/row["IntervalVwap"])*10000
                        if row["DayVwapLimit"]!=0.0:
                            row["AvgPx_vs_DayVwapLimit"]=((-row["DayVwapLimit"]+row["AvgPx"])/row["DayVwapLimit"])*10000
                        if row["IntervalVwapLimit"]!=0.0:
                            row["AvgPx_vs_IntervalVwapLimit"]=((-row["IntervalVwapLimit"]+row["AvgPx"])/row["IntervalVwapLimit"])*10000
        
                        if row["DayTwap"]!=0.0:
                            row["AvgPx_vs_DayTwap"]=((-row["DayTwap"]+row["AvgPx"])/row["DayTwap"])*10000
                        if row["IntervalTwap"]!=0.0:
                            row["AvgPx_vs_IntervalTwap"]=((-row["IntervalTwap"]+row["AvgPx"])/row["IntervalTwap"])*10000
                        if row["DayTwapLimit"]!=0.0:
                            row["AvgPx_vs_DayTwapLimit"]=((-row["DayTwapLimit"]+row["AvgPx"])/row["DayTwapLimit"])*10000
                        if row["IntervalTwapLimit"]!=0.0:
                            row["AvgPx_vs_IntervalTwapLimit"]=((-row["IntervalTwapLimit"]+row["AvgPx"])/row["IntervalTwapLimit"])*10000
        
                        if row["Pwp20"]!=0.0:
                            row["AvgPx_vs_Pwp"]=((-row["Pwp20"]+row["AvgPx"])/row["Pwp20"])*10000
                        if row["Pwp20Limit"]!=0.0:
                            row["AvgPx_vs_20PwpLimit"]=((-row["Pwp20Limit"]+row["AvgPx"])/row["Pwp20Limit"])*10000
                            
                        if row["Pwp10"]!=0.0:
                            row["AvgPx_vs_10Pwp"]=((-row["Pwp10"]+row["AvgPx"])/row["Pwp10"])*10000
                        if row["Pwp10Limit"]!=0.0:
                            row["AvgPx_vs_10PwpLimit"]=((-row["Pwp10Limit"]+row["AvgPx"])/row["Pwp10Limit"])*10000

                        if row["Pwp15"]!=0.0:
                            row["AvgPx_vs_15Pwp"]=((-row["Pwp15"]+row["AvgPx"])/row["Pwp15"])*10000
                        if row["Pwp15Limit"]!=0.0:
                            row["AvgPx_vs_15PwpLimit"]=((-row["Pwp15Limit"]+row["AvgPx"])/row["Pwp15Limit"])*10000

                        if row["Pwp25"]!=0.0:
                            row["AvgPx_vs_25Pwp"]=((-row["Pwp25"]+row["AvgPx"])/row["Pwp25"])*10000
                        if row["Pwp25Limit"]!=0.0:
                            row["AvgPx_vs_25PwpLimit"]=((-row["Pwp25Limit"]+row["AvgPx"])/row["Pwp25Limit"])*10000

                        if row["Pwp30"]!=0.0:
                            row["AvgPx_vs_30Pwp"]=((-row["Pwp30"]+row["AvgPx"])/row["Pwp30"])*10000
                        if row["Pwp30Limit"]!=0.0:
                            row["AvgPx_vs_30PwpLimit"]=((-row["Pwp30Limit"]+row["AvgPx"])/row["Pwp30Limit"])*10000
        
                # the rows with calculated parameters aadded to daarrivalPx       
                logging.info("adding rows to result dataframe...")
                result=result.loc[~result.index.duplicated(keep='first')]
                row=row.loc[~row.index.duplicated(keep='first')]
                result=result.append(row)
                
                report_result=report_result.loc[~report_result.index.duplicated(keep='first')]
                report_result=report_result.append(row)
                
                #print row
                print "Time to calc other params {}".format(time()-starttime)
                logging.info("Time to calc other params {}".format(time()-starttime))
            #all the NaN values in a row of the parameter calculated filled by 0.0
            result=result.fillna(0.0)
            result=result.reindex(columns=col)
            
            report_result=report_result.fillna(0.0)
            report_result=report_result.reindex(columns=col)
            #print report_result.columns
            report_result.drop(labels=["ArrivalTime", "NSEExecutedQty","BSEExecutedQty","NSEExecutedAvg","BSEExecutedAvg","IntervalVwap","IntervalVwapNse","IntervalVwapBse","IntervalVwapLimitNse","IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap","DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse","IntervalTwapBse","IntervalTwapLimitNse","IntervalTwapLimitBse","DayTwapLimit","DayTwapLimitNse","DayTwapLimitBse","Pwp20Nse","Pwp20Bse","Pwp20","Pwp20LimitNse","Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse","IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse","DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","ArrivalPriceNse","ArrivalPriceBse","volExecBse_DayVolBse","volExecBse_DayVolLimitBse","volExecBse_intervalVolBse","volExecBse_intervalVolLimitBse","volExecNse_DayVolLimitNse","volExecNse_DayVolNse","volExecNse_intervalVolLimitNse","volExecNse_intervalVolNse","AvgPx_vs_IntervalVwap","AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit","AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","AvgPx_vs_DayTwapLimit","AvgPx_vs_Pwp","volExec_vs_IntervalVol","volExec_vs_IntervalVolLimit","volExec_vs_DayVol","volExec_vs_DayVolLimit"],axis=1,inplace=True)
            report_result.rename(columns={'Og_ClientOrdID':'Orig_Client_OrdID', 'ClientOrdID':'Client_OrdID', 'ClientName':'Client_Name', 'LimitPrice':'Limit_Price', 'SecurityExchange':'Security_Exchange', 'QuantityExecuted':'Quantity_Executed', 'LastFillTime':'Last_Fill_Time', 'IntervalVwapLimit':'Interval_Vwap_Limit', 'Algorithm':'Algo', 'StartTime':'Start_Time', 'EndTime':'End_Time', 'AvgPx_vs_IntervalVwapLimit':'AvgPx_vs_Interval_Vwap_Limit', 'IntervalTwapLimit':'Interval_Twap_Limit', 'AvgPx_vs_IntervalTwapLimit':'AvgPx_vs_Interval_Twap_Limit', 'ArrivalPrice':'Arrival_Price'}, inplace=True)
            
            
            
            #print result.head()
            logging.info("Writing to a new csv file...")
            #result.to_csv(outpath+"out.csv")
            
        #Writing to multiple sheets in Excel
            writer = pd.ExcelWriter(outpath+"output_new" + "_" + base + ".xlsx")
#            summary_writer = pd.ExcelWriter(outpath+"summary" + "_" + base + ".xlsx")
#            report_result.to_excel(writer, sheet_name="report", index=False, engine="xlsxwriter")
            result.to_excel(writer, sheet_name="complete_output", index=False)
            

            writer.save()
            
            print("Order file process time : " + str(time() - start_my))
            logging.info("Order file process time : " + str(time() - start_my))
            
    #print(result.IntervalVwap)
start_time = time()
#if __name__ == '__main__':
    #calling the main with passing the path of the order file created with above calculated parameters
def tca_calc(d):
    logging.info("start tca computation for {}".format(d))
    print "start tca computation for date",d
    final_output(flag,outpath,market_start,market_end,d)
            
end_time = time()
#logging.info("Time taken to process :{0} Seconds....".format(end_time - start_time))
print("Execution time: {0} Seconds.... ".format(end_time - start_time))
logging.info("Execution time: {0} Seconds.... ".format(end_time - start_time))
