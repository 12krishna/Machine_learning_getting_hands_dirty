# -*- coding: utf-8 -*-
"""
Created on Fri Jan 31 11:23:23 2020

@author: krishna
"""

import pandas as pd 
import os
from cassandra.cluster import Cluster

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

cluster = Cluster(['172.17.9.51'])
session = cluster.connect('rohit')
#connect to your keyspace and create a session using which u can execute cql commands 
session.row_factory = pandas_factory
session.default_fetch_size = None



#define rows fetched from cassandra to be a pandas dataframe
def getData(session,exchange,symbol,order_date):
    print session, exchange, symbol, order_date
    query='SELECT * FROM quotedata WHERE token(exchange,date)=token(\'{1}\',\'{2}\') and symbol=\'{0}\' ALLOW FILTERING;'.format(symbol,exchange,order_date)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    return(rows)



df = pd.DataFrame()
for r,d,f in os.walk("D:\\devansh_new\\TCA_linux_codes\\orderfiles\\"):
    for file in f:
        df=df.append(pd.read_csv("D:\\devansh_new\\TCA_linux_codes\\orderfiles\\"+file)) 

df = df[['Symbol','Ticker','StartTime','NSEExecutedQty','BSEExecutedQty','Tag115']]
df = df[(df['NSEExecutedQty']!=0) & (df['BSEExecutedQty']!=0)]
#temp = df[['Ticker','StartTime']].groupby(['Ticker'], as_index=False).min()





result=[]
for index,row in df.iterrows():  
    d = pd.to_datetime(row['StartTime']).date()
    if len(getData(session,"IS",row['Ticker'],d))==0:
        result.append([row['Ticker'],d,'IS',row['NSEExecutedQty'],row['BSEExecutedQty'], row['Tag115']])
    
    if len(getData(session,"IB",row['Ticker'],d))==0:
        result.append([row['Ticker'],d,'IB',row['NSEExecutedQty'],row['BSEExecutedQty'], row['Tag115']])
    

result = pd.DataFrame(result, columns=['Ticker','Date','Exchange','NSEExecutedQty','BSEExecutedQty','Tag115'])
result.drop_duplicates(inplace=True)
result.sort_values(by='Ticker', inplace=True)

temp = result[['Ticker','Date','Exchange','NSEExecutedQty','BSEExecutedQty','Tag115']].groupby(['Ticker'], as_index=False).min()
#temp = temp.merge(result, on=['Ticker','Date'], how='left')
temp.to_csv("D:\\devansh_new\\TCA_linux_codes\\orderfiles\\missing_values.csv", index=False)