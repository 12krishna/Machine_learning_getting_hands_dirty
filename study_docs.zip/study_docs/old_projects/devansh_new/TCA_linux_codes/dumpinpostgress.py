import logging,psycopg2,datetime
import pandas as pd
from sqlalchemy import create_engine
log_path = "/home/hadoop/tca_project/tca_logs/"
input_dir="/home/hadoop/tca_project/output_files/"

logging.basicConfig(filename=log_path +"test_{}.log".format(datetime.datetime.now().date()),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")



#input_dir="D:\\devansh_new\\TCA_linux_codes\\" #path to get output file of TC_17_9 

def dump_in_postgres(d):
#    d=datetime.datetime.now().date()-datetime.timedelta(days=1)
#    d=d.strftime('%Y%m%d')

    df=pd.read_excel(input_dir+'output_new_{}.xlsx'.format(d),sheetname="complete_output")
#    df["Tag1"]="TAG1"
    df["unique_id"]=df["TradeId"]+df["SecurityExchange"]
    df["date"]=pd.to_datetime(df["StartTime"]).dt.date
    logging.info("Read complete output file and dump in postgres")
# Connect to database (Note: The package psychopg2 is required for Postgres to work with SQLAlchemy)
    try: 
        conn = psycopg2.connect(dbname='NSE-FNO',
                                user='postgres',
                                password='kotak@123', 
                                host='172.17.9.182', 
                                port='5432')
    except:
        print("I am unable to connect to the database") 
        logging.info("I am unable to connect to the database")

    cur = conn.cursor()
    try:
        cur.execute("CREATE TABLE tca_split (unique_id varchar PRIMARY KEY, TradeId varchar,ClientOrdID varchar,Og_ClientOrdID varchar,ClientName varchar,Symbol varchar,Series char,Ticker char,OrdType char,LimitPrice float,Side char,SecurityExchange char,StartTime varchar,EndTime varchar,OrderQty float,SOR char,QuantityExecuted float,AvgPx float,NSEExecutedQty float,BSEExecutedQty float,NSEExecutedAvg float,BSEExecutedAvg float,Remarks char,Algorithm varchar,LastFillTime varchar,ArrivalTime varchar,IntervalVwap float,IntervalVwapNse float,IntervalVwapBse float,IntervalVwapLimit float,AvgPx_vs_IntervalVwapLimit float,IntervalVwapLimitNse float,IntervalVwapLimitBse float,DayVwapLimitNse float,DayVwapLimitBse float,DayVwapLimit float,DayVwap float,DayVwapNse float,DayVwapBse float,DayTwap float,DayTwapNse float,DayTwapBse float,IntervalTwap float,IntervalTwapNse float,IntervalTwapBse float,IntervalTwapLimit float,AvgPx_vs_IntervalTwapLimit float,IntervalTwapLimitNse float,IntervalTwapLimitBse float,DayTwapLimit float,DayTwapLimitNse float,DayTwapLimitBse float,AvgPx_vs_IntervalVwap float,AvgPx_vs_DayVwap float,AvgPx_vs_DayVwapLimit float,AvgPx_vs_IntervalTwap float,AvgPx_vs_DayTwap float,AvgPx_vs_DayTwapLimit float,AvgPx_vs_Pwp float,PwpNse float,PwpBse float,Pwp float,PwpLimit float,AvgPx_vs_PwpLimit float,PwpLimitNse float,PwpLimitBse float,AvgTradeSizeNse float,AvgTradeSizeBse float,AvgTradeSize float,IntervalVolNse float,IntervalVolBse float,IntervalVol float,IntervalVolLimitNse float,IntervalVolLimitBse float,IntervalVolLimit float,DayVolNse float,DayVolBse float,DayVol float,DayVolLimitNse float,DayVolLimitBse float,DayVolLimit float,volExecNse_intervalVolNse float,volExecBse_intervalVolBse float,volExec_vs_IntervalVol float,volExecNse_intervalVolLimitNse float,volExecBse_intervalVolLimitBse float,volExec_vs_IntervalVolLimit float,volExecNse_DayVolNse float,volExecBse_DayVolBse float,volExec_vs_DayVol float,volExecNse_DayVolLimitNse float,volExecBse_DayVolLimitBse float,volExec_vs_DayVolLimit float,ArrivalPriceNse float,ArrivalPriceBse float,ArrivalPrice float,AvgPx_vs_ArrivalPx float,Tag1 varchar);")
    except:
        print("database is already created you can drop it if you want to create new!")
        logging.info("database is already created you can drop it if you want to create new!")

    conn.commit() # <--- makes sure the change is shown in the database
    conn.close()
    cur.close()

    #copy data from dataframe to postgress
    try:
    	dbname="NSE-FNO"
    	user="postgres"
    	password="kotak@123"
    	ip="172.17.9.182"
    	port="5432"
    	engine = create_engine('postgresql://'+user+':'+password+'@'+ip+':'+port+'/'+dbname,echo=False) #create connection 
    	con = engine.connect()
        df.columns = df.columns.str.lower()
    	df.columns=["TradeId","ClientOrdID","Og_ClientOrdID","ClientName","Symbol","Series","Ticker","OrdType","LimitPrice","Side","SecurityExchange","StartTime","EndTime","OrderQty","SOR","QuantityExecuted","AvgPx","NSEExecutedQty","BSEExecutedQty","NSEExecutedAvg","BSEExecutedAvg","Remarks","Algorithm","LastFillTime","ArrivalTime","Tag115","tag9271","IntervalVwap","IntervalVwapNse","IntervalVwapBse","IntervalVwapLimit","AvgPx_vs_IntervalVwapLimit","IntervalVwapLimitNse","IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap","DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse","IntervalTwapBse","IntervalTwapLimit","AvgPx_vs_IntervalTwapLimit","IntervalTwapLimitNse","IntervalTwapLimitBse","DayTwapLimit","DayTwapLimitNse","DayTwapLimitBse","AvgPx_vs_IntervalVwap","AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit","AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","Px_vs_DayTwapLimit","AvgPx_vs_Pwp","Pwp20Nse","Pwp20Bse","Pwp20","Pwp20Limit","AvgPx_vs_PwpLimit","Pwp20LimitNse","Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse","IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse","DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse","volExecBse_intervalVolBse","volExec_vs_IntervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse","volExec_vs_IntervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse","volExec_vs_DayVol","volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_vs_DayVolLimit","ArrivalPriceNse","ArrivalPriceBse","ArrivalPrice","AvgPx_vs_ArrivalPx","Pwp10Nse","Pwp10Bse","Pwp10","Pwp10Limit","Pwp10LimitNse","Pwp10LimitBse","Pwp15Nse","Pwp15Bse","Pwp15","Pwp15Limit","Pwp15LimitNse","Pwp15LimitBse","Pwp25Nse","Pwp25Bse","Pwp25","Pwp25Limit","Pwp25LimitNse","Pwp25LimitBse","Pwp30Nse","Pwp30Bse","Pwp30","Pwp30Limit","Pwp30LimitNse","Pwp30LimitBse","unique_id","date"]
    	df=df[["TradeId","ClientOrdID","Og_ClientOrdID","ClientName","Symbol","Series","Ticker","OrdType","LimitPrice","Side","SecurityExchange","StartTime","EndTime","OrderQty","SOR","QuantityExecuted","AvgPx","NSEExecutedQty","BSEExecutedQty","NSEExecutedAvg","BSEExecutedAvg","Remarks","Algorithm","LastFillTime","ArrivalTime","Tag115","IntervalVwap","IntervalVwapNse","IntervalVwapBse","IntervalVwapLimit","AvgPx_vs_IntervalVwapLimit","IntervalVwapLimitNse","IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap","DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse","IntervalTwapBse","IntervalTwapLimit","AvgPx_vs_IntervalTwapLimit","IntervalTwapLimitNse","IntervalTwapLimitBse","DayTwapLimit","DayTwapLimitNse","DayTwapLimitBse","AvgPx_vs_IntervalVwap","AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit","AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","Px_vs_DayTwapLimit","AvgPx_vs_Pwp","Pwp20Nse","Pwp20Bse","Pwp20","Pwp20Limit","AvgPx_vs_PwpLimit","Pwp20LimitNse","Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse","IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse","DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse","volExecBse_intervalVolBse","volExec_vs_IntervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse","volExec_vs_IntervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse","volExec_vs_DayVol","volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_vs_DayVolLimit","ArrivalPriceNse","ArrivalPriceBse","ArrivalPrice","AvgPx_vs_ArrivalPx","Pwp10Nse","Pwp10Bse","Pwp10","Pwp10Limit","Pwp10LimitNse","Pwp10LimitBse","Pwp15Nse","Pwp15Bse","Pwp15","Pwp15Limit","Pwp15LimitNse","Pwp15LimitBse","Pwp25Nse","Pwp25Bse","Pwp25","Pwp25Limit","Pwp25LimitNse","Pwp25LimitBse","Pwp30Nse","Pwp30Bse","Pwp30","Pwp30Limit","Pwp30LimitNse","Pwp30LimitBse","unique_id","date","tag9271"]]
    
    	df.to_sql(name='tca_split', con=con, if_exists = 'append', index=False)
    #    con.commit()
        con.close()
        logging.info("successfully dumped data")
    except Exception as e:
        print "Error while inserting in db" + str(e)
        logging.info("Error while inserting in db" + str(e))
		
    
#main()

