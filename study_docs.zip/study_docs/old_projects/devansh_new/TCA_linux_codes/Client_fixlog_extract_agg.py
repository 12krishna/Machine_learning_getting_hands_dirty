# -*- coding: utf-8 -*-
"""
Created on Fri Jan 10 17:12:32 2019

@author: krishna
"""
import os, shutil
import re
import pandas as pd
import numpy as np
import string
import simplefix
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from time import time, sleep
from collections import OrderedDict
import pysftp
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

server = '172.17.9.149'; port = 25
MY_ADDRESS = 'MLPFixReport@kotak.com'


#import logging
filelist = list()

ul_path='/UL_DATA/'
input_path='/home/hadoop/tca_project/UL_DATA/'
outpath = '/home/hadoop/tca_project/client_extracted_files/'
contacts_dir = "/home/hadoop/tca_project/"
#log_path = "/home/hadoop/tca_project/tca_logs/"

#input_path='D:\\devansh_new\\TCA_linux_codes\\UL_DATA\\'
#outpath='D:\\devansh_new\\TCA_linux_codes\\UL_DATA\\'
expr = r'8=FIX\.4\.4.*?[10=\d+\|]$'       # pattern to recognize line with valid excution or order line ;
                                        #match line with pattern 8=FIX.4.2 and ending with 10=number|


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """
    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    try:
        msg['Cc']=','.join(kwargs['emails'][1])
        msg['Bcc']=','.join(kwargs['emails'][2])
    except:
        print "Problem with CC or BCC"
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'attachments' in kwargs.keys():
        for attachment in kwargs['attachments']:            
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(attachment, "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(os.path.basename(attachment) ))
            msg.attach(part) 

    
    if 'body_msg' in kwargs.keys():
        msg.attach(MIMEText(kwargs['body_msg'], 'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

# process_email(emails=, subject=, attachments= [], html_email=, text_email=  )



def process_message(rx, line, filename):
    
    x = string.replace(rx[0], '|','\x01')
    parser = simplefix.FixParser()
    parser.append_buffer(x)
    msg = parser.get_message()
    #print "here"
    #print msg.get(128)
    filename.write(str(msg.get(115))+","+str(msg.get(128))+","+str(msg.get(35))\
                    + ","+str(msg.get(11)) + ","+str(msg.get(37)) + ","+str(msg.get(38)) + ","+str(msg.get(1))\
                    + ","+str(msg.get(17)) + ","+str(msg.get(48)) + ","+str(msg.get(52))\
                    + ","+str(msg.get(60)) + ","+str(msg.get(55)) + ","+str(msg.get(31)) + ","+str(msg.get(32))\
                    + ","+str(msg.get(54)) + ","+str(msg.get(56)) + ","+line.split(" ")[3].replace("[",'').replace("]",'') +"," +str(msg.get(58))\
                    + ","+str(msg.get(167)) + ","+str(msg.get(75)) + ","+str(msg.get(41))\
                    + ","+str(msg.get(150)) + ","+str(msg.get(200)) + ","+str(msg.get(442))) 
    filename.write("\n")


def filter_trades(tag=None, session=None):
    
    print "Inputs entered -> Tag ({}), session ({}) ".format(tag,session)
    start_time = time()
    subdirs_list = [r[1] for r in os.walk(input_path)]
    for i in subdirs_list[0]:
        filelist.append(input_path + i + '/' + i[17:21] + i[14:16] + i[11:13] + '.txt')
     
    input_files = []
    for i in filelist:
        file_name = i
        print file_name
        f = open(file_name,'r')
        if f.mode == 'r':
            content = f.readlines()
        
            base = os.path.basename(file_name)
            tempfile1_name = "extractedfile_"+ str(os.path.splitext(base)[0]) + ".csv"
            input_files.append(tempfile1_name)
            
            tempfile1 = open(outpath + tempfile1_name, 'w')
            for line in content:
                if re.findall(expr, line):   
                    rx = re.findall(expr, line)
                    if session!=None:
                        # check if any of session present 
                        if np.any([ s in line for s in session.split(",")]):
                            if tag!=None:
                                if ('35=8' in rx[0]) and np.any([ "115={}".format(t) in rx[0] or "128={}".format(t) in rx[0] for t in tag.split(",")]):
                                    process_message(rx,line, tempfile1)
                            else:
                                if ('35=8' in rx[0]):
                                    process_message(rx,line, tempfile1)
                    elif session==None:
                        if tag!=None:
                           if ('35=8' in rx[0]) and np.any([ "115={}".format(t) in rx[0] or "128={}".format(t) in rx[0] for t in tag.split(",")]):
                                process_message(rx,line, tempfile1)
                        else:
                            if ('35=8' in rx[0]):
                                process_message(rx,line, tempfile1)
                            
                                
            f.close()
    
            tempfile1.close()
                

            print 'Order and execution file aka temp1 and temp2 files generated successfully...'
                
    end_time = time()
    print "Execution time: {0} Seconds.... ".format(end_time - start_time)
    return input_files


def agg_trade(grp):
    '''Func to agg trade '''
    q=np.sum(grp['Quantity'])
    return pd.Series({
                  'Quantity':q , 
                  'Price': round( np.average(grp['Price'], 
                                               weights=grp['Quantity']) if q!=0 else grp['Price'].values[-1] , 2)
                  #'ClientOrderId': grp['ClientOrderId'].values[-1] 
                  })
                  

cal_months_list = [ (datetime(2000,1,1)+relativedelta(month=i)).strftime("%b") for i in range(1,13)]    
monthly_codes_fut = OrderedDict(zip(cal_months_list, ['F','G','H','J','K','M','N','Q','U','V','X','Z']))
monthly_call_options = OrderedDict(zip(cal_months_list, [c for c in map(chr, xrange(ord('A'), ord('M')))]))
monthly_put_options = OrderedDict(zip(cal_months_list, [c for c in map(chr, xrange(ord('M'), ord('Y')))]))


def ric_code_gen(tag55, tag200, tag167):
    '''func to get RIC code for FNO
    '''
    
    ric_root = tag55.split(":")
    
    if tag167=='FUT':
        expiry = monthly_codes_fut[datetime.strptime(tag200, "%Y%m").strftime("%b")] + datetime.strptime(
                            tag200, "%Y%m").strftime("%Y")[-1]
        if ric_root[0] in ['NIF','NBN','NTS']:
            return ric_root[0]+expiry
        else:
            return ric_root[0]+expiry+":"+ric_root[1]
            
    elif tag167=='OPT':
        # options
        print "Options RIC construction logic not set yet....................................................."
        return tag55
    elif tag167=='MLEG':
        print "Multi leg order, constructing single leg RIC {}".format(tag55)
        if tag55[:-2] in ['NIF','NBN','NTS']: # index
            return tag55
        else:
            return tag55+":NS"
    else:
        return tag55
    
        
    
def sftp_file_uploader(filename, sftp_URL, uname, pswd):
    '''Func to upload file to ftp'''
    try:
            
        with pysftp.Connection(sftp_URL, username=uname, password=pswd) as sftp:
                print 'sftp file upload req file {}'.format(outpath+filename)
                sftp.put(outpath+filename, filename, confirm=False)
                print('Success: File upload')
                time.sleep(5)
        return "File successfully uploaded to SFTP {} ...".format(sftp_URL)
    except Exception as e:
        print "File uploading error @ ftp"
        print e
        return e
    


def gen_output(df, f_prefix, filename, sftp_upload):

    df1 = df.copy(deep=True)    
    # drop cancelled orders i,e H
    for index, row in df1[df1['150']=='H'].iterrows():
        df1.drop(index=df1[df1['17']==row['17'][:-6]+row['17'][-5:]].index, inplace=True)
        df1.drop(index=index, inplace=True)
        
    # ignore summary record for multi-leg orders
    df1 = df1[df1['442']!='3']
        
    # get RIC tickers for symbols based on tag55 and expiry tag 200
    if df1.empty!=True:
        df1['55'] = df1[['55','200','167']].apply(lambda row: ric_code_gen(row['55'], row['200'], row['167']), axis=1)
        
    df1 = df1[['54','55','32','31','60','11','37','1','17']]
    df1.columns= ['Side','Symbol','Quantity','Price','TradeDate','ClientOrderID','BrokerOrderID','Account','ExecutionID']
    df1['TradeDate'] = df1['TradeDate'].apply(lambda row: row.strftime("%Y/%m/%d %H:%M:%S") )

    if len(df1) > 0:
        
    	df1.to_csv(outpath+f_prefix+"_"+filename.split("_")[-1], index=False) # client output
        df2 = df1.copy(deep=True); df2['Price']=df2['Price'].astype(float)
    	df2 = df2.groupby(by=['Account','Symbol','Side'], as_index=False).apply(lambda grp: agg_trade(grp)).reset_index()
       
    	# format output 
    	writer = pd.ExcelWriter(outpath+f_prefix+"_{}".format(filename.split("_")[-1].replace(".csv",'.xlsx')))
    	df.to_excel(writer, sheet_name = "raw", index = False)
    	df1.to_excel(writer, sheet_name = "filtered", index = False)
    	df2.to_excel(writer, sheet_name = "aggregate", index=False)
    	writer.save()
    	writer.close()
        
        # copy csv file to ftp
        upload_msg = "Sftp file upload flag not set !"
        if sftp_upload==1:
            upload_msg = sftp_file_uploader(filename = outpath+f_prefix+"_"+filename.split("_")[-1],
                           sftp_URL = "", uname = "", pswd = "")
            print upload_msg
        
        # send email alert
        process_email(emails=get_contacts(contacts_dir+"mlp_contacts.txt"), 
                    subject="MLP FIX report !", 
                    attachments= [outpath+f_prefix+"_"+filename.split("_")[-1],
                                    outpath+f_prefix+"_{}".format(filename.split("_")[-1].replace(".csv",'.xlsx'))],
                    body_msg=upload_msg
                    )

        
def read_csv_extract(filepath):
    
    return pd.read_csv(filepath, header=None, 
                   names=['115','128','35','11','37','38','1','17','48','52','60','55','31','32','54','56','session','58',
                          '167','75','41','150', '200', '442'], 
                          dtype={'31':'string','200':'string', '442':'string'})
    

def process_files(filename, arginput, sftp_upload):
    
    df=read_csv_extract(outpath+filename)
    
    df=df[df['150'].isin(['F','H'])]
    print "Lenght of df contianing f and h {}".format(len(df))
    if df.empty==True:
        print "Exit .........."
        return -1
    df['54'] = np.where((df['54']==1), 'B', 'S' )
      
    tag, session, file_prefix, time_zone = arginput

    df = df[((df['115'].isin(tag.split(","))) | (df['128'].isin(tag.split(",")))) &
            (df['session'].isin(session.split(",")))]
    
    if time_zone=='IST':
        df['52'] = pd.to_datetime(df['52'],errors="coerce") + timedelta(hours=5,minutes=30)
        df['60'] = pd.to_datetime(df['60'],errors="coerce") + timedelta(hours=5,minutes=30)
    else:
        df['52'] = pd.to_datetime(df['52'],errors="coerce") 
        df['60'] = pd.to_datetime(df['60'],errors="coerce") 
        
    #for f_prefix in file_prefix.split(","):
    #    region, service  = tuple(f_prefix.split("_")[-2:])
    #    temp = df[df['session'].str.endswith(region+service)]
    gen_output(df.copy(deep=True), file_prefix, filename, sftp_upload)
    
    
    
def check_fixlog_file(d):
    
    fixfilepath = os.path.join(ul_path, "{}.txt".format(''.join(str(d).split("-"))))
    print fixfilepath
    while 1:
        if os.path.exists(fixfilepath) and os.path.getsize(fixfilepath) > 1024:
            break
        else:
            print "Bridge log files not yet updated @ {}".format(input_path)
            print "Sleep for 2 min..."
            sleep(120)
        
    # delete previous files and copy file to tca UL_data folder
    try:
        shutil.rmtree(input_path) # delete UL_data in tca project dir
        os.mkdir(input_path)
        os.mkdir(input_path+"BridgeLogs_{}".format('-'.join(str(d).split("-")[::-1])))
        shutil.copy(fixfilepath,
                    os.path.join(input_path+"BridgeLogs_{}".format('-'.join(str(d).split("-")[::-1])), 
                                 "{}.txt".format(''.join(str(d).split("-")))) )
        print "Copied file to bridge log folder..."
        return 1    
    except Exception as e:
        print "Error while copying UL_data"
        print e
        return -1
    


def main(arg, sftp_upload):
    
    d = (datetime.now() - timedelta(days=0)).date() # change date as per desiered

    # check if fix log file exist in UL_data
    if check_fixlog_file(d) == -1:
        return -1
        
    print "Start processing for {} .....................".format(d)

    # extract data
    tags = ",".join(list(set([tag[0] for tag in arg])))
    sessions = ",".join(list(set([s[1] for s in arg])))
    input_files = filter_trades(tags, sessions)
      
    for filename in input_files:
        temp = read_csv_extract(outpath+filename)
        if temp.empty==False:
            for arginput in arg:
                process_files(filename, arginput, sftp_upload)
        else:
            # send email alert
            process_email(emails=get_contacts(contacts_dir+"mlp_contacts.txt"), 
                    subject="MLP FIX report !", 
                    body_msg="No Trades from MLP for {}".format(
                            datetime.strptime("extractedfile_20210408.csv".split("_")[-1][:-4], "%Y%m%d").date())
                    
                    )

            
            
    
if __name__=='__main__':
    main(arg = [ 
    ("MLP","I_MLPFUT,I_MLPFUT2,I_MLPFUT3,I_MLPFUT4","Millennium_FUT_Asia_GUI","GMT"),  # takes input as GMT or IST
    ("MLP","I_MLPENOT,I_MLPENOT2","Millennium_EQ_US_DMA","GMT"),
    ("MLP","I_MLPFNOT,I_MLPFNOT2","Millennium_FUT_US_DMA","GMT"),
    ("MLP","I_MLPENALG,I_MLPENALG2","Millennium_EQ_US_PT","GMT"),
    ("MLP","I_MLPFNALG,I_MLPFNALG2","Millennium_FUT_US_PT","GMT"),
    ("MLP","I_MLPETOT,I_MLPETOT2","Millennium_EQ_Tokyo_DMA","GMT"),
    ("MLP","I_MLPFTOT,I_MLPFTOT2","Millennium_FUT_Tokyo_DMA","GMT"),
    ("MLP","I_MLPETALG,I_MLPETALG2","Millennium_EQ_Tokyo_PT","GMT"),
    ("MLP","I_MLPFTALG,I_MLPFTALG2","Millennium_FUT_Tokyo_PT","GMT"),
    ("MLP","I_MLPESOT,I_MLPESOT2","Millennium_EQ_Singapore_DMA","GMT"),
    ("MLP","I_MLPESALG,I_MLPESALG2","Millennium_EQ_Singapore_PT","GMT")
    ], sftp_upload=0)
