# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 19:57:54 2021

@author: krishna
"""

import numpy as np
import pandas as pd
import os, sys
from cassandra.cluster import Cluster


input_dir = "/home/hadoop/new_vwap_process/"
pairmaster_dir = "/Output/"
bloom_dir = "/home/hadoop/GenInstrument/dataFiles/"
output_dir = "/home/hadoop/new_vwap_process/"

'''
input_dir = "D:\devansh_new\TCA_linux_codes\UL_DATA"
pairmaster_dir = "D:\devansh_new\TCA_linux_codes\UL_DATA"
bloom_dir = "D:\devansh_new\TCA_linux_codes\UL_DATA"
'''

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open("D:\\Master\\config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster

def getData(session,exchange,symbol,order_date):
    print session, exchange, symbol, order_date
    query='SELECT * FROM quotedata WHERE token(exchange,date)=token(\'{1}\',\'{2}\') and symbol=\'{0}\' limit 1 ALLOW FILTERING;'.format(symbol,exchange,order_date)
    #query="SELECT symbol, date FROM quotedata WHERE symbol='{}' and exchange='{}'  ALLOW FILTERING;".format(symbol,
    #                                                exchange)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    rows.drop_duplicates(keep='last', inplace=True)
    
    return(rows)

curve_uni_df = pd.read_csv(os.path.join(input_dir, "Security_Names.csv"))
curve_uni_df.rename(columns={'symbol':'berg'}, inplace=True)

# get bloom codes from scripmaster
bloom_df = pd.read_csv(os.path.join(bloom_dir, "scripmaster.csv"), header=None)
bloom_df.rename(columns={0:'Symbol',11:'berg'}, inplace=True)
bloom_df.dropna(subset=['Symbol'], inplace=True)
bloom_df = bloom_df[['Symbol','berg']]
bloom_df.dropna(how='any', axis=0, inplace=True)
#bloom_df['berg'] = bloom_df['berg'].apply(lambda row: row.split(".NS")[0])

cnx500_df = pd.read_csv(os.path.join(input_dir, "ind_nifty500list.csv"))[['Symbol']]
# fno universe
fno_df = pd.read_csv(os.path.join(pairmaster_dir, "PairMaster.csv"))[['Symbol']]

missing_fno_symbols = fno_df[~fno_df['Symbol'].isin(cnx500_df['Symbol'].values.tolist())]['Symbol'].values.tolist()
if len(missing_fno_symbols)!=0:
    print "Missing fno symbols not present in CNX 500"
    print missing_fno_symbols
    
cnx500_df = cnx500_df.merge(bloom_df, on=['Symbol'], how='left')

missing_symbols = cnx500_df[~cnx500_df['berg'].isin(curve_uni_df['berg'].values.tolist())][['berg']]
missing_symbols.dropna(inplace=True)
if len(missing_symbols)!=0:
    print "Missing cnx 500 symbols not present in vwap curve security names"
    print "Total {} symbols missing".format(len(missing_symbols))
    
missing_symbols.to_csv(os.path.join(output_dir, "missing_symbols.csv"), index=False)



# check in get quote data
#cluster = Cluster(['172.17.9.51'])
cluster = cassandra_configs_cluster()

session = cluster.connect('rohit')
#connect to your keyspace and create a session using which u can execute cql commands 
session.row_factory = pandas_factory
session.default_fetch_size = None
'''
missing_db = []
for berg in missing_symbols['berg'].values:
    df = getData(session,'IS',berg,'2020-12-10')
    missing_db.append(['IS',berg, len(df)])
    
missing_db=pd.DataFrame(missing_db)
missing_db.columns=['exch','symbol','count']
missing_db.to_csv(os.path.join(output_dir, "missing_db.csv"), index=False)
'''
import datetime
msci_symbols = pd.read_excel(os.path.join(input_dir, "Book10.xlsx"))
msci_symbols['BBG'] = msci_symbols['BBG'].apply(lambda row: row.split(" ")[0])
missing_db = []
for berg in msci_symbols['BBG'].values:
    res = pd.DataFrame()
    for i in range(150):
        df = getData(session,'IS',berg,(datetime.datetime.now()-datetime.timedelta(days=i)).date() )
        if df.empty==False:
            res= res.append(df)
        
    missing_db.append(['IS',berg, len(res)])
    
      
missing_db=pd.DataFrame(missing_db)
missing_db.columns=['exch','symbol','count']
missing_db.to_csv(os.path.join(output_dir, "data_count.csv"), index=False)

