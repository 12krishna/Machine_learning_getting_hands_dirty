# -*- coding: utf-8 -*-
"""
Created on Wed Feb  9 12:39:15 2022

@author: Administrator
"""

import os, subprocess


data_dir = "/home/hadoop/cass_data/"

# walk through all the downlaoded bhavcopies in downlaods dir
for r,d,f in os.walk(data_dir):
    for csv_file in f:
        #read each csv file
        if csv_file.endswith(".csv"):
            print (csv_file)
            # call sh file
            os.putenv("filename", os.path.join(os.path.join(data_dir, csv_file)))
            subprocess.call(os.path.join(data_dir, 'dumper.sh'))
            break
            #os.remove(os.path.join(data_dir, csv_file))