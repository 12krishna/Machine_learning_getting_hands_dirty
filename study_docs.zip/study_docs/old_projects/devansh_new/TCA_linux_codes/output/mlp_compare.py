# -*- coding: utf-8 -*-
"""
Created on Tue Aug  3 17:29:23 2021

@author: krishna
"""

import time, datetime, os, sys
import numpy as np
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import shutil

server = '172.17.9.149'; port = 25
MY_ADDRESS = 'MLPFixReport@kotak.com'


# set dependency paths here
if sys.platform not in ('win32', 'cygwin', 'cli'):
    input_dir = "/home/hadoop/tca_project/client_extracted_files/"
    bo_file_dir = "/MLPFIXEODTally/"
    output_dir = '/home/hadoop/tca_project/'
    contacts_dir='/home/hadoop/tca_project/'
    master_dir = "/MLPFIXEODTally/Master/"
    processed_folder= "/home/hadoop/tca_project/mlp_compare_processed/"
else:    
    input_dir = "D:\\devansh_new\\TCA_linux_codes\\output\\"
    output_dir = 'D:\\devansh_new\\TCA_linux_codes\\output\\'
    contacts_dir='D:\\devansh_new\\TCA_linux_codes\\output\\'
    master_dir = r"\\172.17.9.22\Users2\MLPFIXEODTally\Master\\"
    bo_file_dir = "D:\\devansh_new\\TCA_linux_codes\\output\\"
    processed_folder="D:\\devansh_new\\TCA_linux_codes\\output\\"

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """
    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    try:
        msg['Cc']=','.join(kwargs['emails'][1])
        msg['Bcc']=','.join(kwargs['emails'][2])
    except:
        print "Problem with CC or BCC"
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'attachments' in kwargs.keys():
        for attachment in kwargs['attachments']:            
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(attachment, "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(os.path.basename(attachment) ))
            msg.attach(part) 

    
    if 'body_msg' in kwargs.keys():
        msg.attach(MIMEText(kwargs['body_msg'], 'plain'))
    
    if 'html_email' in kwargs.keys():
        msg.attach(MIMEText(kwargs['html_email'], 'html'))
    
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

# process_email(emails=, subject=, attachments= [], html_email=, text_email=  )
    
def color_format_table(table, flag):
    
    table['Symbol'] = "text"+table['Symbol'].astype(str)
    table['Side'] = "text"+table['Side'].astype(str)
    
    return "{}".format(table.to_html(classes='mystyle', index=False).replace('<table border="1" class="dataframe mystyle">',
                         '<table border="1" class="{}mystyle">'.format(flag)))
                
    

def read_trades_bofile(d, entity_mappings):
    
    while 1:
        if os.path.exists(os.path.join(input_dir, "extractedfile_{}.csv".format(d.strftime("%Y%m%d")))):
            print "MLP trade files exists; processing after 90 seconds"
            time.sleep(1)
            break
        else:
            print "sleeping..."
            time.sleep(30)
            print "Look if extracted files for {} present ...".format(d.strftime("%Y%m%d"))
        
        if datetime.datetime.now().time()>datetime.time(23,0):
            print "File not present \n{} - Skip for today ...".format(datetime.datetime.now())
            return pd.DataFrame(), pd.DataFrame(), ""
        
    # read input files
    result = pd.DataFrame()
    bo_file = pd.DataFrame()
    
    for _,_,files in os.walk(input_dir):
        for f in files:
            if f.startswith("Millennium_FUT") and f.endswith("{}.xlsx".format(d.strftime("%Y%m%d"))):
                print "Reading file {}".format(f)
                temp = pd.read_excel(os.path.join(input_dir, f), sheet_name="aggregate")
                #temp = pd.read_csv(os.path.join(input_dir, f))
                if temp.empty==False:
                    # get entity id
                    temp['Filename'] = "_".join(f.split("_")[:-1])
                    
                    result = result.append(temp, ignore_index=True)
    
    while 1:
        for _,_,files in os.walk(bo_file_dir):
            for _file in files:
                if _file.startswith("MILLENIUM") and _file.split(".")[0].endswith("{}".format(d.strftime("%Y%m%d"))):
                    print "Bo file present; continue execution..."
                    # read BO provided TCS file  
                    bo_file = pd.read_excel(os.path.join(bo_file_dir,_file))
                    return result, bo_file, _file
        else:
            print "MILLENIUM BO file not present ; checking agian...."
            print "Sleeping..."
            time.sleep(15)
            
            
        if datetime.datetime.now().time()>datetime.time(23,0):
            print "BO File not present \n{} - Skip for today ...".format(datetime.datetime.now())
            return pd.DataFrame(), pd.DataFrame(), ""
        
    
    
def assign_code(df, columnname, entity_mappings):
    
    for _, row in entity_mappings.iterrows():
        if columnname=="Account":
            df.loc[(df[columnname].isin(row[columnname].split(","))) & \
                   (df["Filename"].isin(row['Filename'].split(","))), "code"] = row['code']
        else:
            df.loc[df[columnname].isin(row[columnname].split(",")), "code"] = row['code']
            
    return df    
       

def get_summary(df):
    
    # file wise summary
    summary_df = df.groupby(by=['Filename','Account','Entity ID','Side'], as_index=False).agg({"BO Lots":'sum', 'FIX Lots':'sum'})
    #summary_df.index = summary_df['Filename'].astype(str)+summary_df['Account'].astype(str)+summary_df['Entity ID'].astype(str)
    #summary_df[['Filename','Account','Entity ID']] = summary_df[['Filename','Account','Entity ID']].applymap(
    #                                                        lambda row: row.split(",") if "," in row else row)
    buy = summary_df[summary_df['Side']=='B'].set_index(['Filename','Account','Entity ID'])
    sell = summary_df[summary_df['Side']=='S'].set_index(['Filename','Account','Entity ID'])
    
    summary_df= {'Buy':buy.drop(columns=['Side']), 'Sell':sell.drop(columns=['Side'])}
    summary_df = pd.concat(summary_df.values(), keys=summary_df.keys(), axis=1)
    summary_df.fillna(0, inplace=True)
    summary_df = summary_df.astype(int)
    summary_df.reset_index(inplace=True)
    
    summary_df[['Filename','Account','Entity ID']] = summary_df[['Filename','Account','Entity ID']].applymap(
                                                      lambda row: "<br>".join(row.split(",")) if "," in row else row)
    summary_df.set_index(['Filename','Account','Entity ID'], inplace=True)
    summary_df = "{}".format(summary_df.to_html(classes='mystyle').replace('<table border="1" class="dataframe mystyle">',
                         '<table border="1" class="mystyle">'))
           
    return summary_df
    
    
def prepare_send_email(bo_mismatch, fix_mismatch, matching, d, debug_tables):
    
    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>       
    html_string = "<html><head><style>{css_style}</style></head><body>\
                    <p>FIX trades Vs BO trades on {d} . </p>".format(css_style = open(os.path.join(output_dir,"df_style.css"), 'r').read(),
                                                                                            d=d)
    # OUTPUT AN HTML FILE
    output_file = open(output_dir+"output.html", 'w')
    output_file.write(html_string)
    
    # write debug tables for which there is no code in entity master
    '''
    if debug_tables[0].empty==False:
        output_file.write("<br><br>Trades present in FIX file has no mentioned details in entity master; please update entity master and re-run the process!<br>")
        output_file.write(color_format_table(debug_tables[0], "red"))
    if debug_tables[1].empty==False:
        output_file.write("<br><br>Trades present in BO file has no mentioned details in entity master; please update entity master and re-run the process!<br>")
        output_file.write(color_format_table(debug_tables[1], "red"))
    
    output_file.write("<br>")
    '''
    output_file.write("<p><b>Mismatch in BO File</b></p>")
    
    if bo_mismatch.empty==False:
        output_file.write(color_format_table(bo_mismatch, "red"))
    else:
        output_file.write("<i>No mismatch found</i><br>")
    
    output_file.write("<p><b>Mismatch in FIX File</b></p>")
    if fix_mismatch.empty==False:
        output_file.write(color_format_table(fix_mismatch, "red"))
    else:
        output_file.write("<i>No mismatch found</i><br>")
    
    output_file.write("<p><b>Matching records</b></p>")    
    if matching.empty==False:
        output_file.write("<i>Summary</i>"+get_summary(matching.copy(deep=True)))
        output_file.write("<br><br><i>Trades</i><br>")
        output_file.write(color_format_table(matching[['Symbol','Side','BO Lots','FIX Lots']],""))
    else:
        output_file.write("<i>No matching records found</i><br>")
        
    output_file.write("</body></html>")    
    output_file.close()    
    
    output_file = open(output_dir+"output.html", 'r').read().replace("&lt;","<").replace("&gt;",">")
    #output_file = output_file.replace("dataframe mystyle","mystyle")
    output_file = output_file.replace('<td>text','<td class="text">')
    
    with open(output_dir+"output.html", 'w') as f:
        f.write(output_file)
        
    # send email
    process_email(emails=get_contacts(os.path.join(contacts_dir, "contacts.txt")), 
                  subject="(MLP)Trades Comparison {}".format(d), 
                  html_email=open(output_dir+"output.html", 'r').read())
  
        

def compare_files(nd):
    
    d = datetime.datetime.now().date()-datetime.timedelta(days=nd)
    print "Processing for date {}".format(d)
    # read entity master file
    entity_mappings = pd.read_csv(os.path.join(master_dir, "entitymaster.csv"), sep="|")
    entity_mappings['code'] = 1
    entity_mappings['code'] = entity_mappings['code'].cumsum()
    #entity_mappings = entity_mappings.applymap(lambda col: col.split(","))
    
    #read mlp trade input files for today
    trades, bo_file, bo_filename = read_trades_bofile(d, entity_mappings)
      
    if trades.empty==True or bo_file.empty==True:
        print "\nFIX trades len {}, Bo file len {}\nSkip for {}; file empty...".format(len(trades), len(bo_file), datetime.datetime.now())
        return
    
    # tally trades in both files
    trades = assign_code(trades, "Account", entity_mappings)
    bo_file = assign_code(bo_file, "Entity ID", entity_mappings)
    debug_tables = [ trades[trades.code.isnull()], bo_file[bo_file.code.isnull()] ]
    
    trades_in_entity_account = (bo_file.groupby(by=['code']).apply(lambda grp: ','.join(sorted(set(grp['Entity ID'].values)))).reset_index().rename(
                                        columns={0:'Entity ID'})).merge(
                                trades.groupby(by=['code']).apply(lambda grp: pd.Series({
                                        "Filename": ','.join(sorted(set(grp['Filename'].values))), 
                                        "Account": ','.join(sorted(set(grp['Account'].values)))})).reset_index(), 
                                on=['code'], how='outer')
    
    trades['Symbol']=trades['Symbol'].str.strip(); trades['Side']=trades['Side'].str.strip()
    
    trades['Symbol'] = trades['Symbol'].str.replace(":NS","")
    bo_file['RIC Codes'] = bo_file['RIC Codes'].str.replace(":NS","")
    
    
    trades = trades.groupby(by=['Symbol','Side','code'], as_index=False).agg({"Quantity":"sum"})
    bo_file = bo_file.fillna(0).groupby(by=['RIC Codes','code'], as_index=False).agg({"Buy (Lots)":"sum", "Sell (Lots)":"sum"}) 
    
    temp = bo_file[bo_file['Sell (Lots)']>0][['RIC Codes','code','Sell (Lots)']].rename(columns={'Sell (Lots)':'BO Lots'})
    if temp.empty==False:
        temp['Side'] = "S"
    temp1 = bo_file[bo_file['Buy (Lots)']>0][['RIC Codes','code','Buy (Lots)']].rename(columns={'Buy (Lots)':'BO Lots'})
    if temp1.empty==False:
        temp1['Side'] = "B"
    bo_file = temp.append(temp1, ignore_index=True)
    bo_file.rename(columns={"RIC Codes":'Symbol'}, inplace=True)
    
    result = (trades.rename(columns={'Quantity':'FIX Lots'})).merge(bo_file, on=['Symbol','Side','code'], how="outer")
    result['mismatch'] = result['FIX Lots'] - result['BO Lots']
    
    result['Symbol'] = result['Symbol'].apply(lambda row: row+":NS" if row[:-2] not in ['NBN','NIF','NTS'] else row)
    result.loc[(result['BO Lots'].isnull()|result['FIX Lots'].isnull())&(result['FIX Lots']>0), "mismatch"] = 1
    result.loc[(result['BO Lots'].isnull()|result['FIX Lots'].isnull())&(result['BO Lots']>0), "mismatch"] = -1
    result[['BO Lots','FIX Lots']] = result[['BO Lots','FIX Lots']].fillna(0)
    result[['BO Lots','FIX Lots']] = result[['BO Lots','FIX Lots']].astype(int)
    print "Check for mismatch..........."
    # attach filename and trader name 
    result = result.merge(trades_in_entity_account, on=['code'], how="left")
    cols=['Symbol','Side','BO Lots','FIX Lots',"Filename",'Account','Entity ID']
    bo_mismatch = result[result['mismatch']<0][cols]
    fix_mismatch = result[result['mismatch']>0][cols]
    matching = result[result['mismatch']==0][cols]
    
    # prepare and send email    
    prepare_send_email(bo_mismatch, fix_mismatch, matching, d, debug_tables)
    print "Mail sent..."
    # move BO file to processed
    shutil.move(os.path.join(bo_file_dir, bo_filename), os.path.join(processed_folder, bo_filename))
    
if __name__=="__main__":
    compare_files(nd=0)
    
