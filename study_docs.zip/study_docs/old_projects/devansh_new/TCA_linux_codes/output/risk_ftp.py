# -*- coding: utf-8 -*-
"""
Created on Tue Feb 22 10:37:46 2022

@author: backup
"""


#import socks
#import socket
from ftplib import FTP
import pandas as pd
import logging
#from tabulate import tabulate
import os,datetime,time,sys
import pysftp
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None 
#import FPI_data
import Email_notifications

#server = '172.17.9.144'; port = 25

if sys.platform not in ('win32', 'cygwin', 'cli'):
    contacts_dir = "/home/hadoop/risk_ftp_downloader/"
    data_dir='/RiskDataDownload/'  # output dir for storing files for client
    log_path='/home/hadoop/risk_ftp_downloader/'
    master_dir = "/home/hadoop/tca_project/master_files/"
    password_filepath = "/CMFOReport/scripts/"
    email_sh = '/home/hadoop/risk_ftp_downloader/'
else:
    contacts_dir = "D:\\Emails\\Contacts\\"
    data_dir=r'\\172.17.9.22\Users2\RiskDataDownload'  # output dir for storing files for client
    log_path='C:\\Users\\backup\\'
    master_dir = "D:\\Data_dumpers\\Master\\"
    os.chdir("C:\\Users\\backup\\")
    password_filepath = "C:\\Users\\backup\\New folder\\"

#MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
_user_id = "08081"
_password = ""
_hostname = 'ftp.connect2nse.com'
lines=open(os.path.join(password_filepath, "nsepwd.txt"),"r").readlines()

uname=_user_id
pword=lines[0].strip().split("=")[-1]
print uname, pword
'''
socks.set_default_proxy(socks.HTTP, 
                    "172.17.9.170", 8080,
                     username="geetav",  # use your username  krishnay
                     password="Pass@333"  # passowrd that you use for login to kotak system
                     )       
socket.socket = socks.socksocket
'''
logging.basicConfig(filename=log_path+"risk.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")     

console = logging.StreamHandler()
console.setLevel(logging.INFO)
# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)
logging.info("Start process")


def ftp_proxy_downloader(d):
    
    
    d1=next_working_day(d.date())  
    
    directory1=datetime.datetime.strftime(d1,"%d%m%Y")
    risk_path=os.path.join(data_dir,directory1)
        
    if not os.path.exists(risk_path):          
       os.mkdir(risk_path)
         
    files_dict={"qty_freeze_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")):"/common/NTNEAT", "fo_secban_{}.csv".format(datetime.datetime.strftime(d1,"%d%m%Y")):"/faocommon/Limit Files",
               'F_AEL_OTM_CONTRACTS_{}.csv.gz'.format(datetime.datetime.strftime(d1,"%d%m%Y")):"/faocommon/Limit Files","ael_{}.csv".format(datetime.datetime.strftime(d1,"%d%m%Y")):"/faocommon/Limit Files",
              "F_CN01_NSE_{}.CSV.gz".format(datetime.datetime.strftime(d,"%d%m%Y")):"/faocommon/marketreports","oi_cli_limit_{}.lst".format(datetime.datetime.strftime(d,"%d-%b-%Y").upper()):"/faocommon/Limit Files",
             "fo{}bhav.csv.gz".format(datetime.datetime.strftime(d,"%d%b%Y").upper()):"/faocommon/bhavcopy" }
    
    while len(files_dict)!=0:
          q= "qty_freeze_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y"))
          for f in list(files_dict.keys()):
            if  q == f :
                ftp = FTP(_hostname)
                ftp.set_debuglevel(1) 
                ftp.login(
                       user=_user_id,
                       passwd=pword 
                      ) 
                logging.info("logged in for {} file".format(q))
                print ftp.pwd() # to check what is present working directory
                ftp.cwd(files_dict[q])# to check the current working directory on ftp server
                newf=ftp.nlst()
                if q in newf:
                    logging.info("{} file exists".format(q))
                    try:
                       ftp.retrbinary("RETR " + q,
                                   open(os.path.join(risk_path,q), 'wb').write)	
                       logging.info("{} file stored".format(q))
                       Email_notifications.email_utility("{}".format(q), 
                                "File have been updated on mentioned path: \\172.17.9.22\Users2\RiskDataDownload")                      
                       files_dict.pop(q)
                       ftp.close() # dont forget to close the ftp connection after downloading all the files
                      
                    except Exception as e:
                           print "Error downloading {} file Error code : {}".format(q, e)
                           logging.info("Error downloading {} file Error code : {}".format(q, e))
            else:
              
                    ftp = FTP(_hostname)
                    ftp.set_debuglevel(1) 
                    ftp.login(
                        user="F08081",
                         passwd=pword 
                         ) 
                    logging.info("logged in for {} file".format(f))
                    print ftp.pwd() # to check what is present working directory
                    ftp.cwd(files_dict[f])# to check the current working directory on ftp server
                    newf=ftp.nlst()
                    if f in newf:
                      logging.info("{} file exists".format(f))
                      try:   
                       ftp.retrbinary("RETR " + f,
                                   open(os.path.join(risk_path,f), 'wb').write)	
                       logging.info("{} file stored".format(f))
                       Email_notifications.email_utility("{}".format(f), 
                                       "File have been updated on mentioned path: \\172.17.9.22\Users2\RiskDataDownload")
                       files_dict.pop(f)
                       ftp.close() # dont forget to close the ftp connection after downloading all the files
                      
                      except Exception as e:
                           print "Error downloading {} file Error code : {}".format(f, e)
                           logging.info("Error downloading {} file Error code : {}".format(f, e))       
          time.sleep(900)
    
   
    
    #os.system("Email_notifications.sh {} {}".format('"{}"'.format(filename),
    #          '"File have been updated on mentioned path: \\172.17.9.22\Users2\RiskDataDownload"'))  

    
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
     
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)
             
     
def next_working_day(d):
    d = d + datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d + datetime.timedelta(days=1)
            else:
                return d    
             

             
      
def main(nd):
    
    d=datetime.datetime.today()-datetime.timedelta(nd)
    if process_run_check(d.date())== -1:
        return -1
    print "Processing for date {}".format(d)
    ftp_proxy_downloader(d)
                  
main(nd=0)              
   
