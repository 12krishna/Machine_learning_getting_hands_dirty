import pandas as pd
import numpy as np
import os,re,time,datetime,calendar
import sys
import redis

redis_host = '10.223.105.53'
    

d_cal = dict(enumerate(calendar.month_abbr))

# set paths here
if sys.platform not in ('win32', 'cygwin', 'cli'):
    print "Linux environment paths set"
    path='/home/hadoop/GenInstrument/dataFiles/'
    output_dir = "/Output/"
    
else:
    print "Windows environment path set" 
    path='D:\\devansh_new\\TCA_linux_codes\\output\\dataFiles\\'
    output_dir = "D:\\devansh_new\\TCA_linux_codes\\output\\"
    

#path='/home/hadoop/GenInstrument/dataFiles'

# list of shares in E1 series
_E1_list = ['SATINPP','RELIANCEPP','DHANIPP','TATASTLPP','MOLDTEKPP','RUSHILPP1']
_RR_list = ['EMBASSY','MINDSPACE']
    
instrument_columns = ["SecurityCode","UnderLyingSecurityCode","TradingSymbol", "ScripType","ExchangeSegment","Symbol", "Series",
                      "InstrumentType","ExpiryDate","StrikePrice","OptionType","LotSize", "VolumeFreezeQty","TickSize",
                      "LowerCircuitPrice","UpperCircuitPrice","OrderPlaced","NseSecurityCode","BseSecurityCode",
                      "CurrentMonthFutureSecurityCode","NextMonthFutureSecurityCode","FarMonthFutureSecurityCode","CurrentMonthNextMonthSpreadSecurityCode",
                      "NextMonthFarMonthSpreadSecurityCode","CurrentMonthFarMonthSpreadSecurityCode","IsCurrentMonthContract",
                      "IsNextMonthContract","IsFarMonthContract","IsCurrentMonthNextMonthSpreadContract","IsNextMonthFarMonthSpreadContract",
                      "IsCurrentMonthFarMonthSpreadContract","ISIN","PreviousClose"]
   
#add columns
def add_columns(list1,df):
    
    for i in list1:
        if i in df.columns:
            #print("column present")
            pass
        else:
            #print("adding new column")
            df[i]=np.nan
    
    return df

def expirydate_jiffy(expirydate):
    
    jiffy_epoch = 315532800 # jiffy from 1st jan 1980
    # expiry date
    expirydate = int(expirydate)
    curr_milli = jiffy_epoch + expirydate
    d = datetime.datetime.utcfromtimestamp(curr_milli).strftime("%d-%m-%Y") # get date from timestamp
    return d


def bse_scrip_reader():
    list1=["SecurityCode","ExchCode","Symbol","SecurityName","PartIdProductId","InstrumentType",
           "GroupName","Series","FaceValue","LotSize","TickSize","BseExclusive","Status",
           "ExDivDate","NoDelEndDate","NoDelStartDate","Filler","ISIN","CallAuctionIndicator",
           "BcStartDate","ExBonusDate","ExRightDate","filler2","filler3","BcEndDate","filler4","filler5","filler6","filler7","filler8"]

    bse_scrip=pd.read_csv(path+"SCRIP.TXT",header=None, sep='|', names=list1, index_col=False)
    bse_scrip['SecurityCode'] = bse_scrip['SecurityCode'].astype(str)
    #bse_scrip=bse_scrip[0].str.split('|',expand=True)
    #bse_scrip.drop(columns=[26],axis=1,inplace=True)
    #bse_scrip.columns=list1

    bse_scrip=bse_scrip[((bse_scrip['InstrumentType']=='E') & \
                        ((bse_scrip["SecurityCode"].str.startswith('5')) |  (bse_scrip["SecurityCode"].str.startswith('6')) | \
                         (bse_scrip["Symbol"].isin(_E1_list+_RR_list))) & (bse_scrip["Status"]!='S')) | (bse_scrip["GroupName"]=='XT')]

    bse_scrip["ExchangeSegment"]="BSE"
    bse_scrip["ScripType"]="NORMAL"
    bse_scrip["InstrumentType"]='EQ'
    bse_scrip["Series"]=bse_scrip["GroupName"]
    bse_scrip["StrikePrice"]=-1.0
    bse_scrip["ExpiryDate"]='XX'
    bse_scrip["OptionType"]='XX'
    bse_scrip["UnderLyingSecurityCode"]='XX'
    bse_scrip["LowerCircuitPrice"]=0.0
    bse_scrip["UpperCircuitPrice"]=0.0
    bse_scrip["OrderPlaced"]=False 
    bse_scrip["VolumeFreezeQty"]=-1.0
    bse_scrip['TradingSymbol'] = bse_scrip['Symbol']
    
    bse_scrip.reset_index(drop=True,inplace=True)
    del list1
    return bse_scrip

def bse_dp_reader(bse_scrip):
    '''Func to read circuit limits'''
    bse_dp=pd.read_csv(path+"DP")
    bse_dp.rename(columns={'Scrip Code':'SecurityCode', 'Lower Circuit Price':"LowerCircuitPrice",
                           "Upper Circuit Price":"UpperCircuitPrice"}, inplace=True)
    bse_dp['SecurityCode'] = bse_dp['SecurityCode'].astype(str)   
    bse_scrip = bse_scrip.merge(bse_dp[['SecurityCode','LowerCircuitPrice','UpperCircuitPrice']],
                                on='SecurityCode', how='left', suffixes=("","_new"))
    bse_scrip[['LowerCircuitPrice_new','UpperCircuitPrice_new']]=bse_scrip[['LowerCircuitPrice_new','UpperCircuitPrice_new']].fillna(0.0)
    bse_scrip[['LowerCircuitPrice','UpperCircuitPrice']] = bse_scrip[['LowerCircuitPrice_new','UpperCircuitPrice_new']]    
    bse_scrip[['LowerCircuitPrice','UpperCircuitPrice']]=bse_scrip[['LowerCircuitPrice','UpperCircuitPrice']]/100
    bse_scrip.drop(columns=['LowerCircuitPrice_new','UpperCircuitPrice_new'], inplace=True)
    bse_scrip.reset_index(drop=True,inplace=True)
    return bse_scrip

def load_freeze_qty():
    qty = pd.read_csv(path+"qty_freeze.csv")
    qty['TradingSymbol'] = qty['SYMBOL'].astype(str)+"-"+qty['SERIES'].astype(str)
    return qty[['TradingSymbol','FREEZE_QTY']]

def nse_scrip_reader():
    list2=["SecurityCode","Symbol","Series","InstrumentType","IssuedCapital","PermittedToTrade","CreditRating",
           "SercurityStatusNormalMkt","EligibilityNormalMkt","SecurityStatusOddLotMarket","EligibilityOddLotMarket",
           "SecurityStatusRetDebtMarket","EligibilityRetDebtMarket","SecurityStatusAuction","EligibilityAuction",
           "SecurityStatusAddMarket1","EligibilityAddMarket1","SecurityStatusAddMarket2","EligibilityAddMarket2",
           "LotSize","TickSize","Name","IssueRate","IssueStartDate","IusseIPDate",
           "IssueMaturityDate","FreezePercent","LisingDate","ExpulsionDate","ReAdmissionDate","ExDate","RecordDate",
           "NoDeliveryStartDate","NoDelieryEndDate","ParticipateinMktIndex","AON","MF","WarningPercent",
           "BookClosureStartDate","BookClosureEndDate","Dividend","Rights","Bonus","erest","AGM","EGM","MMSpread",
           "MMMinQty","SSEC","Remark","LocalDBUpdateDateTime","DeleteFlag","FaceValue","ISIN"]
    
    nse_scrip=pd.read_csv(path+"security.txt",header=None, sep='|', names=list2, index_col=False, skiprows=1)
    nse_scrip[['EligibilityNormalMkt','EligibilityAddMarket2']] = nse_scrip[['EligibilityNormalMkt','EligibilityAddMarket2']].astype(str)
    #nse_scrip=nse_scrip[0].str.split('|',expand=True)
    #nse_scrip.columns=list2
        
    nse_scrip=nse_scrip[nse_scrip.apply(lambda x: ((x['Series']=='EQ' or x['Series']=='BE' or \
                                                    ((x['Series']=='E1') and (x['Symbol'] in _E1_list) ) or\
                                                    ((x['Series']=='RR') and (x['Symbol'] in _RR_list) )) \
                                                    and x["DeleteFlag"]=='N' and x["EligibilityNormalMkt"]=='1') \
                                                    or (x["DeleteFlag"]=='N' and x["EligibilityAddMarket2"]=='1'), axis=1)]
    #nse_scrip=nse_scrip[((nse_scrip['Series'].isin(["EQ","BE"])) & (nse_scrip['DeleteFlag']=='N') & (nse_scrip['EligibilityNormalMkt']=="1"))\
    #                    | ((nse_scrip['DeleteFlag']=='N') & (nse_scrip['EligibilityAddMarket2']=="1"))]
    
    
    nse_scrip.reset_index(drop=True,inplace=True)
    
    Lcp=nse_scrip["CreditRating"].str.split('-',expand=True)
    #new=nse_scrip[nse_scrip.apply(lambda x: x["CreditRating"].str.split('-',expand=True)[1] if x["CreditRating"].str.contains('-',regex=True) else x["CreditRating"]==' ')]
    nse_scrip["LowerCircuitPrice"]=np.where(Lcp[0]== " ",-1,Lcp[0])
    nse_scrip["UpperCircuitPrice"]=np.where(Lcp[1]== " ",-1,Lcp[1])
    
    nse_scrip["ExchangeSegment"]="NSE"
    nse_scrip["ScripType"]="NORMAL"
    nse_scrip["TickSize"]=nse_scrip["TickSize"].astype(float)
    nse_scrip["TickSize"]=nse_scrip["TickSize"]*0.01
    
    nse_scrip["StrikePrice"]=-1.0
    nse_scrip["ExpiryDate"]='XX'
    nse_scrip["OptionType"]='XX'
    nse_scrip["VolumeFreezeQty"]=-1.0
    nse_scrip["OrderPlaced"]=False 
    nse_scrip['TradingSymbol']=nse_scrip['Symbol']+"-"+nse_scrip['Series']
    # update volume freeze qty
    nse_scrip = nse_scrip.merge(load_freeze_qty(), on='TradingSymbol', how='left')
    nse_scrip.loc[nse_scrip['FREEZE_QTY']!=np.nan, 'VolumeFreezeQty'] = nse_scrip['FREEZE_QTY']
    nse_scrip['UnderLyingSecurityCode'] = "XX"
    
    nse_scrip.reset_index(drop=True,inplace=True)    
    del list2
    return nse_scrip

def monthly_weekly_fut_contracts(grp):
    '''Func to diff between weekly n monthly contracts'''
    
    temp = grp.copy(deep=True)
    temp['ExpiryDate'] = pd.to_datetime(temp['ExpiryDate'],format="%d-%m-%Y" )
    temp['ExpiryDate'] = temp['ExpiryDate'].dt.date
    month_exp = temp.groupby(by=['ExpiryMonth','ExpiryYear'])['ExpiryDate'].max().values.tolist()
    print month_exp
    temp.loc[~(temp['ExpiryDate'].isin(month_exp)) ,
             ['IsCurrentMonthContract','IsNextMonthContract','IsFarMonthContract']] = False,False,False  
    
    grp[['IsCurrentMonthContract','IsNextMonthContract','IsFarMonthContract']]=temp[['IsCurrentMonthContract','IsNextMonthContract','IsFarMonthContract']]
    
    return grp
    


def nfo_c_reader(nd):
    list3=["SecurityCode","UnderLyingSecurityCode","InstrumentType","Symbol","Series","Filler0","ExpiryDate","StrikePrice",
           "OptionType","SegmentType","CaLevel","ReservedIdentifier","AdmissionType","IssueInfoRate","SercurityStatusNormalMkt",
           "EligibilityNormalMkt","Filler1","SecurityStatusOddLotMarket","EligibilityOddLotMarket","Filler2",
           "SecurityStatusSpotMarket","EligibilitySportMarket","Filler3","SecurityStatusAuctionMarket",
           "EligibilityAuctionMarket","Filler4","IssueInfoStartDate","IssueInfoIpd","issueInfoMatDate",
           "MarginPercentage","MinLotSize","LotSize","TickSize","IssuedCapital","VolumeFreezeQty","WarningQtyOutstn",
           "DateTimeAdmission","DateTimeExpulsion","DateTimeReadmission","DateTimeRecord","DateTimeNoDelStart",
           "DateTimeNoDelEnd","LowerCircuitPrice","UpperCircuitPrice","ExDate","BookClosureStartDate","BookClosureEndDate",
           "RecordDate","ExDateStart","ExDateEnd","TickerSelection","CaOldToken","CreditRating","TradingSymbol","EgmAgm",
           "erestDividend","RightsBonus","Mfaon","Remarks","ExStyle","ExAllowed","ExRejAllowed","PlAllowed","Filler5",
           "IsCorpActions","AssetSymbol","Filler6","BasePrice","DeleteFlag"]
    nfo_c=pd.read_csv(path+"contract.txt",header=None, sep='|', names=list3, index_col=False, skiprows=1)   
    #nfo_c=nfo_c[1:]
    #nfo_c=nfo_c[0].str.split('|',expand=True)
    #nfo_c.columns=list3
    nfo_c = nfo_c[nfo_c['InstrumentType'].isin(['FUTSTK','FUTIDX','OPTSTK','OPTIDX'])]
    #nfo_c=nfo_c[nfo_c.apply(lambda x: x['InstrumentType']=='FUTSTK' or  x['InstrumentType']=='FUTIDX' or  x['InstrumentType']=='OPTSTK' or  x['InstrumentType']=='OPTIDX', axis=1)]
    
    del list3
    
    #nfo_c["ExpiryDate"]=nfo_c["ExpiryDate"].astype(int)
    nfo_c["ExpiryDate"]=nfo_c['ExpiryDate'].apply(lambda x: expirydate_jiffy(x))
    #nfo_c["ExpiryDate"]=nfo_c["ExpiryDate"].astype('datetime64[ns]')
    
    nfo_c["ExpiryYear"]=nfo_c["ExpiryDate"].apply(lambda x: int(x.split("-")[-1]))
    nfo_c["ExpiryMonth"]=nfo_c["ExpiryDate"].apply(lambda x: int(x.split("-")[1]))
    nfo_c["ExpiryDay"]=nfo_c["ExpiryDate"].apply(lambda x: int(x.split("-")[0]))
    #nfo_c['ExpiryDate'] = nfo_c['ExpiryDate'].apply(lambda x: x.strftime("%d-%m-%Y"))
    #nfo_c["ExpiryDate"]=nfo_c["ExpiryDate"].dt.date
    d = (datetime.datetime.now()-datetime.timedelta(days=nd))
    nfo_c["CurrentYear"]=d.date().year
    nfo_c["CurrentMonth"]=d.date().month
    nfo_c["CurrentDay"]=d.date().day
    
    nfo_c.reset_index(drop=True,inplace=True)    
    nfo_c['TempMonth'] = np.where((nfo_c['CurrentMonth']==nfo_c['ExpiryMonth']) & (nfo_c['CurrentYear']==nfo_c['ExpiryYear'])\
                                                             & (nfo_c['CurrentDay']>nfo_c['ExpiryDay']),
                                                             nfo_c['CurrentMonth']+1, nfo_c['CurrentMonth'])
    nfo_c['diff'] = abs(nfo_c['ExpiryMonth']-nfo_c['TempMonth'])    
    nfo_c['IsCurrentMonthContract'] = np.where(nfo_c['diff']==0,True,False)
    nfo_c['IsNextMonthContract'] = np.where((nfo_c['diff']==1) | (nfo_c['diff']==11),True,False)
    nfo_c['IsFarMonthContract'] = np.where((nfo_c['diff']==2) | (nfo_c['diff']==10),True,False)
    
    
    nfo_c["ScripType"]='NORMAL'
    nfo_c[["StrikePrice","TickSize","LowerCircuitPrice","UpperCircuitPrice"]]=nfo_c[["StrikePrice","TickSize","LowerCircuitPrice","UpperCircuitPrice"]].astype(float)
    nfo_c[["StrikePrice","TickSize","LowerCircuitPrice","UpperCircuitPrice"]]=nfo_c[["StrikePrice","TickSize","LowerCircuitPrice","UpperCircuitPrice"]]*0.01

        
    td = d
    td=td.strftime("%b")
    td=td.upper()
    nfo_c["OrderPlaced"]=False
    nfo_c["CurrentMonthName"]=td
    nfo_c["CurrentMonthName"]=nfo_c["CurrentMonthName"].str.upper()
    p=str(d.year)
    nfo_c["ExchangeSegment"]="NFO"
    nfo_c.reset_index(drop=True,inplace=True)
    
    # update months only for FUT in case today is after Expiry day and curr month != expiry month
    if nfo_c[nfo_c['TradingSymbol']=="NIFTY"+'{}'.format(p[2:])+td+"FUT"].empty==True:
        print "After expiry day condition"
        currentmonth = int(d.strftime("%m"))
        currentmonth = 1 if(currentmonth == 12) else currentmonth +1
        
        # update
        nfo_c['diff'] = abs(nfo_c['ExpiryMonth']-currentmonth)    
        nfo_c['IsCurrentMonthContract'] = np.where(nfo_c['diff']==0,True,False)
        nfo_c['IsNextMonthContract'] = np.where((nfo_c['diff']==1) | (nfo_c['diff']==11),True,False)
        nfo_c['IsFarMonthContract'] = np.where((nfo_c['diff']==2) | (nfo_c['diff']==10),True,False)
        
        
        '''
        expiries = list(sorted([ datetime.datetime.strptime(expiry, "%d-%m-%Y").date() \
                      for expiry in set(nfo_c[(nfo_c['Symbol']=='NIFTY') & (nfo_c['InstrumentType']=='FUTIDX')]['ExpiryDate'])]))
               
        nfo_c.loc[(nfo_c['InstrumentType'].str.startswith("FUT")) & (nfo_c['ExpiryDate']==expiries[0].strftime("%d-%m-%Y")) ,
                      ['IsCurrentMonthContract','IsNextMonthContract','IsFarMonthContract']] = True,False,False                  
        nfo_c.loc[(nfo_c['InstrumentType'].str.startswith("FUT")) & (nfo_c['ExpiryDate']==expiries[1].strftime("%d-%m-%Y")) ,
                      ['IsCurrentMonthContract','IsNextMonthContract','IsFarMonthContract']] = False,True,False
        nfo_c.loc[(nfo_c['InstrumentType'].str.startswith("FUT")) & (nfo_c['ExpiryDate']==expiries[-1].strftime("%d-%m-%Y")) ,
                      ['IsCurrentMonthContract','IsNextMonthContract','IsFarMonthContract']] = False,False,True
        '''
    del td,p
    
    # handle weekly fut expiry cases
    result = nfo_c[~(nfo_c['InstrumentType']=='FUTIDX')].copy(deep=True)
    nfo_c = nfo_c[(nfo_c['InstrumentType']=='FUTIDX')]
    
    nfo_c = nfo_c.groupby(by=['Symbol'], as_index=False).apply(lambda grp: monthly_weekly_fut_contracts(grp) )
    
    nfo_c=pd.concat([nfo_c, result], axis=0)
    
    return nfo_c

def sp_c_reader(nfo_c):

    list4=["SecurityCode1","SecurityCode2","InstrumentType1","Symbol1","Series1","ExpiryDate1","StrikePrice1",
           "OptionType1","CaLevel1","InstrumentType2","Symbol2","Series2","ExpiryDate2","StrikePrice2",
           "OptionType2","CaLevel2","ReferencePrice","DayLowPriceDiffRange","DayHighPriceDiffRange",
           "OpLowPriceDiffRange","OpHighPriceDiffRange","BoardLotQuantity1","MinimumLotQuantity1","TickSize1", 
           "BoardLotQuantity2","MinimumLotQuantity2","TickSize2","Eligibility","DeleteFlag"]

    sp_c=pd.read_csv(path+"spd_contract.txt",header=None,sep='|', names=list4, index_col=False, skiprows=1)   
    #sp_c=sp_c[1:]
    #sp_c=sp_c[0].str.split('|',expand=True)
    #sp_c.columns=list4
    sp_c.reset_index(drop=True,inplace=True)
    sp_c[["StrikePrice1","StrikePrice2","TickSize1","TickSize2","DayLowPriceDiffRange","DayHighPriceDiffRange"]]=sp_c[["StrikePrice1","StrikePrice2","TickSize1","TickSize2","DayLowPriceDiffRange","DayHighPriceDiffRange"]].astype(float)
    sp_c[["TickSize1","TickSize2","DayLowPriceDiffRange","DayHighPriceDiffRange"]]=sp_c[["TickSize1","TickSize2","DayLowPriceDiffRange","DayHighPriceDiffRange"]]*0.01
    sp_c["LowerCircuitPrice"]=sp_c["DayLowPriceDiffRange"]
    sp_c["UpperCircuitPrice"]=sp_c["DayHighPriceDiffRange"]
        
    del list4
    
    sp_c["ExchangeSegment"]="NFO"

    sp_c["ScripType"]="SPREAD"

    #sp_c[["ExpiryDate1","ExpiryDate2"]]=sp_c[["ExpiryDate1","ExpiryDate2"]].astype(int)
    sp_c["ExpiryDate1"]=sp_c["ExpiryDate1"].apply(lambda x: expirydate_jiffy(x))
    sp_c["ExpiryDate2"]=sp_c["ExpiryDate2"].apply(lambda x: expirydate_jiffy(x))
    #sp_c[["ExpiryDate1","ExpiryDate2"]]=sp_c[["ExpiryDate1","ExpiryDate2"]].astype('datetime64[ns]')
    sp_c["ExpiryYear1"]=sp_c["ExpiryDate1"].apply(lambda x: int(x.split("-")[-1]))
    sp_c["ExpiryMonth1"]=sp_c["ExpiryDate1"].apply(lambda x: int(x.split("-")[1]))
    sp_c["ExpiryYear2"]=sp_c["ExpiryDate2"].apply(lambda x: int(x.split("-")[-1]))
    sp_c["ExpiryMonth2"]=sp_c["ExpiryDate2"].apply(lambda x: int(x.split("-")[1]))
    #sp_c['ExpiryDate1'] = sp_c['ExpiryDate1'].apply(lambda x: x.strftime("%d-%m-%Y"))
    #sp_c['ExpiryDate2'] = sp_c['ExpiryDate2'].apply(lambda x: x.strftime("%d-%m-%Y"))    
    #sp_c["ExpiryDate1"]=sp_c["ExpiryDate1"].dt.date
    #sp_c["ExpiryDate2"]=sp_c["ExpiryDate2"].dt.date
    
    expy1 = [str(x).strip()[2:] for x in sp_c['ExpiryYear1']]
    expy2 = [str(x).strip()[2:] for x in sp_c['ExpiryYear2']]
    
    expm1 = sp_c["ExpiryMonth1"].map(d_cal).str.upper()
    expm2 = sp_c["ExpiryMonth2"].map(d_cal).str.upper()

    sp_c["TradingSymbol"]=sp_c["Symbol1"]+expy1+expm1+expy2+expm2+"FUT"
    
    del expy1,expy2,expm1,expm2
        
    sp_c=sp_c.merge(nfo_c.rename(columns={"SecurityCode":"SecurityCode1"})[["SecurityCode1","UnderLyingSecurityCode",
                                "IsCurrentMonthContract","IsNextMonthContract","IsFarMonthContract","VolumeFreezeQty"]],
                                        on=["SecurityCode1"],how='left')
    
    sp_c=sp_c.merge(nfo_c.rename(columns={"SecurityCode":"SecurityCode2"})[["IsCurrentMonthContract","IsNextMonthContract",
                    "IsFarMonthContract","SecurityCode2"]],on=["SecurityCode2"],how='left', suffixes=('1','2'))
    
    
    sp_c["ExpiryDate"]=sp_c["ExpiryDate1"].astype(str)+" "+sp_c["ExpiryDate2"].astype(str)
    sp_c[["Symbol","Series","InstrumentType","StrikePrice","OptionType","LotSize","TickSize"]]=sp_c[["Symbol1","Series1","InstrumentType1","StrikePrice1","OptionType1","MinimumLotQuantity1","TickSize1"]]
    
    sp_c["SecurityCode"]=sp_c["SecurityCode1"].astype(str)+" "+sp_c["SecurityCode2"].astype(str)
    sp_c['OrderPlaced']=False
    sp_c["IsCurrentMonthNextMonthSpreadContract"]=sp_c["IsCurrentMonthContract1"]*sp_c["IsNextMonthContract2"]
    sp_c["IsNextMonthFarMonthSpreadContract"]=sp_c["IsNextMonthContract1"]*sp_c["IsFarMonthContract2"]
    sp_c["IsCurrentMonthFarMonthSpreadContract"]=sp_c["IsCurrentMonthContract1"]*sp_c["IsFarMonthContract2"]
    
    sp_c.reset_index(drop=True,inplace=True)
    
    return sp_c

def load_bhavcopy_closeprices(bse_scrip,nse_scrip,nfo_c,sp_c):
    
    cm=pd.read_csv(path+'cmbhav.csv')
    cm["TradingSymbol"]=cm["SYMBOL"]+'-'+cm["SERIES"]
    cm["PreviousClose"]=cm["CLOSE"]

    fo=pd.read_csv(path+'fobhav.csv')
    fo=fo[fo['INSTRUMENT'].isin(['FUTSTK','FUTIDX','OPTSTK','OPTIDX'])]
    fo["ExchangeSegment"]="NFO"
    fo["Series"]="XX"
    fo["STRIKE_PR"]=np.where(fo["STRIKE_PR"]==0,-0.01,fo["STRIKE_PR"])
    fo["ScripType"]="NORMAL"
    fo["Expiry"]=pd.to_datetime(fo['EXPIRY_DT'], format='%d-%b-%Y')
    fo['Expiry']=fo['Expiry'].apply(lambda x: x.strftime("%d-%m-%Y"))
    #fo["Expiry"]=fo["Expiry"].dt.date
    fo["PreviousClose"]=fo["CLOSE"]
    
    bse=pd.read_csv(path+'bsebhav.csv')
    bse["ExchangeSegment"]="BSE"
    bse["common"]=bse["ExchangeSegment"]+str(bse["SC_CODE"])
    bse["SecurityCode"]=bse["SC_CODE"].astype(str)
    bse["PreviousClose"]=bse["CLOSE"]
    
    #bse_scrip["TradingSymbol"]=bse_scrip["Symbol"]+bse_scrip["Series"]
    #nse_scrip["TradingSymbol"]=nse_scrip["Symbol"]+nse_scrip["Series"]
    
    bse_scrip=bse_scrip.merge(bse[['ExchangeSegment','SecurityCode','PreviousClose']],on=['ExchangeSegment','SecurityCode'],how='left')
    nse_scrip=nse_scrip.merge(cm[['TradingSymbol','PreviousClose']],on='TradingSymbol',how='left')


    nfo_c["common"]=nfo_c["ScripType"].astype(str)+nfo_c["ExchangeSegment"].astype(str)+nfo_c["Symbol"].astype(str)\
                    +nfo_c["Series"].astype(str)+nfo_c["InstrumentType"].astype(str)+nfo_c["ExpiryDate"].astype(str)\
                    +nfo_c["StrikePrice"].astype(str)+nfo_c["OptionType"].astype(str)
    fo["common"]=fo["ScripType"].astype(str)+fo["ExchangeSegment"].astype(str)+fo["SYMBOL"].astype(str)+fo["Series"].astype(str)\
                    +fo["INSTRUMENT"].astype(str)+fo["Expiry"].astype(str)+fo["STRIKE_PR"].astype(str)+fo["OPTION_TYP"].astype(str)
    #sp_c["common"]=str(sp_c["ScripType"])+str(sp_c["ExchangeSegment"])+str(sp_c["Symbol"])+str(sp_c["Series"])+str(sp_c["InstrumentType"])+str(sp_c["ExpiryDate"])+str(sp_c["StrikePrice"])+str(sp_c["OptionType"])
    
    #bse_dp["common"]=str(bse_dp["ScripType"])+str(bse_dp["ExchangeSegment"])+str(bse_dp["Symbol"])+str(bse_dp["Series"])+str(bse_dp["InstrumentType"])+str(bse_dp["ExpiryDate"])+str(bse_dp["StrikePrice"])+str(bse_dp["OptionType"])

    fo=fo[["common","PreviousClose"]]
    nfo_c=nfo_c.merge(fo,on='common',how='left')
    #sp_c=sp_c.merge(fo,on="common",how='left')
    #bse_dp=bse_dp.merge(fo,on="common",how='left')
    del cm,bse,fo
    return bse_scrip,nse_scrip,nfo_c,sp_c


def final(bse_scrip,nse_scrip,nfo_c,sp_c):
    
    security_codes = pd.DataFrame()
    futidx_codes = pd.DataFrame()
    
    # cash equities
    nse_scrip.loc[(nse_scrip['ExchangeSegment']=="NSE") & (nse_scrip['Series'].isin(['EQ','BE','IL','E1'])), 'NseSecurityCode'] = nse_scrip['SecurityCode']
    nse_scrip.loc[(nse_scrip['ExchangeSegment']=="NSE") & (nse_scrip['Series'].isin(['EQ','BE','IL','E1'])), 'NseISIN'] = nse_scrip['ISIN']
    temp = nse_scrip[['NseSecurityCode','NseISIN']].dropna(); temp['NseSecurityCode'] = temp['NseSecurityCode'].astype(int)
    security_codes = security_codes.append(temp) #NSE

    
    bse_scrip.loc[(bse_scrip['ExchangeSegment']=="BSE") & ( (bse_scrip['SecurityCode'].str.startswith("5")) | (bse_scrip['SecurityCode'].str.startswith("8"))),
                  "BseSecurityCode"]=bse_scrip["SecurityCode"]
    
    bse_temp1 = bse_scrip[(bse_scrip['ExchangeSegment']=="BSE") & ( (bse_scrip['SecurityCode'].str.startswith("5")) \
                  | (bse_scrip['SecurityCode'].str.startswith("6")) | (bse_scrip['SecurityCode'].str.startswith("8"))) \
                 & (~bse_scrip['ISIN'].isin(nse_scrip['NseISIN'].values.tolist()))][['SecurityCode','ExchangeSegment',
                   'Symbol','ISIN']]
    
    
    security_codes = security_codes.merge(bse_scrip[['ISIN','BseSecurityCode']].rename(columns={'ISIN':'NseISIN'}), 
                                          on='NseISIN', how='left')
    #nse_scrip = nse_scrip.merge(bse_scrip[['ISIN','BseSecurityCode']].rename(columns={'ISIN':'NseISIN'}), on='NseISIN', how='left')
    #bse_scrip = bse_scrip.merge(nse_scrip[['NseISIN','NseSecurityCode']].rename(columns={'NseISIN':'ISIN'}), on='ISIN', how='left')
    #bse_scrip = bse_scrip[(bse_scrip['ISIN'].isin(nse_scrip['NseISIN'].values.tolist()))]
    
    #fno contracts 
    # ssf
    # normal window
    # current month
    nfo_c['CurrentMonthFutureSecurityCode'] = np.where(((nfo_c['ExchangeSegment']=='NFO') & (nfo_c['UnderLyingSecurityCode'].isin(nse_scrip['NseSecurityCode'].values.tolist())) & \
              (nfo_c["InstrumentType"]=="FUTSTK") & (nfo_c["IsCurrentMonthContract"]==True)),nfo_c['SecurityCode'],'NA')    
    # next month
    nfo_c['NextMonthFutureSecurityCode'] = np.where(((nfo_c['ExchangeSegment']=='NFO') & (nfo_c['UnderLyingSecurityCode'].isin(nse_scrip['NseSecurityCode'].values.tolist())) & \
              (nfo_c["InstrumentType"]=="FUTSTK") & (nfo_c["IsNextMonthContract"]==True)),nfo_c['SecurityCode'],'NA')    
    # far month
    nfo_c['FarMonthFutureSecurityCode'] = np.where(((nfo_c['ExchangeSegment']=='NFO') & (nfo_c['UnderLyingSecurityCode'].isin(nse_scrip['NseSecurityCode'].values.tolist())) & \
              (nfo_c["InstrumentType"]=="FUTSTK") & (nfo_c["IsFarMonthContract"]==True)),nfo_c['SecurityCode'],'NA')    
    # index FUTIDX
    # current month
    nfo_c.loc[((nfo_c['ExchangeSegment']=='NFO') & (nfo_c["InstrumentType"]=="FUTIDX") & (nfo_c["IsCurrentMonthContract"]==True)),
                  'CurrentMonthFutureSecurityCode'] = nfo_c['SecurityCode']
    # next month
    nfo_c.loc[((nfo_c['ExchangeSegment']=='NFO') & (nfo_c["InstrumentType"]=="FUTIDX") & (nfo_c["IsNextMonthContract"]==True)),
                  'NextMonthFutureSecurityCode'] = nfo_c['SecurityCode']
    # far month
    nfo_c.loc[((nfo_c['ExchangeSegment']=='NFO') & (nfo_c["InstrumentType"]=="FUTIDX") & (nfo_c["IsFarMonthContract"]==True)),
                  'FarMonthFutureSecurityCode'] = nfo_c['SecurityCode']
    #future normal contracts security codes
    security_codes = security_codes.merge(nfo_c[(nfo_c['InstrumentType']=='FUTSTK') & (nfo_c['ExchangeSegment']=='NFO') \
                                                & (nfo_c['CurrentMonthFutureSecurityCode']!='NA')][['UnderLyingSecurityCode',
                        'CurrentMonthFutureSecurityCode']].rename(columns={'UnderLyingSecurityCode':'NseSecurityCode'}), 
                                                                    on='NseSecurityCode', how='left')
    security_codes = security_codes.merge(nfo_c[(nfo_c['InstrumentType']=='FUTSTK') & (nfo_c['ExchangeSegment']=='NFO')\
                                                & (nfo_c['NextMonthFutureSecurityCode']!='NA')][['UnderLyingSecurityCode',
                        'NextMonthFutureSecurityCode']].rename(columns={'UnderLyingSecurityCode':'NseSecurityCode'}), 
                                                                    on='NseSecurityCode', how='left')
    security_codes = security_codes.merge(nfo_c[(nfo_c['InstrumentType']=='FUTSTK') & (nfo_c['ExchangeSegment']=='NFO')\
                                                & (nfo_c['FarMonthFutureSecurityCode']!='NA')][['UnderLyingSecurityCode',
                        'FarMonthFutureSecurityCode']].rename(columns={'UnderLyingSecurityCode':'NseSecurityCode'}), 
                                                                    on='NseSecurityCode', how='left')
        
    # futidx codes
    futidx_codes = futidx_codes.append(nfo_c[(nfo_c['ExchangeSegment']=='NFO') & (nfo_c["InstrumentType"]=="FUTIDX") \
                            & (nfo_c["IsCurrentMonthContract"]==True)][['UnderLyingSecurityCode','CurrentMonthFutureSecurityCode']])
    futidx_codes = futidx_codes.merge(nfo_c[(nfo_c['ExchangeSegment']=='NFO') & (nfo_c["InstrumentType"]=="FUTIDX") \
                            & (nfo_c["IsNextMonthContract"]==True)][['UnderLyingSecurityCode','NextMonthFutureSecurityCode']],
                                on='UnderLyingSecurityCode', how='left')
    futidx_codes = futidx_codes.merge(nfo_c[(nfo_c['ExchangeSegment']=='NFO') & (nfo_c["InstrumentType"]=="FUTIDX") \
                            & (nfo_c["IsFarMonthContract"]==True)][['UnderLyingSecurityCode','FarMonthFutureSecurityCode']],
                                on='UnderLyingSecurityCode', how='left')
    
    #spread window
    # ssf
    # current next month
    sp_c['CurrentMonthNextMonthSpreadSecurityCode'] = np.where(((sp_c['ExchangeSegment']=='NFO') & (sp_c['UnderLyingSecurityCode'].isin(nse_scrip['NseSecurityCode'].values.tolist())) & \
              (sp_c["InstrumentType"]=="FUTSTK") & (sp_c["IsCurrentMonthNextMonthSpreadContract"]==True)),sp_c['SecurityCode'],'NA')    
    # next far month
    sp_c['NextMonthFarMonthSpreadSecurityCode'] = np.where(((sp_c['ExchangeSegment']=='NFO') & (sp_c['UnderLyingSecurityCode'].isin(nse_scrip['NseSecurityCode'].values.tolist())) & \
              (sp_c["InstrumentType"]=="FUTSTK") & (sp_c["IsNextMonthFarMonthSpreadContract"]==True)),sp_c['SecurityCode'],'NA')    
    # current far month
    sp_c['CurrentMonthFarMonthSpreadSecurityCode'] = np.where(((sp_c['ExchangeSegment']=='NFO') & (sp_c['UnderLyingSecurityCode'].isin(nse_scrip['NseSecurityCode'].values.tolist())) & \
              (sp_c["InstrumentType"]=="FUTSTK") & (sp_c["IsCurrentMonthFarMonthSpreadContract"]==True)),sp_c['SecurityCode'],'NA')
    
    # index FUTIDX
    # current next month
    sp_c.loc[(sp_c['ExchangeSegment']=='NFO') & (sp_c["InstrumentType"]=="FUTIDX") & \
             (sp_c["IsCurrentMonthNextMonthSpreadContract"]==True),'CurrentMonthNextMonthSpreadSecurityCode'] = sp_c['SecurityCode']
    # next far month
    sp_c.loc[(sp_c['ExchangeSegment']=='NFO') & (sp_c["InstrumentType"]=="FUTIDX") & \
             (sp_c["IsNextMonthFarMonthSpreadContract"]==True),'NextMonthFarMonthSpreadSecurityCode'] = sp_c['SecurityCode']

    # current far month
    sp_c.loc[(sp_c['ExchangeSegment']=='NFO') & (sp_c["InstrumentType"]=="FUTIDX") & \
             (sp_c["IsCurrentMonthFarMonthSpreadContract"]==True),'CurrentMonthFarMonthSpreadSecurityCode'] = sp_c['SecurityCode']
    
    
    #future spread contracts security codes
    security_codes = security_codes.merge(sp_c[(sp_c['InstrumentType']=='FUTSTK') & (sp_c['ExchangeSegment']=='NFO') \
                                                & (sp_c['CurrentMonthNextMonthSpreadSecurityCode']!='NA')][['UnderLyingSecurityCode',
                        'CurrentMonthNextMonthSpreadSecurityCode']].rename(columns={'UnderLyingSecurityCode':'NseSecurityCode'}), 
                                                                    on='NseSecurityCode', how='left')
    security_codes = security_codes.merge(sp_c[(sp_c['InstrumentType']=='FUTSTK') & (sp_c['ExchangeSegment']=='NFO')\
                                                & (sp_c['NextMonthFarMonthSpreadSecurityCode']!='NA')][['UnderLyingSecurityCode',
                        'NextMonthFarMonthSpreadSecurityCode']].rename(columns={'UnderLyingSecurityCode':'NseSecurityCode'}), 
                                                                    on='NseSecurityCode', how='left')
    security_codes = security_codes.merge(sp_c[(sp_c['InstrumentType']=='FUTSTK') & (sp_c['ExchangeSegment']=='NFO')\
                                                & (sp_c['CurrentMonthFarMonthSpreadSecurityCode']!='NA')][['UnderLyingSecurityCode',
                        'CurrentMonthFarMonthSpreadSecurityCode']].rename(columns={'UnderLyingSecurityCode':'NseSecurityCode'}), 
                                                                    on='NseSecurityCode', how='left')
    
    # futidx
    futidx_codes = futidx_codes.merge(sp_c[(sp_c['ExchangeSegment']=='NFO') & (sp_c["InstrumentType"]=="FUTIDX") \
                            & (sp_c["IsCurrentMonthNextMonthSpreadContract"]==True)][['UnderLyingSecurityCode','CurrentMonthNextMonthSpreadSecurityCode']],
                                on='UnderLyingSecurityCode', how='left')
    futidx_codes = futidx_codes.merge(sp_c[(sp_c['ExchangeSegment']=='NFO') & (sp_c["InstrumentType"]=="FUTIDX") \
                            & (sp_c["IsNextMonthFarMonthSpreadContract"]==True)][['UnderLyingSecurityCode','NextMonthFarMonthSpreadSecurityCode']],
                                on='UnderLyingSecurityCode', how='left')
    futidx_codes = futidx_codes.merge(sp_c[(sp_c['ExchangeSegment']=='NFO') & (sp_c["InstrumentType"]=="FUTIDX") \
                            & (sp_c["IsCurrentMonthFarMonthSpreadContract"]==True)][['UnderLyingSecurityCode','CurrentMonthFarMonthSpreadSecurityCode']],
                                on='UnderLyingSecurityCode', how='left')
    
    
    # update
    #cash
    nse_scrip = nse_scrip.merge(security_codes.drop(columns=['NseSecurityCode']), on='NseISIN', how='left')
    bse_scrip = bse_scrip.merge(security_codes.drop(columns=['NseISIN']), on='BseSecurityCode', how='left')   
    for col in ['CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode','FarMonthFutureSecurityCode']:
        nse_scrip.loc[(nse_scrip['ExchangeSegment']=="NSE") & (nse_scrip['Series'].isin(['EQ','BE','IL','E1'])) & nse_scrip[col].isin([np.nan,np.NAN,np.NaN]), col] = 'NA'
    
    bse_scrip[['CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode','FarMonthFutureSecurityCode','ISIN']] = bse_scrip[['CurrentMonthFutureSecurityCode',
                                                             'NextMonthFutureSecurityCode','FarMonthFutureSecurityCode','ISIN']].replace([np.nan,np.NAN,np.NaN], 'NA')
    
    # handle BSE null codes
    for col in ['CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode','FarMonthFutureSecurityCode']:
        bse_scrip.loc[bse_scrip['SecurityCode'].isin(bse_temp1['SecurityCode'].values.tolist()), col] = np.nan
    
    
    # futures
    security_codes['temp'] = security_codes['NseSecurityCode'].astype(str)+"FUTSTK"
    nfo_c['temp'] = nfo_c['UnderLyingSecurityCode'].astype(str)+nfo_c['InstrumentType'].astype(str)
    for col in ['NseSecurityCode','BseSecurityCode','CurrentMonthNextMonthSpreadSecurityCode','NextMonthFarMonthSpreadSecurityCode','CurrentMonthFarMonthSpreadSecurityCode']:
        nfo_c = nfo_c.merge(security_codes[['temp',col]], on='temp', how='left')
    
    for col in ['CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode','FarMonthFutureSecurityCode']:
        nfo_c = nfo_c.merge(security_codes[['temp',col]], on='temp', how='left', suffixes=('','_y'))
        nfo_c.loc[(nfo_c['InstrumentType']=='FUTSTK') & (nfo_c[col]=='NA'), col] = nfo_c['{}_y'.format(col)]
        nfo_c.drop(columns=['{}_y'.format(col)], inplace=True)
    
        # replace NA with null for options contracts
        nfo_c.loc[(nfo_c['InstrumentType'].isin(['OPTSTK','OPTIDX'])) & (nfo_c[col]=='NA'), col] = np.nan
    
    
    
    
    # fut spread
    sp_c['temp'] = sp_c['UnderLyingSecurityCode'].astype(str)+sp_c['InstrumentType'].astype(str)
    for col in ['NseSecurityCode','BseSecurityCode','CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode','FarMonthFutureSecurityCode']:
        sp_c = sp_c.merge(security_codes[['temp',col]], on='temp', how='left')
    
    for col in ['CurrentMonthNextMonthSpreadSecurityCode','NextMonthFarMonthSpreadSecurityCode','CurrentMonthFarMonthSpreadSecurityCode']:
        sp_c = sp_c.merge(security_codes[['temp',col]], on='temp', how='left', suffixes=('','_y'))
        sp_c.loc[(sp_c['InstrumentType']=='FUTSTK') , col] = sp_c['{}_y'.format(col)]
        sp_c.drop(columns=['{}_y'.format(col)], inplace=True)
    

    
    return bse_scrip,nse_scrip,nfo_c,sp_c, security_codes, futidx_codes

def merge_all_contracts(bse_scrip,nse_scrip,nfo_c,sp_c, security_codes, futidx_codes):
    
    final_df = pd.DataFrame()
    # cash
    final_df = final_df.append(add_columns(instrument_columns, bse_scrip)[instrument_columns], ignore_index=True)
    final_df = final_df.append(add_columns(instrument_columns, nse_scrip)[instrument_columns], ignore_index=True)
    # nfo normal contracts
    final_df=final_df.append(add_columns(instrument_columns, nfo_c)[instrument_columns], ignore_index=True)
    # nfo spread contracts
    final_df=final_df.append(add_columns(instrument_columns, sp_c)[instrument_columns], ignore_index=True)
    
    # replace boolean columns with 1 and 0
    for col in [i for i in final_df.columns if i.startswith("Is")]:
        final_df.loc[final_df[col]==True, col] = 1
        final_df.loc[final_df[col]==False, col] = 0
    final_df['OrderPlaced'] = np.where(final_df['OrderPlaced']==True,1,0)
    
    # futidx codes
    futidx_codes['temp'] = futidx_codes['UnderLyingSecurityCode'].astype(str)+'FUTIDX'
    final_df['temp'] = final_df['UnderLyingSecurityCode'].astype(str)+final_df['InstrumentType'].astype(str)
    
    
    result=final_df[~(final_df['InstrumentType']=='FUTIDX')].copy(deep=True)
    final_df = final_df[(final_df['InstrumentType']=='FUTIDX')]
    
    for col in ['CurrentMonthFutureSecurityCode','NextMonthFutureSecurityCode','FarMonthFutureSecurityCode',
                'CurrentMonthNextMonthSpreadSecurityCode','NextMonthFarMonthSpreadSecurityCode','CurrentMonthFarMonthSpreadSecurityCode']:
        final_df = final_df.merge(futidx_codes[['temp',col]], on='temp', how='left', suffixes=('','_y'))
        final_df.loc[(final_df['InstrumentType']=='FUTIDX') , col] = final_df['{}_y'.format(col)]
        final_df.drop(columns=['{}_y'.format(col)], inplace=True)
    
    final_df = pd.concat([result, final_df], axis=0)
    final_df = final_df[instrument_columns]  
    
    
    return final_df


def create_pairmaster_file(instru, indices_list):
    
    instru = instru[instru['InstrumentType'].isin(['FUTSTK','FUTIDX','OPTSTK','OPTIDX'])]    
    instru = instru[["SecurityCode","UnderLyingSecurityCode","TradingSymbol", "Symbol", "NseSecurityCode","BseSecurityCode",
                      "CurrentMonthFutureSecurityCode","NextMonthFutureSecurityCode","FarMonthFutureSecurityCode","CurrentMonthNextMonthSpreadSecurityCode",
                      "NextMonthFarMonthSpreadSecurityCode","CurrentMonthFarMonthSpreadSecurityCode"]]
    nifty_bn = instru[instru['Symbol'].isin(indices_list)][['Symbol','UnderLyingSecurityCode']].drop_duplicates().head(3)
    instru.drop_duplicates(inplace=True)
    
    #instru.dropna(subset=['CurrentMonthFutureSecurityCode'], inplace=True)
    instru = instru[(instru['CurrentMonthFutureSecurityCode']!='null') & (instru['CurrentMonthFutureSecurityCode']!='NA')]
    instru['SecurityCode'] = instru['SecurityCode'].str.strip()
    
    # nifty bn cash codes
    for index in indices_list:            
        instru.loc[instru['Symbol']==index, 'NseSecurityCode'] = nifty_bn[nifty_bn['Symbol']==index]['UnderLyingSecurityCode'].values[0]
        instru.loc[instru['Symbol']==index, 'BseSecurityCode'] = nifty_bn[nifty_bn['Symbol']==index]['UnderLyingSecurityCode'].values[0]
      
    instru = instru[["Symbol","NseSecurityCode","BseSecurityCode","CurrentMonthFutureSecurityCode",
                     "NextMonthFutureSecurityCode","FarMonthFutureSecurityCode"]]
    instru.drop_duplicates(inplace=True)
    #instru = instru[~instru.eq('null').any(1)]
    
    instru.rename(columns={"NseSecurityCode":"NSECashCode","BseSecurityCode":"BSECashCode",
                           "CurrentMonthFutureSecurityCode":"FutCode_m1","NextMonthFutureSecurityCode":"FutCode_m2",
                           "FarMonthFutureSecurityCode":"FutCode_m3"}, inplace=True)
    instru.sort_values(by=['Symbol'], inplace=True)
    instru = instru[instru['NSECashCode']!='null']
    try:
        instru[["NSECashCode","BSECashCode"]]=instru[["NSECashCode","BSECashCode"]].astype(int)
    except:
        pass


    # o/p file
    instru.to_csv(output_dir+"PairMaster.csv", index=False)



def redis_publisher(df):
    
    df.rename(columns={'OrderPlaced':'OrderPlaced_'}, inplace=True)
    scripmaster = pd.read_csv(path+"scripmaster.csv", names = ['Symbol','BseSymbol','UnnamedField3','Company Name','UnnamedField5',
                                                               'UnnamedField6','ISIN','RICCode','SedolCode','RICBse','UnnamedField11',
                                                               'BseTicker','BloomCode','UnnamedField14','NfoTicker'] )
    scripmaster = scripmaster[['ISIN','SedolCode','BloomCode','RICCode']]
    
    cols = ['SecurityCode','UnderLyingSecurityCode','TradingSymbol','ScripType','ExchangeSegment','Symbol','Series','InstrumentType','ExpiryDate','StrikePrice','OptionType',
            'LotSize','VolumeFreezeQty','TickSize','LowerCircuitPrice','UpperCircuitPrice','OrderPlaced_','NseSecurityCode','BseSecurityCode','CurrentMonthFutureSecurityCode',
            'NextMonthFutureSecurityCode','FarMonthFutureSecurityCode','IsCurrentMonthContract','IsNextMonthContract','IsFarMonthContract','ISIN','PreviousClose',
            'SedolCode','BloomCode','RICCode','IsCurrentMonthNextMonthSpreadContract','IsNextMonthFarMonthSpreadContract','IsCurrentMonthFarMonthSpreadContract']
    scripmaster = scripmaster[(scripmaster['ISIN']!=' ') & (~scripmaster['ISIN'].isnull())]
    #scripmaster.loc[scripmaster['BseTicker'].isnull(), "BseTicker"] = scripmaster['']
    scripmaster.drop_duplicates(inplace=True)
    scripmaster['BloomCode'] = scripmaster['BloomCode'].fillna(" ")
    scripmaster['BloomCode'] = scripmaster['BloomCode'].apply(lambda row: row[1:])
    df = df.merge(scripmaster, on=['ISIN'], how="left")
    df = df[cols]
    df.sort_values(by=['ScripType','ExchangeSegment','Symbol','Series','InstrumentType','ExpiryDate','StrikePrice','OptionType'],
                   inplace=True)
    df.reset_index(inplace=True, drop=True)
    # publish data to redis
    redisClient = redis.StrictRedis(host=redis_host, port=6379,db=0 ) 
    
    # publish a zset
    redisClient.set("InstrumentsOMM:count",len(df))
    for i, row in df.iterrows():
        zset_key = str(row['ScripType'])+str(row['ExchangeSegment'])+str(row['Symbol'])+str(row['Series'])+\
                         str(row['InstrumentType'])+str(row['ExpiryDate'])+str(row['StrikePrice'])+str(row['OptionType'])
        redisClient.zadd("InstrumentsOMM", {zset_key:i})
        redisClient.hmset(zset_key, row.to_dict())
        
    
        
    #redisClient.set('InstrumentsOMM', df.to_msgpack(compress='zlib'))
            


def main(nd):
    
    print "Processing for day {}".format((datetime.datetime.now()-datetime.timedelta(days=nd)).date())
    
    bse_scrip=bse_scrip_reader()    # read BSE scripts
    bse_scrip=bse_dp_reader(bse_scrip)    # attach circuit limits
    nse_scrip=nse_scrip_reader()       # read NSE scripts
    nfo_c=nfo_c_reader(nd)   # read NFO contracts for normal window
    sp_c= sp_c_reader(nfo_c)    # read NFO contracts for spread window
    bse_scrip,nse_scrip,nfo_c,sp_c=load_bhavcopy_closeprices(bse_scrip,nse_scrip,nfo_c,sp_c)  # attach close prices to all contracts fetched so far
    bse_scrip,nse_scrip,nfo_c,sp_c,security_codes, futidx_codes=final(bse_scrip,nse_scrip,nfo_c,sp_c)  # process all cash and fut security codes    
    result = merge_all_contracts(bse_scrip,nse_scrip,nfo_c,sp_c,security_codes, futidx_codes)
    result = result.replace([np.nan, np.NAN, np.NaN], "null")
    create_pairmaster_file(result.copy(deep=True), ['NIFTY','BANKNIFTY','FINNIFTY'])   
    
    #result = result.replace("NA","null")
    result.to_csv(output_dir+"instrument.csv",index=False)
    stime = time.time()
    redis_publisher(result.copy(deep=True))
    print "Redis publish time {}".format(time.time()-stime)
    #result.to_csv("/Trades/instrument.csv", index=False)
    '''
    # get instrument with berg code
    result = pd.read_csv(output_dir+"instrument.csv")
    scripmaster = pd.read_csv(path+"scripmaster.csv", names = ['Symbol','BseSymbol','UnnamedField3','Company Name','UnnamedField5',
                                                               'UnnamedField6','ISIN','RICNse','Sedol','RICBse','UnnamedField11',
                                                               'BseTicker','NseTicker','UnnamedField14','NfoTicker'] )
    scripmaster = scripmaster[['ISIN','BseTicker','NseTicker','NfoTicker']]
    scripmaster = scripmaster[(scripmaster['ISIN']!=' ') & (~scripmaster['ISIN'].isnull())]
    #scripmaster.loc[scripmaster['BseTicker'].isnull(), "BseTicker"] = scripmaster['']
    scripmaster.drop_duplicates(inplace=True)
    scripmaster['NseTicker'] = scripmaster['NseTicker'].fillna(" ")
    scripmaster['NseTicker'] = scripmaster['NseTicker'].apply(lambda row: row[1:])
    result = result.merge(scripmaster, on=['ISIN'], how="left")
    
    result.to_csv(output_dir+"instrument_new.csv",index=False)
    '''

start_time = time.time()

if __name__ == '__main__':
    main(nd=0)  # set dollar value and (nd = timedelta) days here 
            
end_time = time.time()

print "Execution time: {0} Seconds.... ".format(end_time - start_time)

