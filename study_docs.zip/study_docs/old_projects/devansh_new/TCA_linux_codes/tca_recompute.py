# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 19 16:14:46 2021

@author: krishna
"""

import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import psycopg2,logging,calendar, shutil, time, os
from datetime import datetime, date
import warnings
import pysftp
from TCA_params_compute1 import tca_calc
from dumpinpostgress1 import dump_in_postgres
warnings.filterwarnings("ignore")


#output_dir='C:\\Users\\devanshm\\Desktop\\devansh\\TCAoutput\\TCA\\output\\'
#output_dir='/home/hadoop/tca_project/berg_reqfiles/'
#master_dir="/home/hadoop/tca_project/"
orderfiles="/home/hadoop/tca_project/recompute_orders/"
orderpath="/home/hadoop/tca_project/recomputefinal/"
#output_dir='D:\\devansh_new\\berg_upload\\'
#master_dir="D:\\Master\\"




def get_postgress_data(d,d1):
    #get latest date from database
    df = pd.DataFrame()
    while True:        
        conn = psycopg2.connect(database="NSE-FNO",
                                user="postgres",
                                 password="kotak@123", 
                                 host="172.17.9.182", 
                                 port="5432")
        df = pd.read_sql("select * from tca_split where date>='{}' and date <='{}';".format(d1,d), conn)
        
        if len(df)!=0:
            break
        print "Data not present for {} in tca split postgres db; sleep for 30 sec".format(d)
        time.sleep(30)
        
    return df



def recalc_tcaparams():
    
                
    df = get_postgress_data(date(2021,3,31), date(2020,12,1))
    df = df[(df['QuantityExecuted']>0) & ( (df['DayVwap']==0) | (df['DayTwap']==0) | (df['Pwp20']==0) | (df['Pwp10']==0) | (df['Pwp15']==0) | (df['Pwp25']==0) | (df['Pwp30']==0)| (df['DayVol']==0))]
    df = df[['date','Ticker','TradeId','ClientOrdID','Side','SecurityExchange']]
    
    # read order file and modify one by one
    for r,d,f in os.walk(orderfiles):
        for fcsv in f:
            temp = pd.read_csv(r+fcsv)
            tempcols = temp.columns.tolist()
            temp = temp.merge(df, on=['Ticker','TradeId','ClientOrdID','Side','SecurityExchange'], how='inner')
            temp = temp[tempcols+['date']]
            if temp.empty==False:
                # delete data from postgress for this orders and then append into csv file for order
                print "Recomputing TCA for {}".format(fcsv)
                for _, row in temp.iterrows():
                    conn = psycopg2.connect(database="NSE-FNO",
                                user="postgres",
                                 password="kotak@123", 
                                 host="172.17.9.182", 
                                 port="5432")
                    cur=conn.cursor()
   
                    cur.execute("delete from tca_split where unique_id='{}'; ".format(
                                        row['TradeId']+row['SecurityExchange'])) #d current date ,d1 previous date
                    conn.commit()
                    conn.close()
                    cur.close()

                    
                
                temp.to_csv(orderpath+fcsv, index=False)
                
                # recompute params
                tca_calc(datetime.strptime(fcsv.split("orders")[-1][:-4], "%Y%m%d").date())
                print "Success: TCA param computations"
                dump_in_postgres(fcsv.split("orders")[-1][:-4])
                print "Success: Data dumping"

                os.remove(orderpath+fcsv)


recalc_tcaparams()
