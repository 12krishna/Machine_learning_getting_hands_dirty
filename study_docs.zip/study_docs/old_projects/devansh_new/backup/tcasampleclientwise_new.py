import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import datetime,psycopg2,logging,calendar, shutil, time
import warnings
warnings.filterwarnings("ignore")


#output_dir='C:\\Users\\devanshm\\Desktop\\devansh\\TCAoutput\\TCA\\output\\'
output_dir='D:\\devansh_new\\Output\\'
email_dir="D:\\Emails\\Output\\"
master_dir="D:\\Master\\"

def highlight_vals_c1(val):
    if val < 0:
        color='#FF0000'
    else:
        color='#008000'
    
    return 'color: %s' % color


def dateparse(date):    
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
   


def last_working(d):
    while  True:
            if d in holiday_master["date"].values:
                print "Holiday : ",d
                d = d - datetime.timedelta(days=1)                
            else:
                return d  

def color_r_g_b(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    if val > 25:
        color = '#FF0000' #red
    elif val>=20 and val<=25:
        color='blue' 
    else:
        color='#008000' #green 
    return 'color: %s' % color

def get_postgress_data(d,d1):
    #get latest date from database
    df = pd.DataFrame()
    while True:        
        conn = psycopg2.connect(database="NSE-FNO",
                                user="postgres",
                                 password="kotak@123", 
                                 host="172.17.9.182", 
                                 port="5432")
        cur=conn.cursor()
        cur.execute("select * from tca_split where date>='{}' and date <='{}';".format(d1,d)) #d current date ,d1 previous date
        df = cur.fetchall()
        df = pd.DataFrame(df)
        if len(df)!=0:
            break
        print "Data not present for {} in tca split postgres db; sleep for 30 sec".format(d)
        time.sleep(30)
        
    return df

def get_tca_split(tca):
    
    #add column names to the newlist
    newlist=[]
    newlist=tca.columns
    
    #get column name ends with bse and nse and append them to the respective list
    bselist=[]
    nselist=[]
    for i in range(0,len(newlist)):
        if newlist[i].endswith('Bse'):
            bselist.append(newlist[i])
        if newlist[i].endswith('Nse'):
            nselist.append(newlist[i])
    
    #print "Bselist",bselist
    #print "Nselist",nselist
    #create pairlist and append row to it based on sor is y or n and security exchange is bse or nse
    pairlist=[]
    for col,row in tca.iterrows():
        if row["SOR"]=="Y":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType',
                        'LimitPrice','Side','SecurityExchange','StartTime','EndTime','OrderQty','SOR','NSEExecutedQty',
                        'NSEExecutedQty','NSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapNse','IntervalVwapLimitNse','DayVwapLimitNse','DayVwapNse','DayTwapNse','IntervalTwapNse',
                        'IntervalTwapLimitNse','DayTwapLimitNse','Pwp20Nse','Pwp20LimitNse',
                        'Pwp10Nse','Pwp10LimitNse',
                        'Pwp15Nse','Pwp15LimitNse',
                        'Pwp25Nse','Pwp25LimitNse',
                        'Pwp30Nse','Pwp30LimitNse',
                        'AvgTradeSizeNse','IntervalVolNse',
                        'IntervalVolLimitNse','DayVolNse','DayVolLimitNse','volExecNse_intervalVolNse',
                        'volExecNse_intervalVolLimitNse','volExecNse_DayVolNse','volExecNse_DayVolLimitNse','ArrivalPrice','Tag115','tag9271']]
            result["SecurityExchange"]="NSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result) 
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                        'SecurityExchange','StartTime','EndTime','OrderQty','SOR','BSEExecutedQty','BSEExecutedQty',
                        'BSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapBse','IntervalVwapLimitBse','DayVwapLimitBse','DayVwapBse','DayTwapBse','IntervalTwapBse',
                        'IntervalTwapLimitBse','DayTwapLimitBse','Pwp20Bse','Pwp20LimitBse',
                        'Pwp10Bse','Pwp10LimitBse',
                        'Pwp15Bse','Pwp15LimitBse',
                        'Pwp25Bse','Pwp25LimitBse',
                        'Pwp30Bse','Pwp30LimitBse',
                        'AvgTradeSizeBse','IntervalVolBse',
                        'IntervalVolLimitBse','DayVolBse','DayVolLimitBse','volExecBse_intervalVolBse','volExecBse_intervalVolLimitBse',
                        'volExecBse_DayVolBse', 'volExecBse_DayVolLimitBse','ArrivalPrice','Tag115','tag9271']]
            result["SecurityExchange"]="BSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
        
        if row["SOR"]=='N' and row["SecurityExchange"]=="NSE":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType',
                        'LimitPrice','Side','SecurityExchange','StartTime','EndTime','OrderQty','SOR','NSEExecutedQty',
                        'NSEExecutedQty','NSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapNse','IntervalVwapLimitNse','DayVwapLimitNse','DayVwapNse','DayTwapNse','IntervalTwapNse',
                        'IntervalTwapLimitNse','DayTwapLimitNse','Pwp20Nse','Pwp20LimitNse',
                        'Pwp10Nse','Pwp10LimitNse',
                        'Pwp15Nse','Pwp15LimitNse',
                        'Pwp25Nse','Pwp25LimitNse',
                        'Pwp30Nse','Pwp30LimitNse',
                        'AvgTradeSizeNse','IntervalVolNse',
                        'IntervalVolLimitNse','DayVolNse','DayVolLimitNse','volExecNse_intervalVolNse',
                        'volExecNse_intervalVolLimitNse','volExecNse_DayVolNse','volExecNse_DayVolLimitNse','ArrivalPrice','Tag115','tag9271']]
            result["SecurityExchange"]="NSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
    
        if row["SOR"]=='N' and row["SecurityExchange"]=="BSE":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                        'SecurityExchange','StartTime','EndTime','OrderQty','SOR','BSEExecutedQty','BSEExecutedQty',
                        'BSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapBse','IntervalVwapLimitBse','DayVwapLimitBse','DayVwapBse','DayTwapBse','IntervalTwapBse',
                        'IntervalTwapLimitBse','DayTwapLimitBse','Pwp20Bse','Pwp20LimitBse',
                        'Pwp10Bse','Pwp10LimitBse',
                        'Pwp15Bse','Pwp15LimitBse',
                        'Pwp25Bse','Pwp25LimitBse',
                        'Pwp30Bse','Pwp30LimitBse',
                        'AvgTradeSizeBse','IntervalVolBse',
                        'IntervalVolLimitBse','DayVolBse','DayVolLimitBse','volExecBse_intervalVolBse','volExecBse_intervalVolLimitBse',
                        'volExecBse_DayVolBse', 'volExecBse_DayVolLimitBse','ArrivalPrice','Tag115','tag9271']]
            result["SecurityExchange"]="BSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
            
    final_df=pd.DataFrame(pairlist)
    final_df.columns=['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                      'SecurityExchange','StartTime','EndTime','OrderQty','SOR','QuantityExecuted','ExecutedQty',
                      'AvgPx','Remarks','Algorithm','LastFillTime','ArrivalTime',
                      'IntervalVwap','IntervalVwapLimit','DayVwapLimit','DayVwap','DayTwap','IntervalTwap',
                      'IntervalTwapLimit','DayTwapLimit','Pwp20','Pwp20Limit',
                      'Pwp10','Pwp10Limit',
                      'Pwp15','Pwp15Limit',
                      'Pwp25','Pwp25Limit',
                      'Pwp30','Pwp30Limit',
                      'AvgTradeSize','IntervalVol',
                      'IntervalVolLimit','DayVol','DayVolLimit','volExec_intervalVol','volExec_intervalVolLimit',
                      'volExec_DayVol','volExec_DayVolLimit','ArrivalPrice','Tag115','tag9271']
    
    '''create two dataframes one for summary calculation other to write in excel'''
        

    
    final_write=final_df[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                      'SecurityExchange','StartTime','EndTime','OrderQty','SOR','QuantityExecuted','ExecutedQty',
                      'AvgPx','Remarks','Algorithm','LastFillTime','ArrivalTime',
                      'IntervalVwap','IntervalVwapLimit','DayVwapLimit','DayVwap','DayTwap','IntervalTwap',
                      'IntervalTwapLimit','DayTwapLimit','Pwp20','Pwp20Limit',
                      'Pwp10','Pwp10Limit',
                      'Pwp15','Pwp15Limit',
                      'Pwp25','Pwp25Limit',
                      'Pwp30','Pwp30Limit','AvgTradeSize','IntervalVol',
                      'IntervalVolLimit','DayVol','DayVolLimit','volExec_intervalVol','volExec_intervalVolLimit',
                      'volExec_DayVol','volExec_DayVolLimit','ArrivalPrice','Tag115','tag9271']]
    
    final_write.reset_index(drop=True,inplace=True)
    final_write.to_excel("final_write.xlsx",index=False)
    return final_write 

def f(x):
    d = {}
    d['DayVwap']=x['DayVwap'].values[0]
    d['pwp30values'] = (x['pwp30values']).values[-1]
    d['pwp25values'] = (x['pwp25values']).values[-1]
    d['pwp20values'] = (x['pwp20values']).values[-1]
    d['pwp15values'] = (x['pwp15values']).values[-1]
    d['pwp10values'] = (x['pwp10values']).values[-1]
    d['Ticker']=x['Ticker'].values[0]
    d['TradeId']=x['TradeId'].values[0]
    d['TWAPvalues'] = (x['TWAPvalues']).sum()
    d['IntervalVol']=(x['IntervalVol']).sum()
    d['VWAPvalues'] = (x['VWAPvalues']).sum()
    d['DayVwap']=x['DayVwap'].values[0]
    d['values'] = (x['values']).sum()
    d['QuantityExecuted']=x['QuantityExecuted'].sum()
    d['DayVol']=x['DayVol'].values[0]
    d['SecurityExchange']=x['SecurityExchange'].values[0] 
    d['ClientName']=x['ClientName'].values[0] 
    d['tag9271']=x['tag9271'].values[0] 
    d['Symbol']=x['Symbol'].values[0]                                                                 
    d['Side']=x['Side'].values[0]                                                               
    d['ArrivalPrice']=x['ArrivalPrice'].values[0]    
    d['StartTime']=x['StartTime'].values[0]
    d['LastFillTime']=x['LastFillTime'].values[-1]
    d['Tag115']=x['Tag115'].values[0]
    d['OrdType']=x['OrdType'].values[0]
    d['Pwp10']=x['Pwp10'].values[-1]
    d['Pwp15']=x['Pwp15'].values[-1]
    d['Pwp20']=x['Pwp20'].values[-1]
    d['Pwp25']=x['Pwp25'].values[-1]
    d['Pwp30']=x['Pwp30'].values[-1]
   
    d['IntervalVolLimitpwp10values']=(x['pwp10values']).values[-1]
    d['IntervalVolLimitpwp15values']=(x['pwp15values']).values[-1]
    d['IntervalVolLimitpwp20values']=(x['pwp20values']).values[-1]
    d['IntervalVolLimitpwp25values']=(x['pwp25values']).values[-1]
    d['IntervalVolLimitpwp30values']=(x['pwp30values']).values[-1]
    
    d['IntervalVolLimit']=x['IntervalVolLimit'].sum()                                                                                                                                         
                                                                                                                                           
    return pd.Series(d, index=[ 'DayVwap','pwp30values','pwp25values','pwp20values','pwp15values','pwp10values',
                                'Ticker','TradeId','TWAPvalues','IntervalVol','VWAPvalues','DayVwap','values',
                                'QuantityExecuted','DayVol','SecurityExchange','ClientName','tag9271','Symbol',
                                'Side','ArrivalPrice','StartTime','LastFillTime','Tag115','OrdType',
                                'Pwp10','Pwp15','Pwp20','Pwp25','Pwp30','IntervalVolLimitpwp10values',
                                'IntervalVolLimitpwp15values',
                                'IntervalVolLimitpwp20values','IntervalVolLimitpwp25values','IntervalVolLimitpwp30values',
                                'IntervalVolLimit'])

def get_combine_op(df):
    '''processing for Dayvwap and volumelimit and daylimit and dates done in this code'''
    df['Start Time'] = pd.to_datetime(df['StartTime'])
    df['Date'] = df['Start Time'].dt.date
    df['values'] = df['AvgPx']*df['QuantityExecuted']
    df['VWAPvalues'] = df['IntervalVwapLimit']*df['IntervalVolLimit']
    df['pwp20values'] = df['Pwp20Limit']
    df['pwp10values'] = df["Pwp10Limit"]
    df['pwp15values'] = df["Pwp15Limit"]
    df['pwp25values'] = df["Pwp25Limit"]
    df['pwp30values'] = df["Pwp30Limit"]
    df['TWAPvalues'] = df['IntervalTwapLimit']*df['IntervalVolLimit']
    

    df['uniquetdse'] = df['TradeId']+df['SecurityExchange']
    cmpa=df[["pwp20values","pwp15values","pwp20values","pwp25values","pwp30values","ClientName"]]
    cmpa.to_excel("cmpa.xlsx",index=False)
#    combined_group = df.groupby(['uniquetdse','Date'], as_index=False).agg({'DayVwap':'first','pwp30values':'sum','pwp25values':'sum','pwp15values':'sum','pwp10values':'sum','Ticker':'first','TradeId':'first','TWAPvalues':'sum','IntervalVol':'sum','pwp20values':'sum','VWAPvalues':'sum','DayVwap':'first','QuantityExecuted':'sum','DayVol':'first','IntervalVolLimit':'sum','SecurityExchange':'first','ClientName':'first','Symbol':'first','Side':'first','ArrivalPrice':'first','values':'sum','StartTime':'first','LastFillTime':'last','Tag115':'first','OrdType':'first','Pwp10':'sum','Pwp15':'sum','Pwp20':'sum','Pwp25':'sum','Pwp30':'sum'})
    combined_group = df.groupby(['uniquetdse','Date'], as_index=False).apply(f)
    combined_group = combined_group.loc[:,~combined_group.columns.duplicated()]
    
    combined_group.to_excel("combined_group.xlsx",index=False)
    # print combined_group
    combined_group['wt_AvgPx'] = combined_group['values']/combined_group['QuantityExecuted']
    combined_group['wt_VWAP'] = combined_group['VWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_TWAP'] = combined_group['TWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_20PWP'] = combined_group['pwp20values']
    combined_group['wt_10PWP'] = combined_group['pwp10values']
    combined_group['wt_15PWP'] = combined_group['pwp15values']
    combined_group['wt_25PWP'] = combined_group['pwp25values']
    combined_group['wt_30PWP'] = combined_group['pwp30values']
    
    combined_group.fillna(0, inplace=True)
    combined_group.sort_values(by=['Date','Symbol','TradeId'], inplace=True)
    
    #calculating parameters
    combined_group['wtTWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_TWAP'])/combined_group['wt_TWAP'])*10000
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
    combined_group['wt10PWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_10PWP'])/combined_group['wt_10PWP'])*10000
    combined_group['wt15PWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_15PWP'])/combined_group['wt_15PWP'])*10000
    combined_group['wt20PWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_20PWP'])/combined_group['wt_20PWP'])*10000
    combined_group['wt25PWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_25PWP'])/combined_group['wt_25PWP'])*10000
    combined_group['wt30PWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_30PWP'])/combined_group['wt_30PWP'])*10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice'])/combined_group['ArrivalPrice'])*10000
    combined_group['wtdayVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['DayVwap'])/combined_group['DayVwap'])*10000
    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)
    
    #buy side parameters
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtTWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_10PWP'] != 0), 'wt10PWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wt10PWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_15PWP'] != 0), 'wt15PWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wt15PWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_20PWP'] != 0), 'wt20PWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wt20PWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_25PWP'] != 0), 'wt25PWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wt25PWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_30PWP'] != 0), 'wt30PWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wt30PWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtArrPx_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['DayVwap'] != 0), 'wtdayVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtdayVWAP_vs_AvgPx']
    
    #sell side parameters
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['DayVwap'] != 0), 'wtdayVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtdayVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtTWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_10PWP'] != 0), 'wt10PWP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wt10PWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_15PWP'] != 0), 'wt15PWP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wt15PWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_20PWP'] != 0), 'wt20PWP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wt20PWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_25PWP'] != 0), 'wt25PWP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wt25PWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_30PWP'] != 0), 'wt30PWP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wt30PWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtArrPx_vs_AvgPx']
    
    #difference
    combined_group['VWAP_Value_Difference'] = (combined_group['wtVWAP_vs_AvgPx']*combined_group['wt_VWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['TWAP_Value_Difference'] = (combined_group['wtTWAP_vs_AvgPx']*combined_group['wt_TWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP10_Value_Difference'] = (combined_group['wt10PWP_vs_AvgPx']*combined_group['wt_10PWP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP15_Value_Difference'] = (combined_group['wt15PWP_vs_AvgPx']*combined_group['wt_15PWP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP20_Value_Difference'] = (combined_group['wt20PWP_vs_AvgPx']*combined_group['wt_20PWP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP25_Value_Difference'] = (combined_group['wt25PWP_vs_AvgPx']*combined_group['wt_25PWP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP30_Value_Difference'] = (combined_group['wt30PWP_vs_AvgPx']*combined_group['wt_30PWP']*combined_group['QuantityExecuted'])/10000    
    combined_group['ArrPx_Value_Difference'] = (combined_group['wtArrPx_vs_AvgPx']*combined_group['ArrivalPrice']*combined_group['QuantityExecuted'])/10000
    combined_group['dayVWAP_Value_Difference'] = (combined_group['wtdayVWAP_vs_AvgPx']*combined_group['DayVwap']*combined_group['QuantityExecuted'])/10000                      
    combined_group.reset_index(drop=True,inplace=True)
    combined_group["StartTime"]=pd.to_datetime(combined_group["StartTime"],format='%Y%m%d %H:%M:%S')
    combined_group["LastFillTime"]=pd.to_datetime(combined_group["LastFillTime"],format='%Y%m%d %H:%M:%S.%f')
    # new data frame with split value columns 
    combined_group["Starttime"]=combined_group["StartTime"].dt.time
    combined_group["LastFillTime"]=combined_group["LastFillTime"].dt.time
    combined_group["TradeDate"]=combined_group["StartTime"].dt.date
    combined_group[["Starttime","LastFillTime"]]=combined_group[["Starttime","LastFillTime"]].astype(str)
    combined_group['percent_day_vol']=combined_group["QuantityExecuted"]/combined_group["DayVol"]*100
    combined_group['percent_interval_vol']=combined_group["QuantityExecuted"]/combined_group["IntervalVolLimit"]*100
    
    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)
#     combined_group.sort_values(by='Date',ascending=True, inplace=True)

    return combined_group

def final_output(df, tag115):
    '''function to get the final dataframe'''
    list1=["Security","Trade Date","Side","Order Type","Start - End Time","Shares","Total Value","Avg Trade Price","% from Interval VWAP",
           "Interval VWAP Price","% from Interval TWAP","Interval TWAP Price","twap_diff","vwap_diff","% from Arrival","Arrival Price",
           "arr_diff","% from Full Day VWAP","Full Day VWAP Price","day_diff","% of Day's Volume","% Interval Volume","% from PWP20",
           "PWP20","pwp_diff","PWP (rounded to nearest 5 of % Interval Vol)","% from nearest PWP","Exchange","Tag115","ivolpwpper"]
    df_sample=pd.DataFrame()
    for i in range(0,len(list1)):
        df_sample.insert(i,list1[i],0)
    
    df_sample["Security"]=df["Ticker"]
    df_sample["Side"]=df["Side"]
    df_sample["Order Type"]=df["OrdType"]
    df_sample["Shares"]=df["QuantityExecuted"]
    df_sample["Total Value"]=df["QuantityExecuted"]*df["wt_AvgPx"]
    df_sample["Avg Trade Price"]=df["wt_AvgPx"]
    df_sample["Arrival Price"]=df["ArrivalPrice"]
    df_sample["Interval VWAP Price"]=df["wt_VWAP"]
    df_sample["Full Day VWAP Price"]=df["DayVwap"]
    df_sample["PWP20"]=df["wt_20PWP"]
    df_sample["Interval TWAP Price"]=df["wt_TWAP"]
    df["Start - End Time"]=df["Starttime"]+'-'+df["LastFillTime"].str.split('.',n=1,expand=True)[0]
    vwap=df_sample[["Avg Trade Price","Interval VWAP Price","Shares"]]
    vwap=vwap.loc[vwap["Interval VWAP Price"]!=0]
    try:
        df_sample["vwap_diff"]=((vwap["Avg Trade Price"]-vwap["Interval VWAP Price"])*vwap["Shares"])
    except:
        print"error1"
        
    arr=df_sample[["Avg Trade Price","Arrival Price","Shares"]]
    arr=arr.loc[arr["Arrival Price"]!=0]
    try:
        df_sample["arr_diff"]=((arr["Avg Trade Price"]-arr["Arrival Price"])*arr["Shares"])
    except:
        print"error2"
        
    pwp20c=df_sample[["Avg Trade Price","PWP20","Total Value","Shares"]]
    pwp20c=pwp20c.loc[pwp20c["PWP20"]!=0]    
    try:
        df_sample["pwp_diff"]=((pwp20c["Avg Trade Price"]-pwp20c["PWP20"])*pwp20c["Shares"])
    except:
        print "error3"
        
    day=df_sample[["Avg Trade Price","Full Day VWAP Price","Shares"]]
    day=day.loc[day["Full Day VWAP Price"]!=0]      
    try:
        df_sample["day_diff"]=((day["Avg Trade Price"]-day["Full Day VWAP Price"])*day["Shares"])
    except:
        print "error4"
        
    twap=df_sample[["Avg Trade Price","Interval TWAP Price","Shares"]]
    twap=twap.loc[twap["Interval TWAP Price"]!=0]      
    try:
        df_sample["twap_diff"]=((twap["Avg Trade Price"]-twap["Interval TWAP Price"])*twap["Shares"])
    except:        
        print "error5"
        
    diff=df_sample[["vwap_diff","arr_diff","pwp_diff","day_diff","twap_diff"]]
    try:
        vwap_diff=(df_sample["vwap_diff"].sum()/df_sample["Total Value"].sum())*10000
        vwap_diff="{0:.2f}".format(vwap_diff)
    except:
        vwap_diff=0
        vwap_diff="{0:.2f}".format(vwap_diff)
        
    try:
        arr_diff=(df_sample["arr_diff"].sum()/df_sample["Total Value"].sum())*10000
        arr_diff="{0:.2f}".format(arr_diff)
    except:
        arr_diff=0
        arr_diff="{0:.2f}".format(arr_diff)
    
    try:
        pwp_diff=(df_sample["pwp_diff"].sum()/pwp20c["Total Value"].sum())*10000
        pwp_diff="{0:.2f}".format(pwp_diff)
    except:
        pwp_diff=0
        pwp_diff="{0:.2f}".format(pwp_diff)
    
    try:   
        day_diff=(df_sample["day_diff"].sum()/df_sample["Total Value"].sum())*10000
        day_diff="{0:.2f}".format(day_diff)
    except:
        day_diff=0
        day_diff="{0:.2f}".format(day_diff)
    
    try:
        twap_diff=(df_sample["twap_diff"].sum()/df_sample["Total Value"].sum())*10000
        twap_diff="{0:.2f}".format(twap_diff)
    except:
        twap_diff=0
        twap_diff="{0:.2f}".format(twap_diff)
        
    print (vwap_diff,twap_diff,arr_diff,day_diff,pwp_diff)

    diff.to_excel("difference.xlsx",index=False)
    print (vwap_diff,twap_diff,arr_diff,day_diff,pwp_diff)
        
   
    
    df_sample["% of Day's Volume"]= df["percent_day_vol"]
    df_sample["% Interval Volume"]= df["percent_interval_vol"]
    
    df["LastFillTime"]=df["LastFillTime"].str.split('.',n=1,expand=True)[0]

    df_sample["Start - End Time"]=df["Starttime"]+'-'+df["LastFillTime"]
    df_sample["Trade Date"]=df["TradeDate"]
    
    
    df_sample["% from Interval VWAP"]=df["wtVWAP_vs_AvgPx"]#/100
    df_sample["% from Arrival"]=df["wtArrPx_vs_AvgPx"]#/100
    df_sample["% from PWP20"]=df["wt20PWP_vs_AvgPx"]#/100
    df_sample["% from Full Day VWAP"]=df["wtdayVWAP_vs_AvgPx"]#/100
    df_sample["% from Interval TWAP"]=df["wtTWAP_vs_AvgPx"]#/100
    
    df_sample=df_sample[["Trade Date","Security","Side","Shares","Total Value","Avg Trade Price","Arrival Price","% from Arrival","Interval TWAP Price","% from Interval TWAP","Interval VWAP Price","% from Interval VWAP","Full Day VWAP Price","% from Full Day VWAP","% of Day's Volume","% Interval Volume","PWP20","% from PWP20","PWP (rounded to nearest 5 of % Interval Vol)","% from nearest PWP","Exchange","Start - End Time","Tag115"]]    
    df_sample['% from nearest PWP']=df["ivolpwpper"]
    
    shares_sum=df_sample["Shares"].sum()
    shares_sum="{0:.4f}".format(shares_sum)
    total_value_sum=df_sample["Total Value"].sum()
    total_value_sum="{0:,.2f}".format(total_value_sum)  
    
        
    df_sample['PWP (rounded to nearest 5 of % Interval Vol)']=df["IVol"]
    df_sample['Tag115']=df["Tag115"]
    df_sample['Exchange']=df["SecurityExchange"]
    
    df_sample["ivolpwpper"]=df["IVolpwp"]
    df_sample["ivolpwpper"]=df_sample["ivolpwpper"].astype(float)
    #print"df_sample['ivolpwpper']",df_sample["ivolpwpper"]
    volpep=df_sample[["Avg Trade Price","ivolpwpper","Total Value","Shares"]]
    volpep=volpep.loc[volpep["ivolpwpper"]!=0]
    try:
        df_sample["nearest_diff"]=((volpep["Avg Trade Price"]-volpep["ivolpwpper"])*volpep["Shares"])
        nearest_diff=(df_sample["nearest_diff"].sum()/volpep["Total Value"].sum())*10000
        nearest_diff="{0:.2f}".format(nearest_diff)
    except:
        nearest_diff=0
        nearest_diff="{0:.2f}".format(nearest_diff)
        
    df_sample["PWP20"]=df["wt_20PWP"].map('{:,.4f}'.format) 
    df_sample["Avg Trade Price"]=df["wt_AvgPx"].map('{:,.4f}'.format)
    df_sample["Arrival Price"]=df["ArrivalPrice"].map('{:,.4f}'.format)
    df_sample["Interval VWAP Price"]=df["wt_VWAP"].map('{:,.4f}'.format)
    df_sample["Full Day VWAP Price"]=df["DayVwap"].map('{:,.4f}'.format)
    df_sample["Total Value"]=df_sample["Total Value"].map('{:,.2f}'.format)
    df_sample["Interval TWAP Price"]=df["wt_TWAP"].map('{:,.4f}'.format)
    df_sample.to_excel("nearest_diff.xlsx",index=False)
    
    df_sample[["% from Interval VWAP","% from Arrival","% from Full Day VWAP",
                "% of Day's Volume","% Interval Volume","% from PWP20","% from nearest PWP",
                "% from Interval TWAP"]]=df_sample[[
                "% from Interval VWAP","% from Arrival","% from Full Day VWAP",
                "% of Day's Volume","% Interval Volume","% from PWP20","% from nearest PWP",
                "% from Interval TWAP"]].round(2)   
    df_sample.to_excel(output_dir+'complete_output.xls',index=False)
    
    
    twap=df_sample[['% from Interval TWAP']].style.applymap(highlight_vals_c1,subset=['% from Interval TWAP']).set_properties(**{'border-color':'Black','text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'                                                                                  
                                            })

    c1=df_sample[['% from Interval VWAP']].style.applymap(highlight_vals_c1,subset=['% from Interval VWAP']).set_properties(**{'border-color':'Black','text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'                                                                                  
                                            })
    c2=df_sample[['% from Full Day VWAP']].style.applymap(highlight_vals_c1,subset=['% from Full Day VWAP']).set_properties(**{'border-color':'Black','text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px',})
    c3=df_sample[['% from PWP20']].style.applymap(highlight_vals_c1,subset=['% from PWP20']).set_properties(**{'border-color':'Black','text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c4=df_sample[['% from Arrival']].style.applymap(highlight_vals_c1,subset=['% from Arrival']).set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'
                                            })
    
    c5=df_sample[["% of Day's Volume"]].style.applymap(color_r_g_b,subset=["% of Day's Volume"]).set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c6=df_sample[["% Interval Volume"]].style.applymap(color_r_g_b,subset=["% Interval Volume"]).set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c7=df_sample[['% from nearest PWP']].style.applymap(highlight_vals_c1,subset=['% from nearest PWP']).set_properties(**{
                                            'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c8=df_sample[["Total Value"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})

    c9=df_sample[["Avg Trade Price"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c10=df_sample[["Arrival Price"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c11=df_sample[["Interval VWAP Price"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    twapp=df_sample[["Interval TWAP Price"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c12=df_sample[["Full Day VWAP Price"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c13=df_sample[["PWP20"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    

    cfirst=df_sample[["Trade Date","Security","Side","Shares"]]
    cfirst=cfirst.style.set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    last=''
    if tag115==1:
        print "Daily report ; filter on tag1"
        last=df[["SecurityExchange","Start - End Time","tag9271","ClientName"]]
        last=last.style.set_properties(**{'border-color':'Black',
                                                'border-style':'solid',
                                                'border-width': '1px'})
    else:
        print "Monthly report; discard tag1 internal"
        last=df[["SecurityExchange","Start - End Time","tag9271"]]
        last=last.style.set_properties(**{'border-color':'Black',
                                                'border-style':'solid',
                                                'border-width': '1px'})
        
    
    
    
    pwprounded=df_sample[["PWP (rounded to nearest 5 of % Interval Vol)"]].style.set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    
    return pwprounded,twapp,twap,cfirst,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,last,total_value_sum,arr_diff,twap_diff,vwap_diff,day_diff,pwp_diff,nearest_diff


def output_excel(pwprounded,twapp,twap,cfirst,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,last,total_value_sum,arr_diff,twap_diff,vwap_diff,day_diff,pwp_diff,nearest_diff,d,ivol,tag115):
    length1=len(ivol["IVolpwp"])
    length1=length1+1
    ivol["IVolpwp"]=ivol["IVolpwp"].map('{:,.4f}'.format) 
    c14=ivol.style.set_properties(**{'border-color':'Black',
                                    'text-align':'right',
                                    'border-style':'solid',
                                    'border-width': '1px'})
    
    if tag115==1:
        writer = pd.ExcelWriter(output_dir+'tca_sample_new_{}.xlsx'.format(d.strftime('%Y%m%d')),engine='xlsxwriter')
    else:
        writer = pd.ExcelWriter(output_dir+'monthly_tca_sample_new_{}_{}.xlsx'.format(tag115[0],d.strftime('%Y%m%d')),engine='xlsxwriter')
        
    workbook=writer.book
    worksheet=workbook.add_worksheet('Result')
    
    cell_format = workbook.add_format({'bold': 1,
    'align': 'center',
    'valign': 'vcenter',
    'text_wrap':True,
    'color':'#000080'
    })
    cell_format.set_text_wrap()
    
    writer.sheets['Result'] = worksheet
    worksheet.set_column(0,22,20)
    worksheet.set_row(0,110)
    
    merge_format = workbook.add_format({
    'bold': 1,
    'align': 'center',
    'valign': 'vcenter',
    'text_wrap':True,
    'color':'#000080'
    })
    
    cell_format1 = workbook.add_format({'bold': 1,
    'align': 'center',
    'valign': 'vcenter',
    'text_wrap':True,
    'color':'#000080'})
    cell_format1.set_right(2)
    
    cell_format2 = workbook.add_format({
    'bold': True,
    'align': 'right',
    'valign': 'right',
    'border':1,
    'text_wrap':True})
    
    worksheet.merge_range('A0:F0','  ',merge_format)
    worksheet.write(0,0,'Trade Date',cell_format)
    worksheet.write(length1,0,"Summary",workbook.add_format({
    'bold': True,
    'align': 'left',
    'valign': 'left',
    'border':1,
    'text_wrap':True}))
    worksheet.write(0,1,'Security',cell_format)
    worksheet.write(0,2,'Side',cell_format)

    worksheet.write(0,3,'Shares',cell_format)
    worksheet.write(0,4,'Total Value\n(in INR)',cell_format)
    worksheet.write(length1,4,total_value_sum,cell_format2)
    worksheet.write(0,5,'AvgTrade\nprice\n(in INR)',cell_format1)
   
    worksheet.merge_range('G0:H0',' ',merge_format)
    worksheet.write(0,6, "Arrival\nPrice\n(in INR)",cell_format)
    worksheet.write(0,7,"% from\nArrival\n(in bps)",cell_format1)
    worksheet.write(length1,7,arr_diff,cell_format2)
    
    worksheet.merge_range('I0:J0',' ',merge_format)
    worksheet.write(0,8, "Interval\nTWAP Price\n(in INR)",cell_format)
    worksheet.write(0,9,"% from\nInterval\nTWAP\n(in bps)",cell_format1)
    worksheet.write(length1,9,twap_diff,cell_format2)
   

    worksheet.merge_range('K0:L0',' ',merge_format)
    worksheet.write(0,10, "Interval\nVWAP Price\n(in INR)",cell_format)
    worksheet.write(0,11,"% from\nInterval\nVWAP\n(in bps)",cell_format1)
    worksheet.write(length1,11,vwap_diff,cell_format2)    
    
    worksheet.merge_range('M0:N0',' ',merge_format)
    worksheet.write(0,12,"Full Day\nVWAP\nPrice\n(in INR)",cell_format)
    worksheet.write(0,13,"% from\nFull Day\nVWAP\n(in bps)",cell_format1)
    worksheet.write(length1,13,day_diff,cell_format2)
    
  
    worksheet.write(0,14,"% of\nDay's\nVolume",cell_format)
    
    worksheet.write(0,15,"%\nInterval\nVolume",cell_format1)
    
    worksheet.merge_range('Q0:R0',' ',merge_format)
    worksheet.write(0,16,"PWP20\n(in INR)",cell_format)
    worksheet.write(0,17,"% from\nPWP20\n(in bps)",cell_format1)
    worksheet.write(length1,17,pwp_diff,cell_format2)
    
    worksheet.merge_range('S0:U0',' ',merge_format)
    worksheet.write(0,18,"PWP\n(in INR)",cell_format)
    worksheet.write(0,19,"PWP Percent",cell_format)
    worksheet.write(0,20,"% from\nnearest\nPWP\n(in bps)",cell_format1)
    worksheet.write(length1,20,nearest_diff,cell_format2)
    
    
    worksheet.write(0,21,"Exchange",cell_format)
    worksheet.write(0,22,'Start - End Time',cell_format)

    

    cfirst.to_excel(writer,sheet_name='Result',startrow=1,startcol=0,index=False,header=False)
    c8.to_excel(writer,sheet_name='Result',startrow=1,startcol=4,index=False,header=False)    
    c9.to_excel(writer,sheet_name='Result',startrow=1,startcol=5,index=False,header=False)    
    c10.to_excel(writer,sheet_name='Result',startrow=1,startcol=6,index=False,header=False)
    c4.to_excel(writer,sheet_name='Result',startrow=1,startcol=7,index=False,header=False)
    twapp.to_excel(writer,sheet_name='Result',startrow=1,startcol=8,index=False,header=False)    
    twap.to_excel(writer,sheet_name='Result',startrow=1,startcol=9,index=False,header=False)
    c11.to_excel(writer,sheet_name='Result',startrow=1,startcol=10,index=False,header=False)    
    c1.to_excel(writer,sheet_name='Result',startrow=1,startcol=11,index=False,header=False) 
    c12.to_excel(writer,sheet_name='Result',startrow=1,startcol=12,index=False,header=False)    
    c2.to_excel(writer,sheet_name='Result',startrow=1,startcol=13,index=False,header=False) 
    c5.to_excel(writer,sheet_name='Result',startrow=1,startcol=14,index=False,header=False)       
    c6.to_excel(writer,sheet_name='Result',startrow=1,startcol=15,index=False,header=False)       
    c13.to_excel(writer,sheet_name='Result',startrow=1,startcol=16,index=False,header=False)  
    c3.to_excel(writer,sheet_name='Result',startrow=1,startcol=17,index=False,header=False)  
    c14.to_excel(writer,sheet_name='Result',startrow=1,startcol=18,index=False,header=False)
    c7.to_excel(writer,sheet_name='Result',startrow=1,startcol=20,index=False,header=False)
    pwprounded.to_excel(writer,sheet_name='Result',startrow=1,startcol=19,index=False,header=False)
    
    if tag115==1:
        worksheet.write(0,23,"Tag1-External",cell_format1)
        worksheet.write(0,24,"Tag1-Internal",cell_format1)
        last.to_excel(writer,sheet_name='Result',startrow=1,startcol=21,index=False,header=False)
        writer.save()
        writer.close()  
               
        
        print "writing daily sample report"
        shutil.copy(output_dir+'tca_sample_new_{}.xlsx'.format(d.strftime('%Y%m%d')), 
                    email_dir+'tca_sample_new_{}.xlsx'.format(d.strftime('%Y%m%d')))
    else:
        print "writing monthly report"
        worksheet.write(0,23,"Tag1",cell_format1)
        last.to_excel(writer,sheet_name='Result',startrow=1,startcol=21,index=False,header=False)
        writer.save()
        writer.close()       
        shutil.copy(output_dir+'monthly_tca_sample_new_{}_{}.xlsx'.format(tag115[0],d.strftime('%Y%m%d')), 
                    email_dir+'monthly_tca_sample_new_{}_{}.xlsx'.format(tag115[0],d.strftime('%Y%m%d')))
     
def gen_monthly_report(d,d1,tag115):

    print "today date,yesterday date",d,d1
    
    if tag115==1:
        psql_df=get_postgress_data(d,d1)
        psql_df.columns=["TradeId","ClientOrdID","Og_ClientOrdID","ClientName","Symbol","Series","Ticker","OrdType",
                         "LimitPrice","Side","SecurityExchange","StartTime","EndTime","OrderQty",
                         "SOR","QuantityExecuted","AvgPx","NSEExecutedQty","BSEExecutedQty","NSEExecutedAvg","BSEExecutedAvg",
                         "Remarks","Algorithm","LastFillTime","ArrivalTime","Tag115","IntervalVwap","IntervalVwapNse",
                         "IntervalVwapBse","IntervalVwapLimit","AvgPx_vs_IntervalVwapLimit","IntervalVwapLimitNse",
                         "IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap",
                         "DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse",
                         "IntervalTwapBse","IntervalTwapLimit","AvgPx_vs_IntervalTwapLimit","IntervalTwapLimitNse",
                         "IntervalTwapLimitBse","DayTwapLimit","DayTwapLimitNse","DayTwapLimitBse","AvgPx_vs_IntervalVwap",
                         "AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit","AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","AvgPx_vs_DayTwapLimit",
                         "AvgPx_vs_Pwp","Pwp20Nse","Pwp20Bse","Pwp20","Pwp20Limit","AvgPx_vs_PwpLimit","Pwp20LimitNse",
                         "Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse",
                         "IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse",
                         "DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse","volExecBse_intervalVolBse",
                         "volExec_vs_IntervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse",
                         "volExec_vs_IntervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse",
                         "volExec_vs_DayVol","volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_vs_DayVolLimit",
                         "ArrivalPriceNse","ArrivalPriceBse","ArrivalPrice","AvgPx_vs_ArrivalPx","Pwp10Nse","Pwp10Bse","Pwp10",
                         "Pwp10Limit","Pwp10LimitNse","Pwp10LimitBse","Pwp15Nse","Pwp15Bse","Pwp15","Pwp15Limit","Pwp15LimitNse",
                         "Pwp15LimitBse","Pwp25Nse","Pwp25Bse","Pwp25","Pwp25Limit","Pwp25LimitNse","Pwp25LimitBse",
                         "Pwp30Nse","Pwp30Bse","Pwp30","Pwp30Limit","Pwp30LimitNse","Pwp30LimitBse","unique_id","date","tag9271"]
        final_df=psql_df
        final_df.to_excel("complete_output.xlsx",index=False)
        #print final_df
    else:
        psql_df=get_postgress_data(d,d1)
        psql_df.columns=["TradeId","ClientOrdID","Og_ClientOrdID","ClientName","Symbol","Series","Ticker","OrdType",
                         "LimitPrice","Side","SecurityExchange","StartTime","EndTime","OrderQty",
                         "SOR","QuantityExecuted","AvgPx","NSEExecutedQty","BSEExecutedQty","NSEExecutedAvg","BSEExecutedAvg",
                         "Remarks","Algorithm","LastFillTime","ArrivalTime","Tag115","IntervalVwap","IntervalVwapNse",
                         "IntervalVwapBse","IntervalVwapLimit","AvgPx_vs_IntervalVwapLimit","IntervalVwapLimitNse",
                         "IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap",
                         "DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse",
                         "IntervalTwapBse","IntervalTwapLimit","AvgPx_vs_IntervalTwapLimit","IntervalTwapLimitNse",
                         "IntervalTwapLimitBse","DayTwapLimit","DayTwapLimitNse","DayTwapLimitBse","AvgPx_vs_IntervalVwap",
                         "AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit","AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","AvgPx_vs_DayTwapLimit",
                         "AvgPx_vs_Pwp","Pwp20Nse","Pwp20Bse","Pwp20","Pwp20Limit","AvgPx_vs_PwpLimit","Pwp20LimitNse",
                         "Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse",
                         "IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse",
                         "DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse","volExecBse_intervalVolBse",
                         "volExec_vs_IntervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse",
                         "volExec_vs_IntervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse",
                         "volExec_vs_DayVol","volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_vs_DayVolLimit",
                         "ArrivalPriceNse","ArrivalPriceBse","ArrivalPrice","AvgPx_vs_ArrivalPx","Pwp10Nse","Pwp10Bse","Pwp10",
                         "Pwp10Limit","Pwp10LimitNse","Pwp10LimitBse","Pwp15Nse","Pwp15Bse","Pwp15","Pwp15Limit","Pwp15LimitNse",
                         "Pwp15LimitBse","Pwp25Nse","Pwp25Bse","Pwp25","Pwp25Limit","Pwp25LimitNse","Pwp25LimitBse",
                         "Pwp30Nse","Pwp30Bse","Pwp30","Pwp30Limit","Pwp30LimitNse","Pwp30LimitBse","unique_id","date","tag9271"] 
        final_list=[]
        print "length",len(tag115)
        
        for i in range(0,len(tag115)):
            final_list.append(psql_df.loc[psql_df["Tag115"].isin([tag115[i]])])
            
        final_df=pd.concat(final_list)
        
    final_write=get_tca_split(final_df)
    df=get_combine_op(final_write)
    
    
    df["IVol"]='0'
    df["IVolpwp"]='0'
    df["ivolpwpper"]='0'
    for i in range(0,len(df)):
        if df["percent_interval_vol"][i]<=10.00:
            df["IVol"][i]=10
            df["IVolpwp"][i]=df["wt_10PWP"][i]
            df["ivolpwpper"][i]=df["wt10PWP_vs_AvgPx"][i]
        elif df["percent_interval_vol"][i] > 10.00 and df["percent_interval_vol"][i]<=15.00:
            df["IVol"][i]=15
            df["IVolpwp"][i]=df["wt_15PWP"][i]
            df["ivolpwpper"][i]=df["wt15PWP_vs_AvgPx"][i]
        elif df["percent_interval_vol"][i] > 15.00 and df["percent_interval_vol"][i]<=20.00:
            df["IVol"][i]=20
            df["IVolpwp"][i]=df["wt_20PWP"][i]
            df["ivolpwpper"][i]=df["wt20PWP_vs_AvgPx"][i]
        elif df["percent_interval_vol"][i] > 20.00 and df["percent_interval_vol"][i]<=25.00:
            df["IVol"][i]=25
            df["IVolpwp"][i]=df["wt_25PWP"][i]
            df["ivolpwpper"][i]=df["wt25PWP_vs_AvgPx"][i]
        elif df["percent_interval_vol"][i]> 25.00 and df["percent_interval_vol"][i]<=30.00:
            df["IVol"][i]=30
            df["IVolpwp"][i]=df["wt_30PWP"][i]
            df["ivolpwpper"][i]=df["wt30PWP_vs_AvgPx"][i]
        else:
            df["IVol"][i]=30
            df["IVolpwp"][i]=df["wt_30PWP"][i]
            df["ivolpwpper"][i]=df["wt30PWP_vs_AvgPx"][i]
    df[["IVolpwp","ivolpwpper"]]=df[["IVolpwp","ivolpwpper"]].astype(float)#.round(4)
    
    df= df[df['QuantityExecuted']!=0]
    df.reset_index(drop=True,inplace=True)
    ivol=pd.DataFrame(df["IVolpwp"])
    ivol["IVolpwp"]=ivol["IVolpwp"]#.map('{:,.4f}'.format)
    #print "ivol",ivol
    pwprounded,twapp,twap,cfirst,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,last,total_value_sum,arr_diff,twap_diff,vwap_diff,day_diff,pwp_diff,nearest_diff=final_output(df,tag115)
    output_excel(pwprounded,twapp,twap,cfirst,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,last,total_value_sum,arr_diff,twap_diff,vwap_diff,day_diff,pwp_diff,nearest_diff,d,ivol,tag115)
          

         
def sample_report_main(d,d1):
    #d=last_working(datetime.datetime.now().date()-datetime.timedelta(days=d))
    #d1=last_working(datetime.datetime.now().date()-datetime.timedelta(days=d1))
    print "Processing client sample file ",d,d1
    #middledate=calendar.monthrange(d.year,d.month)[1]/2+1
    #lastdate=calendar.monthrange(d.year,d.month)[1]
    if d==d1:
        print "processing for daily report"
        gen_monthly_report(d,d1,1)
        print "processing for monthly report"
        # get monthly report
        tag115list=[["FRANKLINTRT","FRANKTEMPAW"] ] # ['AZPMSOR'],['MIRAEMFSOR']
        for i in range(0,len(tag115list)):
            #print "tag115",tag115list[i]
            a=tag115list[i]
            print d,d1
            try:
                gen_monthly_report(d,d.replace(day=1),a)
            except:
                print "No trading done in {}".format(a)
        
        
        
    
        
        
        
'''   
    if middledate==d.day or lastdate==d.day:#number to be compared for the middle day of the month
        print "prcessing for monthly report"
        d1=d1-datetime.timedelta(days=31)
#        tag115list=[["FRANKLINTRT","FRANKTEMPAW"],["PRUPMSSOR"]]
        tag115list=[["FRANKLINTRT","FRANKTEMPAW"]]
        for i in range(0,len(tag115list)):
            #print "tag115",tag115list[i]
            a=tag115list[i]
            print d,d1
            gen_monthly_report(d,d1,a)
        '''    
    
#sample_report_main(1,1)#for daily report
# main(3,16)#for monthly report
