import pandas as pd
from datetime import datetime,timedelta
import logging
import numpy as np
from cassandra.cluster import Cluster
from time import time
import os
inputcolnames=["TradeId","ClientOrdID", "Og_ClientOrdID", "ClientName","Symbol","Series","Ticker","OrdType","LimitPrice","Side","SecurityExchange","StartTime","EndTime","OrderQty","SOR","QuantityExecuted","AvgPx","NSEExecutedQty","BSEExecutedQty","NSEExecutedAvg","BSEExecutedAvg","Remarks","Algorithm","LastFillTime", "ArrivalTime","Tag115"]

#orderpath contains the path of the order file
orderpath="D:\\FIXLogParser\\ETS_TCA\\Orders_ETS_Output\\"

log_path = "D:\\FIXLogParser\\ETS_TCA\\ETS_Output\\"
market_start="09:00:00"
market_end="16:00:00"
#outpath contains the path of where the new order file with calclated parameters has to be stored 
outpath="D:\\FIXLogParser\\ETS_TCA\\ETS_Output\\"
#for fetching data from cassandra put flag=1
flag=1

data="/home/kotakalgo/TCA/Marketdata/"

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

cluster = Cluster(['172.17.9.51'])
logging.info('Cassandra Cluster connected...')
session = cluster.connect('rohit')
#connect to your keyspace and create a session using which u can execute cql commands 
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None

#print(df_temp.head())
#order=pd.read_csv(orderpath+'orders.csv',names=inputcolnames)
# log events in debug mode 


#order["Series"]=order["DisplaySymbol"]
#order=order.drop(['Tag1','Trader','NewAmendOrCancel','TimeInForce','Account','HandlInst','TransactTime','Price1','Price1Part','Slices','IC_DripSize','IC_DripPrice','IC_DiscloseQtyPercent','IC_Mode','IC_OrderQty','HD_MinGrabSize','HD_MaxParticipationPer','HD_Price','HD_Mode','HD_OrderQty','LDR_DiscloseQtyPercent','LDR_Limit','LDR_Price2','LDR_Diff','LDR_OrderQty','LDR_Slices','MPOV_OrderType','MPOV_Limit','MPOV_LimitPartPer','MPOV_Price1','MPOV_Price1PartPer','MPOV_SliceQty','MPOV_SliceInterval','MPOV_GDPPrice','MPOV_GDQPer','MPOV_GDPDripSize','MPOV_BlockQty','MPOV_OrderQty','MPOV_Mode','MPOV_Volume','TWAP_OrderType','TWAP_Limit','TWAP_LimitPartPer','TWAP_GDPPrice','TWAP_GDQPer','TWAP_BlockQty','TWAP_Slices','TWAP_OrderQty','TWAP_GDPDripSize','VWAP_OrderType','VWAP_Limit','VWAP_LimitPartPer','VWAP_GDPPrice','VWAP_GDQPer','VWAP_BlockQty','VWAP_Slices','VWAP_OrderQty','VWAP_GDPDripSize','FLT_Limit','FLT_Size','FLT_MinChaseSize','FLT_NumTicks','FLT_MinGrabSize','FLT_Grab','FLT_DiscloseQtyPercent','FLT_OrderQty','Name','OrdStatus','TraderOrClient','Entered','AlgoSliceSeconds','Ccy','QuantitySentToOMS','NSEExecutedVal','BSEExecutedVal','LastPx','Earned','PROCESSING_','State','DisplaySymbol','RefVol','ConsideredVol','MinParticipationPer','MaxTgtParticipation','MinTgtParticipation','RefVolSet','PrevVol','LimitExecShrs','LimitExecVal','LimitAvg','Price1ExecShrs','Price1ExecVal','Price1Avg','Price2ExecShrs','Price2ExecVal','Price2Avg','GDPExecShrs','GDPExecVal','GDPAvg','GDPEnabled','GDPStopped','TWAPEnabled','MinPrice1Part','MinPrice2Part','MaxTgtPrice1Part','MinTgtPrice1Part','MaxTgtPrice2Part','MinTgtPrice2Part','Price1ConsideredVol','Price2ConsideredVol','GDPConsideredVol','LimitBlockTrades','Price1BlockTrades','Price2BlockTrades','GDPBlockTrades','CurrLimitPart','CurrPrice1Part','CurrPrice2Part','CurrGDPPart','AlgoQuantity','MissedShares','LastSlice','LastSize','PrevSlice','TotalConsidered','SentQty','RemainingQty','PerCompleted','Bid','Ask','BidSize','AskSize','LTP','VolumeTraded','ClosePrice','SymbolSfx','ScripGroup','MaturityMonthYear','MaturityDay','SecurityType','OptAttribute','PutOrCall','StrikePrice','TickSize','LotSize','SecurityCode','SliceQty','CummSliceQty','TraderGroup','ConsideredVolMinusGDP','Price1ConsideredVolMinusGDP','Price2ConsideredVolMinusGDP','GDPConsideredVolMinusGDP','ExDestination','NSESecurityExchange','NSESymbol','NSEAccount','NSEScripGroup','NSESecurityCode','NSELotSize','NSETickSize','BSESecurityExchange','BSESymbol','BSEAccount','BSEScripGroup','BSESecurityCode','BSELotSize','BSETickSize','BSEPostFactor','NSEPostFactor','NSEDisplaySymbol','BSEDisplaySymbol','NSEReject','BSEReject','OnBehalfOfCompID','Randomize','OrderQtyInLots','QuantityExecutedInLots','RemainingQtyInLots'],axis=1)
logging.basicConfig(filename=log_path +"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def getbse_nse_close(bse_df,nse_df,sccode):
    bse_df=bse_df.loc[bse_df["symbol"].isin(['{}'.format(sccode)])] 
    bse_df.reset_index(drop=True,inplace=True)
    ltp_bse=bse_df["prevclose"][0]
                
    nse_df=nse_df.loc[nse_df["symbol"].isin(['{}'.format(sccode)])] 
    nse_df.reset_index(drop=True,inplace=True)
    ltp_nse=nse_df["prevclose"][0]
    if ltp_bse !=0:
        ltp=ltp_bse
    else:
        ltp=ltp_nse
        print ltp
    return float(ltp)

#function to extract startTime,endTime and Date in seperate date and time format from dateTime format
def timeformat(start,end):
    
    #start=start.astype(str)
    logging.info('Date time conversion to a well-defined format...')
    startTime=pd.to_datetime(start, format='%Y %m %d %H:%M:%S')
    d=startTime.date()
    
    startTime=datetime.time(startTime)
    endTime=pd.to_datetime(end,format='%Y %m %d %H:%M:%S') 
    endTime=datetime.time(endTime)
    return(startTime,endTime,d)
#function to filter the data within startTime and endTime passed as parameters
def filterTime(startTime,endTime,symbol,df):
    #call to timeformat function to get date and time seperately
    if not df.empty:
        a=timeformat(startTime,endTime)
        start=a[0]
        end=a[1]
        d=a[2]
        logging.info('Filtering data within startTime and endTime...')
        df_f = df.loc[df["symbol"]==symbol]
        if not df_f.empty:
            df_f['date'] = df_f.loc[:,'date'].astype(str)
            df_f['date'] = pd.to_datetime(df_f.loc[:,'date'],format='%Y %m %d %H:%M:%S')
            df_f['date'] = df_f.apply(lambda row: row['date'].date(),axis=1)
            #df_f["date"]=df_f["date"].date()
            #logging.info('Filtering data of a particular dated order...')
            df_f = df_f[df_f.date==d]
            if not df_f.empty:
                #print("drtd",df_f.time)
                df_f.loc[:,'time'] = df_f.loc[:,'time'].map(lambda x: str(x)[:-10])
                df_f.loc[:,'time'] = df_f.loc[:,'time'].astype(str)
                df_f.loc[:,'time'] = pd.to_datetime(df_f['time'],format='%H:%M:%S')
                df_f.loc[:,'time']=df_f['time'].apply(datetime.time)
                logging.info('Filtering data within a particular time interval...')
                df_f=df_f.loc[(df_f['time']>=start)&(df_f['time']<end)]
                #print df_f
            else:
                df_f=df_f
    else:
        df_f=df
    return(df_f)
#function to calculate vwap of the dataframe data passed
def calcvwap(df):
    if df.empty:
        vwap=0.0
    else:
        try:
                vwap=(df["price"]*df["volume"]).sum()/df["volume"].sum()
        except(df["volume"].sum()==0.0):
                vwap=0.0
    return(vwap)
#function to calculate twap of the df passed
def calctwap(df):
    if df.empty:
        twap=0.0
    else:
        try:
            twap=df["price"].sum()/df.shape[0]
        except(df.shape[0]==0):
            twap=0.0
    return(twap)
#function to calculate overall vwap   
def vwap(symbol,startTime,endTime,l,limit,side,df):
    logging.info('Call to the function for filtering the time in a particular interval')
    if df.empty:
        vwap=0.0
    else:
        df_f=filterTime(startTime,endTime,symbol,df)
        vwap=calcvwap(df_f)
    return(vwap)
#function to calculate overall twap  
def twap(symbol,startTime,endTime,l,limit,side,df):
    if df.empty:
        twap=0.0
    else:
        df_f=filterTime(startTime,endTime,symbol,df)
        twap=calctwap(df_f)
    return(twap)
#function to calculate vwap of NSE data      
def vwapNse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:    
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IS"]
        vwapNse=calcvwap(dfEx)
    else:
        vwapNse=0.0
        
    return(vwapNse)
#function to calculate twap of NSE data        
def twapNse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty: 
        df_f=filterTime(startTime,endTime,symbol,df)
        if not df_f.empty:
            dfEx=df_f[df_f.exchange=="IS"]
            twapNse=calctwap(dfEx)
        else:
            twapNse=0.0
    else:
        twapNse=0.0
    return(twapNse)
#function to calculate twap of BSE data      
def twapBse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        if not df_f.empty:  
            dfEx=df_f[df_f.exchange=="IB"]
            twapBse=calctwap(dfEx)
        else:
            twapBse=0.0
    else:
        twapBse=0.0
    return(twapBse)
#function to calculate vwap of BSE data  
def vwapBse(symbol,startTime,endTime,l,limit,side,df):
    logging.info("Vwap for Bse....")
    if not df.empty:  
        df_f=filterTime(startTime,endTime,symbol,df)
        if not df_f.empty:   
            dfEx=df_f[df_f.exchange=="IB"]
            vwapBse=calcvwap(dfEx)
        else:
            vwapBse=0.0
    else:
        vwapBse=0.0
    return(vwapBse)
#function to calculate overall volume  
def vol(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        if df_f.empty:
            vol=0.0
        else:
            vol=df_f["volume"].sum()
    else:
        vol=0.0
    return(vol)
#function to calculate volume of NSE data
def volNse(symbol,startTime,endTime,l,limit,side,df):
    if df.empty:
        vol=0.0
    else:
        df_f=filterTime(startTime,endTime,symbol,df)
        if not df_f.empty:
            dfEx=df_f[df_f.exchange=="IS"]
            if dfEx.empty:
                vol=0.0
            else:
                vol=dfEx["volume"].sum()
        else:
            vol=0.0
    return(vol)
#function to calculate volume of BSE data
def volBse(symbol,startTime,endTime,l,limit,side,df):
    if df.empty:
        vol=0.0
    else:
        
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IB"]
        if dfEx.empty:
            vol=0.0
        else:
            vol=dfEx["volume"].sum()
    return(vol)

#function to calculate vwap of the dataframe data passed
def calcPwpvwap(df):
    if df.empty:
        vwap=0.0
    else:
        try:
                vwap=(df["price"]*df["new_vol"]).sum()/df["new_vol"].sum()
        except(df["volume"].sum()==0.0):
                vwap=0.0
    return(vwap)
    
#function to calculate overall PWP20
def pwp(pwpPara,symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        s=df_f
        s["cum_vol"]=pd.Series(df_f.index)
        s["cum_vol"]=df_f.volume.cumsum()
        s['prev_cum_sum'] = s['cum_vol'].shift(1)
        s = s.fillna(0)
        s['new_vol'] = np.where(s['cum_vol'] > pwpPara,pwpPara-s['prev_cum_sum'],s['volume'])
        s['new_vol'] = np.where(s['new_vol'] > 0,s['new_vol'],0)
        s = s[s['new_vol'] > 0]
        logging.info("Filtering the dataframe for PWP20 and calculating parameters vwap,twap....")
        #s=s.loc[s["cum_vol"]<=pwpPara]
        vwap_pwp=calcPwpvwap(s)
    else:
        vwap_pwp=0.0
    return(vwap_pwp)
    
#function to return PWP20 for NSE data
def pwpNse(pwpPara,symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IS"]
        s=dfEx
        if not s.empty:
            s["cum_vol"]=pd.Series(dfEx.index)
            s["cum_vol"]=dfEx.volume.cumsum()
            s['prev_cum_sum'] = s['cum_vol'].shift(1)
            s = s.fillna(0)
            s['new_vol'] = np.where(s['cum_vol'] > pwpPara,pwpPara-s['prev_cum_sum'],s['volume'])
            s['new_vol'] = np.where(s['new_vol'] > 0,s['new_vol'],0)
            s = s[s['new_vol'] > 0]
            logging.info("Filtering the dataframe for PWP20 and calculating parameters vwap,twap....")
            #s=s.loc[s["cum_vol"]<=pwpPara]
            vwap_pwpNse=calcPwpvwap(s)
        else:
            vwap_pwpNse=0.0
    else:
        vwap_pwpNse=0.0
    return(vwap_pwpNse)
    
#function to return PWP20 for BSE data
def pwpBse(pwpPara,symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IB"]
        s=dfEx
        if not s.empty:
            s["cum_vol"]=pd.Series(dfEx.index)
            s["cum_vol"]=dfEx.volume.cumsum()
            s['prev_cum_sum'] = s['cum_vol'].shift(1)
            s = s.fillna(0)
            s['new_vol'] = np.where(s['cum_vol'] > pwpPara,pwpPara-s['prev_cum_sum'],s['volume'])
            s['new_vol'] = np.where(s['new_vol'] > 0,s['new_vol'],0)
            s = s[s['new_vol'] > 0]
            logging.info("Filtering the dataframe for PWP20 and calculating parameters vwap,twap....")
            #s=s.loc[s["cum_vol"]<=pwpPara]
            vwap_pwpBse=calcPwpvwap(s)
        else:
            vwap_pwpBse=0.0
    else:
        vwap_pwpBse=0.0
    return(vwap_pwpBse)
    
#function to return arrival price of NSE data
def getnse_close(nse_df,sccode):
    nse_df=nse_df.loc[nse_df["symbol"].isin(['{}'.format(sccode)])]
    nse_df.reset_index(drop=True,inplace=True)
    ltp=nse_df["prevclose"][0]
    #print ltp
    return float(ltp)

def getbse_close(bse_df,sccode):
    bse_df=bse_df.loc[bse_df["sc_code"].isin(['{}'.format(sccode)])]
    bse_df.reset_index(drop=True,inplace=True)
    ltp=bse_df["prevclose"][0]
    #print ltp
    return float(ltp)
    
def ltp(symbol,startTime,endTime,arrivalTime,sccode,l,limit,side,df,nse_df,bse_df):
    m_s="09:15:00"
    m_s=datetime.strptime(m_s,'%H:%M:%S').time()
    market_s="09:00:00"
    market_s=datetime.strptime(market_s,'%H:%M:%S').time()
    #print "start time {} and arrival time {}".format(startTime,arrivalTime)
    curr_date = datetime.strptime(startTime,'%Y-%m-%d %H:%M:%S.%f').date()
    market_s = datetime.combine(curr_date,market_s)
    m_s = datetime.combine(curr_date,m_s)
    st= datetime.strptime(startTime, '%Y-%m-%d %H:%M:%S.%f') #start time 
    at= datetime.strptime(arrivalTime, '%Y-%m-%d %H:%M:%S.%f') #arrivaltime
    
    print "start time {} and arrival time {}".format(st,at)
    if at <=  market_s:
        ltp=getbse_nse_close(bse_df,nse_df,sccode)
    elif (at > market_s and at<=m_s):
        if df.empty:
            ltp=getbse_nse_close(bse_df,nse_df,sccode)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange.isin(["IS","IB"])]
            if dfEx.empty:
                ltp=getbse_nse_close(bse_df,nse_df,sccode)
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                #print ltp_df
                ltp=ltp_df.iloc[0]["price"]
    elif (at > m_s):
        if df.empty :
            ltp=getbse_nse_close(bse_df,nse_df,sccode)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange.isin(["IS","IB"])]
            if dfEx.empty:
                ltp=getbse_nse_close(bse_df,nse_df,sccode)
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                #print ltp_df
                ltp=ltp_df.iloc[0]["price"]
    else:
        ltp=0.0
    #print "---",ltp
    return float(ltp)  

def ltpNse(symbol,startTime,endTime,arrivalTime,sccode,l,limit,side,df,nse_df):
    m_s="09:15:00"
    m_s=datetime.strptime(m_s,'%H:%M:%S').time()
    market_s="09:00:00"
    market_s=datetime.strptime(market_s,'%H:%M:%S').time()
    #print startTime, endTime, arrivalTime
    #st= datetime.strptime(startTime, '%Y-%m-%d %H:%M:%S').time() #start time 
    curr_date = datetime.strptime(startTime,'%Y-%m-%d %H:%M:%S.%f').date()
    market_s = datetime.combine(curr_date,market_s)
    m_s = datetime.combine(curr_date,m_s)
    at= datetime.strptime(arrivalTime, '%Y-%m-%d %H:%M:%S.%f') #arrivaltime
    if at<=market_s:
        ltp=getnse_close(nse_df,sccode)
    elif at>market_s and at<=m_s:
        if df.empty:
            ltp=getnse_close(nse_df,sccode)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange=="IS"]
            if dfEx.empty:
                ltp=getnse_close(nse_df,sccode)
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                ltp=ltp_df.iloc[0]["price"]    
    elif (at > m_s): 
        if df.empty:
            ltp=getnse_close(nse_df,sccode)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange=="IS"]
            if dfEx.empty:
                ltp=getnse_close(nse_df,sccode)
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                ltp=ltp_df.iloc[0]["price"]
    else:
        ltp=0.0
    return float(ltp)

def ltpBse(symbol,startTime,endTime,arrivalTime,sccode,l,limit,side,df,bse_df):
    m_s="09:15:00"
    m_s=datetime.strptime(m_s,'%H:%M:%S').time()
    market_s="09:00:00"
    
    market_s=datetime.strptime(market_s,'%H:%M:%S').time()
    curr_date = datetime.strptime(startTime,'%Y-%m-%d %H:%M:%S.%f').date()
    market_s = datetime.combine(curr_date,market_s)
    m_s = datetime.combine(curr_date,m_s)
#    st= datetime.strptime(startTime, '%Y-%m-%d %H:%M:%S').time() #start time 
    at= datetime.strptime(arrivalTime, '%Y-%m-%d %H:%M:%S.%f') #arrivaltime
    if at<=market_s:
        ltp=getbse_close(bse_df,sccode)
    elif at>market_s and at<=m_s:
        if df.empty:
            ltp=getbse_close(bse_df,sccode)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange=="IB"]
            if dfEx.empty:
                ltp=0.0
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                ltp=ltp_df.iloc[0]["price"]
    
    elif (at > m_s):
        if df.empty:
            ltp=getbse_close(bse_df,sccode)
        else:
            df_f=filterTime(market_s,at,symbol,df)
            dfEx=df_f[df_f.exchange=="IB"]
            if dfEx.empty:
                ltp=0.0
            else:
                ltp_df=dfEx[-1:]
                ltp_df.reset_index(drop=True,inplace=True)
                ltp=ltp_df.iloc[0]["price"]
    else:
        ltp=0.0
    return float(ltp)

    
def averageTradeSize(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        if df_f.empty:
            AvgTradeSize=0.0
        else:
            try:
                AvgTradeSize=df_f["volume"].sum()/df_f.shape[0]
            except(df_f.shape[0]==0):
                AvgTradeSize=0.0
    else:
        AvgTradeSize=0.0
    return(AvgTradeSize)
    
def averageTradeSizeNse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
            
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IS"]
        if dfEx.empty:
            AvgTradeSize=0.0
        else:
            try:
                AvgTradeSize=dfEx["volume"].sum()/dfEx.shape[0]
            except(dfEx.shape[0]==0):
                AvgTradeSize=0.0
    else:
        AvgTradeSize=0.0
    return(AvgTradeSize)
    
def averageTradeSizeBse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IB"]
        if dfEx.empty:
            AvgTradeSize=0.0
        else:
            try:
                AvgTradeSize=dfEx["volume"].sum()/dfEx.shape[0]
            except(dfEx.shape[0]==0):
                AvgTradeSize=0.0
    else:
        AvgTradeSize=0.0
    return(AvgTradeSize)

#define rows fetched from cassandra to be a pandas dataframe
def getData(session,exchange,symbol,order_date):
    print session, exchange, symbol, order_date
    query='SELECT * FROM quotedata WHERE token(exchange,date)=token(\'{1}\',\'{2}\') and symbol=\'{0}\' ALLOW FILTERING;'.format(symbol,exchange,order_date)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    return(rows)
    
def myround(x, prec=2, base=.05):
  return round(base * round(float(x)/base),prec)

def fetch_nse_bhavcopy_cassandra(date):
    query_oi = session.execute("SELECT * FROM cm_bhavcopy where timestamp ='{}' and series='EQ' ALLOW FILTERING".format(date))
    query_oi = query_oi._current_rows
    return query_oi

def fetch_bse_bhavcopy_cassandra(date):
    query_oi = session.execute("SELECT * FROM bse_bhavcopy where trading_date ='{}' ALLOW FILTERING".format(date))
    query_oi = query_oi._current_rows
    return query_oi

def final_output(flag,outpath,market_start,market_end,d):
#    d=datetime.now().date() - timedelta(days=1)
    nse_df=fetch_nse_bhavcopy_cassandra(d)
    bse_df=fetch_bse_bhavcopy_cassandra(d)
    for r, d, f in os.walk(orderpath):
        for file in f:
            file_name = os.path.join(r, file)
            print(file_name)
            base = os.path.basename(file_name)[6:14]
            print(file_name, base)
            start_my = time()
            order=pd.read_csv(file_name)
            noOfRows=order.shape[0]
            colnames=["IntervalVwap","IntervalVwapNse","IntervalVwapBse","IntervalVwapLimit","AvgPx_vs_IntervalVwapLimit","IntervalVwapLimitNse","IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap","DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse","IntervalTwapBse","IntervalTwapLimit","AvgPx_vs_IntervalTwapLimit","IntervalTwapLimitNse","IntervalTwapLimitBse","DayTwapLimit","DayTwapLimitNse","DayTwapLimitBse","AvgPx_vs_IntervalVwap","AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit","AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","AvgPx_vs_DayTwapLimit","AvgPx_vs_Pwp","Pwp20Nse","Pwp20Bse","Pwp20","Pwp20Limit","AvgPx_vs_PwpLimit","Pwp20LimitNse","Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse","IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse","DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse","volExecBse_intervalVolBse","volExec_vs_IntervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse","volExec_vs_IntervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse","volExec_vs_DayVol","volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_vs_DayVolLimit","ArrivalPriceNse","ArrivalPriceBse","ArrivalPrice","AvgPx_vs_ArrivalPx","Pwp10Nse","Pwp10Bse","Pwp10","Pwp10Limit","Pwp10LimitNse","Pwp10LimitBse","Pwp15Nse","Pwp15Bse","Pwp15","Pwp15Limit","Pwp15LimitNse","Pwp15LimitBse","Pwp25Nse","Pwp25Bse","Pwp25","Pwp25Limit","Pwp25LimitNse","Pwp25LimitBse","Pwp30Nse","Pwp30Bse","Pwp30","Pwp30Limit","Pwp30LimitNse","Pwp30LimitBse"]
            col=inputcolnames+colnames
            result = pd.DataFrame()
            report_result = pd.DataFrame()
            n=np.zeros((noOfRows,len(colnames)))
            dummyDf=pd.DataFrame(n,columns=colnames)
            #print dummyDf.shape[0]
            order['tmp']=1
            dummyDf['tmp']=1
            orders= order.merge(dummyDf, on='tmp',how='outer',left_index=True, right_index=True)
            orders = orders.drop('tmp', axis=1)
            orders.fillna(0.0)
            #orders = orders[orders['SOR']=="N"]
        		
            grouped_orders = orders.groupby('TradeId', as_index=False).agg({'QuantityExecuted':'sum'})
            grouped_orders.rename(columns={'QuantityExecuted':'Tot_QuantityExecuted'}, inplace=True)
            final_orders = orders.merge(grouped_orders, on='TradeId', how='left')
            
            #column=['ric','date','time','type','price','volume']
            #df_temp=pd.read_csv(data+'getquotes_'+base+'.csv', names=column,header=None,skiprows=1)
            #df_temp['symbol'], df_temp['exchange'] = df_temp['ric'].str.split('.', 1).str
            #df_temp['date'] = df_temp['date'].astype(str)
            #df_temp['date'] = pd.to_datetime(df_temp['date'])
            #df_temp['time'] = df_temp['time'].astype(str)
            #df_temp['time'] = pd.to_datetime(df_temp['time'])
            #df_temp['time'] = df_temp['time'].dt.strftime("%H:%M:%S")
            #df_temp = df_temp[['symbol','exchange','date','time','type','price','volume']]
            prevtradeid = None
            for index,row in final_orders.iterrows():
                #logging.info('Getting price volume data to calculate parameters...')
                print (row["StartTime"])
                print (row["Ticker"], row["SOR"])
                startTime=pd.to_datetime(row["StartTime"], format='%Y %m %d %H:%M:%S')
                
                temp_filtered = final_orders[final_orders["Og_ClientOrdID"] == row["ClientOrdID"]]
                if ((row['Tot_QuantityExecuted'] >= row['OrderQty']) and (len(temp_filtered)==0)):
                    row["EndTime"] = row["LastFillTime"]
                #Extracting the date of the order
                try:
                    d=startTime.date()
                    d=d.strftime('%Y-%m-%d')
                except ValueError:
                    correctDate=False
                    print("Date error",str(correctDate))
                if flag==0:
                    logging.info("Get data from file...")
                    #df=pd.read_csv(data+"data.csv")
#                    if row["SOR"]=="Y":
#                        df_Nse=df_temp.loc[df_temp["exchange"]=="IS",:]
#                        df_Nse=df_temp.loc[df_temp["symbol"]==row["Ticker"],:]
#                        df_Bse=df_temp.loc[df_temp["exchange"]=="IB",:]
#                        df_Bse=df_temp.loc[df_temp["symbol"]==row["Ticker"],:]
#                        frames=[df_Nse,df_Bse]
#                        df=pd.concat(frames)
#                    elif row["SOR"]=="N" and row["SecurityExchange"]=="NSE":
#                        df_Nse=df_temp.loc[df_temp["exchange"]=="IS",:]
#                        df_Nse=df_temp.loc[df_temp["symbol"]==row["Ticker"],:]
#                        df_Bse=None
#                        df=df_Nse
#                    elif row["SOR"]=="N" and row["SecurityExchange"]=="BSE":
#                        df_Bse=df_temp.loc[df_temp["exchange"]=="IB",:]
#                        df_Bse=df_temp.loc[df_temp["symbol"]==row["Ticker"],:]
#                        df_Nse=None
#                        df=df_Bse
                else:
                    #print("Check if data required from cassandra")
                    #print(prevtradeid)
                    #print(row['TradeId'])
                    if ((prevtradeid == None) or (prevtradeid != row['TradeId'])):
                        print("Data required from cassandra")
                        if ((row["SOR"]=="Y") or (row["SOR"]=="N")):
                            #If SOR is 'Y' fetching both NSE and BSE data from cassandra
                            #read bloomberg data from cassandra or file depending value of flag passed in the parameter
                            df_Nse=getData(session,"IS",row["Ticker"],d)
                            df_Bse=getData(session,"IB",row["Ticker"],d)
                            frames=[df_Nse,df_Bse]
                            df=pd.concat(frames)
                            #If SOR is 'N' and  NSE order fetching NSE data from cassandra
                        elif row["SOR"]=="N" and row["SecurityExchange"]=="NSE":
                            df_Nse=getData(session,"IS",row["Ticker"],d)
                            df_Bse=None
                            df=df_Nse
                            #If SOR is 'N' and  BSE order fetching BSE data from cassandra
                        elif row["SOR"]=="N" and row["SecurityExchange"]=="BSE":
                           df_Bse=getData(session,"IB",row["Ticker"],d)
                           df_Nse=None
                           df=df_Bse
                #t1, t2 stores the starting time and closing time of the market on the day of order to calculate days vwap,twap etc
                df["price"] = df["price"].apply(myround)
                #print(df.head())
                t1=d+" "+market_start
                t2=d+" "+market_end
                #pwpPara is the parameter for calculating PWP20
                pwp10Para=row["QuantityExecuted"]*10
                pwp15Para=int(float(row["QuantityExecuted"])*6.67)
                pwp20Para=row["QuantityExecuted"]*5
                pwp25Para=row["QuantityExecuted"]*4
                pwp30Para=int(float(row["QuantityExecuted"])*3.34)
                if df.empty:
                    logging.info("DataFile is Empty...")
                    print("no data present")
                else:
                    #print df.head()
                    #calculating all the parameters and storing them in the respective variables
                    IntervalVolNse=volNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalVolBse=volBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalVwap=vwap(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalTwap=twap(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalVwapBse=vwapBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalVwapNse=vwapNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalTwapNse=twapNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalTwapBse=twapBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp10Nse=pwpNse(pwp10Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp10Bse=pwpBse(pwp10Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp10=pwp(pwp10Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp15Nse=pwpNse(pwp15Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp15Bse=pwpBse(pwp15Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp15=pwp(pwp15Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp20Nse=pwpNse(pwp20Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp20Bse=pwpBse(pwp20Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp20=pwp(pwp20Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp25Nse=pwpNse(pwp25Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp25Bse=pwpBse(pwp25Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp25=pwp(pwp25Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp30Nse=pwpNse(pwp25Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp30Bse=pwpBse(pwp25Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    Pwp30=pwp(pwp25Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayVol=vol(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayVolNse=volNse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayVolBse=volBse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayVwapNse=vwapNse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayVwapBse=vwapBse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayTwapNse=twapNse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayTwapBse=twapBse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayVwap=vwap(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    DayTwap=twap(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],df)
                    IntervalVol=vol(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                    if(row["SecurityExchange"] == "NSE"):
                        ArrivalPriceNse=ltpNse(row["Ticker"],row["StartTime"],row["EndTime"],row["ArrivalTime"],row["Symbol"],row["OrdType"],row["LimitPrice"],row["Side"],df,nse_df)
                        ArrivalPriceBse=ArrivalPriceNse
                        ArrivalPrice=ArrivalPriceNse
                    else:
                        ArrivalPriceBse=ltpBse(row["Ticker"],row["StartTime"],row["EndTime"],row["ArrivalTime"],row["Symbol"],row["OrdType"],row["LimitPrice"],row["Side"],df,bse_df)
                        ArrivalPriceNse=ArrivalPriceBse
                        ArrivalPrice=ArrivalPriceBse
                         #calculating all the limit adjucted parameter by filtering the dataframe within limit
                    if(row["OrdType"]=="LMT"):
                        if row["Side"]=="BUY":
                            dfInLimit=df.loc[df['price']<=float(row["LimitPrice"])]
                        else:
                            dfInLimit=df.loc[df['price']>=float(row["LimitPrice"])]
                            #print dfInLimit.head()
                        IntervalVolLimitNse=volNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalVolLimitBse=volBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalVwapLimit=vwap(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalTwapLimit=twap(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalVwapLimitNse=vwapNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalVwapLimitBse=vwapBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalTwapLimitNse=twapNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalTwapLimitBse=twapBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayVolLimitNse=volNse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayVolLimitBse=volBse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayVolLimit=vol(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayVwapLimit=vwap(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayVwapLimitNse=vwapNse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayTwapLimit=twap(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayVwapLimitBse=vwapBse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayTwapLimitNse=twapNse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        DayTwapLimitBse=twapBse(row["Ticker"],t1,t2,row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp10Limit=pwp(pwp10Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp10LimitNse=pwpNse(pwp10Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp10LimitBse=pwpBse(pwp10Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp15Limit=pwp(pwp15Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp15LimitNse=pwpNse(pwp15Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp15LimitBse=pwpBse(pwp15Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp20Limit=pwp(pwp20Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp20LimitNse=pwpNse(pwp20Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp20LimitBse=pwpBse(pwp20Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp25Limit=pwp(pwp25Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp25LimitNse=pwpNse(pwp25Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp25LimitBse=pwpBse(pwp25Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp30Limit=pwp(pwp30Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp30LimitNse=pwpNse(pwp30Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        Pwp30LimitBse=pwpBse(pwp30Para,row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        AvgTradeSizeNse=averageTradeSizeNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        AvgTradeSizeBse=averageTradeSizeBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        AvgTradeSize=averageTradeSize(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        IntervalVolLimit=vol(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],dfInLimit)
                        #If order type is market order then else condition works and limit adjusted parameters will be equal to interval parameters
                    else:
                        IntervalVolLimitNse=IntervalVolNse
                        IntervalVolLimitBse=IntervalVolBse
                        IntervalVwapLimitNse=IntervalVwapNse
                        IntervalVwapLimitBse=IntervalVwapBse
                        IntervalTwapLimitNse=IntervalTwapNse
                        IntervalTwapLimitBse=IntervalTwapBse
                        IntervalVwapLimit=IntervalVwap
                        IntervalTwapLimit=IntervalTwap
                        DayVolLimitNse=DayVolNse
                        DayVolLimitBse=DayVolBse
                        DayVolLimit=DayVol
                        DayVwapLimit=DayVwap
                        DayVwapLimitNse=DayVwapNse
                        DayVwapLimitBse=DayVwapBse
                        DayTwapLimit=DayTwap
                        DayTwapLimitNse=DayTwapNse
                        DayTwapLimitBse=DayTwapBse
                        Pwp10LimitNse=Pwp10Nse
                        Pwp10LimitBse=Pwp10Bse
                        Pwp10Limit=Pwp10
                        Pwp15LimitNse=Pwp15Nse
                        Pwp15LimitBse=Pwp15Bse
                        Pwp15Limit=Pwp15
                        Pwp20LimitNse=Pwp20Nse
                        Pwp20LimitBse=Pwp20Bse
                        Pwp20Limit=Pwp20
                        Pwp25LimitNse=Pwp25Nse
                        Pwp25LimitBse=Pwp25Bse
                        Pwp25Limit=Pwp25
                        Pwp30LimitNse=Pwp30Nse
                        Pwp30LimitBse=Pwp30Bse
                        Pwp30Limit=Pwp30
                        AvgTradeSizeNse=averageTradeSizeNse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                        AvgTradeSizeBse=averageTradeSizeBse(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                        AvgTradeSize=averageTradeSize(row["Ticker"],row["StartTime"],row["EndTime"],row["OrdType"],row["LimitPrice"],row["Side"],df)
                        IntervalVolLimit=IntervalVol
                        #if SOR 'Y' then giving both the NSE and BSE parameters values calculated above  
                    if(row["SOR"]=="Y"):
                        row["IntervalVolNse"]=IntervalVolNse
                        row["IntervalVwapNse"]=IntervalVwapNse
                        row["IntervalTwapNse"]=IntervalTwapNse
                        row["ArrivalPriceNse"]=ArrivalPriceNse
                        row["Pwp10Nse"]=Pwp10Nse
                        row["Pwp10LimitNse"]=Pwp10LimitNse
                        row["Pwp10Bse"]=Pwp10Bse
                        row["Pwp10LimitBse"]=Pwp10LimitBse
                        row["Pwp15Nse"]=Pwp15Nse
                        row["Pwp15LimitNse"]=Pwp15LimitNse
                        row["Pwp15Bse"]=Pwp15Bse
                        row["Pwp15LimitBse"]=Pwp15LimitBse
                        row["Pwp20Nse"]=Pwp20Nse
                        row["Pwp20LimitNse"]=Pwp20LimitNse
                        row["Pwp20Bse"]=Pwp20Bse
                        row["Pwp20LimitBse"]=Pwp20LimitBse
                        row["Pwp25Nse"]=Pwp25Nse
                        row["Pwp25LimitNse"]=Pwp25LimitNse
                        row["Pwp25Bse"]=Pwp25Bse
                        row["Pwp25LimitBse"]=Pwp25LimitBse
                        row["Pwp30Nse"]=Pwp30Nse
                        row["Pwp30LimitNse"]=Pwp30LimitNse
                        row["Pwp30Bse"]=Pwp30Bse
                        row["Pwp30LimitBse"]=Pwp30LimitBse
                        row["IntervalVolLimitNse"]=IntervalVolLimitNse
                        row["IntervalVolLimitBse"]=IntervalVolLimitBse
                        row["IntervalVolBse"]=IntervalVolBse
                        row["IntervalVwapBse"]=IntervalVwapBse
                        row["IntervalTwapBse"]=IntervalTwapBse
                        row["AvgTradeSizeNse"]=AvgTradeSizeNse
                        row["AvgTradeSizeBse"]=AvgTradeSizeBse
                        row["ArrivalPriceBse"]=ArrivalPriceBse
                        row["IntervalVwapLimitNse"]=IntervalVwapLimitNse
                        row["IntervalVwapLimitBse"]=IntervalVwapLimitBse
                        row["IntervalTwapLimitNse"]=IntervalTwapLimitNse
                        row["IntervalTwapLimitBse"]=IntervalTwapLimitBse
                        #if SOR 'N' and order exchange is NSE then giving NSE parameters values calculated above  
                    elif(row["SOR"]=="N" and df.loc[df["exchange"]=="IS"].shape[0]>0 and (row["SecurityExchange"]=="NSE")):
                        row["IntervalVolNse"]=IntervalVolNse
                        row["IntervalVolLimitNse"]=IntervalVolLimitNse
                        row["AvgTradeSizeNse"]=AvgTradeSizeNse
                        row["Pwp10LimitNse"]=Pwp10LimitNse
                        row["Pwp10Nse"]=Pwp10Nse
                        row["Pwp15LimitNse"]=Pwp15LimitNse
                        row["Pwp15Nse"]=Pwp15Nse
                        row["Pwp20LimitNse"]=Pwp20LimitNse
                        row["Pwp20Nse"]=Pwp20Nse
                        row["Pwp25LimitNse"]=Pwp20LimitNse
                        row["Pwp25Nse"]=Pwp20Nse
                        row["Pwp30LimitNse"]=Pwp30LimitNse
                        row["Pwp30Nse"]=Pwp30Nse
                        row["IntervalVwapNse"]=IntervalVwapNse
                        row["IntervalTwapNse"]=IntervalTwapNse
                        row["ArrivalPriceNse"]=ArrivalPriceNse
                        row["IntervalVwapLimitNse"]=IntervalVwapLimitNse
                        row["IntervalTwapLimitNse"]=IntervalTwapLimitNse
                        #if SOR 'N' and order exchange is BSE then giving BSE parameters values calculated above  
                    elif(row["SOR"]=="N" and df.loc[df["exchange"]=="IB"].shape[0]>0 and (row["SecurityExchange"]=="BSE")):
                        row["IntervalVolBse"]=IntervalVolBse
                        row["IntervalVolLimitBse"]=IntervalVolLimitBse
                        row["AvgTradeSizeBse"]=AvgTradeSizeBse
                        row["IntervalTwapBse"]=IntervalTwapBse
                        row["IntervalVwapBse"]=IntervalVwapBse
                        row["IntervalVwapLimitBse"]=IntervalVwapLimitBse
                        row["IntervalTwapLimitBse"]=IntervalTwapLimitBse
                        row["ArrivalPriceBse"]=ArrivalPriceBse
                        row["Pwp10Bse"]=Pwp10Bse
                        row["Pwp10LimitBse"]=Pwp10LimitBse
                        row["Pwp15Bse"]=Pwp15Bse
                        row["Pwp15LimitBse"]=Pwp15LimitBse
                        row["Pwp20Bse"]=Pwp20Bse
                        row["Pwp20LimitBse"]=Pwp20LimitBse
                        row["Pwp25Bse"]=Pwp25Bse
                        row["Pwp25LimitBse"]=Pwp25LimitBse
                        row["Pwp30Bse"]=Pwp30Bse
                        row["Pwp30LimitBse"]=Pwp30LimitBse
                    #storing parameters in order file column  which will be present irrespective of SOR value
                    row["IntervalVwap"]=IntervalVwap
                    row["IntervalVwapLimit"]=IntervalVwapLimit
                    row["IntervalTwapLimit"]=IntervalTwapLimit
                    row["IntervalTwap"]=IntervalTwap
                    row["IntervalVolLimit"]=IntervalVolLimit
                    row["IntervalVol"]=IntervalVol
                    row["AvgTradeSize"]=AvgTradeSize
                    row["ArrivalPrice"]=ArrivalPrice
                    row["DayVolLimitNse"]=DayVolLimitNse
                    row["DayVolLimitBse"]=DayVolLimitBse
                    row["DayVolLimit"]=DayVolLimit
                    row["Pwp10"]=Pwp10
                    row["Pwp10Limit"]=Pwp10Limit  
                    row["Pwp15"]=Pwp15
                    row["Pwp15Limit"]=Pwp15Limit 
                    row["Pwp20"]=Pwp20
                    row["Pwp20Limit"]=Pwp20Limit 
                    row["Pwp25"]=Pwp25
                    row["Pwp25Limit"]=Pwp25Limit 
                    row["Pwp30"]=Pwp30
                    row["Pwp30Limit"]=Pwp30Limit 
                    row["DayVwap"]=DayVwap
                    row["DayTwap"]=DayTwap
                    row["DayVwapNse"]=DayVwapNse
                    row["DayVwapBse"]=DayVwapBse
                    row["DayTwapNse"]=DayTwapNse
                    row["DayTwapBse"]=DayTwapBse
                    row["DayVwapLimitNse"]=DayVwapLimitNse
                    row["DayVolLimit"]=DayVolLimit
                    row["DayVol"]=DayVol
                    row["DayVolNse"]=DayVolNse
                    row["DayVolBse"]=DayVolBse
                    row["DayVwapLimit"]=DayVwapLimit
                    row["DayVwapLimitBse"]=DayVwapLimitBse
                    row["DayTwapLimit"]=DayTwapLimit
                    row["DayTwapLimitNse"]=DayTwapLimitNse
                    row["DayTwapLimitBse"]=DayTwapLimitBse
                    #row["AvgPx"]=float(row["AvgPx"])
                    #execution volume percent of interval volume 
                    if row["IntervalVol"]!=0.0:
                        row["volExec_vs_IntervalVol"]=((row["QuantityExecuted"]*1.0)/row["IntervalVol"])*100.0  #calculating volumeExecuted by order vs volume in that interval
                    if row["IntervalVolNse"]!=0.0:
                        row["volExecNse_intervalVolNse"]=((row["NSEExecutedQty"]*1.0)/row["IntervalVolNse"])*100.0
                        #print row["volExecNse_intervalVolNse"]
                    if row["IntervalVolBse"]!=0.0:
                        row["volExecBse_intervalVolBse"]=(float(row["BSEExecutedQty"])/row["IntervalVolBse"])*100.0
                        #print row["volExecBse_intervalVolBse"]
                    if row["IntervalVolLimit"]!=0.0:
                        row["volExec_vs_IntervalVolLimit"]=((row["QuantityExecuted"]*1.0)/row["IntervalVolLimit"])*100.0  #calculating volumeExecuted by order vs volume in that interval
                        #print row["volExec_intervalVol"]
                    if row["IntervalVolLimitNse"]!=0.0:
                        row["volExecNse_intervalVolLimitNse"]=(float(row["NSEExecutedQty"])/row["IntervalVolLimitNse"])*100.0
                        #print row["volExecNse_intervalVolNse"]
                    if row["IntervalVolLimitBse"]!=0.0:
                        row["volExecBse_intervalVolLimitBse"]=(float(row["BSEExecutedQty"])/row["IntervalVolLimitBse"])*100.0
                        #print row["volExecBse_intervalVolBse"]
                    #percentage calculation quantity executed vs Days vol parameters
                    if row["DayVol"]!=0.0:
                        row["volExec_vs_DayVol"]=(float(row["QuantityExecuted"])/row["DayVol"])*100.0
                    if row["DayVolNse"]!=0.0:
                        row["volExecNse_DayVolNse"]=(float(row["NSEExecutedQty"])/row["DayVolNse"])*100.0
                    if row["DayVolBse"]!=0.0:
                        row["volExecBse_DayVolBse"]=(float(row["BSEExecutedQty"])/row["DayVolBse"])*100.0
                    if row["DayVolLimit"]!=0.0:
                        row["volExec_vs_DayVolLimit"]=(float(row["QuantityExecuted"])/row["DayVolLimit"])*100.0
                    if row["DayVolLimitNse"]!=0.0:
                        row["volExecNse_DayVolLimitNse"]=(float(row["NSEExecutedQty"])/row["DayVolLimitNse"])*100.0
                    if row["DayVolLimitBse"]!=0.0:
                        row["volExecBse_DayVolLimitBse"]=(float(row["BSEExecutedQty"])/row["DayVolLimitBse"])*100.0
                    #calculting values of avgPrice vs calculated parameters vwap,twap
                    #print "Interval VWAP:",row["IntervalVwap"],row["AvgPx"],
                    if row["Side"]=="BUY":
                        if row["IntervalVwap"]!=0.0:
                            row["AvgPx_vs_IntervalVwap"]=(float(row["IntervalVwap"]-row["AvgPx"])/row["IntervalVwap"])*10000
                        if row["IntervalVwapLimit"]!=0.0:
                            row["AvgPx_vs_IntervalVwapLimit"]=((row["IntervalVwapLimit"]-row["AvgPx"])/row["IntervalVwapLimit"])*10000
                        if row["DayVwap"]!=0.0:
                            row["AvgPx_vs_DayVwap"]=((row["DayVwap"]-row["AvgPx"])/row["DayVwap"])*10000
                        if row["DayVwapLimit"]!=0.0:
                            row["AvgPx_vs_DayVwapLimit"]=((row["DayVwapLimit"]-row["AvgPx"])/row["DayVwapLimit"])*10000
        
                        if row["IntervalTwap"]!=0.0:
                            row["AvgPx_vs_IntervalTwap"]=((row["IntervalTwap"]-row["AvgPx"])/row["IntervalTwap"])*10000
                        if row["IntervalTwapLimit"]!=0.0:
                            row["AvgPx_vs_IntervalTwapLimit"]=((row["IntervalTwapLimit"]-row["AvgPx"])/row["IntervalTwapLimit"])*10000
                        if row["DayTwap"]!=0.0:
                            row["AvgPx_vs_DayTwap"]=((row["DayTwap"]-row["AvgPx"])/row["DayTwap"])*10000
                        if row["DayTwapLimit"]!=0.0:
                            row["AvgPx_vs_DayTwapLimit"]=((row["DayTwapLimit"]-row["AvgPx"])/row["DayTwapLimit"])*10000
                        
                        if row["Pwp20"]!=0.0:
                            row["AvgPx_vs_Pwp"]=((row["Pwp20"]-row["AvgPx"])/row["Pwp20"])*10000
                        if row["Pwp20Limit"]!=0.0:
                            row["AvgPx_vs_PwpLimit"]=((row["Pwp20Limit"]-row["AvgPx"])/row["Pwp20Limit"])*10000
                        if row["ArrivalPrice"]!=0.0:
                            #print "Arrival price:" +  str(row["ArrivalPrice"]) + "|" + str(row["AvgPx"]) + "|" + str(type(row["ArrivalPrice"])) + "|" + str(type(row["AvgPx"]))
                            row["AvgPx_vs_ArrivalPx"]=(float(row["ArrivalPrice"]-row["AvgPx"])/row["ArrivalPrice"])*10000
                    else:
                        if row["DayVwap"]!=0.0:
                            row["AvgPx_vs_DayVwap"]=((-row["DayVwap"]+row["AvgPx"])/row["DayVwap"])*10000
                        if row["IntervalVwap"]!=0.0:
                            row["AvgPx_vs_IntervalVwap"]=(float(-row["IntervalVwap"]+row["AvgPx"])/row["IntervalVwap"])*10000
                        if row["DayVwapLimit"]!=0.0:
                            row["AvgPx_vs_DayVwapLimit"]=((-row["DayVwapLimit"]+row["AvgPx"])/row["DayVwapLimit"])*10000
                        if row["IntervalVwapLimit"]!=0.0:
                            row["AvgPx_vs_IntervalVwapLimit"]=((-row["IntervalVwapLimit"]+row["AvgPx"])/row["IntervalVwapLimit"])*10000
        
                        if row["DayTwap"]!=0.0:
                            row["AvgPx_vs_DayTwap"]=((-row["DayTwap"]+row["AvgPx"])/row["DayTwap"])*10000
                        if row["IntervalTwap"]!=0.0:
                            row["AvgPx_vs_IntervalTwap"]=((-row["IntervalTwap"]+row["AvgPx"])/row["IntervalTwap"])*10000
                        if row["DayTwapLimit"]!=0.0:
                            row["AvgPx_vs_DayTwapLimit"]=((-row["DayTwapLimit"]+row["AvgPx"])/row["DayTwapLimit"])*10000
                        if row["IntervalTwapLimit"]!=0.0:
                            row["AvgPx_vs_IntervalTwapLimit"]=((-row["IntervalTwapLimit"]+row["AvgPx"])/row["IntervalTwapLimit"])*10000
        
                        if row["Pwp20"]!=0.0:
                            row["AvgPx_vs_Pwp"]=((-row["Pwp20"]+row["AvgPx"])/row["Pwp20"])*10000
                        if row["Pwp20Limit"]!=0.0:
                            row["AvgPx_vs_PwpLimit"]=((-row["Pwp20Limit"]+row["AvgPx"])/row["Pwp20Limit"])*10000
                        if row["ArrivalPrice"]!=0.0:
                            row["AvgPx_vs_ArrivalPx"]=(-row["ArrivalPrice"]+row["AvgPx"]/row["ArrivalPrice"])*10000
        
                # the rows with calculated parameters aadded to daarrivalPx       
                logging.info("adding rows to result dataframe...")
                result=result.loc[~result.index.duplicated(keep='first')]
                row=row.loc[~row.index.duplicated(keep='first')]
                result=result.append(row)
                
                report_result=report_result.loc[~report_result.index.duplicated(keep='first')]
                report_result=report_result.append(row)
                prevtradeid = row["TradeId"]
                #print row
                
            #all the NaN values in a row of the parameter calculated filled by 0.0
            result=result.fillna(0.0)
            result=result.reindex(columns=col)
            
            report_result=report_result.fillna(0.0)
            report_result=report_result.reindex(columns=col)
            #print report_result.columns
            report_result.drop(labels=["ArrivalTime", "NSEExecutedQty","BSEExecutedQty","NSEExecutedAvg","BSEExecutedAvg","IntervalVwap","IntervalVwapNse","IntervalVwapBse","IntervalVwapLimitNse","IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap","DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse","IntervalTwapBse","IntervalTwapLimitNse","IntervalTwapLimitBse","DayTwapLimit","DayTwapLimitNse","DayTwapLimitBse","Pwp20Nse","Pwp20Bse","Pwp20","Pwp20LimitNse","Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse","IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse","DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","ArrivalPriceNse","ArrivalPriceBse","volExecBse_DayVolBse","volExecBse_DayVolLimitBse","volExecBse_intervalVolBse","volExecBse_intervalVolLimitBse","volExecNse_DayVolLimitNse","volExecNse_DayVolNse","volExecNse_intervalVolLimitNse","volExecNse_intervalVolNse","AvgPx_vs_IntervalVwap","AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit","AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","AvgPx_vs_DayTwapLimit","AvgPx_vs_Pwp","volExec_vs_IntervalVol","volExec_vs_IntervalVolLimit","volExec_vs_DayVol","volExec_vs_DayVolLimit"],axis=1,inplace=True)
            report_result.rename(columns={'Og_ClientOrdID':'Orig_Client_OrdID', 'ClientOrdID':'Client_OrdID', 'ClientName':'Client_Name', 'LimitPrice':'Limit_Price', 'SecurityExchange':'Security_Exchange', 'QuantityExecuted':'Quantity_Executed', 'LastFillTime':'Last_Fill_Time', 'IntervalVwapLimit':'Interval_Vwap_Limit', 'Algorithm':'Algo', 'StartTime':'Start_Time', 'EndTime':'End_Time', 'AvgPx_vs_IntervalVwapLimit':'AvgPx_vs_Interval_Vwap_Limit', 'IntervalTwapLimit':'Interval_Twap_Limit', 'AvgPx_vs_IntervalTwapLimit':'AvgPx_vs_Interval_Twap_Limit', 'ArrivalPrice':'Arrival_Price'}, inplace=True)
            
            
            
            #print result.head()
            logging.info("Writing to a new csv file...")
            #result.to_csv(outpath+"out.csv")
            
        #Writing to multiple sheets in Excel
            writer = pd.ExcelWriter(outpath+"output" + "_" + base + ".xlsx")
#            summary_writer = pd.ExcelWriter(outpath+"summary" + "_" + base + ".xlsx")
#            report_result.to_excel(writer, sheet_name="report", index=False, engine="xlsxwriter")
            result.to_excel(writer, sheet_name="complete_output", index=False)
            
#            workbook = writer.book
#            worksheet = writer.sheets["report"]
#            report_result.columns = report_result.columns.str.replace('_',' ')
#            green_format = workbook.add_format({'font_color':'#4c7d4c', 'bg_color':'#98fb98'})
#            red_format = workbook.add_format({'font_color':'#FF0000', 'bg_color':'#FF9999'})
#            header_format = workbook.add_format({
#            'bold': True,
#            'text_wrap': True,
#            'valign': 'top',
#            'border': 1})
#                
#            for col_num, value in enumerate(report_result.columns.values):
#                worksheet.write(0, col_num, value, header_format)  # set header format
#                max_len = 8.5
#                worksheet.set_column(col_num, col_num, max_len)  # set column width
#            
#            for i in range(9):
#                col_len = 7.5
#                worksheet.set_column(i, i, col_len)
#            
#            #Applying conditional formatting to cells
#            worksheet.conditional_format('V2:V1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            worksheet.conditional_format('X2:X1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            worksheet.conditional_format('Z2:Z1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            worksheet.conditional_format('AB2:AB1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            worksheet.conditional_format('V2:V1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            worksheet.conditional_format('X2:X1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            worksheet.conditional_format('Z2:Z1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            worksheet.conditional_format('AB2:AB1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            
#            #combined = pd.read_excel(outpath+"output" + "_" + base + ".xlsx", sheet_name='report')
#            #combined = combined.append(df, ignore_index=True)
#            
#            result['Start Time'] = pd.to_datetime(result['StartTime'])
#            result['Date'] = result['Start Time']
#            result['values'] = result['AvgPx']*result['QuantityExecuted']
#            result['VWAPvalues'] = result['IntervalVwapLimit']*result['IntervalVolLimit']
#            result['TWAPvalues'] = result['IntervalTwapLimit']*result['IntervalVolLimit']
#            result['PWPvalues'] = result['Pwp20Limit']*result['IntervalVolLimit']
#            #result['ArrPxvalues'] = result['ArrivalPrice']*result['QuantityExecuted']
#            result = result[result['QuantityExecuted']!=0]
#            
#            combined_group = result.groupby('TradeId', as_index=False).agg({'IntervalVolLimit':'sum','QuantityExecuted':'sum','values':'sum', 'VWAPvalues':'sum', 'TWAPvalues':'sum', 'PWPvalues':'sum', 'Date':'first', 'ClientName':'first', 'Symbol':'first', 'Side':'first', 'ArrivalPrice':'first','AvgPx_vs_ArrivalPx':'first','Tag115':'first'})
#            combined_group['wt_AvgPx'] = combined_group['values']/combined_group['QuantityExecuted']
#            combined_group['wt_VWAP'] = combined_group['VWAPvalues']/combined_group['IntervalVolLimit']
#            combined_group['wt_TWAP'] = combined_group['TWAPvalues']/combined_group['IntervalVolLimit']
#            combined_group['wt_PWP'] = combined_group['PWPvalues']/combined_group['IntervalVolLimit']
#            #combined_group['wt_ArrivalPx'] = combined_group['ArrPxvalues']/combined_group['QuantityExecuted']
#            combined_group.fillna(0, inplace=True)
#            combined_group.sort_values(by='Date', inplace=True)
#            combined_group.drop(['values', 'VWAPvalues', 'TWAPvalues', 'PWPvalues'], axis=1, inplace=True)
#            
#            # calculating parameters
#            combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
#            combined_group['wtTWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_TWAP'])/combined_group['wt_TWAP'])*10000
#            combined_group['wtPWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_PWP'])/combined_group['wt_PWP'])*10000
#            combined_group['wtArrPx_vs_AvgPx'] = combined_group['AvgPx_vs_ArrivalPx']
#            combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
#            combined_group.fillna(0, inplace=True)
#            
#            # BUY side parameters
#            combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtVWAP_vs_AvgPx']
#            combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtTWAP_vs_AvgPx']
#            combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtPWP_vs_AvgPx']
#            combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtArrPx_vs_AvgPx']
#            
#            # SELL side parameters
#            combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtVWAP_vs_AvgPx']
#            combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtTWAP_vs_AvgPx']
#            combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtPWP_vs_AvgPx']
#            combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtArrPx_vs_AvgPx']
#            
#            # Difference parameters
#            combined_group['VWAP_Value_Difference'] = (combined_group['wtVWAP_vs_AvgPx']*combined_group['wt_VWAP']*combined_group['QuantityExecuted'])/10000
#            combined_group['TWAP_Value_Difference'] = (combined_group['wtTWAP_vs_AvgPx']*combined_group['wt_TWAP']*combined_group['QuantityExecuted'])/10000
#            combined_group['PWP_Value_Difference'] = (combined_group['wtPWP_vs_AvgPx']*combined_group['wt_PWP']*combined_group['QuantityExecuted'])/10000
#            combined_group['ArrPx_Value_Difference'] = (combined_group['wtArrPx_vs_AvgPx']*combined_group['ArrivalPrice']*combined_group['QuantityExecuted'])/10000
#            
#            
#            combined_group = combined_group[['TradeId','ClientName','QuantityExecuted', 'Symbol', 'Side', 'Date', 'wt_AvgPx', 'wt_VWAP', 'wtVWAP_vs_AvgPx', 'VWAP_Value_Difference', 'wt_TWAP', 'wtTWAP_vs_AvgPx', 'TWAP_Value_Difference', 'wt_PWP', 'wtPWP_vs_AvgPx', 'PWP_Value_Difference', 'ArrivalPrice', 'wtArrPx_vs_AvgPx', 'ArrPx_Value_Difference']]
#            
#            combined_group = combined_group.round(decimals=4)
#
#            
#            combined_group.to_excel(writer, sheet_name='summary_report', index=False, engine='xlsxwriter')
#            combined_group.to_excel(summary_writer, sheet_name='summary_report', index=False, engine='xlsxwriter')
#            
#            summ_worksheet = writer.sheets["summary_report"]
#            combined_group.columns = combined_group.columns.str.replace('_',' ')
#            
#            for col_num, value in enumerate(combined_group.columns.values):
#                summ_worksheet.write(0, col_num, value, header_format)  # set header format
#                max_len = 10
#                summ_worksheet.set_column(col_num, col_num, max_len)  # set column width
#            
##            for i in range(9):
##                col_len = 7.5
##                summ_worksheet.set_column(i, i, col_len)
#            
#            #applying conditional format on summary report sheet
#            summ_worksheet.conditional_format('I2:I1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            summ_worksheet.conditional_format('J2:J1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            summ_worksheet.conditional_format('L2:L1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            summ_worksheet.conditional_format('M2:M1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})            
#            summ_worksheet.conditional_format('O2:O1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            summ_worksheet.conditional_format('P2:P1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            summ_worksheet.conditional_format('R2:R1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            summ_worksheet.conditional_format('S2:S1048576',{'type': 'cell', 'criteria': '>', 'value': 0, 'format': green_format})
#            
#            summ_worksheet.conditional_format('I2:I1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            summ_worksheet.conditional_format('J2:J1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            summ_worksheet.conditional_format('L2:L1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            summ_worksheet.conditional_format('M2:M1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            summ_worksheet.conditional_format('O2:O1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            summ_worksheet.conditional_format('P2:P1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            summ_worksheet.conditional_format('R2:R1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
#            summ_worksheet.conditional_format('S2:S1048576',{'type': 'cell', 'criteria': '<', 'value': 0, 'format': red_format})
            
            writer.save()
            end_my = time()
            print("Order file process time : " + str(end_my - start_my))
            
    #print(result.IntervalVwap)
start_time = time()
#if __name__ == '__main__':
    #calling the main with passing the path of the order file created with above calculated parameters
def tca_calc(d):
    print "date",d
    final_output(flag,outpath,market_start,market_end,d)
            
end_time = time()
logging.info("Time taken to process :{0} Seconds....".format(end_time - start_time))
print("Execution time: {0} Seconds.... ".format(end_time - start_time))

