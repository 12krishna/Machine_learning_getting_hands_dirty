# -*- coding: utf-8 -*-
"""
Created on Fri May 10 17:12:32 2019

@author: Administrator
"""

import os
import re
import pandas as pd
import numpy as np
import string
import simplefix
from datetime import datetime, timedelta
from time import time
filelist = list()
start_time = time()
input_path='Z:\\'
outpath = 'D:\\FIXLogParser\\ETS_TCA\\Orders_Gen_ETS\\'
expr = r'8=FIX\.4\.2.*?10=\d+\|'

def split1():
    subdirs_list = [r[1] for r in os.walk(input_path)]
    for i in subdirs_list[0]:
        filelist.append(input_path + i + '\\' + i[17:21] + i[14:16] + i[11:13] + '.txt')
    #print filelist
    #subdirs = [datetime.strptime(sub.split('_')[1], '%d-%m-%Y').strftime('%Y%m%d') + '.txt' for sub in subdirs_list[0]]
    #m_start = pd.to_datetime('09:15:00').time()
     
    for i in filelist:
        file_name = i
        print file_name
        
        f = open(file_name,'r')
        if f.mode == 'r':
            content = f.readlines()
        
            base = os.path.basename(file_name)
            tempfile1_name = "tempfile1_" + str(os.path.splitext(base)[0]) +".csv"
            tempfile2_name = "tempfile2_" + str(os.path.splitext(base)[0]) +".csv"
            tempfile1 = open(outpath + tempfile1_name, 'w')
            tempfile2 = open(outpath + tempfile2_name, 'w')
            for line in content:
                if re.findall(expr, line):
                    rx = re.findall(expr, line)
                    if '49=FIXETSKotakSbase' in rx[0]:
                        if '56=FIXETSKotakClient' in rx[0]:
                            if '35=8' in rx[0]:
                                x = string.replace(rx[0], '|','\x01')
                                parser = simplefix.FixParser()
                                parser.append_buffer(x)
                                msg = parser.get_message()
                                tempfile1.write(str(msg.get(11)) + "," + str(msg.get(41)) + "," + str(msg.get(55)) + "," + str(msg.get(37)) + "," + str(msg.get(60)) + "," + str(msg.get(31)) + "," + str(msg.get(32)) + "," + str(msg.get(30)))
                                tempfile1.write("\n")
                    elif '49=FIXETSKotakClient' in rx[0]:
                        if '56=FIXETSKotakSbase' in rx[0]:
                            if (('35=D' in rx[0]) or ('35=G' in rx[0]) or ('35=F' in rx[0])):
                                x = string.replace(rx[0], '|','\x01')
                                parser = simplefix.FixParser()
                                parser.append_buffer(x)
                                msg = parser.get_message()
                                tempfile2.write(str(msg.get(35)) + "," + str(msg.get(11)) + "," + str(msg.get(41)) + "," + str(msg.get(1)) + "," + str(msg.get(55)) + "," + str(msg.get(40)) + "," + str(msg.get(44)) + "," + str(msg.get(54)) + "," + str(msg.get(100)) + "," + str(msg.get(9251)) + "," + str(msg.get(9252)) + "," + str(msg.get(38)) + "," + str(msg.get(9270)) + "," + str(msg.get(58)) + "," + str(msg.get(9250)) + "," + str(msg.get(9272)) + "," + str(msg.get(52))+ "," + str(msg.get(115)))
                                tempfile2.write("\n")
            f.close()
    
            if ((os.stat(outpath + tempfile1_name).st_size == 0) and (os.stat(outpath + tempfile2_name).st_size == 0)):
                tempfile1.close()
                tempfile2.close()
                os.remove(outpath + tempfile1_name)
                os.remove(outpath + tempfile2_name)
                continue
    
            tempfile1.close()
            tempfile2.close()
            print 'done'
                
    end_time = time()
    print "Execution time: {0} Seconds.... ".format(end_time - start_time)