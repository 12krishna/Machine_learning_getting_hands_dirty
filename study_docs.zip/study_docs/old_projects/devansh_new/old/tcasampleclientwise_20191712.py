# -*- coding: utf-8 -*-
"""
Created on Thu Dec  5 16:09:46 2019

@author: Administrator
"""

import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import datetime,psycopg2,logging

#output_dir='C:\\Users\\devanshm\\Desktop\\devansh\\TCAoutput\\TCA\\output\\'
output_dir='D:\\devansh_new\\'

def highlight_vals_c1(val):
    if val < 0:
        color='#FF0000'
    else:
        color='#008000'
    
    return 'color: %s' % color

def color_r_g_b(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    if val > 25:
        color = '#FF0000' #red
    elif val>=20 and val<=25:
        color='blue' 
    else:
        color='#008000' #green 
    return 'color: %s' % color

def get_postgress_data(d,d1):
    #get latest date from database
    conn = psycopg2.connect(database="NSE-FNO",
                            user="postgres",
                             password="kotak@123", 
                             host="172.17.9.182", 
                             port="5432")
    cur=conn.cursor()
    cur.execute("select * from tca_split where date>='{}' and date <='{}';".format(d1,d)) #d current date ,d1 previous date
    df = cur.fetchall()
    df = pd.DataFrame(df)
    return df

def get_tca_split(tca):
    
    #add column names to the newlist
    newlist=[]
    newlist=tca.columns
    
    #get column name ends with bse and nse and append them to the respective list
    bselist=[]
    nselist=[]
    for i in range(0,len(newlist)):
        if newlist[i].endswith('Bse'):
            bselist.append(newlist[i])
        if newlist[i].endswith('Nse'):
            nselist.append(newlist[i])
    
    print "Bselist",bselist
    print "Nselist",nselist
    #create pairlist and append row to it based on sor is y or n and security exchange is bse or nse
    pairlist=[]
    for col,row in tca.iterrows():
        if row["SOR"]=="Y":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType',
                        'LimitPrice','Side','SecurityExchange','StartTime','EndTime','OrderQty','SOR','NSEExecutedQty',
                        'NSEExecutedQty','NSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapNse','IntervalVwapLimitNse','DayVwapLimitNse','DayVwapNse','DayTwapNse','IntervalTwapNse',
                        'IntervalTwapLimitNse','DayTwapLimitNse','Pwp20Nse','Pwp20LimitNse',
                        'Pwp10Nse','Pwp10LimitNse',
                        'Pwp15Nse','Pwp15LimitNse',
                        'Pwp25Nse','Pwp25LimitNse',
                        'Pwp30Nse','Pwp30LimitNse',
                        'AvgTradeSizeNse','IntervalVolNse',
                        'IntervalVolLimitNse','DayVolNse','DayVolLimitNse','volExecNse_intervalVolNse',
                        'volExecNse_intervalVolLimitNse','volExecNse_DayVolNse','volExecNse_DayVolLimitNse','ArrivalPrice','Tag115']]
            result["SecurityExchange"]="NSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result) 
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                        'SecurityExchange','StartTime','EndTime','OrderQty','SOR','BSEExecutedQty','BSEExecutedQty',
                        'BSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapBse','IntervalVwapLimitBse','DayVwapLimitBse','DayVwapBse','DayTwapBse','IntervalTwapBse',
                        'IntervalTwapLimitBse','DayTwapLimitBse','Pwp20Bse','Pwp20LimitBse',
                        'Pwp10Bse','Pwp10LimitBse',
                        'Pwp15Bse','Pwp15LimitBse',
                        'Pwp25Bse','Pwp25LimitBse',
                        'Pwp30Bse','Pwp30LimitBse',
                        'AvgTradeSizeBse','IntervalVolBse',
                        'IntervalVolLimitBse','DayVolBse','DayVolLimitBse','volExecBse_intervalVolBse','volExecBse_intervalVolLimitBse',
                        'volExecBse_DayVolBse', 'volExecBse_DayVolLimitBse','ArrivalPrice','Tag115']]
            result["SecurityExchange"]="BSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
        
        if row["SOR"]=='N' and row["SecurityExchange"]=="NSE":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType',
                        'LimitPrice','Side','SecurityExchange','StartTime','EndTime','OrderQty','SOR','NSEExecutedQty',
                        'NSEExecutedQty','NSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapNse','IntervalVwapLimitNse','DayVwapLimitNse','DayVwapNse','DayTwapNse','IntervalTwapNse',
                        'IntervalTwapLimitNse','DayTwapLimitNse','Pwp20Nse','Pwp20LimitNse',
                        'Pwp10Nse','Pwp10LimitNse',
                        'Pwp15Nse','Pwp15LimitNse',
                        'Pwp25Nse','Pwp25LimitNse',
                        'Pwp30Nse','Pwp30LimitNse',
                        'AvgTradeSizeNse','IntervalVolNse',
                        'IntervalVolLimitNse','DayVolNse','DayVolLimitNse','volExecNse_intervalVolNse',
                        'volExecNse_intervalVolLimitNse','volExecNse_DayVolNse','volExecNse_DayVolLimitNse','ArrivalPrice','Tag115']]
            result["SecurityExchange"]="NSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
    
        if row["SOR"]=='N' and row["SecurityExchange"]=="BSE":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                        'SecurityExchange','StartTime','EndTime','OrderQty','SOR','BSEExecutedQty','BSEExecutedQty',
                        'BSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapBse','IntervalVwapLimitBse','DayVwapLimitBse','DayVwapBse','DayTwapBse','IntervalTwapBse',
                        'IntervalTwapLimitBse','DayTwapLimitBse','Pwp20Bse','Pwp20LimitBse',
                        'Pwp10Bse','Pwp10LimitBse',
                        'Pwp15Bse','Pwp15LimitBse',
                        'Pwp25Bse','Pwp25LimitBse',
                        'Pwp30Bse','Pwp30LimitBse',
                        'AvgTradeSizeBse','IntervalVolBse',
                        'IntervalVolLimitBse','DayVolBse','DayVolLimitBse','volExecBse_intervalVolBse','volExecBse_intervalVolLimitBse',
                        'volExecBse_DayVolBse', 'volExecBse_DayVolLimitBse','ArrivalPrice','Tag115']]
            result["SecurityExchange"]="BSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
            
    final_df=pd.DataFrame(pairlist)
    final_df.columns=['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                      'SecurityExchange','StartTime','EndTime','OrderQty','SOR','QuantityExecuted','ExecutedQty',
                      'AvgPx','Remarks','Algorithm','LastFillTime','ArrivalTime',
                      'IntervalVwap','IntervalVwapLimit','DayVwapLimit','DayVwap','DayTwap','IntervalTwap',
                      'IntervalTwapLimit','DayTwapLimit','Pwp20','Pwp20Limit',
                      'Pwp10','Pwp10Limit',
                      'Pwp15','Pwp15Limit',
                      'Pwp25','Pwp25Limit',
                      'Pwp30','Pwp30Limit',
                      'AvgTradeSize','IntervalVol',
                      'IntervalVolLimit','DayVol','DayVolLimit','volExec_intervalVol','volExec_intervalVolLimit',
                      'volExec_DayVol','volExec_DayVolLimit','ArrivalPrice','Tag115']
    
    '''create two dataframes one for summary calculation other to write in excel'''
        

    
    final_write=final_df[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                      'SecurityExchange','StartTime','EndTime','OrderQty','SOR','QuantityExecuted','ExecutedQty',
                      'AvgPx','Remarks','Algorithm','LastFillTime','ArrivalTime',
                      'IntervalVwap','IntervalVwapLimit','DayVwapLimit','DayVwap','DayTwap','IntervalTwap',
                      'IntervalTwapLimit','DayTwapLimit','Pwp20','Pwp20Limit',
                      'Pwp10','Pwp10Limit',
                      'Pwp15','Pwp15Limit',
                      'Pwp25','Pwp25Limit',
                      'Pwp30','Pwp30Limit','AvgTradeSize','IntervalVol',
                      'IntervalVolLimit','DayVol','DayVolLimit','volExec_intervalVol','volExec_intervalVolLimit',
                      'volExec_DayVol','volExec_DayVolLimit','ArrivalPrice','Tag115']]
    
    final_write.reset_index(drop=True,inplace=True)
    
    return final_write 

def get_combine_op(df):
    '''processing for Dayvwap and volumelimit and daylimit and dates done in this code'''
    df['Start Time'] = pd.to_datetime(df['StartTime'])
    df['Date'] = df['Start Time'].dt.date
    df['values'] = df['AvgPx']*df['QuantityExecuted']
    df['VWAPvalues'] = df['IntervalVwapLimit']*df['IntervalVolLimit']
    df['PWPvalues'] = df['Pwp20Limit']*df['IntervalVolLimit']
    df['pwp10values'] = df["Pwp10Limit"]*df['IntervalVolLimit']
    df['pwp15values'] = df["Pwp15Limit"]*df['IntervalVolLimit']
    df['pwp25values'] = df["Pwp25Limit"]*df['IntervalVolLimit']
    df['pwp30values'] = df["Pwp30Limit"]*df['IntervalVolLimit']
    df['TWAPvalues'] = df['IntervalTwapLimit']*df['IntervalVolLimit']

    df['uniquetdse'] = df['TradeId']+df['SecurityExchange']

    

    combined_group = df.groupby(['uniquetdse','Date'], as_index=False).agg({'DayVwap':'first','pwp30values':'sum','pwp25values':'sum','pwp15values':'sum','pwp10values':'sum','Ticker':'first','TradeId':'first','TWAPvalues':'sum','IntervalVol':'sum','IntervalVolLimit':'sum','PWPvalues':'sum','VWAPvalues':'sum','DayVwap':'first','QuantityExecuted':'sum','DayVol':'first','IntervalVolLimit':'sum','SecurityExchange':'first','ClientName':'first','Symbol':'first','Side':'first','ArrivalPrice':'first','values':'sum','StartTime':'first','LastFillTime':'last','Tag115':'first','OrdType':'first','Pwp10':'sum','Pwp15':'sum','Pwp20':'sum','Pwp25':'sum','Pwp30':'sum'})
    
    # print combined_group
    combined_group['wt_AvgPx'] = combined_group['values']/combined_group['QuantityExecuted']
    combined_group['wt_VWAP'] = combined_group['VWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_TWAP'] = combined_group['TWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_PWP'] = combined_group['PWPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_10PWP'] = combined_group['pwp10values']/combined_group['IntervalVolLimit']
    combined_group['wt_15PWP'] = combined_group['pwp15values']/combined_group['IntervalVolLimit']
    combined_group['wt_25PWP'] = combined_group['pwp25values']/combined_group['IntervalVolLimit']
    combined_group['wt_30PWP'] = combined_group['pwp30values']/combined_group['IntervalVolLimit']
    
    combined_group.fillna(0, inplace=True)
    combined_group.sort_values(by=['Date','Symbol','TradeId'], inplace=True)
#     combined_group.drop(['values', 'VWAPvalues', 'TWAPvalues', 'PWPvalues','DayVwapvalues'], axis=1, inplace=True)
    
    #calculating parameters
    combined_group['wtTWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_TWAP'])/combined_group['wt_TWAP'])*10000
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
    combined_group['wtPWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_PWP'])/combined_group['wt_PWP'])*10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice'])/combined_group['ArrivalPrice'])*10000
    combined_group['wtdayVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['DayVwap'])/combined_group['DayVwap'])*10000
    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)
    
    #buy side parameters
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtTWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtPWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtArrPx_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['DayVwap'] != 0), 'wtdayVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtdayVWAP_vs_AvgPx']
    
    #sell side parameters
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['DayVwap'] != 0), 'wtdayVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtdayVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtTWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtPWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtArrPx_vs_AvgPx']
    
    #difference
    combined_group['VWAP_Value_Difference'] = (combined_group['wtVWAP_vs_AvgPx']*combined_group['wt_VWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['TWAP_Value_Difference'] = (combined_group['wtTWAP_vs_AvgPx']*combined_group['wt_TWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP_Value_Difference'] = (combined_group['wtPWP_vs_AvgPx']*combined_group['wt_PWP']*combined_group['QuantityExecuted'])/10000
    combined_group['ArrPx_Value_Difference'] = (combined_group['wtArrPx_vs_AvgPx']*combined_group['ArrivalPrice']*combined_group['QuantityExecuted'])/10000
    combined_group['dayVWAP_Value_Difference'] = (combined_group['wtdayVWAP_vs_AvgPx']*combined_group['DayVwap']*combined_group['QuantityExecuted'])/10000
                      
    combined_group.reset_index(drop=True,inplace=True)
    combined_group["StartTime"]=pd.to_datetime(combined_group["StartTime"],format='%Y%m%d %H:%M:%S')
    combined_group["LastFillTime"]=pd.to_datetime(combined_group["LastFillTime"],format='%Y%m%d %H:%M:%S.%f')
    # new data frame with split value columns 
    combined_group["Starttime"]=combined_group["StartTime"].dt.time
    combined_group["LastFillTime"]=combined_group["LastFillTime"].dt.time
    combined_group["TradeDate"]=combined_group["StartTime"].dt.date
    combined_group[["Starttime","LastFillTime"]]=combined_group[["Starttime","LastFillTime"]].astype(str)
    combined_group['percent_day_vol']=combined_group["QuantityExecuted"]/combined_group["DayVol"]*100
    combined_group['percent_interval_vol']=combined_group["QuantityExecuted"]/combined_group["IntervalVolLimit"]*100
    
    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)
    combined_group.sort_values(by='Date',ascending=True, inplace=True)
#    combined_group.to_excel('comparecheck.xls',index=False)
    return combined_group

def final_output(df):
    '''function to get the final dataframe'''
    list1=["Security","Trade Date","Side","Order Type","Start - End Time","Shares","Total Value","Avg Trade Price","% from Interval VWAP","Interval VWAP Price","VWAP Value Difference","% from Arrival","Arrival Price","ArrPx Value Difference","% from Full Day VWAP","Full Day VWAP Price","DayVwap Value Difference","% of Day's Volume","% Interval Volume","% from PWP20","PWP20","PWP Value Difference","% from nearest PWP","PWP (rounded to nearest 5 of % Interval Vol)","Exchange","Tag115"]
    df_sample=pd.DataFrame(columns=list1)
    
    df_sample["Security"]=df["Ticker"]
    df_sample["Side"]=df["Side"]
    df_sample["Order Type"]=df["OrdType"]
    df_sample["Shares"]=df["QuantityExecuted"]
    df_sample["Total Value"]=df["QuantityExecuted"]*df["wt_AvgPx"]
    df_sample["Avg Trade Price"]=df["wt_AvgPx"]
    df_sample["Arrival Price"]=df["ArrivalPrice"]
    df_sample["Interval VWAP Price"]=df["wt_VWAP"]
    df_sample["Full Day VWAP Price"]=df["DayVwap"]
    df_sample["PWP20"]=df["wt_PWP"]
    
    try:
        df_sample["vwap_diff"]=((df_sample["Avg Trade Price"]-df_sample["Interval VWAP Price"])*df_sample["Shares"])    
        df_sample["arr_diff"]=((df_sample["Avg Trade Price"]-df_sample["Arrival Price"])*df_sample["Shares"])        
        df_sample["pwp_diff"]=((df_sample["Avg Trade Price"]-df_sample["PWP20"])*df_sample["Shares"])
        df_sample["day_diff"]=((df_sample["Avg Trade Price"]-df_sample["Full Day VWAP Price"])*df_sample["Shares"]) 
        
        vwap_diff=(df_sample["vwap_diff"].sum()/df_sample["Total Value"].sum())*100
        vwap_diff="{0:.4f}".format(vwap_diff)
        
        arr_diff=(df_sample["arr_diff"].sum()/df_sample["Total Value"].sum())*100
        arr_diff="{0:.4f}".format(arr_diff)
        
        pwp_diff=(df_sample["pwp_diff"].sum()/df_sample["Total Value"].sum())*100
        pwp_diff="{0:.4f}".format(pwp_diff)
        
        day_diff=(df_sample["day_diff"].sum()/df_sample["Total Value"].sum())*100
        day_diff="{0:.4f}".format(day_diff)
    except:
        print "divide by zero exception"
    
    df_sample["% of Day's Volume"]= df["percent_day_vol"]
    df_sample["% Interval Volume"]= df["percent_interval_vol"]
    
    df["LastFillTime"]=df["LastFillTime"].str.split('.',n=1,expand=True)[0]

    df_sample["Start - End Time"]=df["Starttime"]+'-'+df["LastFillTime"]
    df_sample["Trade Date"]=df["TradeDate"]
    
    
    df_sample["% from Interval VWAP"]=df["wtVWAP_vs_AvgPx"]#/100
    df_sample["% from Arrival"]=df["wtArrPx_vs_AvgPx"]#/100
    df_sample["% from PWP20"]=df["wtPWP_vs_AvgPx"]#/100
    df_sample["% from Full Day VWAP"]=df["wtdayVWAP_vs_AvgPx"]#/100
    
    df_sample=df_sample[["Security","Trade Date","Side","Order Type","Start - End Time","Shares","Total Value","Avg Trade Price","% from Interval VWAP","Interval VWAP Price","VWAP Value Difference","% from Arrival","Arrival Price","ArrPx Value Difference","% from Full Day VWAP","Full Day VWAP Price","DayVwap Value Difference","% of Day's Volume","% Interval Volume","% from PWP20","PWP20","PWP Value Difference","% from nearest PWP","PWP (rounded to nearest 5 of % Interval Vol)","Exchange","Tag115"]]
    df_sample['% from nearest PWP']=(df["wt_AvgPx"]-df["IVolpwp"])/(df["wt_AvgPx"])
    
    df_sample[['% from nearest PWP']]=df_sample[['% from nearest PWP']].round(4)
    df_sample["nearest_diff"]=((df_sample["Avg Trade Price"]-df["IVolpwp"])*df_sample["Shares"])
    nearest_diff=(df_sample["nearest_diff"].sum()/df_sample["Total Value"].sum())#*100
    nearest_diff="{0:.4f}".format(nearest_diff)
    
    shares_sum=df_sample["Shares"].sum()
    shares_sum="{0:.4f}".format(shares_sum)
    total_value_sum=df_sample["Total Value"].sum()
    total_value_sum="{0:,.4f}".format(total_value_sum)  
    total_value_sum='INR '+str(total_value_sum)
    
    df_sample["PWP20"]=df["wt_PWP"].map('{:,.4f}'.format)
    df_sample["Avg Trade Price"]=df["wt_AvgPx"].map('{:,.4f}'.format)
    df_sample["Arrival Price"]=df["ArrivalPrice"].map('{:,.2f}'.format)
    df_sample["Interval VWAP Price"]=df["wt_VWAP"].map('{:,.4f}'.format)
    df_sample["Full Day VWAP Price"]=df["DayVwap"].map('{:,.4f}'.format)
    df_sample["Total Value"]=df_sample["Total Value"].map('{:,.2f}'.format)
    
    df_sample[["Total Value","Arrival Price","Avg Trade Price","Interval VWAP Price","Full Day VWAP Price"]]=df_sample[["Total Value","Arrival Price","Avg Trade Price","Interval VWAP Price","Full Day VWAP Price"]].astype(str)
    
    df_sample["Total Value"]="INR"+" "+df_sample["Total Value"]
    df_sample["Avg Trade Price"]="INR"+" "+df_sample["Avg Trade Price"]
    df_sample["Arrival Price"]="INR"+" "+df_sample["Arrival Price"]
    df_sample["Interval VWAP Price"]="INR"+" "+df_sample["Interval VWAP Price"]
    df_sample["Full Day VWAP Price"]="INR"+" "+df_sample["Full Day VWAP Price"]
    df_sample["PWP20"]="INR"+" "+df_sample["PWP20"]
    
    df_sample['PWP (rounded to nearest 5 of % Interval Vol)']=df["IVol"]
    df_sample['Tag115']=df["Tag115"]
    df_sample['Exchange']=df["SecurityExchange"]
        
    df_sample[["% from Interval VWAP","% from Arrival","% from Full Day VWAP",
                "% of Day's Volume","% Interval Volume","% from PWP20","% from nearest PWP",
                "PWP (rounded to nearest 5 of % Interval Vol)"]]=df_sample[[
                "% from Interval VWAP","% from Arrival","% from Full Day VWAP",
                "% of Day's Volume","% Interval Volume","% from PWP20","% from nearest PWP",
                "PWP (rounded to nearest 5 of % Interval Vol)"]].round(4)    
    df_sample.to_excel(output_dir+'complete_output.xls',index=False)
    

    c1=df_sample[['% from Interval VWAP']].style.applymap(highlight_vals_c1,subset=['% from Interval VWAP']).set_properties(**{'border-color':'Black','text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'                                                                                  
                                            })
    c2=df_sample[['% from Full Day VWAP']].style.applymap(highlight_vals_c1,subset=['% from Full Day VWAP']).set_properties(**{'border-color':'Black','text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px',})
    c3=df_sample[['% from PWP20']].style.applymap(highlight_vals_c1,subset=['% from PWP20']).set_properties(**{'border-color':'Black','text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c4=df_sample[['% from Arrival']].style.applymap(highlight_vals_c1,subset=['% from Arrival']).set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'
                                            })
    
    c5=df_sample[["% of Day's Volume"]].style.applymap(color_r_g_b,subset=["% of Day's Volume"]).set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c6=df_sample[["% Interval Volume"]].style.applymap(color_r_g_b,subset=["% Interval Volume"]).set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c7=df_sample[['% from nearest PWP']].style.applymap(highlight_vals_c1,subset=['% from nearest PWP']).set_properties(**{
                                            'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c8=df_sample[["Total Value"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})

    c9=df_sample[["Avg Trade Price"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c10=df_sample[["Arrival Price"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c11=df_sample[["Interval VWAP Price"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c12=df_sample[["Full Day VWAP Price"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c13=df_sample[["PWP20"]].style.set_properties(**{'border-color':'Black',
                                            'text-align':'right',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    
    cfirst=df_sample[["Security","Trade Date","Side","Order Type","Start - End Time","Shares"]]
    cfirst=cfirst.style.set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    
    last=df_sample[["Exchange","Tag115"]]
    last=last.style.set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    pwprounded=df_sample[["PWP (rounded to nearest 5 of % Interval Vol)"]].style.set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    
    return cfirst,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,last,pwprounded,total_value_sum,vwap_diff,arr_diff,pwp_diff,day_diff,nearest_diff

  


def output_excel(cfirst,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,last,pwprounded,total_value_sum,vwap_diff,arr_diff,pwp_diff,day_diff,nearest_diff,c14,d,tag115):
    length1=len(c14["IVolpwp"])
    length1=length1+1
    c14["IVolpwp"]=c14["IVolpwp"].astype(str)
    c14["IVolpwp"]="INR"+' '+c14["IVolpwp"]
    c14=c14.style.set_properties(**{'border-color':'Black',
                                    'text-align':'right',
                                    'border-style':'solid',
                                    'border-width': '1px'})
    writer = pd.ExcelWriter(output_dir+'final_{}_{}.xlsx'.format(tag115,d.strftime('%Y%m%d')),engine='xlsxwriter')
    workbook=writer.book
    worksheet=workbook.add_worksheet('Result')
    
    cell_format = workbook.add_format({'bold': 1,
    'align': 'center',
    'valign': 'vcenter',
    'text_wrap':True,
    'color':'#000080'
    })
    cell_format.set_text_wrap()
    
    writer.sheets['Result'] = worksheet
    worksheet.set_column(0,22,20)
    worksheet.set_row(0,110)
    
    merge_format = workbook.add_format({
    'bold': 1,
    'align': 'center',
    'valign': 'vcenter',
    'text_wrap':True,
    'color':'#000080'
    })
    
    cell_format1 = workbook.add_format({'bold': 1,
    'align': 'center',
    'valign': 'vcenter',
    'text_wrap':True,
    'color':'#000080'})
    cell_format1.set_right(2)
    
    cell_format2 = workbook.add_format({
    'align': 'right',
    'valign': 'right',
    'text_wrap':True})
    
    
    
    
    
    
    worksheet.merge_range('A0:G0','  ',merge_format)
    worksheet.write(0,0,'Security',cell_format)
    worksheet.write(0,1,'Trade Date',cell_format)
    worksheet.write(0,2,'Side',cell_format)
    worksheet.write(0,3,'Order Type',cell_format)
    worksheet.write(0,4,'Start - End Time',cell_format)
    worksheet.write(0,5,'Shares',cell_format)
    worksheet.write(0,6,'Total Value',cell_format)
    worksheet.write(length1,6,total_value_sum,cell_format2)

    worksheet.write(0,7,'AvgTrade\nprice',cell_format1)
   
    worksheet.merge_range('I0:J0',' ',merge_format)
    worksheet.write(0,8,"% from\nInterval\nVWAP\n(in bps)",cell_format)
    worksheet.write(length1,8,vwap_diff,cell_format2)

    worksheet.write(0,9, "Interval\nVWAP Price",cell_format1)
    
    worksheet.merge_range('K0:L0',' ',merge_format)

    worksheet.write(0,10,"% from\nArrival\n(in bps)",cell_format)
    worksheet.write(length1,10,arr_diff,cell_format2)

    worksheet.write(0,11, "Arrival\nPrice",cell_format1)
    
    worksheet.merge_range('M0:N0',' ',merge_format)

    worksheet.write(0,12,"% from\nFull Day\nVWAP\n(in bps)",cell_format)
    worksheet.write(length1,12,day_diff,cell_format2)

    worksheet.write(0,13,"Full Day\nVWAP\nPrice",cell_format1)
    
    worksheet.merge_range('O0:P0',' ',merge_format)

    worksheet.write(0,14,"% of\nDay's\nVolume",cell_format)
    
    worksheet.write(0,15,"%\nInterval\nVolume",cell_format1)
    
    worksheet.merge_range('Q0:R0',' ',merge_format)

    worksheet.write(0,16,"% from\nPWP20\n(in bps)",cell_format)
    worksheet.write(length1,16,pwp_diff,cell_format2)

    worksheet.write(0,17,"PWP20",cell_format1)
    
    worksheet.merge_range('S0:T0',' ',merge_format)
    
    worksheet.write(0,18,"% from\nnearest\nPWP\n(in bps)",cell_format)
    worksheet.write(length1,18,nearest_diff,cell_format2)

    worksheet.write(0,19,"PWP",cell_format)
    
    worksheet.write(0,20,"PWP Percent",cell_format1)
    worksheet.write(0,21,"Exchange",cell_format1)
#    worksheet.write(0,22,"Tag115",cell_format1)
    worksheet.write(0,22,"Tag1",cell_format1)

    cfirst.to_excel(writer,sheet_name='Result',startrow=1,startcol=0,index=False,header=False)
    c8.to_excel(writer,sheet_name='Result',startrow=1,startcol=6,index=False,header=False)    
    c9.to_excel(writer,sheet_name='Result',startrow=1,startcol=7,index=False,header=False)    
    c1.to_excel(writer,sheet_name='Result',startrow=1,startcol=8,index=False,header=False) 
    c11.to_excel(writer,sheet_name='Result',startrow=1,startcol=9,index=False,header=False)    
    c4.to_excel(writer,sheet_name='Result',startrow=1,startcol=10,index=False,header=False)
    c10.to_excel(writer,sheet_name='Result',startrow=1,startcol=11,index=False,header=False)    
    c2.to_excel(writer,sheet_name='Result',startrow=1,startcol=12,index=False,header=False) 
    c12.to_excel(writer,sheet_name='Result',startrow=1,startcol=13,index=False,header=False)    
    c5.to_excel(writer,sheet_name='Result',startrow=1,startcol=14,index=False,header=False)       
    c6.to_excel(writer,sheet_name='Result',startrow=1,startcol=15,index=False,header=False)       
    c3.to_excel(writer,sheet_name='Result',startrow=1,startcol=16,index=False,header=False)  
    c13.to_excel(writer,sheet_name='Result',startrow=1,startcol=17,index=False,header=False)  
    c7.to_excel(writer,sheet_name='Result',startrow=1,startcol=18,index=False,header=False)
    c14.to_excel(writer,sheet_name='Result',startrow=1,startcol=19,index=False,header=False)
    pwprounded.to_excel(writer,sheet_name='Result',startrow=1,startcol=20,index=False,header=False)
    last.to_excel(writer,sheet_name='Result',startrow=1,startcol=21,index=False,header=False)
    writer.save()
    writer.close()
    
def gen_monthly_report(d,d1,tag115):

    print "date",d
    
    psql_df=get_postgress_data(d,d1)
    
    psql_df.columns=["TradeId","ClientOrdID","Og_ClientOrdID","ClientName","Symbol","Series","Ticker","OrdType",
                 "LimitPrice","Side","SecurityExchange","StartTime","EndTime","OrderQty",
                 "SOR","QuantityExecuted","AvgPx","NSEExecutedQty","BSEExecutedQty","NSEExecutedAvg","BSEExecutedAvg",
                 "Remarks","Algorithm","LastFillTime","ArrivalTime","Tag115","IntervalVwap","IntervalVwapNse",
                 "IntervalVwapBse","IntervalVwapLimit","AvgPx_vs_IntervalVwapLimit","IntervalVwapLimitNse",
                 "IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap",
                 "DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse",
                 "IntervalTwapBse","IntervalTwapLimit","AvgPx_vs_IntervalTwapLimit","IntervalTwapLimitNse",
                 "IntervalTwapLimitBse","DayTwapLimit","DayTwapLimitNse","DayTwapLimitBse","AvgPx_vs_IntervalVwap",
                 "AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit","AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","AvgPx_vs_DayTwapLimit",
                 "AvgPx_vs_Pwp","Pwp20Nse","Pwp20Bse","Pwp20","Pwp20Limit","AvgPx_vs_PwpLimit","Pwp20LimitNse",
                 "Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse",
                 "IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse",
                 "DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse","volExecBse_intervalVolBse",
                 "volExec_vs_IntervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse",
                 "volExec_vs_IntervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse",
                 "volExec_vs_DayVol","volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_vs_DayVolLimit",
                 "ArrivalPriceNse","ArrivalPriceBse","ArrivalPrice","AvgPx_vs_ArrivalPx","Pwp10Nse","Pwp10Bse","Pwp10",
                 "Pwp10Limit","Pwp10LimitNse","Pwp10LimitBse","Pwp15Nse","Pwp15Bse","Pwp15","Pwp15Limit","Pwp15LimitNse",
                 "Pwp15LimitBse","Pwp25Nse","Pwp25Bse","Pwp25","Pwp25Limit","Pwp25LimitNse","Pwp25LimitBse",
                 "Pwp30Nse","Pwp30Bse","Pwp30","Pwp30Limit","Pwp30LimitNse","Pwp30LimitBse","unique_id","date"]
    
    final_list=[]
    for i in range(0,len(tag115)):
        final_list.append(psql_df.loc[psql_df["Tag115"].isin([tag115[i]])])
    
    final_list.append(psql_df.loc[psql_df["Tag115"].isin(["FRANKTEMPAW"])])
        
    final_df=pd.concat(final_list)
    #final_df=psql_df.loc[psql_df["Tag115"].isin(['{}'.format(tag115)])]
    final_df=psql_df.loc[psql_df["Tag115"].isin(["FRANKLINTRT","FRANKTEMPAW"])]
    
    final_write=get_tca_split(final_df)
    df=get_combine_op(final_write)
    
    
    df["IVol"]='0'
    df["IVolpwp"]='0'
      
    for i in range(0,len(df)):
        if df["percent_interval_vol"][i]<=10:
            df["IVol"][i]=10
            df["IVolpwp"][i]=df["Pwp10"][i]
        elif df["percent_interval_vol"][i] < 12.5:
            df["IVol"][i]=10
            df["IVolpwp"][i]=df["Pwp10"][i]
        elif df["percent_interval_vol"][i] >= 12.5 and df["IntervalVol"][i]<=15:
            df["IVol"][i]=15
            df["IVolpwp"][i]=df["Pwp15"][i]
        elif df["percent_interval_vol"][i] < 17.5:
            df["IVol"][i]=15
            df["IVolpwp"][i]=df["Pwp15"][i]
        elif df["percent_interval_vol"][i] >=17.5 and df["percent_interval_vol"][i]<=20:
            df["IVol"][i]=20
            df["IVolpwp"][i]=df["Pwp20"][i]
        elif df["percent_interval_vol"][i] <22.5:
            df["IVol"][i]=20
            df["IVolpwp"][i]=df["Pwp20"][i]
        elif df["percent_interval_vol"][i] >=22.5 and df["percent_interval_vol"][i]<=25:
            df["IVol"][i]=25
            df["IVolpwp"][i]=df["Pwp25"][i]
        elif df["percent_interval_vol"][i]<27.5:
            df["IVol"][i]=25
            df["IVolpwp"][i]=df["Pwp25"][i]
        elif df["percent_interval_vol"][i]>=27.5 and df["percent_interval_vol"][i]<=30:
            df["IVol"][i]=30
            df["IVolpwp"][i]=df["Pwp30"][i]
        else:
            df["IVol"][i]=30
            df["IVolpwp"][i]=df["Pwp30"][i]
    
    df[["IVolpwp"]]=df[["IVolpwp"]].astype(float).round(4)
    df= df[df['QuantityExecuted']!=0]

    ivol=pd.DataFrame(df["IVolpwp"])
#    print "ivol",ivol
    cfirst,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,last,pwprounded,total_value_sum,vwap_diff,arr_diff,pwp_diff,day_diff,nearest_diff=final_output(df)
    output_excel(cfirst,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,last,pwprounded,total_value_sum,vwap_diff,arr_diff,pwp_diff,day_diff,nearest_diff,ivol,d,tag115)
    
    

    
d=datetime.datetime.now().date()
d1=datetime.date(2019,12,1)
tag115list=["FRANKLINTRT"]#,"B"],["CLIENT1"]
for i in range(0,len(tag115list)):
    gen_monthly_report(d,d1,tag115list[i])