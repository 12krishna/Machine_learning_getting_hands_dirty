import pandas as pd
import datetime,time,re,os,logging
import os ; os.chdir("D:\devansh_new")
from tcasplit import  split_report_main
from tcasampleclientwise import sample_report_main
#import order_generation_split1,order_generation_split2,TCA_17_9,dumpinpostgress,tcasplit,tcasamplefinal

master_dir = "D:\\Master\\"

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1
    
def previous_working_day(d):
    '''Get previous wokring day'''
    
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                #print "Holiday : ",d
                d = d - datetime.timedelta(days=1)                
            else:
                return d    

def main():
    d=datetime.datetime.now().date()#todays date
    #tag115list=["KMAMCALG","FRANKLINTRT"] #tag115 list
    d1 = d

    if process_run_check(d) == -1:
        return -1    
    d=previous_working_day(d)
    d1=previous_working_day(d1)
   
    print "date",d,d1
    split_report_main(d)
    #dump_in_postgres(d.strftime('%Y%m%d'))
    sample_report_main(d,d1)
    #gen_monthly_report(d,d1,tag115list)
    
main()