import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import datetime,psycopg2,logging

outputdir='D:\\FIXLogParser\\ETS_TCA\\ETS_Output\\'


def highlight_vals_c2(row, cols):
    a1,a2= cols
    styles = {col: '' for col in row.index}
    
    if row[a1] > 0 and row[a2]:
    
        styles[a1] = 'color: %s' % '#008000'
        styles[a2] = 'color: %s' % '#008000'
        
    else:
        
        styles[a1] = 'color: %s' % '#FF0000'
        styles[a2] = 'color: %s' % '#FF0000'
        
    return styles

def highlight_vals_c1(val):
    if val < 0:
        color='#FF0000'
    else:
        color='#008000'
    
    return 'color: %s' % color

def color_r_g_b(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    if val > 25:
        color = '#FF0000' #red
    elif val>=20 and val<=25:
        color='blue' 
    else:
        color='#008000' #green 
    return 'color: %s' % color

def get_postgress_data(d):
    #get latest date from database
    conn = psycopg2.connect(database="NSE-FNO",
                            user="postgres",
                             password="kotak@123", 
                             host="172.17.9.182", 
                             port="5432")
    cur=conn.cursor()
    cur.execute("select * from tca_split where date ='{}';".format(d)) 
    df = cur.fetchall()
    df = pd.DataFrame(df)
    logging.info("error in connection")
    return df

def get_combine_op(df):
    '''processing for Dayvwap and volumelimit and daylimit and dates done in this code'''
    df['Start Time'] = pd.to_datetime(df['StartTime'])
    df['Date'] = df['Start Time']
    df['values'] = df['AvgPx']*df['QuantityExecuted']
    df['VWAPvalues'] = df['IntervalVwapLimit']*df['IntervalVolLimit']
    df['PWPvalues'] = df['Pwp20Limit']*df['IntervalVolLimit']
    df['TWAPvalues'] = df['IntervalTwapLimit']*df['IntervalVolLimit']
    df['DayVwapvalues'] = df['DayVwapLimit']*df['DayVolLimit']
    df['percent_day_vol']=df["QuantityExecuted"]/df["DayVolLimit"]
    df['percent_interval_vol']=df["QuantityExecuted"]/df["IntervalVolLimit"]
    df = df[df['QuantityExecuted']!=0]

#     combined_group = df.groupby('unique_id', as_index=False).agg({'IntervalVolLimit':'sum','PWPvalues':'sum','VWAPvalues':'sum','DayVwapvalues':'sum','QuantityExecuted':'sum','percent_day_vol':'sum','percent_interval_vol':'sum','TradeId':'first','SecurityExchange':'first','Date':'first','ClientName':'first','Symbol':'first','Side':'first','ArrivalPrice':'first','values':'sum','StartTime':'first','EndTime':'first'})
    combined_group = df.groupby('TradeId', as_index=False).agg({'IntervalVolLimit':'sum','TWAPvalues':'sum','PWPvalues':'sum','VWAPvalues':'sum','DayVwapvalues':'sum','QuantityExecuted':'sum','percent_day_vol':'sum','percent_interval_vol':'sum','SecurityExchange':'first','Date':'first','ClientName':'first','Symbol':'first','Side':'first','ArrivalPrice':'first','values':'sum','StartTime':'first','EndTime':'first','Tag115':'first'})#'TradeId':'first'

    # print combined_group
    combined_group['wt_AvgPx'] = combined_group['values']/combined_group['QuantityExecuted']
    combined_group['wt_VWAP'] = combined_group['VWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_TWAP'] = combined_group['TWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_dayvwap'] = combined_group['DayVwapvalues']/combined_group['QuantityExecuted']
    combined_group['wt_PWP'] = combined_group['PWPvalues']/combined_group['IntervalVolLimit']
    
    combined_group.fillna(0, inplace=True)
    combined_group.sort_values(by='Date', inplace=True)
    combined_group.drop(['values', 'VWAPvalues', 'TWAPvalues', 'PWPvalues'], axis=1, inplace=True)
    
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
    combined_group['wtTWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_TWAP'])/combined_group['wt_TWAP'])*10000
    combined_group['wtPWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_PWP'])/combined_group['wt_PWP'])*10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice'])/combined_group['ArrivalPrice'])*10000
    combined_group.fillna(0, inplace=True)
    combined_group.sort_values(by='Date', inplace=True)
    
    #calculating parameters
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
    combined_group['wtPWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_PWP'])/combined_group['wt_PWP'])*10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice'])/combined_group['ArrivalPrice'])*10000
    combined_group['wtdayVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_dayvwap'])/combined_group['wt_dayvwap'])*10000
    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)
    
    #buy side parameters
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtTWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtPWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtArrPx_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_dayvwap'] != 0), 'wtdayVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtdayVWAP_vs_AvgPx']
    
    #sell side parameters
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_dayvwap'] != 0), 'wtdayVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtdayVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtTWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtPWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtArrPx_vs_AvgPx']
    
    #difference
    combined_group['VWAP_Value_Difference'] = (combined_group['wtVWAP_vs_AvgPx']*combined_group['wt_VWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['TWAP_Value_Difference'] = (combined_group['wtTWAP_vs_AvgPx']*combined_group['wt_TWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP_Value_Difference'] = (combined_group['wtPWP_vs_AvgPx']*combined_group['wt_PWP']*combined_group['QuantityExecuted'])/10000
    combined_group['ArrPx_Value_Difference'] = (combined_group['wtArrPx_vs_AvgPx']*combined_group['ArrivalPrice']*combined_group['QuantityExecuted'])/10000
    combined_group['dayVWAP_Value_Difference'] = (combined_group['wtdayVWAP_vs_AvgPx']*combined_group['wt_dayvwap']*combined_group['QuantityExecuted'])/10000

    combined_group[['wtArrPx_vs_AvgPx','wtPWP_vs_AvgPx','wtVWAP_vs_AvgPx','ArrPx_Value_Difference',
                    'PWP_Value_Difference','VWAP_Value_Difference','wtdayVWAP_vs_AvgPx',
                    'dayVWAP_Value_Difference','wt_dayvwap','percent_day_vol','percent_interval_vol',
                    'ArrivalPrice','wt_AvgPx','wt_VWAP','wt_PWP','wtArrPx_vs_AvgPx',
                    'wt_TWAP','wtTWAP_vs_AvgPx','TWAP_Value_Difference']]=combined_group[['wtArrPx_vs_AvgPx','wtPWP_vs_AvgPx','wtVWAP_vs_AvgPx','ArrPx_Value_Difference',
                    'PWP_Value_Difference','VWAP_Value_Difference','wtdayVWAP_vs_AvgPx',
                    'dayVWAP_Value_Difference','wt_dayvwap','percent_day_vol','percent_interval_vol',
                    'ArrivalPrice','wt_AvgPx','wt_VWAP','wt_PWP','wtArrPx_vs_AvgPx',
                    'wt_TWAP','wtTWAP_vs_AvgPx','TWAP_Value_Difference']].astype(float).round(2)
    
          
    combined_group.reset_index(drop=True,inplace=True)
    combined_group["StartTime"]=pd.to_datetime(combined_group["StartTime"])
    combined_group["EndTime"]=pd.to_datetime(combined_group["EndTime"])
    combined_group["Starttime"]=combined_group["StartTime"].dt.time
    combined_group["Endtime"]=combined_group["EndTime"].dt.time
    combined_group["TradeDate"]=combined_group["StartTime"].dt.date
    combined_group[["Starttime","Endtime"]]=combined_group[["Starttime","Endtime"]].astype(str)
    
    return combined_group

def final_output(df):
    '''function to get the final dataframe'''
    df_sample=pd.DataFrame(columns=["Security","Trade Date","Side","Order Type","Start - End Time","Shares","Total Value","Avg Trade Price","% from Interval VWAP","Interval VWAP Price","VWAP Value Difference","% from Arrival","Arrival Price","ArrPx Value Difference","% from Full Day VWAP","Full Day VWAP Price","DayVwap Value Difference","% of Day's Volume","% Interval Volume","% from PWP20","PWP20","PWP Value Difference","% from nearest PWP","PWP (rounded to nearest 5 of % Interval Vol)","Exchange","Tag1"])
    df_sample["Security"]=df["Symbol"]
    df_sample["Side"]=df["Side"]
    df_sample["Order Type"]="Limit"
    df_sample["Shares"]=df["QuantityExecuted"]
    df_sample["Total Value"]=df["QuantityExecuted"]*df["wt_AvgPx"]
    df_sample["Avg Trade Price"]=df["wt_AvgPx"]
    df_sample["Arrival Price"]=df["ArrivalPrice"]
    df_sample["Interval VWAP Price"]=df["wt_VWAP"]
    df_sample["Full Day VWAP Price"]=df["wt_dayvwap"]
    df_sample["PWP20"]=df["wt_PWP"]
    df_sample["VWAP Value Difference"]=df["VWAP_Value_Difference"]
    df_sample["ArrPx Value Difference"]=df["ArrPx_Value_Difference"]
    df_sample["PWP Value Difference"]=df["PWP_Value_Difference"]
    df_sample["DayVwap Value Difference"]=df["dayVWAP_Value_Difference"]
    df_sample["% of Day's Volume"]=df["percent_day_vol"]
    df_sample["% Interval Volume"]=df["percent_interval_vol"]
    df_sample["Start - End Time"]=df["Starttime"]+'-'+df["Endtime"]
    df_sample["Trade Date"]=df["TradeDate"]
    
    df_sample["% from Interval VWAP"]=df["wtdayVWAP_vs_AvgPx"]
    df_sample["% from Arrival"]=df["wtArrPx_vs_AvgPx"]
    df_sample["% from PWP20"]=df["wtPWP_vs_AvgPx"]
    df_sample["% from Full Day VWAP"]=df["wtdayVWAP_vs_AvgPx"]
    df_sample=df_sample[["Security","Trade Date","Side","Order Type","Start - End Time","Shares","Total Value","Avg Trade Price","% from Interval VWAP","Interval VWAP Price","VWAP Value Difference","% from Arrival","Arrival Price","ArrPx Value Difference","% from Full Day VWAP","Full Day VWAP Price","DayVwap Value Difference","% of Day's Volume","% Interval Volume","% from PWP20","PWP20","PWP Value Difference","% from nearest PWP","PWP (rounded to nearest 5 of % Interval Vol)","Exchange","Tag1"]]
    df_sample['% from nearest PWP']=0 #add here
    df_sample['PWP (rounded to nearest 5 of % Interval Vol)']=0 #add here
    df_sample['Tag1']=df["Tag115"]
    df_sample['Exchange']=df["SecurityExchange"]
    df_sample.drop(columns=['VWAP Value Difference','ArrPx Value Difference','DayVwap Value Difference','PWP Value Difference'],axis=1,inplace=True)
    df_sample[["Avg Trade Price","% from Interval VWAP","Interval VWAP Price","% from Arrival","Arrival Price","% from Full Day VWAP","Full Day VWAP Price","% of Day's Volume","% Interval Volume","% from PWP20","PWP20","% from nearest PWP","PWP (rounded to nearest 5 of % Interval Vol)","Exchange","Tag1"]]=df_sample[["Avg Trade Price","% from Interval VWAP","Interval VWAP Price","% from Arrival","Arrival Price","% from Full Day VWAP","Full Day VWAP Price","% of Day's Volume","% Interval Volume","% from PWP20","PWP20","% from nearest PWP","PWP (rounded to nearest 5 of % Interval Vol)","Exchange","Tag1"]].round(2)

    c1=df_sample[['% from Interval VWAP']].style.applymap(highlight_vals_c1,subset=['% from Interval VWAP']).set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px'})
    c2=df_sample[['% from Full Day VWAP']].style.applymap(highlight_vals_c1,subset=['% from Full Day VWAP']).set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px',})
    c3=df_sample[['% from PWP20']].style.applymap(highlight_vals_c1,subset=['% from PWP20']).set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px',})
    c4=df_sample[['% from Arrival']].style.applymap(highlight_vals_c1,subset=['% from Arrival']).set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px',})

    df_sample["% of Day's Volume"]=df_sample["% of Day's Volume"]*100
    df_sample["% Interval Volume"]=df_sample["% Interval Volume"]*100
    c5=df_sample[["% of Day's Volume"]].style.applymap(color_r_g_b,subset=["% of Day's Volume"]).set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px',})
    c6=df_sample[["% Interval Volume"]].style.applymap(color_r_g_b,subset=["% Interval Volume"]).set_properties(**{'border':1})
    c7=df_sample[['% from nearest PWP','PWP (rounded to nearest 5 of % Interval Vol)']].style.apply(lambda x: highlight_vals_c2(x, cols=['% from nearest PWP','PWP (rounded to nearest 5 of % Interval Vol)']), axis=1).set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px',})
    df_sample=df_sample.style.set_properties(**{'border-color':'Black',
                                            'border-style':'solid',
                                            'border-width': '1px',})

    return df_sample,c1,c2,c3,c4,c5,c6,c7

def output_excel(df_sample,c1,c2,c3,c4,c5,c6,c7,d):
    
    writer = pd.ExcelWriter(outputdir + 'final_{}.xlsx'.format(d.strftime('%Y%m%d')),engine='xlsxwriter')
    workbook=writer.book
    worksheet=workbook.add_worksheet('Result')
    cell_format = workbook.add_format({'bold': 1,
    'border': 1,
    'align': 'center',
    'valign': 'vcenter',
    'text_wrap':True,
    'color':'#000080'})
    cell_format.set_text_wrap()
    
    writer.sheets['Result'] = worksheet
    worksheet.set_column(0,22,15)
    worksheet.set_row(0,110)
    worksheet.write(0,0,'Security',cell_format)
    worksheet.write(0,1,'Trade Date',cell_format)
    worksheet.write(0,2,'Side',cell_format)
    worksheet.write(0,3,'Order Type',cell_format)
    worksheet.write(0,4,'Start - End Time',cell_format)
    worksheet.write(0,5,'Shares',cell_format)
    worksheet.write(0,6,'Total Value',cell_format)
    worksheet.write(0,7,'AvgTrade\nprice',cell_format)
    worksheet.write(0,8,"% from\nInterval\nVWAP",cell_format)
    worksheet.write(0,9, "Interval\nVWAP Price",cell_format)
    worksheet.write(0,10,"% from\nArrival",cell_format)
    worksheet.write(0,11, "Arrival\nPrice",cell_format)
    worksheet.write(0,12,"% from\nFull Day\nVWAP",cell_format)
    worksheet.write(0,13,"Full Day\nVWAP\nPrice",cell_format)
    worksheet.write(0,14,"% of\nDay's\nVolume",cell_format)
    worksheet.write(0,15,"%\nInterval\nVolume",cell_format)
    worksheet.write(0,16,"% from\nPWP20",cell_format)
    worksheet.write(0,17,"PWP20",cell_format)
    worksheet.write(0,18,"% from\nnearest\nPWP",cell_format)
    worksheet.write(0,19,"PWP:\n(rounded\nto\nnearest 5\nof%\nInterval\nVol",cell_format)
    worksheet.write(0,20,"Exchange",cell_format)
    worksheet.write(0,21,"Tag1",cell_format)

    df_sample.to_excel(writer,sheet_name='Result',startrow=1,startcol=0,index=False,header=False)    
    c1.to_excel(writer,sheet_name='Result',startrow=1,startcol=8,index=False,header=False)       
    c4.to_excel(writer,sheet_name='Result',startrow=1,startcol=10,index=False,header=False)       
    c2.to_excel(writer,sheet_name='Result',startrow=1,startcol=12,index=False,header=False)       
    c5.to_excel(writer,sheet_name='Result',startrow=1,startcol=14,index=False,header=False)       
    c6.to_excel(writer,sheet_name='Result',startrow=1,startcol=15,index=False,header=False)       
    c3.to_excel(writer,sheet_name='Result',startrow=1,startcol=16,index=False,header=False)       
    c7.to_excel(writer,sheet_name='Result',startrow=1,startcol=18,index=False,header=False)
    
    writer.save()
    writer.close()
    
def gen_monthly_report(d):
#    d=datetime.datetime.now().date()-datetime.timedelta(days=2)
    psql_df=get_postgress_data(d)
    psql_df.columns=["TradeId","ClientOrdID","Og_ClientOrdID","ClientName","Symbol","Series","Ticker","OrdType",
                 "LimitPrice","Side","SecurityExchange","StartTime","EndTime","OrderQty",
                 "SOR","QuantityExecuted","AvgPx","NSEExecutedQty","BSEExecutedQty","NSEExecutedAvg","BSEExecutedAvg",
                 "Remarks","Algorithm","LastFillTime","ArrivalTime","Tag115","IntervalVwap","IntervalVwapNse",
                 "IntervalVwapBse","IntervalVwapLimit","AvgPx_vs_IntervalVwapLimit","IntervalVwapLimitNse",
                 "IntervalVwapLimitBse","DayVwapLimitNse","DayVwapLimitBse","DayVwapLimit","DayVwap",
                 "DayVwapNse","DayVwapBse","DayTwap","DayTwapNse","DayTwapBse","IntervalTwap","IntervalTwapNse",
                 "IntervalTwapBse","IntervalTwapLimit","AvgPx_vs_IntervalTwapLimit","IntervalTwapLimitNse",
                 "IntervalTwapLimitBse","DayTwapLimit","DayTwapLimitNse","DayTwapLimitBse","AvgPx_vs_IntervalVwap",
                 "AvgPx_vs_DayVwap","AvgPx_vs_DayVwapLimit","AvgPx_vs_IntervalTwap","AvgPx_vs_DayTwap","AvgPx_vs_DayTwapLimit",
                 "AvgPx_vs_Pwp","Pwp20Nse","Pwp20Bse","Pwp20","Pwp20Limit","AvgPx_vs_PwpLimit","Pwp20LimitNse",
                 "Pwp20LimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse",
                 "IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse",
                 "DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse","volExecBse_intervalVolBse",
                 "volExec_vs_IntervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse",
                 "volExec_vs_IntervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse",
                 "volExec_vs_DayVol","volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_vs_DayVolLimit",
                 "ArrivalPriceNse","ArrivalPriceBse","ArrivalPrice","AvgPx_vs_ArrivalPx","Pwp10Nse","Pwp10Bse","Pwp10",
                 "Pwp10Limit","Pwp10LimitNse","Pwp10LimitBse","Pwp15Nse","Pwp15Bse","Pwp15","Pwp15Limit","Pwp15LimitNse",
                 "Pwp15LimitBse","Pwp25Nse","Pwp25Bse","Pwp25","Pwp25Limit","Pwp25LimitNse","Pwp25LimitBse",
                 "Pwp30Nse","Pwp30Bse","Pwp30","Pwp30Limit","Pwp30LimitNse","Pwp30LimitBse","unique_id","date"]
    df=get_combine_op(psql_df)
    df_sample,c1,c2,c3,c4,c5,c6,c7=final_output(df)
    output_excel(df_sample,c1,c2,c3,c4,c5,c6,c7,d)
#main()

