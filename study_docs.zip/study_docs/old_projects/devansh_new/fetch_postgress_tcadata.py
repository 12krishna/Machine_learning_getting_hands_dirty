# -*- coding: utf-8 -*-
"""
Created on Thu Jan 13 17:27:49 2022

@author: Administrator
"""


import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import datetime,psycopg2,logging,calendar, shutil, time
import warnings
warnings.filterwarnings("ignore")


def get_postgress_data(d,d1):
    #get latest date from database
    df = pd.DataFrame()
    while True:        
        conn = psycopg2.connect(database="NSE-FNO",
                                user="postgres",
                                 password="kotak@123", 
                                 host="172.17.9.182", 
                                 port="5432")
        df = pd.read_sql("select * from tca_split where date>='2020-01-01' and date <='2022-01-12';".format(d1,d), conn) #d current date ,d1 previous date
        if len(df)!=0:
            break
        print "Data not present for {} in tca split postgres db; sleep for 30 sec".format(d)
        time.sleep(30)
        
    return df

df = get_postgress_data('2020-01-01','2022-01-12')
df.to_excel("tca_data.xlsx", index=False)