    # -*- coding: utf-8 -*-
"""
Created on Fri Jan 10 17:12:32 2019

@author: krishna
"""
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
from time import time
#from cassandra.cluster import Cluster
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import logging

server = '172.17.9.149'; port = 25
MY_ADDRESS = 'MissingSymbolsTCA@kotak.com'


inputpath = '/home/hadoop/tca_project/temp_files/'
outpath = '/home/hadoop/tca_project/order_files/'
contacts_dir="/home/hadoop/tca_project/"
log_path = "/home/hadoop/tca_project/tca_logs/"
bloom_req_file="/LogReports/Vwap/"

#inputpath='D:\\devansh_new\\TCA_linux_codes\\UL_DATA\\'
#outpath='D:\\devansh_new\\TCA_linux_codes\\UL_DATA\\'
#contacts_dir="D:\\devansh_new\\TCA_linux_codes\\"


logging.basicConfig(filename=log_path+"test_{}.log".format(datetime.now().date()),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

'''
def getData(session,exchange,symbol,order_date):
    #print session, exchange, symbol, order_date
    query='SELECT * FROM quotedata WHERE token(exchange,date)=token(\'{1}\',\'{2}\') and symbol=\'{0}\' ALLOW FILTERING;'.format(symbol,exchange,order_date)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    return(rows)

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)



cluster = Cluster(['172.17.9.51'])
logging.info('Cassandra Cluster connected...')
session = cluster.connect('rohit')
#connect to your keyspace and create a session using which u can execute cql commands 
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None
'''

#Check if month has changed and if so rewrite the monthly data file


todays_date = date.today()
current_month = todays_date.month

filetime = datetime.fromtimestamp(os.path.getctime(bloom_req_file+'monthly.req'))
file_month = filetime.month
if current_month != file_month:
    open(bloom_req_file+'monthly.req', 'w').close()
else:
    pass


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    msg['Cc']=','.join(kwargs['emails'][1])
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'attachments' in kwargs.keys():
        for attachment in kwargs['attachments']:            
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(attachment, "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(attachment.split("\\")[-1] ))
            msg.attach(part) 

    # read message text or html files to be appeneded in email body 
    if 'html_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['html_email'],'rb').read()
        msg.attach(MIMEText(message, 'html'))
    
    if 'text_email' in kwargs.keys():
        # read html message file
        message = kwargs['text_email']
        msg.attach(MIMEText(message, 'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

# process_email(emails=, subject=, attachments= [], html_email=, text_email=  )

def alert_missing_symbols(order_df):
    # check for symbols dumped in cassandra or not ; and send alert email 
    # read bloomberg req file in order to find missing tickers
    bloom_codes=pd.read_csv(bloom_req_file+'getquotes_vwap_daily.req', header=None)
    logging.info("Successfully read getquotes req file from bloomberg data request ")   
    
    bloom_codes=bloom_codes.iloc[bloom_codes.index[bloom_codes[0]=='START-OF-DATA'][0]+1:bloom_codes.index[bloom_codes[0]=='END-OF-DATA'][0],:]
    
    missing_data=pd.DataFrame()
    for ticker in order_df['Ticker'].unique():  
        d = pd.to_datetime(order_df[order_df['Ticker']==ticker]['StartTime'].values[0]).date()
        if len( bloom_codes[bloom_codes[0]==ticker+" IS Equity"] ) == 0:
            print "Data missing for {} {} {}".format(ticker, d, "IS")
            tag115 = ', '.join(list(order_df[order_df['Ticker']==ticker]['Tag115'].unique()))
            temp = order_df[order_df['Ticker']==ticker]
            temp = temp.groupby(['Ticker'], as_index=False).agg({ 'OrderQty':'last','NSEExecutedQty':'sum',
                               'BSEExecutedQty':'sum'} )
            temp['Exchange']='NSE'; temp['Series']='IS'; temp['Date']=d; temp['Tag115']=tag115
            missing_data = missing_data.append(temp)
            
            
        if len( bloom_codes[bloom_codes[0]==ticker+" IB Equity"] ) == 0:
            print "Data missing for {} {} {}".format(ticker, d, "IB")
            tag115 = ', '.join(list(order_df[order_df['Ticker']==ticker]['Tag115'].unique()))
            temp = order_df[order_df['Ticker']==ticker]
            temp = temp.groupby(['Ticker'], as_index=False).agg({ 'OrderQty':'last','NSEExecutedQty':'sum',
                               'BSEExecutedQty':'sum'} )
            temp['Exchange']='BSE'; temp['Series']='IB'; temp['Date']=d; temp['Tag115']=tag115
            missing_data = missing_data.append(temp)
    
                   
    missing_data=missing_data[['Ticker','Date','Exchange','Series','OrderQty','NSEExecutedQty','BSEExecutedQty','Tag115']]   

    missing_data = missing_data[((missing_data['Series']=='IB')&(missing_data['BSEExecutedQty']!=0))|((missing_data['Series']=='IS')&(missing_data['NSEExecutedQty']!=0)) ]

                 
    
    with open(contacts_dir+"message.txt", "wb") as file:
        file.write(missing_data.to_html())
                

    # dropping passed columns 
    missing_data.drop(['Date','Exchange','OrderQty','NSEExecutedQty','BSEExecutedQty','Tag115'], axis = 1, inplace = True)
    missing_data = missing_data.assign(Name='Equity')
    missing_data.to_csv(bloom_req_file+'file2.csv', header=False, index=False)
    
    # Count total number of symbols before update              
    with open(bloom_req_file+'getquotes_vwap_daily.req', 'r') as f:
       textfile_temp = f.read()
       total_count1 = textfile_temp.split('START-OF-DATA')[1].split("END-OF-DATA")[0]
       old_length = total_count1.count('\n') - 1
       print("old length", old_length)
       data2 = textfile_temp.rsplit("\n", 2)[0]
       
       
    # Collecting today's count in data1            
    fin = open(bloom_req_file+'file2.csv', "r")
    data1 = fin.read()
    data1 = data1.replace(",", " ")  
    #adding it to monthly sheet
    f = open(bloom_req_file+'monthly.req', "a")
    f.write(data1)
    f.close()
    time.sleep(5)
    #counting monthly sheet count
    monthly_count = open(bloom_req_file+'monthly.req').read().count('\n')
    print("monthly_count",monthly_count)
    f.close()
    #adding EOD/EOF to data1
    data1 += "END-OF-DATA\nEND-OF-FILE"
    data1="\n" + data1
    fin.close()

    #combining old symbols with newly added in a string
    combined_data = data2 + data1
    
    
    total_count2 = combined_data.split('START-OF-DATA')[1].split("END-OF-DATA")[0]
    new_length = total_count2.count('\n') - 1
    print("new_length", new_length)

    today_length = new_length - old_length
    print("today_length",today_length)

    
    
    if len(missing_data)>0 and monthly_count <= 100:
        
        # writing updated symbols with old one to file 
        fout = open(bloom_req_file+'getquotes_vwap_daily.req', "w")
        fout.write(combined_data)
        fout.close()
        
        
        #Mail content when missing symbols found
        file_object = open(contacts_dir+"message.txt", 'a')
        file_object.write("Ticker old count in Bloomberg request file was {} ,new count is {} and {} new tickers were addede to the file".format(old_length,new_length,today_length))
        file_object.close()
        
        
        emails = get_contacts(contacts_dir+"tca_missing_symbol_alert_contacts.txt")
        process_email(emails=emails, subject="Missing symbols TCA {}".format(datetime.now().date()),
                      html_email= contacts_dir+"message.txt" )        
        # add symbols to req file 
        os.remove(contacts_dir+"message.txt")
        
    elif len(missing_data)>0:
        
        #Mail content when missing symbols found
        file_object = open(contacts_dir+"message.txt", 'a')
        file_object.write("Tickers have passed the 100 counts for the month")
        file_object.close()
        
        
        emails = get_contacts(contacts_dir+"tca_missing_symbol_alert_contacts.txt")
        process_email(emails=emails, subject="Missing symbols TCA {}".format(datetime.now().date()),
                      html_email= contacts_dir+"message.txt" )        
        # add symbols to req file 
        os.remove(contacts_dir+"message.txt")
        
    else:
        emails = get_contacts(contacts_dir+"tca_missing_symbol_alert_contacts.txt")
        process_email(emails=emails, subject="Missing symbols TCA {}".format(datetime.now().date()),
                      text_email= "NO missing Symbols found for TCA !!!" )        
        logging.info("All symbols present in GetQuotedata table cassnadra !")
        
        
def split2():
    for r, d, f in os.walk(inputpath):
        for file in f:
            #print file
            if (file.find("tempfile1_")!=-1):
                logging.info("Reading temp1 and temp2 files for order and execution data")
                #print f
                file_name = os.path.join(r, file)
                base = os.path.basename(file_name)[10:18]
                print file_name, base
                logging.info("{},{}".format(file_name, base))
                
                execution = pd.read_csv(file_name, header=None)
                execution.columns = ['ClientOrdID','Og_ClientOrdID_exec','Symbol','TradeId','LastFillTime','Price','QuantityExecuted','Exchange','Response_status']
                execution['LastFillTime'] = pd.to_datetime(execution['LastFillTime'],errors="coerce") + timedelta(hours=5,minutes=30)
                execution = execution[execution['ClientOrdID']!='None']
                
                # list of rejected orders
                rejected_orders = execution[(execution['Response_status']==9) | (execution['Response_status']=='9') ][['ClientOrdID','Response_status']]
                rejected_orders['Response_status']=rejected_orders['Response_status'].astype(str)
                logging.info("Number of rejected orders, i.e : tag 35=9-  {}".format(len(rejected_orders)))
                execution = execution[~execution['ClientOrdID'].isin(list(rejected_orders['ClientOrdID'].values))]
              
                
                # storing orders data in dataframe
                orders = pd.read_csv(inputpath + "tempfile2_" + base + ".csv", header=None)
                orders.columns = ['MsgType','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','OrdType','LimitPrice',
                                  'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'Remarks', 'Algorithm',
                                  'Ticker', 'ArrivalTime','Tag115','tag9271']
                
                # drop records with G and 35=9; reject orders
                orders = orders.merge(rejected_orders, on='ClientOrdID',how='left')
                orders = orders[~((orders['MsgType']=='G') & (orders['Response_status']=='9')) ].drop('Response_status',axis=1)
               
                
                orders['ArrivalTime'] = pd.to_datetime(orders['ArrivalTime'], errors='coerce') + timedelta(hours=5,minutes=30)
                orders['EndTime'] = pd.to_datetime(orders['EndTime'], errors='coerce') + timedelta(hours=5,minutes=30)
                orders['Date'] = orders['ArrivalTime'].dt.date
                orders['EndTime'] = orders[orders['EndTime'].dt.time <= pd.to_datetime('15:30:00').time()]['EndTime']
                orders['EndTime'] = orders['EndTime'].fillna(pd.to_datetime(orders['Date'].apply(str)+' '+'15:30:00', errors='coerce'))
                #orders['ArrivalTime'] = orders[orders['ArrivalTime'].dt.time >= pd.to_datetime('09:15:00').time()]['ArrivalTime']
                #orders['ArrivalTime'] = orders['ArrivalTime'].fillna(pd.to_datetime(orders['Date'].apply(str)+' '+'09:15:00', errors='coerce'))
                orders['OrdType'] = orders['OrdType'].astype(str)
                orders.loc[orders['OrdType'] == '1', 'OrdType'] = 'MKT'
                orders.loc[orders['OrdType'] == '2', 'OrdType'] = 'LMT'
                orders.loc[orders['Side'] == 1, 'Side'] = 'BUY'
                orders.loc[orders['Side'] == 2, 'Side'] = 'SELL'
                orders.loc[orders['SecurityExchange'] == 'NS', 'SecurityExchange'] = 'NSE'
                orders.loc[orders['SecurityExchange'] == 'BO', 'SecurityExchange'] = 'BSE'
                orders['StartTime'] = orders[orders['ArrivalTime'].dt.time >= pd.to_datetime('09:15:00').time()]['ArrivalTime']
                orders['StartTime'] = orders['StartTime'].fillna(pd.to_datetime(orders['Date'].apply(str)+' '+'09:15:00', errors='coerce'))
                
                
                for index, item in orders['ClientOrdID'].iteritems():
                    if item in pd.Series(orders.loc[orders['MsgType']=='G', 'Og_ClientOrdID']):
                        orders.loc[orders['ClientOrdID']==item, 'EndTime'] = orders.loc[(orders['MsgType']=='G') & (
                                orders['Og_ClientOrdID']==item), 'ArrivalTime'].values
                    if item in pd.Series(orders.loc[orders['MsgType']=='F', 'Og_ClientOrdID']):
                        orders.loc[orders['ClientOrdID']==item, 'EndTime'] = orders.loc[(orders['MsgType']=='F') & (
                                orders['Og_ClientOrdID']==item), 'ArrivalTime'].values
                       
                orders.drop('Date', axis=1, inplace=True)
                
                               
                
                execution['NSEExecutedQty'] = 0
                execution['BSEExecutedQty'] = 0
                execution['NSEExecutedAvg'] = 0
                execution['BSEExecutedAvg'] = 0
                
                # bifurcating into NSE and BSE volumes
                execution.loc[execution['Exchange'] == 'NS', 'NSEExecutedQty'] = execution['QuantityExecuted']
                execution.loc[execution['Exchange'] == 'BO', 'BSEExecutedQty'] = execution['QuantityExecuted']
                
                execution[['Price','QuantityExecuted','NSEExecutedQty','BSEExecutedQty']] = execution[['Price',
                         'QuantityExecuted','NSEExecutedQty','BSEExecutedQty']].apply(pd.to_numeric, errors='ignore') 
                
                
                execution['values'] = execution['Price'] * execution['QuantityExecuted']
                execution['NSEvalues'] = execution['Price'] * execution['NSEExecutedQty']
                execution['BSEvalues'] = execution['Price'] * execution['BSEExecutedQty']
                
                grouped_exec = execution.groupby('ClientOrdID', as_index=False).agg({'TradeId':'first', 'LastFillTime':'max',
                                                'QuantityExecuted':'sum', 'NSEExecutedQty':'sum', 'BSEExecutedQty':'sum', 'values':'sum',
                                                'NSEvalues':'sum', 'BSEvalues':'sum'})
                
                #calculating overall AvgPx, NSE AvgPx and BSE AvgPx
                grouped_exec['AvgPx'] = grouped_exec['values'] / grouped_exec['QuantityExecuted']
                
                grouped_exec['NSEExecutedAvg'] = grouped_exec[grouped_exec['NSEvalues'] != 0]['NSEvalues'] / grouped_exec[grouped_exec['NSEExecutedQty'] != 0]['NSEExecutedQty']
                grouped_exec['BSEExecutedAvg'] = grouped_exec[grouped_exec['BSEvalues'] != 0]['BSEvalues'] / grouped_exec[grouped_exec['BSEExecutedQty'] != 0]['BSEExecutedQty']
                orders = orders[orders['MsgType'] != 'F']
                # drop columns that are not required                
                orders.drop(labels=['MsgType'], axis=1, inplace=True)
                
                merged_df = pd.merge(orders, grouped_exec, how='left', on='ClientOrdID')
                merged_df['Series'] = 'EQ'
                merged_df = merged_df[['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker', 'OrdType',
                                       'LimitPrice', 'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 
                                       'QuantityExecuted', 'AvgPx', 'NSEExecutedQty', 'BSEExecutedQty', 'NSEExecutedAvg', 
                                       'BSEExecutedAvg', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime','Tag115','tag9271']]
                
                merged_df = merged_df.fillna(0)
                merged_df['TradeId'] = merged_df['TradeId'].replace(0,'None')
                merged_df = merged_df[merged_df['TradeId']!='None']
                
                #break
            
                df_temp = merged_df.loc[merged_df["Og_ClientOrdID"] != "None",['Og_ClientOrdID','StartTime']]
                df_temp['ClientOrdID'] = df_temp['Og_ClientOrdID']
                merged_df_temp = pd.merge(merged_df, df_temp, how='left', on='ClientOrdID')
               
                #break
                merged_df_temp['StartTime_y'] = pd.to_datetime(merged_df_temp['StartTime_y'], errors='coerce')
                merged_df_temp.loc[~np.isnat(merged_df_temp['StartTime_y']),'EndTime'] = merged_df_temp['StartTime_y']
                merged_df_temp['StartTime'] = merged_df_temp['StartTime_x'] 
                merged_df_temp['Og_ClientOrdID'] = merged_df_temp['Og_ClientOrdID_x'] 
                
                merged_df = merged_df_temp[['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker', 
                                            'OrdType', 'LimitPrice', 'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty',
                                            'SOR', 'QuantityExecuted', 'AvgPx', 'NSEExecutedQty', 'BSEExecutedQty', 'NSEExecutedAvg', 
                                            'BSEExecutedAvg', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime','Tag115','tag9271']]
                #merged_df = merged_df[merged_df['QuantityExecuted'] > 0]
                #base = os.path.basename(file_name)
                # copy tag9271 from D to G and F
                merged_df['tag9271'] = merged_df.groupby(['TradeId'])['tag9271'].apply(lambda grp: grp.mask(grp=='None', None).ffill())
                merged_df['tag9271'] = merged_df['tag9271'].fillna('None')
                
                #merged_df = merged_df[merged_df['Ticker']=='BORORENE'] 
                merged_df.to_csv(outpath + "orders{}.csv".format(base), index=False)
                
                print 'Order File generated successfully'
                logging.info('Order File generated successfully')
                
                # send alert for missing symbols
                alert_missing_symbols(merged_df)
                
                

'''
def alert_missing_symbols(order_df):
    # check for symbols dumped in cassandra or not ; and send alert email 
    missing_data=[]
    for ticker in order_df['Ticker'].unique():  
        d = pd.to_datetime(order_df[order_df['Ticker']==ticker]['StartTime'].values[0]).date()
        if len(getData(session,"IS",ticker,d))==0:
            print "Data missing for {} {} {}".format(ticker, d, "IS")
            tag115 = ', '.join(list(order_df[order_df['Ticker']==ticker]['Tag115'].unique()))
            missing_data.append([ticker, "IS", d, "NSE", tag115])
        
        if len(getData(session,"IB",ticker,d))==0:
            print "Data missing for {} {} {}".format(ticker, d, "IB")
            tag115 = ', '.join(list(order_df[order_df['Ticker']==ticker]['Tag115'].unique()))
            missing_data.append([ticker, "IB", d, "BSE", tag115])
                 
    missing_data = pd.DataFrame(missing_data, columns=['Ticker','Series','date','Exchange','Tag115'])        
    with open(contacts_dir+"message.txt", "wb") as file:
        file.write(missing_data.to_html())
                
    if len(missing_data)>0:
        # send an email alert
        emails = get_contacts(contacts_dir+"tca_missing_symbol_alert_contacts.txt")
        process_email(emails=emails, subject="Missing symbols TCA {}".format(datetime.now().date()),
                      html_email= contacts_dir+"message.txt" )
    else:
        logging.info("All symbols present in GetQuotedata table cassnadra !")
        
'''

