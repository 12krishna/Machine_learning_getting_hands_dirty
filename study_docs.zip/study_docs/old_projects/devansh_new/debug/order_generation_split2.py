    # -*- coding: utf-8 -*-
"""
Created on Fri May 10 17:18:04 2019

@author: Administrator
"""
import os
import re
import pandas as pd
import numpy as np
import string
import simplefix
from datetime import datetime, timedelta
from time import time
inputpath = '/home/hadoop/tca_project/temp_files/'
outpath = '/home/hadoop/tca_project/order_files/'

def split2():
    for r, d, f in os.walk(inputpath):
        for file in f:
            #print file
            if (file.find("tempfile1_")!=-1):
                #print f
                file_name = os.path.join(r, file)
                base = os.path.basename(file_name)[10:18]
                print file_name, base
                
                execution = pd.read_csv(file_name, header=None)
                execution.columns = ['ClientOrdID','Og_ClientOrdID_exec','Symbol','TradeId','LastFillTime','Price','QuantityExecuted','Exchange']
                execution['LastFillTime'] = pd.to_datetime(execution['LastFillTime'],errors="coerce") + timedelta(hours=5,minutes=30)
                
                # storing orders data in dataframe
                orders = pd.read_csv(inputpath + "tempfile2_" + base + ".csv", header=None)
                orders.columns = ['MsgType','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','OrdType','LimitPrice','Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'Remarks', 'Algorithm', 'Ticker', 'ArrivalTime','Tag115']
                
                orders['ArrivalTime'] = pd.to_datetime(orders['ArrivalTime'], errors='coerce') + timedelta(hours=5,minutes=30)
                orders['EndTime'] = pd.to_datetime(orders['EndTime'], errors='coerce') + timedelta(hours=5,minutes=30)
                orders['Date'] = orders['ArrivalTime'].dt.date
                orders['EndTime'] = orders[orders['EndTime'].dt.time <= pd.to_datetime('15:30:00').time()]['EndTime']
                orders['EndTime'] = orders['EndTime'].fillna(pd.to_datetime(orders['Date'].apply(str)+' '+'15:30:00', errors='coerce'))
                #orders['ArrivalTime'] = orders[orders['ArrivalTime'].dt.time >= pd.to_datetime('09:15:00').time()]['ArrivalTime']
                #orders['ArrivalTime'] = orders['ArrivalTime'].fillna(pd.to_datetime(orders['Date'].apply(str)+' '+'09:15:00', errors='coerce'))
                orders['OrdType'] = orders['OrdType'].astype(str)
                orders.loc[orders['OrdType'] == '1', 'OrdType'] = 'MKT'
                orders.loc[orders['OrdType'] == '2', 'OrdType'] = 'LMT'
                orders.loc[orders['Side'] == 1, 'Side'] = 'BUY'
                orders.loc[orders['Side'] == 2, 'Side'] = 'SELL'
                orders.loc[orders['SecurityExchange'] == 'NS', 'SecurityExchange'] = 'NSE'
                orders.loc[orders['SecurityExchange'] == 'BO', 'SecurityExchange'] = 'BSE'
                orders['StartTime'] = orders[orders['ArrivalTime'].dt.time >= pd.to_datetime('09:15:00').time()]['ArrivalTime']
                orders['StartTime'] = orders['StartTime'].fillna(pd.to_datetime(orders['Date'].apply(str)+' '+'09:15:00', errors='coerce'))
                
                for index, item in orders['ClientOrdID'].iteritems():
                    if item in pd.Series(orders.loc[orders['MsgType']=='G', 'Og_ClientOrdID']):
                        orders.loc[orders['ClientOrdID']==item, 'EndTime'] = orders.loc[(orders['MsgType']=='G') & (orders['Og_ClientOrdID']==item), 'ArrivalTime'].values
                    if item in pd.Series(orders.loc[orders['MsgType']=='F', 'Og_ClientOrdID']):
                        orders.loc[orders['ClientOrdID']==item, 'EndTime'] = orders.loc[(orders['MsgType']=='F') & (orders['Og_ClientOrdID']==item), 'ArrivalTime'].values
                       
                orders.drop('Date', axis=1, inplace=True)
                
                execution['NSEExecutedQty'] = 0
                execution['BSEExecutedQty'] = 0
                execution['NSEExecutedAvg'] = 0
                execution['BSEExecutedAvg'] = 0
                
                # bifurcating into NSE and BSE volumes
                execution.loc[execution['Exchange'] == 'NS', 'NSEExecutedQty'] = execution['QuantityExecuted']
                execution.loc[execution['Exchange'] == 'BO', 'BSEExecutedQty'] = execution['QuantityExecuted']
                
                execution['values'] = execution['Price'] * execution['QuantityExecuted']
                execution['NSEvalues'] = execution['Price'] * execution['NSEExecutedQty']
                execution['BSEvalues'] = execution['Price'] * execution['BSEExecutedQty']
                
                grouped_exec = execution.groupby('ClientOrdID', as_index=False).agg({'TradeId':'first', 'LastFillTime':'max', 'QuantityExecuted':'sum', 'NSEExecutedQty':'sum', 'BSEExecutedQty':'sum', 'values':'sum', 'NSEvalues':'sum', 'BSEvalues':'sum'})
                
                #calculating overall AvgPx, NSE AvgPx and BSE AvgPx
                grouped_exec['AvgPx'] = grouped_exec['values'] / grouped_exec['QuantityExecuted']
                
                grouped_exec['NSEExecutedAvg'] = grouped_exec[grouped_exec['NSEvalues'] != 0]['NSEvalues'] / grouped_exec[grouped_exec['NSEExecutedQty'] != 0]['NSEExecutedQty']
                grouped_exec['BSEExecutedAvg'] = grouped_exec[grouped_exec['BSEvalues'] != 0]['BSEvalues'] / grouped_exec[grouped_exec['BSEExecutedQty'] != 0]['BSEExecutedQty']
                orders = orders[orders['MsgType'] != 'F']
                # drop columns that are not required                
                orders.drop(labels=['MsgType'], axis=1, inplace=True)
                
                merged_df = pd.merge(orders, grouped_exec, how='left', on='ClientOrdID')
                merged_df['Series'] = 'EQ'
                merged_df = merged_df[['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker', 'OrdType', 'LimitPrice', 'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'QuantityExecuted', 'AvgPx', 'NSEExecutedQty', 'BSEExecutedQty', 'NSEExecutedAvg', 'BSEExecutedAvg', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime','Tag115']]
                
                merged_df = merged_df.fillna(0)
                merged_df['TradeId'] = merged_df['TradeId'].replace(0,'None')
                merged_df = merged_df[merged_df['TradeId']!='None']
                
                #break
            
                df_temp = merged_df.loc[merged_df["Og_ClientOrdID"] != "None",['Og_ClientOrdID','StartTime']]
                df_temp['ClientOrdID'] = df_temp['Og_ClientOrdID']
                merged_df_temp = pd.merge(merged_df, df_temp, how='left', on='ClientOrdID')
               
                #break
                merged_df_temp['StartTime_y'] = pd.to_datetime(merged_df_temp['StartTime_y'], errors='coerce')
                merged_df_temp.loc[~np.isnat(merged_df_temp['StartTime_y']),'EndTime'] = merged_df_temp['StartTime_y']
                merged_df_temp['StartTime'] = merged_df_temp['StartTime_x'] 
                merged_df_temp['Og_ClientOrdID'] = merged_df_temp['Og_ClientOrdID_x'] 
                
                merged_df = merged_df_temp[['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker', 'OrdType', 'LimitPrice', 'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'QuantityExecuted', 'AvgPx', 'NSEExecutedQty', 'BSEExecutedQty', 'NSEExecutedAvg', 'BSEExecutedAvg', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime','Tag115']]
                #merged_df = merged_df[merged_df['QuantityExecuted'] > 0]
                #base = os.path.basename(file_name)
                merged_df.to_csv(outpath + "orders{}.csv".format(base), index=False)
                
                print 'done'
