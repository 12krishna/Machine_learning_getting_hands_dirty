# -*- coding: utf-8 -*-
"""
Created on Fri Jan 24 16:04:43 2020

@author: Administrator
"""

import pandas as pd
import csv
import time
import io
from datetime import date
import datetime
import numpy as np

today = date.today()
d1 = today.strftime("%Y%m%d")
d2 = today.strftime("%Y-%m-%d")
api_read = False
#notisfile = "/NOTIS_API/nsecm_" + d2 + ".txt"
notisfile = "D:\\check\\nsecm.txt"
tcsfile = "D:\\check\\tcs_output.csv"
id_list = ['2337 ','3650 ','14293','16570','17061','17100','18307','22514','26683','41573','41574','41583','43114']
curr_date = d1

df_filtered_11 = pd.DataFrame()
df_orig = pd.DataFrame()
df = pd.read_csv(notisfile,header=None, converters={0:str,1:str,2:str,3:str,4:str,5:str,6:str,7:str,8:str,9:str,10:str,11:str,12:str,13:str,14:str,15:str,16:str,17:str,18:str,19:str,20:str,21:str,22:str,23:str,24:str,25:str})
df.columns = ["tradeid","tradestatus","symbol","series","securityname","instrumenttype","booktype","markettype","userid","branchid","transactiontype","fillsize","fillprice","customerfirm","accountid","executingbroker","auctionparttype","aauctionno","settlementperiod","entrydatetime","modifieddatetime","exchordid","cpid","orderdatetime","dealercode"]

df_filtered = df[df['userid'].isin(id_list)]
df_filtered['tradeid_new'] = df_filtered['tradeid'].apply(lambda x : str(x).strip().zfill(8))
df_filtered['ordid_trdid'] = df_filtered['exchordid'].str.strip() + "_" + curr_date + df_filtered['tradeid_new'] + str(df_filtered['fillsize']) + "_" + str(df_filtered['fillprice'])

df_filtered_11 = df_filtered[df_filtered.tradestatus=='11']
df_filtered_11['exchange'] = 'NSE'
df_notis = df_filtered_11[['exchange','tradeid_new','exchordid','ordid_trdid']]
df_notis.index = df_notis['ordid_trdid'].astype(str)
df_filtered.index = df_filtered['ordid_trdid']
df_orig = df_filtered[["tradeid","tradestatus","symbol","series","securityname","instrumenttype","booktype","markettype","userid","branchid","transactiontype","fillsize","fillprice","customerfirm","accountid","executingbroker","auctionparttype","aauctionno","settlementperiod","entrydatetime","modifieddatetime","exchordid","cpid","orderdatetime","dealercode"]]
df_orig.index = df_filtered['ordid_trdid']

df1 = pd.read_csv(tcsfile,header=None)
df1.columns = ['tradeid_new','ent_id','fi_id','exchordid','terminalid','first_ent','short_code','qty','price']
df1['ordid_trdid'] = df1['exchordid'].astype(str) + "_" + df1['tradeid_new'].astype(str) + df1['qty'].astype(str) + "_" + df1['price'].astype(str)
df1['exchange'] = 'NSE'
df_tcs = df1[['exchange','tradeid_new','exchordid','ordid_trdid']]
df_tcs.index = df_tcs['ordid_trdid'].astype(str)

print df_notis[df_notis.duplicated(['ordid_trdid'])]
print df_tcs[df_tcs.duplicated(['ordid_trdid'])]
