# -*- coding: utf-8 -*-
"""
Created on Thu Jan 21 18:16:09 2021

@author: krishna
"""

import time
import os, shutil
import sys
import numpy as np
import pandas as pd
import datetime
import logging
import warnings
sys.path.insert(0, 'D:\\Trades_tally\\TradesAggregate\\')
from Trades import TradesAggregate
warnings.filterwarnings("ignore")


master_dir = "D:\\Master\\"
# output_dir="D:\\Trades_tally\\TradesSplit\\"
#input_dir = r"\\172.17.40.40\alias_shared_drives\TradeFile2"
input_dir = r"\\172.17.9.22\Users\krishna\Trade Files"
log_dir = "D:\\Trades_tally\\Logs\\FNO\\Alias\\"
setup_dir = "D:\\TradeC\\DealingRoom\\"  # path for account, dealer mappings for particular setup


setup_desk = ["ETS"]  # read evrything except ETS
_Filenames=["nsecm.txt","nsefo.txt","bsecm.csv"]
_Output_filename="ALIAS_{}_withlots.txt"
_Output_cols=['Account','Exchange','TradingSymbol','Symbol','InstrumentType','Expiry','StrikePrice','CallOrPut','Side',
              'Quantity','Average','Value','CpCode','Quantity_Lots']

logging.basicConfig(filename="debug_{}.log".format(datetime.datetime.today().date()),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


'''
Consist of all utilties needed to split trades
first filter on desk-wise ctcl codes
then split trades into seperate files as per account mappings 
'''

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date
        
        
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
    
    # read holiday master
    holiday_master = pd.read_csv('D:\\Master\\Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)    
    
    
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1
         
    
def load_account_mappings():
    '''Account mappings to users'''
          
    df = pd.read_csv(setup_dir+"AccountMappings.txt",header=None, names=['UserName','Account'],
                                        encoding = "ISO-8859-1", delimiter=",", converters={i: str for i in range(0, 5)})
    df = df.applymap(lambda s: s.strip())
    df.drop_duplicates(inplace=True)    
    
    return df

def load_userfile_mappings():
    '''Dir where files are to be stored'''
    
    df = pd.read_csv(setup_dir+"UsersFileMappings.txt",header=None, names=['UserName','Dir'],
                                        encoding = "ISO-8859-1", delimiter=",", converters={i: str for i in range(0, 5)})
    df = df.applymap(lambda s: s.strip())
    df.drop_duplicates(inplace=True)    
    #df['Dir'] = "D:\\Trades_tally\\CASH\\Alias\\TradesSplit\\"
    
    return df

def load_ctcl_setup(trades):
    '''Loads ctcl codes as per desk setup'''
    
    ctcl_codes = trades.load_ctcl_codes(setup_dir+"DealerMappings.txt")
    ctcl_codes = ctcl_codes[~ctcl_codes['Desk'].isin(setup_desk)]
    nsecm_ctcl_list = ctcl_codes[ctcl_codes['Exchange']=='NSE-CM']['UserId'].values.tolist()
    nsefo_ctcl_list = ctcl_codes[ctcl_codes['Exchange']=='NSE-FO']['UserId'].values.tolist()
    bsecm_ctcl_list = ctcl_codes[ctcl_codes['Exchange']=='BSE-CM']['UserId'].values.tolist()
    
    return nsecm_ctcl_list, nsefo_ctcl_list, bsecm_ctcl_list
        


def write_file(filepath, temp):

    temp = temp.to_csv(index=False,sep=",")
    while True:
        try:                        
            #f = open(r"\\172.17.9.97\TradeFile\nsecm_bkcapi.txt","ab",8192*1024*20) 
            f=open(filepath, "w", 8192*1024*20)
            f.writelines(temp)
            f.flush()
            os.fsync(f.fileno())                 
            f.close()
            break
        except Exception as e:
            print ("File write error : Error {}".format(e))
            time.sleep(5)



def user_trade_splits(result):
    '''Split trades as per user access to account or family'''
    
    # reload account mappings and usersfile mappings
    account_mappings = load_account_mappings() # reload latest account mappings
    usersfile_mappings = load_userfile_mappings()
    
    # users with all access to particular desk
    super_user = account_mappings[account_mappings['Account']=='ALL']['UserName'].values.tolist()
    super_path = usersfile_mappings[usersfile_mappings['UserName'].isin(super_user)]
    
    for _, row in super_path.iterrows():
        if os.path.exists(row['Dir']):
            write_file(os.path.join(row['Dir'],_Output_filename.format(row['UserName'])) , result[_Output_cols])
        
    # users with restricted accesss
    df = result.merge(account_mappings, on=['Account'], how='left')
    df = df.merge(usersfile_mappings, on=['UserName'], how='left')
    df.dropna(subset=['UserName','Dir'], inplace=True)
    
    for user in sorted(set(df['UserName'].unique())):
        temp=df[df['UserName']==user][_Output_cols]# filter users records
        #temp.drop(columns=['UserName'], inplace=True)
        # append file to dir
        dirname=usersfile_mappings[usersfile_mappings['UserName']==user]['Dir'].values[0]
        if temp.empty!=True and os.path.exists(dirname):
            write_file(os.path.join(dirname,_Output_filename.format(user)) , temp)
            
def load_lot_size():
    
    while 1 :
        try:
            print(r"Getting instrument file from \\172.17.9.97\TradeFile\instrument.csv")
            if os.path.exists(r"\\172.17.9.97\TradeFile\instrument.csv"):
                shutil.copy(r"\\172.17.9.97\TradeFile\instrument.csv", "D:\Trades_tally\instrument.csv")
            break
        except Exception as e:
             print (e)
             
    df=pd.read_csv("D:\Trades_tally\instrument.csv")
    
    return df[df['ExchangeSegment']=='NFO'][['TradingSymbol','LotSize']]    
            
    
class FileReader():
    '''Class to read input file 
    keeps running track of file offset
    '''
    def __init__(self, filename, schema):
        self.offset = 0
        self.filename = filename
        self.input_schema = schema
    def read(self, input_dir, delimiter):
        # read file and process output
        prev_file =  pd.read_csv(os.path.join(input_dir,'{}'.format(self.filename)), header=None, names= self.input_schema,
                                     delimiter=delimiter, skiprows=self.offset, converters={i: str for i in range(0, 100)},
                                     low_memory=False)# read prev updated file
        self.offset+=len(prev_file)
        return prev_file
        
def flush_files():
    
    users_df = load_userfile_mappings()
    for _, row in users_df.iterrows():
        print (row['Dir'])
        pd.DataFrame(columns = _Output_cols).to_csv(os.path.join(row['Dir'],_Output_filename.format(row['UserName'])), index=False)


def main():
     
    # check for running process condition
    d = datetime.datetime.now().date()
    
    if process_run_check(d) == -1:
        logging.info('Exit: Holiday.')
        return -1   
    else:
        logging.info("Start processing for working day !")
        
    # flush files
    if datetime.datetime.now().time()<datetime.time(9,0):
        flush_files()
    # load lot sizes for today
    lot_sizes = load_lot_size()
    
    
    #batch_data=pd.DataFrame()
    btime=time.time()
    reload_time = time.time()
    processing_time = 21
    
    
    result = pd.DataFrame()
    
    for r, _, _ in os.walk(input_dir):
        print(r)
        
        try:
                
            print ("Start processing batch.........................")
            
            s=time.time()
            
            # trade agg object
            trades = TradesAggregate()
                
            # file objects that keep track of offset and reads data in tail fashion
            nsecm_file_obj = FileReader(_Filenames[0], trades.input_schema_nsecm)
            nsefo_file_obj = FileReader(_Filenames[1], trades.input_schema_nsefo)
            bsecm_file_obj = FileReader(_Filenames[2], trades.input_schema_bsecm)
   
            
            nsecm_ctcl_list, nsefo_ctcl_list, bsecm_ctcl_list = None, None, None #load_ctcl_setup(trades)
            
            ftime = time.time()
            # read new records in file, pre-process and aggregate trades for every iteration
            nsecm_df = nsecm_file_obj.read(r, delimiter=',')
            nsefo_df = nsefo_file_obj.read(r, delimiter=',')
            #bsecm_df = bsecm_file_obj.read(r, delimiter='|')
            print (f"File reading time {time.time()-ftime}")
            
            ftime = time.time()
            nsecm_df = pd.DataFrame(); #trades.pre_process(nsecm_df, 'NSE-CM')
            nsefo_df = trades.pre_process(nsefo_df, 'NSE-FO')
            bsecm_df = pd.DataFrame(); #trades.pre_process(bsecm_df, 'BSE-CM')
            print (f"File pre-processing time {time.time()-ftime}")
            
            update_flag=0
            if nsecm_df.empty!=True:
                print("Processing records for NSE-CM")
                trades.process_records(nsecm_df, 'NSE-CM')
                update_flag=1
            if nsefo_df.empty!=True:
                print("Processing records for NSE-FO")
                trades.process_records(nsefo_df, 'NSE-FO')
                update_flag=1
            if bsecm_df.empty!=True:
                print("Processing records for BSE-CM")
                trades.process_records(bsecm_df, 'BSE-CM')
                update_flag=1
                
            if update_flag==1:
                print("Updates in trade agg; writing file to user dir")
                output = trades.result.groupby(by=['Exchange'], as_index=False).apply(lambda grp: trades.format_output(grp, grp.name))
                
                # add lot sizes to end
                output = output.merge(lot_sizes, on=['TradingSymbol'], how='left')
                output.loc[(output['Exchange'].isin(['NSE-CM','BSE-CM'])), 'LotSize'] = 1
                output.loc[(output['Exchange']=='NSE-FO') & (output['LotSize']>0), 'Quantity_Lots']=output['Quantity']/output['LotSize']
                output.sort_values(by=['Account','Exchange','TradingSymbol'], inplace=True)
                #output['Quantity_Lots'] = output[['Quantity','LotSize']].apply(lambda row: row['Quantity']/row['LotSize'] if row['LotSize']>0 else row['Quantity'], axis=1)
                output['TradeDate'] = pd.to_datetime(os.path.basename(r), format="%Y%m%d").date()
                result = result.append(output, ignore_index=True)
                # split trades according to the account mappings
                #user_trade_splits(output)
            
            processing_time = time.time()-s
            print("Batch processing time {}".format(processing_time))
               
        except Exception as e:
            print(e)


if __name__=='__main__':
    main()
