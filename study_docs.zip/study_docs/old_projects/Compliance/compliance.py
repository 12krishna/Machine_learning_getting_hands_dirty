# -*- coding: utf-8 -*-
"""
Created on Tue Mar 14 14:49:00 2023

@author: Administrator
"""

import pandas as pd
import numpy as np
from cassandra.cluster import Cluster
import os

master_dir = "D:\\Master\\"
trades_dir = "D:\\Compliance\\"

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster

cluster = cassandra_configs_cluster()
session = cluster.connect('rohit')
#logging.info('Using test_df keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None
    

def fetch_cmbhavcopy(date):
        
    print("Getting cm data for {}".format(date))
    query=session.execute("select * from cm_bhavcopy where timestamp='{}' allow filtering;".format(date), timeout=None)
    result=query._current_rows
 
    return result


df = pd.read_csv(os.path.join(trades_dir, "trades.csv"))
df['Expiry'] = pd.to_datetime(df['Expiry'], format="%d%b%Y"); df['Expiry'] = df['Expiry'].dt.date
df.loc[df['Exchange']=='NSE-CM', "InstrumentType"] = df['TradingSymbol'].apply(lambda row: row.split("-")[-1])
df.drop(columns=['LotSize'], inplace=True)

def load_cash_bhavcopies(df):
        
    # nse
    cm_bhavcopy = pd.DataFrame()
    for date in df['TradeDate'].unique():    
        cm_bhavcopy = cm_bhavcopy.append(fetch_cmbhavcopy(date), ignore_index=True)
        
    cm_bhavcopy = cm_bhavcopy.append(fetch_cmbhavcopy("2023-01-17"), ignore_index=True)
    cm_bhavcopy = cm_bhavcopy.append(fetch_cmbhavcopy("2023-01-10"), ignore_index=True)
    
    cm_bhavcopy.drop_duplicates(inplace=True)  
    cm_bhavcopy = cm_bhavcopy[['timestamp','close','symbol','tottrdqty','series']]
    cm_bhavcopy.to_csv("cm_bhavcopy.csv", index=False)
    
    # bse
    bse_bhavcopy = pd.DataFrame()
    for date in df['TradeDate'].unique():    
        print("Getting bse data for {}".format(date))
        query=session.execute("select * from bse_bhavcopy where trading_date='{}' allow filtering;".format(date), timeout=None)._current_rows
        bse_bhavcopy = bse_bhavcopy.append(query, ignore_index=True)
    
    # get symbol
    instru = pd.read_csv(os.path.join(master_dir, "instrument.csv"))
    instru = instru[instru['ExchangeSegment']=='BSE'][['Symbol','Series','ISIN']].rename(columns={'ISIN':'isin_code'})
    
    bse_bhavcopy = bse_bhavcopy.merge(instru, on=['isin_code'], how="left")
    bse_bhavcopy = bse_bhavcopy[['trading_date','Symbol','close','no_trades']]
    bse_bhavcopy.to_csv("bse_bhavcopy.csv", index=False)


def load_bhavcopies():
 
    fo_bhavcopy = pd.DataFrame()
    for _, _, files in os.walk(r"\\172.17.9.22\Users\krishna\fo_bhavcopy"):
        for f in files:
            print("Reading fo bhav for {}".format(f))
            fo_bhavcopy = fo_bhavcopy.append(pd.read_csv(os.path.join(r"\\172.17.9.22\Users\krishna\fo_bhavcopy", f)), ignore_index=True)
            
    fo_bhavcopy = fo_bhavcopy[['INSTRUMENT','SYMBOL', 'EXPIRY_DT', 'STRIKE_PR', 'OPTION_TYP','CLOSE','CONTRACTS','OPEN_INT','TIMESTAMP']]
    fo_bhavcopy.columns = ['InstrumentType','Symbol','Expiry','StrikePrice','CallOrPut','Close_fno','volume_fno','open_int','TradeDate']
    fo_bhavcopy['TradeDate'] = pd.to_datetime(fo_bhavcopy['TradeDate'], format="%d-%b-%Y")
    fo_bhavcopy['TradeDate'] = fo_bhavcopy['TradeDate'].dt.date
    
    fo_bhavcopy['Expiry'] = pd.to_datetime(fo_bhavcopy['Expiry'], format="%d-%b-%Y")
    fo_bhavcopy['Expiry'] = fo_bhavcopy['Expiry'].dt.date
    
    # get lot size
    lot_sizes = pd.read_csv(os.path.join(master_dir, "instrument.csv"))
    lot_sizes = lot_sizes[lot_sizes['InstrumentType'].str.startswith("FUT")][['Symbol','LotSize']].drop_duplicates()
    
    fo_bhavcopy = fo_bhavcopy.merge(lot_sizes, on=['Symbol'], how="left")
    fo_bhavcopy['volume_fno'] = fo_bhavcopy['volume_fno']*fo_bhavcopy['LotSize']
    fo_bhavcopy['open_int'] = fo_bhavcopy['open_int']*fo_bhavcopy['LotSize']
    
    
    fo_bhavcopy.to_csv("fo_bhavcopy.csv", index=False)        
            

# read bhav copy files
cm_bhavcopy = pd.read_csv("cm_bhavcopy.csv")
cm_bhavcopy['InstrumentType'] = cm_bhavcopy['series']
cm_bhavcopy['Exchange'] = "NSE-CM"
cm_bhavcopy.rename(columns={'symbol':'Symbol','timestamp':'TradeDate','tottrdqty':'Volume'}, inplace=True)

# get NSE cash volume
df = df.merge(cm_bhavcopy, on=['Symbol','TradeDate','Exchange','InstrumentType'], how="left")

# get fno volume and oi
#load_bhavcopies()
fo_bhavcopy = pd.read_csv("fo_bhavcopy.csv")
df['Expiry'] = df['Expiry'].astype(str)
df.loc[df['InstrumentType'].str.startswith("FUT"), "StrikePrice"] = 0
df.loc[df['InstrumentType'].str.startswith("FUT"), "CallOrPut"] = 'XX'

df = df.merge(fo_bhavcopy, on=['Symbol','TradeDate','InstrumentType','Expiry','StrikePrice','CallOrPut'], how="left")


df.loc[df['InstrumentType'].isin(['FUTSTK','FUTIDX','OPTSTK','OPTIDX']), 'close'] = df['Close_fno']
df.loc[df['InstrumentType'].isin(['FUTSTK','FUTIDX','OPTSTK','OPTIDX']), 'Volume'] = df['volume_fno']
df.drop(columns=['Close_fno','volume_fno'], inplace=True)

# get bse data
bse_bhavcopy = pd.read_csv("bse_bhavcopy.csv")
bse_bhavcopy.loc[bse_bhavcopy['Symbol']=='INFY', 'Symbol']='INFY*'

bse_bhavcopy['Exchange'] = 'BSE-CM'
df = df.merge(bse_bhavcopy.rename(columns={'trading_date':'TradeDate'}), on=['TradeDate','Symbol','Exchange'], how="left", suffixes=("","_bse"))
df.loc[df['Exchange']=='BSE-CM', 'close'] = df['close_bse']
df.loc[df['Exchange']=='BSE-CM', 'Volume'] = df['no_trades']

df.drop(columns=['no_trades','close_bse'], inplace=True)

df.to_csv("final.csv", index=False)

    