# -*- coding: utf-8 -*-
"""
Created on Thu Dec 24 18:09:09 2020
@author: krishna
"""

import time
import os
import numpy as np
import pandas as pd
import logging
import warnings
warnings.filterwarnings("ignore")
"""
import json
json_dir= open(os.path.join(os.getcwd(),"path.json"))
paths= json.load(json_dir)

'''
master_dir="D:\\Master\\"
output_dir="D:\\Trades_tally\\Output\\"
input_dir="D:\\Trades_tally\\trades dump\\"
log_path="D:\\Trades_tally\\logs\\"
#input_dir="X:\\"
_Filename="nsecm1.txt"
_Output_filename="trades_tally_cm.txt"
'''

master_dir = paths["file_path"]["master_dir"]
"""

class TradesAggregate():
    '''Generic class that contains all utility functions needed
    to handle trade agg as per account
    '''
    def __init__(self):
        '''
        Takes tuple filenames for NSE CM, FO and BSECM
        '''
        
        # class constructor 
        self.input_schema_nsecm = ['TradeId','TradeStatus','Symbol','Series','SecurityName','InstrumentType','BookType',
                                   'MarketType','UserId','BranchId','Side','Quantity','Average','ProClient','Account','CpCode',
                                   'AuctionPartType','AuctionNo','SellPeriod','TradeTime','TradeModificationTime','ExchangeOdrId',
                                   'CounterPartyId','OrderEntryTime','DealerCode']
        self.input_schema_nsefo = ["TradeId","TradeStatus","InstrumentType","Symbol","Expiry","StrikePrice",
                                   "CallOrPut","TradingSymbol","Book_type","Book_type_name","Market_type",
                                   "UserId","Branch_id","Side","Quantity","Average","Pro_Client","Account",
                                   "Participant","Open_close_flag","Uncover_flag","Order_entry_time","Trade_time",
                                   "Exchange_Order_Id","CpCode","Order_entry_time1","CTCL code"]
        self.input_schema_bsecm = ['MemberId','UserId','ScripCode','Symbol','Average','Quantity','TradeStatus','CmCode','Time','Date',
                                   'Account','OrderId','OrderType','Side','TradeId','ClientType','ISIN','ScripGroup','SettNo','OrderTime',
                                   'APFlag','LocationId','TradeModificationTime']        
        self.input_dcschema_nsefo = self.input_schema_nsefo + ['fill','fill1']

    
        self.output_schema = ['Account','Exchange','TradingSymbol','Symbol','InstrumentType','Expiry','StrikePrice',
                              'CallOrPut','Side','Quantity','Average','Value','Participant', 'UserId','Count']
        self.primary_key = ['Participant','UserId','Account','Exchange','TradingSymbol','Symbol','InstrumentType','Expiry','StrikePrice','CallOrPut','Side']
        # self.primary_key = ['Participant', 'Account', 'CTCL code', 'Side']
        
        self.tradeid_side_nsecm = pd.DataFrame(columns=['TradeId_side','Account']) # keeps running track of trade if and account mapping
        self.tradeid_side_nsefo = pd.DataFrame(columns=['TradeId_side','Account'])
        self.tradeid_side_bsecm = pd.DataFrame(columns=['TradeId_side','Account'])
        
        self.result = pd.DataFrame(columns=self.output_schema)
        self.output = pd.DataFrame()
        
        self.exchange_nsecm, self.exchange_nsefo, self.exchange_bsecm = ("NSE-CM", "NSE-FO", "BSE-CM")
        
        
    def load_ctcl_codes(self, filepath):
        client_ctcl_codes = pd.read_csv(filepath, header=None, names=['Desk','Exchange','Username','exchorderid','UserId'], 
                                        converters={i: str for i in range(0, 100)})
        client_ctcl_codes['UserId']=client_ctcl_codes['UserId'].str.strip()
        return client_ctcl_codes
    
    def format_output(self, grp, grpname):
        if grpname=='NSE-CM':
            grp['InstrumentType'], grp['Expiry'], grp['StrikePrice'], grp['CallOrPut'], grp['CpCode'] ='EQ', np.nan, np.nan, np.nan, np.nan
            #grp['Side'] = np.where(grp['Side']=='1','BUY','SELL')
            grp.loc[grp['Side'].astype(str)=='1', 'Side'] = 'BUY'
            grp.loc[grp['Side'].astype(str)=='2', 'Side'] = 'SELL'
        elif grpname=='NSE-FO':
            grp.loc[grp['Side'].astype(str)=='1', 'Side'] = 'BUY'
            grp.loc[grp['Side'].astype(str)=='2', 'Side'] = 'SELL'
            grp['CpCode'] = np.nan
            #grp['Side'],grp['CpCode'] = np.where(grp['Side']=='1','BUY','SELL'), np.nan
        elif grpname=='BSE-CM':
            grp['InstrumentType'], grp['Expiry'], grp['StrikePrice'], grp['CallOrPut'], grp['CpCode'] ='EQ', np.nan, np.nan, np.nan, np.nan
            grp['Side'] = np.where(grp['Side']=='B','BUY','SELL')
            
        return grp[grp['Quantity']>0]


    def agg_trade11(self, grp, cnt):
        '''Func to agg trade 11'''
        
        q, v,c = np.sum(grp['Quantity']), round(np.sum(grp['Value']), 2) ,grp['Count'].sum()
        return pd.Series({'Quantity': q,
                              'Average': round(np.divide(v, q), 4),
                              "Value": v,
                              "Count": c
                              })
        
    
    def update_trademods(self, row, last_tradeid_side_list):
        '''Func to handle trade modifications'''
        
        search_len = len(last_tradeid_side_list)
        if search_len>=1:
            old_account, new_account = last_tradeid_side_list[-1], row['Account']
            if old_account!=new_account:
                    
                # old trade
                self.result['Quantity'] = np.where((self.result['Account']==old_account) & (self.result['Exchange']==row['Exchange'])\
                                        & (self.result['Symbol']==row['Symbol']) & (self.result['InstrumentType']==row['InstrumentType'])\
                                        & (self.result['Expiry']==row['Expiry']) & (self.result['StrikePrice']==row['StrikePrice'])\
                                        & (self.result['CallOrPut']==row['CallOrPut']) & (self.result['Side']==row['Side']) & (self.result['TradingSymbol']==row['TradingSymbol'])\
                                        & (self.result['Participant']==row['Participant']) & (self.result['UserId']==row['UserId']),
                                        self.result['Quantity']-row['Quantity'], self.result['Quantity'])
                self.result['Value'] = np.where((self.result['Account']==old_account) & (self.result['Exchange']==row['Exchange'])\
                                        & (self.result['Symbol']==row['Symbol']) & (self.result['InstrumentType']==row['InstrumentType'])\
                                        & (self.result['Expiry']==row['Expiry']) & (self.result['StrikePrice']==row['StrikePrice'])\
                                        & (self.result['CallOrPut']==row['CallOrPut']) & (self.result['Side']==row['Side']) & (self.result['TradingSymbol']==row['TradingSymbol'])\
                                        & (self.result['Participant']==row['Participant']) & (self.result['UserId']==row['UserId']), 
                                        self.result['Quantity']*self.result['Average'], self.result['Value'])
                self.result.loc[(self.result['Account']==old_account) & (self.result['Exchange']==row['Exchange'])\
                                        & (self.result['Symbol']==row['Symbol']) & (self.result['InstrumentType']==row['InstrumentType'])\
                                        & (self.result['Expiry']==row['Expiry']) & (self.result['StrikePrice']==row['StrikePrice'])\
                                        & (self.result['CallOrPut']==row['CallOrPut']) & (self.result['Side']==row['Side']) & (self.result['TradingSymbol']==row['TradingSymbol'])\
                                        & (self.result['Participant']==row['Participant']) & (self.result['UserId']==row['UserId']),
                'Count'] = self.result.loc[(self.result['Account']==old_account) & (self.result['Exchange']==row['Exchange'])\
                                                                & (self.result['Symbol']==row['Symbol']) & (self.result['InstrumentType']==row['InstrumentType'])\
                                                                & (self.result['Expiry']==row['Expiry']) & (self.result['StrikePrice']==row['StrikePrice'])\
                                                                & (self.result['CallOrPut']==row['CallOrPut']) & (self.result['Side']==row['Side']) & (self.result['TradingSymbol']==row['TradingSymbol'])\
                                                                & (self.result['Participant']==row['Participant']) & (self.result['UserId']==row['UserId'])
                                                                , 'Count'] - 1
                
                # new trade            
                new_trade = self.result[(self.result['Account']==new_account) & (self.result['Exchange']==row['Exchange'])\
                                            & (self.result['Symbol']==row['Symbol']) & (self.result['InstrumentType']==row['InstrumentType'])\
                                            & (self.result['Expiry']==row['Expiry']) & (self.result['StrikePrice']==row['StrikePrice'])\
                                            & (self.result['CallOrPut']==row['CallOrPut']) & (self.result['Side']==row['Side']) & (self.result['TradingSymbol']==row['TradingSymbol'])\
                                            & (self.result['Participant']==row['Participant']) & (self.result['UserId']==row['UserId'])]            
                self.result = self.result[self.result['Quantity']>0]    
                if new_trade.empty==True:
                    row['Value'] = row['Average']*row['Quantity']
                    row['Count'] = 1
                    new_trade=pd.DataFrame(row).T
                    new_trade = new_trade[self.output_schema]
                    self.result = self.result.append(new_trade, ignore_index=True)
                else:
                    # new trade
                    self.result['Quantity'] = np.where((self.result['Account']==new_account) & (self.result['Exchange']==row['Exchange'])\
                                                & (self.result['Symbol']==row['Symbol']) & (self.result['InstrumentType']==row['InstrumentType'])\
                                                & (self.result['Expiry']==row['Expiry']) & (self.result['StrikePrice']==row['StrikePrice'])\
                                                & (self.result['CallOrPut']==row['CallOrPut']) & (self.result['Side']==row['Side']) & (self.result['TradingSymbol']==row['TradingSymbol'])\
                                                & (self.result['Participant']==row['Participant']) & (self.result['UserId']==row['UserId']), 
                                            self.result['Quantity']+row['Quantity'], self.result['Quantity'])
                    self.result['Value'] = np.where((self.result['Account']==new_account) & (self.result['Exchange']==row['Exchange'])\
                                                & (self.result['Symbol']==row['Symbol']) & (self.result['InstrumentType']==row['InstrumentType'])\
                                                & (self.result['Expiry']==row['Expiry']) & (self.result['StrikePrice']==row['StrikePrice'])\
                                                & (self.result['CallOrPut']==row['CallOrPut']) & (self.result['Side']==row['Side']) & (self.result['TradingSymbol']==row['TradingSymbol'])\
                                                & (self.result['Participant']==row['Participant']) & (self.result['UserId']==row['UserId']), 
                                            self.result['Value']+row['Value'], self.result['Value'])
                    self.result['Average'] = np.where((self.result['Account']==new_account) & (self.result['Exchange']==row['Exchange'])\
                                                & (self.result['Symbol']==row['Symbol']) & (self.result['InstrumentType']==row['InstrumentType'])\
                                                & (self.result['Expiry']==row['Expiry']) & (self.result['StrikePrice']==row['StrikePrice'])\
                                                & (self.result['CallOrPut']==row['CallOrPut']) & (self.result['Side']==row['Side']) & (self.result['TradingSymbol']==row['TradingSymbol'])\
                                                & (self.result['Participant']==row['Participant']) & (self.result['UserId']==row['UserId']), 
                                            np.divide(self.result['Value'],self.result['Quantity']), self.result['Average'])
                    self.result.loc[(self.result['Account']==new_account) & (self.result['Exchange']==row['Exchange'])\
                                                & (self.result['Symbol']==row['Symbol']) & (self.result['InstrumentType']==row['InstrumentType'])\
                                                & (self.result['Expiry']==row['Expiry']) & (self.result['StrikePrice']==row['StrikePrice'])\
                                                & (self.result['CallOrPut']==row['CallOrPut']) & (self.result['Side']==row['Side']) & (self.result['TradingSymbol']==row['TradingSymbol'])\
                                                & (self.result['Participant']==row['Participant']) & (self.result['UserId']==row['UserId']),
                    'Count'] = self.result.loc[(self.result['Account']==new_account) & (self.result['Exchange']==row['Exchange'])\
                                                & (self.result['Symbol']==row['Symbol']) & (self.result['InstrumentType']==row['InstrumentType'])\
                                                & (self.result['Expiry']==row['Expiry']) & (self.result['StrikePrice']==row['StrikePrice'])\
                                                & (self.result['CallOrPut']==row['CallOrPut']) & (self.result['Side']==row['Side']) & (self.result['TradingSymbol']==row['TradingSymbol'])\
                                                & (self.result['Participant']==row['Participant']) & (self.result['UserId']==row['UserId']), 'Count'] + 1
                    
            
            #print("npwhere update time {}".format(time.time()-s))
            
        self.result = self.result[self.result['Quantity']>0]    
                        
 
        
    def pre_process(self,prev_file, exchange):

        prev_file['UserId']=prev_file['UserId'].str.strip()
        # prev_file = prev_file[prev_file['UserId'].isin(client_ctcl_codes)]
        prev_file = prev_file.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        
        if exchange=='NSE-CM':
            #prev_file['Symbol'] = prev_file['Symbol'].str.strip()
            prev_file['Exchange'], prev_file['TradingSymbol'], prev_file['Expiry'], \
                        prev_file['StrikePrice'], prev_file['CallOrPut'] = exchange, prev_file['Symbol'].astype(str)+"-"+prev_file['Series'],\
                                                                                'XX', -1, 'XX'
            prev_file['Average']=prev_file['Average'].astype(float)
        elif exchange=='NSE-FO':
            prev_file = prev_file.applymap(lambda x: x.strip() if isinstance(x, str) else x)
            prev_file['Exchange'] = exchange       
            prev_file['Average']=prev_file['Average'].astype(float)
        elif exchange=='BSE-CM':
            prev_file = prev_file.applymap(lambda x: x.strip() if isinstance(x, str) else x)
            #prev_file['Symbol'] = prev_file['Symbol'].str.strip()
            prev_file['Exchange'], prev_file['TradingSymbol'], prev_file['Expiry'], \
                        prev_file['StrikePrice'], prev_file['CallOrPut'], prev_file['InstrumentType'], prev_file['CpCode'] = exchange, \
                            prev_file['Symbol'],'XX', -1, 'XX', 'EQ', ''
            prev_file['Average']=prev_file['Average'].astype(float)
            prev_file['Average']=prev_file['Average']/100
            
        prev_file['TradeStatus']=prev_file['TradeStatus'].astype(int)
        prev_file['Quantity']=prev_file['Quantity'].astype(int)
        prev_file['Value'] = np.multiply(prev_file['Quantity'].values,prev_file['Average'].values)
        prev_file['TradeId_side'] = prev_file['TradeId'].astype(str)+"_"+prev_file['Side'].astype(str)
        prev_file['Count'] = 1
                        
        return prev_file
    
    def update_tradeid_side(self, grpname, key):
        
        if grpname=='NSE-CM':
            self.tradeid_side_nsecm= self.tradeid_side_nsecm.append(key, ignore_index=True)
            self.tradeid_side_nsecm.drop_duplicates(inplace=True, keep='last', subset=['TradeId_side'])
        elif grpname=='NSE-FO':
            self.tradeid_side_nsefo= self.tradeid_side_nsefo.append(key, ignore_index=True)
            self.tradeid_side_nsefo.drop_duplicates(inplace=True, keep='last', subset=['TradeId_side'])
        elif grpname=='BSE-CM':
            self.tradeid_side_bsecm= self.tradeid_side_bsecm.append(key, ignore_index=True)
            self.tradeid_side_bsecm.drop_duplicates(inplace=True, keep='last', subset=['TradeId_side'])
            
            
    
    def process_records(self, prev_file, grpname):
        '''Func to read file and pre process
        returns generator function for reading further trades'''
        
        s=time.time()
        print("process batch")
        
         # group on og trades 11
        trade11, trade12 = prev_file[prev_file['TradeStatus']==11], prev_file[prev_file['TradeStatus']==12]        
        print("File till now: total = %d, 11 = %d, 12 = %d"%(len(prev_file), len(trade11), len(trade12)))
        logging.info("File till now: total = %d, 11 = %d, 12 = %d"%(len(prev_file), len(trade11), len(trade12)))
        if trade11.empty!=True:
            # maintain a track of trade id and corresponding traded account
            key = trade11[['TradeId_side','Account']]
            self.update_tradeid_side(grpname, key)
            
            trade11=pd.concat([self.result, trade11[self.output_schema]], axis=0, ignore_index=True)
            self.result = trade11.groupby(by=self.primary_key, as_index=False).apply(
                lambda grp: self.agg_trade11(grp,0)).reset_index(drop=True)
             
            print("Trade 11 processing time {}".format(time.time()-s))
            logging.info("Trade 11 processing time {}".format(time.time()-s))
            
            self.result = self.result[self.result['Quantity']>0]
            
        s=time.time()
        if trade12.empty==True:
            print("No trade 12 records found...")
        else:
 
            uniques = trade12.drop_duplicates(keep='first', subset=['TradeId_side'])
            duplicates = trade12[trade12.duplicated(keep='first', subset=['TradeId_side'])]
            temp=pd.DataFrame()
            if grpname=='NSE-CM':
                temp = uniques.merge(self.tradeid_side_nsecm, on=['TradeId_side'], how='left', suffixes=('','_old'))
            elif grpname=='NSE-FO':
                temp = uniques.merge(self.tradeid_side_nsefo, on=['TradeId_side'], how='left', suffixes=('','_old'))
            elif grpname=='BSE-CM':
                temp = uniques.merge(self.tradeid_side_bsecm, on=['TradeId_side'], how='left', suffixes=('','_old'))
            
            temp = temp[temp['Account_old']!=temp['Account']]
            
            if temp.empty!=True:
        
                temp11, temp12 = temp.drop(['Account_old'], axis=1), temp.drop(['Account'], axis=1)
                temp12['Quantity']=temp12['Quantity']*-1; temp12['Count'] = temp12['Count']*-1
                temp12.loc[temp12['Quantity']<0, "Value"] = temp12['Value']*-1
                temp12.rename(columns={'Account_old':'Account'}, inplace=True)
                temp=pd.concat([self.result, temp11[self.output_schema], temp12[self.output_schema]], axis=0, ignore_index=True)
                
                # update tradeid_side with new accounts
                self.update_tradeid_side(grpname, temp11[['TradeId_side','Account']])
                                
                temp = temp.groupby(by=self.primary_key, as_index=False).apply(lambda grp: self.agg_trade11(grp,1)).reset_index(drop=True)
                temp.loc[(temp["Quantity"] < 1), "Count"] = 0
                self.result = temp
                 
                #if a->b->c
                if duplicates.empty!=True:     
                    print ("Duplicates exists !")
                    logging.info("Duplicates exists for tradeid_side in same bacth!")
                    for _, row in duplicates.iterrows():
                        #inner = time.time()
                        account_list = []
                        if grpname=='NSE-CM':
                            account_list = self.tradeid_side_nsecm.query('TradeId_side=={}'.format([row['TradeId']+"_"+row['Side']]))['Account'].values.tolist()
                        elif grpname=='NSE-FO':
                            account_list = self.tradeid_side_nsefo.query('TradeId_side=={}'.format([row['TradeId']+"_"+row['Side']]))['Account'].values.tolist()
                        elif grpname=='BSE-CM':
                            account_list = self.tradeid_side_bsecm.query('TradeId_side=={}'.format([row['TradeId']+"_"+row['Side']]))['Account'].values.tolist()
                    
                        self.update_trademods(row, account_list)
                        #dtime= time.time()
                        # update trades dict
                        #self.tradeid_side_nd, self.accounts = np.concatenate([self.tradeid_side_nd, np.array([row['TradeId']+"_"+row['Side']])]), np.concatenate([self.accounts, np.array([row['Account']])])
                        row_df = pd.DataFrame([[str(row['TradeId'])+"_"+str(row['Side']), row['Account']]],columns=['TradeId_side','Account'])
                        
                        if grpname=='NSE-CM':
                            self.tradeid_side_nsecm= self.tradeid_side_nsecm.append(row_df, ignore_index=True)
                        elif grpname=='NSE-FO':
                            self.tradeid_side_nsefo= self.tradeid_side_nsefo.append(row_df, ignore_index=True)
                        elif grpname=='BSE-CM':
                            self.tradeid_side_bsecm= self.tradeid_side_bsecm.append(row_df, ignore_index=True)
                        
                
                        #print("Dict update time {}".format(time.time()-dtime))
                        #print("Inner trade 12 time {}".format(time.time()-inner))
                    
                    if grpname=='NSE-CM':
                        self.tradeid_side_nsecm.drop_duplicates(inplace=True, keep='last', subset=['TradeId_side'])
                    elif grpname=='NSE-FO':
                        self.tradeid_side_nsefo.drop_duplicates(inplace=True, keep='last', subset=['TradeId_side'])
                    elif grpname=='BSE-CM':
                        self.tradeid_side_bsecm.drop_duplicates(inplace=True, keep='last', subset=['TradeId_side'])
                    
                    
                
                print("Trade 12 processing time {}".format(time.time()-s))
                logging.info("Trade 12 processing time {}".format(time.time()-s))
                #self.result = result
                self.result = self.result[self.result['Quantity']>0]    
                # self.write_file()
                
          
    
'''
Account + Exchange + Symbol + InstrumentType + ExpiryDate + StrikePrice + OptionType + Side
Exchange Values => “NSE-CM”, ”NSE-FO”, ”BSE-CM”
'''
#bahar