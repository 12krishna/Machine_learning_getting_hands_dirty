# -*- coding: utf-8 -*-
"""
Created on Tue May 11 17:35:59 2021

@author: krishna
"""
import pandas as pd
import csv
import time
import io
from datetime import date
import datetime
import numpy as np

def list_diff(list1, list2): 
	return (list(set(list1) - set(list2))) 

today = date.today() 
d1 = today.strftime("%Y%m%d")
d2 = today.strftime("%Y-%m-%d")
#api_read = True  

dropcopyfile = "/TradeFile1/nsecm1.txt"
#notisfile = "/sharedrepo1/nsecm1.txt"
#notisfile = "/Trades/nsecm.txt"
tcsfile = "/home/hadoop/checknotisdropcopy/tcs_output.csv"
dropcopy_header = ["tradeid","tradestatus","symbol","series","securityname","instrumenttype","booktype","markettype","userid",
                       "branchid","transactiontype","fillsize","fillprice","customerfirm","accountid","executingbroker","auctionparttype",
                       "aauctionno","settlementperiod","entrydatetime","modifieddatetime","exchordid","cpid","orderdatetime","dealercode"]
id_list = ['2337 ','3650 ','14293','16570','17061','17100','18307','22514','26683','41573','41574','43114','38027','2339 ','3330 ','16360','30201','20986','26596','21620','41567','3538','22735']
dropcopy_id_list = [i.strip() for i in id_list]
curr_date = d1
mail_file = open("/home/hadoop/checknotisdropcopy/mail_body_dropcopy.txt", 'w')

phase1_start = time.time()

df_filtered_11 = pd.DataFrame()
df_orig = pd.DataFrame()

df = pd.read_csv(dropcopyfile,header=None, converters={i: str for i in range(0, 100)}) 
df.columns = dropcopy_header
df_filtered = df[df['userid'].isin(dropcopy_id_list)]
df_filtered['tradeid_new'] = df_filtered['tradeid'].apply(lambda x : str(x).strip().zfill(8))
df_filtered['ordid_trdid'] = df_filtered['exchordid'].str.strip() + "_" + curr_date + df_filtered['tradeid_new']
df_filtered_11 = df_filtered[df_filtered.tradestatus=='11']                
df_filtered_11['exchange'] = 'NSE'
df_notis = df_filtered_11[['exchange','tradeid_new','exchordid','ordid_trdid']]
df_notis.index = df_notis['ordid_trdid'].astype(str)
df_filtered.index = df_filtered['ordid_trdid']
df_orig = df_filtered[dropcopy_header]
df_orig.index = df_filtered['ordid_trdid']

print("Phase 1 : " + str(time.time() - phase1_start))
phase2_start = time.time()

df1 = pd.read_csv(tcsfile,header=None)
#df1.columns = ['seqno','exchange','tradeid','exchordid']
df1.columns = ['tradeid_new','ent_id','fi_id','exchordid','terminalid','first_ent','short_code']
df1['ordid_trdid'] = df1['exchordid'].astype(str) + "_" + df1['tradeid_new'].astype(str)
df1['exchange'] = 'NSE'
df_tcs = df1[['exchange','tradeid_new','exchordid','ordid_trdid']]
df_tcs.index = df_tcs['ordid_trdid'].astype(str)

print("Phase 2 : " + str(time.time() - phase2_start))
phase3_start = time.time()


print "Total Duplicate records in dropcopy file ".format(len(df_notis[df_notis.duplicated(['ordid_trdid'])]))
print df_tcs[df_tcs.duplicated(['ordid_trdid'])]

df_notis = df_notis.drop_duplicates(subset='ordid_trdid', keep="first") # drop duplicate records from alias file 


notis_list =df_notis['ordid_trdid']
tcs_list = df_tcs['ordid_trdid']
diff_list = list_diff(notis_list,tcs_list)

#print diff_list

#df_diff = df_filtered[df_filtered.index.isin(diff_list)]

"""

#diff_list = []

#for item in notis_list:
#	if item not in tcs_list:
#		diff_list.append(item)

"""		
"""
notis_list_file = "notis_list.txt"
with open(notis_list_file, 'w') as f:
    for item in notis_list:
	print item
        print >> f, item

tcs_list_file = "tcs_list.txt"
with open(tcs_list_file, 'w') as f:
    for item in tcs_list:
        f.write("%s\n" % item)

diff_list_file = "diff_list.txt"
with open(diff_list_file, 'w') as f:
    for item in diff_list:
        f.write("%s\n" % item)

"""
print "Length of dropcopy list: " + str(len(diff_list))

print("Phase 3 : " + str(time.time() - phase3_start))

phase4_start = time.time()

df_diff = df_orig[df_orig.index.isin(diff_list)]

if len(df_diff) != 0:
	diff_time_min = df_diff.entrydatetime.min()
	tcs_time_max = df_filtered.entrydatetime.max()

	diff_time = datetime.datetime.strptime(str(diff_time_min), '%d %b %Y %H:%M:%S')
	tcs_time = datetime.datetime.strptime(str(tcs_time_max), '%d %b %Y %H:%M:%S')

	mail_file.write("\nReading DropCopy FILE")
	
	mail_file.write("\nDropCopy records : " + str(len(notis_list)))
	mail_file.write("\nTCS records : " + str(len(tcs_list)))
	if(len(tcs_list) < len(notis_list)):
                mail_file.write("\nDifference in record count : " + str(-1 * len(diff_list)))
        else:
                mail_file.write("\nDifference in record count : " + str(len(diff_list)))
	#mail_file.write("\nDifference in record count : " + str(len(diff_list)))
	mail_file.write("\n\nDiff min timstamp : " + str(diff_time_min))
	mail_file.write("\n\nTCS max timstamp  : " + str(tcs_time_max))

	time_diff = tcs_time - diff_time
	mail_file.write("\n\nLast record time diff : " + str(time_diff.seconds/60) + " mins")
	mail_file.write("\n\n")
	outputfile = "/Today/" + "nsecm_dropcopy_incr_" + curr_date + ".txt"
	df_diff.to_csv(outputfile,index=False,header=False)
	mail_file.close()
	table = pd.pivot_table(df_diff, index =['userid'],values=['entrydatetime'],aggfunc=[np.min,len]) 
	table.to_csv("/home/hadoop/checknotisdropcopy/mail_body_dropcopy.txt",mode='a',header=False)
	#mail_file.write(table)
	#mail_file.write("\n\n")
	#mail_file.write("Notis records")
	table1 = pd.pivot_table(df_filtered_11,index =['userid'],values=['entrydatetime'],aggfunc=[len])
	table1.to_csv("/home/hadoop/checknotisdropcopy/mail_body_dropcopy.txt",mode='a',header=False)
	#mail_file.write("\n\n")
        #mail_file.write("TCS records")
	table2 = pd.pivot_table(df1,index =['terminalid'],values=['tradeid_new'],aggfunc=[len])
	table2.to_csv("/home/hadoop/checknotisdropcopy/mail_body_dropcopy.txt",mode='a',header=False)
	#mail_file.close()
else:
    if datetime.datetime.now().time()>datetime.time(16,15) and len(notis_list)==len(tcs_list):
        mail_file.close()
    else:            
    	mail_file.write("DropCopy records : " + str(len(notis_list)))
        mail_file.write("\nTCS records : " + str(len(tcs_list)))
    	mail_file.close()
    	outputfile = "/Today/" + "nsecm_dropcopy_incr_" + curr_date + ".txt"
        df_diff.to_csv(outputfile,index=False,header=False)


"""
outputfile = "notis_incremental.txt"
count =0
b = io.FileIO(outputfile, 'w')
writer = io.BufferedWriter(b,buffer_size=100000000)
for key in diff_list:
	writer.write(str(df_filtered.loc[key]['tradeid']).ljust(15) + ',')
	writer.write(str(df_filtered.loc[key]['tradestatus']))
	writer.write("\n")
	count = count + 1
	print count

writer.flush()
b.close()
"""

"""
b = open(outputfile, 'w')


for key in diff_list:
	#print key
	b.write(str(df_filtered.loc[key]['tradeid']).ljust(15) + ',')
	b.write(str(df_filtered.loc[key]['tradestatus']))
	b.write("\n")

b.close()
"""
"""
with open(notisfile,"rb") as f:
    reader = csv.reader(f,delimiter=",")
    for i, line in enumerate(reader) :
        x = line
        key = str(x[21]).strip() + "_20191022" + str(x[0]).strip()
        if key in diff_list:
            #print x
            b.write(str(x)) 
            b.write("\n")

b.close()
"""

print("Phase 4 : " + str(time.time() - phase4_start))


