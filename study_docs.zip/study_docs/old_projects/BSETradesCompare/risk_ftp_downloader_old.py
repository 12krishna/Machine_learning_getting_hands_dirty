# -*- coding: utf-8 -*-
"""
Created on Tue Jan  4 11:24:54 2022

@author: Administrator
"""

import threading
#import socks
import socket
from ftplib import FTP
import pandas as pd
import logging
#from tabulate import tabulate
import re,os,datetime,time,sys
import pysftp
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None 
#import FPI_data
import Email_notifications

#server = '172.17.9.144'; port = 25
if sys.platform not in ('win32', 'cygwin', 'cli'):
    contacts_dir = "/home/hadoop/risk_ftp_downloader/"
    data_dir='/RiskDataDownload/'  # output dir for storing files for client
    log_path='/home/hadoop/risk_ftp_downloader/'
    master_dir = "/home/hadoop/tca_project/master_files/"
    password_filepath = "/CMFOReport/scripts/"
    email_sh = '/home/hadoop/risk_ftp_downloader/'
else:
    contacts_dir = "D:\\Emails\\Contacts\\"
    data_dir=r'\\172.17.9.22\Users2\RiskDataDownload'  # output dir for storing files for client
    log_path='C:\\Users\\backup\\'
    master_dir = "D:\\Data_dumpers\\Master\\"
    os.chdir("C:\\Users\\backup\\")
    password_filepath = "C:\\Users\\backup\\New folder\\"

#MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
_user_id = "08081"
_password = ""
_hostname = 'ftp.connect2nse.com'
lines=open(os.path.join(password_filepath, "nsepwd.txt"),"r").readlines()

uname=_user_id
pword=lines[0].strip().split("=")[-1]
print uname, pword

'''
socks.set_default_proxy(socks.HTTP, 
                    "172.17.9.170", 8080,
                     username="geetav",  # use your username  krishnay
                     password="Pass@222"  # passowrd that you use for login to kotak system
                     )       
socket.socket = socks.socksocket
'''
logging.basicConfig(filename=log_path+"risk.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")     
     

def ftp_proxy_downloader(filename, folderpath, _user_id):
    
    print "Downloading file {}".format(filename)
    while True:
        
        ftp = FTP(_hostname)
        ftp.set_debuglevel(1) 
        ftp.login(
                 user=_user_id,
                 passwd=pword 
                 )             
        print ftp.pwd() # to check what is present working directory
        ftp.cwd(folderpath)# to check the current working directory on ftp server
        newf=ftp.nlst()
        if filename in newf:
                    try:
                       ftp.retrbinary("RETR " + filename,
                                   open(os.path.join(data_dir,filename), 'wb').write)	
                       ftp.close() # dont forget to close the ftp connection after downloading all the files
                       break
                    except Exception as e:
                           print "Error downloading {} file Error code : {}".format(filename, e)
        
        time.sleep(3600)
    
    Email_notifications.email_utility("{}".format(filename), 
        "File have been updated on mentioned path: \\172.17.9.22\Users2\RiskDataDownload")
    
    #os.system("Email_notifications.sh {} {}".format('"{}"'.format(filename),
    #          '"File have been updated on mentioned path: \\172.17.9.22\Users2\RiskDataDownload"'))  

    
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 
     
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
   
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        print("working day wait file is getting downloaded")
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        sys.exit(1)
             
     
def next_working_day(d):
    d = d + datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                d = d + datetime.timedelta(days=1)
            else:
                return d    
             

             
      
def main(nd):
    
    d=datetime.datetime.today()-datetime.timedelta(nd)
    if process_run_check(d.date())== -1:
        return -1
    print "Processing for date {}".format(d)
    d1=next_working_day(d)                         #next_working_day(d)  
    
    t1=threading.Thread(target=ftp_proxy_downloader,args=("qty_freeze_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")),"/common/NTNEAT",_user_id,))
    t2=threading.Thread(target=ftp_proxy_downloader,args=("fo_secban_{}.csv".format(datetime.datetime.strftime(d1,"%d%m%Y")),"/faocommon/Limit Files","F08081",))
    t3=threading.Thread(target=ftp_proxy_downloader,args=('F_AEL_OTM_CONTRACTS_{}.csv.gz'.format(datetime.datetime.strftime(d1,"%d%m%Y")),"/faocommon/Limit Files","F08081",))
    t4=threading.Thread(target=ftp_proxy_downloader,args=("ael_{}.csv".format(datetime.datetime.strftime(d1,"%d%m%Y")), "/faocommon/Limit Files", "F08081",))
    t5=threading.Thread(target=ftp_proxy_downloader,args=("F_CN01_NSE_{}.CSV.gz".format(datetime.datetime.strftime(d,"%d%m%Y")), "/faocommon/marketreports",
                        "F08081",))
    t6=threading.Thread(target=ftp_proxy_downloader,args=("oi_cli_limit_{}.lst".format(datetime.datetime.strftime(d,"%d-%b-%Y").upper()),
                         "/faocommon/Limit Files", "F08081",))
    t7=threading.Thread(target=ftp_proxy_downloader,args=("fo{}bhav.csv.gz".format(datetime.datetime.strftime(d,"%d%b%Y").upper()),
                       "/faocommon/bhavcopy", "F08081",))
    t8=threading.Thread(target=ftp_proxy_downloader,args=("fo_mktlots.xls", "/faocommon/", "F08081",))
    t1.start()                    
    t2.start() 
    t3.start()                     
    t4.start()
    t5.start()
    t6.start()
    t7.start()
    t8.start()                         
    t1.join()                    
    t2.join() 
    t3.join()                     
    t4.join()
    t5.join()
    t6.join()
    t7.join()
    t8.join()
    #FPI_data.main()                
    #ftp_proxy_downloader("qty_freeze_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")), "/common/NTNEAT", _user_id)
   # ftp_proxy_downloader("fo_secban_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")), "/faocommon/Limit Files", "F08081")  
    #ftp_proxy_downloader('F_AEL_OTM_CONTRACTS_{}.csv.gz'.format(datetime.datetime.strftime(d,"%d%m%Y")), 
    #                     "/faocommon/Limit Files", "F08081")
    #ftp_proxy_downloader("ael_{}.csv".format(datetime.datetime.strftime(d,"%d%m%Y")), "/faocommon/Limit Files", "F08081")
   # ftp_proxy_downloader("F_CN01_NSE_{}.CSV.gz".format(datetime.datetime.strftime(d,"%d%m%Y")), "/faocommon/marketreports",
    #                     "F08081")
   # ftp_proxy_downloader("oi_cli_limit_{}.lst".format(datetime.datetime.strftime(d,"%d-%b-%Y").upper()),
      #                   "/faocommon/Limit Files", "F08081")
    #ftp_proxy_downloader("fo{}bhav.csv.gz".format(datetime.datetime.strftime(d,"%d%b%Y").upper()),
   #                      "/faocommon/bhavcopy", "F08081")
   # ftp_proxy_downloader
    
    #os.system("C:\\Users\\backup\\Desktop\\debug\\Email_notifications.bat {} {}".format('"Risk Automation Data"',
            #  '"All the files have been updated on \\172.17.9.22\\Users2\\BackOfficeDataDownload"'))
              
main(nd=0)              
   

