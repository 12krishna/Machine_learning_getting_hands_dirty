# -*- coding: utf-8 -*-
"""
Created on Mon Jan  3 14:49:15 2022

@author: Administrator
"""

import pandas as pd
import csv
import time
import io
from datetime import date
import datetime
import numpy as np
import sys
import subprocess

def list_diff(list1, list2): 
	return (list(set(list1) - set(list2))) 

today = date.today() 
d1 = today.strftime("%Y%m%d")
d2 = today.strftime("%Y-%m-%d")
colo_alias_flag=False

if sys.platform not in ('win32', 'cygwin', 'cli'):
    #colo_alias_bsefile = "/sharedrepo1/bsecm.txt"  # colo location
    #alias_bsefile = "/TradeFile2/bsecm.csv"
    dropcopy_bsefile = "/TradeFile1/bsecm.csv"
    tcsfile = "/home/hadoop/checknotis_bse/tcs_output1.csv"
    mailbodytxtpath = "/home/hadoop/checknotis_bse/bsemail_body_dropcopy.txt"
    today_incr_file = "/Today/" + "bsecm_dropcopy_incr_"
else:
    #alias_bsefile = "D:\\BSETradesCompare\\bsecm.csv"
    dropcopy_bsefile = "D:\\BSETradesCompare\\bsecm_dc.csv"
    tcsfile = "D:\\BSETradesCompare\\tcs_output1.csv"
    mailbodytxtpath = "D:\\BSETradesCompare\\bsemail_body_dropcopy.txt"
    today_incr_file = "D:\\BSETradesCompare\\bsecm_dropcopy_incr_"
    
id_list = ['67300251','1005','1011','1014','1012','1013','0254','0260','1006','1007','1008','1009','1010']
curr_date = d1
cols = ['MemberId','userid','ScripCode','symbol','Average','Quantity','tradestatus','CmCode','Time','Date','Account',
                  'exchordid','OrderType','Side','tradeid','ClientType','ISIN','ScripGroup','SettNo','orderdatetime',
                  'APFlag','LocationId','modifieddatetime']
#mail_file = open(mailbodytxtpath, 'w')


def compare_bse_tcs(filename, filetype, mail_file):
    
    phase1_start = time.time()
    
    df_filtered_11 = pd.DataFrame()
    df_orig = pd.DataFrame()
    df = pd.DataFrame()
    try:
        df = pd.read_csv(filename,header=None, converters={0:str,1:str,2:str,3:str,4:str,5:str,6:str,7:str,8:str,9:str,10:str,
                    11:str,12:str,13:str,14:str,15:str,16:str,17:str,18:str,19:str,20:str,21:str,22:str,23:str,24:str,25:str},
                    delimiter="|") 
    except pd.errors.EmptyDataError:
        print "File is empty"
        mail_file.close()
        return
    except Exception as e:
        print e
        mail_file.close()
        return
    
    df.columns = cols + [ "fill {}".format(i) for i in range(df.shape[1]-len(cols))]
    df_filtered = df[df['userid'].isin(id_list)]
    if df_filtered.empty==True:
        mail_file.close()
        return
    df_filtered['tradeid_new'] = df_filtered['tradeid'].apply(lambda x : str(x).strip().zfill(8))
    df_filtered['ordid_trdid'] = df_filtered['exchordid'].str.strip() + "_" + curr_date + df_filtered['tradeid_new']
    df_filtered_11 = df_filtered[df_filtered.tradestatus=='11']                
    df_filtered_11['exchange'] = 'BSE'
    df_notis = df_filtered_11[['exchange','tradeid_new','exchordid','ordid_trdid']]
    df_notis.index = df_notis['ordid_trdid'].astype(str)
    df_filtered.index = df_filtered['ordid_trdid']
    df_orig = df_filtered[["tradeid","tradestatus","symbol","userid","modifieddatetime",
                           "exchordid","orderdatetime"]]
    df_orig.index = df_filtered['ordid_trdid']

    print("Phase 1 : " + str(time.time() - phase1_start))
    phase2_start = time.time()
    # read TCS report
    df1 = pd.read_csv(tcsfile,header=None)
    #df1.columns = ['seqno','exchange','tradeid','exchordid']
    df1.columns = ['tradeid_new','ent_id','fi_id','exchordid','terminalid','first_ent','short_code']
    df1['ordid_trdid'] = df1['exchordid'].astype(str) + "_" + df1['tradeid_new'].astype(str)
    df1['exchange'] = 'BSE'
    df_tcs = df1[['exchange','tradeid_new','exchordid','ordid_trdid']]
    df_tcs.index = df_tcs['ordid_trdid'].astype(str)

    print("Phase 2 : " + str(time.time() - phase2_start))
    phase3_start = time.time()
    

    print "Total Duplicate records in alias file ".format(len(df_notis[df_notis.duplicated(['ordid_trdid'])]))
    print df_tcs[df_tcs.duplicated(['ordid_trdid'])]
    
    df_notis = df_notis.drop_duplicates(subset='ordid_trdid', keep="first") # drop duplicate records from alias file 


    notis_list =df_notis['ordid_trdid']
    tcs_list = df_tcs['ordid_trdid']
    diff_list = list_diff(notis_list,tcs_list)
    #if len(diff_list)==0:
    #    print "Checking TCS VS  notis"
    #    diff_list = list_diff(tcs_list, notis_list)
    print "Length of notis list: " + str(len(diff_list))

    print("Phase 3 : " + str(time.time() - phase3_start))
    
    phase4_start = time.time()
    
    df_diff = df_orig[df_orig.index.isin(diff_list)]

    if len(df_diff) != 0:
        diff_time_min = df_diff.orderdatetime.min()
        tcs_time_max = df_filtered.orderdatetime.max()
        
        diff_time = datetime.datetime.strptime(d1 +" "+ str(diff_time_min), '%Y%m%d %H:%M:%S')
        tcs_time = datetime.datetime.strptime(d1 +" "+ str(tcs_time_max), '%Y%m%d %H:%M:%S')
        if colo_alias_flag==True:
            mail_file.write("-----COLO Setup------\n\n")
            
        mail_file.write("\nReading {} FILE".format(filetype))
    	
    	mail_file.write("\n{} records : ".format(filetype) + str(len(notis_list)))
    	mail_file.write("\nTCS records : " + str(len(tcs_list)))
        if(len(tcs_list) < len(notis_list)):
            mail_file.write("\nDifference in record count : " + str(-1 * len(diff_list)))
        else:
            mail_file.write("\nDifference in record count : " + str(len(diff_list)))
    	#mail_file.write("\nDifference in record count : " + str(len(diff_list)))
    	mail_file.write("\n\nDiff min timstamp : " + str(diff_time_min))
    	mail_file.write("\n\nTCS max timstamp  : " + str(tcs_time_max))
    
    	time_diff = tcs_time - diff_time
    	mail_file.write("\n\nLast record time diff : " + str(time_diff.seconds/60) + " mins")
    	mail_file.write("\n\n")
    	outputfile = today_incr_file + curr_date + ".txt"
    	df_diff.to_csv(outputfile,index=False,header=False)
    	mail_file.close()
    	table = pd.pivot_table(df_diff, index =['userid'],values=['orderdatetime'],aggfunc=[np.min,len]) 
    	table.to_csv(mailbodytxtpath,mode='a',header=False)
    	#mail_file.write(table)
    	#mail_file.write("\n\n")
    	#mail_file.write("Notis records")
    	table1 = pd.pivot_table(df_filtered_11,index =['userid'],values=['orderdatetime'],aggfunc=[len])
    	table1.to_csv(mailbodytxtpath,mode='a',header=False)
    	#mail_file.write("\n\n")
            #mail_file.write("TCS records")
    	table2 = pd.pivot_table(df1,index =['terminalid'],values=['tradeid_new'],aggfunc=[len])
    	table2.to_csv(mailbodytxtpath,mode='a',header=False)
    	#mail_file.close()
    else:
        if datetime.datetime.now().time()>datetime.time(16,15) and len(notis_list)==len(tcs_list):
            mail_file.close()
        else:           
            mail_file.write("{} records : ".format(filetype) + str(len(notis_list)))
            mail_file.write("\nTCS records : " + str(len(tcs_list)))
            mail_file.close()
            outputfile = today_incr_file + curr_date + ".txt"
            df_diff.to_csv(outputfile,index=False,header=False)

    print("Phase 4 : " + str(time.time() - phase4_start))




def process():
    # run tcs query
    subprocess.call("/home/hadoop/checknotis_bse/runtcssql_script1.sh")
    mail_file = open(mailbodytxtpath, 'w')
    mail_file.write("-----------------BSE Exchange vs TCS------------------------------------\n\n")
    compare_bse_tcs(dropcopy_bsefile, "Exchange", mail_file)

    subprocess.call("/home/hadoop/checknotis_bse/dropcopy_vs_tcs_mailer.sh")
    print "Iteration completed...."
    

# driver code
if __name__=='__main__':
    
    while True:
        print "Processing batch...."
        stime = time.time()
        process()
        print "Process time {} ".format(time.time()- stime)
        
        if datetime.datetime.now().time() >= datetime.time(16,0):
            break
        else:
            if datetime.datetime.now().time() >= datetime.time(15,0):
                time.sleep(180)
            else:
                print "Sleep for 15 minutes"
                time.sleep(60*15)
    



#print diff_list

#df_diff = df_filtered[df_filtered.index.isin(diff_list)]



#diff_list_reverse = []

#for item in tcs_list:
#	if item not in notis_list:
#		diff_list_reverse.append(item)

#print diff_list_reverse

		
"""
notis_list_file = "notis_list.txt"
with open(notis_list_file, 'w') as f:
    for item in notis_list:
	print item
        print >> f, item

tcs_list_file = "tcs_list.txt"
with open(tcs_list_file, 'w') as f:
    for item in tcs_list:
        f.write("%s\n" % item)

diff_list_file = "diff_list.txt"
with open(diff_list_file, 'w') as f:
    for item in diff_list:
        f.write("%s\n" % item)

"""

"""
outputfile = "notis_incremental.txt"
count =0
b = io.FileIO(outputfile, 'w')
writer = io.BufferedWriter(b,buffer_size=100000000)
for key in diff_list:
	writer.write(str(df_filtered.loc[key]['tradeid']).ljust(15) + ',')
	writer.write(str(df_filtered.loc[key]['tradestatus']))
	writer.write("\n")
	count = count + 1
	print count

writer.flush()
b.close()
"""

"""
b = open(outputfile, 'w')


for key in diff_list:
	#print key
	b.write(str(df_filtered.loc[key]['tradeid']).ljust(15) + ',')
	b.write(str(df_filtered.loc[key]['tradestatus']))
	b.write("\n")

b.close()
"""
"""
with open(notisfile,"rb") as f:
    reader = csv.reader(f,delimiter=",")
    for i, line in enumerate(reader) :
        x = line
        key = str(x[21]).strip() + "_20191022" + str(x[0]).strip()
        if key in diff_list:
            #print x
            b.write(str(x)) 
            b.write("\n")

b.close()
"""
