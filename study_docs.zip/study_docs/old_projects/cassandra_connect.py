# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 15:47:03 2018

@author: Administrator
"""

from cassandra.cluster import Cluster
import pandas as pd
from dateutil import parser
import os
from time import time

download_dir = "D:\\NSEDatabase-master\\data\\"
file_name = "fo09NOV2018bhav.csv"

def pandas_factory(colnames,rows):
    return pd.DataFrame(rows,columns=colnames)

cluster = Cluster(['172.17.9.152'])
session = cluster.connect('rohit')
bhav_copy = pd.read_csv(download_dir+file_name)
#bhav_copy.dropna(axis=1, inplace=True)
bhav_copy['EXPIRY_DT'] = pd.to_datetime(bhav_copy['EXPIRY_DT'], format='%d-%b-%Y')
bhav_copy['TIMESTAMP'] = pd.to_datetime(bhav_copy['TIMESTAMP'], format='%d-%b-%Y')
bhav_copy.to_csv(download_dir + 'temp.csv', index = False)
#os.putenv("filename", '/home/hadoop/myscript/NSEBhavCopy/temp.csv')
#subprocess.call('/home/hadoop/myscript/NSEBhavCopy/store_nsebhavdata.sh')
os.remove(download_dir + 'temp.csv')

#df_filtered['tradetime'] = pd.to_datetime(df_filtered['entrydatetime'], format='%d %b %Y %H:%M:%S')
                        
#df2['date'] = str(df2['date'])
#df2['time'] = str(df2['time'])
#cluster.shutdown()
