# -*- coding: utf-8 -*-
"""
Created on Mon Mar 27 15:25:35 2023

@author: krishna
"""

import pandas as pd
import os,sys
import logging 
import time
import datetime
import warnings
warnings.filterwarnings("ignore")
import gzip
import shutil 
import pysftp
import email_utility
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None  

server = '172.17.9.149'; port = 25  # mailing server
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'

master_dir =  "D:\\Master\\"
log_path =  "D:\\Commodity\\"
berg_files = "D:\\Commodity\\"
data_dir =  "D:\\Commodity\\"
contacts_dir = ""

column=['ticker',0,3,'PX_LAST','PX_YEST_CLOSE','PX_CLOSE_1D','CHG_PCT_1D','CHG_PCT_5D','CHG_PCT_1M']


logging.basicConfig(filename=log_path+"cmdt_price_chg_{}.log".format(datetime.datetime.now().date()),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def dateparse(d):
    '''Func to parse dates'''    
    d = pd.to_datetime(d, dayfirst=True)    
    return d

      
# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)


def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
          
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1

# get Futures daily file from bloomberg SFTP
def bloomberg_file_downloader(d, ipfilenames, opfilename):
    '''Func to download file from ftp'''
    
    while 1:
        
        for ipfilename in ipfilenames:
            print(f"Looking for file {ipfilename}")
            filename = ipfilename +'.{}'.format( ''.join(str(d).split("-")) )
    
            print ('{} is working day; hence downloading file from SFTP'.format(d))
            with pysftp.Connection('sftp.bloomberg.com', username='dl789941', password='+cf,QPwXjKeG3M,N', cnopts=cnopts) as sftp:
                
                if sftp.isfile(filename)==True:
                    print ("File {} exists for today...start decompressing file ...".format(filename))
                else:
                    print (f"File {filename} not present; sleep for 30 seconds")
                    time.sleep(30)
                    continue
                
                sftp.get(".".join(filename.split(".")[:-1]))
                print ('Success: File downlaoded')
                
                if ipfilename.endswith("csv"):
                    try:
                        os.rename(ipfilename, os.path.join(berg_files, ipfilename.split(".")[0]+"_"+str(d.strftime("%Y%m%d"))+".csv"))
                        return 1
                    except FileExistsError:
                        print("File exists...")
                        return 1
    			# unzipp file 
                try:	
                    with gzip.open(".".join(filename.split(".")[:-1]),'rb') as f_in:
                        with open(os.path.join(berg_files,opfilename),'wb') as f_out:
                            shutil.copyfileobj(f_in, f_out) 
                            print ('Success')
                            
                    os.remove(ipfilename)
                    return 1        
                except Exception as e:
                    print ('Excpetion',e)


def data_preprocess(d):
    
    filename = f"getsnap_comdty_{d.strftime('%Y%m%d')}.csv"
    
    df = pd.read_csv((os.path.join(berg_files,filename)),sep='|',names=column,header=None,index_col=False)
    df = df.iloc[df[df['ticker'].str.startswith('START-OF-DATA')].index.values[0]+1: df[df['ticker'].str.startswith('END-OF-DATA')].index.values[0], :]
    df['date'] = d
    df = df[['ticker','PX_LAST','CHG_PCT_1D','CHG_PCT_5D','CHG_PCT_1M']]
    df.columns = ['ticker','Price','1D Px Chg (%)','5D Px Chg (%)','1M Px Chg (%)']
    
    return df

    
def generate_html_email(df, d):
    
    filename = os.path.join(data_dir, "output_{}.html".format(d.strftime("%Y%m%d")))
    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>       
    html_string = "<html><head><style>{css_style}</style></head><body>\
                    <p>Commodity Tracker for BBG data as on {d}. </p>".format(css_style = open("df_style.css", 'r').read(),
                                                                                            d=d)
                    
    # OUTPUT AN HTML FILE
    output_file = open(filename, 'w')
    output_file.write(html_string)
    
    df['ticker'] = "text" + df['ticker'] 
    output_file.write(df.to_html(classes='mystyle', index=False).replace(
            '<table border="1" class="dataframe mystyle">',
            '<table border="1" class="mystyle">'))
    output_file.write("</body></html>")    
    output_file.close()   

    output_file = open(filename, 'r').read().replace("&lt;","<").replace("&gt;",">")
    output_file = output_file.replace("dataframe mystyle","mystyle")
    output_file = output_file.replace('<td>text','<td class="text">')
    
    
    with open(filename, 'w') as f:
        f.write(output_file)
    
    return filename
    
    
def main(nd):
    '''Func to read files, process and do scheduling of entire process'''
        
    # read yesterdays bhavcopy file     
    d = datetime.datetime.now().date() - datetime.timedelta(days=nd)
    
    if process_run_check(d) == -1:
        logging.info('Exit: Its an holiday.')
        update_db.update_lastruntime("commodity_prices")
        return -1    
   
    # download file from bloomberg
    bloomberg_file_downloader(d, ["getsnap_comdty.csv", "getsnap_comdty.csv.gz"],
                              "getsnap_comdty_{}.csv".format(d.strftime("%Y%m%d")))
    # pre-process data
    df = data_preprocess(d)
    
    # send email
    email_utility.process_status_email(os.path.join(contacts_dir, "commodity_contacts.txt"),
                                       "Commodity prices {}".format(d.strftime("%Y%m%d")),
                                       generate_html_email(df, d))
    update_db.update_lastruntime("commodity_prices")

 
import psycopg2
from project_status_update import project_status_rt as udt
update_db= udt.postgres_updations()
update_db.update_status("commodity_prices")

    
if __name__=="__main__":
    main(0)