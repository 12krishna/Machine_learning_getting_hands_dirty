# -*- coding: utf-8 -*-
"""
Created on Wed Mar 29 15:23:19 2023

@author: Administrator
"""

import numpy as np
import pandas as pd
import logging
#from dateutil import parser
import time, datetime
import os
import warnings
from cassandra.cluster import Cluster
import cassandra_utility
import email_utility
warnings.filterwarnings("ignore")
warnings.filterwarnings("ignore", category=DeprecationWarning)

master_dir = "D:\\Master\\"
contacts_dir="D:\\Emails\\Contacts\\"
output_dir = "D:\\TradingWrap\\Output\\"
log_path  = ""

logging.basicConfig(filename=log_path+"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def dateparse1(d):
    '''Func to parse dates'''
    d = pd.to_datetime(d, dayfirst=True)
    return d


# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse1, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def previous_working_day(d):
    '''Get previous wokring day'''

    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                #print "Holiday : ",d
                d = d - datetime.timedelta(days=1)
            else:
                return d


def get_prev_nth_day(d,c):
    for i in range(0,c):
        prev=previous_working_day(d)
        d=prev
        #print d
    return d

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
          
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1


def read_data(sdate):
    
    cassandra_host_list = ["172.17.9.51"]

    cassandra_obj = cassandra_utility.CassandraUtil(host = cassandra_host_list, username='read',
                                  password='read@123', keyspace='rohit')   # this object will be used for all cassandra operations
    cassandra_obj.connect()
    cassandra_obj.set_pandas_factory()
    
    while 1:
        # get commodities data
        df = cassandra_obj.read(f"select * from commodity_prices where date='{sdate}' allow filtering;")
        if df.empty==False:
            cassandra_obj.cluster.shutdown()
            return df
        print(f"Data not present for {sdate}")
        time.sleep(60)
            

def price_chg_percent(a, b):
    
    return (a-b)*100/b if b!=0 else 0
    
def generate_html_email(df, d):
    
    df = df.to_html(classes='mystyle', index=False).replace(
            '<table border="1" class="dataframe mystyle">',
            '<table border="1" class="mystyle">')
    
    outputpathfile = os.path.join(output_dir, "output_{}.html".format(d.strftime("%Y%m%d")))
    with open(outputpathfile,'w') as f:
        f.write(df)

    output_file = open(outputpathfile, 'r').read().replace("&lt;","<").replace("&gt;",">")
    output_file = output_file.replace("dataframe mystyle","mystyle")
    output_file = output_file.replace('<td>text','<td class="text">')

    with open(outputpathfile, 'w') as f:
        f.write(output_file)

    return outputpathfile
    
    
    
    
def main(nd):
    
    # read yesterdays bhavcopy file     
    d = datetime.datetime.now().date() - datetime.timedelta(days=nd)
    
    if process_run_check(d) == -1:
       logging.info('Exit: Its an holiday.')
       return -1  
       
    df = read_data(d)
    df = df.merge(read_data(get_prev_nth_day(d, 5))[['ticker','close']].rename(columns={'close':'close_5d'}), on=['ticker'], how="left")
    df = df.merge(read_data(get_prev_nth_day(d, 25))[['ticker','close']].rename(columns={'close':'close_1m'}), on=['ticker'], how="left")
    
    df['1D Px Chg (%)'] = df[['last_traded_price','prev_close']].apply(lambda row: price_chg_percent(row['last_traded_price'], row['prev_close']) ,axis=1)
    df['5D Px Chg (%)'] = df[['last_traded_price','close_5d']].apply(lambda row: price_chg_percent(row['last_traded_price'], row['close_5d']) ,axis=1)
    df['1M Px Chg (%)'] = df[['last_traded_price','close_1m']].apply(lambda row: price_chg_percent(row['last_traded_price'], row['close_1m']) ,axis=1)
    
    # gt asset names
    df = df.merge(pd.read_csv(os.path.join(master_dir, "commodity_mappings.csv")), on=['ticker'], how="left")[['ticker',
                 'Asset','last_traded_price','1D Px Chg (%)','5D Px Chg (%)','1M Px Chg (%)']]  

    # send email
    email_utility.process_status_email(os.path.join(contacts_dir, "commodity_contacts.txt"),
                                       "Commodity prices {}".format(d.strftime("%Y%m%d")),
                                       generate_html_email(df, d))

    
    
if __name__=="__main__":
    main(0)
    

















