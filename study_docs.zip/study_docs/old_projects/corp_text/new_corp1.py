# -*- coding: utf-8 -*-
"""
Created on Wed Sep  7 11:55:55 2022

@author: GeetaV
"""
import requests
import datetime
from bs4 import BeautifulSoup
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import logging
import time
import pandas as pd
import os
import numpy as np
import urllib.request
import json
import glob
server = '172.17.9.144'; port = 25

#contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'

#contacts_dir="D:\\Emails\\Contacts\\"
path='D:\\corp_text'
output_dir='D:\\corp_text\\output'

url = 'https://dfws.bseindia.com/DataFeedService/api/DataFeed/Get_CorpAnnouncement/w' 

headers = {'Content-Type': 'application/json',
                'User-Agent':'PostmanRuntime/7.6.0',
                'Authorization':'Basic S290YWs6S290YWtAMTIz'
                }
proxy = {'host':"172.17.9.170",
                'port':'8080',
                'match':"http+https://*/*"
                }  
logging.basicConfig(filename=os.path.join(path,"Corporate_Announcement.log"),filemode="w",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

client_df=pd.read_excel(os.path.join(path,'Symbol_scrip.xlsx'))
client_df["SCRIP_CODE"]=client_df["SCRIP_CODE"].astype(str)
client_df["KEYWORDS"]=client_df["KEYWORDS"].str.upper()
key_list=client_df["KEYWORDS"].dropna(axis=0)
pattern="|".join(key_list)

def df_html(table,d):
        '''Func to create html email body'''
       # logging.info("generating html table")
      #  _font_style = "calibri"
        
        pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>
        html_string = "<html><head><style>{css_style}</style></head><body>".format(css_style = open(os.path.join(path, "df_style.css"), 'r').read())
        
        table['ATTACHMENTURL'] = table['ATTACHMENTURL'].apply(lambda x: 
                                                '<a href="{}">{}</a>'.format(x,x))#, axis=1) 
        #rating_df.drop(columns=['Rating Link'], inplace=True)
        #rating_df=rating_df[['Company Name','PDF Link','Total']]             
        result= table.to_html(classes='mystyle', index=False).replace(
                                                    '<table border="1" class="dataframe mystyle">',
                                                    '<table border="1" class="mystyle">')
        html_string += "<table><tr><td valign='top'>{}</td></tr></table>".format(result)
        html_string += "<br><br></body></html>"
            
        html_file = os.path.join(path, "corp_{}.html".format(d.strftime("%Y-%m-%d-%H")))
         
        with open(html_file,'w') as f:
            f.write(html_string)
    
        output_file = open(html_file, 'r').read().replace("&lt;","<").replace("&gt;",">")
        output_file = output_file.replace("dataframe mystyle","mystyle")
        output_file = output_file.replace('<td>text','<td class="text">')
    
        with open(html_file, 'w') as f:
            f.write(output_file)                        
                                 

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    msg['Cc']=','.join(kwargs['emails'][1])
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'attachments' in kwargs.keys():
        for attachment in kwargs['attachments']:            
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(attachment, "r").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(attachment.split("\\")[-1] ))
            msg.attach(part) 

    # read message text or html files to be appeneded in email body 
    if 'html_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['html_email'],'r').read()
        msg.attach(MIMEText(message, 'html'))
    
    if 'text_email' in kwargs.keys():
        # read html message file
        message = kwargs['text_email']
        msg.attach(MIMEText(message, 'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def email_utility(emails, subject, filename):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
    message = open(os.path.join(path,filename),'r').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
                         
    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()


def http_response_error(status):
        '''Func to display response status recieved from server'''
        
        if status == 200:
            print ('Status: {} / SUCCESS :  Request was handled successfully'.format(status))
            logging.info('Status: {} / SUCCESS :  Request was handled successfully'.format(status))
        elif status == 500:
            print ('Status: {} / UNKNOWN_ERROR : Internal Server Error- Internal server error has occurred in our platform'.format(status))
            logging.info('Status: {} / UNKNOWN_ERROR : Internal Server Error- Internal server error has occurred in our platform'.format(status))
        elif status == 503:
            print ('Status: {} / SVC_UNAVAILABLE The server is currently unable to handle the request due to a temporary overloading or maintenance of the server'.format(status))
            logging.info('Status: {} / SVC_UNAVAILABLE The server is currently unable to handle the request due to a temporary overloading or maintenance of the server'.format(status))
        elif status == 405:
            print ('Status: {} / METHOD_NOT_ALLOWED Unsupported HTTP Method: A request was made for a resource using a request method not supported by that resource  (e.g. using POST instead of GET)'.format(status))
            logging.info('Status: {} / METHOD_NOT_ALLOWED Unsupported HTTP Method: A request was made for a resource using a request method not supported by that resource  (e.g. using POST instead of GET)'.format(status))
        elif status == 400:
            print ("Status: {} / BAD REQUEST PARAMETER_ABSENT/data_invalid/data_format_rejected - There's a required parameter which is not present in the request".format(status))
            logging.info("Status: {} / BAD REQUEST PARAMETER_ABSENT/data_invalid/data_format_rejected - There's a required parameter which is not present in the request".format(status))
        elif status == 401:
            print ('Status: {} / UNAUTHORIZED: Failed to authenticate the request CONSUMER_KEY_UNKNOWN/TOKEN_INVALID/UNAUTHORIZED'.format(status))
            logging.info('Status: {} / UNAUTHORIZED: Failed to authenticate the request CONSUMER_KEY_UNKNOWN/TOKEN_INVALID/UNAUTHORIZED'.format(status))
        elif status == 572:
            print ('Status: {} / TOKEN_EXPIRED The TEMPORARY access token generated by the platform has expired and can no longer be used'.format(status))
            logging.info('Status: {} / TOKEN_EXPIRED The TEMPORARY access token generated by the platform has expired and can no longer be used'.format(status))
        elif status == 403:
            print ('Status: {} / PERMISSION_DENIED Subscriber has temporarily disallowed access to his private data'.format(status))
            logging.info('Status: {} / PERMISSION_DENIED Subscriber has temporarily disallowed access to his private data'.format(status))
        elif status == 570:
            print ('Status: {} / REQUEST_NOT_FOUND Registration request not found'.format(status))
            logging.info('Status: {} / REQUEST_NOT_FOUND Registration request not found'.format(status))
        else:
            print ('Error status: {} /'.format(status))
            logging.info('Error status: {} /'.format(status))
    

#function to get json data and perform formatting on it
def get_data(d):

    try:
        params = {"Username":"Kotak", "Password":"Kotak@123",
                  "hr":f"{d.hour}", "min":f"{d.minute}", "sec":f"{d.second}",#{d.hour}
                  "tradedt":"".join(f"{d.date()}".split("-"))}

        req = requests.post(url, headers=headers, json=params, timeout=30)            
        http_response_error(req.status_code)
        if req.status_code == 200:  
            print(req.json())
            data=req.json()
            print(type(data))
            if type(data)==dict:
                print("No Record found")
                df=pd.DataFrame()
            else:    
                df=pd.DataFrame(data)
    except Exception as e:
        logging.info(e)
        print(e)
    return df


def getting_title_data(df,d):
        print("inside getting title data function")
       # df=pd.read_excel(os.path.join(path,'All_records_2022-08-26.xlsx'))
        df=df.loc[~df['Descriptor'].str.startswith("Reg.")]
        df['TITLE1']=df['Descriptor'].str.upper()
        df=df.loc[df["SCRIP_CD"].isin(client_df["SCRIP_CODE"])]
        
        if df.empty==False:
            print("data not empty")
            if os.path.exists(os.path.join(output_dir,'Records_{}.xlsx'.format(d.date()))):
                 print("reading from alreday existing file")
                 old_df=pd.read_excel(os.path.join(output_dir,'Records_{}.xlsx'.format(d.date())))
                 newdf=df.loc[~df["AttachmentName"].isin(old_df["AttachmentName"])]
                 if newdf.empty==False:
                     print("new announcement done")
                     title_df=newdf[newdf['TITLE1'].str.contains(pattern)]           
                     if title_df.empty==False: 
                         print("data matching pattern is available")
                         title_df=title_df.drop(['TITLE1'],axis=1)
                         title_df['DATETIME']=pd.to_datetime(title_df["Tradedate"],format='%d/%m/%Y %H:%M:%S')
                         title_df=title_df.sort_values(by=['DATETIME'], ascending=False)
                         old_df=pd.concat([old_df,title_df],axis=0,ignore_index=True)
                         old_df.reset_index(drop=True,inplace=True) 
                         old_df.to_excel(os.path.join(output_dir,'Records_{}.xlsx'.format(d.date())),index=None)
                         title_df=title_df[['DT_TM','CompanyName','HeadLine','NewsBody','Descriptor','ATTACHMENTURL']]
                         df_html(title_df,d)
                         print("sending mail")
                         email_utility(get_contacts(os.path.join(path,'corp_actions_anouncement.txt')), "corporate_announcement_{}".format(d.strftime("%Y-%m-%d-%H")),"corp_{}.html".format(d.strftime("%Y-%m-%d-%H")))
        
            else:
                 print("checking first time")
                 title_df=df.loc[df['TITLE1'].str.contains(pattern)]
                 print(len(title_df))
                 if title_df.empty==False:
                     print("data matching pattern is available")
                     title_df=title_df.drop(['TITLE1'],axis=1)
                     title_df['DATETIME']=pd.to_datetime(title_df["Tradedate"],format='%d/%m/%Y %H:%M:%S')
                     title_df=title_df.sort_values(by=['DATETIME'], ascending=False)
                     print("generating file for first time")
                     title_df.to_excel(os.path.join(output_dir,'Records_{}.xlsx'.format(d.date())),index=None)
                     title_df=title_df[['DT_TM','CompanyName','HeadLine','NewsBody','Descriptor','ATTACHMENTURL']]
                     df_html(title_df,d)
                     print("sending mail")
                     email_utility(get_contacts(os.path.join(path,'corp_actions_anouncement.txt')),"corporate_announcement_{}".format(d.strftime("%Y-%m-%d-%H")),"corp_{}.html".format(d.strftime("%Y-%m-%d-%H")))
        else:
            print("empty data ") #'corp_actions_anouncement.txt')

def process_running(d):
    
    try:
        logging.info("Email: Hourly process running check")    
        file = open(os.path.join(path,"final_bse_output_{}.txt".format(d.strftime('%H'))),"w")
        file.write("<html><head></head></html>")    
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> Corporate Action Announcement hourly status: </b></p>")
        file.write("\n\n")
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'>process is running succesfully {}</p>".format(d.strftime("%y-%m-%d-%H:%M:%S")))
        file.write("\n\n")
        file.close()
        logging.info("Output txt for hourly status email compiled successfully")
    except Exception as e :
        logging.info("I/O Error in Output txt for hourly status email; exception / {} ".format(e))
        
    try:
        logging.info("Send hourly status email")
        emails = get_contacts(os.path.join(path,'checker_corp_action.txt')) # read contacts checker_corp_action.txt
        subject = "Corporate Announcement process running Alert - {0} ".format(d.strftime("%y-%m-%d-%H:%M:%S"))  #subject    
        process_email(emails=emails, subject=subject, html_email=os.path.join(path,"final_bse_output_{}.txt".format(d.strftime("%H"))))
   
        logging.info('Corporate action anouncement process running email was sent for {0}'.format(d))
    except Exception as e:
        logging.info("Error in sending email ; exception {}".format(e))






def main():
    
    d = datetime.datetime.now()-datetime.timedelta(hours=6)
    df=get_data(d)
    getting_title_data(df,d)
    d = datetime.datetime.now()-datetime.timedelta(minutes=1)
    dt="23:30:00"
   
    while d.strftime("%H:%M:%S")<dt:
        if os.path.exists(os.path.join(path,"final_bse_output_{}.txt".format(d.strftime("%H")))):
                    logging.info("Done: program running perfectly")
                    print("Done: program running perfectly")
        else:
            process_running(d)
            logging.info("Done: hourly alert email sent; program is running")
            print("Done: hourly alert email sent; program is running")
        try:
            print("sleeping for half an hour")
            time.sleep(1800)
            print("processing for date{}".format(d))          
            print("calling get_data function")
            df=get_data(d)
            if df.empty:
                print("datafarme is empty")
            else:
                print("checking condition")
                getting_title_data(df,d)          
            d = datetime.datetime.now()-datetime.timedelta(minutes=1)
            print(d)
        except Exception as e:
             print(e)
             
    files = glob.glob(os.path.join(path,'*.html')) 
    for f in files:
        os.remove(f)
    files = [f for f in os.listdir(path) if f.startswith("final_bse")]   
    for f in files:
        os.remove(os.path.join(path,f))

main()



