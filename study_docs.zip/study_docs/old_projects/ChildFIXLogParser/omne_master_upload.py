# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 10:18:21 2020

@author: krishna
"""

import os
import re
import sys
import logging
from pandas.io import sql
import pandas as pd
import numpy as np
import simplefix
import datetime
from time import time, sleep
from sqlalchemy import create_engine
import pymysql
import smtplib


# set dependency paths here
if sys.platform not in ('win32', 'cygwin', 'cli'):
    print "Linux environment dependent paths set"
    master_dir = ""
    input_dir = ""
else:
    print("Windows environment paths set")
    master_dir = "D:\\Master\\"
    input_dir = "D:\\ChildFIXLogParser\\"
    


def _write_mysql(frame, table, names, cur):
    bracketed_names = ['`' + column + '`' for column in names]
    col_names = ','.join(bracketed_names)
    wildcards = ','.join([r'%s'] * len(names))
    insert_query = "INSERT INTO %s (%s) VALUES (%s)" % (
        table, col_names, wildcards)

    data = [[None if type(y)==float and np.isnan(y) else y for y in x] for x in frame.values]

    cur.executemany(insert_query, data)
    
sql._write_mysql = _write_mysql  # over ride pandas dataframe with sql implementation



def mysql_configs():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("mysql,")[-1].split("=")[-1]) for config in f if config.startswith("mysql")]  
    return tuple(f)


def mysql_connect(mysql_host, username, password, db):    
    try:              
        sqlEngine = create_engine("mysql+pymysql://{}:{}@{}/{}".format(username, password,mysql_host,db),
                                   pool_recycle=3600)
        
        conn    = sqlEngine.connect()        
        return conn, sqlEngine
    
    except Exception as e:
        logging.error(e)
        return -1, -1


def main():
        
    
    df = pd.read_csv(input_dir+"CPCODE_Family_Details.csv", dtype=object)
    df.drop(columns=['dummy','dummy1','dummy2'], inplace=True)
    df['BSE CP CODE'] = df['BSE CP CODE'].replace('CLI','CLIENT')
    df[['CLIENT CODE', 'FAMILY CODE', 'NSE CP CODE', 'BSE CP CODE','NFO CP CODE']] = df[['CLIENT CODE', 'FAMILY CODE',
                                                          'NSE CP CODE', 'BSE CP CODE','NFO CP CODE']].astype(str)
    
    for col in df.columns:
        df.loc[df[col]=='nan',col]=None
        
    df.rename(columns={'CLIENT CODE':'client_code', 'FAMILY CODE':'family_code', 'NSE CP CODE':'nse_cp_code',
                       'BSE CP CODE':'bse_cp_code','NFO CP CODE':'nfo_cp_code'}, inplace=True)
        
    # get mysql config details
    mysql_host, username, password, db = mysql_configs()
    
    # mysql connection
    conn, sqlEngine = mysql_connect(mysql_host, username, password, db)
    if conn!=-1:
        logging.info("MYSQL: {} -> Connection success".format(mysql_host))
    
        
        
    sqlEngine.execute("drop table omne_account_master;") 
    sqlEngine.execute("CREATE TABLE IF NOT EXISTS omne_account_master (client_code varchar(255) NOT NULL PRIMARY KEY, \
                        family_code VARCHAR(255), nse_cp_code VARCHAR(255), bse_cp_code VARCHAR(255), \
                        nfo_cp_code VARCHAR(255)) ;") 
            
        
    failed=[]
    for j in range(0,len(df),1000):
    
        temp1 = df.iloc[j:j+1000,:]
        try:
            temp1.to_sql(name='omne_account_master', con=conn, if_exists = 'append', 
                  index=False)
            print "success"
        except Exception as e:
            print "Batch size 1000 error, try individual"
            for i in range(len(temp1)):
                temp = temp1.iloc[i:i+1,:]
                try:
                    temp.to_sql(name='omne_account_master', con=conn, if_exists = 'append', 
                          index=False)
                except Exception as e:
                    failed.append(temp['client_code'].values[0] + " , {}".format(e[0]))
    if len(failed)!=0:
        failed = pd.DataFrame(failed)
        failed.to_csv("failed_loads.csv")
            
        
    
    
if __name__ == "__main__":
    main() 

    
