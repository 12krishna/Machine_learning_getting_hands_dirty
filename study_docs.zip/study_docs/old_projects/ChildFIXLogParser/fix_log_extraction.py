
import os
import re
import pandas as pd
import numpy as np
import simplefix
from datetime import datetime, timedelta
from time import time
filelist = list()
start_time = time()
input_path='D:\\ChildFIXLogParser\\input\\'
outpath = 'D:\\ChildFIXLogParser\\output\\'
expr = r'8=FIX\.4\.2.*?\x0110=\d+\x01'

all_files = [r[2] for r in os.walk(input_path)]

for i in all_files[0]:
    filelist.append(input_path + i)

for i in filelist:
    file_name = i
    print file_name
    
    f = open(file_name,'r')
    if f.mode == 'r':
        content = f.readlines()
    
        base = os.path.basename(file_name)
        tempfile1_name = "tempfile1_" + str(os.path.splitext(base)[0]) +".csv"
        tempfile2_name = "tempfile2_" + str(os.path.splitext(base)[0]) +".csv"
        comp1 = base[8:11]
        comp2 = base[12:17]
        tempfile1 = open(outpath + tempfile1_name, 'w')
        tempfile2 = open(outpath + tempfile2_name, 'w')
        print tempfile1
        for line in content:
            if re.findall(expr, line):
                rx = re.findall(expr, line)
                if '49='+comp2 in rx[0]:
                    if '56='+comp1 in rx[0]:
                        if '35=8' in rx[0]:
                            x = rx[0]
                            parser = simplefix.FixParser()
                            parser.append_buffer(x)
                            msg = parser.get_message()
                                            # child order ID(11)     Original Cli ID            Symbol                 Order ID                     Last Qty                    Last Price          Execution Time              Last Market         Time in Force               Currency
                            tempfile1.write(str(msg.get(11)) + "," + str(msg.get(41)) + "," + str(msg.get(55)) + "," + str(msg.get(37)) + "," + str(msg.get(32)) + "," + str(msg.get(31)) + "," + str(msg.get(60)) + "," + str(msg.get(30)) + "," + str(msg.get(59)) + "," + str(msg.get(15)))
                            tempfile1.write("\n")
                elif '49='+comp1 in rx[0]:
                    if '56='+comp2 in rx[0]:
                        if (('35=D' in rx[0]) or ('35=G' in rx[0]) or ('35=F' in rx[0])):
                            x = rx[0]
                            parser = simplefix.FixParser()
                            parser.append_buffer(x)
                            msg = parser.get_message()
                            #               Msg type                    Cli ID              Original Cli ID             Account                 Symbol                      Ord Type                Exec Limit Price                   Side                    Exchange                    Order Qty
                            tempfile2.write(str(msg.get(35)) + "," + str(msg.get(11)) + "," + str(msg.get(41)) + "," + str(msg.get(1)) + "," + str(msg.get(55)) + "," + str(msg.get(40)) + "," + str(msg.get(44)) + "," + str(msg.get(54)) + "," + str(msg.get(100)) + "," + str(msg.get(38)) + "," + str(msg.get(58)) + "," + str(msg.get(52)))
                            tempfile2.write("\n")
        f.close()
        if ((os.stat(outpath + tempfile1_name).st_size == 0) and (os.stat(outpath + tempfile2_name).st_size == 0)):
            tempfile1.close()
            tempfile2.close()
            os.remove(outpath + tempfile1_name)
            os.remove(outpath + tempfile2_name)
            continue

        tempfile1.close()
        tempfile2.close()
        print 'done'
            
end_time = time()
print "Execution time: {0} Seconds.... ".format(end_time - start_time)