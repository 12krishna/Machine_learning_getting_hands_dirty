
import os
import re
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from time import time
inputpath = 'D:\\ChildFIXLogParser\\output\\'
outpath = 'D:\\ChildFIXLogParser\\final_output\\'


for r, d, f in os.walk(inputpath):
    for file in f:
        if (file.find("tempfile1_")!=-1):
            file_name = os.path.join(r, file)
            base = os.path.basename(file_name)[10:36]
            print file_name, base
            
            execution = pd.read_csv(inputpath + "tempfile1_" + base + ".messages.csv", header=None)
            execution.columns = ['ClientOrdID','Og_ClientOrdID_exec','Symbol','TradeId','Last Quantity','Last Price','Execution Time','Last Market','Time in Force','Currency']
            execution['Execution Time'] = pd.to_datetime(execution['Execution Time'],errors="coerce") + timedelta(hours=5,minutes=30)
            
            # storing orders data in dataframe
            orders = pd.read_csv(inputpath + "tempfile2_" + base + ".messages.csv", header=None)
            orders.columns = ['MsgType','ClientOrdID','Og_ClientOrdID','PM/Client','Symbol','OrdType','Execution Limit Price','Side', 'SecurityExchange', 'OrderQty', 'Remarks', 'Execution Decision Time']
            
            orders['Execution Decision Time'] = pd.to_datetime(orders['Execution Decision Time'], errors='coerce') + timedelta(hours=5,minutes=30)

            orders['OrdType'] = orders['OrdType'].astype(str)
#            orders.loc[orders['OrdType'] == '1', 'OrdType'] = 'MKT'
#            orders.loc[orders['OrdType'] == '2', 'OrdType'] = 'LMT'
            orders.loc[orders['Side'] == 1, 'Side'] = 'BUY'
            orders.loc[orders['Side'] == 2, 'Side'] = 'SELL'
            orders.loc[orders['SecurityExchange'] == 'NS', 'SecurityExchange'] = 'NSE'
            orders.loc[orders['SecurityExchange'] == 'BO', 'SecurityExchange'] = 'BSE'



            merged_df = pd.merge(orders, execution, how='left', on='ClientOrdID')
            merged_df['Symbol'] = merged_df['Symbol_x']
            merged_df['Liquidity Flag'] = 1
            merged_df['Last Capacity'] = 1
            
            
            merged_df = merged_df[['ClientOrdID','Og_ClientOrdID','PM/Client','OrdType','Execution Limit Price','Side','SecurityExchange','OrderQty','Remarks','Execution Decision Time','TradeId','Last Quantity','Last Price','Execution Time','Last Market','Time in Force','Currency','Liquidity Flag','Last Capacity']]
            
            merged_df.to_csv(outpath + "Merged{}.csv".format(base), index=False)
            
            print 'done'