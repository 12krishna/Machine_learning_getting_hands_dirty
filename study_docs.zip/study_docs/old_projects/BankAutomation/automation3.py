# -*- coding: utf-8 -*-
"""
Created on Wed Jul 28 10:01:08 2021

@author: krishna
"""

import pandas as pd
import sys, os
from collections import OrderedDict


input_folder = "D:\\BankAutomation\\Input\\"
output_folder = "D:\\BankAutomation\\Output\\"


def file_reader(filepath, sheet_name, skiprows, usecols):

    #skiprows = 0 if header_default==None else header_default
    usecols  = None if usecols==None else usecols
    df = pd.read_excel(filepath, sheet_name=sheet_name, skiprows=skiprows, usecols=usecols)
    return df

def read_input_format(filepath):

    data = open(filepath, "r").readlines()
    data = [ l for l in data if l.strip()!='']
    datatype = data[0].replace("\n","").strip().split("|")
    sheet_name = data[1].replace("\n","").strip()
    col_range, start_row = data[2].replace("\n","").strip().split("|")[0], data[2].replace("\n","").strip().split("|")[1]
    headers = [col.replace("\n","").strip() for col in data[3:]]
    headers_dict = OrderedDict()
    for idx, header in enumerate(headers):
        headers_dict[int(header.split("|")[1])] = {"name":header.split("|")[0], "dtype":datatype[idx]}

    return headers_dict, col_range, start_row, sheet_name

def format_data(df, header_dict):
    result = pd.DataFrame()
    for key, value in header_dict.items():
        result[value['name']] = df.iloc[:,key]
        if "." in value['dtype']:
            result[value['name']] = result[value['name']].astype(float)  # decimaL format
            result[value['name']] = result[value['name']].fillna(0.0)
            result[value['name']] = result[value['name']].round(len(value['dtype'].split(".")[1]))
        else:
            result[value['name']] = result[value['name']].fillna("")

    return result



def main():

    # read input files and process
    for r,d,f in os.walk(input_folder):
        for filename in f:
            if (filename.endswith("xlsx")) and (not filename.startswith("~")):
                print ("Processing for {}".format(r))

                # read all text files ; which is equivalent to sheet_name file format
                for _,_, f_text_files in os.walk(r):
                    for text_file in f_text_files:
                        if text_file.endswith("txt"):
                            print (text_file)

                            header_dict, col_range, start_row, sheet_name, df= '','','','',pd.DataFrame()
                            try:
                                header_dict, col_range, start_row, sheet_name = read_input_format(
                                        os.path.join(os.path.join(input_folder,os.path.basename(r)),text_file)) # read header and file format
                            except Exception as e:
                                print ("Input File format issue for {}\nError: {}".format(
                                        os.path.join(os.path.join(input_folder,os.path.basename(r)),text_file),e))
                            try:
                                df = file_reader(os.path.join(os.path.join(input_folder,os.path.basename(r)),filename), sheet_name, skiprows=int(start_row)-2, usecols=col_range)
                            except Exception as e:
                                print ("Excel file issue: {}\nError: {}".format(
                                        os.path.join(os.path.join(input_folder,os.path.basename(r)),filename), e))

                            result = format_data(df, header_dict)
                            if not os.path.exists(os.path.join(output_folder,os.path.basename(r))):
                                os.mkdir(os.path.join(output_folder,os.path.basename(r)))

                            result.to_csv(os.path.join(os.path.join(output_folder,os.path.basename(r)),text_file), sep="|", index=False)


if __name__=="__main__":
    main()