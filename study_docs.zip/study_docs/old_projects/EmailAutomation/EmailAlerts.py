# -*- coding: utf-8 -*-
"""
Created on Mon Mar  1 20:14:34 2021

@author: krishna
"""


import datetime
import time
import os
import sys
import warnings
warnings.filterwarnings("ignore")
import logging
import xlwings as xw
import pandas as pd


flag_dir = "D:\EmailAutomation"
excel_front_end_path = "PortfolioAlerts.xlsm"


logging.basicConfig(filename="debug.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")




def send_email_flag():
    '''Func to set flag
    server reads flag status
    sends email alert'''

    # mock caller for debugging
    xw.Book(excel_front_end_path).set_mock_caller()
    # book instance for reading values from excel file
    wb = xw.Book.caller()

    df = pd.DataFrame( wb.sheets[0].range('A3').expand('table').value )
    df.columns = df.iloc[0,:].values.tolist()
    df = df.iloc[1:,:]

    # set flag file
    with open(os.path.join(flag_dir, "flag.txt"),'w') as f:
        f.write("0")




def main(args):

    if args:
        if args[0] == "sendEmail":
            send_email_flag()



if __name__ == "__main__":
    main(sys.argv[1:])
