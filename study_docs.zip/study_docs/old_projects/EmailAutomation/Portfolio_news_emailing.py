# -*- coding: utf-8 -*-
"""
Created on Wed Feb 24 13:59:39 2021

@author: krishna
"""

import datetime
import time
import os
import sys
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")
import logging
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from collections import OrderedDict
import locale
locale.setlocale(locale.LC_ALL, 'en_IN')
import re


server = '172.17.9.144'; port = 25


master_dir = "D:\\Master\\"
input_dir = "D:\EmailAutomation"
output_dir = "D:\EmailAutomation\Output"

param_list = ['Net sales','EBITDA','Reported PAT','EBITDA margin (%)']
MY_ADDRESS = "KIEFNODataAnalytics@kotak.com"

logging.basicConfig(filename="test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

class NewsPortfolioAlerts():
    '''Class that consist of all def for handling email automation
    '''

    def __int__(self):

        pass

    def clientMaster(self):

        email_master = pd.read_excel(os.path.join(input_dir, "ClientMaster.xlsx"))
        email_master.dropna(how='all', inplace=True)
        email_master['Client Name'] = email_master['Client Name'].apply(lambda col: col.strip())
        email_master = email_master[email_master['Client Name']!='']
        email_master.iloc[:,email_master.columns.str.startswith("Email")] = email_master.iloc[:,
                          email_master.columns.str.startswith("Email")].applymap(
                          lambda cell: str(cell).strip().replace(';',',') )

        self.email_master = email_master


    def clientPortfolio(self):
        '''keeps track of portfolio stocks for every client
        '''

        df = pd.read_excel(os.path.join(input_dir, "Clientportfolio.xlsx"))
        df = df.applymap(lambda col: col.strip())

        self.client_portfolio = df

    def commanMessage(self):

        msg = open(os.path.join(input_dir, "Commonmessage.txt"), 'r').read()
        self.comman_msg = msg

    def newsMaster(self):

        nm = pd.read_excel(os.path.join(input_dir, "NewsMaster.xlsx"), header=None)
        nm.dropna(how='any', inplace=True)
        nm = nm.applymap(lambda col: col.strip())
        nm.columns = ['Ticker','News']

        self.news_master = nm

    def earningsPreview(self):
        '''func that parses individual tables from excel file
        '''

        df = pd.read_excel(os.path.join(input_dir, "EarningsPreview.xlsx"))
        df.columns = [i for i in range(len(df.columns))]
        df.dropna(how='all', axis=0, inplace=True)
        df.reset_index(inplace=True, drop=True)
        df = df.replace(np.nan, '')
        df.drop(columns=[4,7], inplace=True)

        # break on date row
        d_indices = [i for i, row in df.iterrows() if (type(row[1])==datetime.datetime or type(row[2])==datetime.datetime or type(row[3])==datetime.datetime)]
        d_indices1 = d_indices[1:]+[-1]

        seg_data = []
        for i, j in zip(d_indices, d_indices1):
            seg_data.append(df.iloc[i:j,:])

        ticker_table_dict = OrderedDict()
        for table in seg_data:
            table_headers = [ datetime.datetime.strftime(col, "%b-%Y") if type(col)==datetime.datetime else col for col in table.iloc[0,:].values.tolist()]


            table.reset_index(inplace=True, drop=True)
            table[8] = table[8].str.strip()
            ticker_dfindex = [ i for i,row in table.iterrows() if row[8].endswith(" IN") ]
            ticker_dfindex1 = ticker_dfindex[1:]+[-1]

            for i, j in zip(ticker_dfindex, ticker_dfindex1):
                temp = table.iloc[i:j, :]
                temp.reset_index(inplace=True, drop=True)
                symbol_desc, symbol_ticker = temp.values[0][0], temp.values[0][-1]
                temp.columns = [symbol_desc]+table_headers[1:]
                temp = temp.iloc[1:, :]
                ticker_table_dict[symbol_ticker] = temp.copy(deep=True)


            break

        self.earningsPreview_dict = ticker_table_dict

    def extractEarningsCommentary(self, etable):
        '''Takes df table
        returns any earnings commentary provided by analyst
        '''

        return [ l for l in etable['Comments'].values.tolist() if l ]

    def validateEmail(self, email):
        try:
            return re.findall('^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$', email)[0]
        except:
            return ''

    def getEmails(self, client):

        email_ids = OrderedDict()
        email_ids['To'] = [ e for e in [ self.validateEmail(email) for email in str(client['Email To']).split(",") ] if e ]
        email_ids['Cc'] = [ e for e in [ self.validateEmail(email) for email in str(client['Email Cc']).split(",") ] if e ]
        email_ids['Bcc'] = [ e for e in [ self.validateEmail(email) for email in str(client['Email Bcc']).split(",")] if e]

        return email_ids


    def triggerEmail(self, email_ids, subject, filename ):

        '''Func to send html email to clients'''

        # get total recipients
        rcpt = [ i for email in email_ids.values() for i in email]

        message = open(filename,'r').read()
        # set up the SMTP server
        s = smtplib.SMTP(host=server, port=port)

        msg = MIMEMultipart()# create a message
        # setup the parameters of the message
        msg['From']=MY_ADDRESS
        msg['To']=','.join(email_ids['To'])
        if len(email_ids['Cc'])>0:
            msg['Cc']=','.join(email_ids['Cc'])
        if len(email_ids['Bcc'])>0:
            msg['Bcc']=','.join(email_ids['Bcc'])

        msg['Subject']= subject

        msg.attach(MIMEText(message,'html'))
        s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

        s.quit()


    def processEmail(self):

        self.clientMaster()
        self.clientPortfolio()
        self.commanMessage()
        self.newsMaster()
        self.earningsPreview()

        pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>
        html_string = '<html><head><style>{css_style}</style></head><body>\
                    <p style="font-family:calibri">{comman_msg}</p>'.format(css_style = open("df_style.css", 'r').read(),
                                                comman_msg=self.comman_msg)

        # for client in client master send email
        for _, client in self.email_master.iterrows():
            logging.info(f"Preparing email for client {client['Client Name']}")

            #if client['Client Name']=='T rowe':
            #    break

            # OUTPUT AN HTML FILE
            email_op = open(os.path.join(output_dir, client['Client Name']+".html"), 'w')
            email_op.write(html_string)  # comman msg

            # get client's portfolio tickers
            tickers = self.client_portfolio[self.client_portfolio['Client name']==client['Client Name']].copy(deep=True)
            # process on every ticker
            # news for all tickers
            op_ticker_news = []
            op_earnings = []
            for ticker in tickers['Ticker'].values.tolist():
                # check news updated
                try:
                    ticker_news = self.news_master[self.news_master['Ticker']==ticker]['News'].values[0]
                    #email_op.write('<p style="font-weight: bold;">{} News <br></p><p>{}</p>'.format(ticker,ticker_news))
                    op_ticker_news.append("<b>{}:</b> {}".format(ticker, ticker_news))
                except:
                    print(f"No news for ticker {ticker}")

                # get earnings preview and commentary

                if ticker in self.earningsPreview_dict.keys():
                    df = self.earningsPreview_dict[ticker].copy(deep=True)
                    comments = self.extractEarningsCommentary(df)
                    df = df.iloc[:, :-1]
                    df = df[df.iloc[:,0].str.lower().isin([x.lower() for x in param_list])]
                    df.iloc[:-1, 1:4] = df.iloc[:, 1:4].astype(int)
                    df.iloc[:-1, 1:4] = df.iloc[:, 1:4].applymap(lambda col: f"{col:,}")
                    df.iloc[-1,1:4] = df.iloc[-1,1:4].apply(lambda col: round(col,1))
                    df.iloc[:-1,-2:] = df.iloc[:-1,-2:].applymap(lambda col: "(%.1f)"%(col*-1) if col<0 else round(col,1))

                    df.iloc[:, 0] = "text" + df.iloc[:, 0].astype(str)
                    df.iloc[:, 1:] = "num" + df.iloc[:, 1:].astype(str)

                    df = df.to_html(classes='mystyle', index=False).replace('<table border="1" class="dataframe mystyle">',
                                                        '<table border="1" class="mystyle">')
                    op_earnings.append('<p class="smaller"><b>{}:</b> {}\
                                       <br> <table style="width:100%"><tr><td>{}</td></tr></table>'.format(
                                           ticker, "\n".join(comments),df))



            if len(op_ticker_news)>0:
                print("News update for portfolio stocks")
                email_op.write('<strong style="font-family:calibri">News: </strong>')
                op_ticker_news = "<br>".join(op_ticker_news)
                email_op.write('<p class="smaller">{}</p>'.format(op_ticker_news))

            if len(op_earnings)>0:
                print("Earnings update for portfolio stocks")
                email_op.write('<br><strong style="font-family:calibri">Earnings: </strong><br>')
                for line in op_earnings:
                    email_op.write(line)

            email_op.write("</body></html>")
            email_op.close()

            output_file = open(os.path.join(output_dir, client['Client Name']+".html"), 'r').read().replace("&lt;","<").replace("&gt;",">")
            output_file = output_file.replace("dataframe mystyle","mystyle")
            output_file = output_file.replace('<td>text','<td class="text">')
            output_file = output_file.replace('<td>num','<td class="num">')

            with open(os.path.join(output_dir, client['Client Name']+".html"), 'w') as f:
                f.write(output_file)

            # send email alert
            email_ids = self.getEmails(client)
            self.triggerEmail(email_ids, 'Portfolio Alerts({})'.format(client['Client Name']),
                              os.path.join(output_dir, client['Client Name']+".html"))


def main():

    portfolio_alerts = NewsPortfolioAlerts()
    #self = NewsPortfolioEmailUtility()
    portfolio_alerts.processEmail()

if __name__=='__main__':
    main()