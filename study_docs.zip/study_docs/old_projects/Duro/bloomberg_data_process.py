# -*- coding: utf-8 -*-
"""
Created on Fri Aug 13 18:47:56 2021

@author: krishna
"""

import os, sys, subprocess
import numpy as np
import pandas as pd
import gzip
import shutil 
import pysftp
import datetime,time
import json
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None  

json_dir= open(os.path.join(os.getcwd(),"path.json"))
paths= json.load(json_dir)
windows_path = paths["windows_path"]
linux_path = paths["linux_path"]

# set dependency paths here
if sys.platform not in ('win32', 'cygwin', 'cli'):
    curr_path = "/home/hadoop/tca_futures/"
    master_dir="/home/hadoop/tca_project/master_files/"
    berg_files = "/home/hadoop/tca_futures/bloomberg_quotesfile/"
    instru_dir = "/Output/"
    scripmaster_dir = "/home/hadoop/GenInstrument/dataFiles/"
    #berg_fut_dir = ""

else:    
    curr_path = windows_path["root_path"]
    master_dir = windows_path["master_foldr_path"]
    berg_files = windows_path["bloom_quote_file_path"]
    instru_dir = windows_path["master_foldr_path"]
    scripmaster_dir = windows_path["master_foldr_path"]
    #berg_fut_dir = "D:\\MLP_TCA\\"

    
    
os.chdir(curr_path)

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


def read_instrument():
        
    instru = pd.read_csv(instru_dir+"instrument.csv")
    instru = instru[(instru['InstrumentType'].isin(['FUTIDX','FUTSTK']))&(instru['ScripType']=='NORMAL')]
    instru['expiry'] = instru['ExpiryDate'].apply(lambda row: row.split("-")[-1]+row.split("-")[1])
    # get nse symbols
    scripmaster = pd.read_csv(scripmaster_dir+"scripmaster.csv", 
                              names = ['Symbol','BseSymbol','UnnamedField3','Company Name','UnnamedField5','UnnamedField6',
                                       'ISIN','RICNse','Sedol','RICBse','UnnamedField11','BseTicker','NseTicker',
                                       'UnnamedField14','NfoTicker'] )
    scripmaster = scripmaster[['Symbol','RICNse','NseTicker','NfoTicker']]
    scripmaster.dropna(subset=['NfoTicker'], inplace=True)
    #scripmaster = scripmaster.append(pd.DataFrame([['NIFTY','NIF'], ['BANKNIFTY','NBN']], columns=['Symbol','RICNse']))
    if scripmaster[scripmaster['Symbol'].isin(['NIFTY','BANKNIFTY'])].empty==False:
        scripmaster.loc[(scripmaster['Symbol']=='NIFTY')&(scripmaster['RICNse'].isnull()), "RICNse"] = "NIF"
        scripmaster.loc[(scripmaster['Symbol']=='BANKNIFTY')&(scripmaster['RICNse'].isnull()), "RICNse"] = "NBN"
    else:
        print "Scripmaster doesnt contain BN and Nifty"
        scripmaster = scripmaster.append(pd.DataFrame([['NIFTY','NIF','NNZ','NZ'], ['BANKNIFTY','NBN','NAF','AF']], 
                                                      columns=['Symbol','RICNse','NseTicker','NfoTicker']))
        
    instru = instru.merge(scripmaster, on=['Symbol'], how='left')
    instru = instru[['Symbol', 'RICNse','NseTicker','NfoTicker','expiry','LotSize','PreviousClose']]
    instru['RICNse']=instru['RICNse'].str.replace('.',':')
    instru.dropna(inplace=True)
    
    instru.sort_values(by=['Symbol','expiry'], inplace=True)
    instru['expirymarker'] = 1
    instru['expirymarker'] = instru.groupby(by=['Symbol'])['expirymarker'].cumsum()
    #instru['NseTicker'] = instru['NseTicker'].apply(lambda row: row[1:])
    '''
    berg_futures = pd.read_excel(os.path.join(berg_fut_dir, "FutBergs.xlsx"))
    print instru.shape
    final = instru[instru['NseTicker'].isin(berg_futures['Berg'].values)]
    final = final.merge(berg_futures[['Futures','Berg']].rename(columns={'Berg':'NseTicker'}), on=['NseTicker'], how="left")
    final['NseTicker'] = final['Futures']
    final.drop(columns=['Futures'], inplace=True)
    
    final = instru[~instru['NseTicker'].isin(berg_futures['Berg'].values)].append(final)
    print final.shape
    '''
    instru['NseTicker'] = instru.apply(lambda row: row['NfoTicker']+"="+str(row['expirymarker']) if not row['NfoTicker'] in ['AF','NZ'] \
                                                          else row['NfoTicker']+str(row['expirymarker']), axis=1)
    instru.rename(columns={'NseTicker':'Berg','expiry':'200'}, inplace=True)
    
    return instru

    
# get Futures daily file from bloomberg SFTP
def bloomberg_file_downloader(d, ipfilename, opfilename):
    '''Func to download file from ftp'''
    
    # read holiday master
    holiday_master = pd.read_csv(os.path.join(master_dir, 'Holidays_2019.txt'), delimiter=',',
                                date_parser=dateparse, parse_dates={'date':[0]})       
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)    
    filename = ipfilename +'.{}'.format( ''.join(str(d).split("-")) )
    
    if d in list(holiday_master['date'].values):
        print '{} is holiday ; hence skip dumping'.format(d)
        return -1
    
    while 1:
        
        print '{} is working day; hence downloading file from SFTP, filename {}'.format(d, filename)
        with pysftp.Connection('sftp.bloomberg.com', username='dl789941', password='+cf,QPwXjKeG3M,N', cnopts=cnopts) as sftp:
            
            if sftp.isfile(filename)==True:
                print "File {} exists for today...start decompressing file ...".format(filename)
            else:
                print "File not present; sleep for 30 seconds"
                time.sleep(30)
                continue
            
            sftp.get(".".join(filename.split(".")[:-1]))
            #sftp.get(filename)
            print 'Success: File downlaoded'
            # unzipp file 
            try:	
                
                with gzip.open(".".join(filename.split(".")[:-1]),'rb') as f_in:
                    with open(os.path.join(berg_files,opfilename),'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out) 
                        print 'Success'
                        
                os.remove(ipfilename)
                break        
            except Exception as e:
                print 'Excpetion ',e
        


def dump_trade_data(d):
    
    filename = os.path.join(berg_files, 'getquotes_fut_{}.csv'.format(''.join(str(d).split("-"))))
    while 1:
        if os.path.exists(filename):
            print "Proceed parsing file"
            break
        else:
            print "Today's file not present in {}".format(berg_files)
            time.sleep(30)
            
    # code to read data from all quotes file
    df = pd.read_csv(filename, skiprows=3, header=None)
    print "Dump trade data length ",len(df)
    df = df[(df[0].str.contains("\|T\|"))]
    df = df[0].str.split('\|', expand=True)
    print df.shape
    df = df[[0,1,2,3,4,6]]
    df.columns = ['Ticker','date','time','type','price','volume']
    df['type'] = df['type'].str.strip()
    df[['price','volume']] = df[['price','volume']].apply(pd.to_numeric)
    df.dropna(subset=['volume'], inplace=True)
    df = df[(df['type']=='T') & ((df['volume'].astype(str)!='') | (df['volume'].astype(str)!=' '))]
    df.drop(columns=['type'], inplace=True)
    
    # code to read data from getquotes file
    #df = pd.read_csv(filename, skiprows=3, delimiter="|", header=None)
    #df.columns = ['Ticker','date','time','price','volume','fill','fill1','fill2']
    df['time'] = df['time'].apply(lambda row: datetime.datetime.strptime(row,"%H:%M:%S").time() if ":" in str(row) else np.nan)
    df.dropna(subset=['time'], inplace=True)    
    df = df[(df['time']>=datetime.time(9,0)) & (df['time']<=datetime.time(16,0))]
    df['symbol'] = df['Ticker'].apply(lambda row: row.split(" ")[0])
    #df['expiry'] = df['Ticker'].apply(lambda row: row.split(" ")[0].split("=")[-1] if "=" in row else row.split(" ")[0][-1])
    df['exchange'] = df['Ticker'].apply(lambda row: row.split(" ")[1] if "=" in row else "IS")
    year = open(filename, "r").readlines()[1].split(" ")[2][:4]
    df['date'] = df['date'].apply(lambda row: datetime.date(int(year), int(row.split("/")[0]), int(row.split("/")[1])))
    df.sort_values(by=['date','time'], inplace=True)
    df = df[['exchange','date','time','symbol','price','volume']]
    
    # append lot size and expiry date
    instru = read_instrument()
    df = df.merge(instru[['Berg','200','LotSize']].rename(columns={'Berg':'symbol','200':'expiry','LotSize':'lotsize'}), 
                  on=['symbol'], how="left")
    
    for _d in df['date'].unique():
        # create date-wise pickle file for nse and bse
        path = os.path.join(berg_files, _d.strftime("%Y%m%d"))
        if not os.path.exists(path):
            os.mkdir(os.path.join(path))
            
        temp = df[df['date']==_d]
        temp = temp.groupby(by=['exchange','date','time','symbol','price','expiry','lotsize'], 
                            as_index=False).agg({"volume":'sum'})
            
        if not os.path.exists(os.path.join(path, "data.pkl")):
            temp.to_pickle(os.path.join(path, "data.pkl"), compression="gzip")
        else:
            # append data
            print "Appending data to already existing pickle data"
            temp1 = pd.read_pickle(os.path.join(path, "data.pkl"), compression="gzip")
            temp = temp1.append(temp, ignore_index=True)
            temp.drop_duplicates(inplace=True)
            temp.to_pickle(os.path.join(path, "data.pkl"), compression="gzip")
            
            
    #os.remove(filename)
        
    
def dump_bidask_data(d):
    
    #opfilename = 'getquotes_bidask_{}.csv'.format(''.join(str(d).split("-")))
    #ipfilename = 'getquotes_bidask.csv.gz'
    #bloomberg_file_downloader(d, ipfilename, opfilename)
    filename = os.path.join(berg_files, 'getquotes_fut_{}.csv'.format(''.join(str(d).split("-"))))
    
    df = pd.read_csv(filename, skiprows=3, header=None)
    df = df[~(df[0].str.contains("\|T\|"))]
    df = df[0].str.split('\|', expand=True)
    df = df[[0,1,2,4,6,8,10]]
    df.columns = ['Ticker','date','time','bid_price','bid_volume','ask_price','ask_volume']
    df['time'] = df['time'].apply(lambda row: datetime.datetime.strptime(row,"%H:%M:%S").time() if ":" in str(row) else np.nan)
    df.dropna(subset=['time'], inplace=True)    
    df = df[(df['time']>=datetime.time(9,0)) & (df['time']<=datetime.time(16,0))]
    df['symbol'] = df['Ticker'].apply(lambda row: row.split(" ")[0])
    
    df['exchange'] = df['Ticker'].apply(lambda row: row.split(" ")[1] if "=" in row else "IS")
    year = open(filename, "r").readlines()[1].split(" ")[2][:4]
    df['date'] = df['date'].apply(lambda row: datetime.date(int(year), int(row.split("/")[0]), int(row.split("/")[1])))
    df.sort_values(by=['date','time'], inplace=True)
    df = df[['exchange','date','time','symbol','bid_price','bid_volume','ask_price','ask_volume']]
    
    # append lot size and expiry date
    instru = read_instrument()
    df = df.merge(instru[['Berg','200','LotSize']].rename(columns={'Berg':'symbol','200':'expiry','LotSize':'lotsize'}), 
                  on=['symbol'], how="left")
    
    #df.to_csv(os.path.join(berg_files,"bidask_{}.csv".format(''.join(str(d).split("-")))), index=False )
    #os.remove(os.path.join(berg_files, opfilename))
    stime = time.time()
    for _d in df['date'].unique():
        # create date-wise pickle file for nse and bse
        path = os.path.join(berg_files, _d.strftime("%Y%m%d"))
        if not os.path.exists(path):
            os.mkdir(os.path.join(path))
            
        temp = df[df['date']==_d]
        #temp = temp.groupby(by=['exchange','date','time','symbol','bid_price','ask_price','expiry','lotsize'], 
        #                    as_index=False).agg({"bid_volume":'sum', "ask_volume":'sum'})
            
        if not os.path.exists(os.path.join(path, "data_bidask.pkl")):
            temp.to_pickle(os.path.join(path, "data_bidask.pkl"), compression="gzip")
        else:
            # append data
            print "Appending data to already existing pickle data"
            temp1 = pd.read_pickle(os.path.join(path, "data_bidask.pkl"), compression="gzip")
            temp = temp1.append(temp, ignore_index=True)
            temp.drop_duplicates(inplace=True)
            temp.to_pickle(os.path.join(path, "data_bidask.pkl"), compression="gzip")
            
    print "Data wrtie time {}".format(time.time() - stime)
    os.remove(filename)
    
            
