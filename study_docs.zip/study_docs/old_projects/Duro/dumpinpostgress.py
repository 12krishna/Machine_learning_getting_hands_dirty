import logging, psycopg2, datetime
import pandas as pd
from sqlalchemy import create_engine
import datetime
import json
import os
import sys


os.chdir("/home/hadoop/tca_futures/Duro/")
#os.chdir(r"C:\Users\devops\PycharmProjects\tca_duro_futures")

json_dir= open(os.path.join(os.getcwd(),"path.json"))
paths= json.load(json_dir)
windows_path = paths["windows_path"]
linux_path = paths["linux_path"]

if sys.platform not in ('win32', 'cygwin', 'cli'):
    log_path = linux_path["log_path"]
else:
    log_path = windows_path["log_path"]


logging.basicConfig(filename=os.path.join(log_path,"test_{}.log".format(datetime.datetime.now().date().strftime("%Y%m%d"))),
                    level=logging.DEBUG, filemode="a",
                    format="%(asctime)s:%(levelname)s:%(message)s")


# input_dir="D:\\devansh_new\\TCA_linux_codes\\" #path to get output file of TC_17_9

def dump_in_postgres(d, df):
    d= d.strftime('%Y%m%d')
    try:
        dbname = "nse_fno"
        user = "postgres"
        password = "kotak@123"
        ip = "172.17.9.183"
        port = "5432"
        engine = create_engine('postgresql://' + user + ':' + password + '@' + ip + ':' + port + '/' + dbname,
                               echo=False)  # create connection
        con = engine.connect()
        df.columns = df.columns.str.lower()
        df.to_sql(name='tca_split_fno', con=con, if_exists='append', index=False)
        con.close()
        logging.info("successfully dumped data")
    except Exception as e:
        print "Error while inserting in db" + str(e)
        logging.info("Error while inserting in db" + str(e))

def fetch_from_postgres(d,d1):
    d= d.strftime('%Y%m%d')
    d1 = d1.strftime('%Y%m%d')
    try:
        dbname = "nse_fno"
        user = "postgres"
        password = "kotak@123"
        ip = "172.17.9.183"
        port = "5432"
        engine = create_engine('postgresql://' + user + ':' + password + '@' + ip + ':' + port + '/' + dbname,
                               echo=False)  # create connection
        con = engine.connect()

        df = pd.read_sql("Select * from tca_split_fno where date>= '{}' and date <= '{}' and setup_user = 'Duro_Fno'".format(d1,d), con= con)
        con.close()
        logging.info("successfully dumped data")
        return df

    except Exception as e:
        print "Error while inserting in db" + str(e)
        logging.info("Error while inserting in db" + str(e))

