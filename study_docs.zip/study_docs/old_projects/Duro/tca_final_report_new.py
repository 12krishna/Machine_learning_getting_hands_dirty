# -*- coding: utf-8 -*-
"""
Created on Tue Oct 12 11:46:29 2021

@author: krishna
"""

import pandas as pd
import numpy as np
import matplotlib

matplotlib.use('Agg')
from sqlalchemy import create_engine
import datetime, shutil, time, os, sys
from cassandra.cluster import Cluster
import warnings
import json
from dumpinpostgress import fetch_from_postgres
warnings.filterwarnings("ignore")

os.chdir("/home/hadoop/tca_futures/Duro/")
# os.chdir(r"C:\Users\devops\PycharmProjects\tca_duro_futures")

json_dir= open(os.path.join(os.getcwd(),"path.json"))
paths= json.load(json_dir)
windows_path = paths["windows_path"]
linux_path = paths["linux_path"]

# set dependency paths here
if sys.platform not in ('win32', 'cygwin', 'cli'):
    curr_dir = linux_path["root_path"]
    tca_output_data = linux_path["order_path"]
    output_dir = linux_path["output_path"]
    # email_dir="D:\\Emails\\Output\\"
    master_dir =linux_path["master_foldr_path"]
    config_dir = linux_path["config_path"]
else:
    curr_dir = windows_path["root_path"]
    tca_output_data = windows_path["order_path"]
    output_dir = windows_path["output_path"]
    # email_dir="D:\\Emails\\Output\\"
    master_dir = windows_path["master_foldr_path"]
    config_dir = windows_path["config_path"]


def highlight_vals_c1(val):
    if val < 0:
        color = '#FF0000'
    else:
        color = '#008000'

    return 'color: %s' % color


def dateparse(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date


# read holiday master
holiday_master = pd.read_csv(os.path.join(master_dir , 'Holidays_2019.txt'), delimiter=',', date_parser=dateparse,
                             parse_dates={'date': [0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)


def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)


def cassandra_configs_cluster():
    f = open(config_dir + "config.txt", 'r').readlines()
    f = [str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]

    from cassandra.auth import PlainTextAuthProvider

    auth_provider = PlainTextAuthProvider(username=f[1], password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)

    return cluster


def last_working(d):
    while True:
        if d in holiday_master["date"].values:
            print "Holiday : ", d
            d = d - datetime.timedelta(days=1)
        else:
            return d


def color_r_g_b(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    if val > 25:
        color = '#FF0000'  # red
    elif val >= 20 and val <= 25:
        color = 'blue'
    else:
        color = '#008000'  # green
    return 'color: %s' % color


def get_data(d, d1):
    try:
        result = fetch_from_postgres(d, d1)
        print("The dataframe has been fetched")
        result.columns = ["TradeId", "ClientOrdID", "Og_ClientOrdID", "ClientName", "Symbol", "Series", "Ticker",
                          "OrdType", "LimitPrice", "Side", "SecurityExchange", "StartTime", "EndTime", "OrderQty",
                          "SOR", "QuantityExecuted", "AvgPx","NSEExecutedQty", "BSEExecutedQty",
                          "NSEExecutedAvg", "BSEExecutedAvg", "Remarks", "Algorithm", "LastFillTime", "ArrivalTime",
                          "Tag115", "tag9271","200", "RICNse", "Berg", "LotSize", "PreviousClose", "IntervalVwap",
                          "IntervalVwapNse","IntervalVwapBse", "IntervalVwapLimit", "AvgPx_vs_IntervalVwapLimit",
                          "IntervalVwapLimitNse", "IntervalVwapLimitBse", "DayVwapLimitNse", "DayVwapLimitBse",
                          "DayVwapLimit", "DayVwap","DayVwapNse", "DayVwapBse", "DayTwap", "DayTwapNse",
                          "DayTwapBse", "IntervalTwap","IntervalTwap_minute", "IntervalTwapNse",
                          "IntervalTwapNse_minute", "IntervalTwapBse", "IntervalTwapLimit", "IntervalTwapLimit_minute",
                          "AvgPx_vs_IntervalTwapLimit",
                          "AvgPx_vs_IntervalTwapLimit_minute", "IntervalTwapLimitNse", "IntervalTwapLimitNse_minute",
                          "IntervalTwapLimitBse", "DayTwapLimit",
                          "DayTwapLimitNse", "DayTwapLimitBse", "AvgPx_vs_IntervalVwap", "AvgPx_vs_DayVwap",
                          "AvgPx_vs_DayVwapLimit",
                          "AvgPx_vs_IntervalTwap", "AvgPx_vs_IntervalTwap_minute", "AvgPx_vs_DayTwap",
                          "AvgPx_vs_DayTwapLimit", "AvgPx_vs_Pwp", "Pwp20Nse", "Pwp20Bse", "Pwp20",
                          "Pwp20Limit", "AvgPx_vs_PwpLimit", "Pwp20LimitNse", "Pwp20LimitBse", "AvgTradeSizeNse",
                          "AvgTradeSizeBse", "AvgTradeSize",
                          "IntervalVolNse", "IntervalVolBse", "IntervalVol", "IntervalVolLimitNse",
                          "IntervalVolLimitBse", "IntervalVolLimit",
                          "DayVolNse", "DayVolBse", "DayVol", "DayVolLimitNse", "DayVolLimitBse", "DayVolLimit",
                          "volExecNse_intervalVolNse",
                          "volExecBse_intervalVolBse", "volExec_vs_IntervalVol", "volExecNse_intervalVolLimitNse",
                          "volExecBse_intervalVolLimitBse",
                          "volExec_vs_IntervalVolLimit", "volExecNse_DayVolNse", "volExecBse_DayVolBse",
                          "volExec_vs_DayVol",
                          "volExecNse_DayVolLimitNse", "volExecBse_DayVolLimitBse", "volExec_vs_DayVolLimit",
                          "ArrivalPriceNse", "ArrivalPriceBse",
                          "ArrivalPrice", "AvgPx_vs_ArrivalPx", "Pwp10Nse", "Pwp10Bse", "Pwp10", "Pwp10Limit",
                          "Pwp10LimitNse", "Pwp10LimitBse",
                          "Pwp15Nse", "Pwp15Bse", "Pwp15", "Pwp15Limit", "Pwp15LimitNse", "Pwp15LimitBse", "Pwp25Nse",
                          "Pwp25Bse", "Pwp25",
                          "Pwp25Limit", "Pwp25LimitNse", "Pwp25LimitBse", "Pwp30Nse", "Pwp30Bse", "Pwp30", "Pwp30Limit",
                          "Pwp30LimitNse",
                          "Pwp30LimitBse", "close_price", "AvgPx_vs_Closepx", "spread_bps", "Date", "Setup_user"]
        return result
    except:
        print("NOT able to fetch data from the database from table: tca_split_fno")



def get_tca_split(tca):
    # add column names to the newlist
    newlist = []
    newlist = tca.columns

    # get column name ends with bse and nse and append them to the respective list
    bselist = []
    nselist = []
    for i in range(0, len(newlist)):
        if newlist[i].endswith('Bse'):
            bselist.append(newlist[i])
        if newlist[i].endswith('Nse'):
            nselist.append(newlist[i])

    # print "Bselist",bselist
    # print "Nselist",nselist
    # create pairlist and append row to it based on sor is y or n and security exchange is bse or nse
    pairlist = []
    for col, row in tca.iterrows():
        '''
        if row["SOR"]=="Y":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType',
                        'LimitPrice','Side','SecurityExchange','StartTime','EndTime','OrderQty','SOR','NSEExecutedQty',
                        'NSEExecutedQty','NSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapNse','IntervalVwapLimitNse','DayVwapLimitNse','DayVwapNse','DayTwapNse','IntervalTwapNse',
                        'IntervalTwapLimitNse','DayTwapLimitNse','Pwp20Nse','Pwp20LimitNse',
                        'Pwp10Nse','Pwp10LimitNse',
                        'Pwp15Nse','Pwp15LimitNse',
                        'Pwp25Nse','Pwp25LimitNse',
                        'Pwp30Nse','Pwp30LimitNse',
                        'AvgTradeSizeNse','IntervalVolNse',
                        'IntervalVolLimitNse','DayVolNse','DayVolLimitNse','volExecNse_intervalVolNse',
                        'volExecNse_intervalVolLimitNse','volExecNse_DayVolNse','volExecNse_DayVolLimitNse','ArrivalPrice','Tag115','tag9271']]
            result["SecurityExchange"]="NSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result) 
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                        'SecurityExchange','StartTime','EndTime','OrderQty','SOR','BSEExecutedQty','BSEExecutedQty',
                        'BSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapBse','IntervalVwapLimitBse','DayVwapLimitBse','DayVwapBse','DayTwapBse','IntervalTwapBse',
                        'IntervalTwapLimitBse','DayTwapLimitBse','Pwp20Bse','Pwp20LimitBse',
                        'Pwp10Bse','Pwp10LimitBse',
                        'Pwp15Bse','Pwp15LimitBse',
                        'Pwp25Bse','Pwp25LimitBse',
                        'Pwp30Bse','Pwp30LimitBse',
                        'AvgTradeSizeBse','IntervalVolBse',
                        'IntervalVolLimitBse','DayVolBse','DayVolLimitBse','volExecBse_intervalVolBse','volExecBse_intervalVolLimitBse',
                        'volExecBse_DayVolBse', 'volExecBse_DayVolLimitBse','ArrivalPrice','Tag115','tag9271']]
            result["SecurityExchange"]="BSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
        '''
        if row["SOR"].startswith('N') and row["SecurityExchange"] == "NSE":
            result = row[
                ['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker', 'OrdType',
                 'LimitPrice', 'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'NSEExecutedQty',
                 'NSEExecutedQty', 'NSEExecutedAvg', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime',
                 'IntervalVwapNse', 'IntervalVwapLimitNse', 'DayVwapLimitNse', 'DayVwapNse', 'DayTwapNse',
                 'IntervalTwapNse',
                 'IntervalTwapNse_minute', 'IntervalTwapLimitNse', 'IntervalTwapLimitNse_minute', 'DayTwapLimitNse',
                 'Pwp20Nse', 'Pwp20LimitNse',
                 'Pwp10Nse', 'Pwp10LimitNse',
                 'Pwp15Nse', 'Pwp15LimitNse',
                 'Pwp25Nse', 'Pwp25LimitNse',
                 'Pwp30Nse', 'Pwp30LimitNse',
                 'AvgTradeSizeNse', 'IntervalVolNse',
                 'IntervalVolLimitNse', 'DayVolNse', 'DayVolLimitNse', 'volExecNse_intervalVolNse',
                 'volExecNse_intervalVolLimitNse', 'volExecNse_DayVolNse', 'volExecNse_DayVolLimitNse', 'ArrivalPrice',
                 'Tag115', 'tag9271', 'spread_bps', 'close_price', 'AvgPx_vs_Closepx']]
            result["SecurityExchange"] = "NSE"
            result.reset_index(drop=True, inplace=True)
            result = result.T
            pairlist.append(result)
        '''
        if row["SOR"]=='N' and row["SecurityExchange"]=="BSE":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                        'SecurityExchange','StartTime','EndTime','OrderQty','SOR','BSEExecutedQty','BSEExecutedQty',
                        'BSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapBse','IntervalVwapLimitBse','DayVwapLimitBse','DayVwapBse','DayTwapBse','IntervalTwapBse',
                        'IntervalTwapLimitBse','DayTwapLimitBse','Pwp20Bse','Pwp20LimitBse',
                        'Pwp10Bse','Pwp10LimitBse',
                        'Pwp15Bse','Pwp15LimitBse',
                        'Pwp25Bse','Pwp25LimitBse',
                        'Pwp30Bse','Pwp30LimitBse',
                        'AvgTradeSizeBse','IntervalVolBse',
                        'IntervalVolLimitBse','DayVolBse','DayVolLimitBse','volExecBse_intervalVolBse','volExecBse_intervalVolLimitBse',
                        'volExecBse_DayVolBse', 'volExecBse_DayVolLimitBse','ArrivalPrice','Tag115','tag9271']]
            result["SecurityExchange"]="BSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
        '''
    final_df = pd.DataFrame(pairlist)
    final_df.columns = ['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker',
                        'OrdType', 'LimitPrice', 'Side',
                        'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'QuantityExecuted',
                        'ExecutedQty',
                        'AvgPx', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime',
                        'IntervalVwap', 'IntervalVwapLimit', 'DayVwapLimit', 'DayVwap', 'DayTwap', 'IntervalTwap',
                        'IntervalTwap_minute',
                        'IntervalTwapLimit', 'IntervalTwapLimit_minute', 'DayTwapLimit', 'Pwp20', 'Pwp20Limit',
                        'Pwp10', 'Pwp10Limit',
                        'Pwp15', 'Pwp15Limit',
                        'Pwp25', 'Pwp25Limit',
                        'Pwp30', 'Pwp30Limit',
                        'AvgTradeSize', 'IntervalVol',
                        'IntervalVolLimit', 'DayVol', 'DayVolLimit', 'volExec_intervalVol', 'volExec_intervalVolLimit',
                        'volExec_DayVol', 'volExec_DayVolLimit', 'ArrivalPrice', 'Tag115', 'tag9271', 'spread_bps',
                        'close_price', 'AvgPx_vs_Closepx']

    '''create two dataframes one for summary calculation other to write in excel'''

    final_write = final_df[
        ['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker', 'OrdType',
         'LimitPrice', 'Side',
         'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'QuantityExecuted', 'ExecutedQty',
         'AvgPx', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime',
         'IntervalVwap', 'IntervalVwapLimit', 'DayVwapLimit', 'DayVwap', 'DayTwap', 'IntervalTwap',
         'IntervalTwap_minute',
         'IntervalTwapLimit', 'IntervalTwapLimit_minute', 'DayTwapLimit', 'Pwp20', 'Pwp20Limit',
         'Pwp10', 'Pwp10Limit',
         'Pwp15', 'Pwp15Limit',
         'Pwp25', 'Pwp25Limit',
         'Pwp30', 'Pwp30Limit', 'AvgTradeSize', 'IntervalVol',
         'IntervalVolLimit', 'DayVol', 'DayVolLimit', 'volExec_intervalVol', 'volExec_intervalVolLimit',
         'volExec_DayVol', 'volExec_DayVolLimit', 'ArrivalPrice', 'Tag115', 'tag9271', 'spread_bps',
         'close_price', 'AvgPx_vs_Closepx']]

    final_write.reset_index(drop=True, inplace=True)
    # final_write.to_excel("final_write.xlsx",index=False)
    return final_write


def f(x):
    d = {}
    d['DayVwap'] = x['DayVwap'].values[0]
    d['pwp30values'] = (x['pwp30values']).values[-1]
    d['pwp25values'] = (x['pwp25values']).values[-1]
    d['pwp20values'] = (x['pwp20values']).values[-1]
    d['pwp15values'] = (x['pwp15values']).values[-1]
    d['pwp10values'] = (x['pwp10values']).values[-1]
    d['Ticker'] = x['Ticker'].values[0]
    d['TradeId'] = x['TradeId'].values[0]
    d['TWAPvalues'] = (x['TWAPvalues']).sum()
    d['TWAPvalues_minute'] = (x['TWAPvalues_minute']).sum()
    d['IntervalVol'] = (x['IntervalVol']).sum()
    d['VWAPvalues'] = (x['VWAPvalues']).sum()
    d['DayVwap'] = x['DayVwap'].values[0]
    d['values'] = (x['values']).sum()
    d['QuantityExecuted'] = x['QuantityExecuted'].sum()
    d['DayVol'] = x['DayVol'].values[0]
    d['SecurityExchange'] = x['SecurityExchange'].values[0]
    d['ClientName'] = x['ClientName'].values[0]
    d['tag9271'] = x['tag9271'].values[0]
    d['Symbol'] = x['Symbol'].values[0]
    d['Side'] = x['Side'].values[0]
    d['ArrivalPrice'] = x['ArrivalPrice'].values[0]
    # d['ArrivalPrice_on_amend'] = x['ArrivalPrice'].values[-1]
    d['ArrivalPrice_on_amend'] = round(np.average(x['ArrivalPrice'], weights=x['values']), 4) if x[
                                                                                                     'values'].sum() > 0 else \
    x['ArrivalPrice'].values[-1]
    d['StartTime'] = x['StartTime'].values[0]
    d['LastFillTime'] = x['LastFillTime'].values[-1]
    d['Tag115'] = x['Tag115'].values[0]
    d['OrdType'] = x['OrdType'].values[0]
    d['Pwp10'] = x['Pwp10'].values[-1]
    d['Pwp15'] = x['Pwp15'].values[-1]
    d['Pwp20'] = x['Pwp20'].values[-1]
    d['Pwp25'] = x['Pwp25'].values[-1]
    d['Pwp30'] = x['Pwp30'].values[-1]

    d['IntervalVolLimitpwp10values'] = (x['pwp10values']).values[-1]
    d['IntervalVolLimitpwp15values'] = (x['pwp15values']).values[-1]
    d['IntervalVolLimitpwp20values'] = (x['pwp20values']).values[-1]
    d['IntervalVolLimitpwp25values'] = (x['pwp25values']).values[-1]
    d['IntervalVolLimitpwp30values'] = (x['pwp30values']).values[-1]

    d['IntervalVolLimit'] = x['IntervalVolLimit'].sum()
    d['Algorithm'] = x['Algorithm'].values[-1]
    d['spread_bps'] = round(np.average(x['spread_bps'], weights=x['values']), 4) if x['values'].sum() > 0 else 0
    # d['spread_bps'] = round(np.mean(x['spread_bps']),4)
    d['OrderQty'] = x['OrderQty'].values[-1]

    temp = x[['LastFillTime', 'Start Time', 'values']]
    temp['duration'] = temp.apply(
        lambda row: (pd.to_datetime(row['LastFillTime']) - row['Start Time']).total_seconds() / 60, axis=1)
    d['duration'] = round(np.average(temp['duration'], weights=temp['values']), 2) if x['values'].sum() > 0 else 0

    d['close_price'] = x['close_price'].values[-1]
    d['usd_inr'] = x['usd_inr'].values[-1]

    return pd.Series(d, index=['DayVwap', 'pwp30values', 'pwp25values', 'pwp20values', 'pwp15values', 'pwp10values',
                               'Ticker', 'TradeId', 'TWAPvalues', 'TWAPvalues_minute', 'IntervalVol', 'VWAPvalues',
                               'DayVwap', 'values',
                               'QuantityExecuted', 'DayVol', 'SecurityExchange', 'ClientName', 'tag9271', 'Symbol',
                               'Side', 'ArrivalPrice', 'ArrivalPrice_on_amend', 'StartTime', 'LastFillTime', 'Tag115',
                               'OrdType',
                               'Pwp10', 'Pwp15', 'Pwp20', 'Pwp25', 'Pwp30', 'IntervalVolLimitpwp10values',
                               'IntervalVolLimitpwp15values',
                               'IntervalVolLimitpwp20values', 'IntervalVolLimitpwp25values',
                               'IntervalVolLimitpwp30values',
                               'IntervalVolLimit', 'Algorithm', 'spread_bps', 'OrderQty', 'duration', 'close_price',
                               'usd_inr'])


def calc_slippage(side, avgpx, param_px):
    if side == 'BUY':
        return -1 * (avgpx - param_px) if param_px != 0 else 0
    else:
        return (avgpx - param_px) if param_px != 0 else 0


def get_combine_op(df):
    '''processing for Dayvwap and volumelimit and daylimit and dates done in this code'''

    df['Start Time'] = pd.to_datetime(df['StartTime'])
    df['Date'] = df['Start Time'].dt.date
    df['values'] = df['AvgPx'] * df['QuantityExecuted']
    df['VWAPvalues'] = df['IntervalVwapLimit'] * df['IntervalVolLimit']
    df['pwp20values'] = df['Pwp20Limit']
    df['pwp10values'] = df["Pwp10Limit"]
    df['pwp15values'] = df["Pwp15Limit"]
    df['pwp25values'] = df["Pwp25Limit"]
    df['pwp30values'] = df["Pwp30Limit"]
    df['TWAPvalues'] = df['IntervalTwapLimit'] * df['IntervalVolLimit']
    df['TWAPvalues_minute'] = df['IntervalTwapLimit_minute'] * df['IntervalVolLimit']

    # get dollar values
    dollar_values = get_dollar_values(min(df['Date']), max(df['Date']))
    df = df.merge(dollar_values, on=['Date'], how="left")

    df['uniquetdse'] = df['TradeId'] + df['SecurityExchange']
    cmpa = df[["pwp20values", "pwp15values", "pwp20values", "pwp25values", "pwp30values", "ClientName"]]
    # cmpa.to_excel("cmpa.xlsx",index=False)
    #    combined_group = df.groupby(['uniquetdse','Date'], as_index=False).agg({'DayVwap':'first','pwp30values':'sum','pwp25values':'sum','pwp15values':'sum','pwp10values':'sum','Ticker':'first','TradeId':'first','TWAPvalues':'sum','IntervalVol':'sum','pwp20values':'sum','VWAPvalues':'sum','DayVwap':'first','QuantityExecuted':'sum','DayVol':'first','IntervalVolLimit':'sum','SecurityExchange':'first','ClientName':'first','Symbol':'first','Side':'first','ArrivalPrice':'first','values':'sum','StartTime':'first','LastFillTime':'last','Tag115':'first','OrdType':'first','Pwp10':'sum','Pwp15':'sum','Pwp20':'sum','Pwp25':'sum','Pwp30':'sum'})
    combined_group = df.groupby(['uniquetdse', 'Date'], as_index=False).apply(f)
    combined_group = combined_group.loc[:, ~combined_group.columns.duplicated()]

    combined_group.to_excel("combined_group.xlsx", index=False)
    # print combined_group
    combined_group['wt_AvgPx'] = combined_group['values'] / combined_group['QuantityExecuted']
    combined_group['wt_VWAP'] = combined_group['VWAPvalues'] / combined_group['IntervalVolLimit']
    combined_group['wt_TWAP'] = combined_group['TWAPvalues'] / combined_group['IntervalVolLimit']
    combined_group['wt_TWAP_minute'] = combined_group['TWAPvalues_minute'] / combined_group['IntervalVolLimit']
    combined_group['wt_20PWP'] = combined_group['pwp20values']
    combined_group['wt_10PWP'] = combined_group['pwp10values']
    combined_group['wt_15PWP'] = combined_group['pwp15values']
    combined_group['wt_25PWP'] = combined_group['pwp25values']
    combined_group['wt_30PWP'] = combined_group['pwp30values']

    # round wt_avg_px and other paramter prices to 4 digits
    combined_group.iloc[:, -8:] = combined_group.iloc[:, -8:].round(4)

    combined_group.fillna(0, inplace=True)
    combined_group.sort_values(by=['Date', 'Symbol', 'TradeId'], inplace=True)

    # calculating parameters
    combined_group['wtTWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_TWAP']) / combined_group[
        'wt_TWAP']) * 10000
    combined_group['wtTWAP_minute_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_TWAP_minute']) /
                                                combined_group['wt_TWAP_minute']) * 10000
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP']) / combined_group[
        'wt_VWAP']) * 10000
    combined_group['wt10PWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_10PWP']) / combined_group[
        'wt_10PWP']) * 10000
    combined_group['wt15PWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_15PWP']) / combined_group[
        'wt_15PWP']) * 10000
    combined_group['wt20PWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_20PWP']) / combined_group[
        'wt_20PWP']) * 10000
    combined_group['wt25PWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_25PWP']) / combined_group[
        'wt_25PWP']) * 10000
    combined_group['wt30PWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_30PWP']) / combined_group[
        'wt_30PWP']) * 10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice']) /
                                          combined_group['ArrivalPrice']) * 10000
    combined_group['wtArrPxamend_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice_on_amend']) /
                                               combined_group['ArrivalPrice_on_amend']) * 10000
    combined_group['wtdayVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['DayVwap']) / combined_group[
        'DayVwap']) * 10000
    combined_group['close_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['close_price']) / combined_group[
        'close_price']) * 10000

    # round percentages bps to 2 digits
    combined_group.iloc[:, -12:] = combined_group.iloc[:, -12:].round(2)

    # difference per share
    # if certain ticks are missing then, consider the avgpx as the paramter; i.e. consider zero slippage
    '''
    combined_group['arrival_diff_pershare'] = np.where(combined_group['Side']=='BUY', -1*(combined_group['wt_AvgPx'] - combined_group['ArrivalPrice']),
                                                      (combined_group['wt_AvgPx'] - combined_group['ArrivalPrice']) )
    combined_group['twap_diff_pershare'] = np.where(combined_group['Side']=='BUY', -1*(combined_group['wt_AvgPx'] - combined_group['wt_TWAP']),
                                                      (combined_group['wt_AvgPx'] - combined_group['wt_TWAP']) )
    combined_group['vwap_diff_pershare'] = np.where(combined_group['Side']=='BUY', -1*(combined_group['wt_AvgPx'] - combined_group['wt_VWAP']),
                                                      (combined_group['wt_AvgPx'] - combined_group['wt_VWAP']) )
    combined_group['dayvwap_diff_pershare'] = np.where(combined_group['Side']=='BUY', -1*(combined_group['wt_AvgPx'] - combined_group['DayVwap']),
                                                      (combined_group['wt_AvgPx'] - combined_group['DayVwap']) )
    combined_group['pwp20_diff_pershare'] = np.where(combined_group['Side']=='BUY', -1*(combined_group['wt_AvgPx'] - combined_group['wt_20PWP']),
                                                      (combined_group['wt_AvgPx'] - combined_group['wt_20PWP']) )
    '''
    # handling slippages for missing ticks
    combined_group['arrival_diff_pershare'] = combined_group[['Side', 'wt_AvgPx', 'ArrivalPrice']].apply(
        lambda row: calc_slippage(row['Side'], row['wt_AvgPx'], row['ArrivalPrice']), axis=1)
    combined_group['arrival_amend_diff_pershare'] = combined_group[['Side', 'wt_AvgPx', 'ArrivalPrice_on_amend']].apply(
        lambda row: calc_slippage(row['Side'], row['wt_AvgPx'], row['ArrivalPrice_on_amend']), axis=1)
    combined_group['twap_diff_pershare'] = combined_group[['Side', 'wt_AvgPx', 'wt_TWAP']].apply(
        lambda row: calc_slippage(row['Side'], row['wt_AvgPx'], row['wt_TWAP']), axis=1)
    combined_group['twap_minute_diff_pershare'] = combined_group[['Side', 'wt_AvgPx', 'wt_TWAP_minute']].apply(
        lambda row: calc_slippage(row['Side'], row['wt_AvgPx'], row['wt_TWAP_minute']), axis=1)
    combined_group['vwap_diff_pershare'] = combined_group[['Side', 'wt_AvgPx', 'wt_VWAP']].apply(
        lambda row: calc_slippage(row['Side'], row['wt_AvgPx'], row['wt_VWAP']), axis=1)
    combined_group['dayvwap_diff_pershare'] = combined_group[['Side', 'wt_AvgPx', 'DayVwap']].apply(
        lambda row: calc_slippage(row['Side'], row['wt_AvgPx'], row['DayVwap']), axis=1)
    combined_group['pwp20_diff_pershare'] = combined_group[['Side', 'wt_AvgPx', 'wt_20PWP']].apply(
        lambda row: calc_slippage(row['Side'], row['wt_AvgPx'], row['wt_20PWP']), axis=1)
    combined_group['close_diff_pershare'] = combined_group[['Side', 'wt_AvgPx', 'close_price']].apply(
        lambda row: calc_slippage(row['Side'], row['wt_AvgPx'], row['close_price']), axis=1)

    combined_group.iloc[:, -8:] = combined_group.iloc[:, -8:].round(4)

    # difference amount
    combined_group['arrival_diff_amount'] = combined_group['arrival_diff_pershare'] * combined_group['QuantityExecuted']
    combined_group['arrival_amend_diff_amount'] = combined_group['arrival_amend_diff_pershare'] * combined_group[
        'QuantityExecuted']
    combined_group['twap_diff_amount'] = combined_group['twap_diff_pershare'] * combined_group['QuantityExecuted']
    combined_group['twap_minute_diff_amount'] = combined_group['twap_minute_diff_pershare'] * combined_group[
        'QuantityExecuted']
    combined_group['vwap_diff_amount'] = combined_group['vwap_diff_pershare'] * combined_group['QuantityExecuted']
    combined_group['dayvwap_diff_amount'] = combined_group['dayvwap_diff_pershare'] * combined_group['QuantityExecuted']
    combined_group['pwp20_diff_amount'] = combined_group['pwp20_diff_pershare'] * combined_group['QuantityExecuted']
    combined_group['close_diff_amount'] = combined_group['close_diff_pershare'] * combined_group['QuantityExecuted']

    combined_group.iloc[:, -8:] = combined_group.iloc[:, -8:].round(2)
    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)

    # buy side parameters
    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_VWAP'] != 0), \
                           'wtVWAP_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wtVWAP_vs_AvgPx']
    except:
        print "Length mismatch"
    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_TWAP'] != 0), \
                           'wtTWAP_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wtTWAP_vs_AvgPx']
    except:
        print "Length mismatch"

    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_TWAP_minute'] != 0), \
                           'wtTWAP_minute_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wtTWAP_minute_vs_AvgPx']
    except:
        print "Length mismatch"

    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_10PWP'] != 0), \
                           'wt10PWP_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wt10PWP_vs_AvgPx']
    except:
        print "Length mismatch"
    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_15PWP'] != 0), \
                           'wt15PWP_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wt15PWP_vs_AvgPx']
    except:
        print "Length mismatch"
    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_20PWP'] != 0), \
                           'wt20PWP_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wt20PWP_vs_AvgPx']
    except:
        print "Length mismatch"
    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_25PWP'] != 0), \
                           'wt25PWP_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wt25PWP_vs_AvgPx']
    except:
        print "Length mismatch"
    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_30PWP'] != 0), \
                           'wt30PWP_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wt30PWP_vs_AvgPx']
    except:
        print "Length mismatch"
    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['ArrivalPrice'] != 0), \
                           'wtArrPx_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wtArrPx_vs_AvgPx']
    except:
        print "Length mismatch"
    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['ArrivalPrice_on_amend'] != 0), \
                           'wtArrPxamend_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wtArrPxamend_vs_AvgPx']
    except:
        print "Length mismatch"

    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['DayVwap'] != 0), \
                           'wtdayVWAP_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'wtdayVWAP_vs_AvgPx']
    except:
        print "Length mismatch"

    try:
        combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['close_price'] != 0), \
                           'close_vs_AvgPx'] = (-1) * combined_group.loc[
            combined_group['Side'] == 'BUY', 'close_vs_AvgPx']
    except:
        print "Length mismatch"

    combined_group.reset_index(drop=True, inplace=True)
    combined_group["StartTime"] = pd.to_datetime(combined_group["StartTime"], format='%Y%m%d %H:%M:%S')
    combined_group["LastFillTime"] = pd.to_datetime(combined_group["LastFillTime"], format='%Y%m%d %H:%M:%S.%f')
    # new data frame with split value columns
    combined_group["Starttime"] = combined_group["StartTime"].dt.time
    combined_group["LastFillTime"] = combined_group["LastFillTime"].dt.time
    combined_group["TradeDate"] = combined_group["StartTime"].dt.date
    combined_group[["Starttime", "LastFillTime"]] = combined_group[["Starttime", "LastFillTime"]].astype(str)
    combined_group['percent_day_vol'] = combined_group["QuantityExecuted"] / combined_group["DayVol"] * 100
    combined_group['percent_interval_vol'] = combined_group["QuantityExecuted"] / combined_group[
        "IntervalVolLimit"] * 100

    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)
    #     combined_group.sort_values(by='Date',ascending=True, inplace=True)

    combined_group['IVol'] = np.where(combined_group['percent_interval_vol'] <= 10.00, 10,
                                      np.where((combined_group['percent_interval_vol'] > 10.00) & (
                                                  combined_group['percent_interval_vol'] <= 15.00), 15,
                                               np.where((combined_group['percent_interval_vol'] > 15.00) & (
                                                           combined_group['percent_interval_vol'] <= 20.00), 20,
                                                        np.where((combined_group['percent_interval_vol'] > 20.00) & (
                                                                    combined_group['percent_interval_vol'] <= 25.00),
                                                                 25,
                                                                 30))))
    combined_group['IVolpwp'] = np.where(combined_group['percent_interval_vol'] <= 10.00, combined_group['wt_10PWP'],
                                         np.where((combined_group['percent_interval_vol'] > 10.00) & (
                                                     combined_group['percent_interval_vol'] <= 15.00),
                                                  combined_group['wt_15PWP'],
                                                  np.where((combined_group['percent_interval_vol'] > 15.00) & (
                                                              combined_group['percent_interval_vol'] <= 20.00),
                                                           combined_group['wt_20PWP'],
                                                           np.where((combined_group['percent_interval_vol'] > 20.00) & (
                                                                       combined_group['percent_interval_vol'] <= 25.00),
                                                                    combined_group['wt_25PWP'],
                                                                    combined_group['wt_30PWP']))))

    combined_group['ivolpwpper'] = np.where(combined_group['percent_interval_vol'] <= 10.00,
                                            combined_group['wt10PWP_vs_AvgPx'],
                                            np.where((combined_group['percent_interval_vol'] > 10.00) & (
                                                        combined_group['percent_interval_vol'] <= 15.00),
                                                     combined_group['wt15PWP_vs_AvgPx'],
                                                     np.where((combined_group['percent_interval_vol'] > 15.00) & (
                                                                 combined_group['percent_interval_vol'] <= 20.00),
                                                              combined_group['wt20PWP_vs_AvgPx'],
                                                              np.where(
                                                                  (combined_group['percent_interval_vol'] > 20.00) & (
                                                                              combined_group[
                                                                                  'percent_interval_vol'] <= 25.00),
                                                                  combined_group['wt25PWP_vs_AvgPx'],
                                                                  combined_group['wt30PWP_vs_AvgPx']))))

    # get difference per share and amount for pwp percent
    combined_group['pwp_diff_pershare'] = np.where(combined_group['Side'] == 'BUY',
                                                   -1 * (combined_group['wt_AvgPx'] - combined_group['IVolpwp']),
                                                   (combined_group['wt_AvgPx'] - combined_group['IVolpwp']))
    combined_group.iloc[:, -1] = combined_group.iloc[:, -1].round(4)

    # difference amount
    combined_group['pwp_diff_amount'] = combined_group['pwp_diff_pershare'] * combined_group['QuantityExecuted']

    combined_group = combined_group[combined_group['QuantityExecuted'] != 0]

    return combined_group


def get_vs_relevant_benchmark(df):
    total_executed_value = np.sum(df['wt_AvgPx'] * df['QuantityExecuted'])
    if total_executed_value > 0:
        vs_benchmark = (df[df['Algorithm'] == 'TWAP']['twap_diff_amount'].sum() + df[df['Algorithm'] == 'POV'][
            'pwp_diff_amount'].sum() + \
                        df[df['Algorithm'] == 'MOC']['close_diff_amount'].sum() + \
                        df[~df['Algorithm'].isin(['TWAP', 'POV', 'MOC'])][
                            'vwap_diff_amount'].sum()) / total_executed_value
        vs_benchmark = round(vs_benchmark * 10000, 2)
        # minute
        vs_benchmark_minute = (df[df['Algorithm'] == 'TWAP']['twap_minute_diff_amount'].sum() +
                               df[df['Algorithm'] == 'POV']['pwp_diff_amount'].sum() + \
                               df[df['Algorithm'] == 'MOC']['close_diff_amount'].sum() + \
                               df[~df['Algorithm'].isin(['TWAP', 'POV', 'MOC'])][
                                   'vwap_diff_amount'].sum()) / total_executed_value
        vs_benchmark_minute = round(vs_benchmark_minute * 10000, 2)

        return vs_benchmark, vs_benchmark_minute
    else:
        return 0, 0


def final_output(df, tag115, lotsize_df, ord_type):
    '''function to get the final dataframe'''

    if ord_type == 'dma':
        df = df[df['Algorithm'] != 'None']

    vs_benchmark, vs_benchmark_minute = get_vs_relevant_benchmark(df)

    df.rename(columns={'Ticker': 'Security', 'OrdType': 'Order Type', 'QuantityExecuted': 'Shares',
                       'wt_AvgPx': 'Avg Trade Price',
                       'ArrivalPrice': 'Arrival Price', 'wt_VWAP': 'Interval VWAP Price',
                       'DayVwap': 'Full Day VWAP Price',
                       'wt_20PWP': 'PWP20', 'wt_TWAP': 'Interval TWAP Price',
                       'wt_TWAP_minute': 'Interval TWAP Price (1 min)'}, inplace=True)
    df['Total Value'] = df['Shares'] * df['Avg Trade Price']
    df['Total Value'] = df['Total Value'].round(2)
    df["Start - End Time"] = df["Starttime"] + '-' + df["LastFillTime"].str.split('.', n=1, expand=True)[0]

    diff_amount = pd.DataFrame(df.iloc[:, df.columns.str.endswith('_diff_amount')].sum(axis=0))
    diff_amount[0] = diff_amount[0] * 1.0 * 10000 / (df['Total Value'].sum())
    diff_amount = diff_amount.T
    diff_amount = diff_amount.round(2)

    # get algo wise summary
    algo_summary = df.set_index('Algorithm')
    algo_summary = algo_summary.iloc[:, algo_summary.columns.str.endswith('_diff_amount')].reset_index()
    algo_summary = (algo_summary.groupby(by=['Algorithm'], as_index=False).sum()).merge(df[['Algorithm',
                                                                                            'Total Value',
                                                                                            'TradeId']].groupby(
        by=['Algorithm'], as_index=False).agg({"Total Value": "sum", "TradeId": "count"}),
                                                                                        on=['Algorithm'], how="left")

    for col in algo_summary.columns:
        if col.endswith("_amount"):
            print col
            algo_summary[col] = algo_summary[[col, "Total Value"]].apply(
                lambda row: round(row[col] * 10000.0 / row['Total Value'], 2) \
                    if row['Total Value'] != 0 else 0, axis=1)

    algo_summary['Total Value'] = algo_summary['Total Value'].apply(lambda row: round(row / 10 ** 7, 4))
    algo_summary.rename(columns={'TradeId': 'Order Count', 'Total Value': 'Total Value (Cr)'}, inplace=True)
    algo_summary = algo_summary.set_index('Algorithm').T

    df.rename(columns={"percent_day_vol": "% of Day's Volume", "percent_interval_vol": "% Interval Volume",
                       "TradeDate": "Trade Date",
                       'wtVWAP_vs_AvgPx': '% from Interval VWAP', 'wtArrPx_vs_AvgPx': '% from Arrival',
                       "wtArrPxamend_vs_AvgPx": "% from Arrival (amend)",
                       "ArrivalPrice_on_amend": "ArrivalPrice (amend)", 'wt20PWP_vs_AvgPx': '% from PWP20',
                       "spread_bps": "Bid/Ask spread (bps)", "duration": "Duration (minutes)",
                       'wtdayVWAP_vs_AvgPx': '% from Full Day VWAP', 'wtTWAP_vs_AvgPx': '% from Interval TWAP',
                       'wtTWAP_minute_vs_AvgPx': '% from Interval TWAP (1 min)', 'close_vs_AvgPx': '% from ClosePrice',
                       'close_price': 'ClosePrice'}, inplace=True)

    lotsize_df.drop_duplicates(inplace=True)
    df_sample = df.merge(lotsize_df, on=['Security', 'Trade Date'], how="left")  # merge lot size
    df_sample['Traded lots'] = df_sample[['LotSize', 'Shares']].apply(
        lambda row: row['Shares'] / row['LotSize'] if row['Shares'] != 0 else 0, axis=1)
    df_sample = df_sample[
        ["Trade Date", "Security", "Side", "Shares", "Traded lots", "Total Value", "Avg Trade Price", "Arrival Price",
         "% from Arrival", "ArrivalPrice (amend)", "% from Arrival (amend)", "Interval TWAP Price",
         "% from Interval TWAP",
         "Interval TWAP Price (1 min)", "% from Interval TWAP (1 min)", "Interval VWAP Price", "% from Interval VWAP",
         "Full Day VWAP Price", "% from Full Day VWAP", "% of Day's Volume", "% Interval Volume", "PWP20",
         "% from PWP20",
         'ClosePrice', '% from ClosePrice', "Start - End Time", "Tag115", "Bid/Ask spread (bps)", "Duration (minutes)",
         "usd_inr", 'Algorithm', 'TradeId']]
    df_sample['% from nearest PWP'] = df["ivolpwpper"]

    # shares_sum=df_sample["Shares"].sum()
    # shares_sum="{0:.4f}".format(shares_sum)
    total_value_sum = df_sample["Total Value"].sum()
    total_value_sum = "{0:,.2f}".format(total_value_sum)

    df_sample['PWP (rounded to nearest 5 of % Interval Vol)'] = df["IVol"]
    df_sample['Tag115'] = df["Tag115"]
    df_sample['Exchange'] = df["SecurityExchange"]

    df_sample["ivolpwpper"] = df["IVolpwp"]
    df_sample["ivolpwpper"] = df_sample["ivolpwpper"].astype(float)

    df_sample.to_excel(os.path.join(output_dir , 'complete_output.xls'), index=False)

    column_format = {'border-color': 'Black', 'text-align': 'right', 'border-style': 'solid', 'border-width': '1px'}
    column_format1 = {'border-color': 'Black', 'border-style': 'solid', 'border-width': '1px'}

    twap = df_sample[['% from Interval TWAP']].style.applymap(highlight_vals_c1,
                                                              subset=['% from Interval TWAP']).set_properties(
        **column_format)
    twap_minute = df_sample[['% from Interval TWAP (1 min)']].style.applymap(highlight_vals_c1, subset=[
        '% from Interval TWAP (1 min)']).set_properties(**column_format)
    close = df_sample[['% from ClosePrice']].style.applymap(highlight_vals_c1,
                                                            subset=['% from ClosePrice']).set_properties(
        **column_format)

    c1 = df_sample[['% from Interval VWAP']].style.applymap(highlight_vals_c1,
                                                            subset=['% from Interval VWAP']).set_properties(
        **column_format)
    c2 = df_sample[['% from Full Day VWAP']].style.applymap(highlight_vals_c1,
                                                            subset=['% from Full Day VWAP']).set_properties(
        **column_format)
    c3 = df_sample[['% from PWP20']].style.applymap(highlight_vals_c1, subset=['% from PWP20']).set_properties(
        **column_format)
    c4 = df_sample[['% from Arrival']].style.applymap(highlight_vals_c1, subset=['% from Arrival']).set_properties(
        **column_format)

    df_sample[["% of Day's Volume", "% Interval Volume"]] = df_sample[["% of Day's Volume", "% Interval Volume"]].round(
        2)

    c5 = df_sample[["% of Day's Volume"]].style.applymap(color_r_g_b, subset=["% of Day's Volume"]).set_properties(
        **column_format)
    c6 = df_sample[["% Interval Volume"]].style.applymap(color_r_g_b, subset=["% Interval Volume"]).set_properties(
        **column_format)
    c7 = df_sample[['% from nearest PWP']].style.applymap(highlight_vals_c1,
                                                          subset=['% from nearest PWP']).set_properties(**column_format)
    c8 = df_sample[["Total Value"]].applymap('{:,.4f}'.format).style.set_properties(**column_format)

    c9 = df_sample[["Avg Trade Price"]].applymap('{:,.4f}'.format).style.set_properties(**column_format)
    c10 = df_sample[["Arrival Price"]].applymap('{:,.4f}'.format).style.set_properties(**column_format)

    c11 = df_sample[["Interval VWAP Price"]].applymap('{:,.4f}'.format).style.set_properties(**column_format)
    twapp = df_sample[["Interval TWAP Price"]].applymap('{:,.4f}'.format).style.set_properties(**column_format)
    twapp_minute = df_sample[["Interval TWAP Price (1 min)"]].applymap('{:,.4f}'.format).style.set_properties(
        **column_format)

    c12 = df_sample[["Full Day VWAP Price"]].applymap('{:,.4f}'.format).style.set_properties(**column_format)
    c13 = df_sample[["PWP20"]].applymap('{:,.4f}'.format).style.set_properties(**column_format)

    # difference per share and amount
    differences = pd.concat(
        [df.iloc[:, df.columns.str.endswith('_diff_amount')], df.iloc[:, df.columns.str.endswith('diff_pershare')]],
        axis=1)
    # differences = differences.reindex(sorted(differences.columns), axis=1)
    differences_dict = {};
    diff_amount_sum_dict = {}
    for col in ['arrival_diff', 'arrival_amend_diff', 'dayvwap_', 'vwap_', 'twap_diff', 'twap_minute_diff', 'pwp20_',
                'pwp_', 'close_']:
        temp = differences.iloc[:, differences.columns.str.startswith(col)]
        temp = temp.reindex(sorted(temp.columns, reverse=True), axis=1)
        diff_amount_sum_dict[col.replace('_', '')] = round(temp.iloc[:, -1].sum(), 2)
        differences_dict[col.replace("_", '')] = temp.style.set_properties(**column_format)

    # total value sum
    diff_amount_sum_dict['total value sum'] = round(df_sample['Total Value'].sum(), 2)

    cfirst = df_sample[["Trade Date", "Security", "Side", "Shares", "Traded lots"]]
    cfirst = cfirst.style.set_properties(**column_format1)
    last = ''
    if tag115 == 1:
        print "Daily report ; filter on tag1"
        last = df[["SecurityExchange", "Start - End Time", "Duration (minutes)", "tag9271", "ClientName"]]
        last = last.style.set_properties(**column_format1)
    else:
        print "Monthly report; discard tag1 internal"
        last = df[["SecurityExchange", "Start - End Time", "Duration (minutes)", "tag9271"]]
        last = last.style.set_properties(**column_format1)

    pwprounded = df_sample[["PWP (rounded to nearest 5 of % Interval Vol)"]].style.set_properties(
        **{'border-color': 'Black',
           'border-style': 'solid',
           'border-width': '1px'})

    return pwprounded, twapp, twap, cfirst, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, last, total_value_sum, diff_amount, \
           differences_dict, diff_amount_sum_dict, algo_summary, vs_benchmark, vs_benchmark_minute, df_sample, \
           twapp_minute, twap_minute, close


def write_html_table(table1, table2, output_file):
    table1 = (table1.to_html(classes='mystyle', index=False)).replace(
        '<table border="1" class="dataframe mystyle">',
        '<table border="1" class="mystyle">')
    table2.reset_index(inplace=True)
    table2 = (table2.to_html(classes='mystyle', index=False)).replace(
        '<table border="1" class="dataframe mystyle">',
        '<table border="1" class="mystyle">')

    output_file.write("<br><br>")
    output_file.write("<table style='width:100%'><tr><td>{}</td></tr></table><br>".format(table1))
    output_file.write("<table style='width:100%'><tr><td>{}</td></tr></table><br>".format(table2))

    return output_file


def pretty_html_table(body_tables, d):
    '''func to get table coloured for an html email o/p'''

    pd.set_option('colheader_justify', 'center')  # FOR TABLE <th>
    html_string = "<html><head><style>{css_style}</style></head><body>\
                    <p>MLP client summary report for {d}</p>".format(
        css_style=open(os.path.join(curr_dir, "df_style.css"), 'r').read(), d=d)
    # file to send in email
    output_file = open(os.path.join(output_dir, "output.html"), "w")
    output_file.write(html_string)
    table1, table2 = body_tables[0]
    output_file = write_html_table(table1, table2, output_file)
    try:
        table1, table2 = body_tables[1]
        output_file.write("<br><br><b>Summary (DMA)</b> <br>")
        output_file = write_html_table(table1, table2, output_file)
    except:
        print ("No dma orders has been traded")
    output_file.write("</body></html>")
    output_file.close()
    output_file = open(os.path.join(output_dir, "output.html"), 'r').read().replace("&lt;", "<").replace("&gt;", ">")
    output_file = output_file.replace("dataframe mystyle", "mystyle")
    output_file = output_file.replace('<td>text', '<td class="text">')

    with open(os.path.join(output_dir , "output.html"), 'w') as f:
        f.write(output_file)


def output_excel(pwprounded, twapp, twap, cfirst, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, last,
                 total_value_sum,
                 diff_amount, differences_dict, diff_amount_sum_dict, d, ivol, tag115, algo_summary, vs_benchmark,
                 vs_benchmark_minute,
                 client_format, df_sample, twapp_minute, twap_minute, close, ord_type, writer, workbook):
    length1 = len(ivol["IVolpwp"])
    length1 = length1 + 1
    ivol["IVolpwp"] = ivol["IVolpwp"].map('{:,.4f}'.format)
    c14 = ivol.style.set_properties(**{'border-color': 'Black',
                                       'text-align': 'right',
                                       'border-style': 'solid',
                                       'border-width': '1px'})

    cell_format = workbook.add_format({'bold': 1,
                                       'align': 'center',
                                       'valign': 'vcenter',
                                       'text_wrap': True,
                                       'color': '#000080'
                                       })
    cell_format.set_text_wrap()
    merge_format = workbook.add_format({
        'bold': 1,
        'align': 'center',
        'valign': 'vcenter',
        'text_wrap': True,
        'color': '#000080'
    })

    cell_format1 = workbook.add_format({'bold': 1,
                                        'align': 'center',
                                        'valign': 'vcenter',
                                        'text_wrap': True,
                                        'color': '#000080'})
    cell_format1.set_right(2)

    cell_format2 = workbook.add_format({
        'bold': True,
        'align': 'right',
        'valign': 'right',
        'border': 1,
        'text_wrap': True})

    column_format = {'border-color': 'Black', 'text-align': 'right', 'border-style': 'solid', 'border-width': '1px'}

    if ord_type == 'all':

        worksheet = workbook.add_worksheet('Result')

        writer.sheets['Result'] = worksheet
        worksheet.set_column(0, 47, 20)
        worksheet.set_column(49, 50, 20)
        worksheet.set_row(0, 110)

        worksheet.merge_range('A0:G0', '  ', merge_format)
        worksheet.write(0, 0, 'Trade Date', cell_format)
        worksheet.write(length1, 0, "Summary", workbook.add_format({
            'bold': True,
            'align': 'left',
            'valign': 'left',
            'border': 1,
            'text_wrap': True}))
        worksheet.write(0, 1, 'Security', cell_format)
        worksheet.write(0, 2, 'Side', cell_format)

        worksheet.write(0, 3, 'Shares', cell_format)
        worksheet.write(0, 4, 'Traded Lots', cell_format)
        worksheet.write(0, 5, 'Total Value\n(in INR)', cell_format)
        worksheet.write(length1, 5, total_value_sum, cell_format2)  # sum of total value
        worksheet.write(0, 6, 'AvgTrade\nprice\n(in INR)', cell_format1)

        worksheet.merge_range('H0:K0', ' ', merge_format)
        worksheet.write(0, 7, "Arrival\nPrice\n(in INR)", cell_format)
        worksheet.write(0, 8, "Difference Per Share", cell_format)
        worksheet.write(0, 9, "Difference Amount", cell_format)
        worksheet.write(length1, 9, diff_amount_sum_dict['arrivaldiff'],
                        cell_format2)  # sum of difference amount; diff* total value
        worksheet.write(0, 10, "% from\nArrival\n(in bps)", cell_format1)
        bps = pd.DataFrame([diff_amount['arrival_diff_amount'].values[0]]).style.applymap(
            highlight_vals_c1).set_properties(**column_format)
        # sum of arrival difference
        bps.to_excel(writer, sheet_name='Result', startrow=length1, startcol=10, index=False, header=False)

        # arrival price on amend
        worksheet.merge_range('L0:O0', ' ', merge_format)
        worksheet.write(0, 11, "Arrival\nPrice\nAmend\n(in INR)", cell_format)
        worksheet.write(0, 12, "Difference Per Share", cell_format)
        worksheet.write(0, 13, "Difference Amount", cell_format)
        worksheet.write(length1, 13, diff_amount_sum_dict['arrivalamenddiff'],
                        cell_format2)  # sum of difference amount; diff* total value
        worksheet.write(0, 14, "% from\nArrival\nAmend\n(in bps)", cell_format1)
        bps = pd.DataFrame([diff_amount['arrival_amend_diff_amount'].values[0]]).style.applymap(
            highlight_vals_c1).set_properties(**column_format)
        # sum of arrival difference
        bps.to_excel(writer, sheet_name='Result', startrow=length1, startcol=14, index=False, header=False)

        # worksheet.write(length1+1,9,round(diff_amount_sum_dict['arrival']*10000/diff_amount_sum_dict['total value sum'],2),cell_format2)  # sum of diff amount / sum of toal values
        # Vs close price
        worksheet.merge_range('P0:S0', ' ', merge_format)
        worksheet.write(0, 15, "Close\nPrice\n(in INR)", cell_format)
        worksheet.write(0, 16, "Difference Per Share", cell_format)
        worksheet.write(0, 17, "Difference Amount", cell_format)
        worksheet.write(length1, 17, diff_amount_sum_dict['close'],
                        cell_format2)  # sum of difference amount; diff* total value
        worksheet.write(0, 18, "% from\nClose\nPrice\n(in bps)", cell_format1)
        bps = pd.DataFrame([diff_amount['close_diff_amount'].values[0]]).style.applymap(
            highlight_vals_c1).set_properties(**column_format)
        # sum of arrival difference
        bps.to_excel(writer, sheet_name='Result', startrow=length1, startcol=18, index=False, header=False)

        worksheet.merge_range('T0:W0', ' ', merge_format)
        worksheet.write(0, 19, "Interval\nTWAP Price\n(in INR)", cell_format)
        worksheet.write(0, 20, "Difference Per Share", cell_format)
        worksheet.write(0, 21, "Difference Amount", cell_format)
        worksheet.write(length1, 21, diff_amount_sum_dict['twapdiff'],
                        cell_format2)  # sum of difference amount; diff* total value
        worksheet.write(0, 22, "% from\nInterval\nTWAP\n(in bps)", cell_format1)
        # worksheet.write(length1,13,diff_amount['twap_diff_amount'].values[0],cell_format2)
        # worksheet.write(length1+1,13,round(diff_amount_sum_dict['twap']*10000/diff_amount_sum_dict['total value sum'],2),cell_format2)  # sum of diff amount / sum of toal values
        bps = pd.DataFrame([diff_amount['twap_diff_amount'].values[0]]).style.applymap(
            highlight_vals_c1).set_properties(**column_format)
        # sum of arrival difference
        bps.to_excel(writer, sheet_name='Result', startrow=length1, startcol=22, index=False, header=False)

        # one minute twap
        worksheet.merge_range('X0:AA0', ' ', merge_format)
        worksheet.write(0, 23, "Interval\nTWAP Price\n1 min(in INR)", cell_format)
        worksheet.write(0, 24, "Difference Per Share", cell_format)
        worksheet.write(0, 25, "Difference Amount", cell_format)
        worksheet.write(length1, 25, diff_amount_sum_dict['twapminutediff'],
                        cell_format2)  # sum of difference amount; diff* total value
        worksheet.write(0, 26, "% from\nInterval\nTWAP\n1 min(in bps)", cell_format1)
        # worksheet.write(length1,13,diff_amount['twap_diff_amount'].values[0],cell_format2)
        # worksheet.write(length1+1,13,round(diff_amount_sum_dict['twap']*10000/diff_amount_sum_dict['total value sum'],2),cell_format2)  # sum of diff amount / sum of toal values
        bps = pd.DataFrame([diff_amount['twap_minute_diff_amount'].values[0]]).style.applymap(
            highlight_vals_c1).set_properties(**column_format)
        # sum of arrival difference
        bps.to_excel(writer, sheet_name='Result', startrow=length1, startcol=26, index=False, header=False)

        worksheet.merge_range('AB0:AE0', ' ', merge_format)
        worksheet.write(0, 27, "Interval\nVWAP Price\n(in INR)", cell_format)
        worksheet.write(0, 28, "Difference Per Share", cell_format)
        worksheet.write(0, 29, "Difference Amount", cell_format)
        worksheet.write(length1, 29, diff_amount_sum_dict['vwap'],
                        cell_format2)  # sum of difference amount; diff* total value
        worksheet.write(0, 30, "% from\nInterval\nVWAP\n(in bps)", cell_format1)
        # worksheet.write(length1,17,diff_amount['vwap_diff_amount'].values[0],cell_format2)
        # worksheet.write(length1+1,17,round(diff_amount_sum_dict['vwap']*10000/diff_amount_sum_dict['total value sum'],2),cell_format2)  # sum of diff amount / sum of toal values
        bps = pd.DataFrame([diff_amount['vwap_diff_amount'].values[0]]).style.applymap(
            highlight_vals_c1).set_properties(**column_format)
        # sum of arrival difference
        bps.to_excel(writer, sheet_name='Result', startrow=length1, startcol=30, index=False, header=False)

        # spread bps
        worksheet.merge_range('AF0:AG0', ' ', merge_format)
        worksheet.write(0, 31, "Bid-Ask Spread\n(in bps)", cell_format)
        worksheet.write(0, 32, "VWAP slip\n(%spread)", cell_format1)
        df_temp = df_sample[['Bid/Ask spread (bps)', '% from Interval VWAP']].copy(deep=True)
        df_temp['Bid/Ask spread (bps)'] = df_temp['Bid/Ask spread (bps)'].round(2)
        spread_bps = df_temp[['Bid/Ask spread (bps)']].style.applymap(highlight_vals_c1,
                                                                      subset=['Bid/Ask spread (bps)']).set_properties(
            **column_format)
        spread_bps.to_excel(writer, sheet_name='Result', startrow=1, startcol=31, index=False, header=False)
        df_temp['VWAP slip (%spread)'] = df_temp[['% from Interval VWAP', 'Bid/Ask spread (bps)']].apply(
            lambda row: round((row['% from Interval VWAP'] / row['Bid/Ask spread (bps)']) * 100, 2) \
                if row['Bid/Ask spread (bps)'] != 0 else 0, axis=1)
        vwap_slip_spread = df_temp[['VWAP slip (%spread)']].style.applymap(highlight_vals_c1, subset=[
            'VWAP slip (%spread)']).set_properties(**column_format)
        vwap_slip_spread.to_excel(writer, sheet_name='Result', startrow=1, startcol=32, index=False, header=False)

        worksheet.merge_range('AH0:AK0', ' ', merge_format)
        worksheet.write(0, 33, "Full Day\nVWAP\nPrice\n(in INR)", cell_format)
        worksheet.write(0, 34, "Difference Per Share", cell_format)
        worksheet.write(0, 35, "Difference Amount", cell_format)
        worksheet.write(length1, 35, diff_amount_sum_dict['dayvwap'],
                        cell_format2)  # sum of difference amount; diff* total value
        worksheet.write(0, 36, "% from\nFull Day\nVWAP\n(in bps)", cell_format1)
        # worksheet.write(length1,21,diff_amount['dayvwap_diff_amount'].values[0],cell_format2)
        # worksheet.write(length1+1,21,round(diff_amount_sum_dict['dayvwap']*10000/diff_amount_sum_dict['total value sum'],2),cell_format2)  # sum of diff amount / sum of toal values
        bps = pd.DataFrame([diff_amount['dayvwap_diff_amount'].values[0]]).style.applymap(
            highlight_vals_c1).set_properties(**column_format)
        # sum of arrival difference
        bps.to_excel(writer, sheet_name='Result', startrow=length1, startcol=36, index=False, header=False)

        worksheet.write(0, 37, "% of\nDay's\nVolume", cell_format)
        worksheet.write(0, 38, "%\nInterval\nVolume", cell_format1)

        worksheet.merge_range('AL0:AO0', ' ', merge_format)
        worksheet.write(0, 39, "PWP20\n(in INR)", cell_format)
        worksheet.write(0, 40, "Difference Per Share", cell_format)
        worksheet.write(0, 41, "Difference Amount", cell_format)
        worksheet.write(length1, 41, diff_amount_sum_dict['pwp20'],
                        cell_format2)  # sum of difference amount; diff* total value
        worksheet.write(0, 42, "% from\nPWP20\n(in bps)", cell_format1)
        # worksheet.write(length1,27,diff_amount['pwp20_diff_amount'].values[0],cell_format2)
        # worksheet.write(length1+1,27,round(diff_amount_sum_dict['pwp20']*10000/diff_amount_sum_dict['total value sum'],2),cell_format2)  # sum of diff amount / sum of toal values
        bps = pd.DataFrame([diff_amount['pwp20_diff_amount'].values[0]]).style.applymap(
            highlight_vals_c1).set_properties(**column_format)
        # sum of arrival difference
        bps.to_excel(writer, sheet_name='Result', startrow=length1, startcol=42, index=False, header=False)

        worksheet.merge_range('AP0:AS0', ' ', merge_format)
        worksheet.write(0, 43, "PWP\n(in INR)", cell_format)
        worksheet.write(0, 44, "Difference Per Share", cell_format)
        worksheet.write(0, 45, "Difference Amount", cell_format)
        worksheet.write(length1, 45, diff_amount_sum_dict['pwp'],
                        cell_format2)  # sum of difference amount; diff* total value
        worksheet.write(0, 46, "PWP Percent", cell_format)
        worksheet.write(0, 47, "% from\nnearest\nPWP\n(in bps)", cell_format1)
        # worksheet.write(length1,32,diff_amount['pwp_diff_amount'].values[0],cell_format2)
        # worksheet.write(length1+1,32,round(diff_amount_sum_dict['pwp']*10000/diff_amount_sum_dict['total value sum'],2),cell_format2)  # sum of diff amount / sum of toal values
        bps = pd.DataFrame([diff_amount['pwp_diff_amount'].values[0]]).style.applymap(highlight_vals_c1).set_properties(
            **column_format)
        # sum of arrival difference
        bps.to_excel(writer, sheet_name='Result', startrow=length1, startcol=47, index=False, header=False)

        worksheet.write(0, 48, "Exchange", cell_format)
        worksheet.write(0, 49, 'Start - End Time', cell_format)
        worksheet.write(0, 50, 'Duration (minutes)', cell_format)

        cfirst.to_excel(writer, sheet_name='Result', startrow=1, startcol=0, index=False, header=False)
        c8.to_excel(writer, sheet_name='Result', startrow=1, startcol=5, index=False, header=False)
        c9.to_excel(writer, sheet_name='Result', startrow=1, startcol=6, index=False, header=False)
        c10.to_excel(writer, sheet_name='Result', startrow=1, startcol=7, index=False, header=False)
        differences_dict['arrivaldiff'].to_excel(writer, sheet_name='Result', startrow=1, startcol=8, index=False,
                                                 header=False)
        c4.to_excel(writer, sheet_name='Result', startrow=1, startcol=10, index=False, header=False)

        # arrival amend
        arri_amend = df_sample[["ArrivalPrice (amend)"]].applymap('{:,.4f}'.format).style.set_properties(
            **column_format)
        arri_amend.to_excel(writer, sheet_name='Result', startrow=1, startcol=11, index=False, header=False)
        differences_dict['arrivalamenddiff'].to_excel(writer, sheet_name='Result', startrow=1, startcol=12, index=False,
                                                      header=False)
        arri_amend = df_sample[['% from Arrival (amend)']].style.applymap(highlight_vals_c1, subset=[
            '% from Arrival (amend)']).set_properties(**column_format)
        arri_amend.to_excel(writer, sheet_name='Result', startrow=1, startcol=14, index=False, header=False)

        # close price
        df_sample[["ClosePrice"]].applymap('{:,.4f}'.format).style.set_properties(**column_format).to_excel(
            writer, sheet_name='Result', startrow=1, startcol=15, index=False, header=False)
        differences_dict['close'].to_excel(writer, sheet_name='Result', startrow=1, startcol=16, index=False,
                                           header=False)
        close.to_excel(writer, sheet_name='Result', startrow=1, startcol=18, index=False, header=False)

        twapp.to_excel(writer, sheet_name='Result', startrow=1, startcol=19, index=False, header=False)
        differences_dict['twapdiff'].to_excel(writer, sheet_name='Result', startrow=1, startcol=20, index=False,
                                              header=False)
        twap.to_excel(writer, sheet_name='Result', startrow=1, startcol=22, index=False, header=False)
        # 1 minute
        twapp_minute.to_excel(writer, sheet_name='Result', startrow=1, startcol=23, index=False, header=False)
        differences_dict['twapminutediff'].to_excel(writer, sheet_name='Result', startrow=1, startcol=24, index=False,
                                                    header=False)
        twap_minute.to_excel(writer, sheet_name='Result', startrow=1, startcol=26, index=False, header=False)

        c11.to_excel(writer, sheet_name='Result', startrow=1, startcol=27, index=False, header=False)
        differences_dict['vwap'].to_excel(writer, sheet_name='Result', startrow=1, startcol=28, index=False,
                                          header=False)
        c1.to_excel(writer, sheet_name='Result', startrow=1, startcol=30, index=False, header=False)

        c12.to_excel(writer, sheet_name='Result', startrow=1, startcol=33, index=False, header=False)
        differences_dict['dayvwap'].to_excel(writer, sheet_name='Result', startrow=1, startcol=34, index=False,
                                             header=False)
        c2.to_excel(writer, sheet_name='Result', startrow=1, startcol=36, index=False, header=False)

        c5.to_excel(writer, sheet_name='Result', startrow=1, startcol=37, index=False, header=False)
        c6.to_excel(writer, sheet_name='Result', startrow=1, startcol=38, index=False, header=False)

        c13.to_excel(writer, sheet_name='Result', startrow=1, startcol=39, index=False, header=False)
        differences_dict['pwp20'].to_excel(writer, sheet_name='Result', startrow=1, startcol=40, index=False,
                                           header=False)
        c3.to_excel(writer, sheet_name='Result', startrow=1, startcol=42, index=False, header=False)

        c14.to_excel(writer, sheet_name='Result', startrow=1, startcol=43, index=False, header=False)
        differences_dict['pwp'].to_excel(writer, sheet_name='Result', startrow=1, startcol=44, index=False,
                                         header=False)
        c7.to_excel(writer, sheet_name='Result', startrow=1, startcol=47, index=False, header=False)
        pwprounded.to_excel(writer, sheet_name='Result', startrow=1, startcol=46, index=False, header=False)

        if tag115 == 1:

            worksheet.write(0, 51, "Tag1-External", cell_format1)
            worksheet.write(0, 52, "Tag1-Internal", cell_format1)
            last.to_excel(writer, sheet_name='Result', startrow=1, startcol=48, index=False, header=False)
            # write usd inr
            worksheet.write(0, 53, "USD INR", cell_format1)
            worksheet.write(0, 54, "Algo", cell_format1)
            worksheet.write(0, 55, "TradeId", cell_format1)
            df_sample[['usd_inr', 'Algorithm', 'TradeId']].to_excel(writer, sheet_name='Result', startrow=1,
                                                                    startcol=53, index=False, header=False)
            print "writing daily sample report"

            # shutil.copy(output_dir+'tca_sample_new_{}.xlsx'.format(d.strftime('%Y%m%d')),
            #            email_dir+'tca_sample_new_{}.xlsx'.format(d.strftime('%Y%m%d')))

        else:
            print "writing monthly report"
            worksheet.write(0, 51, "Tag1", cell_format1)
            last.to_excel(writer, sheet_name='Result', startrow=1, startcol=48, index=False, header=False)
            # write usd inr
            worksheet.write(0, 52, "USD INR", cell_format1)
            worksheet.write(0, 53, "Algo", cell_format1)
            worksheet.write(0, 54, "TradeId", cell_format1)
            df_sample[['usd_inr', 'Algorithm', 'TradeId']].to_excel(writer, sheet_name='Result', startrow=1,
                                                                    startcol=52, index=False, header=False)

            # shutil.copy(output_dir+'monthly_tca_sample_new_{}_{}.xlsx'.format(tag115[0],d.strftime('%Y%m%d')),
            #            email_dir+'monthly_tca_sample_new_{}_{}.xlsx'.format(tag115[0],d.strftime('%Y%m%d')))

    summary_sheetname = 'Summary'
    if ord_type == 'dma':
        summary_sheetname = "Summary_dma"

    # small TCA Summary in summary sheet
    worksheet1 = workbook.add_worksheet(summary_sheetname)
    writer.sheets[summary_sheetname] = worksheet1
    worksheet1.set_column(0, 0, 35)
    worksheet1.set_column(1, 8, 18)

    worksheet1.set_row(0, 30)
    worksheet1.set_row(3, 30)
    worksheet1.set_row(14, 30)

    # write headers
    header_format = workbook.add_format(
        {'bold': 1, 'align': 'center', 'valign': 'vcenter', 'text_wrap': True, 'color': '#000080'})
    worksheet1.merge_range('A1:B1', ' ', merge_format)
    worksheet1.merge_range('A4:B4', ' ', merge_format)
    worksheet1.merge_range('A15:B15', ' ', merge_format)

    worksheet1.write(0, 0, "TCA Summary", header_format)
    worksheet1.write(3, 0, "TCA Performance in BPS", header_format)
    worksheet1.write(14, 0, "Algo Performance in BPS", header_format)

    # data frame output of summary
    tca_summary_df = pd.DataFrame([['No of Orders', 'Value In Crores'],
                                   [length1 - 1, round(diff_amount_sum_dict['total value sum'] / 10 ** 7, 2)]])
    tca_summary_df = tca_summary_df.T

    diff_amount.drop(columns=['arrival_amend_diff_amount'], inplace=True)
    summary_bps_df = diff_amount.T
    summary_bps_df.reset_index(inplace=True)
    summary_bps_df = (summary_bps_df[summary_bps_df['index'] != 'close_diff_amount']).append(
        summary_bps_df[summary_bps_df['index'] == 'close_diff_amount'], ignore_index=True)
    summary_bps_df = pd.DataFrame(
        [['vs Arrival', 'vs Interval TWAP', 'vs Interval TWAP (1 min)', 'vs Interval VWAP', 'vs Full day VWAP',
          'vs PWP20', 'vs PWP', 'vs Close'], summary_bps_df[0].values.tolist()]).T
    summary_bps_df = pd.DataFrame([['vs Relevant Benchmark', vs_benchmark],
                                   ['vs Relevant Benchmark (1 min TWAP)', vs_benchmark_minute]]).append(summary_bps_df,
                                                                                                        ignore_index=True)

    # algo wise summary
    algo_summary.reset_index(inplace=True)
    algo_summary = ((algo_summary.iloc[:9, :]).append(algo_summary[algo_summary['index'] == 'close_diff_amount'],
                                                      ignore_index=True).drop_duplicates(keep='last')).append(
        algo_summary.iloc[-2:, :], ignore_index=True).set_index('index')

    algo_summary = pd.concat([algo_summary.drop(index='arrival_amend_diff_amount'),
                              pd.DataFrame([['vs Arrival', 'vs Interval TWAP', 'vs Interval TWAP (1 min)',
                                             'vs Interval VWAP', 'vs Full day VWAP',
                                             'vs PWP20', 'vs PWP', 'vs Close', 'Order Count', 'Total Value (Cr)'],
                                            ['arrival_diff_amount', 'twap_diff_amount', 'twap_minute_diff_amount',
                                             'vwap_diff_amount',
                                             'dayvwap_diff_amount', 'pwp20_diff_amount', 'pwp_diff_amount',
                                             'close_diff_amount', 'Order Count', 'Total Value (Cr)']]).T.set_index(1)],
                             axis=1)
    algo_summary.reset_index(inplace=True, drop=True)
    algo_summary.set_index(0, inplace=True)

    num_format = {'border-color': 'Black', 'text-align': 'right', 'border-style': 'solid', 'border-width': '1px'}
    text_format = {'border-color': 'Black', 'text-align': 'left', 'border-style': 'solid', 'border-width': '1px'}

    tca_summary_df = tca_summary_df.style.applymap(highlight_vals_c1, subset=[1]).set_properties(
        subset=[0], **text_format).set_properties(subset=[1], **num_format)
    summary_bps_df = summary_bps_df.style.applymap(highlight_vals_c1, subset=[1]).set_properties(
        subset=[0], **text_format).set_properties(subset=[1], **num_format)
    algo_summary.reset_index(inplace=True)
    algo_summary.rename(columns={0: ''}, inplace=True)
    algo_summary_columns = [col for col in algo_summary.columns if col != '']
    algo_summary = algo_summary.style.applymap(highlight_vals_c1, subset=algo_summary_columns).set_properties(
        **num_format).set_properties(subset=[''],
                                     **text_format)

    tca_summary_df.to_excel(writer, sheet_name=summary_sheetname, startrow=1, startcol=0, index=False, header=False)
    summary_bps_df.to_excel(writer, sheet_name=summary_sheetname, startrow=4, startcol=0, index=False, header=False)
    # summary_bps_df
    algo_summary.to_excel(writer, sheet_name=summary_sheetname, startrow=15, startcol=0, index=False)

    # client format report
    # aggregate row
    client_format_df, client_format_df1 = '', ''
    if ord_type == 'dma':
        client_format_df, client_format_df1 = client_format['dma']
    else:
        client_format_df, client_format_df1 = client_format['all']

    a, b, table1 = client_format_df
    a.to_excel(writer, sheet_name=summary_sheetname, startrow=28, startcol=0, index=False)
    b.to_excel(writer, sheet_name=summary_sheetname, startrow=28, startcol=4, index=False)

    # algo wise
    a, b, table2 = client_format_df1
    a.to_excel(writer, sheet_name=summary_sheetname, startrow=31, startcol=0)
    b.to_excel(writer, sheet_name=summary_sheetname, startrow=31, startcol=4, index=False)

    return table1, table2


def client_format_report(df, d, tag115, ord_type):
    if ord_type == 'dma':
        df = df[df['Algorithm'] != 'None']

    if tag115 == 1:
        df = df[df['TradeDate'] == d]

    df['Notional Order Received'] = df['ArrivalPrice'] * df['OrderQty']
    df['Notional Filled'] = df['wt_AvgPx'] * df['QuantityExecuted']
    df['Notional Filled ($mn)'] = (df['wt_AvgPx'] * df['QuantityExecuted']) / df['usd_inr']
    df['Fill %'] = df['Notional Filled'] / df['Notional Order Received'] * 100

    df = df[['TradeDate', 'Ticker', 'TradeId', 'Tag115', 'Side', 'SecurityExchange', 'Algorithm', 'OrderQty',
             'QuantityExecuted',
             'Notional Order Received', 'Notional Filled', 'Fill %', 'OrdType', 'ArrivalPrice', 'ArrivalPrice_on_amend',
             'wt_AvgPx',
             'arrival_diff_pershare', 'arrival_diff_amount', 'wtArrPx_vs_AvgPx', 'arrival_amend_diff_pershare',
             'arrival_amend_diff_amount',
             'wtArrPxamend_vs_AvgPx', 'wt_20PWP', 'DayVwap', 'dayvwap_diff_pershare', 'dayvwap_diff_amount',
             'wtdayVWAP_vs_AvgPx',
             'pwp_diff_pershare', 'pwp_diff_amount', 'IntervalVol', 'IntervalVolLimit', 'DayVol',
             'wt_TWAP', 'twap_diff_pershare', 'twap_diff_amount', 'wtTWAP_vs_AvgPx',
             'wt_VWAP', 'vwap_diff_pershare', 'vwap_diff_amount', 'wtVWAP_vs_AvgPx',
             'close_price', 'close_vs_AvgPx', 'close_diff_pershare', 'close_diff_amount', 'spread_bps', 'duration',
             'values',
             'Notional Filled ($mn)']]
    # 'IntervalVolLimitpwp10values','IntervalVolLimitpwp15values',
    # 'IntervalVolLimitpwp20values','IntervalVolLimitpwp25values','IntervalVolLimitpwp30values',
    # ]]

    df.rename(
        columns={'wt_AvgPx': 'AvgPx', 'wt_VWAP': 'VWAP', 'wt_TWAP': 'TWAP', 'wt_20PWP': 'PWP20', 'wt_10PWP': 'PWP10',
                 'wt_15PWP': 'PWP15', 'wt_25PWP': 'PWP25', 'wt_30PWP': 'PWP30', 'wtVWAP_vs_AvgPx': 'VWAP slip bps',
                 'close_price': 'ClosePrice', 'close_vs_AvgPx': 'Close slip bps'
                 }, inplace=True)

    # final_df.replace([np.inf, -np.inf], np.nan, inplace=True)
    df.dropna(subset=['Fill %'], inplace=True)

    df['VWAP slip (%spread)'] = df[['VWAP slip bps', 'spread_bps']].apply(
        lambda row: (row['VWAP slip bps'] / row['spread_bps']) * 100 \
            if row['spread_bps'] != 0 else 0, axis=1)
    df[['QuantityExecuted', 'IntervalVol']] = df[['QuantityExecuted', 'IntervalVol']].apply(pd.to_numeric)

    df['% vol'] = df[['QuantityExecuted', 'IntervalVol']].apply(
        lambda row: round(row['QuantityExecuted'] * 100.0 / row['IntervalVol'], 4) \
            if row['IntervalVol'] > 0 else 0, axis=1)

    # writer = pd.ExcelWriter("Tca_algo_performance.xlsx", engine='xlsxwriter')
    # df.to_excel(writer, sheet_name="raw_data", index=False)

    bps_columns1 = ['vwap_diff_amount', 'twap_diff_amount', 'dayvwap_diff_amount', 'pwp_diff_amount',
                    'arrival_diff_amount', 'arrival_amend_diff_amount', 'close_diff_amount']

    result = []
    # create pivot tables
    for col in ['TradeDate', 'Algorithm']:

        print "Processing by {}".format(col)
        notional_df = df[['TradeDate', 'Ticker', 'TradeId', 'Tag115', 'Side', 'SecurityExchange', 'Algorithm',
                          'Notional Order Received',
                          'Notional Filled', 'Notional Filled ($mn)']]
        notional_df.drop_duplicates(subset=['TradeDate', 'Ticker', 'TradeId', 'Tag115', 'Side'], keep='last',
                                    inplace=True)

        if tag115 != 1:
            print "monhtly ..."
            df['TradeDate'] = 1
            notional_df['TradeDate'] = 1

        notional_df = pd.pivot_table(notional_df, index=[col], values=['Notional Order Received'], aggfunc=np.sum)

        df_pi = pd.pivot_table(df, index=[col],
                               values=['Notional Filled', 'Notional Filled ($mn)'] + bps_columns1, aggfunc=np.sum)
        df_pi = df_pi.merge(notional_df, left_index=True, right_index=True, how='inner')
        df_pi['Fill %'] = df_pi['Notional Filled'] / df_pi['Notional Order Received'] * 100
        df_pi['Fill %'] = df_pi['Fill %'].round(2)

        for col1 in bps_columns1:
            df_pi[col1] = df_pi[col1] / df_pi['Notional Filled'] * 10000
            df_pi[col1] = df_pi[col1].round(4)

        df_pi[['Notional Order Received', 'Notional Filled']] = df_pi[['Notional Order Received',
                                                                       'Notional Filled']] / 10 ** 7
        df_pi['Notional Filled ($mn)'] = df_pi['Notional Filled ($mn)'] / 10 ** 6
        df_pi.columns = ['Notional Filled (INR Cr)', 'Notional Filled ($mn)', 'vs Arrival amend(bps)',
                         'vs Arrival (bps)',
                         'vs Close (bps)', 'vs DayVwap (bps)', 'vs PWP from nearest (bps)', 'vs TWAP (bps)',
                         'VWAP slip bps', 'Notional Order Received (INR Cr)', 'Fill %']

        df_pi[['Notional Filled (INR Cr)', 'Notional Order Received (INR Cr)', 'Notional Filled ($mn)']] = df_pi[
            ['Notional Filled (INR Cr)',
             'Notional Order Received (INR Cr)', 'Notional Filled ($mn)']].round(2)
        if col == 'TradeDate':
            df_pi['No of orders'] = df.shape[0]
        elif col == 'Algorithm':
            df_pi = df_pi.merge(pd.DataFrame(df.groupby(by=['Algorithm'])['TradeId'].count()).rename(
                columns={'TradeId': 'No of orders'}), left_index=True, right_index=True, how="left")

        df_pi = df_pi[
            ['No of orders', 'Notional Filled (INR Cr)', 'Notional Filled ($mn)', 'Notional Order Received (INR Cr)',
             'Fill %', 'vs Arrival (bps)',
             'vs Arrival amend(bps)', 'VWAP slip bps', 'vs DayVwap (bps)', 'vs TWAP (bps)', 'vs PWP from nearest (bps)',
             'vs Close (bps)']]
        # duration
        temp = df.groupby(by=[col]).apply(lambda grp: pd.Series({
            "duration": np.average(grp['duration'], weights=grp['values']),
            "spread_bps": np.average(grp['spread_bps'], weights=grp['values']),
            "% vol": np.average(grp['% vol'], weights=grp['values'])
        }))
        df_pi = df_pi.merge(temp, how="left", left_index=True, right_index=True)

        df_pi['VWAP slip (%spread)'] = df_pi[['VWAP slip bps', 'spread_bps']].apply(
            lambda row: row['VWAP slip bps'] / row['spread_bps'] * 100 \
                if row['spread_bps'] != 0 else 0, axis=1)
        df_pi = df_pi[
            ['No of orders', 'Notional Filled (INR Cr)', 'Notional Filled ($mn)', '% vol', 'duration', 'spread_bps',
             'vs Arrival (bps)',
             'vs Arrival amend(bps)', 'VWAP slip bps', 'VWAP slip (%spread)', 'vs Close (bps)']].rename(columns={
            "duration": "Duration (minutes)", "Notional Filled (INR Cr)": "Notional",
            "Notional Filled ($mn)": "Notional ($mn)"})

        # round to one decimal places
        df_pi[['% vol', 'Duration (minutes)', 'spread_bps', 'vs Arrival (bps)', 'vs Arrival amend(bps)',
               'VWAP slip bps', 'VWAP slip (%spread)', 'vs Close (bps)']] = df_pi[
            ['% vol', 'Duration (minutes)', 'spread_bps', 'vs Arrival (bps)', 'vs Arrival amend(bps)',
             'VWAP slip bps', 'VWAP slip (%spread)', 'vs Close (bps)']].round(2)

        # df_pi.drop(columns=['TradeDate'], inplace=True)
        df_pi_color = df_pi.iloc[:, 5:].style.applymap(highlight_vals_c1)

        result.append([df_pi.iloc[:, :5], df_pi_color, df_pi])

    return tuple(result)


def process(df, ivol, d, tag115, ord_type, lotsize_df, client_format, writer, workbook):
    pwprounded, twapp, twap, cfirst, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, last, total_value_sum, diff_amount, \
    differences_dict, diff_amount_sum_dict, algo_summary, vs_benchmark, vs_benchmark_minute, df_sample, \
    twapp_minute, twap_minute, close = final_output(df.copy(deep=True), tag115, lotsize_df.copy(deep=True), ord_type)

    return output_excel(pwprounded, twapp, twap, cfirst, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, last,
                        total_value_sum, diff_amount,
                        differences_dict, diff_amount_sum_dict, d, ivol, tag115, algo_summary, vs_benchmark,
                        vs_benchmark_minute,
                        client_format, df_sample, twapp_minute, twap_minute, close, ord_type, writer, workbook)


def get_dollar_values(startdate, enddate):
    '''
    fetches value from cassandra historically
    '''

    # cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()
    session = cluster.connect('rohit')
    session.row_factory = pandas_factory
    session.default_fetch_size = None
    while 1:
        temp = session.execute("select * from bloom_usd_inr where date='{}' allow filtering;".format(enddate))
        temp = temp._current_rows
        if temp.empty == False:
            break
        else:
            print "Dollar value not yet available; sleep for 30 seconds..."
            time.sleep(30)

    df = session.execute(
        "select * from bloom_usd_inr where date>='{}' and date<='{}' allow filtering;".format(startdate, enddate))
    df = df._current_rows
    df['date'] = df['date'].apply(lambda row: row.date())
    df.sort_values(by=['date'], inplace=True)
    df.rename(columns={'date': 'Date'}, inplace=True)
    return df


def gen_monthly_report(d, d1, tag115):
    print "today date,yesterday date", d, d1

    if tag115 == 1:
        psql_df = get_data(d, d1)
        lotsize_df = psql_df[['Berg', 'LotSize', 'Date']]
        lotsize_df.columns = ['Security', 'LotSize', 'Trade Date']
        final_df = psql_df
        final_df.to_excel(os.path.join(output_dir,"complete_output.xlsx"), index=False)
        # print final_df
    else:
        psql_df = get_data(d, d1)
        lotsize_df = psql_df[['Berg', 'LotSize', 'Date']]
        lotsize_df.columns = ['Security', 'LotSize', 'Trade Date']
        final_list = []
        print "length", len(tag115)

        for i in range(0, len(tag115)):
            final_list.append(psql_df.loc[psql_df["Tag115"].isin([tag115[i]])])

        final_df = pd.concat(final_list)

    # discard nifty bn
    # print "Dropping index"
    # final_df = final_df[~final_df['Symbol'].isin(['NIFTY','FINNIFTY','BANKNIFTY'])]
    final_write = get_tca_split(final_df)
    df = get_combine_op(final_write)

    df.reset_index(drop=True, inplace=True)
    df = df[df['ArrivalPrice'] > 0]
    # print "ivol",ivol
    lotsize_df['Trade Date'] = pd.to_datetime(lotsize_df['Trade Date']).dt.date
    # client_format_df, client_format_df1 = pd.DataFrame(), pd.DataFrame()
    # if d==d1:
    client_format = {}
    writer = ''
    if tag115 == 1:
        writer = pd.ExcelWriter(os.path.join(output_dir , 'tca_duro_{}.xlsx'.format(d.strftime('%Y%m%d'))), engine='xlsxwriter')
    else:
        writer = pd.ExcelWriter(os.path.join(output_dir , 'monthly_tca_{}_{}.xlsx'.format("duro", d.strftime('%Y%m%d'))),
                                engine='xlsxwriter')

    workbook = writer.book
    body_tables = []
    for ord_type in ['all', 'dma']:
        df_f = pd.DataFrame()
        if ord_type == 'dma':
            df_f = df[df['Algorithm'] != 'None'].copy(deep=True)
            if not df_f.empty:
                ivol = pd.DataFrame(df_f["IVolpwp"])
                ivol["IVolpwp"] = ivol["IVolpwp"]  # .map('{:,.4f}'.format)
                client_format[ord_type] = client_format_report(df_f.copy(deep=True), d, tag115, ord_type)
                body_tables.append(process(df_f, ivol, d, tag115, ord_type, lotsize_df, client_format, writer, workbook))
        else:
            df_f = df.copy(deep=True)
            ivol = pd.DataFrame(df_f["IVolpwp"])
            ivol["IVolpwp"] = ivol["IVolpwp"]  # .map('{:,.4f}'.format)
            client_format[ord_type] = client_format_report(df_f.copy(deep=True), d, tag115, ord_type)
            body_tables.append(process(df_f, ivol, d, tag115, ord_type, lotsize_df, client_format, writer, workbook))

    writer.save()
    writer.close()

    if tag115 == 1:
        # get html table format for email body
        pretty_html_table(body_tables, d)


def sample_report_main(d, d1):
    # d=last_working(datetime.datetime.now().date()-datetime.timedelta(days=d))
    # d1=last_working(datetime.datetime.now().date()-datetime.timedelta(days=d1))
    print "Processing client sample file ", d, d1
    # middledate=calendar.monthrange(d.year,d.month)[1]/2+1
    # lastdate=calendar.monthrange(d.year,d.month)[1]
    if d == d1:
        print "processing for daily report"
        gen_monthly_report(d, d1, 1)
        print "processing for monthly report"
        # get monthly report
        tag115list = [
            ['DURO']]  # [["FRANKLINTRT","FRANKTEMPAW"], ['AZPMSOR']] # ['AZPMSOR'],['MIRAEMFSOR'], ['KLIMUMSOR']
        for i in range(0, len(tag115list)):
            # print "tag115",tag115list[i]
            a = tag115list[i]
            print d, d1
            try:
                gen_monthly_report(d, d.replace(day=1), a)
            except Exception as e:
                print "No trading done in {}/ Error {}".format(a, e)
'''
if __name__ == "__main__":
    d= datetime.date(2023, 1, 1)
    d1= datetime.date(2023, 1, 23)
    sample_report_main(d, d1)
'''