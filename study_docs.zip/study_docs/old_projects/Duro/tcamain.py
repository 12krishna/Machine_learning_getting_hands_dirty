# -*- coding: utf-8 -*-
"""
Created on Tue Aug 10 16:12:58 2022
@author: Amit
"""

import numpy as np
import pandas as pd
import datetime, time
import os, sys, shutil
import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import json
import warnings
warnings.filterwarnings("ignore")
from project_status_update import project_status_rt as udt
update_db= udt.postgres_updations()


os.chdir("/home/hadoop/tca_futures/Duro/")
# os.chdir(r"C:\Users\devops\PycharmProjects\tca_duro_futures")
# os.chdir(r"D:\deploying_codes\Duro_fut")
#os.chdir("D:\\Duro\\")

json_dir= open(os.path.join(os.getcwd(),"path.json"))
paths= json.load(json_dir)
windows_path = paths["windows_path"]
linux_path = paths["linux_path"]
# set dependency paths here
if sys.platform not in ('win32', 'cygwin', 'cli'):
    curr_path = linux_path["root_path"]
    log_path = linux_path["log_path"]
    master_dir = linux_path["master_foldr_path"]
    berg_files = linux_path["bloom_quote_file_path"]
    processed_files = linux_path["processed_file_path"]
    temp_dir = linux_path["temp_path"]
    order_path = linux_path["order_path"]
    output_dir = linux_path["output_path"]
    holiday_path= linux_path["holiday_dir"]

else:    
    curr_path = windows_path["root_path"]
    log_path = windows_path["log_path"]
    master_dir = windows_path["master_foldr_path"]
    berg_files = windows_path["bloom_quote_file_path"]
    processed_files = windows_path["processed_file_path"]
    temp_dir = windows_path["temp_path"]
    order_path = windows_path["order_path"]
    output_dir = windows_path["output_path"]
    holiday_path = windows_path["master_foldr_path"]
    
# file_name= "20221007.txt"
    
os.chdir(curr_path)

logging.basicConfig(filename=os.path.join(log_path,"test_{}.log".format(datetime.datetime.now().date().strftime("%Y%m%d"))),
                    level=logging.INFO, filemode="a",
                    format="%(asctime)s:%(levelname)s:%(message)s")

# import other py files
import orderfile_gen_new  # generates temp 1 and temp 2 files
import order_exec_file_generation # generates final order file which is then used as input for generating final TCA output



server = '172.17.9.149'; port = 25
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'


def get_contacts(filename):
    '''
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    '''

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    msg['Cc']=','.join(kwargs['emails'][1])
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'attachments' in kwargs.keys():
        for attachment in kwargs['attachments']:            
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(attachment, "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(os.path.basename(attachment)))
            msg.attach(part) 

    # read message text or html files to be appeneded in email body 
    if 'html_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['html_email'],'rb').read()
        msg.attach(MIMEText(message, 'html'))
    
    if 'text_email' in kwargs.keys():
        # read html message file
        message = kwargs['text_email']
        msg.attach(MIMEText(message, 'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

# process_email(emails=, subject=, attachments= [], html_email=, text_email=  )


def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(os.path.join(holiday_path,'Holidays_2019.txt'), delimiter=',',date_parser=dateparse, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1) 

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d.date()])==0:
        print "working day wait file is getting downloaded"
        return 1   
    
    elif len(holiday_master[holiday_master['date']==d.date()])==1:
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1

def prev_working_day(d):
    #get first working day for the week
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                print "Holiday : ",d
                d = d - datetime.timedelta(days=1)                
            else:
                return d  

def move_files(list_dir):
    
    for f in os.listdir(list_dir):
        print "Moving " + f
        logging.info("Moving " + f)
        shutil.move(os.path.join(list_dir,f),os.path.join(processed_files,f))

    
def main(nd, tags):
    
    d = datetime.datetime.now()-datetime.timedelta(days=nd)
    file_name = d.strftime("%Y%m%d.txt")
    if process_run_check(d)==-1:
        update_db.update_lastruntime("tca_duro_fut")
        print "Skip process for holiday {}".format(d)
        return -1
    print "Processing for {}".format(d.strftime("%Y-%m-%d"))
    move_files(temp_dir) # move temp files
    move_files(order_path) # move order files
    move_files(output_dir)

    logging.info("---- Order file EXECUTION IS RUNNING ----")
    order_exec_file_generation.split1(d, tags)
    logging.info("---- Order file EXECUTION DONE ----")

    logging.info("---- Order file Split2 IS RUNNING ----")
    orderfile_gen_new.split2(d.date(),prev_working_day(d.date()))
    logging.info("---- Order file Split2 DONE ----")

    order_files = [files for files in os.listdir(order_path) if ".csv" in files]
    for file in order_files:
        ordr_file = pd.read_csv(os.path.join(order_path, file))
        if ordr_file.shape[0] ==0:
            logging.info("---- No orders found for today, Hence exiting ----")
            update_db.update_lastruntime("tca_duro_fut")
            return -1

    logging.info("---- Computing Parameters   ----")
    import tca_params_compute_new
    tca_params_compute_new.tca_calc(d.date(),prev_working_day(d.date()))
    logging.info("---- Parameters Computed ----")

    logging.info("---- DUMPING DATA IN DB   ----")
    import dumpinpostgress
    # data_frm = pd.read_excel(os.path.join(output_dir, "output_Duro"+d.strftime("%Y%m%d")+ ".xlsx"))
    data_frm = pd.read_excel(os.path.join(output_dir, "output_Duro_{}.xlsx".format(d.strftime("%Y-%m-%d"))))
    data_frm["setup_user"]= "Duro_Fno"
    data_frm.rename(columns={"200": "tag200"}, inplace=True)
    dumpinpostgress.dump_in_postgres(d.date(), data_frm)
    logging.info("---- DATA DUMPED IN DB  ----")
    '''
    # logging.info("---- CREAING REPORT 1 ----")
    import tca_final_report_new
    tca_final_report_new.sample_report_main(d.date(), d.date())
    
    logging.info("---- SENDING REPORT 1 ----")
    process_email(emails=get_contacts(os.path.join(curr_path, "tca_contacts.txt")),
                   subject="TCA futures for Duro {}".format(d.date()),
                   attachments= [os.path.join(curr_path,"Output",'monthly_tca_duro_{}.xlsx'.format(d.date().strftime('%Y%m%d'))),
                                 os.path.join(curr_path,"Output",'tca_duro_{}.xlsx'.format(d.date().strftime('%Y%m%d')))],
                   html_email = os.path.join(curr_path,"Output", "output.html"), text_email="")
    '''
    # # sending only SSf orders
    # logging.info("---- Creating Report SSF ----")
    # import tca_final_report_new1
    # tca_final_report_new1.sample_report_main(d.date(), d.date())
    #
    # # send email
    # logging.info("---- SENDING SSF REPORT ----")
    # process_email(emails=get_contacts(os.path.join(curr_path, "tca_contacts.txt")),
    #               subject="(SSF) TCA futures for Duro {}".format(d.date()),
    #               attachments= [os.path.join(curr_path,"Output",'tca_SSF_duro_{}.xlsx'.format(d.date().strftime('%Y%m%d'))),
    #                             os.path.join(curr_path,"Output",'monthly_tca_SSF_duro_{}.xlsx'.format(d.date().strftime('%Y%m%d')))],
    #               html_email = os.path.join(curr_path,"Output", "output1.html"), text_email="")
    #
    # logging.info("---- ALL REPORT SENT ----")
    # os.remove(os.path.join(curr_path,"Output", "output1.html"))
    # os.remove(os.path.join(curr_path,"Output", "output.html"))
    update_db.update_lastruntime("tca_duro_fut")

if __name__=="__main__":
    update_db.update_status("tca_duro_fut")
    main(nd=0, tags="I_EZE")
