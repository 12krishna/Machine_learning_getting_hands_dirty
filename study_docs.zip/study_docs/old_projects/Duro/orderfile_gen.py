# -*- coding: utf-8 -*-
"""
Created on Fri Jan 10 17:12:32 2019

@author: krishna
"""
import os, sys
import re
import pandas as pd
import numpy as np
import string
import simplefix
from datetime import datetime, timedelta, date
from time import time
# from cassandra.cluster import Cluster
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import logging
from cassandra.cluster import Cluster
import json

json_dir = open(os.path.join(os.getcwd(), "path.json"))
paths = json.load(json_dir)
windows_path = paths["windows_path"]
linux_path = paths["linux_path"]

# set dependency paths here
if sys.platform not in ('win32', 'cygwin', 'cli'):
    os.chdir("/home/hadoop/starwar_tca_cash/")
    curr_dir = linux_path["root_path"]
    scripmasterpath = linux_path["scripmaster_path"]
    inputpath = linux_path["temp_path"]
    outpath = linux_path["order_path"]
    log_path = linux_path["log_path"]
    bloom_req_file = linux_path["req_path"]
    config_path = linux_path["config_path"]
else:
    inputpath = windows_path["temp_path"]
    outpath = windows_path["order_path"]
    curr_dir = windows_path["root_path"]
    log_path = windows_path["log_path"]
    bloom_req_file = windows_path["req_path"]
    scripmasterpath = windows_path["master_foldr_path"]
    config_path = windows_path["master_foldr_path"]


def cassandra_configs_cluster():
    f = open(os.path.join(config_path, "config.txt"), 'r').readlines()
    f = [str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]

    from cassandra.auth import PlainTextAuthProvider

    auth_provider = PlainTextAuthProvider(username=f[1], password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)

    return cluster


def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)


cluster = cassandra_configs_cluster()

logging.info('Cassandra Cluster connected...')
session = cluster.connect('rohit')
# connect to your keyspace and create a session using which u can execute cql commands
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None

server = '172.17.9.149';
port = 25
MY_ADDRESS = 'MissingSymbolsTCA@kotak.com'

logging.basicConfig(filename=log_path + "test_{}.log".format(datetime.now().date()),
                    level=logging.DEBUG,
                    format="%(asctime)s:%(levelname)s:%(message)s")

'''
def getData(session,exchange,symbol,order_date):
    #print session, exchange, symbol, order_date
    query='SELECT * FROM quotedata WHERE token(exchange,date)=token(\'{1}\',\'{2}\') and symbol=\'{0}\' ALLOW FILTERING;'.format(symbol,exchange,order_date)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    return(rows)

def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)



cluster = Cluster(['172.17.9.51'])
logging.info('Cassandra Cluster connected...')
session = cluster.connect('rohit')
#connect to your keyspace and create a session using which u can execute cql commands 
logging.info('Using rohit keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None
'''

# Check if month has changed and if so rewrite the monthly data file


todays_date = date.today()
current_month = todays_date.month


# filetime = datetime.fromtimestamp(os.path.getctime(curr_dir+'monthly.req'))
# file_month = filetime.month
# if current_month != file_month:
#     open(curr_dir+'monthly.req', 'w').close()
# else:
#     pass


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails


def fetch_nse_bhavcopy_cassandra(date):
    logging.info("Read data from cm_bhavcopy for {}".format(date))
    query_oi = session.execute(
        "SELECT * FROM cm_bhavcopy where timestamp ='{}' and series='EQ' ALLOW FILTERING".format(date))
    query_oi = query_oi._current_rows
    logging.info("Successfully read")
    query_oi = query_oi[["close", "isin"]]
    return query_oi


def fetch_bse_bhavcopy_cassandra(date):
    logging.info("Read data from cm_bhavcopy for {}".format(date))
    query_oi = session.execute("SELECT * FROM bse_bhavcopy where trading_date ='{}' ALLOW FILTERING".format(date))
    query_oi = query_oi._current_rows
    return query_oi


def process_email(**kwargs):  # accept variable number of keyworded arguments

    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''

    # get total email recipients
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)

            # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)

    msg = MIMEMultipart()  # create a message
    # setup the parameters of the message, to cc emails
    msg['From'] = MY_ADDRESS
    msg['To'] = ','.join(kwargs['emails'][0])
    msg['Cc'] = ','.join(kwargs['emails'][1])
    msg['Subject'] = kwargs['subject']

    # attachments to the email
    if 'attachments' in kwargs.keys():
        for attachment in kwargs['attachments']:
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(attachment, "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(attachment.split("\\")[-1]))
            msg.attach(part)

            # read message text or html files to be appeneded in email body
    if 'html_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['html_email'], 'rb').read()
        msg.attach(MIMEText(message, 'html'))

    if 'text_email' in kwargs.keys():
        # read html message file
        message = kwargs['text_email']
        msg.attach(MIMEText(message, 'plain'))

    s.sendmail(MY_ADDRESS, rcpt, msg.as_string())

    s.quit()


# process_email(emails=, subject=, attachments= [], html_email=, text_email=  )

def alert_missing_symbols(order_df):
    # check for symbols dumped in cassandra or not ; and send alert email
    # read bloomberg req file in order to find missing tickers
    bloom_codes = pd.read_csv(bloom_req_file + 'getquotes_vwap_daily.req', header=None)
    logging.info("Successfully read getquotes req file from bloomberg data request ")

    bloom_codes = bloom_codes.iloc[bloom_codes.index[bloom_codes[0] == 'START-OF-DATA'][0] + 1:
                                   bloom_codes.index[bloom_codes[0] == 'END-OF-DATA'][0], :]

    missing_data = pd.DataFrame(
        columns=['Ticker', 'Date', 'Exchange', 'Series', 'OrderQty', 'NSEExecutedQty', 'BSEExecutedQty', 'Tag115'])
    for ticker in order_df['Ticker'].unique():
        d = pd.to_datetime(order_df[order_df['Ticker'] == ticker]['StartTime'].values[0]).date()
        if len(bloom_codes[bloom_codes[0] == ticker + " IS Equity"]) == 0:
            print "Data missing for {} {} {}".format(ticker, d, "IS")
            tag115 = ', '.join(list(order_df[order_df['Ticker'] == ticker]['Tag115'].unique()))
            temp = order_df[order_df['Ticker'] == ticker]
            temp = temp.groupby(['Ticker'], as_index=False).agg({'OrderQty': 'last', 'NSEExecutedQty': 'sum',
                                                                 'BSEExecutedQty': 'sum'})
            temp['Exchange'] = 'NSE';
            temp['Series'] = 'IS';
            temp['Date'] = d;
            temp['Tag115'] = tag115
            print temp.columns
            missing_data = missing_data.append(temp)

        if len(bloom_codes[bloom_codes[0] == ticker + " IB Equity"]) == 0:
            print "Data missing for {} {} {}".format(ticker, d, "IB")
            tag115 = ', '.join(list(order_df[order_df['Ticker'] == ticker]['Tag115'].unique()))
            temp = order_df[order_df['Ticker'] == ticker]
            temp = temp.groupby(['Ticker'], as_index=False).agg({'OrderQty': 'last', 'NSEExecutedQty': 'sum',
                                                                 'BSEExecutedQty': 'sum'})
            temp['Exchange'] = 'BSE';
            temp['Series'] = 'IB';
            temp['Date'] = d;
            temp['Tag115'] = tag115
            missing_data = missing_data.append(temp)

    missing_data = missing_data[
        ['Ticker', 'Date', 'Exchange', 'Series', 'OrderQty', 'NSEExecutedQty', 'BSEExecutedQty', 'Tag115']]

    missing_data = missing_data[((missing_data['Series'] == 'IB') & (missing_data['BSEExecutedQty'] != 0)) | (
                (missing_data['Series'] == 'IS') & (missing_data['NSEExecutedQty'] != 0))]

    with open(curr_dir + "message.txt", "wb") as file:
        file.write(missing_data.to_html())

    # dropping passed columns
    missing_data.drop(['Date', 'Exchange', 'OrderQty', 'NSEExecutedQty', 'BSEExecutedQty', 'Tag115'], axis=1,
                      inplace=True)
    missing_data = missing_data.assign(Name='Equity')
    missing_data = missing_data['Ticker'].astype(str) + " " + missing_data['Series'].astype(str) + " " + missing_data[
        'Name'].astype(str)

    # adding it to monthly sheet
    with open(curr_dir + 'monthly.req', "a") as f:
        for line in missing_data.values.tolist():
            f.write(line + "\n")
            f.flush()

    # counting monthly sheet count
    monthly_count = 0
    try:
        monthly_count = len(pd.read_csv(curr_dir + 'monthly.req', header=None))
        print "New Berg Count for the month ..", monthly_count
    except pd.errors.EmptyDataError:
        print "New Berg Count for the month ..", monthly_count

    # combining old symbols with newly added in a string
    old_length, new_length, today_length = len(bloom_codes), len(bloom_codes) + len(missing_data), len(missing_data)
    print "old_length ", old_length
    print "today_length ", today_length
    print "new_length ", new_length

    if len(missing_data) > 0 and monthly_count <= 100:
        # update berg req file
        # Read in the file
        berg_file = open(bloom_req_file + 'getquotes_vwap_daily.req', 'r').read().replace("END-OF-DATA\nEND-OF-FILE",
                                                                                          '\n'.join(
                                                                                              missing_data.values.tolist()) + "\n" + "END-OF-DATA\nEND-OF-FILE")

        # Write the file out again
        with open(bloom_req_file + 'getquotes_vwap_daily.req', 'w') as file:
            file.write(berg_file)

        # Mail content when missing symbols found
        file_object = open(curr_dir + "message.txt", 'a')
        file_object.write(
            "<br>Ticker old count in Bloomberg request file was {} ,new count is {} and {} new tickers were addede to the file".format(
                old_length, new_length, today_length))
        file_object.close()

        emails = get_contacts(curr_dir + "tca_missing_symbol_alert_contacts.txt")
        process_email(emails=emails, subject="Missing symbols TCA {}".format(datetime.now().date()),
                      html_email=curr_dir + "message.txt")
        # add symbols to req file
        logging.info(
            "Ticker old count in Bloomberg request file was {} ,new count is {} and {} new tickers were addede to the file".format(
                old_length, new_length, today_length))
        '''
        try:
            # append data in Security names for vwap curve sampling 
            if sys.platform not in ('win32', 'cygwin', 'cli'):
                print "Adding ticker in Security names for vwap curve sampling..."
                for missing in missing_data.values.tolist():
		    missing_tickertemp = missing.split(" ")[0]
                    os.system('echo "{}" >> {}Security_Names_new1.csv'.format(missing_tickertemp, new_vwap_process))
        except Exception as e:
            print e
        '''


    elif len(missing_data) > 0:

        # Mail content when missing symbols found
        file_object = open(curr_dir + "message.txt", 'a')
        file_object.write("<br>Tickers have passed the 100 counts for the month")
        file_object.close()

        emails = get_contacts(curr_dir + "tca_missing_symbol_alert_contacts.txt")
        process_email(emails=emails, subject="Missing symbols TCA {}".format(datetime.now().date()),
                      html_email=curr_dir + "message.txt")
        # add symbols to req file
        logging.info("Tickers have passed the 100 counts for the month")

    else:
        emails = get_contacts(curr_dir + "tca_missing_symbol_alert_contacts.txt")
        process_email(emails=emails, subject="Missing symbols TCA {}".format(datetime.now().date()),
                      text_email="NO missing Symbols found for TCA !!!")
        logging.info("All symbols present berg file!")

    os.remove(curr_dir + "message.txt")


def scripmaster_tickers(merged_df):
    scrip_df = pd.read_csv(os.path.join(scripmasterpath, "scripmaster.csv"),
                           names=['Symbol', 'BseSymbol', 'UnnamedField3', 'Company Name',
                                  'UnnamedField5', 'UnnamedField6', 'ISIN', 'RICNse', 'Sedol', 'RICBse',
                                  'UnnamedField11', 'BseTicker',
                                  'NseTicker', 'UnnamedField14', 'NfoTicker'])[['Symbol', 'NseTicker']]
    scrip_df.dropna(subset=['Symbol'], inplace=True)
    scrip_df['NseTicker'] = scrip_df['NseTicker'].apply(lambda row: str(row)[1:])

    merged_df = merged_df.merge(scrip_df, on=['Symbol'], how='left')
    merged_df.loc[merged_df['Ticker'] == 'None', 'Ticker'] = merged_df['NseTicker']
    merged_df.drop(columns=['NseTicker'], inplace=True)

    return merged_df


def fetch_tickers_pre_cls(df, nse_df):
    scrip_df = pd.read_csv(os.path.join(scripmasterpath, "scripmaster.csv"),
                           names=['Symbol', 'BseSymbol', 'UnnamedField3', 'Company Name',
                                  'UnnamedField5', 'UnnamedField6', 'ISIN', 'RICNse',
                                  'Sedol', 'RICBse', 'UnnamedField11', 'BseTicker',
                                  'NseTicker', 'UnnamedField14', 'NfoTicker'])[['Symbol', 'ISIN']]
    scrip_df.dropna(subset=['Symbol'], inplace=True)
    scrip_df.sort_values("Symbol", inplace=True)
    df_main = df.merge(scrip_df, on=['Symbol'], how='left')
    df_main = df_main.merge(nse_df[["isin", "close"]], left_on=['ISIN'], right_on=["isin"], how='left')
    df_main.rename(columns={"close": "PreviousClose"}, inplace=True)
    return df_main


def append_eq(req_path, ordr_file_path):
    req_fil_path = [os.path.join(rt, files) for rt, dr, fl in os.walk(req_path) for files in fl if
                    "getallquotes_mlpcash_Copy.req" in files]
    odr_file_path = [os.path.join(rt, files) for rt, dr, fl in os.walk(ordr_file_path) for files in fl if
                     ".csv" in files]

    req_file = open(req_fil_path[0], "r")
    odr_file = pd.read_csv(odr_file_path[0], usecols=["Berg"])
    odr_list = [i + " IS Equity\n" for i in odr_file["Berg"].to_list()]
    req_content = req_file.readlines()
    print req_content

    first_occurance = [idx for idx, s in enumerate(req_content) if 'START-OF-DATA' in s][0]
    last_occurance = [idx for idx, s in enumerate(req_content) if 'END-OF-DATA' in s][-1]
    new_content = req_content[:first_occurance + 1] + odr_list + req_content[last_occurance:]

    with open(os.path.join(req_path, 'getallquotes_mlpcash.req'), 'w') as f:
        for item in new_content:
            f.write("%s" % item)
    f.close()


# def split2_copy():
#     outpath= outpath
#     append_eq(bloom_req_file, outpath)

def split2(d, prev_wd):
    for r, di, f in os.walk(inputpath):
        for file in f:
            # print file
            if (file.find("tempfile1_") != -1):
                logging.info("Reading temp1 and temp2 files for order and execution data")
                # print f
                file_name = os.path.join(r, file)
                base = os.path.basename(file_name)[10:18]
                print file_name, base
                logging.info("{},{}".format(file_name, base))

                execution = pd.read_csv(file_name)
                execution.rename(columns={'LastQty': 'QuantityExecuted',
                                          'MsgType': 'Response_status', 'LastExchange': 'Exchange', 'LastPx': 'Price',
                                          'ParentOrdID': 'TradeId', 'Og_ClientOrdID': 'Og_ClientOrdID_exec'},
                                 inplace=True)
                execution['LastFillTime'] = pd.to_datetime(execution['LastFillTime'], errors="coerce") + timedelta(
                    hours=5, minutes=30)
                execution = execution[execution['ClientOrdID'] != 'None']

                # list of rejected orders
                rejected_orders = execution[(execution['Response_status'].astype(str) == '9')][
                    ['ClientOrdID', 'Response_status']]
                rejected_orders['Response_status'] = rejected_orders['Response_status'].astype(str)
                logging.info("Number of rejected orders, i.e : tag 35=9-  {}".format(len(rejected_orders)))
                execution = execution[~execution['ClientOrdID'].isin(list(rejected_orders['ClientOrdID'].values))]

                # storing orders data in dataframe
                orders = pd.read_csv(os.path.join(inputpath, "tempfile2_" + base + ".csv"))

                # drop records with G and 35=9; reject orders
                orders = orders.merge(rejected_orders, on='ClientOrdID', how='left')
                orders = orders[~((orders['MsgType'] == 'G') & (orders['Response_status'] == '9'))].drop(
                    'Response_status', axis=1)
                scripmaster = pd.read_csv(os.path.join(scripmasterpath, "scripmaster.csv"), header=None)
                scripmaster = scripmaster[[0, 12]].rename(columns={0: "Symbol", 12: "Berg"})

                orders['ArrivalTime'] = pd.to_datetime(orders['ArrivalTime'], errors='coerce') + timedelta(hours=5,
                                                                                                           minutes=30)
                orders['EndTime'] = pd.to_datetime(orders['EndTime'], errors='coerce') + timedelta(hours=5, minutes=30)
                orders['Date'] = orders['ArrivalTime'].dt.date
                orders['EndTime'] = orders['EndTime'].fillna(pd.to_datetime(str(d) + " " + '15:30:00'))
                orders['EndTime'] = orders[orders['EndTime'].dt.time <= pd.to_datetime('15:30:00').time()]['EndTime']
                # orders['EndTime'] = orders['EndTime'].fillna(pd.to_datetime(orders['Date'].apply(str)+' '+'15:30:00', errors='coerce'))
                # orders['ArrivalTime'] = orders[orders['ArrivalTime'].dt.time >= pd.to_datetime('09:15:00').time()]['ArrivalTime']
                # orders['ArrivalTime'] = orders['ArrivalTime'].fillna(pd.to_datetime(orders['Date'].apply(str)+' '+'09:15:00', errors='coerce'))
                orders['OrdType'] = orders['OrdType'].astype(str)
                orders.loc[orders['OrdType'] == '1', 'OrdType'] = 'MKT'
                orders.loc[orders['OrdType'] == '2', 'OrdType'] = 'LMT'
                orders.loc[orders['Side'] == 1, 'Side'] = 'BUY'
                orders.loc[orders['Side'] == 2, 'Side'] = 'SELL' \
                    # orders.loc[orders['SecurityExchange']=="None",["SecurityExchange"]] = np.nan
                # orders['SecurityExchange']= orders['SecurityExchange'].fillna("NSE")
                orders.loc[orders['SecurityExchange'] == 'NS', 'SecurityExchange'] = 'NSE'
                orders.loc[orders['SecurityExchange'] == 'BO', 'SecurityExchange'] = 'BSE'
                orders.loc[orders['StartTime'] == 'None', ["StartTime"]] = np.nan
                orders['StartTime'] = orders[orders['ArrivalTime'].dt.time >= pd.to_datetime('09:15:00').time()][
                    'ArrivalTime']
                orders['StartTime'] = orders['StartTime'].fillna(
                    pd.to_datetime(orders['Date'].apply(str) + ' ' + '09:15:00', errors='coerce'))
                # orders = orders.loc[orders["167"]=="CS",:]
                for index, item in orders['ClientOrdID'].iteritems():
                    if item in pd.Series(orders.loc[orders['MsgType'] == 'G', 'Og_ClientOrdID']):
                        orders.loc[orders['ClientOrdID'] == item, 'EndTime'] = orders.loc[(orders['MsgType'] == 'G') & (
                                orders['Og_ClientOrdID'] == item), 'ArrivalTime'].values
                    if item in pd.Series(orders.loc[orders['MsgType'] == 'F', 'Og_ClientOrdID']):
                        orders.loc[orders['ClientOrdID'] == item, 'EndTime'] = orders.loc[(orders['MsgType'] == 'F') & (
                                orders['Og_ClientOrdID'] == item), 'ArrivalTime'].values

                orders.drop('Date', axis=1, inplace=True)
                scripmaster.columns = ["Symbol", "Berg"]
                orders = orders.merge(scripmaster, how="left", on="Symbol")
                orders["Berg"] = orders["Berg"].apply(lambda x: str(x)[1:])

                execution['NSEExecutedQty'] = 0
                execution['BSEExecutedQty'] = 0
                execution['NSEExecutedAvg'] = 0
                execution['BSEExecutedAvg'] = 0
                # execution['Exchange'] = execution['Exchange'].fillna("NS"); execution['Exchange'] = np.where(execution['Exchange']=="None", "NS", execution['Exchange'])
                # bifurcating into NSE and BSE volumes
                execution.loc[((execution['Exchange'] == 'NS') | (execution['Exchange'] == 'XNSE')), 'NSEExecutedQty'] = \
                execution['QuantityExecuted']
                execution.loc[(execution['Exchange'] == 'BO'), 'BSEExecutedQty'] = execution['QuantityExecuted']

                execution[['Price', 'QuantityExecuted', 'NSEExecutedQty', 'BSEExecutedQty']] = execution[['Price',
                                                                                                          'QuantityExecuted',
                                                                                                          'NSEExecutedQty',
                                                                                                          'BSEExecutedQty']].apply(
                    pd.to_numeric, errors='ignore')

                execution = execution.loc[((execution['QuantityExecuted'] != "None") & (execution['Price'] != "None")),
                            :]
                execution['values'] = execution['Price'].astype("float") * execution['QuantityExecuted'].astype("float")
                execution['NSEvalues'] = execution['Price'].astype(float) * execution['NSEExecutedQty'].astype(float)
                execution['BSEvalues'] = execution['Price'].astype("float") * execution['BSEExecutedQty'].astype(float)
                execution["QuantityExecuted"] = execution["QuantityExecuted"].astype(int)
                execution["NSEExecutedQty"] = execution["NSEExecutedQty"].astype(int)
                execution["BSEExecutedQty"] = execution["BSEExecutedQty"].astype(int)
                grouped_exec = execution.groupby('ClientOrdID', as_index=False).agg(
                    {'TradeId': 'first', 'LastFillTime': 'max',
                     'QuantityExecuted': 'sum', 'NSEExecutedQty': 'sum', 'BSEExecutedQty': 'sum', 'values': 'sum',
                     'NSEvalues': 'sum', 'BSEvalues': 'sum'})

                # calculating overall AvgPx, NSE AvgPx and BSE AvgPx
                grouped_exec['AvgPx'] = grouped_exec['values'] / grouped_exec['QuantityExecuted']

                grouped_exec['NSEExecutedAvg'] = grouped_exec[grouped_exec['NSEvalues'] != 0]['NSEvalues'] / \
                                                 grouped_exec[grouped_exec['NSEExecutedQty'] != 0]['NSEExecutedQty']
                grouped_exec['BSEExecutedAvg'] = grouped_exec[grouped_exec['BSEvalues'] != 0]['BSEvalues'] / \
                                                 grouped_exec[grouped_exec['BSEExecutedQty'] != 0]['BSEExecutedQty']
                orders = orders[orders['MsgType'] != 'F']
                # drop columns that are not required
                orders.drop(labels=['MsgType'], axis=1, inplace=True)

                merged_df = pd.merge(orders, grouped_exec, how='left', on='ClientOrdID')
                merged_df['Series'] = 'EQ'
                merged_df = merged_df[
                    ['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker', 'OrdType',
                     'LimitPrice', 'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR',
                     'QuantityExecuted', 'AvgPx', 'NSEExecutedQty', 'BSEExecutedQty', 'NSEExecutedAvg',
                     'BSEExecutedAvg', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime', 'Tag115', 'tag9271',
                     "Berg"]]

                merged_df = merged_df.fillna(0)
                merged_df['TradeId'] = merged_df['TradeId'].replace(0, 'None')
                merged_df = merged_df[merged_df['TradeId'] != 'None']

                # break

                df_temp = merged_df.loc[merged_df["Og_ClientOrdID"] != "None", ['Og_ClientOrdID', 'StartTime']]
                df_temp['ClientOrdID'] = df_temp['Og_ClientOrdID']
                merged_df_temp = pd.merge(merged_df, df_temp, how='left', on='ClientOrdID')

                # break
                merged_df_temp['StartTime_y'] = pd.to_datetime(merged_df_temp['StartTime_y'], errors='coerce')
                merged_df_temp.loc[~np.isnat(merged_df_temp['StartTime_y']), 'EndTime'] = merged_df_temp['StartTime_y']
                merged_df_temp['StartTime'] = merged_df_temp['StartTime_x']
                merged_df_temp['Og_ClientOrdID'] = merged_df_temp['Og_ClientOrdID_x']

                merged_df = merged_df_temp[
                    ['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker',
                     'OrdType', 'LimitPrice', 'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty',
                     'SOR', 'QuantityExecuted', 'AvgPx', 'NSEExecutedQty', 'BSEExecutedQty', 'NSEExecutedAvg',
                     'BSEExecutedAvg', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime', 'Tag115', 'tag9271',
                     "Berg"]]
                # merged_df = merged_df[merged_df['QuantityExecuted'] > 0]
                # base = os.path.basename(file_name)
                # copy tag9271 from D to G and F
                merged_df['tag9271'] = merged_df.groupby(['TradeId'])['tag9271'].apply(
                    lambda grp: grp.mask(grp == 'None', None).ffill())
                merged_df['tag9271'] = merged_df['tag9271'].fillna('None')

                # merged_df = merged_df[merged_df['Ticker']=='BORORENE']
                # merged_df['SecurityExchange'] = merged_df['SecurityExchange'].replace(to_replace = ['XNSE', 'XBSE'], value = ['NSE', 'BSE'])
                # get ticker from scripmaster for tickers having None value

                merged_df = merged_df[
                    ['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker',
                     'OrdType', 'LimitPrice', 'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty',
                     'SOR', 'QuantityExecuted', 'AvgPx', 'NSEExecutedQty', 'BSEExecutedQty', 'NSEExecutedAvg',
                     'BSEExecutedAvg', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime', 'Tag115', 'tag9271',
                     "Berg"]]
                merged_df = scripmaster_tickers(merged_df)

                merged_df["tag200"] = None
                merged_df["RICNse"] = None
                merged_df["LotSize"] = 1

                scripmaster = pd.read_csv(os.path.join(scripmasterpath, "scripmaster.csv"), header=None)
                scripmaster = scripmaster[[0, 7]].rename(columns={7: "RIC_NSE", 0: "Symbol"})
                # scripmaster.columns = ["Symbol", "Berg"]
                merged_df["tag200"] = d.strftime("%Y%d")
                # merged_df["RICNse"]= merged_df["Symbol"]
                merged_df = merged_df.merge(scripmaster, how="left", on="Symbol")
                merged_df["RICNse"] = merged_df["RIC_NSE"]
                merged_df.drop("RIC_NSE", axis=1, inplace=True)
                # merged_df = merged_df.merge(scripmaster, how="left", on="Symbol")
                # merged_df["Ticker_x"] = merged_df["Ticker_y"]
                # merged_df.drop("Ticker_y", axis=1, inplace=True)
                # merged_df["Symbol"] = merged_df["Real_symbol"]
                # merged_df.rename(columns={"Ticker_x": "Ticker"}, inplace=True)
                # merged_df.drop("Real_symbol", axis=1, inplace=True)
                merged_df["StartTime"] = merged_df["StartTime"].astype(str)
                merged_df["SOR"] = "N"

                nse_bhav = fetch_nse_bhavcopy_cassandra(prev_wd)
                bse_df = fetch_bse_bhavcopy_cassandra(d)
                merged_df = fetch_tickers_pre_cls(merged_df, nse_bhav)

                merged_df = merged_df[
                    ['TradeId', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'Series', 'Ticker',
                     'OrdType', 'LimitPrice', 'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty',
                     'SOR', 'QuantityExecuted', 'AvgPx', 'NSEExecutedQty', 'BSEExecutedQty', 'NSEExecutedAvg',
                     'BSEExecutedAvg', 'Remarks', 'Algorithm', 'LastFillTime', 'ArrivalTime', 'Tag115', 'tag9271',
                     "tag200", "RICNse", "Berg", "LotSize", "PreviousClose"]]
                merged_df = merged_df.loc[merged_df["QuantityExecuted"] != 0, :]

                merged_df.to_csv(os.path.join(outpath, "orders{}.csv".format(base)), index=False)
                # merged_df["SecurityExchange"]= np.where(merged_df["NSEExecutedQty"]>0, "NSE", "BSE")
                print 'Order File generated successfully'
                logging.info('Order File generated successfully')

                # send alert for missing symbols
                # append_eq(bloom_req_file, outpath)

# if __name__ == "__main__":
#      d = datetime.now().date() - timedelta(days=0)
#      pwd= datetime.now().date() - timedelta(days=1)
#      split2(d, pwd)
# append_eq(bloom_req_file, outpath)
