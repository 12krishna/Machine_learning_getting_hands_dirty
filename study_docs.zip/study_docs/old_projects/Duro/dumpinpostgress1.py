import logging, psycopg2, datetime
import pandas as pd
from sqlalchemy import create_engine

log_path = "C:\\Users\\devops\\PycharmProjects\\MLP_TCP_linux\\logs\\"
input_dir = "C:\\Users\\devops\\PycharmProjects\\MLP_TCP_linux\\Output\\"

logging.basicConfig(filename=log_path + "test_{}.log".format(datetime.datetime.now().date()),
                    level=logging.DEBUG,
                    format="%(asctime)s:%(levelname)s:%(message)s")


# input_dir="D:\\devansh_new\\TCA_linux_codes\\" #path to get output file of TC_17_9

def dump_in_postgres(d):
    #    d=datetime.datetime.now().date()-datetime.timedelta(days=1)
    #    d=d.strftime('%Y%m%d')

    df = pd.read_excel(input_dir + 'output_new{}.xlsx'.format(d), sheetname="complete_output")
    #    df["Tag1"]="TAG1"
    df["setup_user"] = "Kits_FNO_&_Omnisis"
    df["unique_id"] = df["TradeId"] + df["SecurityExchange"]
    df["date"] = pd.to_datetime(df["StartTime"]).dt.date
    df.rename(columns={"200":"tag200"}, inplace=True)
    logging.info("Read complete output file and dump in postgres")
    # Connect to database (Note: The package psychopg2 is required for Postgres to work with SQLAlchemy)
    try:
        conn = psycopg2.connect(dbname='NSE-FNO',
                                user='postgres',
                                password='kotak@123',
                                host='172.17.9.182',
                                port='5432')
    except:
        print("I am unable to connect to the database")
        logging.info("I am unable to connect to the database")

    cur = conn.cursor()
    try:
        cur.execute(
            "CREATE TABLE tca_split_fno (TradeId text, ClientOrdID text,Og_ClientOrdID text,ClientName text,Symbol text,Series text,Ticker text,OrdType text,LimitPrice text,Side text,SecurityExchange text,StartTime text,EndTime text,OrderQty bigint,SOR text,QuantityExecuted bigint,AvgPx real,NSEExecutedQty bigint,BSEExecutedQty bigint,NSEExecutedAvg real,BSEExecutedAvg real,Remarks text,Algorithm text,LastFillTime text,ArrivalTime text,Tag115 text, tag9271 text, tag200 int, RICNse text, Berg text,LotSize int, PreviousClose real,IntervalVwap real,IntervalVwapNse real,IntervalVwapBse real,IntervalVwapLimit real,AvgPx_vs_IntervalVwapLimit real,IntervalVwapLimitNse real,IntervalVwapLimitBse real,DayVwapLimitNse real,DayVwapLimitBse real,DayVwapLimit real,DayVwap real,DayVwapNse real,DayVwapBse real,DayTwap real,DayTwapNse real,DayTwapBse real,IntervalTwap real,IntervalTwap_minute real, IntervalTwapNse real,IntervalTwapNse_minute real, IntervalTwapBse real,IntervalTwapLimit real,IntervalTwapLimit_minute real, AvgPx_vs_IntervalTwapLimit real,IntervalTwapLimitNse real,IntervalTwapLimitNse_minute real, IntervalTwapLimitBse real,DayTwapLimit real,DayTwapLimitNse real,DayTwapLimitBse real,AvgPx_vs_IntervalVwap real,AvgPx_vs_DayVwap real,AvgPx_vs_DayVwapLimit real,AvgPx_vs_IntervalTwap real,AvgPx_vs_IntervalTwap_minute real,AvgPx_vs_DayTwap real,AvgPx_vs_DayTwapLimit real,AvgPx_vs_Pwp real,Pwp20Nse real,Pwp20Bse real,Pwp20 real,Pwp20Limit real,AvgPx_vs_PwpLimit real,Pwp20LimitNse real,Pwp20LimitBse real,AvgTradeSizeNse bigint,AvgTradeSizeBse bigint,AvgTradeSize bigint,IntervalVolNse bigint,IntervalVolBse bigint,IntervalVol bigint,IntervalVolLimitNse bigint, IntervalVolLimitBse bigint, IntervalVolLimit bigint, DayVolNse bigint,DayVolBse bigint, DayVol bigint, DayVolLimitNse bigint, DayVolLimitBse  bigint, DayVolLimit bigint,volExecNse_intervalVolNse real, volExecBse_intervalVolBse real, volExec_vs_IntervalVol real,volExecNse_intervalVolLimitNse real, volExecBse_intervalVolLimitBse real, volExec_vs_IntervalVolLimit real,volExecNse_DayVolNse real, volExecBse_DayVolBse real, volExec_vs_DayVol real, volExecNse_DayVolLimitNse real,volExecBse_DayVolLimitBse real, volExec_vs_DayVolLimit real, ArrivalPriceNse real, ArrivalPriceBse real,ArrivalPrice real, AvgPx_vs_ArrivalPx real, Pwp10Nse real, Pwp10Bse real, Pwp10 real, Pwp10Limit real,Pwp10LimitNse  real, Pwp10LimitBse real, Pwp15Nse  real, Pwp15Bse real, Pwp15 real, Pwp15Limit  real,Pwp15LimitNse real, Pwp15LimitBse real, Pwp25Nse real, Pwp25Bse real, Pwp25 real, Pwp25Limit real,Pwp25LimitNse real, Pwp25LimitBse real, Pwp30Nse real, Pwp30Bse real, Pwp30 real, Pwp30Limit real,Pwp30LimitNse real, Pwp30LimitBse real, close_price real, AvgPx_vs_Closepx real, spread_bps real, Date date, setup_user text, primarykey(TradeId, Date, setup_user) );")
    except:
        print("database is already created you can drop it if you want to create new!")
        logging.info("database is already created you can drop it if you want to create new!")

    conn.commit()  # <--- makes sure the change is shown in the database
    conn.close()
    cur.close()

    # copy data from dataframe to postgress
    try:
        dbname = "NSE-FNO"
        user = "postgres"
        password = "kotak@123"
        ip = "172.17.9.182"
        port = "5432"
        engine = create_engine('postgresql://' + user + ':' + password + '@' + ip + ':' + port + '/' + dbname,
                               echo=False)  # create connection
        con = engine.connect()
        df.columns = df.columns.str.lower()

        df.columns = ["TradeId" , "ClientOrdID" ,"Og_ClientOrdID" ,"ClientName" ,"Symbol" ,"Series" ,"Ticker" ,"OrdType" ,"LimitPrice" ,"Side" ,
        "SecurityExchange" ,"StartTime" ,"EndTime" ,"OrderQty" ,"SOR" ,"QuantityExecuted" ,"AvgPx" ,"NSEExecutedQty" ,"BSEExecutedQty" ,"NSEExecutedAvg" ,
        "BSEExecutedAvg" ,"Remarks" ,"Algorithm" ,"LastFillTime" ,"ArrivalTime" ,"Tag115" , "tag9271" , "tag200" , "RICNse" , "Berg" ,"LotSize" , "PreviousClose" ,
        "IntervalVwap" ,"IntervalVwapNse" ,"IntervalVwapBse" ,"IntervalVwapLimit" ,"AvgPx_vs_IntervalVwapLimit" ,"IntervalVwapLimitNse" ,"IntervalVwapLimitBse" ,
        "DayVwapLimitNse" ,"DayVwapLimitBse" ,"DayVwapLimit" ,"DayVwap" ,"DayVwapNse" ,"DayVwapBse" ,"DayTwap" ,"DayTwapNse" ,"DayTwapBse" ,"IntervalTwap" ,
        "IntervalTwap_minute" , "IntervalTwapNse" ,"IntervalTwapNse_minute" , "IntervalTwapBse" ,"IntervalTwapLimit" ,"IntervalTwapLimit_minute" ,
        "AvgPx_vs_IntervalTwapLimit" ,"IntervalTwapLimitNse" ,"IntervalTwapLimitNse_minute" , "IntervalTwapLimitBse" ,"DayTwapLimit" ,"DayTwapLimitNse" ,
        "DayTwapLimitBse" ,"AvgPx_vs_IntervalVwap" ,"AvgPx_vs_DayVwap" ,"AvgPx_vs_DayVwapLimit" ,"AvgPx_vs_IntervalTwap" ,"AvgPx_vs_IntervalTwap_minute" ,
        "AvgPx_vs_DayTwap" ,"AvgPx_vs_DayTwapLimit" ,"AvgPx_vs_Pwp" ,"Pwp20Nse" ,"Pwp20Bse" ,"Pwp20" ,"Pwp20Limit" ,"AvgPx_vs_PwpLimit" ,"Pwp20LimitNse" ,
        "Pwp20LimitBse" ,"AvgTradeSizeNse" ,"AvgTradeSizeBse" ,"AvgTradeSize" ,"IntervalVolNse" ,"IntervalVolBse" ,"IntervalVol" ,"IntervalVolLimitNse" ,
        "IntervalVolLimitBse" , "IntervalVolLimit" , "DayVolNse" ,"DayVolBse" , "DayVol" , "DayVolLimitNse" , "DayVolLimitBse"  , "DayVolLimit" ,
        "volExecNse_intervalVolNse" , "volExecBse_intervalVolBse" , "volExec_vs_IntervalVol" ,"volExecNse_intervalVolLimitNse" ,
        "volExecBse_intervalVolLimitBse" , "volExec_vs_IntervalVolLimit" ,"volExecNse_DayVolNse" , "volExecBse_DayVolBse" , "volExec_vs_DayVol" ,
        "volExecNse_DayVolLimitNse" ,"volExecBse_DayVolLimitBse" , "volExec_vs_DayVolLimit" , "ArrivalPriceNse" , "ArrivalPriceBse" ,"ArrivalPrice" ,
        "AvgPx_vs_ArrivalPx" , "Pwp10Nse" , "Pwp10Bse" , "Pwp10" , "Pwp10Limit" ,"Pwp10LimitNse  , Pwp10LimitBse" , "Pwp15Nse"  , "Pwp15Bse" , "Pwp15" , "Pwp15Limit" ,
        "Pwp15LimitNse" , "Pwp15LimitBse" , "Pwp25Nse" , "Pwp25Bse" , "Pwp25" , "Pwp25Limit" ,"Pwp25LimitNse" , "Pwp25LimitBse" , "Pwp30Nse" , "Pwp30Bse" , "Pwp30" ,
        "Pwp30Limit" ,"Pwp30LimitNse" , "Pwp30LimitBse" , "close_price" , "AvgPx_vs_Closepx" , "spread_bps" , "Date" , "setup_user" ]

        df = df[["TradeId" , "ClientOrdID" ,"Og_ClientOrdID" ,"ClientName" ,"Symbol" ,"Series" ,"Ticker" ,"OrdType" ,"LimitPrice" ,"Side" ,
        "SecurityExchange" ,"StartTime" ,"EndTime" ,"OrderQty" ,"SOR" ,"QuantityExecuted" ,"AvgPx" ,"NSEExecutedQty" ,"BSEExecutedQty" ,"NSEExecutedAvg" ,
        "BSEExecutedAvg" ,"Remarks" ,"Algorithm" ,"LastFillTime" ,"ArrivalTime" ,"Tag115" , "tag9271" , "tag200" , "RICNse" , "Berg" ,"LotSize" , "PreviousClose" ,
        "IntervalVwap" ,"IntervalVwapNse" ,"IntervalVwapBse" ,"IntervalVwapLimit" ,"AvgPx_vs_IntervalVwapLimit" ,"IntervalVwapLimitNse" ,"IntervalVwapLimitBse" ,
        "DayVwapLimitNse" ,"DayVwapLimitBse" ,"DayVwapLimit" ,"DayVwap" ,"DayVwapNse" ,"DayVwapBse" ,"DayTwap" ,"DayTwapNse" ,"DayTwapBse" ,"IntervalTwap" ,
        "IntervalTwap_minute" , "IntervalTwapNse" ,"IntervalTwapNse_minute" , "IntervalTwapBse" ,"IntervalTwapLimit" ,"IntervalTwapLimit_minute" ,
        "AvgPx_vs_IntervalTwapLimit" ,"IntervalTwapLimitNse" ,"IntervalTwapLimitNse_minute" , "IntervalTwapLimitBse" ,"DayTwapLimit" ,"DayTwapLimitNse" ,
        "DayTwapLimitBse" ,"AvgPx_vs_IntervalVwap" ,"AvgPx_vs_DayVwap" ,"AvgPx_vs_DayVwapLimit" ,"AvgPx_vs_IntervalTwap" ,"AvgPx_vs_IntervalTwap_minute" ,
        "AvgPx_vs_DayTwap" ,"AvgPx_vs_DayTwapLimit" ,"AvgPx_vs_Pwp" ,"Pwp20Nse" ,"Pwp20Bse" ,"Pwp20" ,"Pwp20Limit" ,"AvgPx_vs_PwpLimit" ,"Pwp20LimitNse" ,
        "Pwp20LimitBse" ,"AvgTradeSizeNse" ,"AvgTradeSizeBse" ,"AvgTradeSize" ,"IntervalVolNse" ,"IntervalVolBse" ,"IntervalVol" ,"IntervalVolLimitNse" ,
        "IntervalVolLimitBse" , "IntervalVolLimit" , "DayVolNse" ,"DayVolBse" , "DayVol" , "DayVolLimitNse" , "DayVolLimitBse"  , "DayVolLimit" ,
        "volExecNse_intervalVolNse" , "volExecBse_intervalVolBse" , "volExec_vs_IntervalVol" ,"volExecNse_intervalVolLimitNse" ,
        "volExecBse_intervalVolLimitBse" , "volExec_vs_IntervalVolLimit" ,"volExecNse_DayVolNse" , "volExecBse_DayVolBse" , "volExec_vs_DayVol" ,
        "volExecNse_DayVolLimitNse" ,"volExecBse_DayVolLimitBse" , "volExec_vs_DayVolLimit" , "ArrivalPriceNse" , "ArrivalPriceBse" ,"ArrivalPrice" ,
        "AvgPx_vs_ArrivalPx" , "Pwp10Nse" , "Pwp10Bse" , "Pwp10" , "Pwp10Limit" ,"Pwp10LimitNse  , Pwp10LimitBse" , "Pwp15Nse"  , "Pwp15Bse" , "Pwp15" , "Pwp15Limit" ,
        "Pwp15LimitNse" , "Pwp15LimitBse" , "Pwp25Nse" , "Pwp25Bse" , "Pwp25" , "Pwp25Limit" ,"Pwp25LimitNse" , "Pwp25LimitBse" , "Pwp30Nse" , "Pwp30Bse" , "Pwp30" ,
        "Pwp30Limit" ,"Pwp30LimitNse" , "Pwp30LimitBse" , "close_price" , "AvgPx_vs_Closepx" , "spread_bps" , "Date" , "setup_user" ]]

        df.to_sql(name='tca_split', con=con, if_exists='append', index=False)
        con.close()
        logging.info("successfully dumped data")
    except Exception as e:
        print "Error while inserting in db" + str(e)
        logging.info("Error while inserting in db" + str(e))

# main()

