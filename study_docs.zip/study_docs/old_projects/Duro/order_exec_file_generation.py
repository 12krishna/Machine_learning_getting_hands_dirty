import os, sys
import re
import pandas as pd
import numpy as np
import string
import simplefix
from datetime import datetime, timedelta
from time import time
import logging
import json, os
import warnings
warnings.filterwarnings("ignore")

#os.chdir("/home/hadoop/tca_futures/Duro/")
# os.chdir(r"C:\Users\devops\PycharmProjects\tca_duro_futures")

json_dir = open(os.path.join(os.getcwd(), "path.json"))
paths = json.load(json_dir)
windows_path = paths["windows_path"]
linux_path = paths["linux_path"]

if sys.platform not in ('win32', 'cygwin', 'cli'):
    input_path = linux_path["input_data_path"]
    outpath = linux_path["temp_path"]
    log_path = linux_path["log_path"]
    scripmasterpath = linux_path["scripmaster_path"]
    instru_dir = linux_path['instru_path']
else:
    input_path = windows_path["input_data_path"]
    outpath = windows_path["temp_path"]
    log_path = windows_path["log_path"]
    scripmasterpath = windows_path["master_foldr_path"]
    instru_dir = windows_path['instru_path']
    
# expr = r'8=FIX\.4\.2.*?10=\d+\|'  # pattern to recognize line with valid excution or order line ;
expr = r'8=FIX\.4\.2.*?\|10=\d+\|'
# match line with pattern 8=FIX.4.2 and ending with 10=number|
expr_4_4 = r'8=FIX\.4\.4.*?[10=\d+\|]$'

logging.basicConfig(filename=log_path + "test_{}.log".format(datetime.now().date()),
                    level=logging.DEBUG,
                    format="%(asctime)s:%(levelname)s:%(message)s")


def filter_tag(line, tag, exec_type):
    if exec_type == "order":
        # client orders recieved
        if tag != None:
            if np.any(["115={}".format(t) in line for t in tag.split(",")]):
                return 1
            else:
                return None
        else:
            return 1


def filter_sessions_tags(row, session, tag, exec_type):
    line = row
    if session != None:
        # check if any of session present
        if np.any([s in line for s in session.split(",")]):
            return filter_tag(line, tag, exec_type)
        else:
            return None


def read_instrument():

    instru = pd.read_csv(os.path.join(instru_dir, "instrument.csv")) 
    instru = instru[(instru['InstrumentType'].isin(['FUTIDX','FUTSTK']))&(instru['ScripType']=='NORMAL')]
    instru['expiry'] = instru['ExpiryDate'].apply(lambda row: row.split("-")[-1]+row.split("-")[1])
    #replace to previus expiry
    #instru.loc[instru['expiry']=='202304','expiry']='202301'
    #instru.loc[instru['expiry']=='202305','expiry']='202302'
    #instru.loc[instru['expiry']=='202306','expiry']='202303'
    # get nse symbols
    scripmaster = pd.read_csv(os.path.join(scripmasterpath, "scripmaster.csv"),
                              names = ['Symbol','BseSymbol','UnnamedField3','Company Name','UnnamedField5','UnnamedField6',
                                       'ISIN','RICNse','Sedol','RICBse','UnnamedField11','BseTicker','NseTicker',
                                       'UnnamedField14','NfoTicker'] )
    scripmaster = scripmaster[['Symbol','RICNse','NseTicker','NfoTicker']]
    scripmaster.dropna(subset=['NfoTicker'], inplace=True)
    #scripmaster = scripmaster.append(pd.DataFrame([['NIFTY','NIF'], ['BANKNIFTY','NBN']], columns=['Symbol','RICNse']))
    if scripmaster[scripmaster['Symbol'].isin(['NIFTY','BANKNIFTY'])].empty==False:
        scripmaster.loc[(scripmaster['Symbol']=='NIFTY')&(scripmaster['RICNse'].isnull()), "RICNse"] = "NIF"
        scripmaster.loc[(scripmaster['Symbol']=='BANKNIFTY')&(scripmaster['RICNse'].isnull()), "RICNse"] = "NBN"
    else:
        print "Scripmaster doesnt contain BN and Nifty"
        scripmaster = scripmaster.append(pd.DataFrame([['NIFTY','NIF','NNZ','NZ'], ['BANKNIFTY','NBN','NAF','AF']],
                                                      columns=['Symbol','RICNse','NseTicker','NfoTicker']))

    instru = instru.merge(scripmaster, on=['Symbol'], how='left')
    instru = instru[['Symbol', 'RICNse','NseTicker','NfoTicker','expiry','LotSize','PreviousClose']]
    instru['RICNse']=instru['RICNse'].str.replace('.',':')
    instru.dropna(inplace=True)

    instru.sort_values(by=['Symbol','expiry'], inplace=True)
    instru['expirymarker'] = 1
    instru['expirymarker'] = instru.groupby(by=['Symbol'])['expirymarker'].cumsum()
    #instru['NseTicker'] = instru['NseTicker'].apply(lambda row: row[1:])
    '''
    berg_futures = pd.read_excel(os.path.join(berg_fut_dir, "FutBergs.xlsx"))
    print instru.shape
    final = instru[instru['NseTicker'].isin(berg_futures['Berg'].values)]
    final = final.merge(berg_futures[['Futures','Berg']].rename(columns={'Berg':'NseTicker'}), on=['NseTicker'], how="left")
    final['NseTicker'] = final['Futures']
    final.drop(columns=['Futures'], inplace=True)

    final = instru[~instru['NseTicker'].isin(berg_futures['Berg'].values)].append(final)
    print final.shape
    '''
    instru['NseTicker'] = instru.apply(lambda row: row['NfoTicker']+"="+str(row['expirymarker']) if not row['NfoTicker'] in ['AF','NZ'] \
                                                      else row['NfoTicker']+str(row['expirymarker']), axis=1)
    instru.rename(columns={'NseTicker':'Berg','expiry':'200'}, inplace=True)

    return instru


def split1(nd, tags):
    for_date = nd.strftime("%Y%m%d")
    foldr_name = nd.strftime("_%d-%m-%Y")
    print ("proceeding for date {}".format(for_date))
    filelist = list()
    logging.info("Order generation ; split 1 process start")
    start_time = time()
    if sys.platform not in ('win32', 'cygwin', 'cli'):
        # filelist.append(os.path.join(input_path , "BridgeLogs"+foldr_name, for_date+'.txt'))
        filelist.append(os.path.join(input_path, for_date + '.txt'))
    else:
        # filelist.append(os.path.join(input_path , "BridgeLogs"+foldr_name, for_date+'.txt'))
        filelist.append(os.path.join(input_path, for_date + '.txt'))


    for i in filelist:
        file_name = i
        print "the file we are using ----{}".format(file_name)
        logging.info("Reading file {}".format(file_name))
        f = open(file_name, 'r')
        if f.mode == 'r':
            content = f.readlines()

            base = os.path.basename(file_name)
            tempfile1 = []
            tempfile2 = []
            text_file_odr = []
            text_file_exec = []
            for line in content:  # 555000:575000
                if ("disconnected" not in line) and ("|43=Y|" not in line) and (tags in line):
                    if re.findall(expr, line):
                        rx = re.findall(expr, line)
                        if ((('35=8') or ('35=9')) and ('128=DURO')) in rx[0]:
                            x = string.replace(rx[0], '|', '\x01')
                            parser = simplefix.FixParser()
                            parser.append_buffer(x)
                            msg = parser.get_message()
                            if msg != None:
                                text_file_exec.append(str(rx))
                                tempfile1.append(
                                    str(msg.get(35)) + "," + str(msg.get(11)) + "," + str(msg.get(41)) + "," + str(
                                        msg.get(1)) \
                                    + "," + str(msg.get(150)) + "," + str(msg.get(39)) + "," + str(
                                        msg.get(151)) + "," + str(msg.get(14)) + "," + str(msg.get(6)) \
                                    + "," + str(msg.get(55)) + "," + str(msg.get(40)) + "," + str(
                                        msg.get(44)) + "," + str(msg.get(54)) \
                                    + "," + str(msg.get(100)) + "," + str(msg.get(9251)) + "," + str(
                                        msg.get(9252)) + "," + str(msg.get(38)) \
                                    + "," + str(msg.get(9270)) + "," + str(msg.get(58)).replace(',', ' ') + "," + str(
                                        msg.get(9250)) \
                                    + "," + str(msg.get(9272)) + "," + str(msg.get(60)) + "," + str(
                                        msg.get(128)) + "," + str(msg.get(9271)) \
                                    + "," + str(msg.get(167)) + "," + str(msg.get(200)) + "," + str(
                                        msg.get(52)) + "," + str(msg.get(201)) \
                                    + "," + str(msg.get(37)) + "," + str(msg.get(31)) + "," + str(
                                        msg.get(32)) + "," + str(msg.get(100)))

                        elif ((('35=D') or ('35=G') or ('35=F')) and ("115=DURO")) in rx[0]:

                            print (rx[0])

                            x = string.replace(rx[0], '|', '\x01')
                            parser = simplefix.FixParser()
                            parser.append_buffer(x)
                            msg = parser.get_message()
                            text_file_odr.append(str(rx))

                            tempfile2.append(
                                str(msg.get(35)) + "," + str(msg.get(11)) + "," + str(msg.get(41)) + "," + str(
                                    msg.get(1)) \
                                + "," + str(msg.get(55)) + "," + str(msg.get(40)) + "," + str(msg.get(44)) + "," + str(
                                    msg.get(54)) \
                                + "," + str(msg.get(100)) + "," + str(msg.get(5001)) + "," + str(
                                    msg.get(5002)) + "," + str(msg.get(38)) \
                                + "," + str(msg.get(9270)) + "," + str(msg.get(58)).replace(',', ' ') + "," + str(
                                    msg.get(5000)) \
                                + "," + str(msg.get(9904)) + "," + str(msg.get(52)) + "," + str(
                                    msg.get(115)) + "," + str(msg.get(9271)) \
                                + "," + str(msg.get(167)) + "," + str(msg.get(200)) + "," + str(
                                    msg.get(21)) + "," + str(msg.get(116)) \
                                + "," + str(msg.get(57)) + "," + str(msg.get(50)) + "," + str(msg.get(49)) + "," + str(
                                    msg.get(56)) \
                                + "," + str(msg.get(201)) + "," + str(msg.get(9260)))
                    elif re.findall(expr_4_4, line):
                        # new setup for KLIMUMSOR on MLP
                        rx = re.findall(expr_4_4, line)
                        if ((('35=8') or ('35=9')) and ('128=DURO')) in rx[0]:
                            x = string.replace(rx[0], '|', '\x01')
                            parser = simplefix.FixParser()
                            parser.append_buffer(x)
                            msg = parser.get_message()
                            text_file_odr.append(str(rx))
                            tempfile1.append(
                                str(msg.get(35)) + "," + str(msg.get(11)) + "," + str(msg.get(41)) + "," + str(
                                    msg.get(1)) \
                                + "," + str(msg.get(150)) + "," + str(msg.get(39)) + "," + str(msg.get(151))
                                + "," + str(msg.get(14)) + "," + str(msg.get(6)) + "," + str(msg.get(55))
                                + "," + str(msg.get(40)) + "," + str(msg.get(44)) + "," + str(msg.get(54)) \
                                + "," + str(msg.get(100)) + "," + str(msg.get(9251)) + "," + str(msg.get(9252))
                                + "," + str(msg.get(38)) + "," + str(msg.get(9270)) + "," + str(msg.get(58)).replace(
                                    ',', ' ')
                                + "," + str(msg.get(9250)) \
                                + "," + str(msg.get(9272)) + "," + str(msg.get(60)) + "," + str(msg.get(128))
                                + "," + str(msg.get(9271)) + "," + str(msg.get(167)) + "," + str(msg.get(200))
                                + "," + str(msg.get(52)) + "," + str(msg.get(201)) + "," + str(msg.get(37))
                                + "," + str(msg.get(31)) + "," + str(msg.get(32)) + "," + str(msg.get(100)))
                        elif ((('35=D') or ('35=G') or ('35=F')) and ("115=DURO")) in rx[0]:
                            print (rx[0])
                            text_file_exec.append(str(rx))
                            x = string.replace(rx[0], '|', '\x01')
                            parser = simplefix.FixParser()
                            parser.append_buffer(x)
                            msg = parser.get_message()
                            tempfile2.append(
                                str(msg.get(35)) + "," + str(msg.get(11)) + "," + str(msg.get(41)) + "," + str(
                                    msg.get(1)) \
                                + "," + str(msg.get(55)) + "," + str(msg.get(40)) + "," + str(msg.get(44)) + "," + str(
                                    msg.get(54)) \
                                + "," + str(msg.get(100)) + "," + str(msg.get(5001)) + "," + str(
                                    msg.get(5002)) + "," + str(msg.get(38)) \
                                + "," + str(msg.get(9270)) + "," + str(msg.get(58)).replace(',', ' ') + "," + str(
                                    msg.get(5000)) \
                                + "," + str(msg.get(9904)) + "," + str(msg.get(52)) + "," + str(
                                    msg.get(115)) + "," + str(msg.get(9271)) \
                                + "," + str(msg.get(167)) + "," + str(msg.get(200)) + "," + str(
                                    msg.get(21)) + "," + str(msg.get(116)) \
                                + "," + str(msg.get(57)) + "," + str(msg.get(50)) + "," + str(msg.get(49)) + "," + str(
                                    msg.get(56)) \
                                + "," + str(msg.get(201)) + "," + str(msg.get(9260)))
                else:
                    continue

            order_cols = ['MsgType', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'Symbol', 'OrdType', 'LimitPrice',
                          'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'Remarks', 'Algorithm',
                          'Ticker', 'ArrivalTime', 'Tag115', 'tag9271', '167', '200', 'Tag21', 'Tag116', 'Tag57',
                          'Tag50', 'Tag49', 'Tag56', 'OptionType', "POV %"]
            exe_cols = ['MsgType', 'ClientOrdID', 'Og_ClientOrdID', 'ClientName', 'tag150', 'tag39', 'tag151', 'tag14',
                        'AvgPx', 'Symbol', 'OrdType', 'LimitPrice',
                        'Side', 'SecurityExchange', 'StartTime', 'EndTime', 'OrderQty', 'SOR', 'Remarks', 'Algorithm',
                        'Ticker', 'ExecutionTime', 'Tag128', 'tag9271', '167', '200', 'LastFillTime', 'OptionType',
                        'ParentOrdID',
                        'LastPx', 'LastQty', 'LastExchange']

            temp2 = pd.DataFrame(tempfile2)
            # temp2["115"] = "DURO"
            if temp2.shape[0]==0:
                print("No trade happend")
                temp2.to_csv(os.path.join(outpath, "tempfile2_{}.csv".format(for_date)))
                return -1
            temp2 = temp2[0].str.split(',', expand=True)
            temp2.columns = order_cols
            temp1 = pd.DataFrame(tempfile1)
            temp1 = temp1[0].str.split(',', expand=True)
            temp1.columns = exe_cols
            temp1.loc[temp1["LastExchange"]=="None", "LastExchange"] = "NS"
            
            temp1['RICNse'] = temp1['Symbol'].apply(lambda sym: sym[:-5]+":NS" if sym.endswith(":NS") else sym[:-2])
            
            instru = read_instrument()
            
            temp1 = temp1.merge(instru[['RICNse', '200', 'LotSize']].drop_duplicates(subset=['RICNse','200']), on=['RICNse','200'], how="left")
            temp2 = temp2.merge(temp1[['Symbol','200','LotSize']].drop_duplicates(subset=['Symbol','200']), on=['Symbol', '200'], how="left")
            
            pd.DataFrame(temp2).to_csv(os.path.join(outpath, "tempfile2_{}.csv".format(for_date)), sep=",", index=False)
            pd.DataFrame(temp1).to_csv(os.path.join(outpath, "tempfile1_{}.csv".format(for_date)), sep=",", index=False)

            print 'Order and execution file aka temp1 and temp2 files generated successfully...'
            logging.info('Order and execution file aka temp1 and temp2 files generated successfully...')

    end_time = time()
    print "Execution time: {0} Seconds.... ".format(end_time - start_time)

# split1()
