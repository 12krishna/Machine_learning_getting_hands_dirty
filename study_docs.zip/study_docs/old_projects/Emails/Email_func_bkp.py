import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import datetime
import logging
import os
import pandas as pd 

server = '172.17.9.144'; port = 25


output_dir = "D:\\Emails\\Output\\"
log_path = "D:\\Emails\\"
contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
master_dir= "D:\\Emails\\Master\\"

logging.basicConfig(filename=log_path+"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def read_template(filename):
    """
    Returns a Template object comprising the contents of the 
    file specified by filename.
    """
    
    with open(filename, 'r') as template_file:
        template_file_content = template_file.read()
    return Template(template_file_content)

def expiry_email(month, year, expiry):
    
    # read the message file
    message_template = read_template(output_dir+'Expiry_reports\message.txt')
    emails = get_contacts(contacts_dir+'Expiry_contacts.txt') # read contacts
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)    
    

    # set up the SMTP server
    s = smtplib.SMTP(server, port)    
    # For each contact, send the email:
    message = message_template.substitute(PERSON_NAME=email[0].title())      
        
    msg = MIMEMultipart()       # create a message       
    
        # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])    
            
    msg['Subject']="[Kotak] Rollover Snapshot {0}'{1} ({2})".format(month,year,expiry)
            
    # add in the message body
    msg.attach(MIMEText(message, 'plain'))           
            
    # send the message via the server set up earlier.
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    del msg
        
    # Terminate the SMTP session and close the connection
    s.quit()
    

def daily_email_reports(filename, flag):
    '''Func to send daily report emails // Flag =0 -> Daily descriptive email, flag=1 -> ML report'''
    # check the flag and process the request
    emails = None; subject =''; part= None
    if flag == 0:
        # fetch contacts from the file 
        emails = get_contacts(contacts_dir+'Descriptive_report_contacts.txt') # read contacts
        subject = "Descriptive report for {0}".format(datetime.datetime.now().date())
                
        # attachment 
        attachment_name = "Descriptive_report.xlsx"
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(filename, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="{0}"'.format(attachment_name))     
        
    if flag == 1:
        # fetch contacts from the file 
        emails = get_contacts(contacts_dir+'ML_report_contacts.txt') # read contacts
        subject = "ML report for {0}".format(datetime.datetime.now().date())
                        
        # attachment 
        attachment_name = "Report.xlsx"
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(filename, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="{0}"'.format(attachment_name))
        
               
        
    if flag == 2:
        # fetch contacts from the file 
        emails = get_contacts(contacts_dir+'Expiry_summary_contacts.txt') # read contacts
        subject = "Expiry roll data for {0}".format(datetime.datetime.now().date())
                        
        # attachment 
        attachment_name = "Expiry_roll_data.xlsx"
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(filename, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="{0}"'.format(attachment_name))

        
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()       # create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
        
    # add in the message body
    #msg.attach(MIMEText('This is an auto generated email, please do not reply to it','plain'))        
    msg.attach(part)         
    # send the message via the server set up earlier.
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    del msg       
    # Terminate the SMTP session and close the connection
    s.quit()




def main():
    '''Main function to schedule and send mails'''
    
    # loop through all the folders and send emails 
    for r, d, f in os.walk(output_dir):
        # traverse through all folders
        for file_name in f:           
            
            if file_name.startswith('Descriptive_report'):
                # call daily mail reports func
                flag = 0
                daily_email_reports(output_dir+"Daily_Descriptive_reports\Descriptive_report.xlsx", flag)
                logging.info('Decriptive email was sent for {0}'.format(datetime.datetime.now().date()))
                os.remove(output_dir+"Daily_Descriptive_reports\Descriptive_report.xlsx")
                
            if file_name.startswith('message'):
                # call expiry email func
                date = datetime.date.today()
                month, year = date.strftime('%b'), date.strftime("%Y")
                dates = pd.read_excel(master_dir + 'Expiry_dates_master.xlsx')
                expiry = str(dates[(dates['Date'] == int(date.strftime("%d"))) &
                                       (dates['Month'] == month.upper()) & 
                                       (dates['Year'] == int(year))]['Expiry'].values[0])
                expiry_email(month, year, expiry)
                logging.info('Expiry report email was sent for {0}'.format(datetime.datetime.now().date()))
                os.remove(output_dir+'Expiry_reports\message.txt') 
                # send expiry summary report 
                daily_email_reports(output_dir+"Expiry_reports\Expiry_report_summary.xlsx", 2)
                os.remove(output_dir+'Expiry_reports\Expiry_report_summary.xlsx') 
                
                
                
            if file_name.startswith('Report'):
                # call daily mail reports func      
                flag = 1
                daily_email_reports(output_dir+"Positioning_reports\Report.xlsx", flag)
                logging.info('ML Report was sent for {0}'.format(datetime.datetime.now().date()))
                os.remove(output_dir+"Positioning_reports\Report.xlsx")
                
            if file_name.startswith('Vol_insights'):
                #send vol insights query report 
                flag=3
                
                
                
                                        
    

 
if __name__ == '__main__':
    main()
    
    