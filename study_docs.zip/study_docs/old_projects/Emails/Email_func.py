"""
Created on Fri Jan 10 17:12:32 2019

@author: krishna
"""

import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import datetime
import logging
import os
import pandas as pd 

server = '172.17.9.144'; port = 25


output_dir = "D:\\Emails\\Output\\"
log_path = "D:\\Emails\\"
contacts_dir = "D:\\Emails\\Contacts\\"
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
master_dir= "D:\\Master\\"

logging.basicConfig(filename=log_path+"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    try:
        msg['Cc']=','.join(kwargs['emails'][1])
        msg['Bcc']=','.join(kwargs['emails'][2])
    except:
        print "Problem with CC or BCC"
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'attachments' in kwargs.keys():
        for attachment in kwargs['attachments']:            
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(attachment, "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(attachment.split("\\")[-1] ))
            msg.attach(part) 

    # read message text or html files to be appeneded in email body 
    if 'html_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['html_email'],'rb').read()
        msg.attach(MIMEText(message, 'html'))
    
    if 'text_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['text_email'],'rb').read()
        msg.attach(MIMEText(message, 'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

# process_email(emails=, subject=, attachments= [], html_email=, text_email=  )


def main():
    '''Main function to schedule and send mails'''
    
    # loop through all the folders and send emails 
    for r, d, f in os.walk(output_dir):
        # traverse through all folders
        for file_name in f:           
            try:
                    
                if file_name.startswith('Descriptive_report'):
                    # call daily mail reports func
                    emails = get_contacts(contacts_dir+'Descriptive_report_contacts.txt') # read contacts
                    subject = "Descriptive report for {0}".format( file_name.split('.')[0][-10:])  #subject
                    
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name],
                                                text_email= output_dir+"descriptive_summary.txt" )
                    
                    logging.info('Decriptive email was sent for {0}'.format(file_name.split('.')[0][-10:]))
                    os.remove(output_dir+file_name)
                    os.remove(output_dir+"descriptive_summary.txt")
                    
                if file_name.startswith('message.txt'):
                    # call expiry email func
                    date = datetime.date.today()
                    month, year = date.strftime('%b'), date.strftime("%Y")
                    dates = pd.read_excel(master_dir + 'Expiry_dates_master.xlsx')
                    expiry = str(dates[(dates['Date'] == int(date.strftime("%d"))) &
                                           (dates['Month'] == month.upper()) & 
                                           (dates['Year'] == int(year))]['Expiry'].values[0])
                    subject = "[Kotak] Rollover Snapshot {0}'{1} ({2})".format(month,year,expiry)
                    email_list = get_contacts(contacts_dir+'Expiry_contacts.txt') # read contacts
                    process_email(emails=email_list, subject=subject, text_email= output_dir+file_name )
                    
                    #text_emails(month, year, expiry)
                    logging.info('Expiry report email was sent for {0}'.format(datetime.datetime.now().date()))
                    
                    os.remove(output_dir+file_name) 
                
                if file_name.startswith("Expiry_roll_data.xlsx"):
                    # send expiry summary report 
                    # fetch contacts from the file 
                    email_list = get_contacts(contacts_dir+'Expiry_summary_contacts.txt') # read contacts
                    subject = "Expiry roll data for {0}".format(datetime.datetime.now().date())                        
                    # attachment 
                    #attachment_name = "Expiry_roll_data.xlsx"
                    process_email(emails=email_list, subject=subject, attachments= [output_dir+file_name])
    
                    #attachment_emails(output_dir+"Expiry_roll_data.xlsx", emails, subject, attachment_name)
                    os.remove(output_dir+file_name) 
                    
                if file_name.startswith('message_new.txt'):
                    # call expiry email func
                    date = datetime.date.today()
                    month, year = date.strftime('%b'), date.strftime("%Y")
                    dates = pd.read_excel(master_dir + 'Expiry_dates_master.xlsx')
                    expiry = str(dates[(dates['Date'] == int(date.strftime("%d"))) &
                                           (dates['Month'] == month.upper()) & 
                                           (dates['Year'] == int(year))]['Expiry'].values[0])
                    subject = "New: [Kotak] Rollover Snapshot {0}'{1} ({2})".format(month,year,expiry)
                    email_list = get_contacts(contacts_dir+'Expiry_contacts_new.txt') # read contacts
                    process_email(emails=email_list, subject=subject, text_email= output_dir+file_name )
                    
                    #text_emails(month, year, expiry)
                    logging.info('Expiry report email was sent for {0}'.format(datetime.datetime.now().date()))
                    
                    os.remove(output_dir+file_name) 
                
                if file_name.startswith("Expiry_roll_data_new.xlsx"):
                    # send expiry summary report 
                    # fetch contacts from the file 
                    email_list = get_contacts(contacts_dir+'Expiry_summary_contacts_new.txt') # read contacts
                    subject = "New : Expiry roll data for {0}".format(datetime.datetime.now().date())                        
                    # attachment 
                    #attachment_name = "Expiry_roll_data.xlsx"
                    process_email(emails=email_list, subject=subject, attachments= [output_dir+file_name])
    
                    #attachment_emails(output_dir+"Expiry_roll_data.xlsx", emails, subject, attachment_name)
                    os.remove(output_dir+file_name) 
                    
                    
                if file_name.startswith('Report'):
                    # call daily mail reports func  
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'ML_report_contacts.txt') # read contacts
                    subject = "ML report for {0}".format(datetime.datetime.now().date())
                    # attachment 
                    #attachment_name = "Report.xlsx"
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name])
                    
                    #attachment_emails(output_dir+"Report.xlsx", emails, subject, attachment_name)
                    logging.info('ML Report was sent for {0}'.format(datetime.datetime.now().date()))
                    os.remove(output_dir+file_name)
                    
                if file_name.startswith('Options_query'):
                    # call daily mail reports func  
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'Options_query_contacts.txt') # read contacts
                    subject = "Options query for {0}".format( file_name.split('.')[0][-10:] )
                    # attachment 
                    #attachment_name = "Options_query_{}.xlsx".format(datetime.datetime.now().date())
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name ] )
                    
                    #attachment_emails(output_dir+"Options_query_{}.xlsx".format(datetime.datetime.now().date()),
                    #                    emails, subject, attachment_name)
                    logging.info('Options query Report was sent for {0}'.format(file_name.split('.')[0][-10:]))
                    os.remove(output_dir+file_name )
                        
                if file_name.startswith('ssf_oi_change'):
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'SSF_OI_contacts.txt') # read contacts
                    subject = "SSF OI Change for {0}".format( file_name.split('.')[0][-10:] )
                    
                    process_email(emails=emails, subject=subject, html_email=output_dir+file_name )
    
                    
                    #html_emails(output_dir+"ssf_oi_change.txt", emails, subject)
            
                    logging.info('SSF OI change report was sent for {0}'.format(file_name.split('.')[0][-10:]))
                    os.remove(output_dir+file_name)
                    
                if file_name.startswith('fidi_report'):
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'Fii_dii_contacts.txt') # read contacts
                    subject = "FII DII report for {0}".format(file_name.split('.')[0][-10:])
                    process_email(emails=emails, subject=subject, html_email=output_dir+file_name)
                    
                    #html_emails(output_dir+"fidi_report.txt", emails, subject)
            
                    logging.info('FII DII report was sent for {0}'.format(file_name.split('.')[0][-10:]))
                    os.remove(output_dir+file_name)
                                        
                    
                if file_name.startswith('intrasector_') and file_name.endswith('.txt'):
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'intrasector_div_contacts.txt') # read contacts
                    subject = "Intrasector divergence for {0}".format( file_name.split('.')[0][-10:] )
                    process_email(emails=emails, subject=subject, html_email=output_dir+file_name,
                                  attachments= [output_dir+"intrasector_data_{}.xlsx".format(file_name.split('.')[0][-10:])] )
                    
                    #html_emails(output_dir+"intrasector.txt", emails, subject)
            
                    logging.info('Intrasector divergence report was sent for {0}'.format(file_name.split('.')[0][-10:]))
                    os.remove(output_dir+file_name)
                    os.remove(output_dir+"intrasector_data_{}.xlsx".format(file_name.split('.')[0][-10:]))
                    
                    
                if file_name.startswith('DailyTrendsInFPI'):
                    # call daily mail reports func  
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'DailyTrendsInFPI_contacts.txt') # read contacts
                    subject = "Trends in FPI as on {0}".format(file_name.split('.')[0][-10:])
                    # attachment 
                    #attachment_name = "DailyTrendsinFPI_{}.xlsx".format(datetime.datetime.now().date())
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name] )
                    
                    #attachment_emails(output_dir+"DailyTrendsInFPI.xlsx",
                    #                    emails, subject, attachment_name)
                    logging.info('Daily Trends in FPI Report was sent for {0}'.format(file_name.split('.')[0][-10:]))
                    os.remove(output_dir+file_name)
                    
                    
                    
                if file_name.startswith('Participant_OI'):
                    # call daily mail reports func  
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'participant_oi_contacts.txt') # read contacts
                    subject = "Participant OI as on {0}".format(file_name.split('.')[0][-10:])
                    # attachment 
                    #attachment_name = "Participant_OI_{}.xlsx".format(datetime.datetime.now().date())
                    process_email(emails=emails, subject=subject, attachments= [output_dir+"Participant_OI_{}.xlsx".format(file_name.split('.')[0][-10:])], 
                                  html_email= output_dir+"Participant_OI_{}.txt".format(file_name.split('.')[0][-10:])  )
                    
                    #combine_html_excel(output_dir+"Participant_OI.xlsx",output_dir+"Participant_OI.txt",emails,subject,attachment_name)
                    
                    logging.info('Participant_OI Report was sent for {0}'.format(file_name.split('.')[0][-10:]))
                    os.remove(output_dir+"Participant_OI_{}.xlsx".format(file_name.split('.')[0][-10:]))
                    os.remove(output_dir+"Participant_OI_{}.txt".format(file_name.split('.')[0][-10:]))
                    
                    
                    
                if file_name.startswith('Market_snapshot'):
                    # call daily mail reports func  
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'Market_snapshot_contacts.txt') # read contacts
                    subject = "Market Snapshot for {0}".format(file_name.split('.')[0][-10:] )
                    # attachment 
                    #attachment_name = "Market_snapshot.xlsx"
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name])
                    
                    #attachment_emails(output_dir+"Market_snapshot.xlsx",emails, subject, attachment_name)
                    logging.info('Market Snapshot Report was sent for {0}'.format(file_name.split('.')[0][-10:] ))
                    os.remove(output_dir+file_name)
                    
                    
                if file_name.startswith('ssf_OI_t5'):
                    # call daily mail reports func  
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'ssf_oi_t5_contacts.txt') # read contacts
                    subject = "SSF OI T-5 for {0}".format( file_name.split('.')[0][-10:] )
                    # attachment 
                    #attachment_name = "ssf_OI_t5.xlsx"
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name])
                    
                    #attachment_emails(output_dir+"ssf_OI_t5.xlsx", emails, subject, attachment_name)
                    logging.info('SSF OI T-5 Report was sent for {0}'.format( file_name.split('.')[0][-10:] ))
                    os.remove(output_dir+file_name)
                    
                    
                if file_name.startswith('airflights-one_way'):
                    emails = get_contacts(contacts_dir+'airflights_contacts_oneway.txt') # read contacts
                    subject = "Air Flights (One way) for {0}".format(file_name.split('.')[0][-10:])
                    # attachment 
                    #attachment_name = "Air_flights.xlsx"
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name])
                    os.remove(output_dir+file_name)
                    
                
                if file_name.startswith('airflights'):
                    # call daily mail reports func  
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'airflights_contacts.txt') # read contacts
                    subject = "Air Flights for {0}".format(file_name.split('.')[0][-10:])
                    # attachment 
                    #attachment_name = "Air_flights.xlsx"
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name])
                    
                    #attachment_emails(output_dir+"airflights.xlsx", emails, subject, attachment_name)
                    logging.info('Air Flights Report was sent for {0}'.format(file_name.split('.')[0][-10:]))
                    os.remove(output_dir+file_name)
                    
                if file_name.startswith('Avg_delivery_qty'):
                    # call daily mail reports func  
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'Security_avg_qty_delivery_contacts.txt') # read contacts
                    subject = "Security Delivery 20D avg".format(file_name.split('.')[0][-10:])
                    # attachment 
                    #attachment_name = "Air_flights.xlsx"
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name])
                    
                    #attachment_emails(output_dir+"airflights.xlsx", emails, subject, attachment_name)
                    logging.info('Secuirty wise 20 D avg delivery report mail sent for {}'.format(file_name.split('.')[0][-10:]))
                    os.remove(output_dir+file_name)
                    
                    
                if file_name.startswith('RollReport'):
                    # call daily mail reports func  
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'Roll_intraday_contacts.txt') # read contacts
                    subject = "Roll intraday data"
                    # get all files on expiry day
                    output_files = [output_dir+filename for filename in os.listdir(output_dir) if filename.startswith("RollReport")]
                    if len(output_files)==0:
                        continue 
                    process_email(emails=emails, subject=subject, attachments= output_files)
                    
                    #attachment_emails(output_dir+"airflights.xlsx", emails, subject, attachment_name)
                    logging.info('Roll intraday data email sent for {} '.format(datetime.datetime.now().date()))
                    for filename in output_files:
                        os.remove(filename)
                        
                        
                if file_name.startswith('New_RollReport'):
                    # call daily mail reports func  
                    # fetch contacts from the file 
                    emails = get_contacts(contacts_dir+'Roll_intraday_new_contacts.txt') # read contacts
                    subject = "Roll intraday data - Buckets"
                    # get all files on expiry day
                    output_files = [output_dir+filename for filename in os.listdir(output_dir) if filename.startswith("New_RollReport")]
                    if len(output_files)==0:
                        continue 
                    process_email(emails=emails, subject=subject, attachments= output_files)
                    
                    #attachment_emails(output_dir+"airflights.xlsx", emails, subject, attachment_name)
                    logging.info('Roll intraday data email sent for {} '.format(datetime.datetime.now().date()))
                    for filename in output_files:
                        os.remove(filename)
                    
                if file_name.startswith('tca_'):
                    emails = get_contacts(contacts_dir+'tca_contacts.txt') # read contacts
                    subject = "TCA Report"
                    
                    output_files = [output_dir+filename for filename in os.listdir(output_dir) if filename.startswith("tca")]
                    if len(output_files)==0:
                        continue 
                    process_email(emails=emails, subject=subject, attachments= output_files)
                    
                    #attachment_emails(output_dir+"airflights.xlsx", emails, subject, attachment_name)
                    logging.info('Roll intraday data email sent for {} '.format(datetime.datetime.now().date()))
                    for filename in output_files:
                        os.remove(filename)
                    
                if file_name.startswith('monthly_tca'):
                    emails = get_contacts(contacts_dir+'tca_contacts.txt') # read contacts
                    subject = "TCA Monthly Report"
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name])
                    os.remove(output_dir+file_name)
                    
                if file_name.startswith('SSF Positioning daily'):
                    emails = get_contacts(contacts_dir+'basis_contacts.txt') # read contacts
                    subject = file_name.split(".")[0]
                    process_email(emails=emails, subject=subject, attachments= [output_dir+file_name])
                    os.remove(output_dir+file_name)
                    
                if file_name.startswith('combined_price_for_online_websites'):
                    process_email(emails=get_contacts(contacts_dir+'grocery_contacts.txt'),
                                  subject=file_name.split(".")[0],
                                  attachments= [output_dir+file_name])
                    os.remove(output_dir+file_name)
                    
                if file_name.startswith('groceries_combined'):
                    process_email(emails=get_contacts(contacts_dir+'grocery_combined_contacts.txt'),
                                  subject=file_name.split(".")[0],
                                  attachments= [output_dir+file_name])
                    os.remove(output_dir+file_name)
                    
                if file_name.startswith('client_sending_orders_'):
                    process_email(emails=get_contacts(contacts_dir+'UL_client_orders_data_contacts.txt'),
                                  subject="UL extract client order data {}".format( file_name.split('_')[3] ),
                                  attachments= [output_dir+file_name,
                                                output_dir+ ''.join(['client_not',file_name.split('client')[1]]) ] )
        
                    os.remove(output_dir+file_name)
                    os.remove(output_dir+ ''.join(['client_not',file_name.split('client')[1]]))
                    
                if file_name.startswith('basis_spread_bps_'):
                    process_email(emails=get_contacts(contacts_dir+'basis_spread_bps_contacts.txt'),
                                  subject="Basis spread bps avg",
                                  attachments= [output_dir+file_name])
                    os.remove(output_dir+file_name)
                    
                if file_name.startswith('Basis_realtime_sheet_result'):
                    process_email(emails=get_contacts(contacts_dir+'basis_sheet_backup.txt'),
                                  subject="Basis sheet backup", 
                                  attachments= [output_dir+file_name])
                    os.remove(output_dir+file_name)
                    
                if file_name.startswith('Basis_EOD'):
                    process_email(emails=get_contacts(contacts_dir+'basis_eod_backup.txt'),
                                  subject="Basis spreads EOD", 
                                  attachments= [output_dir+file_name])
                    os.remove(output_dir+file_name)
                    
                    
                if file_name.startswith('CDSL_FPI_chg'):
                    process_email(emails=get_contacts(contacts_dir+'FPI_limits_contacts.txt'),
                                  subject="CDSL Changes in FPI Limit", 
                                  attachments= [output_dir+file_name])
                    os.remove(output_dir+file_name)
                    
                if file_name.startswith('NSDL_FPI_chg'):
                    process_email(emails=get_contacts(contacts_dir+'FPI_limits_contacts.txt'),
                                  subject="NSDL Changes in FPI Limit", 
                                  attachments= [output_dir+file_name])
                    os.remove(output_dir+file_name)
            except Exception as e:
                print e
                    
                
 
if __name__ == '__main__':
    main()
    
    