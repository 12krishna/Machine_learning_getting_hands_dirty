import pandas as pd
import numpy as np
import datetime,os,re,string,logging,time,sys,shutil #redis
from cassandra.cluster import Cluster
from dateutil.parser import parse
from decimal import Decimal
import xlwings as xw
os.chdir("D:\\Basis_Project\\")
import basis_cumulative_fetch
import basis_sheet_backup
import warnings
warnings.filterwarnings("ignore")


master_dir = "D:\\Master\\"
email_dir="D:\\Emails\\Output\\"
output_dir = "D:\\Basis_Project\\Output\\"


cassandra_host = "172.17.9.51"
redis_host = "10.223.104.86"
logging.basicConfig(filename='test.log',
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

# take a backup of realtime sheet
basis_sheet_backup.main()
index_list = ['NIFTY','BANKNIFTY','FINNIFTY']

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date
    
holiday_master = pd.read_csv(master_dir+ 'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)  
    
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)


def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster



# create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
#cluster = Cluster([cassandra_host])
cluster = cassandra_configs_cluster()
#logging.info('Cassandra Cluster connected...')
# connect to your keyspace and create a session using which u can execute cql commands 
session = cluster.connect('rohit')
#logging.info('Using test_df keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None

ca = pd.read_excel(master_dir+'Corporate_actions.xlsx')
    
ca_factors = ca[['Date','Symbol','Factor']]
ca_factors.dropna(inplace=True)  
ca_factors.sort_values(by=['Date','Symbol'], inplace=True)
ca_factors['Date'] = pd.to_datetime(ca_factors['Date'], dayfirst=True)
ca_factors['Factor'] = ca_factors['Factor'].round(3)


def previous_working_day(d, holiday_master):
    '''Get previous wokring day'''
    
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                print "Holiday : ",d
                d = d - datetime.timedelta(days=1)                
            else:
                return d

def corp_actions_factor(bhav_copy, ca_factors, datename):    
    '''Func to perfrom CA factor adjustments ; takes input datecolumn name and '''
    
    
    # perform CA on factor changes
    bhav_copy[datename] = bhav_copy[datename].apply(lambda d: pd.to_datetime(d.date()) )
    result = bhav_copy[~bhav_copy["symbol"].isin(ca_factors['Symbol'])]
    bhav_copy = bhav_copy[bhav_copy["symbol"].isin(ca_factors['Symbol'])]
    

    for gpname, grp in bhav_copy.groupby("symbol"):
        
        # check if symbol has any CA factors; perform on fly adjustment 
        if len(ca_factors[ca_factors['Symbol']==gpname])>=1:  # if more than one CA actions have happend
            adjust_df = ca_factors[ca_factors['Symbol']==gpname]          
            counter = 0; temp1='';
            for index, row in adjust_df.iterrows():
                
                print "CA action on {} for stock {}; Factor adjustment {}".format(row['Date'],row['Symbol'], 
                                    row['Factor'])
                if counter==0:
                    temp1 = grp[grp[datename]<row['Date']]   # first CA event 
                    # look for price and quanitiy columns 
                    for col in temp1.columns:
                        if col in ['price','open','high','low','close','last','prevclose']:
                            # perform price/factor conv
                            temp1[col] = temp1[col]/Decimal(row['Factor'])
                        elif col in 'open_int volume'.split(" "):  # perfrom quantity* factor
                            temp1[col] = temp1[col]*Decimal(row['Factor'])
                    
                    temp2 = grp[grp[datename]>=row['Date']]
                    temp1 = pd.concat([temp1,temp2], axis=0, ignore_index=True)
                    counter +=  1
                        
                else:   # more than one CA event 
                    print '******{} CA ratio******'.format(counter+1)
                    temp3 = temp1[temp1[datename]<row['Date']]
                    
                    for col in temp3.columns:
                        if col in 'price open high low close last prevclose'.split(" "):
                            # perform price/factor conv
                            temp3[col] = temp3[col]/Decimal(row['Factor'])
                        elif col in 'open_int volume'.split(" "):  # perfrom quantity* factor
                            temp3[col] = temp3[col]*Decimal(row['Factor'])                    
                    
                    temp4 = temp1[temp1[datename]>=row['Date']]
                    temp1 = pd.concat([temp3, temp4], axis=0, ignore_index=True)
                    counter += 1
            
            result = result.append(temp1, ignore_index=True)
     
        
    for col in result.columns:
        if col in 'price open high low close last prevclose open_int volume'.split(" "):
            result[col] = result[col].astype(float).round(2)  
    
    
    return result


def get_cassandra_df(value, ca, ca_factors):
    
    
    # CREATE A TABLE; dump bhavcopies to this table
    #query=session.execute("select * from test_df.test_bhavcopy limit 40000")
    logging.info("Reading data from cassandra")
    #query=session.execute("SELECT * FROM test_df.test_bhavcopy where price_date='{}' ALLOW FILTERING".format(value))
    keys = pd.read_excel(master_dir+'MasterData.xlsx')
    keys = keys[keys['IsActiveFNO']==True]
    keys.loc[keys['Type']=='SSF','instrument'] = 'FUTSTK'
    keys.loc[keys['Type']=='Index','instrument'] = 'FUTIDX'
    keys = keys['SYMBOL']+"_"+keys['instrument']+"_0.0_XX_1"
    
    result = pd.DataFrame()
    for i in range(1,4):
        
        keys_list = keys.str.replace('_1','_{}'.format(i))
        
    
        for key in keys_list:
            query=session.execute("SELECT * FROM fno_bhavcopy where price_date='{}' and key='{}' ALLOW FILTERING".format(value, key),
                          timeout = None)
            result = result.append(query._current_rows, ignore_index = True)
            
    
     # read corporate actions file for reading symbols from cassandra
    ca=ca[["Old_bloomcode","Old_symbol","New_bloomcode","New_symbol"]]
    ca.dropna(inplace=True)
    
    for i in range(0,len(ca)):
        result=result.replace(to_replace=ca["Old_symbol"][i], value=ca["New_symbol"][i], regex=True)
    
#     result.to_csv("checker.csv",index=False)
    result = corp_actions_factor(result, ca_factors, 'price_date')
    result['open_int']=result['open_int'].astype(float)#.astype(int)
    
    print '{} number of rows returned : {}'.format(value, len(result))
    return result


def final_oi_output(today_data,yesterday_data,d):
    
    #final_df=today_data.merge(yesterday_data,on=["symbol","expiry_dt"],how="left")

    # expiry
    '''
    expiry=pd.read_excel(master_dir+'Expiry_contract_Master.xlsx',sheet=1)
    expiry["Date"]=pd.to_datetime(expiry["Date"]).dt.date
    expiry=expiry[["Date"]]
    '''
    expiry_dates_master = pd.read_excel(master_dir+'Expiry_dates_master.xlsx')
    expiry_dates_master['date'] = expiry_dates_master.apply(lambda row: pd.to_datetime(str(row['Date'])+row['Month']+str(row['Year'])).date(),
                           axis=1)
    expiry_dates_master = expiry_dates_master[expiry_dates_master['Expiry']=='E']['date']
    
    if pd.to_datetime(today_data['price_date'].values[0]).date() in expiry_dates_master.values:
        today_data = today_data.loc[(today_data['key'].str.endswith("_2")) | (today_data['key'].str.endswith("_3"))]
    else:
        today_data = today_data.loc[(today_data['key'].str.endswith("_1")) | (today_data['key'].str.endswith("_2"))]
        
    if pd.to_datetime(yesterday_data['price_date'].values[0]).date() in expiry_dates_master.values:
        yesterday_data = yesterday_data.loc[(yesterday_data['key'].str.endswith("_2")) | (yesterday_data['key'].str.endswith("_3"))]
    else:
        yesterday_data = yesterday_data.loc[(yesterday_data['key'].str.endswith("_1")) | (yesterday_data['key'].str.endswith("_2"))]
        
    '''
    if d in final_df["expiry_dt"].values:   
        m2=final_df.loc[final_df["key_x"].str.endswith('_2')]
        m3=final_df.loc[final_df["key_x"].str.endswith('_3')]
        finaldf1=pd.concat([m2,m3])
        print "Expiry : ",d 
    else:
        m1=final_df.loc[final_df["key_x"].str.endswith('_1')]
        m2=final_df.loc[final_df["key_x"].str.endswith('_2')]
        finaldf1=pd.concat([m1,m2])
        print "Not an Expiry : ",d
    '''
    today_data = today_data.groupby(by=['symbol'], as_index=False).agg({'price_date':'first', 'expiry_dt':'first', 'open_int':'sum'})
    yesterday_data = yesterday_data.groupby(by=['symbol'], as_index=False).agg({'price_date':'first', 'open_int':'sum'})
    new_df = today_data.merge(yesterday_data, on=['symbol'], how="left")
    '''
    new_df = finaldf1.groupby(['symbol']).agg({'price_date_x':'first',
                                               'expiry_dt':'first',
                                               'open_int_x':'sum',
                                               'price_date_y':'first',
                                               'open_int_y':'sum'}) #if group by then add instrument in Symbol


    new_df=new_df.reset_index()
    '''
    new_df["change_open_int"]=new_df["open_int_x"]-new_df["open_int_y"]
    new_df["oi_shares"]=new_df["change_open_int"]
    logging.info("divide by zero error for open interest")
    '''
    for i in range(len(new_df["change_open_int"])):
        if new_df["open_int_y"][i]==0:
            new_df["change_open_int"][i]=new_df["change_open_int"][i]*100
        else:
            new_df["change_open_int"][i]=(new_df["change_open_int"][i]/new_df["open_int_y"][i])*100
    '''
    new_df['change_open_int'] = new_df[['change_open_int','open_int_y']].apply(lambda row: \
                                      (row["change_open_int"]/row["open_int_y"])*100 if row['open_int_y']!=0 else 0.0, axis=1)
    
    
    #new_df.to_excel('oioutput.xlsx',index=False)
    new_df=new_df[["symbol","price_date_x","price_date_y","change_open_int","oi_shares","open_int_x","open_int_y","expiry_dt"]]
    new_df[["change_open_int","oi_shares","open_int_x","open_int_y"]]=new_df[["change_open_int","oi_shares","open_int_x","open_int_y"]].astype(float)#.astype(int)

    return new_df



def get_realtime_cumulative(d):
    
    # get cumulative result for current month 
    real = basis_cumulative_fetch.cumulative_result(1)
    
    # write one copy to email dir; current month
    temp = real[0][['Symbol','Min','Max','Spread bps avg', '5%', '95%']].copy(deep=True)
    temp['date'] = d; temp = temp[['Symbol','date','Min','Max','Spread bps avg', '5%', '95%']]
    temp = temp[~temp['Symbol'].isin(index_list)]
    temp.to_csv(email_dir+"basis_spread_bps_{}_curr_month.csv".format(d), index=False)
        
    if len(real)==3: 
        # next month
        temp = real[1][['Symbol','Min','Max','Spread bps avg', '5%', '95%']].copy(deep=True)
        temp['date'] = d; temp = temp[['Symbol','date','Min','Max','Spread bps avg', '5%', '95%']]
        temp = temp[~temp['Symbol'].isin(index_list)]
        temp.to_csv(email_dir+"basis_spread_bps_{}_next_month.csv".format(d), index=False)
    
    real, dollar = basis_cumulative_fetch.cumulative_result(2)    
    
           
    real=real[['Symbol','Px_chg','FA','Arb_short ($mn)','RA','Arb_long ($mn)','Short Futs',
               'Non_Arb_short ($mn)','Long Futs','Non_Arb_long ($mn)','Min','Max','Spread bps avg',
                'fa avg','ra avg','Shortfuts avg','Longfuts avg']]
    real.dropna(subset=["Symbol"],inplace=True)
    real.replace([np.inf, -np.inf], np.nan, inplace=True)
    real.fillna(0, inplace=True)
    
    return real, dollar
    
    



def merge_real_oi_df(real,oi_df):
    
    
    oi_df.rename(columns={'symbol':'Symbol'},inplace=True)
    real=real.merge(oi_df,on="Symbol",how='left')
    real.rename(columns={'Symbol':'symbol','price_date_x':'timestamp'},inplace=True)

    return real

def fetch_cm_bhavcopy(td):
        
    rows = session.execute("select key,symbol,close,prevclose,timestamp from cm_bhavcopy where timestamp='{}' and series='EQ' allow filtering;".format(td))
    rows = rows._current_rows
        
    for i in range(0,len(ca)):
        rows=rows.replace(to_replace=ca["Old_symbol"][i], value=ca["New_symbol"][i], regex=True)
    
    result = corp_actions_factor(rows,ca_factors,'timestamp')
    result["pxchange"]=((result["close"]-result["prevclose"])/result["prevclose"])*100
    return result

def usd_inr(td):
      
    rows = session.execute("select * from  bloom_usd_inr where  date='{}' allow filtering;".format(td))
    rows = rows._current_rows
    rows.sort_values(by="date",ascending=False,inplace=True)
    
    rows.reset_index(drop=True,inplace=True)
    
    return rows


def is_data_available(tablename, columnname, d):
    
    #cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()
    session = cluster.connect('rohit')
    session.row_factory = pandas_factory
    session.default_fetch_size = None    
    rows = session.execute("select {} from  {} where  {}>='{}' allow filtering;".format( 
            columnname, tablename,columnname, d - datetime.timedelta(days=7)), timeout=None) 
    rows = rows._current_rows
    rows = rows[columnname].drop_duplicates()
    if d in rows.values:
        print "Data present in {}".format(tablename)
        return 1
    else :
        print "Data not present for {}".format(tablename)
        return -1
    
def check_data(tables,d):
    for table, columnname in tables.items():
        while True:
            check = is_data_available(table, columnname, d)
            if check==-1:   # provide tablename, columnname and date 
                print "Sleep for 2 min"
                time.sleep(200)
            elif check==1:
                break             
    
    return 1


def get_price_change(today_data, yesterday_data):
    
    t = today_data[today_data['key'].str.endswith("_1")]
    y = yesterday_data[yesterday_data['key'].str.endswith("_1")]
    df = t.merge(y, on=['key'], how='left', suffixes=("","_y"))
    df.fillna(0, inplace=True)
    df['pxchange'] = df.apply(lambda row: ((row["close"]-row["close_y"])/row["close_y"])*100 if row['close_y']!=0 else 0, axis=1)
    #t["pxchange"]=((t["close"]-y["close"])/y["close"])*100
    df = df[['symbol','close','pxchange','price_date']]
    df.rename(columns={"price_date":"timestamp"}, inplace=True)
    return df


def main(nd):
    
    d = datetime.datetime.now().date() - datetime.timedelta(days=nd) 
    print "Start: Processing for %s"%str(d)
    logging.info("Start: Processing for %s"%str(d))
    # check if working day 
    if len(holiday_master[holiday_master['date']==d])==1 :
        print "Holiday : %s, Skip for current day "%str(d)
        logging.info("Holiday : %s, Skip for current day "%str(d))
        return -1   
         
    # get cumulative data for today
    real, dollar = '', '' 
    try:
        real, dollar = get_realtime_cumulative(d)
    except:
        print "Parameters not set, skipping process for today"
        sys.exit()
        
        
    # sleep till bhavcopy aint available
    if check_data({"fno_bhavcopy":"price_date"}, d)==1:
        print "Data available for all tables; start process !"
    
    d_prev = previous_working_day(d, holiday_master)
    #dollar=usd_inr(d)
    
    
    # get df from casandra
    today_data=get_cassandra_df(d, ca, ca_factors)    
    yesterday_data=get_cassandra_df(d_prev, ca, ca_factors)
    
    price_chg = get_price_change(today_data[["key","close","symbol","price_date"]], yesterday_data[["key","close","symbol","price_date"]])
    
    
    #cm=fetch_cm_bhavcopy(d)
    oi_df=final_oi_output(today_data,yesterday_data,d)
    real_oi_df=merge_real_oi_df(real, oi_df)
    final_df=real_oi_df.merge(price_chg,on=["symbol","timestamp"],how='left')
   
    bloom=pd.read_excel(master_dir+'MasterData.xlsx',sheetname='Sheet1')
    bloom=bloom.loc[bloom["IsActiveFNO"]==True]
    bloom.rename(columns={"SYMBOL":"symbol"},inplace=True)

    final_df=final_df.merge(bloom,on="symbol",how='left')
    
    #dollar["usd_inr"]=dollar["usd_inr"].astype(float)
    #dollar["usd_inr"]=dollar["usd_inr"].astype(float)
    
    newcol=["Arbplus","Arbminus","domdirplus","domdirminus","Arbscale","dirscale","Arbplusfinal","Arbminusfinal","domdirplustwo","domdirminustwo","residualdirplus",
            "residualdirminus","totalplus","totalminus","Arbplusadj","Arbminustwo","Dirplus","Dirminus","scaledown","Arblongtwo",
            "Arbshorttwo","Dirlong","Dirshort","Arblongtwotwo","Arbshorttwothree","dirlongfour","dirshortfive","POS","OIXtwo",
            "OI_Chg($mn)","Arb_long($mn)","Arb_short($mn)","Res+","Res-","nonarblong","nonarbshort","OI_Chg Abs($mn)","Non_Arb_long($mn)","Non_Arb_short($mn)"]

    # drop indicies nifty and banknifty
    final_df = final_df[~final_df['BloomCode'].isin(index_list)]
    final_df.reset_index(drop=True, inplace=True)

    for i in range(0,len(newcol)):
        final_df.insert(i,newcol[i],0)

    final_df["Arblong"]=final_df["RA"]
    final_df["Arbshort"]=final_df["FA"]
    final_df["longfut"]=final_df["Long Futs"]
    final_df["shortfut"]=final_df["Short Futs"]
    
    final_df["Arbplus"]=final_df["Arblong"]/final_df["open_int_x"]*100
    final_df["Arbminus"]=final_df["Arbshort"]/final_df["open_int_x"]*100
    final_df["domdirplus"]=final_df["longfut"]/final_df["open_int_x"]*100
    final_df["domdirminus"]=final_df["shortfut"]/final_df["open_int_x"]*100
    final_df[['Arbplus','Arbminus','domdirplus','domdirminus','change_open_int']] = final_df[['Arbplus','Arbminus','domdirplus','domdirminus',
                                                                                                        'change_open_int']].round(2)
    
    final_df[['Arbscale','dirscale']] = final_df[['Arbscale','dirscale']].astype(float)
    
    for i in range(0,len(final_df)):

        try:
            if (final_df["Arbplus"][i]+final_df["Arbminus"][i])>abs(final_df["change_open_int"][i]+4):
                
                final_df["Arbscale"][i]=float(np.mean([(final_df["Arbplus"][i]+final_df["Arbminus"][i]),abs(final_df["change_open_int"][i]),
                        abs(final_df["change_open_int"][i])])) / float(final_df["Arbplus"][i]+final_df["Arbminus"][i])
            else:
                final_df["Arbscale"][i]=float(final_df["Arbplus"][i]+final_df["Arbminus"][i])/float(final_df["Arbplus"][i]+final_df["Arbminus"][i])
        except:
            final_df["Arbscale"][i]=1
            
        try:
            if (final_df["domdirplus"][i]+final_df["domdirminus"][i])>abs(final_df["change_open_int"][i]+4):
                final_df["dirscale"][i]=float(np.mean([(final_df["domdirplus"][i]+final_df["domdirminus"][i]),
                        abs(final_df["change_open_int"][i]),abs(final_df["change_open_int"][i])])) / float(final_df["domdirplus"][i]+final_df["domdirminus"][i])
            else:
                final_df["dirscale"][i]=float(final_df["domdirplus"][i]+final_df["domdirminus"][i])/float(final_df["domdirplus"][i]+final_df["domdirminus"][i])
        except:
            final_df["dirscale"][i]=1
    
    
    final_df['Arbplusfinal'] = np.where(final_df["change_open_int"]<0, (-final_df["Arbminus"]*final_df["Arbscale"]),
                                                                        final_df["Arbplus"]*final_df["Arbscale"])
    final_df['Arbminusfinal'] = np.where(final_df["change_open_int"]<0, (-final_df["Arbplus"]*final_df["Arbscale"]),
                                                                        final_df["Arbminus"]*final_df["Arbscale"])
    final_df['domdirplustwo'] = np.where(final_df["change_open_int"]>0, final_df["domdirplus"]*final_df["dirscale"],
                                                                        (-final_df["domdirminus"]*final_df["Arbscale"]))
    final_df['domdirminustwo'] = np.where(final_df["change_open_int"]>0, final_df["domdirminus"]*final_df["Arbscale"],
                                                                        (-final_df["domdirplus"]*final_df["Arbscale"]))
    
    final_df["residualdirplus"]=final_df["change_open_int"]-final_df["Arbplusfinal"]-final_df["domdirplustwo"]
    final_df["residualdirminus"]=final_df["change_open_int"]-final_df["Arbminusfinal"]-final_df["domdirminustwo"]
    final_df["totalplus"]=final_df["Arbplusfinal"]+final_df["domdirplustwo"]+final_df["residualdirplus"]
    final_df["totalminus"]=final_df["Arbminusfinal"]+final_df["domdirminustwo"]+final_df["residualdirminus"]
        
    final_df['Arbplusadj'] = np.where(final_df["oi_shares"]>0, final_df["Arblong"]*final_df["Arbscale"],
                                                                        -(final_df["Arbshort"]*final_df["Arbscale"]))
    final_df['Arbminustwo'] = np.where(final_df["oi_shares"]>0, final_df["Arbshort"]*final_df["Arbscale"],
                                                                        -(final_df["Arblong"]*final_df["Arbscale"]))
    final_df['Dirplus'] = np.where(final_df["oi_shares"]>0, final_df["longfut"]*final_df["dirscale"],
                                                                        -(final_df["shortfut"]*final_df["dirscale"]))
    final_df['Dirminus'] = np.where(final_df["oi_shares"]>0, final_df["shortfut"]*final_df["dirscale"],
                                                                        -(final_df["longfut"]*final_df["dirscale"]))
    
    final_df.dropna(inplace=True)
    final_df.reset_index(inplace=True, drop=True)
    for i in range(0,len(final_df)):
        
        print final_df['symbol'][i]
        final_df["scaledown"][i]=(int(final_df["oi_shares"][i]*2)+(final_df["Arblong"][i]+final_df["Arbshort"][i]+final_df["longfut"][i]+final_df["shortfut"][i]))/2
    
        try:
            final_df["Arblongtwo"][i]=final_df["scaledown"][i]*(final_df["Arblong"][i]/(final_df["Arblong"][i]+final_df["Arbshort"][i]+final_df["futlong"][i]+final_df["futshort"][i]))
        except:
            final_df["Arblongtwo"][i]=0
        
        try:
            final_df["Arbshorttwo"][i]=final_df["scaledown"][i]*(final_df["Arbshort"][i]/(final_df["Arblong"][i]+final_df["Arbshort"][i]+final_df["futlong"][i]+final_df["futshort"][i]))
        except:
            final_df["Arbshorttwo"][i]=0
    
        try:
            final_df["Dirlong"][i]=final_df["scaledown"][i]*(final_df["futlong"][i]/(final_df["Arblong"][i]+final_df["Arbshort"][i]+final_df["futlong"][i]+final_df["futshort"][i]))
        except:
            final_df["Dirlong"][i]=0
        
        try:
            final_df["Dirshort"][i]=final_df["scaledown"][i]*(final_df["futshort"][i]/(final_df["Arblong"][i]+final_df["Arbshort"][i]+final_df["futlong"][i]+final_df["futshort"][i]))
        except:
            final_df["Dirshort"][i]=0
        
        if final_df["oi_shares"][i]>0:
            final_df["Arblongtwotwo"][i]=final_df["Arblongtwo"][i]
        else:
            final_df["Arblongtwotwo"][i]=-(final_df["Arbshorttwo"][i])
        
        if final_df["oi_shares"][i]>0:
            final_df["Arbshorttwothree"][i]=final_df["Arbshorttwo"][i]
        else:
            final_df["Arbshorttwothree"][i]=-(final_df["Arblongtwo"][i])
        
        if final_df["oi_shares"][i]>0:
            final_df["dirlongfour"][i]=final_df["Dirlong"][i]
        else:
            final_df["dirlongfour"][i]=-(final_df["Dirshort"][i])
        
        if final_df["oi_shares"][i]>0:
            final_df["dirshortfive"][i]=final_df["Dirshort"][i]
        else:
            final_df["dirshortfive"][i]=-(final_df["Dirlong"][i])
        
        final_df["POS"][i]=final_df["Arblongtwotwo"][i]+final_df["dirshortfive"][i]
    
        final_df["OIXtwo"][i]=final_df["oi_shares"][i]*2
        
    
    final_df["OI_Chg($mn)"]=np.divide(np.divide(np.multiply(final_df["oi_shares"],final_df["close"]),dollar),1000000.00)
    final_df["Arb_long($mn)"]=np.divide(np.divide(np.multiply(final_df["close"],final_df["Arbplusadj"]),dollar),1000000.00)
    final_df["Arb_short($mn)"]=np.divide(np.divide(np.multiply(final_df["close"],final_df["Arbminustwo"]),dollar),1000000.00)
    
    final_df["Res+"]=np.subtract(np.subtract(final_df["oi_shares"],final_df["Arbplusadj"]),final_df["Dirplus"])
    final_df["Res-"]=np.subtract(np.subtract(final_df["oi_shares"],final_df["Arbminustwo"]),final_df["Dirminus"])
    final_df["nonarblong"]=np.add(final_df["Dirplus"],final_df["Res+"])
    final_df["nonarbshort"]=np.add(final_df["Dirminus"],final_df["Res-"])
    
    final_df["Non_Arb_long($mn)"]=np.divide(np.divide(np.multiply(final_df["close"],final_df["nonarblong"]),dollar),1000000.00)
    final_df["Non_Arb_short($mn)"]=np.divide(np.divide(np.multiply(final_df["close"],final_df["nonarbshort"]),dollar),1000000.00)
        
    
    # final_df.replace([np.inf, -np.inf], np.nan, inplace=True)
    # final_df.fillna(0, inplace=True)
    final_df["change_open_int"]=final_df["change_open_int"].round(2)
    final_df[["OI_Chg($mn)","Arb_long($mn)","Arb_short($mn)","Non_Arb_long($mn)","Non_Arb_short($mn)"]]=final_df[["OI_Chg($mn)","Arb_long($mn)","Arb_short($mn)","Non_Arb_long($mn)","Non_Arb_short($mn)"]].round()
    final_df['pxchange'] = final_df['pxchange'].round(2)
    final_df.to_excel("ssfdebugdata.xlsx")
    final_df=final_df[["BloomCode","pxchange","change_open_int","OI_Chg($mn)","Arb_long($mn)","Arb_short($mn)","Non_Arb_long($mn)","Non_Arb_short($mn)"]]
    final_df.sort_values(by=["BloomCode"],inplace=True)    
    
    
    final_df.rename(columns={"change_open_int":"OI_Chg %","BloomCode":"BERG", "pxchange":"Px_chg %"}, inplace=True)
    final_df.to_excel(output_dir+"SSF Positioning daily {}.xlsx".format(datetime.datetime.strftime(d, "%d %b %Y")),index=False)
    final_df.to_excel(email_dir+"SSF Positioning daily {}.xlsx".format(datetime.datetime.strftime(d, "%d %b %Y")),index=False)

    
    #final_df1.to_excel("lastbasis.xlsx",index=False)
    
start_time = time.time()

if __name__ == '__main__':
    main(nd=0)  # set dollar value and (nd = timedelta) days here 
            

end_time = time.time()

logging.info('Time taken to process :'.format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)
