# hello.py
#import numpy as np
import xlwings as xw
import pandas as pd
import datetime 
#import matplotlib.pyplot as plt
import redis 
import win32api
import os, sys, time
import numpy as np
import warnings
warnings.filterwarnings("ignore")


excel_front_end_path = "Realtimebasis.xlsm"
#redis_host = "localhost"
redis_host = "10.223.104.86"


def get_timer(length):
    '''Func to get start and end times for processing '''
    
    time_buckets = [datetime.time(9,15),datetime.time(10,0),datetime.time(10,30),datetime.time(11,0),datetime.time(11,30),
                 datetime.time(12,0),datetime.time(12,30),datetime.time(13,0),datetime.time(13,30),datetime.time(14,0),
                 datetime.time(14,30),datetime.time(15,0),datetime.time(15,30)]
    
    time_range = [i for i in range(3,42,3)]
    
    if length in time_range:
        index =  time_range.index(length)
        return time_buckets[index],time_buckets[index+1]

    

def get_params(expiry):
    '''Func to display all the set params set by user from redis to excel'''

    # mock caller for debugging 
    xw.Book(excel_front_end_path).set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()    
    # redis server connection
    print "Connecting to redis {}".format(redis_host)
    r = redis.Redis(host=redis_host, port=6379) 
    rtime = time.time()
    print "Connected..."
    # get all redis keys for all the set params
    dividends = r.keys('*_dividend_{}'.format(expiry))
    fa = r.keys('*_fa_{}'.format(expiry))
    ra = r.keys('*_ra_{}'.format(expiry))
    df = pd.DataFrame({'Dividend':dividends, 'FA':fa, 'RA':ra })
    # get all symbols set so far
    symbols = set(df.apply(lambda row: row['FA'].split('_')[0] , axis=1))
    # get all the time frames 
    timeframes = set(df.apply(lambda row: '_'.join(row['FA'].split('_')[1:3]) , axis=1))
    
    result_df = pd.DataFrame()
    for time_ in list(sorted(timeframes)):
        result = []
        for symbol in list(sorted(symbols)):
            result.append({'Symbol': symbol, 'Dividend': r.get('{}_{}_dividend_{}'.format(symbol, time_,expiry)),
                           'FA':r.get('{}_{}_fa_{}'.format(symbol, time_,expiry)),
                           'RA':r.get('{}_{}_ra_{}'.format(symbol, time_,expiry))})

        result = pd.DataFrame(result)
        result.set_index('Symbol',inplace=True)
        result_df = pd.concat([result_df, result], axis=1)
    
    print "Data fetched from redis...time taken {}".format(time.time()-rtime)
       
    if expiry=='m1':         
        # flush perivous results and append new 
        wb.sheets[1].range('A5:AP210').value = ''        
        wb.sheets[1].range('A4').value = result_df          
        win32api.MessageBox(wb.app.hwnd, "Current Month Parameters imported !","Success !")   
    elif expiry=='m2':
        # flush perivous results and append new 
        wb.sheets[4].range('A5:AP210').value = ''        
        wb.sheets[4].range('A4').value = result_df        
        win32api.MessageBox(wb.app.hwnd, "Next Month Parameters imported !","Success !")  
        
            



def set_params(expiry):
    '''Func to fetch parameters from excel and write to redis'''
    
    # mock caller for debugging 
    xw.Book(excel_front_end_path).set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()
    dollar_value = 0
    # redis server connection
    print "Setting data to reids {}".format(redis_host)
    r = redis.Redis(host=redis_host, port=6379)   
    print "Connected to redis"
    rtime = time.time()
    data = pd.DataFrame()
    if expiry=='m1':
        # Read entire excel data
        data = pd.DataFrame( wb.sheets[0].range('A5').expand('table').value )  # gets contents in list format with (symbol, div, FA, RA)
        temp = data.set_index([0])
        for col in temp.columns:
            if temp[col].dtype=='O':
                for index,row in temp[[col]].iterrows():                    
                    try :
                        int(row[col])
                    except:
                        print "Data entered for {} is not a number".format(index)
                        win32api.MessageBox(wb.app.hwnd, 
                                            "Data entered for {} is not a number".format(index),"Error !")
                        sys.exit()      
        
        dollar_value = wb.sheets[0].range('B2').value  # dollar value
        r.set('dollar_value', dollar_value)
        
    elif expiry=='m2':
        # Read entire excel data
        data = pd.DataFrame( wb.sheets[3].range('A5').expand('table').value )  # gets contents in list format with (symbol, div, FA, RA)
        
        temp = data.set_index([0])
        for col in temp.columns:
            if temp[col].dtype=='O':
                for index,row in temp[[col]].iterrows():                    
                    try :
                        int(row[col])
                    except:
                        print "Data entered for {} is not a number".format(index)
                        win32api.MessageBox(wb.app.hwnd, 
                                            "Data entered for {} is not a number".format(index),"Error !")
                        sys.exit()            
        
        
        
    # drop symbols that have no parameters set
    data.dropna(inplace=True)
    print "Excel data reading time {}".format(time.time()-rtime)
    rtime=time.time()
    while len(data.columns)-1 != 0:
        
        # get start time and end times
        starttime, endtime = get_timer(len(data.columns)-1)           
        # read symbols
        data[0] = data[0].str.strip()
        symbols = data[0].values
        # parameters
        params = data.iloc[:, -3:]
        params.columns = ['dividend','fa','ra'] # set column names 
        params.index = symbols
        
        if len(params[params['dividend']<0])!=0:
            print "Dividend can not be less than zero "
            dividend_err_symbols = ', '.join(list(params[params['dividend']<0].index.values))
            win32api.MessageBox(wb.app.hwnd, "Time Frame {} - {} \n Dividend cannot be less than zero for {} \n Exit ! ".format(starttime,endtime, 
                                dividend_err_symbols),"Error !")
            sys.exit()
        
                       
        print "Writing data"
        # write params to redis
        for symbol in symbols:
            r.set(symbol+'_'+str(starttime)[:-3]+'_'+str(endtime)[:-3]+'_'+'dividend_{}'.format(expiry), params.loc[symbol].values[0] )
            r.set(symbol+'_'+str(starttime)[:-3]+'_'+str(endtime)[:-3]+'_'+'fa_{}'.format(expiry), params.loc[symbol].values[1] )
            r.set(symbol+'_'+str(starttime)[:-3]+'_'+str(endtime)[:-3]+'_'+'ra_{}'.format(expiry), params.loc[symbol].values[2] )
        print "done"
        # update data
        data = data.iloc[:, :-3]        
    r.set('param_flag_{}'.format(expiry), 1)   #params flag set 
    
    if expiry=='m2':
        # set flag only if next month params set
        r.set('param_cumulative_flag_m2',1)
        
    print "Redis data writing time {}".format(time.time()-rtime)
    print "Params set on redis"   
        
    win32api.MessageBox(wb.app.hwnd, "Parameters Set !","Success !")
    #os.system('X:\\Data_Analytics\\Basis_Project\\compute.bat')
    
    
def result(expiry):
    '''Fetch results for set params'''
     
    # show result tab func 
    # mock caller for debugging 
    xw.Book(excel_front_end_path).set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()
        
    result = pd.DataFrame(); symbols=''
    if expiry=='m1':
        df = pd.DataFrame( wb.sheets[0].range('A5').expand('table').value ) 
        symbols = list(df[0].str.strip().values)   # display only those symbols that r set by user for current month
        result['Symbol'] = symbols
    elif expiry=='m2':
        df = pd.DataFrame( wb.sheets[3].range('A5').expand('table').value ) 
        symbols = list(df[0].str.strip().values)   # display only those symbols that r set by user for next month
        result['Symbol'] = symbols
        
        
    # read result files from redis 
    r = redis.Redis(host=redis_host, port=6379) 
    print "Connected to redis"
    rtime=time.time()
    result_files = sorted(r.keys('result_*'))
       
    result_files = list(sorted([ x for x in result_files if x.startswith('result')])) # filter only result files 
    result_files = list(sorted( [ x for x in result_files if x.endswith(expiry)] ))  # filter on current month m1
    
        
    for res in result_files:
        # read the published msgpack
        df = pd.read_msgpack(r.get('{}'.format(res)))
        df = df[df.Symbol.isin(symbols)][['Symbol','dividend','FA','RA','Short Futs','Long Futs', 'Min','Max','Spread_bps avg','5%','95%',
                'fa avg','ra avg','Shortfuts avg','Longfuts avg']]
        result = result.merge(df, on='Symbol', how='left')
                 
            
    result.set_index('Symbol', inplace=True)
    print "Displaying data..."
    cols = result.columns.values
    cols = { x: 'Dividend' if x.startswith('dividend') else 'FA' if x.startswith('FA') else 'RA' if x.startswith('RA') else 'Short Futs' if x.startswith('Short Futs') else 'Long Futs' if x.startswith('Long Futs') else 'Min' if x.startswith('Min') else 'Max' if x.startswith('Max') else 'Spread bps avg' if x.startswith('Spread_bps avg') else '5%' if x.startswith('5%') else '95%' if x.startswith('95%') else 'FA avg' if x.startswith('fa avg') else 'RA avg' if x.startswith('ra avg') else 'Shortfuts avg' if x.startswith('Shortfuts avg') else 'Longfuts avg' if x.startswith('Longfuts avg') else None  for x in cols }
    result.rename(columns = cols, inplace=True)
    
    try:
        if expiry=='m1':
            # processing flag for current month            
            if int(r.get('processing_flag_m1')) == 1:
                wb.sheets[2].range('A3').color = (240,112,122) # color alert
                wb.sheets[2].range('A3').value = 'Processing'
            elif int(r.get('processing_flag_m1')) == 0:
                wb.sheets[2].range('A3').color = (17,213,30) # color alert
                wb.sheets[2].range('A3').value = 'Done'
                
        elif expiry=='m2':            
            # processing flag for next month            
            if int(r.get('processing_flag_m2')) == 1:
                wb.sheets[5].range('A3').color = (240,112,122) # color alert
                wb.sheets[5].range('A3').value = 'Processing'
            elif int(r.get('processing_flag_m2')) == 0:
                wb.sheets[5].range('A3').color = (17,213,30) # color alert
                wb.sheets[5].range('A3').value = 'Done'
    except:
        pass
            
    print "Writing data to excel"
    print "Redis-Excel data writing time {}".format(time.time()-rtime)
    
    if expiry=='m1':         
        # flush perivous results and append new 
        wb.sheets[2].range('A5:FT210').value = ''        
        wb.sheets[2].range('A4').value = result          
        win32api.MessageBox(wb.app.hwnd, "Current Month results imported !","Success !")
    elif expiry=='m2':
        # flush perivous results and append new 
        wb.sheets[5].range('A5:FT210').value = ''        
        wb.sheets[5].range('A4').value = result          
        win32api.MessageBox(wb.app.hwnd, "Next Month results imported !","Success !")
        
         
def cumulative_computation_func(r, today_files):
    '''Func to do cummulative compuation for any given month'''
    
    rtime=time.time()
    df = pd.DataFrame()  
    for f in today_files:
        df = df.append(pd.read_msgpack(r.get(f)))
    
    result = []
    if len(df)==0:
        return pd.DataFrame()
    for gname, gelements in df.groupby(['Symbol']):
        
        gelements = gelements[gelements['LTP_cash']!=0]
        if len(gelements)!=0:            
        
            sum_fa = gelements[gelements['FA/RA'] == 'FA']['cfvolume'].sum() # filter on fa
            sum_ra = gelements[gelements['FA/RA'] == 'RA']['cfvolume'].sum() # filter on ra    
            sum_short_futs = gelements['Short Futs'].sum() 
            sum_long_futs = gelements['Long Futs'].sum() 
            min_spread = gelements['spread_bps'].min()
            max_spread = gelements['spread_bps'].max()
            spread_bps_avg = gelements['spread_bps'].mean()
            quantile_5, quantile_95 = gelements['spread_bps'].quantile([0.05,0.95])
            fa_average  = gelements[gelements['FA/RA'] == 'FA']
            fa_average = np.sum(fa_average['spread_bps']*fa_average['cfvolume'])/np.sum(fa_average['cfvolume'])  # weighted average
                
            ra_average = gelements[gelements['FA/RA'] == 'RA']
            ra_average = np.sum(ra_average['spread_bps']*ra_average['cfvolume'])/np.sum(ra_average['cfvolume'])  # weighted average
                
            short_futs_avg = np.sum(gelements['Short Futs']*gelements['spread_bps'])/np.sum(gelements['Short Futs']) 
            long_futs_avg = np.sum(gelements['Long Futs']*gelements['spread_bps'])/np.sum(gelements['Long Futs']) 
            
                
            result.append([gname, sum_fa, sum_ra ,round(sum_short_futs), round(sum_long_futs), round(min_spread),
                               round(max_spread),round(spread_bps_avg), round(quantile_5), round(quantile_95), round(fa_average), round(ra_average),
                               round(short_futs_avg), round(long_futs_avg)])
                
    result = pd.DataFrame(result, columns=['Symbol','FA','RA','Short Futs','Long Futs','Min','Max','Spread bps avg','5%','95%',
                                               'fa avg','ra avg','Shortfuts avg','Longfuts avg'])
    print "Cumm computation time {}".format(time.time()-rtime)
    
    return result    


def price_Oi_change(cur_dir,re):
    '''Func to get price and OI change for current month'''
   
    rtime=time.time()
    os.chdir(cur_dir) # change dir to current excel front end dir 
 
    expiry_dates_master = pd.read_csv('Expiry_dates_master.csv')
    expiry_dates_master['date'] = expiry_dates_master.apply(lambda row: pd.to_datetime(str(row['Date'])+row['Month']+str(row['Year'])).date(),
                           axis=1)
    expiry_dates_master = expiry_dates_master[expiry_dates_master['Expiry']=='E']['date']
    
    # read prev day bhavcopy from redis 
    df = pd.read_msgpack(re.get("prev_bhavcopy"))
    df['EXPIRY_DT'] = pd.to_datetime(df['EXPIRY_DT'], format='%d-%b-%Y').dt.date
    df['TIMESTAMP'] = pd.to_datetime(df['TIMESTAMP'], format='%d-%b-%Y').dt.date
        
    d = df['TIMESTAMP'][0]  

    df = df[df['INSTRUMENT']=='FUTSTK'][['SYMBOL','EXPIRY_DT','OPEN_INT']]
    df['EXPIRY_DT'] = df['EXPIRY_DT'].apply(lambda row: pd.to_datetime(row))
    res = pd.DataFrame()
    if d not in expiry_dates_master.values:
        res = df.sort_values(by='EXPIRY_DT').groupby(['SYMBOL'], sort=True).head(2)   # oi = m1+m2
        res = res.groupby(['SYMBOL']).agg({'OPEN_INT':'sum'}).reset_index()
    else:
        res = df.sort_values(by='EXPIRY_DT').groupby(['SYMBOL'], sort=True).tail(2)  # oi = m2+m3
        res = res.groupby(['SYMBOL']).agg({'OPEN_INT':'sum'}).reset_index()
    res.rename(columns={'SYMBOL':'Symbol'}, inplace=True)  
    
    
    
    # get close price and OI from redis dumped files 
    cp_oi_df = pd.DataFrame()
    for f in list(re.keys('price_oi_chg_*')):
        cp_oi_df = pd.concat([cp_oi_df, pd.read_msgpack(re.get(f))], axis=0)
    cp_oi_df = cp_oi_df.sort_values(by='time').groupby(['Symbol'],sort=True).last().reset_index()[['Symbol','time','ClosePrice','OI']]  # get futures LTP from dumped redis files
    
    # get LTP files from processed market files dumped in redis 
    d = datetime.date.today()
    today_files = ''.join(['0'+str(d.day) if len(str(d.day))==1 else str(d.day),'0'+str(d.month) if len(str(d.month))==1 else str(d.month),
                 str(d.year)])
    today_files = list(re.keys('{}*'.format(today_files)))
    
    
    today_files_m1 = [ x for x in today_files if x.endswith('_m1')]
    today_files_m2 = [ x for x in today_files if x.endswith('_m2')]
    ltp_df_m1 = pd.DataFrame()
    for f in today_files_m1:
        ltp_df_m1 = pd.concat([ltp_df_m1, pd.read_msgpack(re.get(f))], axis=0)
    ltp_df_m1 = ltp_df_m1.sort_values(by='time').groupby(['Symbol'],sort=True).last().reset_index()[['Symbol','LTP_fut']]  # get futures LTP from dumped redis files
    
    # next month
    ltp_df_m2 = pd.DataFrame()
    for f in today_files_m2:
        ltp_df_m2 = pd.concat([ltp_df_m2, pd.read_msgpack(re.get(f))], axis=0)
    ltp_df_m2 = ltp_df_m2.sort_values(by='time').groupby(['Symbol'],sort=True).last().reset_index()[['Symbol','LTP_fut']]  # get futures LTP from dumped redis files
    
    ltp_df = ltp_df_m1.merge(ltp_df_m2, on="Symbol", how="left", suffixes=('_m1', '_m2'))
    
       
    cp_oi_df = cp_oi_df.merge(ltp_df, on='Symbol', how='left')
    cp_oi_df = cp_oi_df.merge(res, on='Symbol', how='left')
    
    cp_oi_df['OPEN_INT'] = cp_oi_df['OPEN_INT'].fillna(0)
    
    # handle coporate actions here
    
    
    cp_oi_df['Px_chg'] = (cp_oi_df['LTP_fut_m1'] - cp_oi_df['ClosePrice'])/ cp_oi_df['ClosePrice']* 100
    cp_oi_df['OI_Chg_quantity'] = cp_oi_df['OI']- cp_oi_df['OPEN_INT']
    cp_oi_df['OI_chg'] = (cp_oi_df['OI_Chg_quantity'])/ cp_oi_df['OPEN_INT']* 100
    
    # round till 2 decimals 
    cp_oi_df['Px_chg'] = cp_oi_df['Px_chg'].round(2)
    cp_oi_df['OI_chg'] = cp_oi_df['OI_chg'].round(2)
    #cp_oi_df['OI_Chg ($mn)'] = cp_oi_df['OI_Chg ($mn)']*dollar_value/10000  # oi change mn dollars
    dollar_value = 69
    if re.get('dollar_value')!=None:
        dollar_value = float(re.get('dollar_value'))
    cp_oi_df.dropna(subset=['OI_Chg_quantity'], inplace=True)
    # convert into million dollars 
    cp_oi_df['OI_Chg ($mn)'] = cp_oi_df.apply(lambda row: int( row['OI_Chg_quantity']*row['LTP_fut_m1']/(1000000*dollar_value)) if row['OI_Chg_quantity']!=0 else 0,axis=1 ) 
    #result_m1['OI_Chg_quantity'] = result_m1['OI_Chg_quantity'].round()
       
    cp_oi_df = cp_oi_df[['Symbol','Px_chg','OPEN_INT','OI','OI_Chg_quantity','OI_chg','OI_Chg ($mn)','LTP_fut_m1','LTP_fut_m2']]
    print "price/oi chg time {}".format(time.time()-rtime)
    
    
    return cp_oi_df



def cumulative_result(cur_dir):
    '''Func to display cummulative result for all the files'''
    
    # method to get cumulative results
    xw.Book(excel_front_end_path).set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()
    
    #starttime = str(wb.sheets[3].range('B1').value)
    r = redis.Redis(host=redis_host, port=6379) 
    print "Connected to redis"
    dollar_value = 68.5
    if r.get('dollar_value')!=None:
        dollar_value = float(r.get('dollar_value'))
    #endtime = str(wb.sheets[3].range('B2').value)
    # get all result files and filter on starttime and endtime 
    d = datetime.date.today()
    today_files = ''.join(['0'+str(d.day) if len(str(d.day))==1 else str(d.day),'0'+str(d.month) if len(str(d.month))==1 else str(d.month),
                 str(d.year)])
            
    today_files = list(sorted(r.keys('bpsresult_{}_*'.format(today_files))))
    today_files_m1 = list(sorted( [ x for x in today_files if x.endswith('m1')] ))  # filter on current month m1
    today_files_m2 = list(sorted( [ x for x in today_files if x.endswith('m2')] ))  # filter on next month m2
    print "File for today read from redis"
    # current month day cummulative     
    #result.reset_index(inplace=True)
    # but filter on symbol that are set by the user 
    symbols_m1 = pd.DataFrame( wb.sheets[0].range('A5').expand('table').value ) 
    symbols_m1 = list(symbols_m1[0].str.strip().values)   # display only those symbols that r set by user    
    result_m1 = cumulative_computation_func(r, today_files_m1)
    result_m1 = result_m1[result_m1['Symbol'].isin(symbols_m1)]   #filter on symbols that r set 
    # get price and OI change 
    print "Price and OI changes"
    price_oi_chg_df = price_Oi_change(cur_dir,r)
    price_oi_chg_df_m1 = price_oi_chg_df[price_oi_chg_df['Symbol'].isin(symbols_m1)]  # filter on set symbols 
    
    result_m1 = price_oi_chg_df_m1.merge(result_m1, on='Symbol',how='left')  
    
    result_m1.set_index('Symbol', inplace=True)
    result_m1.dropna(how="all", inplace=True)
    result_m1.reset_index(inplace=True)
    print "Price and OI changes successfully fetched..."
    
    # fa ra levels into million dollars 
    #result_m1.to_csv('debug.csv')
    result_m1['Arb_long ($mn)'] = result_m1.apply(lambda row: row['RA']*row['LTP_fut_m1']/(1000000*dollar_value) if row['RA']!=0 or row['RA']!=np.NaN else 0, axis=1 ) 
    #result_m1['FA'] = result_m1['FA'].round()
    result_m1['Arb_short ($mn)'] = result_m1.apply(lambda row: row['FA']*row['LTP_fut_m1']/(1000000*dollar_value) if row['FA']!=0 or row['FA']!=np.NaN else 0, axis=1 ) 
        
    #result_m1['RA'] = result_m1['RA'].round()
    result_m1['Non_Arb_long ($mn)'] = result_m1.apply(lambda row: row['Long Futs']*row['LTP_fut_m1']/(1000000*dollar_value) if row['Long Futs']!=0 or row['Long Futs']!=np.NaN else 0, axis=1 ) 
    #result_m1['Short Futs'] = result_m1['Short Futs'].round()
    result_m1['Non_Arb_short ($mn)'] = result_m1.apply(lambda row: row['Short Futs']*row['LTP_fut_m1']/(1000000*dollar_value) if row['Short Futs']!=0 or row['Short Futs']!=np.NaN else 0, axis=1 ) 
    #result_m1['Long Futs'] = result_m1['Long Futs'].round()
    result_m1[['OI_Chg ($mn)','Arb_short ($mn)','Arb_long ($mn)','Non_Arb_short ($mn)','Non_Arb_long ($mn)']] = result_m1[['OI_Chg ($mn)',
               'Arb_short ($mn)','Arb_long ($mn)','Non_Arb_short ($mn)','Non_Arb_long ($mn)']].round()
    result_m1 = result_m1[['Symbol','Px_chg','OPEN_INT','OI','OI_chg','OI_Chg_quantity','OI_Chg ($mn)',
                           'FA','Arb_short ($mn)','RA','Arb_long ($mn)','Short Futs','Non_Arb_short ($mn)',
                           'Long Futs','Non_Arb_long ($mn)','Min','Max','Spread bps avg','5%','95%','fa avg','ra avg',
                           'Shortfuts avg','Longfuts avg']]

    
    result_m1.set_index('Symbol', inplace=True)
    
    print "Result computation done ..."
    # next month day cummulative result 
    # if cond to handle if next param not set 
    wb.sheets[6].range('Z5:AQ210').value = ''
    
    if int(r.get('param_cumulative_flag_m2') if r.get('param_cumulative_flag_m2')!= None else 0 )==1:  
        print "next month cumulative...."
        symbols_m2 = pd.DataFrame( wb.sheets[3].range('A5').expand('table').value ) 
        symbols_m2 = list(symbols_m2[0].str.strip().values)   # display only those symbols that r set by user    
        result_m2 = cumulative_computation_func(r, today_files_m2)
    
        
        if len(result_m2)>0:
            
            result_m2 = result_m2[result_m2['Symbol'].isin(symbols_m2)]        
            
            # get price and OI change
            price_oi_chg_df_m2 = price_oi_chg_df[price_oi_chg_df['Symbol'].isin(symbols_m2)][['Symbol','LTP_fut_m2']]  # filter on set symbols 
            
            result_m2 = price_oi_chg_df_m2.merge(result_m2, on='Symbol',how='left') 
            
            result_m2.set_index('Symbol', inplace=True)
            result_m2.dropna(how="all", inplace=True)
            result_m2.reset_index(inplace=True)
            
            # fa ra levels into million dollars 
            result_m2.to_csv('debug.csv', index=False)
            result_m2[['FA','RA','Long Futs','Short Futs']] = result_m2[['FA','RA','Long Futs','Short Futs']].fillna(0)
            
            
            result_m2['Arb_long ($mn)'] = result_m2.apply(lambda row: row['RA']*row['LTP_fut_m2']/(1000000*dollar_value) if row['RA']!=0 or row['RA']!=np.NaN else 0, axis=1 ) 
            #result_m1['FA'] = result_m1['FA'].round()
            result_m2['Arb_short ($mn)'] = result_m2.apply(lambda row: row['FA']*row['LTP_fut_m2']/(1000000*dollar_value) if row['FA']!=0 or row['FA']!=np.NaN else 0, axis=1 ) 
                
            #result_m1['RA'] = result_m1['RA'].round()
            result_m2['Non_Arb_long ($mn)'] = result_m2.apply(lambda row: row['Long Futs']*row['LTP_fut_m2']/(1000000*dollar_value) if row['Long Futs']!=0 or row['Long Futs']!=np.NaN else 0, axis=1 ) 
            #result_m1['Short Futs'] = result_m1['Short Futs'].round()
            result_m2['Non_Arb_short ($mn)'] = result_m2.apply(lambda row: row['Short Futs']*row['LTP_fut_m2']/(1000000*dollar_value) if row['Short Futs']!=0 or row['Short Futs']!=np.NaN else 0, axis=1 ) 
            #result_m1['Long Futs'] = result_m1['Long Futs'].round()
            result_m2[['Arb_short ($mn)','Arb_long ($mn)','Non_Arb_short ($mn)','Non_Arb_long ($mn)']] = result_m2[['Arb_short ($mn)',
                       'Arb_long ($mn)','Non_Arb_short ($mn)','Non_Arb_long ($mn)']].round()
            result_m2 = result_m2[['Symbol','FA','Arb_short ($mn)','RA','Arb_long ($mn)','Short Futs','Non_Arb_short ($mn)',
                                   'Long Futs','Non_Arb_long ($mn)','Min','Max','Spread bps avg','5%','95%','fa avg','ra avg',
                                   'Shortfuts avg','Longfuts avg']]
                
            result_m2.set_index('Symbol', inplace=True)  
          
            # display next month             
            wb.sheets[6].range('Z4').value = result_m2   
            print "Computation for next month done..."
        else:
            print "No next month params set; Reset param flag for next month"
            r.set('param_cumulative_flag_m2',0)
            
        
        
    # total Current month and next month cullumative logic here 
    today_files_cum = today_files_m1+today_files_m2   

    result_cum = cumulative_computation_func(r, today_files_cum)
    result_cum = result_cum[result_cum['Symbol'].isin(symbols_m1)]
    result_cum = result_cum.merge(price_oi_chg_df_m1[['Symbol','LTP_fut_m1']], on="Symbol", how="left" )
    
    # fa ra levels into million dollars
    result_cum.set_index('Symbol', inplace=True)
    result_cum.dropna(how="all", inplace=True)
    result_cum.reset_index(inplace=True)
    #result_m1.to_csv('debug.csv')
    result_cum['Arb_long ($mn)'] = result_cum.apply(lambda row: row['RA']*row['LTP_fut_m1']/(1000000*dollar_value) if row['RA']!=0 or row['RA']!=np.NaN else 0, axis=1 ) 
    #result_m1['FA'] = result_m1['FA'].round()
    result_cum['Arb_short ($mn)'] = result_cum.apply(lambda row: row['FA']*row['LTP_fut_m1']/(1000000*dollar_value) if row['FA']!=0 or row['FA']!=np.NaN else 0, axis=1 ) 
    
    #result_m1['RA'] = result_m1['RA'].round()
    result_cum['Non_Arb_long ($mn)'] = result_cum.apply(lambda row: row['Long Futs']*row['LTP_fut_m1']/(1000000*dollar_value) if row['Long Futs']!=0 or row['Long Futs']!=np.NaN else 0, axis=1 ) 
    #result_m1['Short Futs'] = result_m1['Short Futs'].round()
    result_cum['Non_Arb_short ($mn)'] = result_cum.apply(lambda row: row['Short Futs']*row['LTP_fut_m1']/(1000000*dollar_value) if row['Short Futs']!=0 or row['Short Futs']!=np.NaN else 0, axis=1 ) 
    #result_m1['Long Futs'] = result_m1['Long Futs'].round()
    result_cum[['Arb_short ($mn)','Arb_long ($mn)','Non_Arb_short ($mn)','Non_Arb_long ($mn)']] = result_cum[['Arb_short ($mn)',
               'Arb_long ($mn)','Non_Arb_short ($mn)','Non_Arb_long ($mn)']].round()
    result_cum = result_cum[['Symbol','FA','Arb_short ($mn)','RA','Arb_long ($mn)','Short Futs','Non_Arb_short ($mn)',
                           'Long Futs','Non_Arb_long ($mn)','Min','Max','Spread bps avg','5%','95%','fa avg','ra avg',
                               'Shortfuts avg','Longfuts avg']]
            
        
    result_cum.set_index('Symbol', inplace=True)
    print "Merging done"
    # flush perivous results and append new 
    # display current month cummulative 
    #wb.sheets[6].range('T5:AF210').value = ''   
    wb.sheets[6].range('A5:W210').value = ''    
    wb.sheets[6].range('A4').value = result_m1    
     
    # display total cumulative
    wb.sheets[6].range('AS5:BJ210').value = ''    
    wb.sheets[6].range('AS4').value = result_cum   
    
        
    win32api.MessageBox(wb.app.hwnd, "Results imported !","Success !")   
    

#cumulative_result("D:\Basis_Project")

def main(args):
    
    
    if args:
        if args[0] == "setparams1":
            set_params('m1')
        elif args[0] == "setparams2":
            set_params('m2')
        elif args[0] == "getparams1":
            get_params('m1')
        elif args[0] == "getparams2":
            get_params('m2')
        elif args[0] == "result1":
            result('m1')
        elif args[0] == "result2":
            result('m2')
        elif args[0] == "cumulative":
            cumulative_result(args[1])
        elif args[0] == "email_next":
            r = redis.Redis(host=redis_host, port=6379) 
            r.set("email_next_month_flag",1)
            xw.Book(excel_front_end_path).set_mock_caller()
            # book instance for reading values from excel file 
            wb = xw.Book.caller()
            win32api.MessageBox(wb.app.hwnd, "Next month results will be included in the email !","Success !")   
            

if __name__ == "__main__":
    main(sys.argv[1:])

#RunFrozenPython (ThisWorkbook.path & "\build\exe.win-amd64-2.7\excel_redis_interface.exe")
#RunPython ("import excel_redis_interface; excel_redis_interface.get_params()")
#RunPython ("import excel_redis_interface; excel_redis_interface.result()")

"""
import redis
redis_host = "10.223.104.61"
r = redis.Redis(host=redis_host, port=6379) 
r.set("processing_flag_m2",0)
r.set('param_cumulative_flag_m2',0)
"""