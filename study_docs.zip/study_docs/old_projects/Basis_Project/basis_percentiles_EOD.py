# -*- coding: utf-8 -*-
"""
Created on Thu Feb 11 16:36:24 2021

@author: krishna
"""
import pandas as pd
import numpy as np
import datetime,os,time
from cassandra.cluster import Cluster
import warnings
warnings.filterwarnings("ignore")

master_dir = "D:\\Master\\"
output_dir = r"\\172.17.9.22\Users2\Derivatives Eod\EOD Confirms NAVNEET\GoldmanInput\Basis Percentiles"

cassandra_host = "172.17.9.51"
#redis_host = "localhost"


# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):

    '''Pandas factory to determine cassandra data into python df'''
    return pd.DataFrame(rows, columns=colnames)



def dateparse(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]

    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)

    return cluster

# read holiday master
holiday_master = pd.read_csv(master_dir+ 'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

cluster = cassandra_configs_cluster()
session = cluster.connect('rohit')
#logging.info('Using test_df keyspace')
session.row_factory = pandas_factory
session.default_fetch_size = None

def previous_working_day(d):
    '''Get previous wokring day'''

    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                #print "Holiday : ",d
                d = d - datetime.timedelta(days=1)
            else:
                return d


def get_end_date(d,c):
    for i in range(0,c):
        prev=previous_working_day(d)
        d=prev
        #print d
    return d



def process_run_check(d):
    '''Func to check if the process should run on current day or not'''

    # check if working day or not
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded

        df = session.execute("select date from fno_basis where date='{}' allow filtering".format(d))
        df = df._current_rows

        while datetime.datetime.now().time() > datetime.time(16,0) and df.empty==True:
            print ('Sleep for 2 min...')
            time.sleep(120)
            df = session.execute("select date from fno_basis where date='{}' allow filtering".format(d))
            df = df._current_rows

        return 1

    elif len(holiday_master[holiday_master['date']==d])==1:
         print ('Holiday: skip for current date :{} '.format(d))
         return -1



def main(nd):

    d = datetime.datetime.now().date()-datetime.timedelta(days=nd)
    prev_d = get_end_date(d,60)

    if process_run_check(d)==-1:
         return -1

    df = session.execute("select symbol,date,percentile_5,percentile_95 from fno_basis where date>='{}' and date <='{}' allow filtering".format(prev_d, d))
    df = df._current_rows
    df = df[~df['symbol'].isin(['FINNIFTY','NIFTY','BANKNIFTY'])]
    df['date'] = df['date'].apply(lambda row: row.date())
    df.sort_values(by=['date'], ascending=True, inplace=True)
    df[['percentile_5','percentile_95']] = df[['percentile_5','percentile_95']].astype(float)

    # apply name change corporate action
    ca = pd.read_excel(master_dir+'Corporate_actions.xlsx')
    ca.dropna(subset=['Old_symbol','New_symbol'], inplace=True)
    for _, row in ca.iterrows():
         df['symbol'].replace(row['Old_symbol'], row['New_symbol'], inplace=True)


    # output sheet
    writer = pd.ExcelWriter(os.path.join(output_dir,"Basis_percentiles.xlsx"))
    df1 = df[['symbol','date','percentile_5']].pivot(index='symbol', columns='date', values='percentile_5')
    df1 = df1[df1.columns[::-1]]
    df2 = df[['symbol','date','percentile_95']].pivot(index='symbol', columns='date', values='percentile_95')
    df2 = df2[df2.columns[::-1]]

    #temp=df1.copy(deep=True)
    #temp=temp.astype(str)
    #temp = temp.applymap(lambda col: col.replace('.0',''))
    #temp.to_excel(writer, sheet_name='5%')
    df1.to_excel(writer, sheet_name='5%')
    df2.to_excel(writer, sheet_name='95%')

    # high low
    df1 = pd.DataFrame(df1.iloc[:,:5].min(axis=1)).reset_index(); df1.columns=['symbol','Low']
    df2 = pd.DataFrame(df2.iloc[:,:5].max(axis=1)).reset_index(); df2.columns=['symbol','High']

    df = pd.merge(df1, df2, on='symbol', how='inner')
    df.to_excel(writer, index=False, sheet_name='5days_high_low')
    #save data
    writer.save()
    writer.close()


if __name__=='__main__':
     main(0)

