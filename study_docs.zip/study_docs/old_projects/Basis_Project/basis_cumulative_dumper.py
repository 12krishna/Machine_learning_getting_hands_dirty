# -*- coding: utf-8 -*-
"""

@author: krishna
"""

import pandas as pd
import numpy as np
import datetime,os,time
from cassandra.cluster import Cluster
import redis
import warnings
warnings.filterwarnings("ignore")


os.chdir("D:\\Basis_Project\\")
import basis_cumulative_fetch

master_dir = "D:\\Master\\"

cassandra_host = "172.17.9.51"
redis_host = "localhost"
redis_prod = "10.223.104.86"


def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster

def get_data(d, flag):
        
    # get cumulative result for today 
    result = pd.DataFrame()
    while 1:
        try:
            result_tuple = basis_cumulative_fetch.cumulative_result(flag)
            if len(result_tuple)==2:
                print "getting current month values"
                result = result_tuple[0] 
            elif len(result_tuple)==3:
                print "next month values set...."
                result = result_tuple[1]
                
            result['date'] = d
        
            result = result[['Symbol','date', 'Px_chg', 'Min', 'Max', 'Spread bps avg', '5%', '95%', 'fa avg', 'ra avg',
                         'Shortfuts avg', 'Longfuts avg']]
            break
        except Exception as e:
            print e
            print "Sleep for 2 mins"
            time.sleep(120)
    return result
            
# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)


def main(nd):
    
    d = datetime.datetime.now().date()-datetime.timedelta(days=nd)
    cluster = cassandra_configs_cluster()
    session = cluster.connect('rohit')
    session.row_factory = pandas_factory
    session.default_fetch_size = None
    redis_client = redis.Redis(host=redis_host, port=6379)
    #session.execute("create table if not exists fno_basis (Symbol varchar,date date, Px_chg decimal, Min decimal, Max decimal, \
    #                Spread_bps_avg decimal, percentile_5 decimal, percentile_95 decimal, fa_avg decimal, ra_avg decimal, \
    #                Shortfuts_avg decimal, Longfuts_avg decimal, primary key (symbol, date) ) ")
    # dump current month data and if next month available dump
    redis_client_prod = redis.Redis(host=redis_prod, port=6379)
    
    for i in range(0,2):
        params_flag = redis_client_prod.get('param_flag_m{}'.format(i+1))
        if params_flag==None:
            print "Data for param_flag_m{} flag not set; skip......".format(i+1)
            continue     
        
        result = get_data(d, i)
        print "Getting data from redis; param_flag_m{} flag set".format(i+1)
        if result.empty==False:        
            # dump result in db
            result.to_csv("basis_cumm_dumper.csv", index=False)
            if i==0:
                if os.system("basis_cumm_dumper.bat")==0:
                    print "Data Successfully dumped for current month basis"
                    redis_client.set("basis_dumper_eod", 1)
            elif i==1:
                if os.system("basis_cumm_dumper_next.bat")==0:
                    print "Data successfully dumped for next month basis"
        else:
            print "Data is empty"
            
    for table in ['fno_basis','fno_basis_next']:
        query = session.execute("select * from {} where date='{}' allow filtering;".format(table, d))
        result = query._current_rows
        print "{} rows dumped in {} for {}".format(len(result), table, d)
        
        
if __name__=="__main__":
    main(0)
