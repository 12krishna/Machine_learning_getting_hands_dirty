# -*- coding: utf-8 -*-
"""
Created on Fri Jan 31 16:22:34 2020

@author: krishna
"""

import pandas as pd
import datetime 
#import matplotlib.pyplot as plt
import redis 
import os
import sys
import numpy as np
import warnings, sys
from collections import OrderedDict
warnings.filterwarnings("ignore")

input_dir = "D:\\Basis_Project\\Input\\"
master_dir = "D:\\Master\\"
redis_host = "10.223.104.86"
r = redis.Redis(host=redis_host, port=6379)

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date
# read holiday master
holiday_master = pd.read_csv(master_dir+ 'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)


d = datetime.date.today()
# check if working day or not 
if len(holiday_master[holiday_master['date']==d])==1:
    print ('Holiday: skip for current date :{} '.format(d))   
    sys.exit()     
    

print "Working day processing data for basis"

today_files = ''.join(['0'+str(d.day) if len(str(d.day))==1 else str(d.day),'0'+str(d.month) if len(str(d.month))==1 else str(d.month),
             str(d.year)])
        
today_files = list(sorted(r.keys('{}_*_m1'.format(d.strftime("%d%m%Y")))))
today_files_m1 = list(sorted( [ x for x in today_files if x.endswith('m1')] ))  # filter on current month m1
#today_files_m2 = list(sorted( [ x for x in today_files if x.endswith('m2')] ))  # filter on next month m2


# obtain raw files 
curr_df = pd.DataFrame()
if len(today_files_m1)!=0:
    for key in today_files_m1:
        curr_df = curr_df.append(pd.read_msgpack(r.get(key)))

# fill for missing time frames
curr_df.reset_index(inplace=True)
curr_df.sort_values(["Symbol",'time'], inplace=True)

timeframes=[]
t=datetime.datetime.now().replace(hour=9,minute=15,second=0,microsecond=0)
endtime=datetime.datetime.now().replace(hour=15,minute=25,second=0,microsecond=0)
while t<endtime:
    timeframes.append((t.time()))
    t=t+datetime.timedelta(seconds=300)
timeframes.append((t.time()))

timeframes = pd.DataFrame(timeframes, columns=['time'])
result = pd.DataFrame()

def agg_func(grp):
    '''agg func weighted avearge on LTP sum of volume diff'''    
    
    return pd.Series({'Volume_cash':np.sum(grp['Volume_cash']),'Volume_fut':np.sum(grp['Volume_fut']),
                      'LTP_cash': np.average(grp['LTP_cash'], weights=grp['Volume_cash']) if sum(grp['Volume_cash'])!=0 else 0,
                      'LTP_fut': np.average(grp['LTP_fut'], weights=grp['Volume_fut']) if sum(grp['Volume_fut'])!=0 else 0})
 
def impute_missing_timeframes(grp): 
    
    grp['time']=grp['date'].dt.time
    grp = timeframes.merge(grp, on='time', how='left')
    grp[['Symbol','date','LTP_cash','LTP_fut']] = grp[['Symbol','date','LTP_cash','LTP_fut']].ffill().bfill()
    grp[['Volume_cash','Volume_fut']] = grp[['Volume_cash','Volume_fut']].fillna(0)
    
    return grp
 

    
    
curr_df['date'] = curr_df['time'].apply(lambda row: datetime.datetime.combine(d, datetime.datetime.strptime(row,"%H:%M:%S").time()) ) 
curr_df = curr_df.groupby(['Symbol',pd.Grouper(key='date',freq='300s', 
                                                     sort=True)]).apply(lambda grp: agg_func(grp)).reset_index() 
# impute missing values
curr_df = curr_df.groupby(['Symbol'], as_index=False).apply(lambda grp: impute_missing_timeframes(grp))    
curr_df['date'] = curr_df['time'].apply(lambda row: datetime.datetime.combine(d, row) ) 

   
# read input dividend file from network
div = pd.read_excel(r"\\172.17.9.21\Agent\Ojas Shah\Basis report\Dividend\input_Dividend.xlsx")
div.rename(columns={'TimeFrame':'time'}, inplace=True)    
symbols = curr_df[['Symbol']].drop_duplicates()
div_df = pd.DataFrame()
for symbol in symbols['Symbol']:
    temp = timeframes.copy(deep=True)
    temp['Symbol'] = symbol
    div_df = div_df.append(temp, ignore_index=True)
div_df = div_df.merge(div, on=['Symbol','time'], how='left')
div_df.fillna(0, inplace=True)
    

curr_df = curr_df.merge(div_df, on=['Symbol','time'], how='left')
curr_df['basis_intra'] = curr_df[['LTP_cash','LTP_fut','Dividend']].apply(
        lambda row: (row['LTP_fut']-row['LTP_cash']+ row['Dividend'])*10000/row['LTP_cash'] if row['LTP_cash']!=0 else 0 ,axis=1)
    
curr_df['Spread_Vol'] = curr_df['Volume_fut']-curr_df['Volume_cash']


writer = pd.ExcelWriter(r"\\172.17.9.21\Agent\Ojas Shah\Basis report\basis_curr_month_{}.xlsx".format(d))
# format data for ouput
bloomcodes = pd.read_excel(master_dir+"MasterData.xlsx")
bloomcodes = bloomcodes[['BloomCode','SYMBOL']]
bloomcodes.rename(columns={'SYMBOL':'Symbol'}, inplace=True)
curr_df = curr_df.merge(bloomcodes, on='Symbol', how='left')

def pretty_data(df, columnname):
    result = OrderedDict()
    for symbol in list(sorted(df['Symbol'].unique())):
        temp = df[df['Symbol']==symbol]
        temp.sort_values(by='date', inplace=True)
        #temp.set_index('date', inplace=True)
        result[temp['BloomCode'].values[0]]=temp[['date',columnname]].set_index('date').rename(columns={columnname:symbol}) 
        
    #reform = {(outerKey, innerKey): values for outerKey, innerDict in result.iteritems() for innerKey, values in innerDict.iteritems()}
    df = pd.concat(result.values(), axis=1, keys=result.keys())
    df = df.round(2)
    return df


basis_intra = pretty_data(curr_df[['Symbol','BloomCode','date','basis_intra']], 'basis_intra')

#reform.to_excel("C:\Users\krishna\Desktop\debug1.xlsx")
spread_vol = pretty_data(curr_df[['Symbol','BloomCode','date','Spread_Vol']], 'Spread_Vol')

fut_vol = pretty_data(curr_df[['Symbol','BloomCode','date','Volume_fut']], 'Volume_fut')

basis_EOD = curr_df[['Symbol','BloomCode','date','basis_intra']].groupby(['Symbol','BloomCode'],
                   as_index=False)['basis_intra'].mean()
basis_EOD['date'] = d
basis_EOD = pretty_data(basis_EOD, 'basis_intra')

# write output
basis_intra.to_excel(writer, sheet_name='Basis_Intra')
spread_vol.to_excel(writer, sheet_name='Spread_Vol')
fut_vol.to_excel(writer, sheet_name='Fut_Vol')
basis_EOD.to_excel(writer, sheet_name='Basis_EOD')

writer.save()
writer.close()


