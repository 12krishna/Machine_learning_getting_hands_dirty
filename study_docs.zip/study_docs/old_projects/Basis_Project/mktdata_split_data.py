# -*- coding: utf-8 -*-
"""
Created on Mon May 31 11:17:18 2021

@author: krishna
"""

import pandas as pd
import datetime

def redis_key_generator():
    '''Generate all the keys needed for computation over a period of day '''
    
    # read master file for cash and fut codes 
    #symbols = pd.read_excel(master_dir+'PairMaster.xlsx')['Symbol']
    # redis server connection
    #r = redis.Redis(host='localhost', port=6379)
    #keys = []
    timekeys = []
    a = datetime.datetime(1,1,1,9,5)
    
    for i in range(77):
        a = a + datetime.timedelta(minutes=5)
        timekeys.append("{}{}".format(('0'+str(a.hour) if len(str(a.hour))==1 else str(a.hour)),
                                      ( '0'+str(a.minute) if len(str(a.minute))==1 else str(a.minute))))

    '''
    for symbol in symbols:
        for time in timekeys:
            keys.append(symbol+'.'+time)
            
    for key in keys:
        r.set(key, '') '''
        
    return timekeys


def gen_filename(timekeys):
    '''Generate filenames'''
    
    d = datetime.date.today()-datetime.timedelta(days=0)
    filename = []
    for timek in timekeys:
        filename.append( 'debug_log_mktdata_{}{}{}_{}.txt'.format(('0'+str(d.day) if len(str(d.day))==1 else str(d.day)),
                                                ('0'+str(d.month) if len(str(d.month))==1 else str(d.month)),
                                                str(d.year), timek ))
        
    return filename


filenames = gen_filename(redis_key_generator())
filenames = pd.DataFrame(filenames)
filenames[1] = filenames[0].shift(-1)
filenames.dropna(inplace=True)


df = pd.read_csv("D:\\Delivery_data_realtime\\input\\debug_log_mktdata_31052021.txt",
                 delimiter=',', engine='c',skipinitialspace=True, low_memory=False, header=None)
df['date'] = df[0].apply(lambda row: row.split("+")[0])
df['date'] = pd.to_datetime(df['date'], format='%Y-%m-%d %H:%M:%S.%f')        
df['time'] = df['date'].dt.time   
    

for _, row in filenames.iterrows():
    
    
    start = datetime.time(int(row[0].split('_')[-1].split('.')[0][:2]),int(row[0].split('_')[-1].split('.')[0][2:]) )
    end = datetime.time(int(row[1].split('_')[-1].split('.')[0][:2]),int(row[1].split('_')[-1].split('.')[0][2:]) )
    
    
    temp = df[ (df['time']>= start ) & (df['time']< end)]     
    temp.drop(columns=['date','time'], inplace=True)
    print len(temp)
    temp.to_csv("D:\\Delivery_data_realtime\\input\\output\\{}".format(row[1]), index=False, header=False)
    