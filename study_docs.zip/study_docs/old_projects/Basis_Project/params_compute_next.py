import numpy as np 
import pandas as pd
import logging 
#from dateutil import parser
import time
import datetime
import redis
import os 
import decimal 
import warnings
warnings.filterwarnings("ignore")


master_dir = "D:\\Master\\"
log_path = "D:\\Basis_Project\\"
redis_host = '10.223.104.86'
params_log = "D:\\Basis_Project\\Params_log\\Next_month\\"

#redis_host = "localhost"
logging.basicConfig(filename=log_path+"params_next.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")



def compute_func(r, time_f,symbols, today_files, file_indicator, input_formula):
    # func to performe computation on dividend fa ra 
    
    i = [ i.replace(':','')  for i in time_f.split('_')]

    index = 0 
    try:
        index = [idx  for idx in range(len(today_files))  if today_files[idx].endswith(i[0]+'_m2') or today_files[idx].endswith(i[1]+'_m2') ]
        
    except Exception as e:
        print 'No raw ticker files dumped in backend for this time frame {}! : Error-{}'.format(time_f, e)
        return -1
    filenames = 0
    if len(index)==0:
        print 'No ticker files dumped in backend !'
        return -1
    
    if len(index) == 1:
        filenames = today_files[index[0]: ]   # fetch all the files avaliable till now; from start index time frame 
        
    else:
        filenames = today_files[index[0]: index[1]+1] # fetch files between time frame index
        print filenames
                
    df = pd.DataFrame()
    # pop first file if indicator is set during looping 
    if file_indicator==1:
        try:
            filenames.pop(0)
        except:
            pass
                
    
    print filenames
    for filename in filenames:
        # merge available files
        df_1 = pd.read_msgpack(r.get(filename))
        df = pd.concat([df, df_1], axis=0)
                
    # apply parametric operations on merged df 
    result = []
    if len(df)==0:
        # if no trading is done for 9:15 micro secs skip the process 
        return -1
    starttime = time.time()
    final_df = pd.DataFrame()
    
  
    # get input dividend, fa and ra levels for calc of short and long futs
    input_df = []
    for symbol in sorted(symbols):
        d = r.get('{}_{}_dividend_m2'.format(symbol,time_f))
        d = 0 if d == None or d=='' or d==' ' else float(d) # convert div to float else set div to zero        
        f = r.get('{}_{}_fa_m2'.format(symbol,time_f)) 
        f = 50 if f == None or f=='' or f==' ' else float(f) # convert fa to float else set fa to default  
        ra = r.get('{}_{}_ra_m2'.format(symbol,time_f)) 
        ra = 10 if ra == None or ra=='' or ra==' ' else float(ra) # convert ra to float else set div to default   
        
        input_df.append([symbol,d,f,ra])
    input_df = pd.DataFrame(input_df, columns=['Symbol','input_div','input_fa','input_ra'])
    
    # merge input levels on processing dataframe
    df = df.merge(input_df, on='Symbol',how='left')
    
    # spread bps calc on dividend 
    #df['spread_bps'] = df.apply(lambda row: (row['spread_ab'] - row['input_div'] )*10000/(row['LTP_cash']+float(row['input_div'])) if row['LTP_cash']!=0 else 0, axis=1)
    df.loc[df['LTP_cash']!=0,'spread_bps'] = (df['spread_ab'] + df['input_div'] )*10000/(df['LTP_cash'])
    df.loc[df['LTP_cash']==0,'spread_bps'] = 0
    # price change
    df['price_chg'] = df.groupby(['Symbol'])['LTP_fut'].transform(lambda x: x/x.shift(1)*100 - 100 )
    
    df['price_chg'].fillna(0.0, inplace=True)
    df['price_chg'].replace([np.Inf, -np.Inf], 0.0, inplace=True)
    # trunacte 2 decimal places
    df['price_chg'] = df['price_chg'].apply(lambda row: decimal.Decimal(row).quantize(decimal.Decimal('.01'),
                                                                                                  rounding=decimal.ROUND_DOWN) )
    
    df['price_chg'] = df['price_chg'].astype(float)
    # FA RA levels 
    #df['FA'] = df.apply(lambda row: row['spread_bps'] if row['spread_bps'] > float(fa) else 0, axis=1)
    #df.loc[ df['spread_bps'] > df['input_fa'], 'FA' ] = df['spread_bps']  # FA levels
    #df.loc[ df['spread_bps'] < df['input_ra'], 'RA' ] = df['spread_bps']  # FA levels
    #df.fillna(0, inplace=True)
    
      
    # FA/RA notation
    df['FA/RA'] = np.where(df['spread_bps'] > df['input_fa'],'FA',
                           np.where(df['spread_bps'] < df['input_ra'],'RA',''))
    # bid ask impact; consider only above .1 price change 
    df['bid_ask_spread_impact'] = np.where( df['price_chg'] > 0.10, 1 , 0)
    
    # px calc
    # mark px positive if %price_chg is +ve else -ve for all impact 1 rows ; else " " for impact 0 rows
    
    df['px'] = np.where( (df['bid_ask_spread_impact'] == 1) & (df['price_chg'] > 0), 'UP',
                       np.where( (df['bid_ask_spread_impact'] == 1) & (df['price_chg'] < 0), 'DN', ''))
    
    # basis calc 
    df['tbasis'] = df.groupby(['Symbol'])['spread_bps'].transform(lambda x: x.shift(1) )
    df['basis'] = np.where( (df['bid_ask_spread_impact'] == 1) & (df['spread_bps'] < df['tbasis'] ), 'DN',
                       np.where( (df['bid_ask_spread_impact'] == 1) & (df['spread_bps'] > df['tbasis'] ), 'UP', ''))
    
    df[['basis','px']] = df[['basis','px']].fillna('')  # handle no up dn situations
    
    
    # final indicator
    df['Final'] = df.apply(lambda row: 'NO' if row['bid_ask_spread_impact']==0 else ('{}{}{}'.format(row['FA/RA'],row['px'],row['basis']) if row['bid_ask_spread_impact']==1 else 'NO' ), axis=1)
                            
    df['Final'] = df['Final'].str.strip()
    
    
    df = df.merge(input_formula, on='Final', how='left')  # merge on input formula to get impacted volume levels
    df.rename(columns={'POS_OI Bias':'Volume Impact'}, inplace=True)
    df['Volume Impact'].fillna(0, inplace=True)
    
    # short futs and long futs calc
    df['Short Futs'] = np.where( df['Volume Impact'] < 0, df['Volume Impact']*df['Volume_fut'], 0 )
    df['Short Futs'] = df['Short Futs'].abs()
    df['Long Futs'] = np.where( df['Volume Impact'] > 0, df['Volume Impact']*df['Volume_fut'], 0 )
    df['Long Futs'] = df['Long Futs'].abs()
    df.set_index('Symbol', inplace=True)
    
    final_df = df.copy(deep=True)  # make a copy for backend storage bpsresult redis file 
    final_df.drop(columns=['input_div','input_fa','input_ra','tbasis'], inplace=True)
    final_df= final_df[final_df['LTP_cash']!=0]
    
    # front end FA,RA,long short calc 
    result = []
    for gname, gelements in df.groupby('Symbol'):
        
        gelements = gelements[gelements['LTP_cash']!=0]
        
        if len(gelements)!=0:            
            # front end sum of FA,RA,long short futs calc 
            div = gelements['input_div'].values[0] # input dividend for that symbol
            fa = gelements['input_fa'].values[0]
            ra = gelements['input_ra'].values[0]
            sum_fa = gelements[gelements['spread_bps'] > fa]['cfvolume'].sum() # filter on fa
            sum_ra = gelements[gelements['spread_bps'] < ra]['cfvolume'].sum() # filter on ra    
            sum_short_futs = gelements['Short Futs'].sum() 
            sum_long_futs = gelements['Long Futs'].sum() 
            min_spread = gelements['spread_bps'].min()
            max_spread = gelements['spread_bps'].max()
            spread_bps_avg = gelements['spread_bps'].mean()
            quantile_5, quantile_95 = gelements['spread_bps'].quantile([0.05,0.95])
            fa_average  = gelements[gelements['spread_bps'] > fa]
            fa_average = np.sum(fa_average['spread_bps']*fa_average['cfvolume'])/np.sum(fa_average['cfvolume'])  # weighted average
            
            ra_average = gelements[gelements['spread_bps'] < ra]
            ra_average = np.sum(ra_average['spread_bps']*ra_average['cfvolume'])/np.sum(ra_average['cfvolume'])  # weighted average
            
            short_futs_avg = np.sum(gelements['Short Futs']*gelements['spread_bps'])/np.sum(gelements['Short Futs']) 
            long_futs_avg = np.sum(gelements['Long Futs']*gelements['spread_bps'])/np.sum(gelements['Long Futs']) 
            
            result.append([gname,div , sum_fa, sum_ra ,round(sum_short_futs,2), round(sum_long_futs,2), round(min_spread),
                           round(max_spread), round(spread_bps_avg),round(quantile_5), round(quantile_95), round(fa_average), round(ra_average),
                           round(short_futs_avg), round(long_futs_avg)])
    
    result = pd.DataFrame(result, columns=['Symbol','dividend','FA','RA','Short Futs','Long Futs','Min','Max','Spread_bps avg','5%','95%',
                                           'fa avg','ra avg','Shortfuts avg','Longfuts avg'])
     
    
    
    
    print time.time()- starttime
    
    #result['timeframe'] = time_f
    #publish to redis 
    r.set('result_{}_{}_m2'.format(today_files[0].split('_')[0],time_f), result.to_msgpack(compress='zlib'))
    
    r.set('bpsresult_{}_{}_m2'.format(today_files[0].split('_')[0],time_f), final_df.to_msgpack(compress='zlib'))        
    
            
    
def parameters_compute(r, param_flag,input_formula, symbols):
    '''Func to fetch params from redis and process dumped files on redis to cal bps div, fa , ra'''   

    st = time.time()
    
    # get all redis keys for all the set params
    dividends = list(sorted(r.keys('*_dividend_m2')))
    fa = list(sorted(r.keys('*_fa_m2')))
    ra = list(sorted(r.keys('*_ra_m2')))
    if len(fa)==0 or len(ra)==0:
        print 'No parameters set in excel file !'
        return -1
        
    #df = pd.DataFrame({'Dividend':dividends, 'FA':fa, 'RA':ra })
    
    df = ''
    try:
        print "Div FA RA"
        df = pd.DataFrame({'Dividend':dividends, 'FA':fa, 'RA':ra })
    except:
        logging.info("Div FA RA length issue excpetion, re call parameters_compute")
        print "Div FA RA length issue excpetion, re call parameters_compute"
        parameters_compute(r, param_flag,input_formula, symbols)
    
    
    
    
    # get all symbols from pairmaster file
    #symbols = set(df.apply(lambda row: row['FA'].split('_')[0] , axis=1))  symbols set so far
    #symbols = list(sorted(pd.read_csv(master_dir+'PairMaster.csv')['Symbol'].values))
    # get all the time frames
    timeframes = sorted(set(df.apply(lambda row: '_'.join(row['FA'].split('_')[1:3]) , axis=1)))
    
    d = datetime.date.today()
    today_files = ''.join(['0'+str(d.day) if len(str(d.day))==1 else str(d.day),'0'+str(d.month) if len(str(d.month))==1 else str(d.month),
             str(d.year)])
    today_files = sorted(r.keys('{}*'.format(today_files)))
    today_files = sorted( [ x for x in today_files if x.endswith('m2')] )
    
    #today_files = [ x for x in today_files if not x.startswith('bpsresult') and not x.startswith('result') ] # take raw dumped files 
      
    
    if len(today_files)==0:
        print 'No raw ticker files are yet dumped in redis!'
        return -1
    
    # apply dividend, fa ,ra on files 
    file_indicator = 0 # for ignoring first file after first loop 
    
    if param_flag == 1:
        
        params_dumper = []
        for index, row in df.iterrows():
            params_dumper.append([row['FA'].split('_')[0], '_'.join(row['FA'].split('_')[1:3]) ,r.get(row['Dividend']), r.get(row['FA']), r.get(row['RA'])])
        params_dumper = pd.DataFrame(params_dumper, columns=['Symbol','time','Dividend','FA','RA'])
                      
        params_dumper.to_csv(params_log + "params_{}".format( datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S.csv') ) , index=False )
        print 'Log: Saving parameters in csv file '
        logging.info('Log: Saving parameters in csv file ')
        del params_dumper
        
        
        
        # do computation on all set parameters for all time frames        
        for time_f in timeframes:
            compute_func(r, time_f,symbols, today_files, file_indicator, input_formula) 
            file_indicator = 1 # skip firs filename now on ...
            
        
    elif param_flag == 0:
        # perform compuation only on last timeframe
        df = pd.read_csv(master_dir+'timeframes.csv')        
        timeframes = df[df['filename'] == int(today_files[-1].split('_')[1]) ]['timeframe'].values[0]
        
        if timeframes == '09:15_10:00':
            file_indicator = 0
        else:
            file_indicator = 1
        
        compute_func(r, timeframes,symbols, today_files, file_indicator, input_formula)
        
    print 'Paramater computation time: {}'.format( time.time() - st )
        
    
    
def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

   
def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
    
    # read holiday master
    holiday_master = pd.read_csv(master_dir+ 'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)    
    
    
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        logging.info('Start process ')          
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))
        
        return -1


    
def main():
    
    d = datetime.datetime.now().date()
    if process_run_check(d) == -1:
        return -1
    
    
    r = redis.Redis(host=redis_host, port=6379) 
    # long short volume calc 
    input_formula = pd.read_csv(master_dir+'Input_formula.csv')[['Final','POS_OI Bias']] # input formula to calc volume
    # process for all symbols
    symbols = list(sorted(pd.read_csv(master_dir+'PairMaster.csv')['Symbol'].values))
    while True:   
        
        try:
            
            param_flag = r.get('param_flag_m2')  # if parameters are set in excel this flag is activated 
            if param_flag == None:
                print 'No parameters set in excel ; sleep for 5 sec'
                time.sleep(5)
            
            else:
                param_flag = int(param_flag)            
                
                if param_flag == 1:
                    # params computation
                    print "Computing params for all timeframes; due to change in parameters..."
                    r.set('processing_flag_m2',1)
                    parameters_compute(r, param_flag, input_formula, symbols)
                    r.set('processing_flag_m2',0)
                    r.set('param_flag_m2', 0)
                else:
                    # does computation for only last time frame; while files are added in real time 
                    print 'No paramters change; doing compuation only on last timeframe'
                    r.set('processing_flag_m2',1)
                    parameters_compute(r, param_flag, input_formula, symbols)
                    r.set('processing_flag_m2',0)
                    print 'Sleep for 5 sec'
                    time.sleep(5)
                
            if datetime.datetime.now().time() >= datetime.time(20,30):
                print 'Process ended for current day'
                break
        except:
            print "Exception......................"    
        
    
    
if __name__ == '__main__':
    main()
    