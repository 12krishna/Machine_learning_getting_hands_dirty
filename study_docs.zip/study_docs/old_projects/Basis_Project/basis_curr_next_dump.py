# -*- coding: utf-8 -*-
"""
Created on Wed Jan  4 10:51:09 2023

@author: backup
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Jun 24 15:04:47 2022

@author: backup
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Oct 18 15:40:52 2021

@author: krishna
"""

import pandas as pd
import numpy as np
import datetime,os,time, shutil

data_dir = "D:\\Basis_Project\\"


basis_dict={"basis_spread_bps_2022-12-29_curr_month.csv":['basis_dump.csv','basis_dump.bat'],"basis_spread_bps_2022-12-29_next_month.csv":['basis_dump_next.csv','basis_dump_next.bat']}

for i in basis_dict:
    
    basis_dump=pd.DataFrame(columns=['symbol', 'date', 'closing_basis', 'fa_avg', 'longfuts_avg', 'max',
           'min', 'opening_basis', 'percentile_5', 'percentile_95', 'px_chg',
           'ra_avg', 'shortfuts_avg', 'spread_bps_avg'])
    
       
    basis1=pd.read_csv(os.path.join(data_dir,"{}".format(i)))
    basis1.columns
    basis1.rename(columns={'Symbol':'symbol','Spread bps avg':'spread_bps_avg', '5%':'percentile_5', '95%':'percentile_95',
                           'Opening_basis':'opening_basis', 'Closing_basis':'closing_basis','Min':'min','Max':'max'},inplace=True)
    for c in basis1.columns:
        basis_dump[c]=basis1[c]
        
    #basis_dump['date']=basis_dump['date'].apply(lambda x:datetime.datetime.strptime(x,"%m/%d/%Y").date())
    basis_dump.to_csv(os.path.join(data_dir,"{}".format(basis_dict[i][0])),index=False)    
    os.system(os.path.join(data_dir,"{}".format(basis_dict[i][1])))
    print(f"data dumped for {i}")














