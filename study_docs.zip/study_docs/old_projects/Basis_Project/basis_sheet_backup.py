# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 15:13:37 2020

@author: krishna
"""

import pandas as pd
import datetime 
import xlwings as xw
#import matplotlib.pyplot as plt
import redis 
import win32api
import os, shutil
import sys
import numpy as np
import warnings, sys
warnings.filterwarnings("ignore")


#excel_front_end_path = "Realtimebasis.xlsm"

#redis_host = "localhost"
redis_host = "10.223.104.86"

email_dir="D:\\Emails\\Output\\"
#output_dir = "D:\\Basis_Project\\Output\\"



def get_timer(length):
    '''Func to get start and end times for processing '''
    
    time_buckets = [datetime.time(9,15),datetime.time(10,0),datetime.time(10,30),datetime.time(11,0),datetime.time(11,30),
                 datetime.time(12,0),datetime.time(12,30),datetime.time(13,0),datetime.time(13,30),datetime.time(14,0),
                 datetime.time(14,30),datetime.time(15,0),datetime.time(15,30)]
    
    time_range = [i for i in range(3,42,3)]
    
    if length in time_range:
        index =  time_range.index(length)
        return time_buckets[index],time_buckets[index+1]


def result(expiry, r, wb):
    '''Fetch results for set params'''
     
        
    result = pd.DataFrame()
        
    # read result files from redis 
    #r = redis.Redis(host=redis_host, port=6379) 
    result_files = sorted(r.keys('result_*'))
       
    result_files = list(sorted([ x for x in result_files if x.startswith('result')])) # filter only result files 
    result_files = list(sorted( [ x for x in result_files if x.endswith(expiry)] ))  # filter on current month m1
    
        
    for res in result_files:
        # read the published msgpack
        df = pd.read_msgpack(r.get('{}'.format(res)))
        df = df[['Symbol','dividend','FA','RA','Short Futs','Long Futs', 'Min','Max','Spread_bps avg','5%','95%',
                'fa avg','ra avg','Shortfuts avg','Longfuts avg']]
        if result.empty==True:
            result=df.copy(deep=True)
        else:
            result = result.merge(df, on='Symbol', how='left')
                 
            
    result.set_index('Symbol', inplace=True)
        
    cols = result.columns.values
    cols = { x: 'Dividend' if x.startswith('dividend') else 'FA' if x.startswith('FA') else 'RA' if x.startswith('RA') else 'Short Futs' if x.startswith('Short Futs') else 'Long Futs' if x.startswith('Long Futs') else 'Min' if x.startswith('Min') else 'Max' if x.startswith('Max') else 'Spread bps avg' if x.startswith('Spread_bps avg') else '5%' if x.startswith('5%') else '95%' if x.startswith('95%') else 'FA avg' if x.startswith('fa avg') else 'RA avg' if x.startswith('ra avg') else 'Shortfuts avg' if x.startswith('Shortfuts avg') else 'Longfuts avg' if x.startswith('Longfuts avg') else None  for x in cols }
    result.rename(columns = cols, inplace=True)
    # write data
    #Sheet2.range('A2:M5000') = ''
    if expiry=='m1':
        wb.sheets[0].range('A4').value = result
    else:
        wb.sheets[1].range('A4').value = result
    #Sheet2.range('A1') = result2
    
    wb.save()
    
    
    
def main():
    
    # read result files from redis 
    r = redis.Redis(host=redis_host, port=6379) 
    wb = xw.Book("Basis_realtime_sheet_result.xlsx")
    wb.sheets[0].range('A5:FT210').value = ''
    wb.sheets[1].range('A5:FT210').value = ''
    wb.save()
    # check which month is active
    if r.get('param_flag_m1')!=None and r.get('param_flag_m1')=='1' :
        print "Current month set"
        result('m1', r, wb)
    if r.get('param_flag_m2')!=None and r.get('param_flag_m2')=='1':
        print "Next month set"
        result('m2',r, wb)
        
    wb.save()
    wb.close()
    shutil.copy("D:\\Basis_Project\\Basis_realtime_sheet_result.xlsx", email_dir+"Basis_realtime_sheet_result.xlsx")
    
#if __name__=='__main__':
#    main()