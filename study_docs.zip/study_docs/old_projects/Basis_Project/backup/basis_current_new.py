import numpy as np 
import pandas as pd
import logging 
#from dateutil import parser
import time
from datetime import date, timedelta
import datetime
#import matplotlib.pyplot as plt 
import logging
import redis
import zlib
import os
import email_utility 
import shutil



#redis_host = '10.223.104.61'
redis_host = "localhost"
'''
download_dir = "/tmp/"
master_dir = "/opt/Basis_project/Master/"
log_path = "/opt/Basis_project/"
fo_path = "/opt/kits_project_xl/dataFiles/"
'''

download_dir = "D:\\Basis_Project\\input\\"
master_dir = "D:\\Master\\"
log_path = "D:\\Basis_Project\\"
fo_path = log_path



global_avg_df = pd.DataFrame()

logging.basicConfig(filename=log_path+"basis_current.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def redis_key_generator():
    '''Generate all the keys needed for computation over a period of day '''
    
    # read master file for cash and fut codes 
    #symbols = pd.read_excel(master_dir+'PairMaster.xlsx')['Symbol']
    # redis server connection
    #r = redis.Redis(host='localhost', port=6379)
    #keys = []
    timekeys = []
    a = datetime.datetime(1,1,1,9,5)
    
    for i in range(77):
        a = a + datetime.timedelta(minutes=5)
        timekeys.append("{}{}".format(('0'+str(a.hour) if len(str(a.hour))==1 else str(a.hour)),
                                      ( '0'+str(a.minute) if len(str(a.minute))==1 else str(a.minute))))

    '''
    for symbol in symbols:
        for time in timekeys:
            keys.append(symbol+'.'+time)
            
    for key in keys:
        r.set(key, '') '''
        
    return timekeys


def gen_filename(timekeys):
    '''Generate filenames'''
    
    d = datetime.date.today()-datetime.timedelta(days=3)
    filename = []
    for timek in timekeys:
        filename.append( 'debug_log_mktdata_{}{}{}_{}.txt'.format(('0'+str(d.day) if len(str(d.day))==1 else str(d.day)),
                                                ('0'+str(d.month) if len(str(d.month))==1 else str(d.month)),
                                                str(d.year), timek ))
        
    return filename


def dateparse(row):
    '''Func to parse dates while reading ticker files'''
    d = row.split("+")[0]
    d = pd.to_datetime(d, format='%Y-%m-%d %H:%M:%S')
    return d
    



def price_oi_change(prices, expiry_dates_master, r, endtime):
    '''Function to calc price change and OI'''
    
    # calc price chg and OI chg
    logging.info("Generate price and Oi changes")
    price_df = prices[(prices['ExchangeSegment']=='NFO') & (prices['SecurityCode']==prices['FutCode_m1'])][['Symbol','time','ClosePrice']] 
    price_df = price_df.sort_values(by='time').groupby(['Symbol'] , sort=True).last().reset_index(); oi_df1=pd.DataFrame(); oi_df2=pd.DataFrame()
  
    result = pd.DataFrame()
            
        
    if datetime.datetime.now().date() not in expiry_dates_master.values:
        # not an expiry day 
        logging.info("Not an expiry day; hence working on m1 and m2 months")
        oi_df1 = prices[(prices['ExchangeSegment']=='NFO') &
                        (prices['SecurityCode']==prices['FutCode_m1']) ][['Symbol','time','OI']] 
        oi_df1 = oi_df1.sort_values(by='time').groupby(['Symbol'] , sort=True).last().reset_index()
        oi_df1.rename(columns={'OI':'Current_month'}, inplace=True)
        oi_df1.drop(columns=['time'], inplace=True)
        
        oi_df1_1 = prices[(prices['ExchangeSegment']=='NFO') &
                        (prices['SecurityCode']==prices['FutCode_m2']) ][['Symbol','time','OI']]        
        oi_df1_1 = oi_df1_1.sort_values(by='time').groupby(['Symbol'] , sort=True).last().reset_index()
        oi_df1_1.rename(columns={'OI':'next_month'}, inplace=True)
        oi_df1_1.drop(columns=['time'], inplace=True)
        
        #oi_df1 = pd.concat([oi_df1, oi_df1_1], axis=1)
        oi_df1 = oi_df1.merge(oi_df1_1, on='Symbol', how='left')
        oi_df1.fillna(0, inplace=True)
        #oi_df1.to_csv('te.csv')
        oi_df1['OI'] = oi_df1['Current_month']+ oi_df1['next_month']     
        
        
        result = price_df.merge(oi_df1, on='Symbol', how='left') 
        #result.to_csv('oi1.csv')
    else:
        # expiry day 
        logging.info("Not an expiry day; hence working on m2 and m3 months")
        oi_df2 = prices[(prices['ExchangeSegment']=='NFO') & (prices['SecurityCode']==prices['FutCode_m2']) ][['Symbol','time','OI']]        
        oi_df2 = oi_df2.sort_values(by='time').groupby(['Symbol'] , sort=True).last().reset_index()       
        oi_df2.drop(columns=['time'], inplace=True)
        
        oi_df2_1 = prices[(prices['ExchangeSegment']=='NFO') & (prices['SecurityCode']==prices['FutCode_m3']) ][['Symbol','time','OI']]        
        oi_df2_1 = oi_df2_1.sort_values(by='time').groupby(['Symbol'] , sort=True).last().reset_index()       
        oi_df2_1.drop(columns=['time'], inplace=True)
        
        oi_df2 = pd.concat([oi_df2, oi_df2_1], axis=0)
        #oi_df2.to_csv('te1.csv')
        
        
        oi_df2 = oi_df2.groupby(['Symbol'], sort=True).agg({'OI':'sum'}).reset_index()
        #oi_df2.to_csv('oi2.csv')
        result = price_df.merge(oi_df2, on='Symbol', how='left') 

    result['time'] = result['time'].apply(lambda row: str(row.replace(second=0,microsecond=0)))
    #result.to_csv('debug.csv')  
    # publish to redis 
    
    r.set('price_oi_chg_{}'.format(str(endtime)), result.to_msgpack(compress='zlib'))
    logging.info("Successfully dumped price oi change to redis for {}".format(endtime))
     
        
        
    

def agg_func(grp):
    '''agg func weighted avearge on LTP sum of volume diff'''    
    
    return pd.Series({'VolumeTraded':np.max(grp['VolumeTraded']),'Volume':np.sum(grp['Volume']),
                      'LTP': np.average(grp['LTP'], weights=grp['Volume']) if sum(grp['Volume'])!=0 else 0 })
   
    
  



def aggregate_func(prices, starttime, endtime, pairmaster, expiry_dates_master,r):
    '''Func to return max of volume traded and mean of LTP for 5 sec ticker data'''   
    
    agg_main = time.time()
    
    # return empty df if empty 
    if len(prices)==0:
        d =  pd.DataFrame(columns=['Symbol','time','VolumeTraded_cash','LTP_cash','VolumeTraded_fut','LTP_fut',
                      'Volume_cash','Volume_fut','cfvolume','spread_ab','spread_bps'])
        d.set_index('Symbol', inplace=True)
        return d
    
    
    try:        
        # time range refrence ; for filling empty timeframes while aggr ip data
        time_keys = pd.DataFrame(pd.timedelta_range(start=str(starttime), end=str(endtime), freq = '5s')[:-1], columns=['time'])
        time_keys['time'] = time_keys.apply(lambda row: str(row['time']).split(' ')[-1], axis=1)
        
    except:
        print 'time issue'
        logging.info('time issue')

    
    result = pd.DataFrame()  # processing result after aggregation over 5s data 
    #global_df = pd.DataFrame()
    for index in [['NFO','FutCode_m1' ],[['NSE','NSECashCode'], ['BSE','BSECashCode']]]:
        print 'Aggregating over exchange {}, with secuirty code on {}'.format(index[0], index[1])
        logging.info('Aggregating over exchange {}, with secuirty code on {}'.format(index[0], index[1]))
        opti = prices.merge(pairmaster, on='Symbol',how='left')
        if index[0]=='NFO':
            price_oi_change(opti, expiry_dates_master, r, endtime)
            opti = opti[(opti['ExchangeSegment']==index[0]) & (opti['SecurityCode']==opti[index[1]])]   
            if starttime==datetime.time(9,15):
                # first instance no merging needed
                # maintain last insatnce of every symbol 
                global global_avg_df
                global_avg_df = global_avg_df.append(opti.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                
            else:
                # merge previous instance volume and price 
                global global_avg_df
                temp = global_avg_df[global_avg_df['ExchangeSegment']==index[0]]
                # main tail to global 
                global_avg_df = global_avg_df.append(opti.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                #update global with single instance
                global_avg_df = global_avg_df.groupby(['Symbol','ExchangeSegment'], sort=True).last().reset_index()
                
                
                opti = pd.concat([opti, temp], axis=0, ignore_index=True)  
                                
            
            opti['Volume'] = opti.groupby('Symbol', sort=True)['VolumeTraded'].diff().fillna(0)   # get volume from volume traded till now   
            opti = opti[ (opti['time']>= starttime ) & (opti['time']< endtime)]   # filter on time 
            
            opti = opti.groupby(['Symbol',pd.Grouper(key='date',freq='5s', 
                                                     sort=True)]).apply(lambda grp: agg_func(grp)).reset_index() 
    
        else:
            # combaining on NSE and BSE
            #NSE
            temp1 = opti[(opti['ExchangeSegment']==index[0][0]) & (opti['SecurityCode']==opti[index[0][1]])]  #NSE
            if starttime==datetime.time(9,15):
                # first instance no merging needed
                global global_avg_df
                global_avg_df = global_avg_df.append(temp1.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                
            else:
                # merge previous instance volume and price 
                global global_avg_df
                temp = global_avg_df[global_avg_df['ExchangeSegment']==index[0][0]]
                  
                # main tail to global 
                global_avg_df = global_avg_df.append(temp1.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                #update global with single instance
                global_avg_df = global_avg_df.groupby(['Symbol','ExchangeSegment'], sort=True).last().reset_index()
                
                temp1 = pd.concat([temp1, temp], axis=0, ignore_index=True)     
                
                
            
            temp1['Volume'] = temp1.groupby('Symbol', sort=True)['VolumeTraded'].diff().fillna(0)   # get volume from volume traded till now   
            temp1 = temp1[ (temp1['time']>= starttime ) & (temp1['time']< endtime)]   # filter on time 
            
            temp1 = temp1.groupby(['Symbol',pd.Grouper(key='date',freq='5s', 
                                                       sort=True)]).apply(lambda grp: agg_func(grp)).reset_index() 
    
            #BSE
            temp2 = opti[(opti['ExchangeSegment']==index[1][0]) & (opti['SecurityCode']==opti[index[1][1]])]
            if starttime==datetime.time(9,15):
                # first instance no merging needed
                global global_avg_df
                global_avg_df = global_avg_df.append(temp2.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                
            else:
                # merge previous instance volume and price 
                global global_avg_df
                temp = global_avg_df[global_avg_df['ExchangeSegment']==index[1][0]]
                           
                # main tail to global 
                global_avg_df = global_avg_df.append(temp2.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                #update global with single instance
                global_avg_df = global_avg_df.groupby(['Symbol','ExchangeSegment'], sort=True).last().reset_index()
                
                temp2 = pd.concat([temp2, temp], axis=0, ignore_index=True)            
                
                
            
            temp2['Volume'] = temp2.groupby('Symbol', sort=True)['VolumeTraded'].diff().fillna(0)   # get volume from volume traded till now   
            temp2 = temp2[ (temp2['time']>= starttime ) & (temp2['time']< endtime)]   # filter on time 
            
            temp2 = temp2.groupby(['Symbol',pd.Grouper(key='date',freq='5s', 
                                                       sort=True)]).apply(lambda grp: agg_func(grp)).reset_index() 
            
            
            
            # combine NSE and BSE with weighted average 
            opti = pd.concat([temp1,temp2],axis=0, ignore_index=True)  
            if len(opti)!=0:
                opti = opti.groupby(['Symbol','date'], sort=True).apply(lambda grp: agg_func(grp)).reset_index() 
            
                    
        # handle special case of market lower circuit/ upper circuit i.e. trading halt
        
        if len(opti)==0:
                print "NO data is present for any of the symbols during this timeframe, alert ! "
                logging.info("NO data is present for any of the symbols during this timeframe, alert ! ")
        else:               
            opti['time'] = opti['date'].dt.time.astype(str)
            opti.sort_values(by=['Symbol','time'], inplace=True) # sort for fill 
            # handling missing time frames 
            temp = pd.DataFrame()
            for gname, gelements in opti.groupby(['Symbol']):
                t = time_keys.merge(gelements, on='time',how='left')
                t.fillna(method='ffill', inplace=True)
                if t.isnull().values.any()==True:
                    t.fillna(method='bfill', inplace=True)
                temp = temp.append(t)
                
            opti = temp.copy(deep=True)
            
            #opti.groupby(['Symbol']).transform(lambda x: x.sort_values(by ='time').fillna(method='ffill') )
            #opti.fillna(method='ffill', inplace=True)  # forward fill missing values 
            opti.drop(columns=['date'], inplace=True)
            if index[0]=='NFO':
                opti['Exchange'] = index[0]
            else:
                opti['Exchange'] = index[0][0]
        
        
            # maintain tail of every symbol
            #t = opti.groupby(['Symbol']).last()  # get last element for every symbol for tail maintance 
            #t = t.reset_index().set_index(['Symbol','time'])
            #global_df = global_df.append(t)
        
            opti.set_index(['Symbol','time'], inplace=True)
            result = result.append(opti)
    
        
        
    #global_df.sort_values(by=['Symbol','time'], inplace=True)

                 
    # redis connection 
    #r = redis.Redis(host=redis_host, port=6379)
    #r.set('global_{}_m1'.format(endtime), global_df.to_msgpack(compress='zlib'))  # publish tail to global df redis 
    
    #result.to_csv('agg.csv' )
    print 'Agg func : ',time.time() - agg_main
    print 'Aggregation length: ',len(result)
    logging.info('Agg func : {}'.format(time.time() - agg_main))
    logging.info('Aggregation length: {}'.format(len(result)))    
    
    return result

def summary_func(result, starttime, endtime):
    '''Func to generate summary data'''
    stime = time.time()
    if len(result)==0:
        d =  pd.DataFrame(columns=['Symbol','time','VolumeTraded_cash','LTP_cash','VolumeTraded_fut','LTP_fut',
                      'Volume_cash','Volume_fut','cfvolume','spread_ab','spread_bps'])
        d.set_index('Symbol', inplace=True)
        return d
    
    # cash df for NSE
    cash_df = result[result['Exchange']=='NSE']
    
    # fill na with forward pads i.e. copy value as it is in forward timestamp
    if cash_df.isnull().values.any():
        cash_df.fillna(method='pad', inplace=True)
    # difference of volume traded with cconsecutive time bound 
    #cash_df.sort_values(by = 'date', ascending=True , inplace=True)
    # concat last memory df 
    '''
    temp = pd.DataFrame()
    
    global_df = ''
    # redis connection ; read global tail for forward diff operation 
    r = redis.Redis(host=redis_host, port=6379)
    if starttime == datetime.time(9,15):
        global_df = pd.read_msgpack(r.get('global_{}_m1'.format(endtime)))
    else:
        global_df = pd.read_msgpack(r.get('global_{}_m1'.format(starttime)))
        
    
    global_df.reset_index(inplace=True)
    cash_df.reset_index(inplace=True)
    
    for symbol in sorted(set(cash_df['Symbol'])):
        try:
            temp  = temp.append(global_df[(global_df['Symbol']==symbol) & (global_df['Exchange']=='NSE')]) # append global tail at start
            temp = temp.append(cash_df[cash_df['Symbol']==symbol])  # append df at the end 
        
        except:
            pass
        
    temp.drop_duplicates(inplace=True, keep='last')
    cash_df = temp.set_index(['Symbol','time']) 
    
    # cal volume cash
    cash_df['Volume_cash'] = cash_df.groupby('Symbol')['VolumeTraded'].diff()
    cash_df['Volume_cash'] = cash_df['Volume_cash'].fillna(cash_df['VolumeTraded'])
    '''
    cash_df.rename(columns={'Volume':'Volume_cash'}, inplace=True)
    # cal percent change in fut price B/A -1 * 100
        
    
    fut_df = result[result['Exchange']=='NFO']
    # fill na with forward pads i.e. copy value as it is in forward timestamp
    fut_df.fillna(method='pad', inplace=True)
    # difference of volume traded with cconsecutive time bound 
    #fut_df.sort_values(by = 'date', ascending=True , inplace=True)
    # concat last memory df 
    '''
    temp = pd.DataFrame()
    fut_df.reset_index(inplace=True)
    for symbol in sorted(set(fut_df['Symbol'])):
        try:
            temp  = temp.append(global_df[(global_df['Symbol']==symbol) & (global_df['Exchange']=='NFO')])
            temp = temp.append(fut_df[fut_df['Symbol']==symbol])
        
        except:
            pass
    temp.drop_duplicates(inplace=True, keep='last')
    fut_df = temp.set_index(['Symbol','time'])     
    
    fut_df['Volume_fut'] = fut_df.groupby('Symbol')['VolumeTraded'].diff()
    fut_df['Volume_fut'] = fut_df['Volume_fut'].fillna(fut_df['VolumeTraded'])
    '''
    fut_df.rename(columns={'Volume':'Volume_fut'}, inplace=True)
    
    # merge cash and futures df
 
    temp = cash_df.reset_index().assign(key=cash_df.index.get_level_values(1)).merge(fut_df.reset_index().assign(key=fut_df.index.get_level_values(1)),
                                                                          on=['key','Symbol'], how='outer', suffixes=('_cash','_fut')).set_index(['Symbol']).drop(columns=['time_cash','time_fut','Exchange_cash','Exchange_fut'], axis=1)[['key','VolumeTraded_cash','LTP_cash','VolumeTraded_fut','LTP_fut','Volume_cash','Volume_fut']]

    temp.rename(columns={'key':'time'}, inplace=True)
    # fill non tarded time with zeros on merged df
    temp.fillna(0, inplace=True)
    
    # min of volume cash and future
    temp['cfvolume'] = temp[['Volume_cash','Volume_fut']].min(axis=1, numeric_only=True)
    
    # calc spread of price:ltp
    temp['spread_ab'] = temp['LTP_fut'] - temp['LTP_cash']
    # spread in 10,000 bps
    temp['spread_bps'] = temp['spread_ab']*10000/temp['LTP_cash']
    # replace inf with zeros; zero divison handling for cash=0
    temp.replace(np.inf, 0, inplace=True)
    
    # percent change
    temp = temp[temp['LTP_fut']!=0]
    
    
    
    #temp.to_csv('summ.csv')
    print 'Summary func: ', time.time() - stime
    logging.info('Summary func: {} '.format( time.time() - stime))
   
    
    return temp   
   
    
    
    
def ticker_generator(starttime,endtime, filename, pairmaster, expiry_dates_master,r):
    '''Func to read 5 min logutility file and generate 5 sec ticker stats for volume traded and LTP for each symbol''' 
    
        
    cols = ['date','Symbol','QtyBuy int','QtyBuy_2','QtyBuy_3','QtyBuy_4','QtyBuy_5','Bid','Bid_2','Bid_3','Bid_4','Bid_5','offer',
        'Offer_2','Offer_3','Offer_4','Offer_5','QtySell','QtySell_2','QtySell_3','QtySell_4','QtySell_5','VolumeTraded',
        'OpenPrice','Ccy', 'LTP','NumberOfOrdersBuy','NumberOfOrdersBuy_2','NumberOfOrdersBuy_3','NumberOfOrdersBuy_4',
        'NumberOfOrdersBuy_5','NumberOfOrdersSell','NumberOfOrdersSell_2','NumberOfOrdersSell_3','NumberOfOrdersSell_4',
        'NumberOfOrdersSell_5','LowerCircuitLimit','UpperCircuitLimit','HighPrice','LowPrice','ClosePrice','LTT timestamp',
        'NetChangeIndicator','LTQ','LotSize','OI','SecurityCode','ExchangeSegment','TradingSymbol']
    
    prices_df = pd.DataFrame(); prices_df_1 = pd.DataFrame()    
    
    try:  
        print 'Processing : ',filename[1]
        # read input file for every 5 sec data 
        prices_df = pd.read_csv(download_dir+filename[0],delimiter=',', engine='c'
                                , names=cols,skipinitialspace=True, low_memory=False )[['date','Symbol','VolumeTraded',
                                'LTP','ClosePrice','OI','SecurityCode','ExchangeSegment']]
        
        prices_df['date'] = prices_df['date'].str.split('+',expand=True)
        prices_df['date'] = pd.to_datetime(prices_df['date'], format='%Y-%m-%d %H:%M:%S')        
        
        
        logging.info('Sucessfully read ticker file {}'.format(filename[0]))
        
    except Exception as e :
        logging.info('No file with name {}'.format(filename[0]))
        
        
    try:       
        
        prices_df_1 = pd.read_csv(download_dir+filename[1],delimiter=',', engine='c',
                                  names=cols,skipinitialspace=True, low_memory=False )[['date','Symbol','VolumeTraded',
                                  'LTP','ClosePrice','OI','SecurityCode','ExchangeSegment']]
        
        prices_df_1['date'] = prices_df_1['date'].str.split('+',expand=True)
        prices_df_1['date'] = pd.to_datetime(prices_df_1['date'], format='%Y-%m-%d %H:%M:%S')    
        
        logging.info('Sucessfully read ticker file {}'.format(filename[1]))
        
    except Exception as e :        
        logging.info('Exception: {} // No file with name {}'.format(e,filename[1]))
           
        

    # concat two dataframes
    prices_df = pd.concat([prices_df, prices_df_1], axis=0)
    '''
    with open('vgaurd.csv','ab') as f:
        prices_df[prices_df['Symbol']=='VGUARD'].to_csv(f)
        f.close()
        '''
    #prices_df.to_csv('raw.csv', index=False)
    # retain records between market hours and ignore rest
    prices_df['time'] = prices_df['date'].dt.time   
    prices = prices_df[ (prices_df['time']>= starttime ) & (prices_df['time']< endtime)]     
    #ignore_tf = prices_df[ ~((prices_df['time']>= starttime ) & (prices_df['time']< endtime)) ]   
 
    
    # ignore codes with long codes
    if prices.SecurityCode.dtype==str:
        prices = prices[ ~(prices.SecurityCode.str.len() > 6 ) ]
    #prices = prices[(prices['Symbol']=='ACC') | (prices['Symbol']=='ADANIENT')]

    # cpnvert to numeric
    prices['SecurityCode'] = pd.to_numeric(prices['SecurityCode'], errors='coerce') 
    #prices.to_csv('ticker.csv')
    
    # final result 
    print 'Start time {} End time {}'.format(starttime, endtime)
    logging.info('Start time {} End time {}'.format(starttime, endtime))
    result = aggregate_func(prices, starttime, endtime, pairmaster, expiry_dates_master,r)
    # get summary data for cashtill now and future till now;
    result = summary_func(result, starttime, endtime)
 
    # filter on start time and end time 
    result = result[ (result['time']>= str(starttime) ) & (result['time']< str(endtime))] 
    
    
    '''
    #result.to_csv('final.csv')
    with open('final.csv','ab') as f:
        result.to_csv(f)
        f.close()
    '''
    
    return result
    


def cumulative_computation_func(r, today_files):
    '''Func to do cummulative compuation for any given month'''
    
    df = pd.DataFrame()  
    for f in today_files:
        df = df.append(pd.read_msgpack(r.get(f)))
    
    result = []
    try:
        
        for gname, gelements in df.groupby(['Symbol']):
            
            sum_fa = gelements[gelements['FA/RA'] == 'FA']['cfvolume'].sum() # filter on fa
            sum_ra = gelements[gelements['FA/RA'] == 'RA']['cfvolume'].sum() # filter on ra    
            sum_short_futs = gelements['Short Futs'].sum() 
            sum_long_futs = gelements['Long Futs'].sum() 
                    
                
            result.append([gname, sum_fa, sum_ra ,round(sum_short_futs), round(sum_long_futs)])
                
        result = pd.DataFrame(result, columns=['Symbol','FA','RA','Short Futs','Long Futs'])
        
        return result    
    except:
        print 'Params compute program not running on server'
        logging.info('Params compute program not running on server')
        return -1





def price_Oi_change(re, expiry_dates_master):
    '''Func to get price and OI change for current month'''
   
 
    
    # check for fo bhavcopy 
    #files = [f for f in os.listdir('.') if os.path.isfile(f) and f.startswith('fo')]
    
    df = pd.read_csv('fobhav_{}.csv'.format(datetime.datetime.today().date()- datetime.timedelta(days=1)))
    
    df = df[df['INSTRUMENT']=='FUTSTK'][['SYMBOL','EXPIRY_DT','OPEN_INT']]
    df['EXPIRY_DT'] = df['EXPIRY_DT'].apply(lambda row: pd.to_datetime(row))
    res = pd.DataFrame()
    if datetime.datetime.now().date() not in expiry_dates_master.values:
        res = df.sort_values(by='EXPIRY_DT').groupby(['SYMBOL'], sort=True).head(2)
        res = res.groupby(['SYMBOL']).agg({'OPEN_INT':'sum'}).reset_index()
    else:
        res = df.sort_values(by='EXPIRY_DT').groupby(['SYMBOL'], sort=True).tail(2)
        res = res.groupby(['SYMBOL']).agg({'OPEN_INT':'sum'}).reset_index()
    res.rename(columns={'SYMBOL':'Symbol'}, inplace=True)  
    
    res.to_csv('bhav.csv')
    
    # get close price and OI from redis dumped files 
    cp_oi_df = pd.DataFrame()
    for f in list(re.keys('price_oi_chg_*')):
        cp_oi_df = pd.concat([cp_oi_df, pd.read_msgpack(re.get(f))], axis=0)
    cp_oi_df = cp_oi_df.sort_values(by='time').groupby(['Symbol'],sort=True).last().reset_index()[['Symbol','time','ClosePrice','Current_month','next_month','OI']]  # get futures LTP from dumped redis files
    #cp_oi_df.to_csv('price_oi_chg.csv')
    # get LTP files from processed market files dumped in redis 
    d = datetime.date.today()
    today_files = ''.join(['0'+str(d.day) if len(str(d.day))==1 else str(d.day),'0'+str(d.month) if len(str(d.month))==1 else str(d.month),
                 str(d.year)])
    today_files = list(re.keys('{}*'.format(today_files)))
    
    # current month
    today_files_m1 = [ x for x in today_files if x.endswith('_m1')]    
    # current month ltp
    ltp_df_m1 = pd.DataFrame()
    for f in today_files_m1:
        ltp_df_m1 = pd.concat([ltp_df_m1, pd.read_msgpack(re.get(f))], axis=0)
    ltp_df_m1 = ltp_df_m1.sort_values(by='time').groupby(['Symbol'],sort=True).last().reset_index()[['Symbol','LTP_fut']]  # get futures LTP from dumped redis files
    
    
    ltp_df = pd.DataFrame()
    if re.get("email_next_month_flag")!=None and int(re.get("email_next_month_flag"))==1:  
        print "Flag: Processing for next month"
        logging.info("Flag: Processing for next month")
        # next month ltp prices 
        today_files_m2 = [ x for x in today_files if x.endswith('_m2')]   
        ltp_df_m2 = pd.DataFrame()
        for f in today_files_m2:
            ltp_df_m2 = pd.concat([ltp_df_m2, pd.read_msgpack(re.get(f))], axis=0)
        ltp_df_m2 = ltp_df_m2.sort_values(by='time').groupby(['Symbol'],sort=True).last().reset_index()[['Symbol','LTP_fut']]  # get futures LTP from dumped redis files
        
        ltp_df = ltp_df_m1.merge(ltp_df_m2, on="Symbol", how="left", suffixes=('_m1', '_m2'))
    else:
        print "Next month data not combined in email"
        ltp_df = ltp_df_m1.copy(deep=True)
        ltp_df.rename(columns={"LTP_fut":"LTP_fut_m1"}, inplace=True)
           
    
    cp_oi_df = cp_oi_df.merge(ltp_df, on='Symbol', how='left')
    cp_oi_df = cp_oi_df.merge(res, on='Symbol', how='left')
    
    cp_oi_df['Px_chg'] = (cp_oi_df['LTP_fut_m1'] - cp_oi_df['ClosePrice'])/ cp_oi_df['ClosePrice']* 100
    cp_oi_df['OI_Chg_quantity'] = cp_oi_df['OI']- cp_oi_df['OPEN_INT']
    cp_oi_df['OI_chg'] = (cp_oi_df['OI_Chg_quantity'])/ cp_oi_df['OPEN_INT']* 100
    
    # round till 2 decimals 
    cp_oi_df['Px_chg'] = cp_oi_df['Px_chg'].round(2)
    cp_oi_df['OI_chg'] = cp_oi_df['OI_chg'].round(2)
    #cp_oi_df['OI_Chg ($mn)'] = cp_oi_df['OI_Chg ($mn)']*dollar_value/10000  # oi change mn dollars
    
    if re.get("email_next_month_flag")!=None and int(re.get("email_next_month_flag"))==1:    
        cp_oi_df = cp_oi_df[['Symbol','Px_chg','OI_chg','OI_Chg_quantity','LTP_fut_m1','LTP_fut_m2']]    
        return cp_oi_df
    else:
        cp_oi_df = cp_oi_df[['Symbol','Px_chg','OI_chg','OI_Chg_quantity','LTP_fut_m1']]    
        return cp_oi_df
        





def cumulative_result(expiry_dates_master):
    '''Func to display cummulative result for all the files'''
    
    r = redis.Redis(host=redis_host, port=6379) 
    
    dollar_value = 69
    if r.get('dollar_value')!=None:
        dollar_value = float(r.get('dollar_value'))
    print '-----------------------------'
    print dollar_value
    
    d = datetime.date.today() 
    today_files = ''.join(['0'+str(d.day) if len(str(d.day))==1 else str(d.day),'0'+str(d.month) if len(str(d.month))==1 else str(d.month),
                 str(d.year)])
            
    today_files = list(sorted(r.keys('bpsresult_{}_*'.format(today_files))))
    today_files_m1 = list(sorted( [ x for x in today_files if x.endswith('m1')] ))  # filter on current month m1      
    result_m1 = cumulative_computation_func(r, today_files_m1)
    
    today_files_m2 = list(sorted( [ x for x in today_files if x.endswith('m2')] ))  # filter on current month m2      
    result_m2 = cumulative_computation_func(r, today_files_m2)
    
    try:
        if result_m1 == -1:
            logging.info('No params set; hence skiping email')
            return -1
    except:
        pass
    # get price and OI change 
    price_oi_chg_df = price_Oi_change(r, expiry_dates_master)
    result_m1 = price_oi_chg_df.merge(result_m1, on='Symbol',how='left')    
    # replace symbols with bloomcode
    bloom = pd.read_csv(master_dir+"bloomcode.csv")
    result_m1 = result_m1.merge(bloom, on='Symbol', how='left')
    
    
    # current month calc
    result_m1 = result_m1[['BloomCode','Px_chg','OI_chg','OI_Chg_quantity','FA','RA','Short Futs','Long Futs','LTP_fut_m1']]        
    result_m1.dropna(inplace=True)
    result_m1['Non_Arb_long'] = result_m1['Long Futs'] 
    result_m1['Non_Arb_short'] = result_m1['Short Futs']        
    # convert into million dollars 
    result_m1['OI_Chg ($mn)'] = result_m1.apply(lambda row: row['OI_Chg_quantity']*row['LTP_fut_m1']/(1000000*dollar_value) if row['OI_Chg_quantity']!=0 else 0,axis=1 ) 
    #result_m1['OI_Chg_quantity'] = result_m1['OI_Chg_quantity'].round()
    result_m1['Arb_long ($mn)'] = result_m1.apply(lambda row: row['RA']*row['LTP_fut_m1']/(1000000*dollar_value) if row['RA']!=0 else 0, axis=1 ) 
    #result_m1['FA'] = result_m1['FA'].round()
    result_m1['Arb_short ($mn)'] = result_m1.apply(lambda row: row['FA']*row['LTP_fut_m1']/(1000000*dollar_value) if row['FA']!=0 else 0, axis=1 ) 
    #result_m1['RA'] = result_m1['RA'].round()
    result_m1['Non_Arb_long ($mn)'] = result_m1.apply(lambda row: row['Non_Arb_long']*row['LTP_fut_m1']/(1000000*dollar_value) if row['Non_Arb_long']!=0 else 0, axis=1 ) 
    #result_m1['Short Futs'] = result_m1['Short Futs'].round()
    result_m1['Non_Arb_short ($mn)'] = result_m1.apply(lambda row: row['Non_Arb_short']*row['LTP_fut_m1']/(1000000*dollar_value) if row['Non_Arb_short']!=0 else 0, axis=1 ) 
    #result_m1['Long Futs'] = result_m1['Long Futs'].round()
    result_m1['key'] = result_m1['OI_Chg ($mn)'].abs()
    result_m1[['OI_Chg ($mn)','Arb_long ($mn)','Arb_short ($mn)','Non_Arb_long ($mn)','Non_Arb_short ($mn)']] = result_m1[['OI_Chg ($mn)',
               'Arb_long ($mn)','Arb_short ($mn)','Non_Arb_long ($mn)','Non_Arb_short ($mn)']].round()
    
    
    result_m1.sort_values(by='key', ascending =False, inplace=True)  # reorder by abs high to low 
    #result_m1.to_csv("email1.csv", index=False)
    
    # convet to million dollars 
    #result_m1['key'] = result_m1['OI_chg'].abs()
    #result_m1.sort_values(by='key', ascending =False, inplace=True)  # reorder by abs high to low 
    
    # arb and non_arb calc 
    #result_m1['res+'] = result_m1['OI_Chg_quantity'] - result_m1['RA'] - result_m1['Long Futs']
    #result_m1['res-'] = result_m1['OI_Chg_quantity'] - result_m1['FA'] - result_m1['Short Futs']
    
    #result_m1['Non_Arb_long'] = result_m1['Long Futs'] + result_m1['res+']
    #result_m1['Non_Arb_short'] = result_m1['Short Futs'] + result_m1['res-']
    
    
    
    
    
    if r.get("email_next_month_flag")!=None and int(r.get("email_next_month_flag"))==1:  
        print 'Email for next month flag is set'
        try:
            
            
            print 'IN'
            result_m2 = price_oi_chg_df.merge(result_m2, on='Symbol',how='left')    
            result_m2 = result_m2.merge(bloom, on='Symbol', how='left')
            result_m2 = result_m2[['BloomCode','FA','RA','Short Futs','Long Futs','LTP_fut_m2']]  
            result_m2.set_index('BloomCode', inplace=True)
            result_m2.dropna(how="all", inplace=True)
    	    result_m2.dropna(inplace=True)
            result_m2.reset_index(inplace=True)
            
            result_m2['Non_Arb_long'] = result_m2['Long Futs'] 
            result_m2['Non_Arb_short'] = result_m2['Short Futs']   
            
            print 'hellllll'
            result_m2['Arb_long ($mn) m2'] = result_m2.apply(lambda row: row['RA']*row['LTP_fut_m2']/(1000000*dollar_value) if row['RA']!=0 else 0, axis=1 ) 
            result_m2['Arb_short ($mn) m2'] = result_m2.apply(lambda row: row['FA']*row['LTP_fut_m2']/(1000000*dollar_value) if row['FA']!=0 else 0, axis=1 )          
            result_m2['Non_Arb_long ($mn) m2'] = result_m2.apply(lambda row: row['Non_Arb_long']*row['LTP_fut_m2']/(1000000*dollar_value) if row['Non_Arb_long']!=0 else 0, axis=1 )                
            result_m2['Non_Arb_short ($mn) m2'] = result_m2.apply(lambda row: row['Non_Arb_short']*row['LTP_fut_m2']/(1000000*dollar_value) if row['Non_Arb_short']!=0 else 0, axis=1 ) 
            # round 
            result_m2[['Arb_long ($mn) m2','Arb_short ($mn) m2','Non_Arb_long ($mn) m2','Non_Arb_short ($mn) m2']] = result_m2[['Arb_long ($mn) m2','Arb_short ($mn) m2','Non_Arb_long ($mn) m2','Non_Arb_short ($mn) m2']].round()
            
            result_m2 = result_m2[['BloomCode','Arb_long ($mn) m2','Arb_short ($mn) m2','Non_Arb_long ($mn) m2','Non_Arb_short ($mn) m2']]
            #result_m2.to_csv("email2.csv", index=False)
            result_m1 = result_m1.merge(result_m2, how="left", on="BloomCode")
            result_m1.fillna(0, inplace=True)
            #result_m1.to_csv("emaildebug.csv", index=False)
            # combine 
            result_m1['Arb_long ($mn)'] = result_m1['Arb_long ($mn)'] + result_m1['Arb_long ($mn) m2']
            result_m1['Arb_short ($mn)'] = result_m1['Arb_short ($mn)'] + result_m1['Arb_short ($mn) m2']
            result_m1['Non_Arb_long ($mn)'] = result_m1['Non_Arb_long ($mn)'] + result_m1['Non_Arb_long ($mn) m2']
            result_m1['Non_Arb_short ($mn)'] = result_m1['Non_Arb_short ($mn)'] + result_m1['Non_Arb_short ($mn) m2']
            #result_m1.to_csv("emailfinal.csv", index=False)
        
        except Exception as e :
            print e
            logging.info("Issues while converting next month fa ra to dollar values")
            print "Issues while converting next month fa ra to dollar values"
    

    result_m1.rename(columns={'BloomCode':'BERG'}, inplace=True)          
    result_m1 = result_m1[['BERG','Px_chg','OI_chg','OI_Chg ($mn)','Arb_long ($mn)','Arb_short ($mn)','Non_Arb_long ($mn)',
                               'Non_Arb_short ($mn)']]
        
    result_m1.set_index('BERG', inplace=True)
    return result_m1
            
        
    
    
 
     

def snapshot_email(expiry_dates_master, time_key):
    '''Snapshot email of cumulative report'''
    
    result = cumulative_result(expiry_dates_master)
    try:
        if result == -1:   
            print 'Skip email'
            logging.info('Skip email')
    except:
        result.to_csv('basis_snapshot.csv')
        email_utility.attachment_emails('basis_snapshot.csv', time_key)
        logging.info('{} : Email sent successfully'.format(time_key))
        



  
    
def main():
    '''Func to read files, process and do scheduling of entire process'''
    # read yesterdays bhavcopy file 
    logging.info("Start Process")
    shutil.copy(fo_path+'fobhav.csv', 'fobhav_{}.csv'.format(datetime.datetime.today().date()- datetime.timedelta(days=1)) )
    logging.info("Copied yesterday bhavopy to current folder")
    # read pairmaster file for encodings
    # read master file for cash and fut codes 
    pairmaster = pd.read_csv(master_dir+'PairMaster.csv')
    
    expiry_dates_master = pd.read_csv(master_dir+'Expiry_dates_master.csv')
    expiry_dates_master['date'] = expiry_dates_master.apply(lambda row: pd.to_datetime(str(row['Date'])+row['Month']+str(row['Year'])).date(),
                       axis=1)
    expiry_dates_master = expiry_dates_master[expiry_dates_master['Expiry']=='E']['date']
    logging.info("Read master files")
    # create redis keys
    timekeys = redis_key_generator()
    timekeys_30 = [ t for t in timekeys if t.endswith('00') or t.endswith('30')][1:] 
    
    # get filenames to be processed over a time 
    files = gen_filename(timekeys)
    filenames = []
    for index, f in enumerate(files):
        try:
            filenames.append( [files[index-1], f] )
        except Exception as e:
            print 'Error'
            logging.info('Exception: {}'.format(e))
        
    filenames.pop(0)  
    
    # redis connection 
    r = redis.Redis(host=redis_host, port=6379)
    
    for index, filename in enumerate(filenames):
        if datetime.datetime.now().time() > datetime.time(23,0):   # run code till 4 pm
            logging.info("End process")
            break
            
        while not os.path.exists(download_dir+filename[1]):   
            
            print 'Resume after 10 secs'
            logging.info('Resume after 10 secs')
            time.sleep(10)
        else:                 
            start = time.time() 
            print "---------{}  -----".format(filename)
            result = ticker_generator(datetime.time(int(filenames[index-1][1].split('_')[-1].split('.')[0][:2]),
                                           int(filenames[index-1][1].split('_')[-1].split('.')[0][2:]) ),
                             datetime.time(int(filenames[index][1].split('_')[-1].split('.')[0][:2]), 
                                           int(filenames[index][1].split('_')[-1].split('.')[0][2:]) )
                             ,filename, pairmaster, expiry_dates_master,r)           
            
            r.set('{}_m1'.format('_'.join(filename[1].split('_')[-2:])[:-4]), result.to_msgpack(compress='zlib'))
            print 'Total data processing time : {}'.format(time.time()-start)
            logging.info('Total data processing time : {}'.format(time.time()-start))
            snap_time_t = str(datetime.time(int(filenames[index][1].split('_')[-1].split('.')[0][:2]), 
                                           int(filenames[index][1].split('_')[-1].split('.')[0][2:]) ))
            snap_time = ''.join(snap_time_t.split(':')[:2])
         
            if  snap_time in timekeys_30:
                # send 30 min snapshot email 
                time.sleep(10)
                snapshot_email(expiry_dates_master, snap_time_t)
            


if __name__ == '__main__':
    main()
    # remove bhavcopy 
    os.remove('fobhav_{}.csv'.format(datetime.datetime.today().date()- datetime.timedelta(days=1)))
    logging.info("End of the process for the day")


'''    
df = pd.read_msgpack(r.get('bpsresult_07052019_09:15_10:00_m1'))    
df1 = pd.read_msgpack(r.get('bpsresult_07052019_10:00_10:30_m1'))   
df2 = pd.read_msgpack(r.get('bpsresult_07052019_10:30_11:00_m1'))   
df3 = pd.read_msgpack(r.get('bpsresult_07052019_11:00_11:30_m1'))   

df = pd.concat([df,df1,df2,df3], axis=0)
df.to_csv('test.csv')



df=pd.DataFrame()
for x in r.keys('13032020_*_m1'):
    df=df.append(pd.read_msgpack(r.get(x)))
    




'''



