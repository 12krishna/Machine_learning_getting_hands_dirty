# -*- coding: utf-8 -*-
"""
Created on Thu Feb  7 10:44:06 2019

@author: Administrator
"""

import numpy as np 
import pandas as pd
import logging 
#from dateutil import parser
import time
import datetime
import redis

redis_host = '10.223.104.61'

symbol='ALBK'
   
r = redis.Redis(host=redis_host, port=6379) 

d = datetime.date.today()
today_files = ''.join(['0'+str(d.day) if len(str(d.day))==1 else str(d.day),'0'+str(d.month) if len(str(d.month))==1 else str(d.month),
             str(d.year)])
today_files = sorted(r.keys('{}*'.format(today_files)))


df = pd.DataFrame()
for filename in today_files:
    # merge available files
    df1 = pd.read_msgpack(r.get(filename))
    df = pd.concat([df, df1], axis=0)
    

df = df.loc[symbol]
df.to_excel(symbol+'_'+today_files[-1].split('_')[1]+'.xlsx', index=False)