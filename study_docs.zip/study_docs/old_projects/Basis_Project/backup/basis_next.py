import numpy as np 
import pandas as pd
import logging 
#from dateutil import parser
import time
from datetime import date, timedelta
import datetime
#import matplotlib.pyplot as plt 
import logging
import redis
import zlib
import os 

redis_host = '10.223.104.61'

download_dir = "/tmp/"
master_dir = "/opt/Basis_project/Master/"
log_path = "/opt/Basis_project/"
global_avg_df = pd.DataFrame()

logging.basicConfig(filename=log_path+"basis_current.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


def redis_key_generator():
    '''Generate all the keys needed for computation over a period of day '''
    
    # read master file for cash and fut codes 
    #symbols = pd.read_excel(master_dir+'PairMaster.xlsx')['Symbol']
    # redis server connection
    #r = redis.Redis(host='localhost', port=6379)
    #keys = []
    timekeys = []
    a = datetime.datetime(1,1,1,9,5)
    
    for i in range(77):
        a = a + datetime.timedelta(minutes=5)
        timekeys.append("{}{}".format(('0'+str(a.hour) if len(str(a.hour))==1 else str(a.hour)),
                                      ( '0'+str(a.minute) if len(str(a.minute))==1 else str(a.minute))))

    '''
    for symbol in symbols:
        for time in timekeys:
            keys.append(symbol+'.'+time)
            
    for key in keys:
        r.set(key, '') '''
        
    return timekeys


def gen_filename(timekeys):
    '''Generate filenames'''
    
    d = datetime.date.today()
    filename = []
    for timek in timekeys:
        filename.append( 'debug_log_mktdata_{}{}{}_{}.txt'.format(('0'+str(d.day) if len(str(d.day))==1 else str(d.day)),
                                                ('0'+str(d.month) if len(str(d.month))==1 else str(d.month)),
                                                str(d.year), timek ))
        
    return filename


def dateparse(row):
    '''Func to parse dates while reading ticker files'''
    d = row.split("+")[0]
    d = pd.to_datetime(d, format='%Y-%m-%d %H:%M:%S')
    return d
    

def agg_func(grp):
    '''agg func weighted avearge on LTP sum of volume diff'''        
    
    return pd.Series({'VolumeTraded':np.max(grp['VolumeTraded']),'Volume':np.sum(grp['Volume']),
                      'LTP': np.average(grp['LTP'], weights=grp['Volume']) if sum(grp['Volume'])!=0 else 0 })
   
    
  



def aggregate_func(prices, starttime, endtime, pairmaster):
    '''Func to return max of volume traded and mean of LTP for 5 sec ticker data'''   
    
    agg_main = time.time()
    
    # return empty df if empty 
    if len(prices)==0:
        d =  pd.DataFrame(columns=['Symbol','time','VolumeTraded_cash','LTP_cash','VolumeTraded_fut','LTP_fut',
                      'Volume_cash','Volume_fut','cfvolume','spread_ab','spread_bps'])
        d.set_index('Symbol', inplace=True)
        return d
    
    
    try:        
        # time range refrence ; for filling empty timeframes while aggr ip data
        time_keys = pd.DataFrame(pd.timedelta_range(start=str(starttime), end=str(endtime), freq = '60s')[:-1], columns=['time'])
        time_keys['time'] = time_keys.apply(lambda row: str(row['time']).split(' ')[-1], axis=1)
        
    except:
        print 'time issue'

    
    result = pd.DataFrame()  # processing result after aggregation over 5s data 
    #global_df = pd.DataFrame()
    for index in [['NFO','FutCode_m2' ],[['NSE','NSECashCode'], ['BSE','BSECashCode']]]:
        print 'Aggregating over exchange {}, with secuirty code on {}'.format(index[0], index[1])
        opti = prices.merge(pairmaster, on='Symbol',how='left')
        if index[0]=='NFO':
            opti = opti[(opti['ExchangeSegment']==index[0]) & (opti['SecurityCode']==opti[index[1]])]   
            if starttime==datetime.time(9,15):
                # first instance no merging needed
                # maintain last insatnce of every symbol 
                global global_avg_df
                global_avg_df = global_avg_df.append(opti.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                
            else:
                # merge previous instance volume and price 
                global global_avg_df
                temp = global_avg_df[global_avg_df['ExchangeSegment']==index[0]]
                # main tail to global 
                global_avg_df = global_avg_df.append(opti.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                #update global with single instance
                global_avg_df = global_avg_df.groupby(['Symbol','ExchangeSegment'], sort=True).last().reset_index()
                
                
                opti = pd.concat([opti, temp], axis=0, ignore_index=True)  
                                
            
            opti['Volume'] = opti.groupby('Symbol', sort=True)['VolumeTraded'].diff().fillna(0)   # get volume from volume traded till now   
            opti = opti[ (opti['time']>= starttime ) & (opti['time']< endtime)]   # filter on time 
            
            opti = opti.groupby(['Symbol',pd.Grouper(key='date',freq='60s', 
                                                     sort=True)]).apply(lambda grp: agg_func(grp)).reset_index() 
    
        else:
            # combaining on NSE and BSE
            #NSE
            temp1 = opti[(opti['ExchangeSegment']==index[0][0]) & (opti['SecurityCode']==opti[index[0][1]])]  #NSE
            if starttime==datetime.time(9,15):
                # first instance no merging needed
                global global_avg_df
                global_avg_df = global_avg_df.append(temp1.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                
            else:
                # merge previous instance volume and price 
                global global_avg_df
                temp = global_avg_df[global_avg_df['ExchangeSegment']==index[0][0]]
                  
                # main tail to global 
                global_avg_df = global_avg_df.append(temp1.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                #update global with single instance
                global_avg_df = global_avg_df.groupby(['Symbol','ExchangeSegment'], sort=True).last().reset_index()
                
                temp1 = pd.concat([temp1, temp], axis=0, ignore_index=True)     
                
                
            
            temp1['Volume'] = temp1.groupby('Symbol', sort=True)['VolumeTraded'].diff().fillna(0)   # get volume from volume traded till now   
            temp1 = temp1[ (temp1['time']>= starttime ) & (temp1['time']< endtime)]   # filter on time 
            
            temp1 = temp1.groupby(['Symbol',pd.Grouper(key='date',freq='60s', 
                                                       sort=True)]).apply(lambda grp: agg_func(grp)).reset_index() 
    
            #BSE
            temp2 = opti[(opti['ExchangeSegment']==index[1][0]) & (opti['SecurityCode']==opti[index[1][1]])]
            if starttime==datetime.time(9,15):
                # first instance no merging needed
                global global_avg_df
                global_avg_df = global_avg_df.append(temp2.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                
            else:
                # merge previous instance volume and price 
                global global_avg_df
                temp = global_avg_df[global_avg_df['ExchangeSegment']==index[1][0]]
                           
                # main tail to global 
                global_avg_df = global_avg_df.append(temp2.groupby(['Symbol'], sort=True).last().reset_index(), ignore_index=True)
                #update global with single instance
                global_avg_df = global_avg_df.groupby(['Symbol','ExchangeSegment'], sort=True).last().reset_index()
                
                temp2 = pd.concat([temp2, temp], axis=0, ignore_index=True)            
                
                
            
            temp2['Volume'] = temp2.groupby('Symbol', sort=True)['VolumeTraded'].diff().fillna(0)   # get volume from volume traded till now   
            temp2 = temp2[ (temp2['time']>= starttime ) & (temp2['time']< endtime)]   # filter on time 
            
            temp2 = temp2.groupby(['Symbol',pd.Grouper(key='date',freq='60s', 
                                                       sort=True)]).apply(lambda grp: agg_func(grp)).reset_index() 
            
            
            
            # combine NSE and BSE with weighted average 
            opti = pd.concat([temp1,temp2],axis=0, ignore_index=True)        
            opti = opti.groupby(['Symbol','date'], sort=True).apply(lambda grp: agg_func(grp)).reset_index() 
            
                    
        opti['time'] = opti['date'].dt.time.astype(str)
        opti.sort_values(by=['Symbol','time'], inplace=True) # sort for fill 
        # handling missing time frames 
        temp = pd.DataFrame()
        for gname, gelements in opti.groupby(['Symbol']):
            t = time_keys.merge(gelements, on='time',how='left')
            t.fillna(method='ffill', inplace=True)
            if t.isnull().values.any()==True:
                t.fillna(method='bfill', inplace=True)
            temp = temp.append(t)
            
        opti = temp.copy(deep=True)
        
        #opti.groupby(['Symbol']).transform(lambda x: x.sort_values(by ='time').fillna(method='ffill') )
        #opti.fillna(method='ffill', inplace=True)  # forward fill missing values 
        opti.drop(columns=['date'], inplace=True)
        if index[0]=='NFO':
            opti['Exchange'] = index[0]
        else:
            opti['Exchange'] = index[0][0]
    
    
        # maintain tail of every symbol
        #t = opti.groupby(['Symbol']).last()  # get last element for every symbol for tail maintance 
        #t = t.reset_index().set_index(['Symbol','time'])
        #global_df = global_df.append(t)
    
        opti.set_index(['Symbol','time'], inplace=True)
        result = result.append(opti)
    
        
        
    #global_df.sort_values(by=['Symbol','time'], inplace=True)

                 
    # redis connection 
    #r = redis.Redis(host=redis_host, port=6379)
    #r.set('global_{}_m1'.format(endtime), global_df.to_msgpack(compress='zlib'))  # publish tail to global df redis 
    
    result.to_csv('agg.csv' )
    print 'Agg func : ',time.time() - agg_main
    print 'Aggregation length: ',len(result)
    
    
    return result

def summary_func(result, starttime, endtime):
    '''Func to generate summary data'''
    stime = time.time()
    if len(result)==0:
        d =  pd.DataFrame(columns=['Symbol','time','VolumeTraded_cash','LTP_cash','VolumeTraded_fut','LTP_fut',
                      'Volume_cash','Volume_fut','cfvolume','spread_ab','spread_bps'])
        d.set_index('Symbol', inplace=True)
        return d
    
    # cash df for NSE
    cash_df = result[result['Exchange']=='NSE']
    
    # fill na with forward pads i.e. copy value as it is in forward timestamp
    if cash_df.isnull().values.any():
        cash_df.fillna(method='pad', inplace=True)
    # difference of volume traded with cconsecutive time bound 
    #cash_df.sort_values(by = 'date', ascending=True , inplace=True)
    # concat last memory df 
    '''
    temp = pd.DataFrame()
    
    global_df = ''
    # redis connection ; read global tail for forward diff operation 
    r = redis.Redis(host=redis_host, port=6379)
    if starttime == datetime.time(9,15):
        global_df = pd.read_msgpack(r.get('global_{}_m1'.format(endtime)))
    else:
        global_df = pd.read_msgpack(r.get('global_{}_m1'.format(starttime)))
        
    
    global_df.reset_index(inplace=True)
    cash_df.reset_index(inplace=True)
    
    for symbol in sorted(set(cash_df['Symbol'])):
        try:
            temp  = temp.append(global_df[(global_df['Symbol']==symbol) & (global_df['Exchange']=='NSE')]) # append global tail at start
            temp = temp.append(cash_df[cash_df['Symbol']==symbol])  # append df at the end 
        
        except:
            pass
        
    temp.drop_duplicates(inplace=True, keep='last')
    cash_df = temp.set_index(['Symbol','time']) 
    
    # cal volume cash
    cash_df['Volume_cash'] = cash_df.groupby('Symbol')['VolumeTraded'].diff()
    cash_df['Volume_cash'] = cash_df['Volume_cash'].fillna(cash_df['VolumeTraded'])
    '''
    cash_df.rename(columns={'Volume':'Volume_cash'}, inplace=True)
    # cal percent change in fut price B/A -1 * 100
        
    
    fut_df = result[result['Exchange']=='NFO']
    # fill na with forward pads i.e. copy value as it is in forward timestamp
    fut_df.fillna(method='pad', inplace=True)
    # difference of volume traded with cconsecutive time bound 
    #fut_df.sort_values(by = 'date', ascending=True , inplace=True)
    # concat last memory df 
    '''
    temp = pd.DataFrame()
    fut_df.reset_index(inplace=True)
    for symbol in sorted(set(fut_df['Symbol'])):
        try:
            temp  = temp.append(global_df[(global_df['Symbol']==symbol) & (global_df['Exchange']=='NFO')])
            temp = temp.append(fut_df[fut_df['Symbol']==symbol])
        
        except:
            pass
    temp.drop_duplicates(inplace=True, keep='last')
    fut_df = temp.set_index(['Symbol','time'])     
    
    fut_df['Volume_fut'] = fut_df.groupby('Symbol')['VolumeTraded'].diff()
    fut_df['Volume_fut'] = fut_df['Volume_fut'].fillna(fut_df['VolumeTraded'])
    '''
    fut_df.rename(columns={'Volume':'Volume_fut'}, inplace=True)
    
    # merge cash and futures df
 
    temp = cash_df.reset_index().assign(key=cash_df.index.get_level_values(1)).merge(fut_df.reset_index().assign(key=fut_df.index.get_level_values(1)),
                                                                          on=['key','Symbol'], how='outer', suffixes=('_cash','_fut')).set_index(['Symbol']).drop(columns=['time_cash','time_fut','Exchange_cash','Exchange_fut'], axis=1)[['key','VolumeTraded_cash','LTP_cash','VolumeTraded_fut','LTP_fut','Volume_cash','Volume_fut']]

    temp.rename(columns={'key':'time'}, inplace=True)
    # fill non tarded time with zeros on merged df
    temp.fillna(0, inplace=True)
    
    # min of volume cash and future
    temp['cfvolume'] = temp[['Volume_cash','Volume_fut']].min(axis=1, numeric_only=True)
    
    # calc spread of price:ltp
    temp['spread_ab'] = temp['LTP_fut'] - temp['LTP_cash']
    # spread in 10,000 bps
    temp['spread_bps'] = temp['spread_ab']*10000/temp['LTP_cash']
    # replace inf with zeros; zero divison handling for cash=0
    temp.replace(np.inf, 0, inplace=True)
    
    # percent change
    temp = temp[temp['LTP_fut']!=0]
    
    
    
    #temp.to_csv('summ.csv')
    print 'Summary func: ', time.time() - stime
   
    
    return temp   
   
    
    
    
def ticker_generator(starttime,endtime, filename, pairmaster):
    '''Func to read 5 min logutility file and generate 5 sec ticker stats for volume traded and LTP for each symbol''' 
    
        
    cols = ['date','Symbol','QtyBuy int','QtyBuy_2','QtyBuy_3','QtyBuy_4','QtyBuy_5','Bid','Bid_2','Bid_3','Bid_4','Bid_5','offer',
        'Offer_2','Offer_3','Offer_4','Offer_5','QtySell','QtySell_2','QtySell_3','QtySell_4','QtySell_5','VolumeTraded',
        'OpenPrice','Ccy', 'LTP','NumberOfOrdersBuy','NumberOfOrdersBuy_2','NumberOfOrdersBuy_3','NumberOfOrdersBuy_4',
        'NumberOfOrdersBuy_5','NumberOfOrdersSell','NumberOfOrdersSell_2','NumberOfOrdersSell_3','NumberOfOrdersSell_4',
        'NumberOfOrdersSell_5','LowerCircuitLimit','UpperCircuitLimit','HighPrice','LowPrice','ClosePrice','LTT timestamp',
        'NetChangeIndicator','LTQ','LotSize','OI','SecurityCode','ExchangeSegment','TradingSymbol']
    
    prices_df = pd.DataFrame(); prices_df_1 = pd.DataFrame()    
    
    try:  
        print 'Processing : ',filename[1]
        # read input file for every 5 sec data 
        prices_df = pd.read_csv(download_dir+filename[0],delimiter=',', engine='c'
                                , names=cols,skipinitialspace=True, low_memory=False )[['date','Symbol','VolumeTraded','LTP','SecurityCode','ExchangeSegment']]
        
        prices_df['date'] = prices_df['date'].str.split('+',expand=True)
        prices_df['date'] = pd.to_datetime(prices_df['date'], format='%Y-%m-%d %H:%M:%S')        
        
        
        logging.info('Sucessfully read ticker file {}'.format(filename[0]))
        
    except Exception as e :
        logging.info('No file with name {}'.format(filename[0]))
        
        
    try:       
        
        prices_df_1 = pd.read_csv(download_dir+filename[1],delimiter=',', engine='c',
                                  names=cols,skipinitialspace=True, low_memory=False )[['date','Symbol','VolumeTraded','LTP','SecurityCode','ExchangeSegment']]
        
        prices_df_1['date'] = prices_df_1['date'].str.split('+',expand=True)
        prices_df_1['date'] = pd.to_datetime(prices_df_1['date'], format='%Y-%m-%d %H:%M:%S')    
        
        logging.info('Sucessfully read ticker file {}'.format(filename[1]))
        
    except Exception as e :        
        logging.info('Exception: {} // No file with name {}'.format(e,filename[1]))
           
        

    # concat two dataframes
    prices_df = pd.concat([prices_df, prices_df_1], axis=0)
    with open('vgaurd.csv','ab') as f:
        prices_df[prices_df['Symbol']=='VGUARD'].to_csv(f)
        f.close()
    #prices_df.to_csv('raw.csv', index=False)
    # retain records between market hours and ignore rest
    prices_df['time'] = prices_df['date'].dt.time   
    prices = prices_df[ (prices_df['time']>= starttime ) & (prices_df['time']< endtime)]     
    #ignore_tf = prices_df[ ~((prices_df['time']>= starttime ) & (prices_df['time']< endtime)) ]   
 
    
    # ignore codes with long codes
    prices = prices[ ~(prices.SecurityCode.str.len() > 6 ) ]
    #prices = prices[(prices['Symbol']=='ACC') | (prices['Symbol']=='ADANIENT')]

    # cpnvert to numeric
    prices['SecurityCode'] = pd.to_numeric(prices['SecurityCode'], errors='coerce') 
    #prices.to_csv('ticker.csv')
    
    # final result 
    print 'Start time {} End time {}'.format(starttime, endtime)
    result = aggregate_func(prices, starttime, endtime, pairmaster)
    # get summary data for cashtill now and future till now;
    result = summary_func(result, starttime, endtime)
 
    # filter on start time and end time 
    result = result[ (result['time']>= str(starttime) ) & (result['time']< str(endtime))] 
    
    #result.to_csv('final.csv')
    with open('final.csv','ab') as f:
        result.to_csv(f)
        f.close()
    
    return result
    
        
    
def main():
    '''Func to read files, process and do scheduling of entire process'''
    
    # read pairmaster file for encodings
    # read master file for cash and fut codes 
    pairmaster = pd.read_csv(master_dir+'PairMaster.csv')
    
    # create redis keys
    timekeys = redis_key_generator()
    
    # get filenames to be processed over a time 
    files = gen_filename(timekeys)
    filenames = []
    for index, f in enumerate(files):
        try:
            filenames.append( [files[index-1], f] )
        except Exception as e:
            print 'Error'
            logging.info('Exception: {}'.format(e))
        
    filenames.pop(0)  
    
    # redis connection 
    r = redis.Redis(host=redis_host, port=6379)
    
    for index, filename in enumerate(filenames):
        if datetime.datetime.now().time() > datetime.time(23,0):   # run code till 4 pm
                break
            
        while not os.path.exists(download_dir+filename[1]):   
            
            print 'Resume after 10 secs'
            time.sleep(10)
        else:                 
            start = time.time()  
            result = ticker_generator(datetime.time(int(filenames[index-1][1].split('_')[-1].split('.')[0][:2]),
                                           int(filenames[index-1][1].split('_')[-1].split('.')[0][2:]) ),
                             datetime.time(int(filenames[index][1].split('_')[-1].split('.')[0][:2]), 
                                           int(filenames[index][1].split('_')[-1].split('.')[0][2:]) )
                             ,filename, pairmaster)           
            
            r.set('{}_m2'.format('_'.join(filename[1].split('_')[-2:])[:-4]), result.to_msgpack(compress='zlib'))
            print 'Total data processing time : {}'.format(time.time()-start)
            


if __name__ == '__main__':
    main()

#print "Execution time: {0} Seconds.... ".format(end_time - start_time)