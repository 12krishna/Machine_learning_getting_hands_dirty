from bs4 import BeautifulSoup
import time,datetime,re,os,urllib,json,logging,smtplib
import pandas as pd 
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import glob

curr_dir="D:\\CorporateActions1\\"
os.chdir(curr_dir) 
master_dir='D:\\Data_dumpers\\Master\\'
output_dir='D:\\CorporateActions1\\output\\'
download_dir='D:\\CorporateActions1\\download\\'
#share_drive = 'D:\\jsontoexcel\\'
processed_dir='D:\\CorporateActions1\\processed\\'
contacts_dir='D:\\CorporateActions1\\contacts\\'
log_dir='D:\\CorporateActions1\\log\\'

server = '172.17.9.149'; port = 25

MY_ADDRESS = 'KIEResearchAlerts@kotak.com'

logging.basicConfig(filename=log_dir+"Corporate_Announcement.log",filemode="w",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")



def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def process_email(**kwargs):  # accept variable number of keyworded arguments 
    
    '''Func to send daily report emails excel, text or html attachment emails or combination of any formats'''
    
    # get total email recipients 
    rcpt = []
    for email in kwargs['emails']:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message, to cc emails 
    msg['From']=MY_ADDRESS
    msg['To']=','.join(kwargs['emails'][0])
    msg['Cc']=','.join(kwargs['emails'][1])
    msg['Subject']= kwargs['subject']
        

    # attachments to the email
    if 'attachments' in kwargs.keys():
        for attachment in kwargs['attachments']:            
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(attachment, "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(attachment.split("\\")[-1] ))
            msg.attach(part) 

    # read message text or html files to be appeneded in email body 
    if 'html_email' in kwargs.keys():
        # read html message file
        message = open(kwargs['html_email'],'rb').read()
        msg.attach(MIMEText(message, 'html'))
    
    if 'text_email' in kwargs.keys():
        # read html message file
        message = kwargs['text_email']
        msg.attach(MIMEText(message, 'plain'))
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()

def dateparse_d(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',date_parser=dateparse_d, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''  
    if len(holiday_master[holiday_master['date']==d])==0:
        return 1
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        return -1

#function to get json data and perform formatting on it
def get_data(d):

    print "Inside get data function.................."
    url = "https://api.bseindia.com/BseIndiaAPI/api/AnnGetData/w?strCat=-1&strPrevDate={}&strScrip=&strSearch=P&strToDate={}&strType=C".format(d.strftime(format='%Y%m%d'),d.strftime(format='%Y%m%d'))
    logging.info("URL used to get data; {}".format(url))
    response=urllib.urlopen(url)
    logging.info("Response : {}".format(response.getcode()))
#    print "response",response
    data=response.read()    
    data = json.loads(data)
#    print "data",data
    try:
        with open(download_dir+"data_file_{}.json".format(d.strftime(format='%Y%m%d%H%M%S')), "w") as write_file:
            json.dump(data, write_file)
        logging.info("file downloaded from url {}".format(d))
    except Exception as e:
        logging.info("Error in writing json data to file; exception {}".format(e))
        
    
    df=pd.read_json(download_dir+'data_file_{}.json'.format(d.strftime(format='%Y%m%d%H%M%S')),orient ='records')
    logging.info("reading json file {}".format(d))
    final_df =''
    try:
        
        final_df = df.Table.values.tolist()
        final_df=pd.DataFrame(final_df)
        final_df['HEADLINE'] = [BeautifulSoup(text,"lxml").get_text() for text in final_df['HEADLINE']]
        final_df['MORE'] = [BeautifulSoup(text,"lxml").get_text() for text in final_df['MORE']]
        print final_df.columns
        try:
            final_df.rename(columns={'Fld_Attachsize':'Fld_attachsize'}, inplace=True)
            final_df.drop(columns=['Fld_attachsize'], inplace=True)
            print len(final_df.columns)
        except Exception as e:
            print e
            print "Column Fld_attachsize not present !"
            logging.info("Column Fld_attachsize not present !")
        
        
        final_df.columns=['AGENDA_ID','ANNOUNCEMENT_TYPE','ATTACHMENTNAME','CATEGORYNAME',
                          'CRITICALNEWS','DT_TM','DissemDT','FILESTATUS','DETAIL',
                          'MORE','NEWSID','TITLE','NEWS_DT','NSURL',
                          'News_submission_dt','OLD','PDFFLAG','QUARTER_ID','RN',
                          'SCRIP_CD','SLONGNAME','TimeDiff','TotalPageCnt','XML_NAME']
        final_df.to_csv(download_dir+"data_scraped{}.csv".format(d.strftime("%d%m%y-%H%M")),encoding="utf-8",index=False)   
        os.remove(download_dir+"data_file_{}.json".format(d.strftime(format='%Y%m%d%H%M%S')))
        logging.info("csv file generted using json data {}".format(len(final_df)))
    except Exception as e:
        logging.error("Error in processing json file; exception {}".format(e))
    return final_df
    

ca_links_df = pd.read_csv(os.path.join(curr_dir, 'master.csv'))[['Scrip Code', 'link']]
    
def send_output_mail(df,d):
    
    file = open(output_dir+"final_bse_output_{}.txt".format(d.strftime(format='%Y%m%d%H%M%S')),"w")
    file.write("<html><head></head></html>")
    
    file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> MAIL TIME: </b>{}</p>".format(d.strftime("%y-%m-%d-%H:%M:%S")))
    file.write("\n\n")
    file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> Dissemation Time: </b>{}</p>".format(df["DissemDT"]))
    file.write("\n\n")
    file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> News Submission Time: </b>{}</p>".format(df["News_submission_dt"]))
    file.write("\n\n")

    file.write("<table  border='1px solid black',border-collapse='collapse'>")
    file.write("<tr><th>Headline</th><th>Details</th></tr>")
    file.write("<tr>")
    file.write("<td><p style='color:black;font-size:14px;font-style:Calibri'>{}</p></td>".format(df["TITLE"]))
#    file.write("\n\n")
    file.write("<td><p style='color:black;font-size:14px;font-style:Calibri'>{}\n\n{}</p></td>".format(df["DETAIL"],df["NSURL"]))
    file.write("</tr>")
    file.write("</table>")
    
    # attach links in the email
    if str(df['ATTACHMENTNAME']).strip()!='':
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> PDF Link: </b><a>{}</a></p>".format(
                                "https://www.bseindia.com/xml-data/corpfiling/AttachLive/"+str(df['ATTACHMENTNAME'])))
        file.write("\n\n")
    
    file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> See on BSE page: </b><a>{}</a></p>".format(
                              ca_links_df[ca_links_df['Scrip Code']==int(df['SCRIP_CD'])]['link'].values[0]))
    file.write("\n\n")
        
    file.close()

    emails = get_contacts(contacts_dir+'corp_actions_anouncement.txt') # read contacts
    subject = "(Research)Corporate Announcement Alert - {0} - {1}".format(df["SCRIP_CD"],df['SLONGNAME'])  #subject
    logging.info('CA email sending for {} , {} ,{}'.format(d,df["SCRIP_CD"],df['SLONGNAME']))

    process_email(emails=emails, subject=subject, html_email=output_dir+"final_bse_output_{}.txt".format(d.strftime(format='%Y%m%d%H%M%S')))
   
    logging.info('Corporate action anouncement email was sent for {0}'.format(d))


def check_similar_value(final_df,d):
      
    if os.path.exists(output_dir+"final_bse_output_{}.csv".format(d.date())):
        try: 
#        print "file exsists in folder"
            logging.info("file exsists for current day  {}".format(d))
    
            final_df=final_df[['DETAIL','TITLE','NSURL','SCRIP_CD','XML_NAME','SLONGNAME','DissemDT','News_submission_dt','ATTACHMENTNAME']]
            old_df=pd.read_csv(output_dir+"final_bse_output_{}.csv".format(d.date()))
            logging.info("contents of old csv file  {}".format(old_df))
    
    #        print "old dataframe",old_df
            newdf=final_df.loc[~final_df["XML_NAME"].isin(old_df["XML_NAME"])]
            logging.info("contents of new df {}".format(newdf))
            old_df=pd.concat([old_df,newdf],axis=0,ignore_index=True)
            old_df.reset_index(drop=True,inplace=True)
            if newdf.empty:
    #            print "No Corporate announcement"
                logging.info("no ca announced")
            else:
    #            print "Corporate announcement"
                logging.info("Bingo: CA announced...")
                old_df.to_csv(output_dir+"final_bse_output_{}.csv".format(d.date()),encoding="utf-8",index=False)
      #          newdf.to_csv(output_dir+"final_bse_output_{}.csv".format(d.strftime(format='%Y%m%d%H%M%S')),encoding="utf-8",index=False)
                logging.info("writing data to csv file")
                for col,row in newdf.iterrows():
                    send_output_mail(row,d)
                    logging.info("ca announced {} {} {} ".format(d,row["SCRIP_CD"],row['SLONGNAME']))
        except Exception as e:
            logging.info("Error in check_similar_values; exception {}".format(e))
    else:
#        print "file dosent exsits"
#        print "generating file"
        try:
            
            final_df=final_df[['DETAIL','TITLE','NSURL','SCRIP_CD','XML_NAME','SLONGNAME','DissemDT','News_submission_dt','ATTACHMENTNAME']]
            final_df.to_csv(output_dir+"final_bse_output_{}.csv".format(d.date()),encoding="utf-8",index=False)
          #  final_df.to_csv(output_dir+"final_bse_output_{}.csv".format(d.strftime(format='%Y%m%d%H%M%S')),encoding="utf-8",index=False)
            logging.info("writing data to csv file for first time for the day")
    #        print "new file generated",final_df
            for col,row in final_df.iterrows():
                send_output_mail(row,d)
                logging.info("sending file for 1st time if not created")
                logging.info("ca announced {} {} {} ".format(d,row["SCRIP_CD"],row["SLONGNAME"]))
        except Exception as e:
            logging.info("Error in creating file for first time CA action; exception {}".format(e))
                
                
                
        
def check_conditions(df,d):
    
    '''
    bse_corp=''
    Special_Keyword=[]; permanent_ignore=[];Details_Keyword=[];Title_Keyword=[]
    try:
        bse_corp=pd.read_csv(os.path.join(curr_dir, 'master.csv'))
        logging.info("Done: File successfully read from network drive")
        
        Special_Keyword=bse_corp["Special Keyword"].dropna()
        Special_Keyword = Special_Keyword.astype(str)
        Special_Keyword = Special_Keyword.apply(lambda x: x.split('.')[0])
        
        permanent_ignore=bse_corp["permanent_ignore"].dropna()
        permanent_ignore = permanent_ignore.astype(str)
        permanent_ignore = permanent_ignore.apply(lambda x: x.split('.')[0])
        print permanent_ignore, len(permanent_ignore)
        
        Details_Keyword=bse_corp["Details_Keyword"].dropna()
        Details_Keyword = Details_Keyword.astype(str)
        Details_Keyword= Details_Keyword.apply(lambda x: x.split('.')[0])
         
        Title_Keyword=bse_corp["Title Keyword"].dropna()
        Title_Keyword = Title_Keyword.astype(str)
        Title_Keyword =Title_Keyword.apply(lambda x: x.split('.')[0])
        
        logging.info("Reading keywords list")
        #logging.info("Permanent_ignore {}".format(permanent_ignore))
        #logging.info("Special_keywords {}".format(Special_Keyword))
        #logging.info("Details_keyword {}".format(Details_Keyword))
        #logging.info("Title_keyword {}".format(Title_Keyword))
    except Exception as e:
        logging.info("error in reading file from network drive; exception {}".format(e))
        
    
    
    df.reset_index(drop=True,inplace=True)
    
    #drop rows with this keyword    
    for i in range(len(permanent_ignore)):
#        print "permanent_ignore",permanent_ignore[i]
        try:
            df["{}".format(permanent_ignore[i])]=df["DETAIL"].str.findall(permanent_ignore[i],flags=re.IGNORECASE)
            
            df["{}".format(permanent_ignore[i])]=df["{}".format(permanent_ignore[i])].str.get(0)
            df=df.loc[~df['{}'.format(permanent_ignore[i])].notnull()]
           # logging.info("keywords permnanetly ignored in DETAIL{}".format(permanent_ignore[i]))
#            df.reset_index(drop=True,inplace=True)
            
            df["{}".format(permanent_ignore[i])]=df["TITLE"].str.findall(permanent_ignore[i],flags=re.IGNORECASE)
            logging.info("processing for permanent ignore keywords")
            df["{}".format(permanent_ignore[i])]=df["{}".format(permanent_ignore[i])].str.get(0)
            df=df.loc[~df['{}'.format(permanent_ignore[i])].notnull()]
            #logging.info("keywords permanantely ignored in TITLE {}".format(permanent_ignore[i]))
#            df.reset_index(drop=True,inplace=True)
        except Exception as e:
            print "Error: in permanent ignore keyword ; exception {}".format(e)
            logging.info("Error: in permanent ignore keyword ; exception {}".format(e))
    
    #special keyword
    s1=pd.DataFrame()
    s2=pd.DataFrame()
    for i in range(len(Special_Keyword)):
#        print "Stocks",Special_Keyword[i]
        try:
            df["{}".format(Special_Keyword[i])]=df["DETAIL"].str.findall(Special_Keyword[i],flags=re.IGNORECASE)
            logging.info("processing for special keywords")
            df["{}".format(Special_Keyword[i])]=df["{}".format(Special_Keyword[i])].str.get(0)
            s1=df
            s1=s1.loc[s1['{}'.format(Special_Keyword[i])].notnull()]
            s1.reset_index(drop=True,inplace=True)
            check_similar_value(s1,d,'SPECIAL KEYWORD',Special_Keyword[i])
            
            df["{}".format(Special_Keyword[i])]=df["TITLE"].str.findall(Special_Keyword[i],flags=re.IGNORECASE)
            logging.info("processing for special keywords")
            df["{}".format(Special_Keyword[i])]=df["{}".format(Special_Keyword[i])].str.get(0)
            s2=df
            s2=s2.loc[s2['{}'.format(Special_Keyword[i])].notnull()]
            s2.reset_index(drop=True,inplace=True)
            check_similar_value(s2,d,'SPECIAL KEYWORD',Special_Keyword[i])
        except Exception as e:
            print "Error in special keyword; exception {}".format(e)
            logging.info("Error in special keyword; exception {}".format(e))
    
    '''
    
    bse_corp=pd.read_csv(os.path.join(curr_dir, 'master.csv'))
    df=df.loc[df["SCRIP_CD"].isin(bse_corp["Scrip Code"])]
    logging.info("filter on IT stocks")
    df.reset_index(drop=True,inplace=True)
    
    # check if new and send email 
    check_similar_value(df,d)
    
    
#    FO_Stocks=bse_corp["FO Stocks"].dropna()

#    to get data and dump in our excel file date wise
    if os.path.exists(download_dir+'datacollection_fnostock_{}.csv'.format(d.date())):
        old_df=pd.read_csv(download_dir+'datacollection_fnostock_{}.csv'.format(d.date()))
        newdf=df.loc[~df["XML_NAME"].isin(old_df["XML_NAME"])]
        old_df=pd.concat([old_df,newdf],axis=0,ignore_index=True)
        old_df.reset_index(drop=True,inplace=True)    
        old_df.to_csv(download_dir+"datacollection_fnostock_{}.csv".format(d.date()),encoding="utf-8",index=False)
        logging.info("done Data collection fnostock")
    else:
        df.to_csv(download_dir+"datacollection_fnostock_{}.csv".format(d.date()),encoding="utf-8",index=False)
        logging.info("done created new Data collection fnostock")
    
    '''
    #processing for details
    l1=pd.DataFrame()
    for i in range(len(Details_Keyword)):
#        print "Details_Keyword",Details_Keyword[i]
        try:            
            df["{}".format(Details_Keyword[i])]=df["DETAIL"].str.findall(Details_Keyword[i],flags=re.IGNORECASE)
            logging.info("processing for Details keywords")
            df["{}".format(Details_Keyword[i])]=df["{}".format(Details_Keyword[i])].str.get(0)
            l1=df
            l1=l1.loc[l1['{}'.format(Details_Keyword[i])].notnull()]
            l1.reset_index(drop=True,inplace=True)
            check_similar_value(l1,d,'DETAIL',Details_Keyword[i])
        except Exception as e:
            logging.info("Error in details keyword: exception as {}".format(e))
            
            
    
    df.reset_index(drop=True,inplace=True)
    #processing for title
    l2=pd.DataFrame()
    for i in range(len(Title_Keyword)):
#        print "Title_Keyword",Title_Keyword[i]
        try:
            
            df["{}".format(Title_Keyword[i])]=df["TITLE"].str.findall(Title_Keyword[i],flags=re.IGNORECASE)
            logging.info("processing for  title keywords")
            df["{}".format(Title_Keyword[i])]=df["{}".format(Title_Keyword[i])].str.get(0)
            l2=df
            l2=l1.loc[l2['{}'.format(Title_Keyword[i])].notnull()]
            l2.reset_index(drop=True,inplace=True)
            check_similar_value(l2,d,'TITLE',Title_Keyword[i])
        except Exception as e:
            logging.info("Error in title keyword: exception as {}".format(e))
     
   '''
  


def process_running(d):
    
    try:
        logging.info("Email: Hourly process running check")    
        file = open(output_dir+"final_bse_output_{}.txt".format(d.strftime('%H')),"w")
        file.write("<html><head></head></html>")    
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'><b> Corporate Action Announcement hourly status: </b></p>")
        file.write("\n\n")
        file.write("<p style='color:black;font-size:14px;font-style:Calibri'>process is running succesfully {}</p>".format(d.strftime("%y-%m-%d-%H:%M:%S")))
        file.write("\n\n")
        file.close()
        logging.info("Output txt for hourly status email compiled successfully")
    except Exception as e :
        logging.info("I/O Error in Output txt for hourly status email; exception / {} ".format(e))
        
    try:
        logging.info("Send hourly status email")
        emails = get_contacts(contacts_dir+'checker_corp_action.txt') # read contacts
        subject = "Corporate Announcement (Research) running Alert - {0} ".format(d.strftime("%y-%m-%d-%H:%M:%S"))  #subject    
        process_email(emails=emails, subject=subject, html_email=output_dir+"final_bse_output_{}.txt".format(d.strftime("%H")))
   
        logging.info('Corporate action anouncement process running email was sent for {0}'.format(d))
    except Exception as e:
        logging.info("Error in sending email ; exception {}".format(e))

      
def delete_log_files():
    
    files = pd.DataFrame(glob.glob(log_dir+'*.log'))  # find .log files 
    try:
        files['date'] = files[0].apply(lambda x: datetime.datetime.strptime(re.search(r'\d{4}-\d{2}-\d{2}', x).group(),
                                               '%Y-%m-%d').date())  # extract date from filename
        files.sort_values(by=['date'], ascending=False, inplace=True)
        files = files.iloc[3: , :]
    except Exception as e:
        print e
        
    if files.empty!=True:
        for f in files.iterrows():
            try:
                os.remove(f[0])
            except Exception as e:
                logging.error("log file deletion error: {} \n {}".format(e, f[0]))
    
    
    
        
def main():
    
    
    d=datetime.datetime.now()
    logging.info("Start process: {}".format(d))
#    if process_run_check(d.date()) == -1:
#        return -1 
    delete_log_files()
    dt="23:00:00"
    try:
        
        while d.strftime("%H:%M:%S")<dt: 
            try:                
                print "While iteration {}".format(d)
                logging.info("While iteration {}".format(d))
                if d.strftime("%H:%M:%S")>="22:55:00":
                    logging.info("Remove files from the output dir after 11 PM ")
                    files = glob.glob(output_dir+'*.txt')  # find .txt files in output dir and list them
                      
                    for f in files:
                        os.remove(f)  # remove all .txt files from the list 
                    logging.info("deleting text files from output directory")    
                    files1=glob.glob(download_dir+'*.csv')
                    for f in files1:
                        os.remove(f)
                    logging.info("deleting csv files from output directory")  
                        
                        
                    logging.info("Shutting down the process")
                    logging.info("End process: {}".format(datetime.datetime.now()))
                    
                    logging.info("End of the day; process shutdown")
                    emails = get_contacts(contacts_dir+'checker_corp_action.txt') # read contacts
                    subject = "End of the day: Corporate Announcement (Research) {}".format(d.strftime("%y-%m-%d-%H:%M:%S"))  #subject    
                    process_email(emails=emails, subject=subject, text_email="Corporate Announcement Process EOD ! ")
                                       
                    import sys; sys.exit()
                
                if os.path.exists(output_dir+"final_bse_output_{}.txt".format(d.strftime("%H"))):
                    logging.info("Done: program running perfectly")
                else:
                    process_running(d)
                    logging.info("Done: hourly alert email sent; program is running")
                logging.info("Call to get_data function ")
                final_df=get_data(d)  # get json data from links
                if isinstance(final_df, pd.DataFrame):
                    logging.info("Done: get_data function executed successfully ")
                    logging.info("Check for keyword conditions and send email ; call to check_conditions functions")
                    check_conditions(final_df,d)  # if keyword Ca found; send email       
                else:
                    print "Data recieved empty from the exchange"
                    logging.info("Data recieved empty from the exchange")           
                
                logging.info("Sleep for 1 min; current time {}".format(d)) 
                print "Sleep for 1 min; current time {}".format(d)
                time.sleep(60)
                d=datetime.datetime.now()
            except Exception as e:
                logging.info("Process level error")
        else:
            logging.info("While loop ending: End process: {}".format(datetime.datetime.now()))
            logging.info("End of the day; process shutdown")
            emails = get_contacts(contacts_dir+'checker_corp_action.txt') # read contacts
            subject = "End of the day: Corporate Announcement (Research) {}".format(d.strftime("%y-%m-%d-%H:%M:%S"))  #subject    
            process_email(emails=emails, subject=subject, text_email="Corporate Announcement (Research) EOD ! ")
       

    except Exception as e:
        logging.info("Apocalypse; sending an email regarding shutdown; exception ".format(e))
        emails = get_contacts(contacts_dir+'checker_corp_action.txt') # read contacts
        subject = "SHUTDOWN: Corporate Announcement (Research)".format(d.strftime("%y-%m-%d-%H:%M:%S"))  #subject    
        process_email(emails=emails, subject=subject, text_email="Corporate Announcement (Research) shutdown !!!!!!!!! \n\n PLEASE ALERT !!!")
   
        

main()