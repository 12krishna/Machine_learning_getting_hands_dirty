# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 09:12:47 2019

@author: Administrator
"""

import subprocess

def process_exists(process_name):
    #call = 'TASKLIST', '/v /FI', 'username eq %s' % process_name
    #call = 'TASKLIST', '/v /FI', 'Windowtitle eq %s' % 'FNOBhavcopy'
    call = 'TASKLIST /v /fi "username eq administrator"'
    # use buildin check_output right away
    output = subprocess.check_output(call)
    # check in last line for process name
    last_line = output.strip().split('\r\n')[-1]
    # because Fail message could be translated
    return last_line.lower().startswith(process_name).lower()

process_exists("notepad.exe")