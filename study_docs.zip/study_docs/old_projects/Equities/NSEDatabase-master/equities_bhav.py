#Copyright (c) 2017 Chinmay Hundekari
#See the file license.txt for copying permission.

import urllib2
import datetime
from dateutil.relativedelta import relativedelta
import requests
import httplib, StringIO, zipfile
import os
import sys
import shutil
from dateutil import parser
from dateutil import parser
import pandas as pd
import time 


download_dir = "D:\\Equities\\Download\\"

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date


class nseConnect:
    headers = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
               'Accept':'application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5',
               'Accept-Encoding':'gzip,deflate,sdch',
               'Referer':'http://www.nseindia.com/archives/archives.htm'}
    url = "www.nseindia.com"

    def connect(self):
        response = requests.head('http://' + self.url)
        if response.status_code == 302:
            self.url = response.headers["Location"]
        isHttps = self.url.find("https") > -1
        self.url = self.url[self.url.find("//")+2:self.url.rfind("/")]
        if isHttps:
            self.conn = httplib.HTTPSConnection(self.url)
        else:
            self.conn = httplib.HTTPConnection(self.url)

    def disconnect(self):
        self.conn.close()

    def getFilename(self, date):
        [y, m, d] = self.convertDate(date)
        return "cm%s%s%sbhav.csv" % (d, m, y)

    def convertDate(self, date):
        y = date.strftime("%Y")
        m = date.strftime("%b").upper()
        d = date.strftime("%d")
        return [y, m, d]

    def getReqStr(self, date):
        [y, m, d] = self.convertDate(date)
        return "/content/historical/EQUITIES/%s/%s/%s.zip" % (y, m, self.getFilename(date))

    def getResponse(self, reqstr):
        c = self.conn
        c.request("GET", reqstr, None, self.headers)
        response = c.getresponse()
        self.data = response.read()
        return response.status

def downloadCSV(c, d):
    
    
    filename = c.getFilename(d)
    reqstr = c.getReqStr(d)

    print "Downloading %s ..." % (filename)
    # read holiday master
    holiday_master = pd.read_csv(os.path.join(os.getcwd(), 'Holidays_2019.txt'), delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
    
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        responsecode = c.getResponse(reqstr) 
        while responsecode!= 200:
            # sleep for 2 min
            time.sleep(120)
            
            responsecode = c.getResponse(reqstr)
    elif len(holiday_master[holiday_master['date']==d])==1:
        return -1 
    
    
    
    sdata = StringIO.StringIO(c.data)
    z = zipfile.ZipFile(sdata)
    try:
        csv = z.read(z.namelist()[0])
    except Exception as e:
        print "%s" % (format(e))
        return -1
    if not csv:
        print "Could not download %s." % (e.message)
        return -1
    else:
        if not os.path.exists("data"):
            os.makedirs("data")
        fil = open(os.path.join("data",filename), 'w')
        fil.write(csv)
        fil.close()
        
        #move to downlaod_dir
        shutil.copy(os.path.join("data",filename), download_dir+filename )
        return 1

def downloadCSVDate(c, date):
    [y, m, d] = convertDate(date)
    return downloadCSV(c, y, m, d)

def getUpdate(c):
    errContinous = 0
    d = datetime.date.today()
    decr = datetime.timedelta(days=1)
    while errContinous > -30 and (not os.path.exists(os.path.join("data",c.getFilename(d)))):
        if d == parser.parse('2016 01 01').date():
            break
        if downloadCSV(c, d) > -1:
            errContinous = 0
        else:
            errContinous -= 1
        d -= decr


def main(args):
    c = nseConnect()
    c.connect()
    if args:
        if args[0] == "-update":
            getUpdate(c)
        
    c.disconnect()

if __name__ == "__main__":
    main(sys.argv[1:])
