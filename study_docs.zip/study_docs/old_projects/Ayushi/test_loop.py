# -*- coding: utf-8 -*-
"""
Created on Tue Dec 18 12:33:26 2018

@author: Administrator
"""

import pandas as pd
from datetime import datetime
import logging
from cassandra.cluster import Cluster
from time import time
colnames=["Identifer","Client","Symbol","Series","BloomCode","OrderType","Price","Side","Exchange","StartTime","EndTime","OrderQty","SOR","QuantityExecuted","AvgPx","NSEExecuted","BSEExecuted","NSEAvgPx","BSEAvgPx","IntervalVwap","IntervalTwap","IntervalVwapNse","IntervalVwapBse","IntervalTwapNse","IntervalTwapBse","IntervalVwapLimit","IntervalTwapLimit","IntervalVwapLimitNse","IntervalTwapLimitBse","IntervalTwapLimitNse","IntervalTwapLimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse","IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse","DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse","volExecBse_intervalVolBse","volExec_intervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse","volExec_intervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse","volExec_DayVol","volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_DayVolLimit","DayVwap", "DayTwap","DayVwapNse","DayVwapBse","DayTwapNse","DayTwapBse","PwpNse","PwpBse","Pwp","PwpLimit","PwpLimitNse","PwpLimitBse","ArrivalPriceNse","ArrivalPriceBse","ArrivalPrice","avgPx_vwap","avgPx_twap","avgPx_vwapLimit","avgPx_twapLimit","avgPx_pwp","avgPx_pwpLimit","avgPx_arrivalPx"]
inputcolnames=["Identifer","Client","Symbol","Series","BloomCode","OrderType","Price","Side","Exchange","StartTime","EndTime","OrderQty","SOR","QuantityExecuted","AvgPx","NSEExecuted","BSEExecuted","NSEAvgPx","BSEAvgPx"]
#orderpath contains the path of the order file
orderpath="D:\\Ayushi\\Input\\"
log_path = "D:\\Ayushi\\Logs\\"
market_start="09:15:00"
market_end="15:30:00"
#outpath contains the path of where the new order file with calclated parameters has to be stored 
outpath="D:\\Ayushi\\Output\\"
#for fetching data from cassandra put flag=1
flag=1
order=pd.read_csv(orderpath+'orders_ets.csv',names=inputcolnames,header=0)
# log events in debug mode 
logging.basicConfig(filename=log_path+"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

for index,row in order.iterrows():
        logging.info('Getting price volume data to calculate parameters...')
        print row;
        row["test"] = 1
        