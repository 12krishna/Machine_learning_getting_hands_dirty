import pandas as pd
from datetime import datetime
import logging
from cassandra.cluster import Cluster
from time import time
colnames=["Identifer","Client","Symbol","Series","BloomCode","OrderType","Price","Side","Exchange","StartTime","EndTime","OrderQty","SOR","QuantityExecuted","AvgPx","NSEExecuted","BSEExecuted","NSEAvgPx","BSEAvgPx","IntervalVwap","IntervalTwap","IntervalVwapNse","IntervalVwapBse","IntervalTwapNse","IntervalTwapBse","IntervalVwapLimit","IntervalTwapLimit","IntervalVwapLimitNse","IntervalTwapLimitBse","IntervalTwapLimitNse","IntervalTwapLimitBse","AvgTradeSizeNse","AvgTradeSizeBse","AvgTradeSize","IntervalVolNse","IntervalVolBse","IntervalVol","IntervalVolLimitNse","IntervalVolLimitBse","IntervalVolLimit","DayVolNse","DayVolBse","DayVol","DayVolLimitNse","DayVolLimitBse","DayVolLimit","volExecNse_intervalVolNse","volExecBse_intervalVolBse","volExec_intervalVol","volExecNse_intervalVolLimitNse","volExecBse_intervalVolLimitBse","volExec_intervalVolLimit","volExecNse_DayVolNse","volExecBse_DayVolBse","volExec_DayVol","volExecNse_DayVolLimitNse","volExecBse_DayVolLimitBse","volExec_DayVolLimit","DayVwap", "DayTwap","DayVwapNse","DayVwapBse","DayTwapNse","DayTwapBse","PwpNse","PwpBse","Pwp","PwpLimit","PwpLimitNse","PwpLimitBse","ArrivalPriceNse","ArrivalPriceBse","ArrivalPrice","avgPx_vwap","avgPx_twap","avgPx_vwapLimit","avgPx_twapLimit","avgPx_pwp","avgPx_pwpLimit","avgPx_arrivalPx"]
inputcolnames=["Identifer","Client","Symbol","Series","BloomCode","OrderType","Price","Side","Exchange","StartTime","EndTime","OrderQty","SOR","QuantityExecuted","AvgPx","NSEExecuted","BSEExecuted","NSEAvgPx","BSEAvgPx"]
#orderpath contains the path of the order file
orderpath="D:\\Ayushi\\Input\\"
log_path = "D:\\Ayushi\\Logs\\"
market_start="09:15:00"
market_end="15:30:00"
#outpath contains the path of where the new order file with calclated parameters has to be stored 
outpath="D:\\Ayushi\\Output\\"
#for fetching data from cassandra put flag=1
flag=1
order=pd.read_csv(orderpath+'orders_ets.csv',names=inputcolnames,header=0)
# log events in debug mode 
logging.basicConfig(filename=log_path +"test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

#function to extract startTime,endTime and Date in seperate date and time format from dateTime format
def timeformat(start,end):
    
    #start=start.astype(str)
    logging.info('Date time conversion to a well-defined format...')
    startTime=pd.to_datetime(start, format='%Y %m %d %H:%M:%S')
    d=startTime.date()
    
    startTime=datetime.time(startTime)
    endTime=pd.to_datetime(end,format='%Y %m %d %H:%M:%S') 
    endTime=datetime.time(endTime)
    
    return(startTime,endTime,d)
#function to filter the data within startTime and endTime passed as parameters
def filterTime(startTime,endTime,symbol,df):
#call to timeformat function to get date and time seperately
    a=timeformat(startTime,endTime)
    start=a[0]
    end=a[1]
    d=a[2]
    logging.info('Filtering data within startTime and endTime...')
    df_f = df.loc[df["symbol"]==symbol]
    df_f['date'] = df_f.loc[:,'date'].astype(str)
    df_f['date'] = pd.to_datetime(df_f.loc[:,'date'],format='%Y %m %d %H:%M:%S')
    df_f['date'] = df_f.apply(lambda row: row['date'].date(),axis=1)
    logging.info('Filtering data of a particular dated order...')
    df_f = df_f[df_f.date==d]
    
    df_f['time'] = df_f['time'].map(lambda x: str(x)[:-10])
    df_f['time'] = df_f['time'].astype(str)
    df_f['time'] = pd.to_datetime(df_f['time'],format='%H:%M:%S')
    df_f['time']=df_f['time'].apply(datetime.time)
    logging.info('Filtering data within a particular time interval...')
    df_f=df_f[(df_f['time']>=start) & (df_f['time']<=end)]
    #print(df_f.tail(5))
    return(df_f)
    #function to calculate vwap of the dataframe data passed
def calcvwap(df):
    if df.empty:
        vwap=0.0
    else:
        try:
                vwap=(df["price"]*df["volume"]).sum()/df["volume"].sum()
        except(df["volume"].sum()==0.0):
                vwap=0.0
    return(vwap)
#function to calculate twap of the df passed
def calctwap(df):
    if df.empty:
        twap=0.0
    else:
        try:
            twap=df["price"].sum()/df.shape[0]
        except(df.shape[0]==0):
            twap=0.0
    return(twap)
#function to calculate overall vwap   
def vwap(symbol,startTime,endTime,l,limit,side,df):
    logging.info('Call to the function for filtering the time in a particular interval')
    if df.empty:
        vwap=0.0
    else:
        df_f=filterTime(startTime,endTime,symbol,df)
        vwap=calcvwap(df_f)
    return(vwap)
#function to calculate overall twap  
def twap(symbol,startTime,endTime,l,limit,side,df):
    if df.empty:
        twap=0.0
    else:
        df_f=filterTime(startTime,endTime,symbol,df)
        twap=calctwap(df_f)
    return(twap)
#function to calculate vwap of NSE data      
def vwapNse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:    
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IS"]
        vwapNse=calcvwap(dfEx)
    else:
        vwapNse=0.0
        
    return(vwapNse)
#function to calculate twap of NSE data        
def twapNse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty: 
        df_f=filterTime(startTime,endTime,symbol,df)
        if not df_f.empty:
            dfEx=df_f[df_f.exchange=="IS"]
            twapNse=calctwap(dfEx)
        else:
            twapNse=0.0
    else:
        twapNse=0.0
    return(twapNse)
#function to calculate twap of BSE data      
def twapBse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        if not df_f.empty:  
            dfEx=df_f[df_f.exchange=="IB"]
            twapBse=calctwap(dfEx)
        else:
            twapBse=0.0
    else:
        twapBse=0.0
    return(twapBse)
#function to calculate vwap of BSE data  
def vwapBse(symbol,startTime,endTime,l,limit,side,df):
    logging.info("Vwap for Bse....")
    if not df.empty:  
        df_f=filterTime(startTime,endTime,symbol,df)
        if not df_f.empty:   
            dfEx=df_f[df_f.exchange=="IB"]
            vwapBse=calcvwap(dfEx)
        else:
            vwapBse=0.0
    else:
        vwapBse=0.0
    return(vwapBse)
#function to calculate overall volume  
def vol(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        if df_f.empty:
            vol=0.0
        else:
            vol=df_f["volume"].sum()
    else:
        vol=0.0
    return(vol)
#funvtion to calculate volume of NSE data
def volNse(symbol,startTime,endTime,l,limit,side,df):
    if df.empty:
        vol=0.0
    else:
        
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IS"]
        if dfEx.empty:
            vol=0.0
        else:
            vol=dfEx["volume"].sum()
    return(vol)
#function to calculate volume of BSE data
def volBse(symbol,startTime,endTime,l,limit,side,df):
    if df.empty:
        vol=0.0
    else:
        
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IB"]
        if dfEx.empty:
            vol=0.0
        else:
            vol=dfEx["volume"].sum()
    return(vol)
#function to calculate overall PWP20
def pwp(pwpPara,symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        s=df_f
        s["cum_vol"]=pd.Series(df_f.index)
        s["cum_vol"]=df_f.volume.cumsum()
        logging.info("Filtering the dataframe for PWP20 and calculating parameters vwap,twap....")
        s=s.loc[s["cum_vol"]<=pwpPara]
        vwap_pwp=calcvwap(s)
    else:
        vwap_pwp=0.0
    return(vwap_pwp)
#function to return PWP20 for NSE data
def pwpNse(pwpPara,symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f.loc[df_f.exchange=="IS"]
        s=dfEx
        if not s.empty:
            s["cum_vol"]=pd.Series(dfEx.index)
            s["cum_vol"]=dfEx.volume.cumsum()
            logging.info("Filtering the dataframe for PWP20 and calculating parameters vwap,twap....")
            s=s.loc[s["cum_vol"]<=pwpPara]
            vwap_pwpNse=calcvwap(s)
        else:
            vwap_pwpNse=0.0
    else:
        vwap_pwpNse=0.0
    return(vwap_pwpNse)
#function to return PWP20 for BSE data
def pwpBse(pwpPara,symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f.loc[df_f.exchange=="IB"]
        s=dfEx
        if not s.empty:
            s["cum_vol"]=pd.Series(dfEx.index)
            s["cum_vol"]=dfEx.volume.cumsum()
            logging.info("Filtering the dataframe for PWP20 and calculating parameters vwap,twap....")
            s=s.loc[s["cum_vol"]<=pwpPara]
            vwap_pwpBse=calcvwap(s)
        else:
            vwap_pwpBse=0.0
    else:
        vwap_pwpBse=0.0
    return(vwap_pwpBse)
def ltp(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        if df_f.empty:
            ltp=0.0
        else:
            ltp_df=df_f.tail(1)
            ltp=ltp_df.iloc[0]["price"]
            #print("fughj",ltp)
    else:
        ltp=0.0
    return(ltp)
#function to return arrival price of NSE data
def ltpNse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IS"]
        if dfEx.empty:
            ltp=0.0
        else:
            ltp_df=dfEx.tail(1)
            ltp=ltp_df.iloc[0]["price"]
            #print("ltpNse",ltp)
            #print("type",type(ltp))
    else:
        ltp=0.0
    return(ltp)
#function to return arrival price of BSE data
def ltpBse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IB"]
        if dfEx.empty:
            ltp=0.0
        else:
            ltp_df=dfEx.tail(1)
            ltp=ltp_df.iloc[0]["price"]
    else:
        ltp=0.0
    return(ltp)
def averageTradeSize(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        if df_f.empty:
            AvgTradeSize=0.0
        else:
            try:
                AvgTradeSize=df_f["volume"].sum()/df_f.shape[0]
            except(df_f.shape[0]==0):
                AvgTradeSize=0.0
    else:
        AvgTradeSize=0.0
    return(AvgTradeSize)
def averageTradeSizeNse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
            
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IS"]
        if dfEx.empty:
            AvgTradeSize=0.0
        else:
            try:
                AvgTradeSize=dfEx["volume"].sum()/dfEx.shape[0]
            except(dfEx.shape[0]==0):
                AvgTradeSize=0.0
    else:
        AvgTradeSize=0.0
    return(AvgTradeSize)
def averageTradeSizeBse(symbol,startTime,endTime,l,limit,side,df):
    if not df.empty:
        df_f=filterTime(startTime,endTime,symbol,df)
        dfEx=df_f[df_f.exchange=="IB"]
        if dfEx.empty:
            AvgTradeSize=0.0
        else:
            try:
                AvgTradeSize=dfEx["volume"].sum()/dfEx.shape[0]
            except(dfEx.shape[0]==0):
                AvgTradeSize=0.0
    else:
        AvgTradeSize=0.0
    return(AvgTradeSize)
#function to read the data from cassandra(if flag=1) or from the file(if flag=0)
def getData(session,exchange,symbol,order_date):
    query='SELECT * FROM quotedata WHERE token(exchange,date)=token(\'{1}\',\'{2}\') and symbol=\'{0}\' ALLOW FILTERING;'.format(symbol,exchange,order_date)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    return(rows)
#define rows fetched from cassandra to be a pandas dataframe
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)
def main(flag,outpath,market_start,market_end):
    result = pd.DataFrame()  
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
# =============================================================================
    cluster = Cluster(['172.17.9.152'])
    logging.info('Cassandra Cluster connected...')
    session = cluster.connect('rohit')
    # connect to your keyspace and create a session using which u can execute cql commands 
    logging.info('Using test_df keyspace')
    session.row_factory = pandas_factory
    session.default_fetch_size = None 
# =============================================================================
    for index,row in order.iterrows():
        logging.info('Getting price volume data to calculate parameters...')
        startTime=pd.to_datetime(row["StartTime"], format='%Y %m %d %H:%M:%S')
        #Extracting the date of the order
        d=startTime.date()
        d=d.strftime('%Y-%m-%d')
        if flag==0:
            colnames=['symbol','exchange','date','time','type','price','volume']
            data="D:\\Projects\\Input\\"
            df=pd.read_csv(data+"data.csv",names=colnames)
        else:
            logging.info("Get data from cassandra in dataframe format...")
            if row["SOR"]=="Y":
            #If SOR is 'Y' fetching both NSE and BSE data from cassandra
            #read bloomberg data from cassandra or file depending value of flag passed in the parameter
                df_Nse=getData(session,"IS",row["Symbol"],d)
                df_Bse=getData(session,"IB",row["Symbol"],d)
                frames=[df_Nse,df_Bse]
                df=pd.concat(frames)
            #If SOR is 'N' and  NSE order fetching NSE data from cassandra
            elif row["SOR"]=="N" and row["Exchange"]=="NSE":
                df_Nse=getData(session,"IS",row["Symbol"],d)
                df_Bse=None
                df=df_Nse
            #If SOR is 'N' and  BSE order fetching BSE data from cassandra
            elif row["SOR"]=="N" and row["Exchange"]=="BSE":
                df_Bse=getData(session,"IB",row["Symbol"],d)
                df_Nse=None
                df=df_Bse
        #t1, t2 stores the starting time and closing time of the market on the day of order to calculate days vwap,twap etc
        t1=d+" "+market_start
        t2=d+" "+market_end
        #pwpPara is the parameter for calculating PWP20
        pwpPara=row["QuantityExecuted"]*5
        if df.empty:
            logging.info("DataFile is Empty...")
            print("no data present")
        else:
            #calculating all the parameters and storing them in the respective variables
            IntervalVolNse=volNse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            IntervalVolBse=volBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            IntervalVwap=vwap(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            IntervalTwap=twap(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            IntervalVwapBse=vwapBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            IntervalVwapNse=vwapNse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            IntervalTwapNse=twapNse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            IntervalTwapBse=twapBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            PwpNse=pwpNse(pwpPara,row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            PwpBse=pwpBse(pwpPara,row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            Pwp=pwp(pwpPara,row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            DayVol=vol(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],df)
            DayVolNse=volNse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],df)
            DayVolBse=volBse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],df)
            DayVwapNse=vwapNse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],df)
            DayVwapBse=vwapBse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],df)
            DayTwapNse=twapNse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],df)
            DayTwapBse=twapBse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],df)
            DayVwap=vwap(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],df)
            DayTwap=twap(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],df)
            IntervalVol=vol(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
            #print("Symbol is",row["Symbol"])
            #calculating all the limit adjucted parameter by filtering the dataframe within limit
            if(row["OrderType"]=="LMT"):
                if row["Side"]=="BUY":
                    dfInLimit=df.loc[df['price']<=row["Price"]]
                else:
                    dfInLimit=df.loc[df['price']>=row["Price"]]
                IntervalVolLimitNse=volNse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                IntervalVolLimitBse=volBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                IntervalVwapLimit=vwap(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                IntervalTwapLimit=twap(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                IntervalVwapLimitNse=vwapNse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                IntervalVwapLimitBse=vwapBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                IntervalTwapLimitNse=twapNse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                IntervalTwapLimitBse=twapBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                DayVolLimitNse=volNse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],dfInLimit)
                DayVolLimitBse=volBse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],dfInLimit)
                DayVolLimit=vol(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],dfInLimit)
                DayVwapLimitNse=vwapNse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],dfInLimit)
                DayVwapLimitBse=vwapBse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],dfInLimit)
                DayTwapLimitNse=twapNse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],dfInLimit)
                DayTwapLimitBse=twapBse(row["Symbol"],t1,t2,row["OrderType"],row["Price"],row["Side"],dfInLimit)
                PwpLimit=pwp(pwpPara,row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                PwpLimitNse=pwpNse(pwpPara,row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                PwpLimitBse=pwpBse(pwpPara,row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                AvgTradeSizeNse=averageTradeSizeNse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                AvgTradeSizeBse=averageTradeSizeBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                ArrivalPriceNse=ltpNse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                ArrivalPriceBse=ltpBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                ArrivalPrice=ltp(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                AvgTradeSize=averageTradeSize(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                IntervalVolLimit=vol(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],dfInLimit)
                #If order type is market order then else condition works and limit adjusted parameters will be equal to interval parameters
            else:
                IntervalVolLimitNse=IntervalVolNse
                IntervalVolLimitBse=IntervalVolBse
                IntervalVwapLimitNse=IntervalVwapNse
                IntervalVwapLimitBse=IntervalVwapBse
                IntervalTwapLimitNse=IntervalTwapNse
                IntervalTwapLimitBse=IntervalTwapBse
                IntervalVwapLimit=IntervalVwap
                IntervalTwapLimit=IntervalTwap
                DayVolLimitNse=DayVolNse
                DayVolLimitBse=DayVolBse
                DayVolLimit=DayVol
                DayVwapLimitNse=DayVwapNse
                DayVwapLimitBse=DayVwapBse
                DayTwapLimitNse=DayTwapNse
                DayTwapLimitBse=DayTwapBse
                PwpLimitNse=PwpNse
                PwpLimitBse=PwpBse
                PwpLimit=Pwp
                AvgTradeSizeNse=averageTradeSizeNse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
                AvgTradeSizeBse=averageTradeSizeBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
                ArrivalPriceNse=ltpNse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
                ArrivalPriceBse=ltpBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
                ArrivalPrice=ltp(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
                AvgTradeSize=averageTradeSize(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)
                IntervalVolLimit=IntervalVol
                #if SOR 'Y' then giving both the NSE and BSE parameters values calculated above  
            if(row["SOR"]=="Y"):
                row["IntervalVolNse"]=IntervalVolNse
                row["IntervalVwapNse"]=IntervalVwapNse
                row["IntervalTwapNse"]=IntervalTwapNse
                row["Arrival PriceNse"]=ArrivalPriceNse
                row["PwpNse"]=PwpNse
                row["IntervalVolLimitNse"]=IntervalVolLimitNse
                row["IntervalVolLimitBse"]=IntervalVolLimitBse
                row["IntervalVolBse"]=IntervalVolBse
                row["IntervalVwapBse"]=IntervalVwapBse
                
                row["IntervalTwapBse"]=IntervalTwapBse
                row["Arrival PriceNse"]=ArrivalPriceNse
                row["AvgTradeSizeNse"]=AvgTradeSizeNse
                row["AvgTradeSizeBse"]=AvgTradeSizeBse
                row["Arrival PriceBse"]=ArrivalPriceBse
                row["IntervalVwapLimitNse"]=IntervalVwapLimitNse
                row["IntervalVwapLimitBse"]=IntervalVwapLimitBse
                row["IntervalTwapLimitNse"]=IntervalTwapLimitNse
                row["IntervalTwapLimitBse"]=IntervalTwapLimitBse
                #if SOR 'N' and order exchange is NSE then giving NSE parameters values calculated above  
            elif(row["SOR"]=="N" and df.loc[df["exchange"]=="IS"].shape[0]>0 and (row["Exchange"]=="NSE")):
                row["IntervalVolNse"]=IntervalVolNse
                row["IntervalVolLimitNse"]=IntervalVolLimitNse
                row["AvgTradeSizeNse"]=AvgTradeSizeNse
                row["IntervalVwapNse"]=IntervalVwapNse
                row["IntervalTwapNse"]=IntervalTwapNse
                row["Arrival PriceNse"]=ArrivalPriceNse
                row["IntervalVwapLimitNse"]=IntervalVwapLimitNse
                row["IntervalTwapLimitNse"]=IntervalTwapLimitNse
                #if SOR 'N' and order exchange is BSE then giving BSE parameters values calculated above  
            elif(row["SOR"]=="N" and df.loc[df["exchange"]=="IB"].shape[0]>0 and (row["Exchange"]=="BSE")):
                row["IntervalVolBse"]=IntervalVolBse
                row["IntervalVolLimitBse"]=IntervalVolLimitBse
                row["AvgTradeSizeBse"]=AvgTradeSizeBse
                row["IntervalTwapBse"]=IntervalTwapBse
                row["IntervalVwapBse"]=vwapBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)[0]
                row["IntervalVwapLimitBse"]=vwapBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)[3]
                row["IntervalTwapLimitBse"]=twapBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)[3]
                row["Arrival PriceBse"]=vwapBse(row["Symbol"],row["StartTime"],row["EndTime"],row["OrderType"],row["Price"],row["Side"],df)[1]
            #storing parameters in order file column  which will be present irrespective of SOR value
            row["IntervalVwap"]=IntervalVwap
            row["IntervalVwapLimit"]=IntervalVwapLimit
            row["IntervalTwapLimit"]=IntervalTwapLimit
            row["IntervalTwap"]=IntervalTwap
            row["IntervalVolLimit"]=IntervalVolLimit
            row["IntervalVol"]=IntervalVol
            row["AvgTradeSize"]=AvgTradeSize
            row["ArrivalPrice"]=ArrivalPrice
            row["DayVolLimitNse"]=DayVolLimitNse
            row["DayVolLimitBse"]=DayVolLimitBse
            row["DayVolLimit"]=DayVolLimit
            row["PwpBse"]=PwpBse
            row["Pwp"]=Pwp
            row["PwpLimit"]=PwpLimit
            row["PwpLimitNse"]=PwpLimitNse
            row["PwpLimitBse"]=PwpLimitBse
            row["DayVwap"]=DayVwap
            row["DayTwap"]=DayTwap
            row["DayVwapNse"]=DayVwapNse
            row["DayVwapBse"]=DayVwapBse
            row["DayTwapNse"]=DayTwapNse
            row["DayTwapBse"]=DayTwapBse
            row["DayVwapLimitNse"]=DayVwapLimitNse
            row["DayVolLimit"]=DayVolLimit
            row["DayVol"]=DayVol
            row["DayVolNse"]=DayVolNse
            row["DayVolBse"]=DayVolBse
            row["DayVwapLimitBse"]=DayVwapLimitBse
            row["DayTwapLimitNse"]=DayTwapLimitNse
            row["DayTwapLimitBse"]=DayTwapLimitBse
            row["AvgPx"]=float(row["AvgPx"])
            #execution volume percent of interval volume 
            if row["IntervalVol"]!=0.0:
                row["volExec_intervalVol"]=((row["QuantityExecuted"]*1.0)/row["IntervalVol"])*100.0  #calculating volumeExecuted by order vs volume in that interval
                print row["volExec_intervalVol"]
            if row["IntervalVolNse"]!=0.0:
                row["volExecNse_intervalVolNse"]=((row["NSEExecuted"]*1.0)/row["IntervalVolNse"])*100.0
                print row["volExecNse_intervalVolNse"]
            if row["IntervalVolBse"]!=0.0:
                row["volExecBse_intervalVolBse"]=((row["BSEExecuted"]*1.0)/row["IntervalVolBse"])*100.0
                #print row["volExecBse_intervalVolBse"]
            if row["IntervalVolLimit"]!=0.0:
                row["volExec_intervalVolLimit"]=((row["QuantityExecuted"]*1.0)/row["IntervalVolLimit"])*100.0  #calculating volumeExecuted by order vs volume in that interval
                #print row["volExec_intervalVol"]
            if row["IntervalVolLimitNse"]!=0.0:
                row["volExecNse_intervalVolLimitNse"]=(float(row["NSEExecuted"])/row["IntervalVolLimitNse"])*100.0
                #print row["volExecNse_intervalVolNse"]
            if row["IntervalVolLimitBse"]!=0.0:
                row["volExecBse_intervalVolLimitBse"]=(float(row["BSEExecuted"])/row["IntervalVolLimitBse"])*100.0
                #print row["volExecBse_intervalVolBse"]
#percentage calculation quantity executed vs Days vol parameters
            if row["DayVol"]!=0.0:
                row["volExec_DayVol"]=(float(row["QuantityExecuted"])/row["DayVol"])*100.0
            if row["DayVolNse"]!=0.0:
                row["volExecNse_DayVolNse"]=(float(row["NSEExecuted"])/row["DayVolNse"])*100.0
            if row["DayVolBse"]!=0.0:
                row["volExecBse_DayVolBse"]=(float(row["BSEExecuted"])/row["DayVolBse"])*100.0
            if row["DayVolLimit"]!=0.0:
                row["volExec_DayVolLimit"]=(float(row["QuantityExecuted"])/row["DayVolLimit"])*100.0
            if row["DayVolLimitNse"]!=0.0:
                row["volExecNse_DayVolLimitNse"]=(float(row["NSEExecuted"])/row["DayVolLimitNse"])*100.0
            if row["DayVolLimitBse"]!=0.0:
                row["volExecBse_DayVolLimitBse"]=(float(row["BSEExecuted"])/row["DayVolLimitBse"])*100.0
    #calculting values of avgPrice vs calculated parameters vwap,twap
            if row["IntervalVwap"]!=0.0:
                row["avgPx_vwap"]=((row["IntervalVwap"]-row["AvgPx"])/row["IntervalVwap"])*10000
            if row["IntervalTwap"]!=0.0:
                row["avgPx_twap"]=((row["IntervalTwap"]-row["AvgPx"])/row["IntervalTwap"])*10000
            if row["IntervalVwapLimit"]!=0.0:
                #print("asds",row["vwap_limit"])
                row["avgPx_vwapLimit"]=((row["IntervalVwapLimit"]-row["AvgPx"])/row["IntervalVwapLimit"])*10000
            if row["IntervalTwapLimit"]!=0.0:
                row["avgPx_twapLimit"]=((row["IntervalTwapLimit"]-row["AvgPx"])/row["IntervalTwapLimit"])*10000
            if row["Pwp"]!=0.0:
                row["avgPx_pwp"]=((row["Pwp"]-row["AvgPx"])/row["Pwp"])*10000
            if row["PwpLimit"]!=0.0:
                row["avgPx_vwap"]=((row["PwpLimit"]-row["AvgPx"])/row["PwpLimit"])*10000
            if row["ArrivalPrice"]!=0.0:
                row["avgPx_arrivalPx"]=((row["ArrivalPrice"]-row["AvgPx"])/row["ArrivalPrice"])*10000
# the rows with calculated parameters aadded to dataframe
        logging.info("adding rows of each order in dataframe...")
        result = result.append(row)
#all the NaN values in a row of the parameter calculated filled by 0.0
    result=result.fillna(0.0)
    logging.info("Writing to a new csv file...")
    result.to_csv(outpath+"out.csv")
    #print(result.IntervalVwap)  
start_time = time()
if __name__ == '__main__':
#calling the main with passing the path of the order file created with above calculated parameters
    main(flag,outpath,market_start,market_end)
end_time = time()
logging.info("Time taken to process :{0} Seconds....".format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)

