# -*- coding: utf-8 -*-
"""
Created on Tue Dec 18 11:47:20 2018

@author: Administrator
"""

from cassandra.cluster import Cluster
import pandas as pd

def getData(session,exchange,symbol,order_date):
    query='SELECT * FROM quotedata WHERE token(exchange,date)=token(\'{1}\',\'{2}\') and symbol=\'{0}\' ALLOW FILTERING;'.format(symbol,exchange,order_date)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    return(rows)
#define rows fetched from cassandra to be a pandas dataframe
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

cluster = Cluster(['172.17.9.152'])
session = cluster.connect('rohit')
session.row_factory = pandas_factory
session.default_fetch_size = None 
df = getData(session,'IS','RIL','2018-12-10')
print df.head()