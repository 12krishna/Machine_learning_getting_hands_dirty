import pandas as pd, datetime
#from dateutil import parser
from cassandra.cluster import Cluster
#import cassandra
import os 


os.chdir('D:\\ADR')

curr_dir = os.getcwd()
input_dir = curr_dir+"\\Input\\"
cassandra_host = "172.17.9.51"
master_dir = "D:\\Master\\"


def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


#cluster = Cluster([cassandra_host])  
cluster = cassandra_configs_cluster()  
# connect to your keyspace and create a session using which u can execute cql commands 
session = cluster.connect('rohit')  
session.row_factory = pandas_factory
session.default_fetch_size = None  
#session.execute("CREATE TABLE IF NOT EXISTS adr_email_flag (email VARCHAR,flag int, PRIMARY KEY (email));")
# set the email flag to be 1 
df = session.execute("select * from adr_email_flag;")  # reset this flag in adr report after email is sent
df = df._current_rows
    
for _, row in df.iterrows():
    
    if row['flag']==1:
        # check if backdated event is fired
        if row['adr_date']!=datetime.date(1999,1,1) and row['emails']!='':
            # run backdated adr report 
            os.system("D:\\ADR\\adr_report_backdated{}.bat".format('' if row['email']=='US' else "_india"))   # run the process
            session.execute("insert into adr_email_flag(email,adr_date,emails,flag) \
                                            values('{}','1999-01-01','',0);".format(row['email']))  # reset flag
        else:
            # fire adr process 
            os.system("D:\\ADR\\ADR_report{}.bat".format('' if row['email']=='US' else "_india"))   # run the process
            session.execute("insert into adr_email_flag(email,flag) values('{}',0);".format(row['email']))  # reset flag
    