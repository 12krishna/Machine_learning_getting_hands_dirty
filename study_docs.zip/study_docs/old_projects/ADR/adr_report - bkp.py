import pandas as pd
#from dateutil import parser
from cassandra.cluster import Cluster
#import cassandra
import logging 
from time import time
import datetime
import os 
import dateutil.relativedelta
from forex_python.converter import CurrencyRates
import decimal 


curr_dir = os.getcwd()
input_dir = curr_dir+"\\Input\\"
master_dir = curr_dir+"\\Master\\"
cassandra_host = "172.17.9.152"

# log events in debug mode 
logging.basicConfig(filename=curr_dir+"\\adr_report.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):
    
    '''Pandas factory to determine cassandra data into python df'''
    return pd.DataFrame(rows, columns=colnames)

def dateparse(date):
    
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

def expiry_flag_func(expiry_dates, d):
    
    '''Func to check if date is expiry or not'''
    expiry_flag = 0 if len(expiry_dates[expiry_dates['d']==d]) == 0 else 1 # expiry flag to check if today is expiry day
    logging.info('{} is {}'.format( d,'Not an expiry' if expiry_flag==0 else 'is an expiry') )
    #print '{} is {}'.format( d,'not an expiry' if expiry_flag==0 else 'is an expiry')
    return expiry_flag

def m_expiry_dates(expiry_encoders, date):
    
    '''Func to get 3 expiry dates for any given date '''    
    m1 = expiry_encoders[expiry_encoders['Date']==date]['Expiry1'].values[0]
    m2 = expiry_encoders[expiry_encoders['Date']==date]['Expiry2'].values[0]
    m3 = expiry_encoders[expiry_encoders['Date']==date]['Expiry3'].values[0]
    logging.info('m1 = {}, m2 = {}, m3 = {} for current date = {}'.format(m1,m2,m3,date))
    
    return m1,m2,m3

    
def get_cassandra_df(session,table,date ):
    
    '''Func to read df from cassandra dumps'''    
    # create empty dataframe 
    #dr_data_df = pd.DataFrame()
    logging.info('Fetching df from cassandra table {} for date {}'.format(table, date))
    query = 'SELECT symbol,price_date,instrument,open_int,close,key,expiry_dt FROM {} WHERE price_date = \'{}\' and instrument = \'FUTSTK\' ALLOW FILTERING;'.format(
        table,date )    
    #query = 'SELECT * FROM test_df.adrdb WHERE date >= \'{}\' AND date <= \'{}\' ALLOW FILTERING;'.format(startdate, enddate)
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    logging.info('Successfully fetched {} rows from db'.format(len(rows)))
    
    return rows
    
def last_date_func(today, holiday_master, flag):
    
    '''Fetch last week or month working day '''
    enddate = ''
    if flag==0:
        # get last week working day 
        enddate = today- datetime.timedelta(weeks=1)
    elif flag==1:
        # get last month day
        enddate = today - dateutil.relativedelta.relativedelta(months=1)  
    elif flag==2:
        # previous working day 
        enddate = today - dateutil.relativedelta.relativedelta(days=1) 
        
        
    while True:
        if enddate not in holiday_master['date'].values:
            break            
        elif enddate in holiday_master['date'].values:
            logging.info('{} is holiday fetching d-1 date for week OI calc'.format(enddate))
        enddate = enddate-datetime.timedelta(1)
        
    
    logging.info('Last {} working day for current date {} is {}'.format( 'week' if flag==0 else 'month' ,today, enddate))  
    
    return enddate



def OI_calc_func(expiry_dates,expiry_encoders, date, df, symbol, dollar_value):
    
    '''Calc OI change for week and ETD from today''' 
    # get corresponding expiry dates for current processing date
    m1_expiry, m2_expiry, m3_expiry = m_expiry_dates(expiry_encoders, date)
    val = 0
    if expiry_flag_func(expiry_dates, date)==1:
        # its an expiry day hence m2*close+m3*close
        val = df[ (df['symbol']==symbol) & (df['price_date']==date) & ( (df['expiry_dt']==m2_expiry) | (df['expiry_dt']==m3_expiry)  )][['open_int','close']] 
        val['product'] = val['open_int']*val['close']        
        val = int(val['product'].sum()/(1000000*dollar_value))
    else:
        # not an expiry hence m1*close+m2*close+m3*close
        val = df[ (df['symbol']==symbol) & (df['price_date']==date)  ][['open_int','close']] 
        val['product'] = val['open_int']*val['close']        
        val = int(val['product'].sum()/(1000000*dollar_value))
    
    return val

def total_oi_mn_dollars(today, today_7,expiry_dates,expiry_encoders, session,symbols, dollar_value ):
    
    '''Final Func to calc Total OI in million dollars'''    
    # total OI ($mn) calculation    
    # total OI for previous expiry date
    expiry_list = list(sorted(expiry_dates['d']))
    # get previous expiry
    previous_expiry = expiry_list[expiry_list.index(expiry_encoders[expiry_encoders['Date']==today]['Expiry1'].values[0])-1]
    logging.info('{} is preivous expiry for current date {}'.format(previous_expiry, today))

    # get today, t-7 and previous expiry df from cassandra
    df = pd.DataFrame()
    df = df.append( get_cassandra_df(session,'fno_bhavcopy',today), ignore_index=True )
    df = df.append( get_cassandra_df(session,'fno_bhavcopy',today_7), ignore_index=True )
    df = df.append( get_cassandra_df(session,'fno_bhavcopy',previous_expiry), ignore_index=True )

    #df = get_cassandra_df(session, 'test_bhavcopy', enddate, today)
    #filter on ADR symbols
    logging.info('Filtering on ADR symbols...')
    logging.info('Dollar value used for calc = {}'.format(dollar_value))
    df = df[df['symbol'].isin(symbols['Symbol'].values)]
    # maintain for ADR LP SP calc 
    temp = df.copy(deep=True)
    # OI calc and table generation    
    total_oi_df = []
    for symbol in symbols['Symbol']:
        # total OI calc ; check if date is expiry date if yes calc on m2+m3 if not expiry m1+m2+m3
        #today OI # call OI_calc_func
        logging.info('Total OI calc for {}'.format(symbol))
        today_oi = OI_calc_func(expiry_dates,expiry_encoders, today, df, symbol, dollar_value)
        # get 1 week before OI
        week_oi = OI_calc_func(expiry_dates,expiry_encoders, today_7, df, symbol, dollar_value)
        # get ETD OI
        etd_oi = OI_calc_func(expiry_dates,expiry_encoders, previous_expiry, df, symbol, dollar_value)

        wk_chg = today_oi - week_oi
        etd_chg = today_oi - etd_oi
        total_oi_df.append([symbol, today_oi, wk_chg, etd_chg])

    total_oi_df = pd.DataFrame(total_oi_df, columns=['symbol','today','1wk_chg_mn_dollars','ETD_chg_mn_dollars'])
    if len(total_oi_df)!=0:
        logging.info('Success: Total OI calculation done for all ADR symbols ')
    else:
        logging.info('Failure: Total OI calculation failed ')
    return total_oi_df, temp



def avg_daily_volumes_and_close(session, today, today_7, last_month, holiday_master):
    '''Func to calc average volume for today, week and month'''
    
    # fetch data over 1 month from cassandra db for analysis
    df = pd.DataFrame()
    logging.info('Fetching df from cassandra table {} from date {} to {}'.format('adr_bhavcopy', today, last_month))

    query = 'SELECT symbol,date,close,volume FROM {} WHERE date >= \'{}\' and date <= \'{}\'  ALLOW FILTERING;'.format('adr_bhavcopy',
                                                                                                                 last_month,today) 
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    df = df.append(rows, ignore_index=True) 
    logging.info('Successfully fetched {} rows from db'.format(len(rows)))
    adr_data_df = df.copy(deep=True) # copy for pocessing further
    
    # computations
    df['date'] = df['date'].apply(lambda row: row.date()) # convert cassandra date to python datetime.date format
    result = []
    # prev working day 
    t_prev = last_date_func(today, holiday_master, 2)
    try:
        
        for groupname, groupelements in df.groupby('symbol'):
            # vol calc 
            groupelements['val'] = groupelements['close']*groupelements['volume']
            t_vol = round(groupelements[groupelements['date']==today]['val'].values[0]/1000000,1)  # today volume value in million dolllars
            t_week_vol = round(groupelements[(groupelements['date'] <= today) & (groupelements['date'] >= today_7)  ]['val'].mean()/1000000,1) # 1 week before 
            t_month_vol = round(groupelements[(groupelements['date'] <= today) & (groupelements['date'] >= last_month) ]['val'].mean()/1000000,1) # 1 month before 
            # fetch close prices 
            t_close = groupelements[groupelements['date']==today]['close'].values[0] # today close price
            t_prev_close = groupelements[groupelements['date']==t_prev]['close'].values[0] # previous working day close price
            t_week_close = groupelements[groupelements['date']==today_7]['close'].values[0] # previous week close price
            t_month_close = groupelements[groupelements['date']==last_month]['close'].values[0] # previous month close price
            # % price change calc 
            one_day_chg = int(((t_close-t_prev_close)/t_close)*100) 
            week_day_chg = int(((t_close-t_week_close)/t_close)*100)
            month_day_chg = int(((t_close-t_month_close)/t_close)*100)       

            result.append([groupname,one_day_chg,week_day_chg,month_day_chg,t_vol,t_week_vol, t_month_vol ])
    except Exception as e:
        print 'Data not avaliable in adr_bhavcopy (cassandra table) for one of the following days: {} {} {} {}'.format(today,t_prev, today_7, last_month )
        logging.info('Data not avaliable in adr_bhavcopy (cassandra table) for one of the following days: {} {} {} {}'.format(today,t_prev, today_7,
                                                                                                  last_month ))
    # df
    result = pd.DataFrame(result, columns=['symbol','1d_chg','1w_chg','1m_chg','1d_vol','1w_vol','1m_vol'])
    
    return result, adr_data_df


def percentile_SP_LP_etd_range(session,today,m1_expiry, symbols, last_month, adr_data_df, indian_close_prices, dollar_value):
    '''Func to calc percentiles,SP LP mandates, week range, etd range'''
    
    # fetch data over 1 month from cassandra db for analysis
    df = pd.DataFrame()
    logging.info('Fetching df from cassandra table {} from date {} to {}'.format('adr_bhavcopy', today, last_month))

    query = 'SELECT symbol,date,price,type,volume FROM {} WHERE date = \'{}\' ALLOW FILTERING;'.format('adrdb',
                                                                                                        today) 
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    df = df.append(rows, ignore_index=True) 
    logging.info('Successfully fetched {} rows from db'.format(len(rows)))
    print 'Successfully fetched {} rows from db'.format(len(rows))


    # long short position calc 
    input_df = pd.read_excel(input_dir+"/adr_cr_ip.xlsx")
    input_df['Symbol'] = input_df['Symbol'].apply(lambda row: row.split('US')[0].strip())
    input_df['SP']=input_df['SP']*10000
    input_df['LP']=input_df['LP']*10000
    
    # fetch todays close and volumes 
    adr_close_vols_df = adr_data_df[adr_data_df['date']==today]

    final_mandates = []
    for groupname, groupelements in df.groupby('symbol'):       
        #groupelements.to_csv('raw.csv')

        top_vol = int(adr_close_vols_df[adr_close_vols_df['symbol']==groupname]['volume'].values[0]*0.1) # 10% of volume done
        bot_vol = int(adr_close_vols_df[adr_close_vols_df['symbol']==groupname]['volume'].values[0]*0.9) # 10% of volume done    
        conversion_factor = input_df[input_df['Symbol']==groupname]['Conversion Factor'].values[0]
        sp_levels = input_df[input_df['Symbol']==groupname]['SP'].values[0]
        lp_levels = input_df[input_df['Symbol']==groupname]['LP'].values[0]    

        #close = adr_close_vols_df[adr_close_vols_df['symbol']==groupname]['close'].values[0] # close price for ADR stock
        # get indian close price for today i.e. current expiry
        
        close = float(indian_close_prices[(indian_close_prices['expiry_dt']==m1_expiry) &
                                          (indian_close_prices['price_date']==today)  & 
                                          (indian_close_prices['symbol']==symbols[symbols['ADR']==groupname]['symbol'].values[0])]['close'].values[0])



        # calc spread    
        groupelements['price'] = groupelements['price']*conversion_factor*float(dollar_value)  # convert price to INR
        groupelements['spread'] = groupelements['price']/close - 1
        groupelements['spread'] = groupelements['spread']*10000
        groupelements.sort_values(by='spread', inplace=True)  

        # filter on first 10% of volume happened cummulative vol
        groupelements['cumsum']= groupelements['volume'].cumsum()
        #groupelements.to_csv('cumsum.csv')
        low_avg = groupelements[groupelements['cumsum'] <= top_vol]    
        low_avg['value'] = low_avg['volume']*low_avg['spread']    
        bottom10vol= low_avg['volume'].sum()
        low_avg['value'] = low_avg['spread']*low_avg['volume']   
        val = low_avg['value'].sum()
        low_avg = val/bottom10vol

        high_avg = groupelements[groupelements['cumsum'] >= bot_vol]    
        high_avg['value'] = high_avg['volume']*high_avg['spread']    
        top10vol= high_avg['volume'].sum()
        high_avg['value'] = high_avg['spread']*high_avg['volume']   
        val = high_avg['value'].sum()
        high_avg = val/top10vol

        # SP and LP calc
        sp_df = groupelements[groupelements['spread']>=sp_levels]
        lp_df = groupelements[groupelements['spread']<=lp_levels]

        #est sum vol in mn
        sp_val_mn = sp_df['price']*sp_df['volume']
        sp_val_mn = sp_val_mn.sum()/(float(dollar_value)*1000000)    
        lp_val_mn = lp_df['price']*lp_df['volume']
        lp_val_mn = lp_val_mn.sum()/(float(dollar_value)*1000000)

        # est avg bps
        sp_vol = sp_df['spread']*sp_df['volume']
        sp_vol = sp_vol.sum()/sp_df['volume'].sum()
        lp_vol = lp_df['spread']*lp_df['volume']
        lp_vol = lp_vol.sum()/lp_df['volume'].sum()       

        final_mandates.append([groupname,int(low_avg), int(high_avg),round(lp_val_mn,1),round(lp_vol,1),round(sp_val_mn,1)
                               , round(sp_vol,1) ])

    final_mandates = pd.DataFrame(final_mandates, columns=['ADR','Low%tileAvg_1d','High%tileAvg_1d','LP Est Vol $mn',
                                                          'LP Est Avg Bps','SP Est Vol $mn','SP Est Avg Bps'])

    final_mandates.fillna(0, inplace=True)
    return final_mandates


def write_email_message(final_df, final_mandates):
    '''Write Email HTML file'''
    
    # long short position calc 
    input_df = pd.read_excel(input_dir+"/adr_cr_ip.xlsx", converters={
        'SP': lambda value: '{}%'.format(value * 100), 'LP': lambda value: '{}%'.format(value * 100)})
    input_df['Symbol'] = input_df['Symbol'].apply(lambda row: row.split('US')[0].strip())
    input_df.rename(columns={'Symbol':'ADR'}, inplace=True)

    with open('message.txt', 'wb') as f:
        f.write('<style> thead tr {background-color:"#4682B4"; color:"white"; text-align: right; font-family: Calibri; border-color:"#FFFFFF";} tbody tr {text-align: right; font-family: Calibri; border-color:"#FFFFFF";} </style>')
        f.write('ADR report <br><br>')
        f.write('Input<br><br>')
        f.write(input_df.to_html(index=False))
        f.write('<br>Output<br><br>')
        f.write(final_mandates.to_html(index=False))
        f.write('<br><br>')        
        f.write(final_df.to_html(index=False))
        f.write('<br><br>')  
        f.write('This is an auto generated email!<br>')
        f.close()



def main():   
    
    
    # cassandra connection setup
    cluster = Cluster([cassandra_host])
    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')
    logging.info('Using test_df keyspace')
    #define rows fetched from cassandra to be a pandas dataframe
    session.row_factory = pandas_factory
    session.default_fetch_size = None   
    
    logging.info('Reading master files')
    holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                     date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)
        
    symbols = pd.read_excel(master_dir+'Symbol_mappings.xlsx')
    expiry_encoders = pd.read_excel(master_dir+'Expiry_contract_Master.xlsx')
    # convert date to datetime format
    expiry_encoders['Date'] = expiry_encoders['Date'].dt.date
    expiry_encoders['Expiry1'] = expiry_encoders['Expiry1'].dt.date
    expiry_encoders['Expiry2'] = expiry_encoders['Expiry2'].dt.date
    expiry_encoders['Expiry3'] = expiry_encoders['Expiry3'].dt.date
    
    expiry_dates = pd.read_excel(master_dir+'Expiry_dates_master.xlsx')
    expiry_dates.dropna(inplace=True)
    expiry_dates['d'] = expiry_dates.apply(lambda row: datetime.datetime.strptime("{}{}{}".format(row['Date'],
                                                              row['Month'], row['Year']),"%d%b%Y").date() , axis=1)
    expiry_dates = expiry_dates[expiry_dates['Expiry']=='E']
    
    today = datetime.datetime.now().date()- datetime.timedelta(1)
    today_7 = last_date_func(today, holiday_master, 0) # 1 week before date
    last_month = last_date_func(today, holiday_master, 1) # 1 month before date
    
    m1_expiry, m2_expiry, m3_expiry = m_expiry_dates(expiry_encoders, today)
    # get dollar exchange rate in NIR
    c = CurrencyRates()
    dollar_value= c.get_rate('USD', 'INR')
    dollar_value = decimal.Decimal(dollar_value)
    
    # get total OI calculations 
    total_oi_df,indian_close_prices = total_oi_mn_dollars(today, today_7,expiry_dates,expiry_encoders, session,symbols, dollar_value )
    
    # Average Vols in million dollars and close price % change
    vol_close_df, adr_data_df = avg_daily_volumes_and_close(session, today, today_7, last_month, holiday_master)
    
    # merge into one table
    symbols['ADR'] = symbols['ADR'].apply(lambda row: row.split('US')[0].strip() )
    symbols.rename(columns={'Symbol':'symbol'}, inplace=True)
    
    total_oi_df = total_oi_df.merge(symbols, on='symbol',how='left')
    total_oi_df['symbol'] = total_oi_df['ADR']
    total_oi_df.drop(columns=['ADR'], inplace=True)
    final_df = vol_close_df.merge(total_oi_df, on='symbol',how='left')
    final_df.rename(columns={'symbol':'ADR','1d_chg':'1d','1w_chg':'1w','1m_chg':'1m','1d_vol':'1d','1w_vol':'1w','1m_vol':'1m','today':'Today',
                             '1wk_chg_mn_dollars':'1 wk Chg','ETD_chg_mn_dollars':'ETD chg'}, inplace=True)
    #final_df.set_index('ADR', inplace=True)
    # create multi index
    d = {'Price Change %': final_df.iloc[:,1:4] , 'Avg Daily Vols(Mn dollars)':final_df.iloc[:, 4:7] ,
        'Total OI (Mn dollars)':final_df.iloc[:, 7:]}
    d = pd.concat(d.values(), axis=1, keys=d.keys())
    d.insert(0,'ADR', final_df['ADR'] )
    final_df = d.copy(deep=True)
    
    # Mandates calc on ADRDB data
    final_mandates = percentile_SP_LP_etd_range(session,today,m1_expiry, symbols, last_month,
                                                adr_data_df, indian_close_prices, dollar_value)
    final_mandates.rename(columns={'LP Est Vol $mn':'LP Est Vol mn_dollars','SP Est Vol $mn':'SP Est Vol mn_dollars'}, inplace=True)
    #final_mandates.set_index('ADR', inplace=True)
    
    # write to HTML email file to send auto email 
    write_email_message(final_df, final_mandates)


     
    
    
start_time = time()

if __name__ == '__main__':
    main()

end_time = time()

logging.info('Time taken to process :'.format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)

