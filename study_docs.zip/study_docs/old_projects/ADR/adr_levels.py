import pandas as pd
import datetime
import time
from cassandra.cluster import Cluster
from dateutil.parser import parse
import sys
import xlwings as xw
import win32api
import os

cassandra_host = "172.17.9.51"
#cassandra_host = 'localhost'



def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster(master_dir):
    f = open(master_dir+"config",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster



## set adr levels and email ###

def adr(table):
    
    # mock caller for debugging 
    xw.Book("ADR_input_levels.xlsm").set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()
    master_dir = str(os.path.split(wb.fullname)[0]) + "\\build\\exe.win-amd64-2.7\\"
    
    # get config details and cassandra cluster session object
    #cluster = Cluster([cassandra_host])  
    cluster = cassandra_configs_cluster(master_dir)         
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')    
    session.row_factory = pandas_factory
    session.default_fetch_size = None
    
    
    df = pd.DataFrame()
    if table=='adr_levels_india':
        # set adr levels for india
        df=pd.DataFrame(wb.sheets[2].range('A4:E30').value)           
    else:
        df=pd.DataFrame(wb.sheets[0].range('A4:E30').value)
       
    df.rename(columns=df.iloc[0], inplace=True)
    df.dropna(how="any", inplace=True)
    df=df.iloc[1:]
    df["Date"]=pd.datetime.now().replace(second=0,microsecond=0)
    
    # CREATE A TABLE; dump bhavcopies to this table
    session.execute("CREATE TABLE IF NOT EXISTS {} (Symbol VARCHAR,LP FLOAT, SP FLOAT, conversion_Factor FLOAT \
                        , Date TIMESTAMP, dividend float, PRIMARY KEY (Symbol, Date))".format(table))
    
    print df.columns
    print df
    print df['dividend']
    
    for index, row in df.iterrows():
        #print 'Insert into test_df.adr_levels(symbol,sp,lp,conversion_factor,date) VALUES(\'{}\',{},{},{},{});'.format(row['Symbol'],row['SP'],row['LP'],row['Conversion Factor'],row['Date'])
       
       session.execute('Insert into {}(symbol,lp,sp,conversion_factor,date, dividend) VALUES(\'{}\',{},{},{},\'{}\',{});'.format(
                           table, row['Symbol'], row['LP'], row['SP'], row['Conv Factor'], row['Date'], row['dividend'] ))  

    win32api.MessageBox(wb.app.hwnd, "ADR mandates {} set!".format( 'India' if table=='adr_levels_india' else 'US'),"Success !")  
    
    
def flag(site):
    '''Flag that sets email flag'''
    
    # mock caller for debugging 
    xw.Book("ADR_input_levels.xlsm").set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()   
    master_dir = str(os.path.split(wb.fullname)[0]) + "\\build\\exe.win-amd64-2.7\\"
    
    # get config details and cassandra cluster session object
    #cluster = Cluster([cassandra_host])  
    cluster = cassandra_configs_cluster(master_dir)         
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')    
    session.row_factory = pandas_factory
    session.default_fetch_size = None
       
    #session.execute("CREATE TABLE IF NOT EXISTS adr_email_flag (email VARCHAR,flag int, PRIMARY KEY (email));")
    # set the email flag to be 1
    session.execute("insert into adr_email_flag(email,flag) values('{}',1);".format(site))  # reset this flag in adr report after email is sent
    win32api.MessageBox(wb.app.hwnd, "(ADR {}) Email will be fired in 5 minutes from the server !".format(site),"Success !")  


    
###########################################################    
##### get, set and email for back dated ADR report##################    
    
def get_levels(table):
    
    xw.Book("ADR_input_levels.xlsm").set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()
    master_dir = str(os.path.split(wb.fullname)[0]) + "\\build\\exe.win-amd64-2.7\\"
    
    # get config details and cassandra cluster session object
    #cluster = Cluster([cassandra_host])  
    cluster = cassandra_configs_cluster(master_dir)         
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')    
    session.row_factory = pandas_factory
    session.default_fetch_size = None
        
    processing_date = ''
    if table=='adr_levels':
        processing_date=wb.sheets[1].range('A2:A2').value #get the date which needs to be changed
    elif table=='adr_levels_india':
        processing_date=wb.sheets[3].range('A2:A2').value #get the date which needs to be changed
    #get the data from adr levels
    query=session.execute("SELECT * from {} where date <= '{}' and date >= '{}' allow filtering".format(table,
                          processing_date + datetime.timedelta(hours=23,minutes=59,seconds=59), processing_date-datetime.timedelta(days=30) ) )
    result=query._current_rows
    result['date'] = result['date']+datetime.timedelta(hours=5, minutes=30)
    result.sort_values(by='date',ascending=True,inplace=True)
    
    combined_group = result.groupby('symbol', as_index=False).agg({'date':'last','conversion_factor':'last',
                                                                       'dividend':'last','lp':'last','sp':'last'})
    combined_group=combined_group[["symbol","lp","sp","conversion_factor","dividend","date"]]
    #combined_group['date'] = combined_group['date']
    combined_group.rename(columns={"lp":"LP","sp":"SP","conversion_factor":"Conv Factor","symbol":"Symbol"}, inplace=True)
    combined_group.set_index('Symbol', inplace=True)
    combined_group['Conv Factor'] = combined_group['Conv Factor'].round(5)
    
    # display on front end
    if table=='adr_levels':
        wb.sheets[1].range("A4:H100").value = ''
        wb.sheets[1].range("A4").value = combined_group
        win32api.MessageBox(wb.app.hwnd, "(ADR US) Data successfully imported from db !","Success !") 
    
    elif table=='adr_levels_india':
        wb.sheets[3].range("A4:H100").value = ''
        wb.sheets[3].range("A4").value = combined_group
        win32api.MessageBox(wb.app.hwnd, "(ADR India) Data successfully imported from db !","Success !") 
    
    

def set_levels(table):
    
    xw.Book("ADR_input_levels.xlsm").set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()
    master_dir = str(os.path.split(wb.fullname)[0]) + "\\build\\exe.win-amd64-2.7\\"
    
    # get config details and cassandra cluster session object
    #cluster = Cluster([cassandra_host])  
    cluster = cassandra_configs_cluster(master_dir)         
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')    
    session.row_factory = pandas_factory
    session.default_fetch_size = None
    
    df=xw.Range('A4:F100').options(pd.DataFrame, expand='table').value
    df=df.reset_index(); df.dropna(inplace=True)
    
    if len(df)!= 0:
        df['date'] = df['date'].apply(lambda row:  row.replace(second=0,microsecond=0)  )
        
    # insert updated values into cassandra 
    for index, row in df.iterrows():
        session.execute("insert into {}(symbol,date,conversion_factor,dividend,lp,sp) values('{}','{}',{},{},{},{});".format(table,
                row['Symbol'], row['date'], round(row['Conv Factor'],5), row['dividend'], round(row['LP'],5), round(row['SP'],5))) 
        
    win32api.MessageBox(wb.app.hwnd, "({}) Levels Data updated !".format('India' if table=='adr_levels_india' else 'US'),"Success !") 
    
def backdated_email(site):
    # send backdated email 
    
    xw.Book("ADR_input_levels.xlsm").set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()
    master_dir = str(os.path.split(wb.fullname)[0]) + "\\build\\exe.win-amd64-2.7\\"
    
    # get config details and cassandra cluster session object
    #cluster = Cluster([cassandra_host])  
    cluster = cassandra_configs_cluster(master_dir)         
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')    
    session.row_factory = pandas_factory
    session.default_fetch_size = None
    
    email_list=''; processing_date=''
    if site=='US':
        email_list=wb.sheets[1].range('J5:J5').value 
        processing_date=wb.sheets[1].range('A2:A2').value.date() #get the date for email 
    elif site=='India':
        email_list=wb.sheets[3].range('J5:J5').value 
        processing_date=wb.sheets[3].range('A2:A2').value.date() #get the date for email 
   
    session.execute("insert into adr_email_flag(email,adr_date,emails,flag) values('{}','{}','{}',1);".format(site,
                        processing_date,email_list))  # set flag for backdated processing and emailing     
    win32api.MessageBox(wb.app.hwnd, "ADR {} ; Email will be fired in 5 minutes from the server !".format(site),"Success !")  
    
  
    
    
def main(args):
    
    
    if args:
        if args[0] == "adr":
            print "Set ADR levels for current"
            adr('adr_levels')
        elif args[0] == "flag":
            print "Sending email after 5 min for current date event"
            flag('US')
        elif args[0] == 'get_levels':
            print "Get ADR levels for specified date"
            get_levels('adr_levels')
        elif args[0] == "set_levels":
            print "Set ADR levels for backdated event"
            set_levels('adr_levels')
        elif args[0] == "email_bd":
            print "Sending email for backdated event"
            backdated_email('US')
            
        # adr for india
        elif args[0] == "adr_india":
            print "Set ADR levels for current"
            adr('adr_levels_india')
        elif args[0] == "flag_india":
            print "Sending email after 5 min for current date event"
            flag('India')
        elif args[0] == 'get_levels_india':
            print "Get ADR levels for specified date"
            get_levels('adr_levels_india')
        elif args[0] == "set_levels_india":
            print "Set ADR levels for backdated event"
            set_levels('adr_levels_india')
        elif args[0] == "email_bd_india":
            print "Sending email for backdated event"
            backdated_email('India')
        
    
        
       

if __name__ == "__main__":
    main(sys.argv[1:])
    
