import pandas as pd
#from dateutil import parser
import os
from cassandra.cluster import Cluster
import logging 
#from time import time
#import shutil
#import redis 
import datetime 


cassandra_host = "172.17.9.51"
master_dir = "D:\\Master\\"

#cassandra_host = "LocalHost"
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)


def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


def fetch_dollar():
    
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()
    session = cluster.connect('rohit')
    #logging.info('Using test_df keyspace')
    session.row_factory = pandas_factory
    session.default_fetch_size = None
    
    query=session.execute("SELECT * from bloom_usd_inr where date>='{}' allow filtering".format(
            datetime.datetime.now().date()-datetime.timedelta(days=10 )))
    result=query._current_rows

    result['date'] = result['date'].apply(lambda row: row.date())
    result.sort_values(by='date', inplace=True)

   
    return round(result.tail(1)['usd_inr'].values[0],2)




