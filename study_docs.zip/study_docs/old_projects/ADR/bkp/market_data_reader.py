# -*- coding: utf-8 -*-
"""
Created on Thu May 21 19:36:33 2020

@author: krishna
"""

import numpy as np 
import pandas as pd
import time, datetime, os
import warnings
warnings.filterwarnings("ignore")
import tarfile
import zipfile
import logging
#from dateutil import parser
from cassandra.cluster import Cluster
from cassandra.util import datetime_from_timestamp



#redis_host = '10.223.104.61'
#redis_host = "localhost"
cassandra_host = "172.17.9.51"

'''
master_dir = "/opt/Basis_project/Master/"
#log_path = "/opt/Sectoral_trends/"
data_dir = "/opt/Sectoral_trends/Data/"
contacts_dir = "/opt/Sectoral_trends/"
output_dir = "/opt/Sectoral_trends/Output/"

'''
download_dir = "D:\\Volumes_intraday_mailer\\Download\\"
master_dir = "D:\\Master\\"

# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):
    
    '''Pandas factory to determine cassandra data into python df'''
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster



def dateparse(row):
    '''Func to parse dates while reading ticker files'''
    d = row.split("+")[0]
    d = pd.to_datetime(d, format='%Y-%m-%d %H:%M:%S')
    return d

def redis_key_generator():
    '''Generate all the keys needed for computation over a period of day '''
    
    #keys = []
    timekeys = []
    a = datetime.datetime(1,1,1,9,5)
    
    for i in range(77):
        a = a + datetime.timedelta(minutes=5)
        timekeys.append("{}{}".format(('0'+str(a.hour) if len(str(a.hour))==1 else str(a.hour)),
                                      ( '0'+str(a.minute) if len(str(a.minute))==1 else str(a.minute))))

        
    return timekeys

def flattern(A):
    rt = []
    for i in A:
        if isinstance(i,list): rt.extend(flattern(i))
        else: rt.append(i)
    return rt



def gen_filename(timekeys, d):
    '''Generate filenames'''
    
    #d = datetime.date.today() -datetime.timedelta(10)
    filename = []
    for timek in timekeys:
        filename.append( 'debug_log_mktdata_{}{}{}_{}.txt'.format(('0'+str(d.day) if len(str(d.day))==1 else str(d.day)),
                                                ('0'+str(d.month) if len(str(d.month))==1 else str(d.month)),
                                                str(d.year), timek ))
        
    return filename

   
def dump_in_cassandra(result, pairmaster):
    '''Formats futures data and stores in cassandra'''
    
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])   
    cluster = cassandra_configs_cluster()
    session = cluster.connect('rohit')
    session.row_factory = pandas_factory
    session.default_fetch_size = None
    
    # CREATE A TABLE; dump bhavcopies to this table
    session.execute('CREATE TABLE IF NOT EXISTS adr_market_debuglog (fut_contract VARCHAR,date date, symbol varchar, time time \
                                                                     , ltp decimal, volumetraded int, closeprice DECIMAL,\
                                                                     , PRIMARY KEY ((fut_contract, date), symbol, time) )')
    
    
    prices_df = pd.DataFrame()
    for col in ['FutCode_m1', 'FutCode_m2', 'FutCode_m3']:
        temp = (pairmaster[['Symbol',col]].rename(columns={col:'SecurityCode'})).merge( result ,
                                                                     on='SecurityCode', how='inner', suffixes=('_P','')) 
        temp['fut_contract'] = col.split('_')[-1]       
        prices_df = prices_df.append(temp, ignore_index=True, sort=True)      
        
    prices_df['Symbol'] = prices_df['Symbol_P']  
    prices_df = prices_df[['fut_contract','date','Symbol','time','LTP','VolumeTraded','ClosePrice']]
    prices_df['date'] =  prices_df['date'].dt.date
    prices_df.sort_values(by=['fut_contract','date','Symbol','time'], inplace=True)
    
    prices_df.to_csv('dump.csv', index=False)
    
    # write csv file to cassandra db
        
    os.system("dump.bat")   
	#os.putenv("filename", '/home/linuxconfig/ADRreport/temp.csv')
	#subprocess.call('/home/linuxconfig/ADRreport/ARDstoredata.sh')
    cluster.shutdown()
        
    '''
    vols = pd.DataFrame()
    for symbol in ['INFY','ICICIBANK','TATAMOTORS','HDFCBANK','DRREDDY','WIPRO','VEDL']:
        df = session.execute("select * from rohit.adr_market_debuglog where token(fut_contract,date)=token('m1','2020-05-28') \
                         and symbol='{}' allow filtering;".format(symbol))
        df = df._current_rows
        df = df.groupby(by=['symbol','fut_contract'])['volumetraded'].max().reset_index()
        vols = vols.append(df, ignore_index=True)
    '''
    
    

 



    

def file_reader(filename, pairmaster):
    # reads files and filters on time 
    
    cols = ['date','Symbol','QtyBuy int','QtyBuy_2','QtyBuy_3','QtyBuy_4','QtyBuy_5','Bid','Bid_2','Bid_3','Bid_4','Bid_5','offer',
        'Offer_2','Offer_3','Offer_4','Offer_5','QtySell','QtySell_2','QtySell_3','QtySell_4','QtySell_5','VolumeTraded',
        'OpenPrice','Ccy', 'LTP','NumberOfOrdersBuy','NumberOfOrdersBuy_2','NumberOfOrdersBuy_3','NumberOfOrdersBuy_4',
        'NumberOfOrdersBuy_5','NumberOfOrdersSell','NumberOfOrdersSell_2','NumberOfOrdersSell_3','NumberOfOrdersSell_4',
        'NumberOfOrdersSell_5','LowerCircuitLimit','UpperCircuitLimit','HighPrice','LowPrice','ClosePrice','LTT timestamp',
        'NetChangeIndicator','LTQ','LotSize','OI','SecurityCode','ExchangeSegment','TradingSymbol']   
    
    prices_df = pd.DataFrame()

    """
    # untar files and then read
    with tarfile.open(r"\\172.17.9.141\Archive_Data\MarketdataAprMay\{}.tar.gz".format(filename)) as tar:
        tar.extractall(path=r"\\172.17.9.141\Archive_Data\MarketdataAprMay")
    """ 
   
    
    try:  
        print 'Processing : ',filename
        
        # read input file for every 5 sec data 
        prices_df = pd.read_csv(r"\\172.17.9.141\Archive_Data\MarketdataAprMay\{}".format(filename),delimiter=','
                                , names=cols,skipinitialspace=True, low_memory=False )[['date','Symbol','VolumeTraded',
                                'LTP','ClosePrice','SecurityCode','ExchangeSegment']]
        
        prices_df['date'] = prices_df['date'].str.split('+',expand=True)
        prices_df['date'] = pd.to_datetime(prices_df['date'], format='%Y-%m-%d %H:%M:%S')            
        #logging.info('Sucessfully read ticker file {}'.format(filename))
        
    except Exception as e :
        #logging.info('No file with name {}'.format(filename))   
        
  
    # retain records between market hours and ignore rest
    prices_df['time'] = prices_df['date'].dt.time   
    
    # ignore codes with long codes
    prices_df['SecurityCode'] = prices_df['SecurityCode'].astype(str)
    prices_df = prices_df[ ~(prices_df.SecurityCode.str.len() > 6 ) ]
    #prices = prices[(prices['Symbol']=='ACC') | (prices['Symbol']=='ADANIENT')]

    # cpnvert to numeric
    prices_df['SecurityCode'] = pd.to_numeric(prices_df['SecurityCode'], errors='coerce') 
    
    codes = pairmaster[['FutCode_m1','FutCode_m2', 'FutCode_m3']].astype(int)
    prices_df = prices_df[prices_df['SecurityCode'].isin( flattern(codes.values.tolist()) )]  # filter on adr symbols
    
    
    '''
    # delete the extracted file
    os.remove(r"\\172.17.9.141\Archive_Data\MarketdataAprMay\{}".format(filename))
    '''
    
    return prices_df
    

 
def ticker_generator(files, pairmaster):
    '''Func to read 5 min log utility file and generate 1 min ticker stats for volume traded and LTP for each symbol''' 
    
         
    ftime = time.time()
    # read all files till this hour in time 
    result_df = pd.DataFrame()   
    
    for f in files:        
        result_df = result_df.append( file_reader(f, pairmaster) ,ignore_index=True)
     
    print "Length of Market data {}".format(len(result_df))
    #logging.info("Length of Market data {}".format(len(result_df)))   
    
    result_df.drop_duplicates(inplace=True, keep='last')
    
    stime=datetime.time(9,15); etime=datetime.time(15,30)    
    result_df = result_df[ (result_df['time']>=stime) & (result_df['time']<=etime) ]
    
    print "Length of Market data {}".format(len(result_df))
    #logging.info("Length of Market data {}".format(len(result_df)))   
    print "file reading time {}".format(time.time() - ftime)
    #logging.info("file reading time {}".format(time.time() - ftime))
    
    return result_df


def dateparse1(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date
      
# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse1, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)  

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
          
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        #logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1



  
    
def main(nd):
    '''Func to read files, process and do scheduling of entire process'''
    
    
    d = datetime.datetime.now().date() - datetime.timedelta(days=nd)
    if process_run_check(d) == -1:
        #logging.info('Exit: Its an holiday.')
        return -1    
       
    
    # read yesterdays bhavcopy file 
    #logging.info("Start Process; read market data")
    # read master file for cash and fut codes 
    pairmaster = pd.read_csv(master_dir+'PairMaster.csv')
    # filter on ADR symbols
    pairmaster = pairmaster[pairmaster['Symbol'].isin(['INFY','ICICIBANK','TATAMOTORS','HDFCBANK',
                            'DRREDDY','WIPRO','VEDL'])]  # add new adr Symbols here to record data from market debug log data
    
    '''
    expiry_dates_master = pd.read_csv(master_dir+'Expiry_dates_master.csv')
    expiry_dates_master['date'] = expiry_dates_master.apply(lambda row: pd.to_datetime(str(row['Date'])+row['Month']+str(row['Year'])).date(),
                       axis=1)
    expiry_dates_master = expiry_dates_master[expiry_dates_master['Expiry']=='E']['date'] '''
    
    #logging.info("Read master files")
    # create redis keys
    timekeys = redis_key_generator()
    
    # get filenames to be processed over a time 
    files = gen_filename(timekeys, d)
    
    start = time.time()
    result = ticker_generator( files, pairmaster)   

    # format and store data to cassandra
    dump_in_cassandra(result, pairmaster)



        
                
    print 'Total data processing time : {}'.format(time.time()-start)
    #logging.info('Total data processing time : {}'.format(time.time()-start))
    
        
           
start_time = time.time()

if __name__ == '__main__':
    main(0)  # set (nd = timedelta) days here ; for india session nd=0 i.e. current date
            

end_time = time.time()

#logging.info('Time taken to process :'.format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)

 
