from cx_Freeze import setup, Executable 


options = {'build_exe': {'packages': ['numpy'],
                         'include_files':['D:\Anaconda\Lib\site-packages\mkl_intel_thread.dll']
                         } }

setup(name = "ADR_input_levels" , 
       version = "2.0" , 
       description = "" ,
       options = options,  
       executables = [Executable("adr_levels.py")])