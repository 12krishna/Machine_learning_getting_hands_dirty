import pandas as pd
#from dateutil import parser
from cassandra.cluster import Cluster
from cassandra.util import datetime_from_timestamp
#import cassandra
import logging  
from time import time
import datetime
import os 
import dateutil.relativedelta
#from forex_python.converter import CurrencyRates
import decimal 
import email_utility
import warnings
import numpy as np
warnings.filterwarnings("ignore")
import rigd_report

os.chdir('D:\\ADR')

curr_dir = os.getcwd()
input_dir = curr_dir+"\\Input\\"
master_dir = "D:\\Master\\"
cassandra_host = "172.17.9.51"

# log events in debug mode 
logging.basicConfig(filename=curr_dir+"\\adr_report.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):
    
    '''Pandas factory to determine cassandra data into python df'''
    return pd.DataFrame(rows, columns=colnames)


def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster


def dateparse(date):
    
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date

def expiry_flag_func(expiry_dates, d):
    
    '''Func to check if date is expiry or not'''
    expiry_flag = 0 if len(expiry_dates[expiry_dates['d']==d]) == 0 else 1 # expiry flag to check if today is expiry day
    logging.info('{} is {}'.format( d,'Not an expiry' if expiry_flag==0 else 'is an expiry') )
    #print '{} is {}'.format( d,'not an expiry' if expiry_flag==0 else 'is an expiry')
    return expiry_flag

def m_expiry_dates(expiry_encoders, date):
    
    '''Func to get 3 expiry dates for any given date '''    
    m1 = expiry_encoders[expiry_encoders['Date']==date]['Expiry1'].values[0]
    m2 = expiry_encoders[expiry_encoders['Date']==date]['Expiry2'].values[0]
    m3 = expiry_encoders[expiry_encoders['Date']==date]['Expiry3'].values[0]
    logging.info('m1 = {}, m2 = {}, m3 = {} for current date = {}'.format(m1,m2,m3,date))
    
    return m1,m2,m3

        

def fetch_last_adr_levels(session):
    '''Function to fetch latest 3 mintues adr levels'''
    
    query=session.execute("SELECT * from adr_levels")
    result=query._current_rows

    result["symbol"]=result["symbol"].astype(str)
    adr=result.groupby(['symbol'],sort=True).last()
    adr['time'] = adr['date'].dt.time
    
    adr.drop(['date','time'], inplace=True, axis=1)
    adr.reset_index(inplace=True)
    adr.rename(columns={'symbol':'Symbol', 'conversion_factor':'Conv factor','dividend':'Dividend',
                        'lp':'LP','sp':'SP'}, inplace=True)
    adr = adr[['Symbol','LP','SP','Conv factor','Dividend']]
    adr['Conv factor'] = adr['Conv factor'].round(5)
    
    
    return adr



def fetch_dollar(d):
    
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()
    session = cluster.connect('rohit')
    #logging.info('Using test_df keyspace')
    session.row_factory = pandas_factory
    session.default_fetch_size = None
    
    query=session.execute("SELECT * from bloom_usd_inr where date='{}' allow filtering".format(d))
    result=query._current_rows

    result['date'] = result['date'].apply(lambda row: row.date())
    result.sort_values(by='date', inplace=True)

   
    return round(result.tail(1)['usd_inr'].values[0],2)





def get_cassandra_df(session,table,date ):
    
    '''Func to read df from cassandra dumps'''    
    # create empty dataframe 'VEDL_FUTSTK_0.0_XX_1'
    #dr_data_df = pd.DataFrame()
    logging.info('Fetching df from cassandra table {} for date {}'.format(table, date))
    result = pd.DataFrame()
    for i in range(1,4):
        
        for key in ['TATAMOTORS_FUTSTK_0.0_XX_{}'.format(i),'HDFCBANK_FUTSTK_0.0_XX_{}'.format(i),'WIPRO_FUTSTK_0.0_XX_{}'.format(i),
                    'INFY_FUTSTK_0.0_XX_{}'.format(i),'DRREDDY_FUTSTK_0.0_XX_{}'.format(i),'ICICIBANK_FUTSTK_0.0_XX_{}'.format(i),
                    'VEDL_FUTSTK_0.0_XX_{}'.format(i),'RELIANCE_FUTSTK_0.0_XX_{}'.format(i)]:
            
            query = 'SELECT * FROM {} WHERE price_date = \'{}\' and key= \'{}\' ALLOW FILTERING;'.format(
                table,date, key )    
            #query = 'SELECT * FROM test_df.adrdb WHERE date >= \'{}\' AND date <= \'{}\' ALLOW FILTERING;'.format(startdate, enddate)
            rows = session.execute(query, timeout = None)
            rows = rows._current_rows
            rows = rows[['symbol','price_date','instrument','open_int','close','key','expiry_dt']]
            rows = rows[rows['instrument']=='FUTSTK']
            
            result = result.append(rows, ignore_index=True)
        logging.info('Successfully fetched {} rows from db'.format(len(result)))
        print 'Successfully fetched {} rows from db'.format(len(result))
    
    return result
    
def last_date_func(today, holiday_master, flag):
    
    '''Fetch last week or month working day '''
    enddate = ''
    if flag==0:
        # get last week working day 
        enddate = today- datetime.timedelta(weeks=1)
    elif flag==1:
        # get last month day
        enddate = today - dateutil.relativedelta.relativedelta(months=1)  
    elif flag==2:
        # previous working day 
        enddate = today - dateutil.relativedelta.relativedelta(days=1)        
        
    while True:
        if enddate not in holiday_master['date'].values:
            break            
        elif enddate in holiday_master['date'].values:
            logging.info('{} is holiday fetching d-1 date for week OI calc'.format(enddate))
        enddate = enddate-datetime.timedelta(1)
        
    
    logging.info('Last {} working day for current date {} is {}'.format( 'week' if flag==0 else 'month' ,today, enddate))  
    
    return enddate



def OI_calc_func(expiry_dates,expiry_encoders, date, df, symbol, dollar_value):
    
    '''Calc OI change for week and ETD from today''' 
    # get corresponding expiry dates for current processing date
    m1_expiry, m2_expiry, m3_expiry = m_expiry_dates(expiry_encoders, date)
    val = 0
    
    
    if expiry_flag_func(expiry_dates, date)==1:
        # its an expiry day hence m2*close+m3*close
        val = df[ (df['symbol']==symbol) & (df['price_date']==date) & ( (df['expiry_dt']==m2_expiry) | (df['expiry_dt']==m3_expiry)  )][['open_int','close']] 
        val['product'] = val['open_int']*val['close']        
        val = int(val['product'].sum()/(1000000*dollar_value))
    else:
        # not an expiry hence m1*close+m2*close+m3*close
    
        val = df[ (df['symbol']==symbol) & (df['price_date']==date)  ][['open_int','close']] 
        
        val['product'] = val['open_int']*val['close'] 

        val = int(val['product'].sum()/(1000000*dollar_value))
    
    return val

def total_oi_mn_dollars(today, today_7,expiry_dates,expiry_encoders, session,symbols, dollar_value, holiday_master ):
    
    '''Final Func to calc Total OI in million dollars'''    
    # total OI ($mn) calculation    
    # total OI for previous expiry date
    expiry_list = list(sorted(expiry_dates['d']))
    # get previous expiry
    previous_expiry = expiry_list[expiry_list.index(expiry_encoders[expiry_encoders['Date']==today]['Expiry1'].values[0])-1]
    previous_expiry = previous_expiry + datetime.timedelta(days=1)  # ETD + 1 day
    while True:
        if previous_expiry not in holiday_master['date'].values:
            break            
        elif previous_expiry in holiday_master['date'].values:
            logging.info('{} is holiday fetching d+1 date '.format(previous_expiry))
        previous_expiry = previous_expiry + datetime.timedelta(1)
        
    print "previous expiry date", previous_expiry
    
    
    
    
    logging.info('{} is preivous expiry+1 for current date {}'.format(previous_expiry, today))

    # get today, t-7 and previous expiry df from cassandra
    df = pd.DataFrame()
    df = df.append( get_cassandra_df(session,'fno_bhavcopy',today), ignore_index=True )
    df = df.append( get_cassandra_df(session,'fno_bhavcopy',today_7), ignore_index=True )
    df = df.append( get_cassandra_df(session,'fno_bhavcopy',previous_expiry), ignore_index=True )
    df.drop_duplicates(inplace=True)
    #df = get_cassandra_df(session, 'test_bhavcopy', enddate, today)
    #filter on ADR symbols
    logging.info('Filtering on ADR symbols...')
    logging.info('Dollar value used for calc = {}'.format(dollar_value))
    df = df[df['symbol'].isin(symbols['Symbol'].values)]
    # maintain for ADR LP SP calc 
    temp = df.copy(deep=True)
    # OI calc and table generation    
    total_oi_df = []
    for symbol in symbols['Symbol']:
        
        # total OI calc ; check if date is expiry date if yes calc on m2+m3 if not expiry m1+m2+m3
        #today OI # call OI_calc_func
        logging.info('Total OI calc for {}'.format(symbol))
        today_oi = OI_calc_func(expiry_dates,expiry_encoders, today, df, symbol, dollar_value)
        # get 1 week before OI
        week_oi = OI_calc_func(expiry_dates,expiry_encoders, today_7, df, symbol, dollar_value)
        # get ETD OI
        etd_oi = OI_calc_func(expiry_dates,expiry_encoders, previous_expiry, df, symbol, dollar_value)

        wk_chg = today_oi - week_oi
        etd_chg = today_oi - etd_oi
        total_oi_df.append([symbol, today_oi, wk_chg, etd_chg])

    total_oi_df = pd.DataFrame(total_oi_df, columns=['symbol','today','1wk_chg_mn_dollars','ETD_chg_mn_dollars'])
    if len(total_oi_df)!=0:
        logging.info('Success: Total OI calculation done for all ADR symbols ')
    else:
        logging.info('Failure: Total OI calculation failed ')
        
    return total_oi_df, temp, previous_expiry



def avg_daily_volumes_and_close(session, today, today_7, last_month, holiday_master):
    '''Func to calc average volume for today, week and month'''
    
    # fetch data over 1 month from cassandra db for analysis
    df = pd.DataFrame()
    logging.info('Fetching df from cassandra table {} from date {} to {}'.format('adr_bhavcopy', today, last_month))

    query = 'SELECT symbol,date,close,volume FROM {} WHERE date >= \'{}\' and date <= \'{}\'  ALLOW FILTERING;'.format('adr_bhavcopy',
                                                                                                                 last_month,today) 
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    df = df.append(rows, ignore_index=True) 
    df=df[df['symbol']!='RIGD']
    logging.info('Successfully fetched {} rows from db'.format(len(rows)))
    adr_data_df = df.copy(deep=True) # copy for pocessing further
    
    # computations
    df['date'] = df['date'].apply(lambda row: row.date()) # convert cassandra date to python datetime.date format
    result = []
    # prev working day 
    t_prev = last_date_func(today, holiday_master, 2)
    
    for groupname, groupelements in df.groupby('symbol'):
        try:
            print(groupname)
            # vol calc 
            groupelements['val'] = groupelements['close']*groupelements['volume']
            t_vol = round(groupelements[groupelements['date']==today]['val'].values[0]/1000000,1)  # today volume value in million dolllars
            t_week_vol = round(groupelements[(groupelements['date'] <= today) & (groupelements['date'] >= today_7)  ]['val'].mean()/1000000,1) # 1 week before 
            t_month_vol = round(groupelements[(groupelements['date'] <= today) & (groupelements['date'] >= last_month) ]['val'].mean()/1000000,1) # 1 month before 
            # fetch close prices 
            t_close = groupelements[groupelements['date']==today]['close'].values[0] # today close price
            t_prev_close = groupelements[groupelements['date']==t_prev]['close'].values[0] # previous working day close price
            t_week_close = groupelements[groupelements['date']==today_7]['close'].values[0] # previous week close price
            t_month_close = groupelements[groupelements['date']==last_month]['close'].values[0] # previous month close price
            # % price change calc 
            one_day_chg = round(((t_close-t_prev_close)/t_close)*100,1) 
            week_day_chg = round(((t_close-t_week_close)/t_close)*100,1)
            month_day_chg = round(((t_close-t_month_close)/t_close)*100,1)       

            result.append([groupname,one_day_chg,week_day_chg,month_day_chg,t_vol,t_week_vol, t_month_vol ])
            logging.info('AVg daily volumes: Fetched record for {} {} {}'.format(today, t_prev, today_7, last_month))
        except Exception as e:
            print 'Error: {} / Data not avaliable in adr_bhavcopy (cassandra table) for one of the following days: {} {} {} {}'.format(e,today,t_prev, today_7, last_month )
            logging.info('Error: {} / Data not avaliable in adr_bhavcopy (cassandra table) for one of the following days: {} {} {} {}'.format(e,today,t_prev, today_7,
                                                                                                  last_month ))
    # df
    result = pd.DataFrame(result, columns=['symbol','1d_chg','1w_chg','1m_chg','1d_vol','1w_vol','1m_vol'])
    
    return result, adr_data_df




def agg_func(grp):
    '''agg func vwap price, total volume'''    
    
    return pd.Series({'volume':np.sum(grp['volume']),
                      'price': np.average(grp['price'], weights=grp['volume']) if sum(grp['volume'])!=0 else 0,
                      'spread': "{} : {}".format(int(grp['spread'].values[0]), int(grp['spread'].values[-1]))})
   
    


def interpolate_basis(volume_distribution):
    '''Func to interpolate data on every 25 basis points'''
    
    volume_distribution.reset_index(drop=True, inplace=True)
    volume_distribution['temp1'] = 1
    
    volume_distribution['temp'] = (volume_distribution['spread'].abs() - abs(volume_distribution['spread'].values[0])).astype(int)%25
    flag=0
    for index, row in volume_distribution.iterrows():
        if row['temp']==0:
            volume_distribution.iloc[index, volume_distribution.columns.str.startswith('temp1')] = flag
            flag += 1
        else:
            flag=0
            
    first_zero_ind = volume_distribution[volume_distribution['temp1']==0].index.astype(int).tolist()    
    last = 0
    result = pd.DataFrame()
    
    idx = first_zero_ind[0]
    for idx in first_zero_ind[1:]:
        result = result.append(volume_distribution.iloc[last:idx, :].groupby(by=['symbol'], 
                               as_index=False).apply(lambda grp: agg_func(grp)), ignore_index=True)
        last=idx
    result = result.append(volume_distribution.iloc[idx:, :].groupby(by=['symbol'], 
                           as_index=False).apply(lambda grp: agg_func(grp)), ignore_index=True)
    result.insert(0, 'ADR', volume_distribution['symbol'].values[0])
            
    return result
            
    

def percentile_SP_LP_etd_range(session,today,m1_expiry, symbols, last_month, adr_data_df, indian_close_prices, dollar_value,
                               today_7,us_today, us_7,us_last_month):                                 
    '''Func to calc percentiles,SP LP mandates, week range, etd range'''
    
    # fetch data over 1 month from cassandra db for analysis
    df = pd.DataFrame()

    query = 'SELECT symbol,date,time,price,type,volume FROM {} WHERE date = \'{}\' ALLOW FILTERING;'.format('adrdb',
                                                                                                        us_today) 
    rows = session.execute(query, timeout = None)
    rows = rows._current_rows
    df = df.append(rows, ignore_index=True)
    df=df[df['symbol']!='RIGD']
    #df=pd.read_csv(r"\\172.17.9.22\Users\krishna\geeta\risk intrinsic\df.csv")
    logging.info('Successfully fetched {} rows from db'.format(len(rows)))
    print 'Successfully fetched {} rows from db'.format(len(rows))

    # long short position calc 
    #input_df = pd.read_excel(input_dir+"/adr_cr_ip.xlsx")
    input_df = fetch_last_adr_levels(session)  # fetch last adr levels from casssnadra
    print input_df
    input_df['Symbol'] = input_df['Symbol'].apply(lambda row: row.split(' ')[0].strip())
    input_df['SP']=input_df['SP']*10000
    input_df['LP']=input_df['LP']*10000
    
    # fetch todays close and volumes 
    adr_close_vols_df = adr_data_df[adr_data_df['date']==us_today]
    
    # filter on input master input
    df = df[df['symbol'].isin(list(input_df['Symbol']))]
    df['time'] = df['time'].apply(lambda row: row.time())
    #df.to_csv("adrdata.csv")
    df = df[df['type']!='SD,N,OL,PT']  #ignore these trades
    # 25 basis points volume distribution in excel   
    adr_spread_wise_vols = pd.DataFrame()
    final_mandates = []
    for groupname, groupelements in df.groupby('symbol'):  
        a = len(groupelements)
        temp = groupelements[groupelements['time']>=datetime.time(19,0)]
        temp.sort_values(by='time', inplace=True)
        temp1 = groupelements[groupelements['time'] < datetime.time(19,0)]    
        temp1.sort_values(by='time', inplace=True)
        groupelements = pd.concat([temp, temp1], axis=0)
        b = len(groupelements)
        if a==b:
            print True
        else :
            print False
        #groupelements.to_csv('debug.csv')
        #groupelements.to_csv('raw.csv')
        print '------------',groupname

        top_vol = int(adr_close_vols_df[adr_close_vols_df['symbol']==groupname]['volume'].values[0]*0.1) # 10% of volume done
        print top_vol
        bot_vol = int(adr_close_vols_df[adr_close_vols_df['symbol']==groupname]['volume'].values[0]*0.9) # 10% of volume done    
        
        conversion_factor = input_df[input_df['Symbol']==groupname]['Conv factor'].values[0]
        
        sp_levels = input_df[input_df['Symbol']==groupname]['SP'].values[0]
        lp_levels = input_df[input_df['Symbol']==groupname]['LP'].values[0]  
        dividend = input_df[input_df['Symbol']==groupname]['Dividend'].values[0]  

        #close = adr_close_vols_df[adr_close_vols_df['symbol']==groupname]['close'].values[0] # close price for ADR stock
        # get indian close price for today i.e. current expiry
        
        close = float(indian_close_prices[(indian_close_prices['expiry_dt']==m1_expiry) &
                                          (indian_close_prices['price_date']==today)  & 
                                          (indian_close_prices['symbol']==symbols[symbols['ADR']==groupname]['symbol'].values[0])]['close'].values[0])



        # calc spread  
        groupelements['act_price'] = groupelements['price']   # actual US price 
        groupelements['price'] = groupelements['price']*conversion_factor*float(dollar_value)  # convert price to INR
        
        groupelements['spread'] = groupelements['price']/(close+dividend) - 1
        groupelements['spread'] = groupelements['spread']*10000
        groupelements.sort_values(by='spread', inplace=True)  
        day_high = round(groupelements['spread'].max(),1) 
        day_low = round(groupelements['spread'].min(),1)
        print "{} -->  Day high {} - Day low {}".format(groupname, day_high, day_low)
        # filter on first 10% of volume happened cummulative vol
        groupelements['cumsum']= groupelements['volume'].cumsum()
        groupelements.to_csv('{}cumsum.csv'.format(groupname))
        low_avg = groupelements[groupelements['cumsum'] <= top_vol] 
        if len(low_avg)==0:
            low_avg = groupelements.head(1)
        
        #groupelements.to_csv("cumsum.csv")
        low_avg['value'] = low_avg['volume']*low_avg['spread']    
        bottom10vol= low_avg['volume'].sum()
        low_avg['value'] = low_avg['spread']*low_avg['volume']   
        val = low_avg['value'].sum(); val1=val
        low_avg = int(val/bottom10vol)

        high_avg = groupelements[groupelements['cumsum'] >= bot_vol]    
        high_avg['value'] = high_avg['volume']*high_avg['spread']    
        top10vol= high_avg['volume'].sum()
        high_avg['value'] = high_avg['spread']*high_avg['volume']   
        val = high_avg['value'].sum()
        high_avg = int(val/top10vol)

        # write basis volume distribution
        volume_distribution = groupelements[(groupelements['spread']>=(val1/bottom10vol) ) & (groupelements['spread']<=(val/top10vol))][['symbol',
                                            'date','time','act_price','price','volume','spread']].sort_values(by=['spread'])
        # aggergate basis over 25 basis points
        interpolate_basis_df = interpolate_basis(volume_distribution)
        interpolate_basis_df['volume'] = interpolate_basis_df['volume']*interpolate_basis_df['price']/(10**6*float(dollar_value))
        adr_spread_wise_vols = adr_spread_wise_vols.append(interpolate_basis_df, ignore_index=True)
        
        

        # SP and LP calc
        sp_df = groupelements[groupelements['spread']>=sp_levels]
        lp_df = groupelements[groupelements['spread']<=lp_levels]

        #est sum vol in mn/ multiply with acutal us prices 
        sp_val_mn = sp_df['act_price']*sp_df['volume']
        sp_val_mn = round(sp_val_mn.sum()/1000000,1)   
        lp_val_mn = lp_df['act_price']*lp_df['volume']
        lp_val_mn = round(lp_val_mn.sum()/1000000,1)

        # est avg bps
        sp_vol = sp_df['spread']*sp_df['volume']
        sp_vol = round(sp_vol.sum()/sp_df['volume'].sum(),1)
        lp_vol = lp_df['spread']*lp_df['volume']
        lp_vol = round(lp_vol.sum()/lp_df['volume'].sum(),1)       

        final_mandates.append([groupname,low_avg, high_avg,lp_val_mn,int(lp_vol) if lp_val_mn != 0.0 else 0  ,sp_val_mn,
                               int(sp_vol) if sp_val_mn != 0.0 else 0, day_low, day_high ])

    final_mandates = pd.DataFrame(final_mandates, columns=['ADR','Low%tileAvg_1d','High%tileAvg_1d','LP Est Vol $mn',
                                                          'LP Est Avg Bps','SP Est Vol $mn','SP Est Avg Bps','DayLow','DayHigh'])
   
   
    final_mandates.fillna(0, inplace=True)
    adr_spread_wise_vols.to_excel("spread_vol_distribution.xlsx", index=False)
    
    return final_mandates

def write_email_message(session, final_df, final_mandates,sum_sp_lp_1w_etd_df):
    '''Write Email HTML file'''
    
    # long short position calc 
    input_df = fetch_last_adr_levels(session)
    #input_df = pd.read_excel(input_dir+"/adr_cr_ip.xlsx")
    input_df['SP'] = input_df['SP'].apply(lambda row: '{}%'.format( round(row * 100,2) )) 
    input_df['LP'] = input_df['LP'].apply(lambda row: '{}%'.format( round(row * 100,2) )) 
    input_df['Symbol'] = input_df['Symbol'].apply(lambda row: row.split('US')[0].strip())
    #input_df['Conv factor'] = input_df['Conv factor'].apply(lambda row: round(row, 2))
    input_df.rename(columns={'Symbol':'ADR'}, inplace=True)
    
    
    final_mandates = final_mandates[['ADR','Low%tileAvg_1d','High%tileAvg_1d','LP Est Vol $mn',
                                    'LP Est Avg Bps','SP Est Vol $mn','SP Est Avg Bps','1wk_Low','1w_High','ETD_Low','ETD_High','month_Low','month_High']]
    final_mandates.rename(columns={'Low%tileAvg_1d':'Low','High%tileAvg_1d':'High','LP Est Vol $mn':'Long prem','LP Est Avg Bps':'@ Bps',
                                   'SP Est Vol $mn':'Short prem','SP Est Avg Bps':'@ Bps',
                                   '1wk_Low':'Low','1w_High':'High','ETD_Low':'Low','ETD_High':'High','month_Low':'Low','month_High':'High'}, inplace=True)
    
    
    d = {'Basis': final_mandates.iloc[:,1:3] , 'Vol Estimate $mn yesterday':final_mandates.iloc[:, 3:7] ,
        'Basis Range (1 Week)':final_mandates.iloc[:, 7:9], 'Basis Range (ETD)':final_mandates.iloc[:, 9:11],'Basis Range (Month)':final_mandates.iloc[:, 11:]}
    d = pd.concat(d.values(), axis=1, keys=d.keys())
    d.insert(0,'ADR', final_mandates['ADR'] )
    final_mandates = d[['ADR','Basis','Vol Estimate $mn yesterday','Basis Range (1 Week)','Basis Range (ETD)','Basis Range (Month)']].copy(deep=True)        
 
    with open('message.txt', 'wb') as f:
        f.write('<html><head>')
        f.write('</head><body>')
        f.write("<br>Yesterday's activity wrap<br>")        
        #f.write('<br>Output<br><br>')
        f.write(final_mandates.to_html(index=False))
        f.write('<br>Price, Volume & OI table<br>')
        f.write(final_df.to_html(index=False))
        f.write('<br>Estimated Long prm/Short prm build up<br>')         
        f.write(sum_sp_lp_1w_etd_df.to_html(index=False))
        f.write('<br>Tradable range table<br>')
        f.write(input_df.to_html(index=False))
        #f.write('This is an auto generated email!<br>')
        f.write('</body><html>')
        f.close()


def write_email_message_merge(session,r_final_mandates,r_final_df,r_sum_sp_lp_1w_etd_df ,final_df, final_mandates,sum_sp_lp_1w_etd_df):
    '''Write Email HTML file'''
    
    # long short position calc 
    input_df = fetch_last_adr_levels(session)
    #input_df = pd.read_excel(input_dir+"/adr_cr_ip.xlsx")
    input_df['SP'] = input_df['SP'].apply(lambda row: '{}%'.format( round(row * 100,2) )) 
    input_df['LP'] = input_df['LP'].apply(lambda row: '{}%'.format( round(row * 100,2) )) 
    input_df['Symbol'] = input_df['Symbol'].apply(lambda row: row.split(' ')[0].strip())
    #input_df['Conv factor'] = input_df['Conv factor'].apply(lambda row: round(row, 2))
    input_df.rename(columns={'Symbol':'ADR'}, inplace=True)
    
    
    final_mandates = final_mandates[['ADR','Low%tileAvg_1d','High%tileAvg_1d','LP Est Vol $mn',
                                    'LP Est Avg Bps','SP Est Vol $mn','SP Est Avg Bps','1wk_Low','1w_High','ETD_Low','ETD_High','month_Low','month_High']]
    final_mandates.rename(columns={'Low%tileAvg_1d':'Low','High%tileAvg_1d':'High','LP Est Vol $mn':'Long prem','LP Est Avg Bps':'@ Bps',
                                   'SP Est Vol $mn':'Short prem','SP Est Avg Bps':'@ Bps',
                                   '1wk_Low':'Low','1w_High':'High','ETD_Low':'Low','ETD_High':'High','month_Low':'Low','month_High':'High'}, inplace=True)
    
    
    d = {'Basis': final_mandates.iloc[:,1:3] , 'Vol Estimate $mn yesterday':final_mandates.iloc[:, 3:7] ,
        'Basis Range (1 Week)':final_mandates.iloc[:, 7:9], 'Basis Range (ETD)':final_mandates.iloc[:, 9:11],'Basis Range (Month)':final_mandates.iloc[:, 11:]}
    d = pd.concat(d.values(), axis=1, keys=d.keys())
    d.insert(0,'ADR', final_mandates['ADR'] )
    final_mandates = d[['ADR','Basis','Vol Estimate $mn yesterday','Basis Range (1 Week)','Basis Range (ETD)','Basis Range (Month)']].copy(deep=True)  
    # concatenating rigd and other stocks data  
    final_mandates=pd.concat([final_mandates,r_final_mandates],axis=0)
    final_df=pd.concat([final_df,r_final_df],axis=0)
    sum_sp_lp_1w_etd_df=pd.concat([sum_sp_lp_1w_etd_df,r_sum_sp_lp_1w_etd_df],axis=0)
  
    
    with open('message.txt', 'wb') as f:
        f.write('<html><head>')
        f.write('</head><body>')
        f.write("<br>Yesterday's activity wrap<br>")        
        #f.write('<br>Output<br><br>')
        f.write(final_mandates.to_html(index=False))
        f.write('<br>Price, Volume & OI table<br>')
        f.write(final_df.to_html(index=False))
        f.write('<br>Estimated Long prm/Short prm build up<br>')         
        f.write(sum_sp_lp_1w_etd_df.to_html(index=False))
        f.write('<br>Tradable range table<br>')
        f.write(input_df.to_html(index=False))
        #f.write('This is an auto generated email!<br>')
        f.write('</body><html>')
        f.close()


def low_high_cassandra_calc_func(session,today, weekdate, prev_expiry,last_month):
    '''Func to calc low high for week and ETD'''  
          
    result = []
    for startdate in [weekdate, prev_expiry,last_month]:
        query = 'SELECT adr,date,lowAvg_1d,highAvg_1d,sp_est_vol_mn_dollars,lp_est_vol_mn_dollars FROM {} WHERE date >= \'{}\' and date <= \'{}\'  ALLOW FILTERING;'.format(
                'adr_mandates',startdate,today )    
        rows = session.execute(query, timeout = None)        
        df = rows._current_rows
        df=df[df['adr']!="RIGD"]
        df.to_csv("debug.csv")
        logging.info('Successfully fetched {} of rows from adr_mandates table'.format(len(df)))
        print 'LOW high cassandrta: Successfully fetched {} of rows from adr_mandates table'.format(len(df)) 
        # find low high values
        # filter on input symbol 
        
     
        for groupname, groupelements in df.groupby('adr'):  
            min_value = groupelements['lowavg_1d'].min()
            max_value = groupelements['highavg_1d'].max()
            sp_sum = int(groupelements['sp_est_vol_mn_dollars'].sum())
            lp_sum = int(groupelements['lp_est_vol_mn_dollars'].sum())  
                        
            result.append([groupname,startdate, min_value, max_value, sp_sum, lp_sum])
    
    
    result = pd.DataFrame(result, columns=['ADR','date','Low','High','sp_mn_dollars','lp_mn_dollars'])
    result.to_csv("lhsum.csv")
    
    df1 = result[result['date']==weekdate][['ADR','Low','High']]    
    df1.rename(columns={'Low':'1wk_Low','High':'1w_High'}, inplace=True)
    df2 = result[result['date']==prev_expiry][['ADR','Low','High']]    
    df2.rename(columns={'Low':'ETD_Low','High':'ETD_High'}, inplace=True)
    df3=result[result['date']==last_month][['ADR','Low','High']] 
    df3.rename(columns={'Low':'month_Low','High':'month_High'}, inplace=True)
    result1 = df1.merge(df2, on='ADR', how='outer').merge(df3, on='ADR', how='outer')

    
    # SP LP WTD ETD calc
    df1 = result[result['date']==weekdate][['ADR','lp_mn_dollars','sp_mn_dollars']]    
    df1.rename(columns={'sp_mn_dollars':'1wk SP $mn','lp_mn_dollars':'1wk LP $mn'}, inplace=True)
    df2 = result[result['date']==prev_expiry][['ADR','lp_mn_dollars','sp_mn_dollars']]    
    df2.rename(columns={'sp_mn_dollars':'ETD SP $mn','lp_mn_dollars':'ETD LP $mn'}, inplace=True)
    
    result2 = df1.merge(df2, on='ADR', how='outer' )
    
    # drop duplicate rows to handle same day ETD and WTD
    result1.drop_duplicates(inplace=True)   
    #result2.drop_duplicates(inplace=True) 
    result2.drop_duplicates(subset=['ADR'], keep='first',inplace=True)

    
    return result1, result2


def price_premium_chg(session, today, us_today, holiday_master, expiry_dates, m1_expiry, m2_expiry, 
                      adr_data_df, dollar_value, symbols)  :
    '''Func to getch india price change and obtain premium amount'''
    
    # get previous india working day 
    t_prev = last_date_func(today, holiday_master, 2)
    
    df = get_cassandra_df(session,'fno_bhavcopy', today)
    df = df.append( get_cassandra_df(session,'fno_bhavcopy', t_prev) )
    
    # get adr close prices 
    adr_data_df1 = adr_data_df[adr_data_df['date']!=us_today]
    adr_data_df1 = adr_data_df1[adr_data_df1['date']==max(adr_data_df1['date'])]
    adr_data_df = adr_data_df[adr_data_df['date']==us_today]
    
    
    # get conversion factors 
    conv_factor = fetch_last_adr_levels(session)
    conv_factor['Symbol'] = conv_factor['Symbol'].apply(lambda row: row.split(' ')[0])
   
    
    #df.groupby("symbol", sort=True).agg({'Price_chg %':  })
    if len(expiry_dates[expiry_dates['d']==today])==1  :
        print 'Expiry day hence taking m2 expiry'
        logging.info('Expiry day hence taking m2 expiry')
        df = df[df['expiry_dt']==m2_expiry]
    else:
        df = df[df['expiry_dt']==m1_expiry]
    
    result = []
    
    for index, row  in symbols.iterrows():
       
        
        close1 = df[(df['symbol']==row['symbol']) & (df['price_date']==today)]['close'].values[0]
        close2 = df[(df['symbol']==row['symbol']) & (df['price_date']==t_prev)]['close'].values[0]
        
        close_chg = round((close1/close2 - 1)*100,1)
       
        us_close = adr_data_df[adr_data_df['symbol']==row['ADR']]['close'].values[0]* float(dollar_value)* conv_factor[conv_factor['Symbol']==row['ADR']]['Conv factor'].values[0]
        us_close1 = adr_data_df1[adr_data_df1['symbol']==row['ADR']]['close'].values[0]* float(dollar_value)* conv_factor[conv_factor['Symbol']==row['ADR']]['Conv factor'].values[0]
        
        premium = round((us_close/float(close1) -1)*100, 1)
        premium1 = round((us_close1/float(close2) -1)*100, 1) # yesterday's premium
        
        premium_chg = premium - premium1
        result.append([row['ADR'], close_chg, premium, premium_chg])
    result = pd.DataFrame(result, columns=['ADR','India price chg %','Premium %','Premium chg DoD'])
    
    return result 






def main(nd):   
    
    
    # cassandra connection setup
    logging.info('Start ADR process')
    #cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()
    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')
    logging.info('Using rohit keyspace')
    #define rows fetched from cassandra to be a pandas dataframe
    session.row_factory = pandas_factory
    session.default_fetch_size = None   
    
    logging.info('Reading master files')
    holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                     date_parser=dateparse, parse_dates={'date':[0]})    
    holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
    us_holiday_master = pd.read_csv(master_dir+'US_holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
    us_holiday_master['date'] = us_holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
                
    symbols = pd.read_excel(master_dir+'ADR_Symbol_mappings.xlsx')
    symbols=symbols[symbols["ADR"]!="RIGD LI Equity"]
    expiry_encoders = pd.read_excel(master_dir+'Expiry_contract_Master.xlsx')
    # convert date to datetime format
    expiry_encoders['Date'] = expiry_encoders['Date'].dt.date
    expiry_encoders['Expiry1'] = expiry_encoders['Expiry1'].dt.date
    expiry_encoders['Expiry2'] = expiry_encoders['Expiry2'].dt.date
    expiry_encoders['Expiry3'] = expiry_encoders['Expiry3'].dt.date
    
    expiry_dates = pd.read_excel(master_dir+'Expiry_dates_master.xlsx')
    expiry_dates.dropna(inplace=True)
    expiry_dates['d'] = expiry_dates.apply(lambda row: datetime.datetime.strptime("{}{}{}".format(row['Date'],
                                                              row['Month'], row['Year']),"%d%b%Y").date() , axis=1)
    expiry_dates = expiry_dates[expiry_dates['Expiry']=='E']
     
    
    today = datetime.datetime.now().date()- datetime.timedelta(nd) 
    us_today= today
    
    if len(holiday_master[holiday_master['date']==today])==1 and len(us_holiday_master[us_holiday_master['date']==today])==1:
        logging.info('{} is holiday on both primses, hence skip processing'.format(today))
        print '{} is holiday on both primses, hence skip processing'.format(today)
        return -1
    elif len(holiday_master[holiday_master['date']==today])==0 and len(us_holiday_master[us_holiday_master['date']==today])==1:
        logging.info('{} is holiday in US but working in india'.format(today)) 
        print '{} is holiday in US but working in india'.format(today)
        us_today = last_date_func(today,us_holiday_master ,2)
        logging.info('Last working day in US = {}'.format(us_today))
    elif len(holiday_master[holiday_master['date']==today])==1 and len(us_holiday_master[us_holiday_master['date']==today])==0:
        logging.info('{} is holiday in India but working in US'.format(today)) 
        print '{} is holiday in India but working in US'.format(today)
        today = last_date_func(today, holiday_master, 2)
        logging.info('Last working day in india = {}'.format(today))
    elif len(holiday_master[holiday_master['date']==today])==0 and len(us_holiday_master[us_holiday_master['date']==today])==0:
        logging.info('{} is working in both primises'.format(today))
        print '{} is working in both primises'.format(today)
    
    today_7 = last_date_func(today, holiday_master, 0) # 1 week before date
    last_month = last_date_func(today, holiday_master, 1) # 1 month before date
    us_7 = last_date_func(us_today, us_holiday_master, 0) 
    us_last_month = last_date_func(us_today, us_holiday_master, 1)

    
    print 'India processing dates; Today = {}, T_week= {}, last_month= {}'.format(today, today_7, last_month)
    print 'US processing dates; Today = {}, T_week= {}, last_month= {}'.format(us_today, us_7, us_last_month)
    
    m1_expiry, m2_expiry, m3_expiry = m_expiry_dates(expiry_encoders, today)
    # get dollar exchange rate in NIR
    #c = CurrencyRates()
    #dollar_value= c.get_rate('USD', 'INR', today)
    #dollar_value=68.82
    dollar_value=fetch_dollar(today)
    
    
    print 'Dollar value used for {} is {}'.format(today, dollar_value)
    logging.info('Dollar value used for {} is {}'.format(today, dollar_value))
    dollar_value = decimal.Decimal(dollar_value)
    
    # get total OI calculations 
    total_oi_df,indian_close_prices, prev_expiry = total_oi_mn_dollars(today, today_7,expiry_dates,expiry_encoders, session,symbols, dollar_value, holiday_master )
    
    # Average Vols in million dollars and close price % change
   
    vol_close_df, adr_data_df = avg_daily_volumes_and_close(session, us_today, us_7, us_last_month, us_holiday_master)
    vol_close_df, adr_data_df = avg_daily_volumes_and_close(session, us_today, us_7, us_last_month, us_holiday_master)

    # highlight if volume 1D is 1.5 times greater than 1W volume
    vol_close_df['1d_vol'] = vol_close_df.apply(lambda row: "volhighlight"+str(row['1d_vol']) \
                                if (row['1d_vol']>row['1w_vol']*1.5) else row['1d_vol'], axis=1)
   
    
    
    # merge into one table
    symbols['ADR'] = symbols['ADR'].apply(lambda row: row.split(' ')[0].strip() )
    symbols.rename(columns={'Symbol':'symbol'}, inplace=True)
    
    
    total_oi_df = total_oi_df.merge(symbols, on='symbol',how='left')
    total_oi_df['symbol'] = total_oi_df['ADR']
    total_oi_df.drop(columns=['ADR'], inplace=True)
    final_df = vol_close_df.merge(total_oi_df, on='symbol',how='left')
    final_df.rename(columns={'symbol':'ADR','1d_chg':'1d','1w_chg':'1w','1m_chg':'1m','1d_vol':'1d','1w_vol':'1w','1m_vol':'1m','today':'Today',
                             '1wk_chg_mn_dollars':'1 wk Chg','ETD_chg_mn_dollars':'ETD chg'}, inplace=True)
        
    # get india close price changes and premium price 
    price_chg_df = price_premium_chg(session, today, us_today, holiday_master, expiry_dates, m1_expiry, 
                                     m2_expiry, adr_data_df, dollar_value, symbols) 
    
    final_df = final_df.merge(price_chg_df, on='ADR', how='left')
    

    #final_df.set_index('ADR', inplace=True)
    # create multi index
    d = {'Price Change %': final_df.iloc[:,1:4] , 'Avg Daily Vols($mn)':final_df.iloc[:, 4:7] ,
        'Total OI ($mn)':final_df.iloc[:, 7:10], 'Premium Discount':final_df.iloc[:,10:]}
    d = pd.concat(d.values(), axis=1, keys=d.keys())
    d.insert(0,'ADR', final_df['ADR'] )
    final_df = d.copy(deep=True)
    
    multi_tuples = [('ADR',''),('Price Change %','1d'),('Price Change %','1w'),('Price Change %','1m'),
                    ('Avg Daily Vols($mn)','1d'),('Avg Daily Vols($mn)','1w'),('Avg Daily Vols($mn)','1m'),
                    ('Total OI ($mn)','Today'),('Total OI ($mn)','1 wk Chg'),('Total OI ($mn)','ETD chg'), 
                    ('Premium Discount','India price chg %'),('Premium Discount','Premium %'),('Premium Discount','Premium chg DoD') ]

    multi_cols = pd.MultiIndex.from_tuples(multi_tuples)

    final_df = pd.DataFrame(final_df, columns=multi_cols)
    
  

    # Mandates calc on ADRDB data
    final_mandates = 0
    if expiry_flag_func(expiry_dates, today)==1:
        final_mandates = percentile_SP_LP_etd_range(session,today,m2_expiry, symbols, last_month,
                                                adr_data_df, indian_close_prices, dollar_value, today_7,
                                                us_today, us_7,us_last_month)
    else:
        final_mandates = percentile_SP_LP_etd_range(session,today,m1_expiry, symbols, last_month,
                                                adr_data_df, indian_close_prices, dollar_value, today_7,
                                                us_today, us_7,us_last_month)
        
        
        
    #final_mandates.rename(columns={'LP Est Vol $mn':'LP Est Vol mn_dollars','SP Est Vol $mn':'SP Est Vol mn_dollars'}, inplace=True)
    #final_mandates.set_index('ADR', inplace=True)
    
    # dump todays final mandates to cassandra table adr_mandates
    final_mandates['date']=today  
   
    final_mandates.to_csv('adr_results.csv', sep = ',', index=False)
    #session.execute('CREATE TABLE IF NOT EXISTS adr_mandates (adr text,lowAvg_1d int,highAvg_1d int,lp_est_vol_mn_dollars float,lp_est_avg_bps float,sp_est_vol_mn_dollars float,sp_est_avg_bps float,daylow float,dayhigh float,date date, PRIMARY KEY (adr,date) )')
    os.system(curr_dir+"\\adr_results.bat")   
    
    # calc low high for week range and ETD
    low_high_df,sum_sp_lp_1w_etd_df = low_high_cassandra_calc_func(session,today, today_7, prev_expiry,last_month)
    final_mandates.drop(columns=['date'], inplace=True)
 
    final_mandates = final_mandates.merge(low_high_df, on='ADR', how='left')
    #sum_sp_lp_1w_etd_df = sum_sp_lp_1w_etd_df[sum_sp_lp_1w_etd_df['ADR']!='VEDL']
    oi_df = total_oi_df[['symbol','today']].rename(columns={'symbol':'ADR','today':'OI'}).copy(deep=True)
    oi_df['OI'] = oi_df['OI']*0.2; oi_df['OI'] = oi_df['OI'].round() 
    oi_df['OI'] = oi_df['OI'].astype(int)
    # highlight SP/LP whereever greater than 20% of OI
    sum_sp_lp_1w_etd_df = sum_sp_lp_1w_etd_df.merge(oi_df, on=['ADR'], how='left')
    sum_sp_lp_1w_etd_df['ETD LP $mn'] = sum_sp_lp_1w_etd_df.apply(lambda row: "highlight"+str(row['ETD LP $mn']) if (row['ETD LP $mn']>row['OI']) else row['ETD LP $mn'], axis=1)
    sum_sp_lp_1w_etd_df['ETD SP $mn'] = sum_sp_lp_1w_etd_df.apply(lambda row: "highlight"+str(row['ETD SP $mn']) if (row['ETD SP $mn']>row['OI']) else row['ETD SP $mn'], axis=1)
    sum_sp_lp_1w_etd_df.drop(columns=['OI'], inplace=True)
    # write to HTML email file to send auto email 
    if rigd_report.main(nd)==-1:
        write_email_message(session, final_df, final_mandates,sum_sp_lp_1w_etd_df)
    else:
        r_final_mandates,r_final_df,r_sum_sp_lp_1w_etd_df=rigd_report.main(nd)
    
        write_email_message_merge(session, r_final_mandates,r_final_df,r_sum_sp_lp_1w_etd_df,final_df, final_mandates,sum_sp_lp_1w_etd_df )
       
    
    cluster.shutdown()   
    
    
    email_utility.process_status_email()
    os.remove('message.txt')    # remove after email is done!
   

start_time = time()

if __name__ == '__main__':
    main(nd=1)  # set dollar value and (nd = timedelta) days here 
            

end_time = time()

logging.info('Time taken to process :'.format(end_time - start_time))
print "Execution time: {0} Seconds.... ".format(end_time - start_time)








'''
import pandas as pd
df = pd.read_csv("adr_results.csv")
df['date'] = pd.to_datetime(df['date']).dt.date

df.to_csv("adr_results.csv", index=False)
import os
os.system("adr_results.bat")   
'''
