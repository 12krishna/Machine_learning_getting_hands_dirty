import numpy as np 
import pandas as pd
import logging 
from datetime import date, timedelta
import datetime
import os 
from cassandra.cluster import Cluster
import subprocess 
import pysftp
import gzip
import shutil


cassandra_host = "172.17.9.152"

curr_dir = os.getcwd()


logging.basicConfig(filename=curr_dir+"/test.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

def dateparse(d):
    
    '''Func to parse dates'''    
    d = pd.to_datetime(d, dayfirst=True)    
    return d


def file_downloader(today):
    '''Func to download file from ftp'''
    
    # code to download adr file from ftp
    us_holiday_master = pd.read_csv(curr_dir+'/US_holidays_2019.txt', delimiter=',',
									 date_parser=dateparse, parse_dates={'date':[0]})
    us_holiday_master['date'] = us_holiday_master.apply(lambda row: row['date'].date(), axis=1)
    
    filename = 'getquotes_adr_daily.csv.gz.{}'.format(''.join((str(today).split('-'))))
    if today in list(us_holiday_master['date'].values):
        logging.info('{} is holiday in US; hence skip dumping'.format(today))
        return -1
    else:
        logging.info('{} is working day; hence processing dumper'.format(today))
	print 'Download file {}'.format(filename)
        with pysftp.Connection('sftp.bloomberg.com', username='dl789941', password='+cf,QPwXjKeG3M,N') as sftp:
            logging.info('Get file from ftp ')
            sftp.get(filename)
	    
            logging.info('Success: File downlaoded')
			# unzipp file 
            try:	
                logging.info('Unzip file...')	
                os.rename(filename,''.join([filename.split('.gz')[0],'.gz']))
                with gzip.open(''.join([filename.split('.gz')[0],'.gz']),'r') as f_in, open('getquotes_adr_daily.csv','wb') as f_out:

                    shutil.copyfileobj(f_in, f_out) 
                    f_in.close()
		    f_out.close()
                    logging.info('Success: file unzip done')
                    return ''.join((str(today).split('-')))
            except Exception as e:
                print 'Excpetion ',e
                logging.info('Not a zip file')		

        
        
    
    
    


		

def agg_func(df):
    '''Func to agg price and volume'''
    #df.drop(columns = ['type1'], inplace=True)
    # drop MC and MO entries 
    df = df[(df['type2']!='MC') & (df['type2']!='MO') ]
    df = df[pd.notnull(df.volume)] # drop rows in which volume is null 
    # sum volume and take weighted avg for price for same time frames
    df['val'] = df['price']*df['volume']
    res = []
    for gname, gelements in df.groupby(['ric','time']):
        vol = gelements.volume.sum()
        price = gelements.val.sum()/vol
        type2 = gelements.type2.values[0]
        res.append([gname[0],gelements['date'].values[0],gelements['time'].values[0],type2, price, vol ])
    
    res = pd.DataFrame(res, columns=['ric','date','time','type','price','volume'])
        
    return res


def pre_process_func():
    '''Func to pre process and filter ip file'''
    
    # read input file
    # download file from bloomberg ftp server
    today = datetime.datetime.now().date()- datetime.timedelta(1) 
    file_d = file_downloader(today)
    if file_d == -1:
        return -1
		
    logging.info('Start: Read ADR csv file... ')
    df = pd.read_csv(curr_dir+"/{}".format('getquotes_adr_daily.csv' ), delimiter="|", skiprows=3, header=None,
                     names=['ric','date','time','price','volume','type1','type2'], index_col=False).dropna(axis=1, how='all')
    
    # filter on symbols from master file 
    master_df = pd.read_csv(curr_dir+'/Symbol_mappings.csv', delimiter=',')
    symbols = list(master_df.ADR.values)
    df = df[df.ric.isin(symbols)]
    logging.info("Filtered on symbols from master file")
    
    # convert date to datetime format of cassandra
    df['date'] = df['date'].apply(lambda x: pd.datetime.strptime('/'.join([x, str((datetime.datetime.now()-datetime.timedelta(1)).year)]),
                             "%m/%d/%Y").date() )    
    # filter on todays date 
    df = df[df['date']==(datetime.datetime.now()-datetime.timedelta(1)).date()]        
        
    logging.info("Date type formatted for cassandra dumping")  
   
    df['time'] = pd.to_datetime(df['time'])
    df['time'] = df['time'].dt.time
    logging.info("Time format changed")

    result = pd.DataFrame()
    adr_bhavcopy_df = [] # df to be dumped in another adr_bhavcopy table 
    
    for group_name, group_elements in df.groupby('ric'):
        # filter on 20 to 1:30
        
        result = result.append(group_elements[group_elements['ric']==group_name],
                         ignore_index=True)
        # get close price for current symbol
        close_price = group_elements[group_elements['type2']=='MC'].sort_values(by='time', axis=0, 
                                                                                ascending=False).head(1)['price'].values[0]
        logging.info('Close price for {} is {}'.format(group_name, close_price))
        
      
        # calc volume without MC and MO
        volume = group_elements[~group_elements['type2'].isin(['MC','MO'])].fillna(0)['volume'].sum()
        logging.info('volume tarded for {} is {}'.format(group_name, volume))
        
        # calc value
        value = group_elements[~group_elements['type2'].isin(['MC','MO'])].fillna(0)[['price','volume']]
        value['product'] = value['price']*value['volume']
        value = value['product'].sum()
        logging.info('Value traded for {} is {}'.format(group_name, value))
        
        # df generationf for appending
        adr_bhavcopy_df.append(['{}'.format(group_name.split('US')[0].strip()) ,'US',group_elements['date'].values[0],
                               close_price, volume, value] )
        
    adr_bhavcopy_df = pd.DataFrame(adr_bhavcopy_df, columns=['symbol','exchange','date','close','volume','value'],index=None)
    adr_bhavcopy_df.to_csv('adr_bhavcopy.csv', sep = ',', index=False)
    logging.info('ADR bhavcopy dumped in csv file')
    # dump ADR bhavcopy to cassanrda
    cassandra_dumper_func(0)       
    
    
    # agg func before dumping 
    result = agg_func(result)    
    result['symbol'] = result['ric'].apply(lambda row: row.split('US')[0]) # generate symbol
    result['symbol'] = result['symbol'].str.strip()
    result['exchange'] = "US"
    #result.rename(columns={'type2':'type'}, inplace=True)
    result = result[['symbol','exchange','date','time','type','price','volume']]    

    result.to_csv('temp.csv', sep = ',', index=False)
    logging.info("file dumped to temp.csv")
    cassandra_dumper_func(1)
    logging.info('ADR file dumped to cassandra')
	
	# move file to processed dir
    shutil.move('getquotes_adr_daily.csv', curr_dir+'/processed_files/getquotes_adr_daily.csv.{}'.format(file_d))		
	
	
	
	
    
def cassandra_dumper_func(flag):
    '''Func to dump proccessed DR file to cassandra db'''
    
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    cluster = Cluster([cassandra_host])
    logging.info('Cassandra Cluster connected...')
    # connect to your keyspace and create a session using which u can execute cql commands 
    session = cluster.connect('rohit')
    logging.info('Using rohit keyspace')
    #onetime code
    #session.execute('CREATE TABLE IF NOT EXISTS adr_bhavcopy (symbol text,exchange text,date date,close float,volume double,value double, PRIMARY KEY ((exchange,symbol),date) )')
    
    # write csv file to cassandra db
    #os.system(curr_dir+"\\dump2.bat")   
	 # write csv file to cassandra db
    #os.putenv("filename", '/home/linuxconfig/ADRreport/onetime.csv')
    #subprocess.call('/home/linuxconfig/ADRreport/adrbhavcopy.sh')


      
    
    if flag==0:
        # CREATE A TABLE; dump bhavcopies to this table
        session.execute('CREATE TABLE IF NOT EXISTS adr_bhavcopy (symbol text,exchange text,date date,close float,volume double,value double, PRIMARY KEY ((exchange,symbol),date) )')
        
        # write csv file to cassandra db
        #os.putenv("filename", '/home/linuxconfig/ADRreport/temp.csv')
        #subprocess.call('/home/linuxconfig/ADRreport/ARDstoredata.sh')
        #os.system(curr_dir+"\\dump1.bat")   
	 # write csv file to cassandra db
	os.putenv("filename", '/home/linuxconfig/ADRreport/adr_bhavcopy.csv')
	subprocess.call('/home/linuxconfig/ADRreport/adrbhavcopy.sh')

        cluster.shutdown()        
        
    elif flag==1:        
        
        # CREATE A TABLE; dump bhavcopies to this table
        session.execute('CREATE TABLE IF NOT EXISTS ADRDB (symbol text,exchange text,date date, time time,type text, price float,volume double,PRIMARY KEY ((exchange, date), symbol, time) )')
        
        # write csv file to cassandra db
        #os.putenv("filename", '/home/linuxconfig/ADRreport/temp.csv')
        #subprocess.call('/home/linuxconfig/ADRreport/ARDstoredata.sh')
        #os.system(curr_dir+"\\dump.bat")   
	os.putenv("filename", '/home/linuxconfig/ADRreport/temp.csv')
	subprocess.call('/home/linuxconfig/ADRreport/ARDstoredata.sh')
        cluster.shutdown()
    
    
	
	
	
if __name__ == '__main__':
    pre_process_func() 
    
    
    
    
