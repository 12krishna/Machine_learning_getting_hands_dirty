import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from string import Template
server = '172.17.9.149'; port = 25
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
import os 
os.chdir('D:\\ADR')
curr_dir = os.getcwd()


def read_template(filename):
    """
    Returns a Template object comprising the contents of the 
    file specified by filename.
    """
    
    with open(filename, 'r') as template_file:
        template_file_content = template_file.read()
    return Template(template_file_content)

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """
    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails



def process_status_email():
    '''Func to send daily emails after the data is dumped'''
    
    # read the message file
    message_template = open(curr_dir+"\\message.txt",'rb').read()
    message_template = message_template.replace('<th>','<th style="text-align: center; background-color:#4682B4; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<th colspan="3" halign="left">','<th colspan="3" style="text-align: center; background-color:#4682B4; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<th colspan="2" halign="left">','<th colspan="2" style="text-align: center; background-color:#4682B4; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<th colspan="4" halign="left">','<th colspan="4" style="text-align: center; background-color:#4682B4; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<tbody>','<tbody style="text-align: right; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('1wk SP $mn','1wk<br>SP<br>$mn' )
    message_template = message_template.replace('1wk LP $mn','1wk<br>LP<br>$mn' )
    message_template = message_template.replace('ETD SP $mn','ETD<br>SP<br>$mn' )
    message_template = message_template.replace('ETD LP $mn','ETD<br>LP<br>$mn' )
    message_template = message_template.replace('Conv factor','Conv<br>factor') 
    message_template = message_template.replace('<br>Tradable range table<br><table border="1" class="dataframe">',
                                                '<br>Tradable range table<br><table border="1" class="dataframe" style="font-size:8.5pt">') 
    message_template = message_template.replace('<td>highlight','<td bgcolor="#00ffff">')
    message_template = message_template.replace('<td>volhighlight','<td bgcolor="#34ebb1">')
    
    #message_template = message_template.replace('</table></body><html>','</table></div></body><html>')
    
    with open('debug.txt','wb') as f:
        f.write(message_template)
        f.close()
    
    
    emails = get_contacts('contacts.txt') # read contacts contacts.txt
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)    
    

    # set up the SMTP server
    s = smtplib.SMTP(server, port)    
    # For each contact, send the email:
    #message = message_template.substitute(PERSON_NAME=email[0].title())
        
        
    msg = MIMEMultipart('alternative')       # create a message       
    
        # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1]) 
    try:
        msg['Bcc']=','.join(emails[2])
    except:
        print "No bcc email id set"
            
    msg['Subject']="ADR report"
            
    # attachments
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open('spread_vol_distribution.xlsx', "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="{}"'.format("spread_vol_distribution.xlsx"))
    msg.attach(part) 
    
    # add in the message body
    msg.attach(MIMEText(message_template, 'html'))   
    #msg.attach(MIMEText('This is an auto generated email!', 'plain'))
   
    # send the message via the server set up earlier.
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    del msg
        
    # Terminate the SMTP session and close the connection
    s.quit()


def process_status_email_india(contacts):
    '''Func to send daily emails after the data is dumped'''
    
    # read the message file
    message_template = open(curr_dir+"\\message_india.txt",'rb').read()
    message_template = message_template.replace('<th>','<th style="text-align: center; background-color:#f55142; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<th colspan="3" halign="left">','<th colspan="3" style="text-align: center; background-color:#f55142; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<th colspan="2" halign="left">','<th colspan="2" style="text-align: center; background-color:#f55142; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<th colspan="4" halign="left">','<th colspan="4" style="text-align: center; background-color:#f55142; color:white; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('<tbody>','<tbody style="text-align: right; font-family: Calibri; border-color:#FFFFFF;">')
    message_template = message_template.replace('1wk SP $mn','1wk<br>SP<br>$mn' )
    message_template = message_template.replace('1wk LP $mn','1wk<br>LP<br>$mn' )
    message_template = message_template.replace('ETD SP $mn','ETD<br>SP<br>$mn' )
    message_template = message_template.replace('ETD LP $mn','ETD<br>LP<br>$mn' )
    message_template = message_template.replace('Conv factor','Conv<br>factor') 
    message_template = message_template.replace('<br>Tradable range table<br><table border="1" class="dataframe">',
                                                '<br>Tradable range table<br><table border="1" class="dataframe" style="font-size:8.5pt">') 
    message_template = message_template.replace('<td>highlight','<td bgcolor="#00ffff">')
    message_template = message_template.replace('<td>volhighlight','<td bgcolor="#34ebb1">')
    
    #message_template = message_template.replace('</table></body><html>','</table></div></body><html>')
    
    with open('debug_india.txt','wb') as f:
        f.write(message_template)
        f.close()
    
    
    emails = get_contacts(contacts) # read contacts
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)    
    

    # set up the SMTP server
    s = smtplib.SMTP(server, port)    
    # For each contact, send the email:
    #message = message_template.substitute(PERSON_NAME=email[0].title())
        
        
    msg = MIMEMultipart('alternative')       # create a message       
    
        # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])    
    try:
        msg['Bcc']=','.join(emails[2])
    except:
        print "No bcc email id set"
            
    msg['Subject']="ADR India session"
    
    # add in the message body
    msg.attach(MIMEText(message_template, 'html'))   
    #msg.attach(MIMEText('This is an auto generated email!', 'plain'))
   
    # send the message via the server set up earlier.
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    del msg
        
    # Terminate the SMTP session and close the connection
    s.quit()

