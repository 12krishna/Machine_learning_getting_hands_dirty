import pandas as pd
import numpy as np

file = "D:\\devansh\\nsecm_notis_incr_20191108.txt"

df = pd.read_csv(file,sep=",")
df.columns = ["tradeid","tradestatus","symbol","series","securityname","instrumenttype","booktype","markettype","userid","branchid","transactiontype","fillsize","fillprice","customerfirm","accountid","executingbroker","auctionparttype","aauctionno","settlementperiod","entrydatetime","modifieddatetime","exchordid","cpid","orderdatetime","dealercode"]

table = pd.pivot_table(df, index =['userid'],values=['entrydatetime'],aggfunc=[np.min,len]) 

df1 = table.reset_index(0)
print table

print df1

print df1.columns