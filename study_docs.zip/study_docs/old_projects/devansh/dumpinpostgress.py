import logging,psycopg2 
import pandas as pd
from sqlalchemy import create_engine
# log events in debug mode 
logging.basicConfig(filename="TCA_update.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

df=pd.read_excel('output_20191015.xlsx',sheetname="complete_output")
df["Tag1"]="TAG1"
df["unique_id"]=df["TradeId"]+df["SecurityExchange"]

# Connect to database (Note: The package psychopg2 is required for Postgres to work with SQLAlchemy)
try: 
    conn = psycopg2.connect(dbname='NSE-FNO',
                 user='postgres',
                 password='kotak@123', 
                 host='172.17.9.182', 
                 port='5432')
except:
    print("I am unable to connect to the database") 

cur = conn.cursor()
try:
    cur.execute("CREATE TABLE TCA_split (unique_id varchar PRIMARY KEY, TradeId varchar,ClientOrdID varchar,Og_ClientOrdID varchar,ClientName varchar,Symbol varchar,Series char,Ticker char,OrdType char,LimitPrice float,Side char,SecurityExchange char,StartTime varchar,EndTime varchar,OrderQty float,SOR char,QuantityExecuted float,AvgPx float,NSEExecutedQty float,BSEExecutedQty float,NSEExecutedAvg float,BSEExecutedAvg float,Remarks char,Algorithm varchar,LastFillTime varchar,ArrivalTime varchar,IntervalVwap float,IntervalVwapNse float,IntervalVwapBse float,IntervalVwapLimit float,AvgPx_vs_IntervalVwapLimit float,IntervalVwapLimitNse float,IntervalVwapLimitBse float,DayVwapLimitNse float,DayVwapLimitBse float,DayVwapLimit float,DayVwap float,DayVwapNse float,DayVwapBse float,DayTwap float,DayTwapNse float,DayTwapBse float,IntervalTwap float,IntervalTwapNse float,IntervalTwapBse float,IntervalTwapLimit float,AvgPx_vs_IntervalTwapLimit float,IntervalTwapLimitNse float,IntervalTwapLimitBse float,DayTwapLimit float,DayTwapLimitNse float,DayTwapLimitBse float,AvgPx_vs_IntervalVwap float,AvgPx_vs_DayVwap float,AvgPx_vs_DayVwapLimit float,AvgPx_vs_IntervalTwap float,AvgPx_vs_DayTwap float,AvgPx_vs_DayTwapLimit float,AvgPx_vs_Pwp float,PwpNse float,PwpBse float,Pwp float,PwpLimit float,AvgPx_vs_PwpLimit float,PwpLimitNse float,PwpLimitBse float,AvgTradeSizeNse float,AvgTradeSizeBse float,AvgTradeSize float,IntervalVolNse float,IntervalVolBse float,IntervalVol float,IntervalVolLimitNse float,IntervalVolLimitBse float,IntervalVolLimit float,DayVolNse float,DayVolBse float,DayVol float,DayVolLimitNse float,DayVolLimitBse float,DayVolLimit float,volExecNse_intervalVolNse float,volExecBse_intervalVolBse float,volExec_vs_IntervalVol float,volExecNse_intervalVolLimitNse float,volExecBse_intervalVolLimitBse float,volExec_vs_IntervalVolLimit float,volExecNse_DayVolNse float,volExecBse_DayVolBse float,volExec_vs_DayVol float,volExecNse_DayVolLimitNse float,volExecBse_DayVolLimitBse float,volExec_vs_DayVolLimit float,ArrivalPriceNse float,ArrivalPriceBse float,ArrivalPrice float,AvgPx_vs_ArrivalPx float,Tag1 varchar);")
except:
     print("database is already created you can drop it if you want to create new!")

conn.commit() # <--- makes sure the change is shown in the database
conn.close()
cur.close()

#copy data from dataframe to postgress
dbname="NSE-FNO"
user="postgres"
password="kotak@123"
ip="172.17.9.182"
port="5432"
engine = create_engine('postgresql://'+user+':'+password+'@'+ip+':'+port+'/'+dbname,echo=False) #create connection 
con = engine.connect()
df.columns = df.columns.str.lower()
df.columns=['unique_id','tradeid','clientordid','og_clientordid','clientname','symbol','series','ticker','ordtype','limitprice','side','securityexchange','starttime','endtime','orderqty','sor','quantityexecuted','avgpx','nseexecutedqty','bseexecutedqty','nseexecutedavg','bseexecutedavg','remarks','algorithm','lastfilltime','arrivaltime','intervalvwap','intervalvwapnse','intervalvwapbse','intervalvwaplimit','avgpx_vs_intervalvwaplimit','intervalvwaplimitnse','intervalvwaplimitbse','dayvwaplimitnse','dayvwaplimitbse','dayvwaplimit','dayvwap','dayvwapnse','dayvwapbse','daytwap','daytwapnse','daytwapbse','intervaltwap','intervaltwapnse','intervaltwapbse','intervaltwaplimit','avgpx_vs_intervaltwaplimit','intervaltwaplimitnse','intervaltwaplimitbse','daytwaplimit','daytwaplimitnse','daytwaplimitbse','avgpx_vs_intervalvwap','avgpx_vs_dayvwap','avgpx_vs_dayvwaplimit','avgpx_vs_intervaltwap','avgpx_vs_daytwap','avgpx_vs_daytwaplimit','avgpx_vs_pwp','pwpnse','pwpbse','pwp','pwplimit','avgpx_vs_pwplimit','pwplimitnse','pwplimitbse','avgtradesizense','avgtradesizebse','avgtradesize','intervalvolnse','intervalvolbse','intervalvol','intervalvollimitnse','intervalvollimitbse','intervalvollimit','dayvolnse','dayvolbse','dayvol','dayvollimitnse','dayvollimitbse','dayvollimit','volexecnse_intervalvolnse','volexecbse_intervalvolbse','volexec_vs_intervalvol','volexecnse_intervalvollimitnse','volexecbse_intervalvollimitbse','volexec_vs_intervalvollimit','volexecnse_dayvolnse','volexecbse_dayvolbse','volexec_vs_dayvol','volexecnse_dayvollimitnse','volexecbse_dayvollimitbse','volexec_vs_dayvollimit','arrivalpricense','arrivalpricebse','arrivalprice','avgpx_vs_arrivalpx','tag1']
df.to_sql(name='tca_split', con=con, if_exists = 'append', index=False)
#con.commit()
con.close()