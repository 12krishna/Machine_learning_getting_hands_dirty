import pandas as pd
import numpy as np

def highlight_vals_c1(row, cols):
    a1,a2= cols
    styles = {col: '' for col in row.index}
    
    if row[a1] > 0 and row[a2] > 0:
    
        styles[a1] = 'background-color: %s' % '#98fb98'
        styles[a2] = 'background-color: %s' % '#98fb98'
    
    else:
        
        styles[a1] = 'background-color: %s' % '#FF9999'
        styles[a2] = 'background-color: %s' % '#FF9999'
   
    return styles

def color_r_g_b(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    if val > 25:
        color = '#98fb98' 
    elif val>=20 and val<=25:
        color='blue' 
    else:
        color='#FF9999'
    return 'background-color: %s' % color

def get_combine_op():
    '''processing for Dayvwap and volumelimit and daylimit and dates done in this code'''
    df=pd.read_excel('output_20191015.xlsx',sheet_name='complete_output')
    df['values'] = df['AvgPx']*df['QuantityExecuted']
    df['VWAPvalues'] = df['IntervalVwapLimit']*df['IntervalVolLimit']
    df['PWPvalues'] = df['PwpLimit']*df['IntervalVolLimit']
    df['Start Time'] = pd.to_datetime(df['StartTime'])
    df['Date'] = df['Start Time']
    df['DayVwapvalues'] = df['DayVwapLimit']*df['DayVolLimit']
    df['percent_day_vol']=df["QuantityExecuted"]/df["DayVolLimit"]
    df['percent_interval_vol']=df["QuantityExecuted"]/df["IntervalVolLimit"]
    df['uniquetdse'] = df['TradeId']+df['SecurityExchange']
    df = df[df['QuantityExecuted']!=0]

    combined_group = df.groupby('uniquetdse', as_index=False).agg({'IntervalVolLimit':'sum','PWPvalues':'sum','VWAPvalues':'sum','DayVwapvalues':'sum','QuantityExecuted':'sum','percent_day_vol':'sum','percent_interval_vol':'sum','TradeId':'first','SecurityExchange':'first','Date':'first','ClientName':'first','Symbol':'first','Side':'first','ArrivalPrice':'first','values':'sum','StartTime':'first','EndTime':'first'})
    # print combined_group
    combined_group['wt_AvgPx'] = combined_group['values']/combined_group['QuantityExecuted']
    combined_group['wt_VWAP'] = combined_group['VWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_dayvwap'] = combined_group['DayVwapvalues']/combined_group['QuantityExecuted']
    combined_group['wt_PWP'] = combined_group['PWPvalues']/combined_group['IntervalVolLimit']
    
    
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
    combined_group['wtPWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_PWP'])/combined_group['wt_PWP'])*10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice'])/combined_group['ArrivalPrice'])*10000
    combined_group.fillna(0, inplace=True)
    combined_group.sort_values(by='Date', inplace=True)
    
    #calculating parameters
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
    combined_group['wtPWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_PWP'])/combined_group['wt_PWP'])*10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice'])/combined_group['ArrivalPrice'])*10000
    combined_group['wtdayVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_dayvwap'])/combined_group['wt_dayvwap'])*10000
    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)
    
    #buy side parameters
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtPWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtArrPx_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_dayvwap'] != 0), 'wtdayVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtdayVWAP_vs_AvgPx']
    
    #sell side parameters
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_dayvwap'] != 0), 'wtdayVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtdayVWAP_vs_AvgPx']
    
    #difference
    combined_group['VWAP_Value_Difference'] = (combined_group['wtVWAP_vs_AvgPx']*combined_group['wt_VWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP_Value_Difference'] = (combined_group['wtPWP_vs_AvgPx']*combined_group['wt_PWP']*combined_group['QuantityExecuted'])/10000
    combined_group['ArrPx_Value_Difference'] = (combined_group['wtArrPx_vs_AvgPx']*combined_group['ArrivalPrice']*combined_group['QuantityExecuted'])/10000
    combined_group['dayVWAP_Value_Difference'] = (combined_group['wtdayVWAP_vs_AvgPx']*combined_group['wt_dayvwap']*combined_group['QuantityExecuted'])/10000
    combined_group[['wtArrPx_vs_AvgPx','wtPWP_vs_AvgPx','wtVWAP_vs_AvgPx','ArrPx_Value_Difference','PWP_Value_Difference','VWAP_Value_Difference','wtdayVWAP_vs_AvgPx','dayVWAP_Value_Difference','wt_dayvwap','percent_day_vol','percent_interval_vol']]=combined_group[['wtArrPx_vs_AvgPx','wtPWP_vs_AvgPx','wtVWAP_vs_AvgPx','ArrPx_Value_Difference','PWP_Value_Difference','VWAP_Value_Difference','wtdayVWAP_vs_AvgPx','dayVWAP_Value_Difference','wt_dayvwap','percent_day_vol','percent_interval_vol']].astype(float).round(4)
    combined_group.reset_index(drop=True,inplace=True)
    combined_group["StartTime"]=pd.to_datetime(combined_group["StartTime"])
    combined_group["EndTime"]=pd.to_datetime(combined_group["EndTime"])
    combined_group["Starttime"]=combined_group["StartTime"].dt.time
    combined_group["Endtime"]=combined_group["EndTime"].dt.time
    combined_group["TradeDate"]=combined_group["StartTime"].dt.date
    combined_group[["Starttime","Endtime"]]=combined_group[["Starttime","Endtime"]].astype(str)
    
    return combined_group

def final_output(combined_group):
    '''function to get the final dataframe'''
    df_summary=pd.read_excel('output_20191015.xlsx',sheet_name='summary_report')
    df_sample=pd.DataFrame(columns=["Security","Trade Date","Side","Order Type","Start - End Time","Shares","Total Value","Avg Trade Price","% from Interval VWAP","Interval VWAP Price","VWAP Value Difference","% from Arrival","Arrival Price","ArrPx Value Difference","% from Full Day VWAP","Full Day VWAP Price","DayVwap Value Difference","% of Day's Volume","% Interval Volume","% from PWP20","PWP20","PWP Value Difference","% from nearest PWP","PWP (rounded to nearest 5 of % Interval Vol)","Exchange","Tag1"])
    df_sample["Security"]=df_summary["Symbol"]
    df_sample["Side"]=df_summary["Side"]
    df_sample["Order Type"]="Limit"
    df_sample["Shares"]=df_summary["QuantityExecuted"]
    df_sample["Total Value"]=df_summary["QuantityExecuted"]*df_summary["wt AvgPx"]
    df_sample["Avg Trade Price"]=df_summary["wt AvgPx"]
    df_sample["Arrival Price"]=df_summary["ArrivalPrice"]
    df_sample["Interval VWAP Price"]=df_summary["wt VWAP"]
    df_sample["Full Day VWAP Price"]=combined_group["wt_dayvwap"]
    df_sample["PWP20"]=df_summary["wt PWP"]
    df_sample["VWAP Value Difference"]=df_summary["VWAP Value Difference"]
    df_sample["ArrPx Value Difference"]=df_summary["ArrPx Value Difference"]
    df_sample["PWP Value Difference"]=df_summary["PWP Value Difference"]
    df_sample["DayVwap Value Difference"]=combined_group["dayVWAP_Value_Difference"]
    df_sample["% of Day's Volume"]=combined_group["percent_day_vol"]
    df_sample["% Interval Volume"]=combined_group["percent_interval_vol"]
    df_sample["Start - End Time"]=combined_group["Starttime"]+'-'+combined_group["Endtime"]
    df_sample["Trade Date"]=combined_group["TradeDate"]
    
    df_sample["% from Interval VWAP"]=combined_group["wtdayVWAP_vs_AvgPx"]
    df_sample["% from Arrival"]=combined_group["wtArrPx_vs_AvgPx"]
    df_sample["% from PWP20"]=combined_group["wtPWP_vs_AvgPx"]
    df_sample["% from Full Day VWAP"]=combined_group["wtdayVWAP_vs_AvgPx"]
    df_sample=df_sample[["Security","Trade Date","Side","Order Type","Start - End Time","Shares","Total Value","Avg Trade Price","% from Interval VWAP","Interval VWAP Price","VWAP Value Difference","% from Arrival","Arrival Price","ArrPx Value Difference","% from Full Day VWAP","Full Day VWAP Price","DayVwap Value Difference","% of Day's Volume","% Interval Volume","% from PWP20","PWP20","PWP Value Difference","% from nearest PWP","PWP (rounded to nearest 5 of % Interval Vol)","Exchange","Tag1"]]
    df_sample['% from nearest PWP']=0 #add here
    df_sample['PWP (rounded to nearest 5 of % Interval Vol)']=0 #add here
    df_sample['Tag1']=0 #add here
    df_sample['Exchange']=combined_group["SecurityExchange"]
    c1=df_sample[['% from Interval VWAP','VWAP Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['% from Interval VWAP','VWAP Value Difference']), axis=1)
    c2=df_sample[['% from Full Day VWAP','DayVwap Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['% from Full Day VWAP','DayVwap Value Difference']), axis=1)
    c3=df_sample[['% from PWP20','PWP Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['% from PWP20','PWP Value Difference']), axis=1)
    c4=df_sample[['% from Arrival','ArrPx Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['% from Arrival','ArrPx Value Difference']), axis=1)
    df_sample["% of Day's Volume"]=df_sample["% of Day's Volume"]*100
    df_sample["% Interval Volume"]=df_sample["% Interval Volume"]*100
    c5=df_sample[["% of Day's Volume"]].style.applymap(color_r_g_b,subset=["% of Day's Volume"])
    c6=df_sample[["% Interval Volume"]].style.applymap(color_r_g_b,subset=["% Interval Volume"])
    c7=df_sample[['% from nearest PWP','PWP (rounded to nearest 5 of % Interval Vol)']].style.apply(lambda x: highlight_vals_c1(x, cols=['% from nearest PWP','PWP (rounded to nearest 5 of % Interval Vol)']), axis=1)

    return df_sample,c1,c2,c3,c4,c5,c6,c7

def output_excel(df_sample,c1,c2,c3,c4,c5,c6,c7):
    writer = pd.ExcelWriter('final.xlsx',engine='xlsxwriter')
    workbook=writer.book
    worksheet=workbook.add_worksheet('Result')
    writer.sheets['Result'] = worksheet
    df_sample.to_excel(writer,sheet_name='Result',startrow=0,startcol=0,index=False,header=True)    
    c1.to_excel(writer,sheet_name='Result',startrow=0,startcol=8,index=False,header=True)       
    c4.to_excel(writer,sheet_name='Result',startrow=0,startcol=11,index=False,header=True)       
    c2.to_excel(writer,sheet_name='Result',startrow=0,startcol=14,index=False,header=True)       
    c5.to_excel(writer,sheet_name='Result',startrow=0,startcol=17,index=False,header=True)       
    c6.to_excel(writer,sheet_name='Result',startrow=0,startcol=18,index=False,header=True)       
    c3.to_excel(writer,sheet_name='Result',startrow=0,startcol=19,index=False,header=True)       
    c7.to_excel(writer,sheet_name='Result',startrow=0,startcol=21,index=False,header=True)
    writer.save()
    writer.close()
    
def main():
    df=get_combine_op()
    df_sample,c1,c2,c3,c4,c5,c6,c7=final_output(df)
    output_excel(df_sample,c1,c2,c3,c4,c5,c6,c7)
main()
