
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 15:57:53 2022

@author: backup
"""

import numpy as np
import time    
import pandas as pd  
import os
import datetime
import sys
data_dir=r'\\172.17.9.22\Users\krishna\geeta\order_trade\ORD'

user_id=pd.read_csv(os.path.join(data_dir,"Client_ctcl_codes.csv"))
nse_id=user_id['NSE-CM']

def reading_order_trade_files(date,nse_id):
        df1=pd.read_csv(os.path.join(data_dir,"CM_ORD_LOG_{}_08081.CSV.gz".format(date)),compression='gzip')#,chunksize=1000000) 
        #chunk=pd.read_csv(r"\\172.17.9.22\Users\krishna\geeta\order_trade\ORD\CM_ORD_LOG_24082022_08081.CSV.gz",compression='gzip')#,chunksize=1000000) 
        
        #df1=pd.concat(chunk)
        
        df1.columns=['Trading_Member_ID', 'Branch_ID', 'User_ID', 'Market_Type', 'Book_Type', \
                     'OnStop_Indicator', 'Order_Number', 'Buy_Sell_Indicator', 'Symbol', 'Series', \
                    'Volume_Original', 'Volume_Disclosed', 'Volume_Disclosed_Remaining', 'Min_Fill_All_Or_None', \
                    'Market_Indicator', 'Limit_Price', 'Trigger_Price', 'Pro_Cli_Indicator', 'Client_AC_Number', \
                    'Volume_Remaining', 'Special_Term', 'Good_Till_Date', 'Day_Indicator', 'Participant_Id', \
                    'Time', 'Activity_Type', 'Location_ID']#, 'Serial_No']
        
        
        
        
        #df1_alphnum=df1[df1['Client_AC_Number'].str.isnumeric==True]
        df1['Limit_Price']=pd.to_numeric(df1['Limit_Price'], errors='coerce').fillna(0.0,downcast='infer')
        
        
        
        non_numeric_columns = list(set(df1.columns)-set(df1._get_numeric_data().columns))
        for i in non_numeric_columns:
            df1[i] = df1[i].apply(lambda x : str(x).strip()) 
               
            
       
           
        bkc_df=df1[df1['User_ID'].isin(nse_id.tolist())]
        d1=date[4:8]+"-"+date[2:4]+"-"+date[0:2]
        cm_trade=pd.read_csv(os.path.join(data_dir,"nsecm_bkcapi_{}.txt".format(d1)),sep=',',skiprows=None,header=None)
        #cm_trade=pd.read_csv(os.path.join(data_dir,"nsecm_bkcapi.txt"),sep=',',skiprows=None,header=None)
        cm_trade.columns=['TradeId','TradeStatus','Symbol','Series','SecurityName','InstrumentType','BookType',
                                           'MarketType','UserId','BranchId','Side','Quantity','Average','ProClient','Account','CpCode',
                                           'AuctionPartType','AuctionNo','SellPeriod','TradeTime','TradeModificationTime','ExchangeOdrId',
                                           'CounterPartyId','OrderEntryTime','CTCL code']
        cm_trade = cm_trade[cm_trade['TradeStatus']==11]
        
        
        
        cm_trade=cm_trade[cm_trade['UserId'].isin(nse_id.tolist())]
        non_numeric_columns = list(set(cm_trade.columns)-set(cm_trade._get_numeric_data().columns))
        for i in non_numeric_columns:
            cm_trade[i] = cm_trade[i].apply(lambda x : str(x).strip())  
            
        return bkc_df,cm_trade

def order_handling(grp):
    
    new_ord=grp[grp['Activity_Type']==''] #BLANK IS ONEW
    n=len(new_ord)
    if n!=0:
        new_ord['order_value']=new_ord['Limit_Price']*new_ord['Volume_Original']
        nov=new_ord['order_value'].sum()
    else:
        nov=0.0        
    mod_ord=grp[grp['Activity_Type']=='OMOD']
    m=len(mod_ord)
    if m!=0:
       mod_ord['order_value']=mod_ord['Limit_Price']*mod_ord['Volume_Original']
       mov=mod_ord['order_value'].sum()
    else:
       mov=0.0       
    cancel_ord=grp[grp['Activity_Type']=='OCXL']
    c=len(cancel_ord)
    if c!=0:
       cancel_ord['order_value']=cancel_ord['Limit_Price']*cancel_ord['Volume_Original']
       cov=cancel_ord['order_value'].sum()
    else:
        cov=0.0
   
    return pd.Series({'ExpiryDate':np.nan,
                      'OptionType':np.nan,
                      'StrikePrice':np.nan,
                      'Count_newOrders':n,
                      'Count_modOrders':m,
                      'Count_cancelOrders':c,
                      'New_orderValue':nov,
                      'Mod_orderValue':mov,
                      'Cancel_orderValue':cov})



def generating_data(bkc_df,cm_trade,date):
        order_df = bkc_df.groupby(by=['Client_AC_Number','Symbol','User_ID','Series','Location_ID']).apply(lambda grp:
                            order_handling(grp)).reset_index()
        
        
        trades_df = cm_trade.groupby(by=['Account','Symbol','UserId','Series','CTCL code']).apply(lambda grp:
                        pd.Series({
                                'trade_count': len(grp),
                                'trade_qty':grp['Quantity'].sum(),
                                'trade_value': np.sum(grp['Average']*grp['Quantity']),
                                })).reset_index()
        
        
        final1 = (order_df.groupby(by=['Client_AC_Number','Symbol','Series']).apply(lambda grp: pd.Series({
                            'ExpiryDate':np.nan, 'OptionType':np.nan, 'StrikePrice':np.nan,
                            'Count_newOrders': grp['Count_newOrders'].sum(),
                            'Count_modOrders':grp['Count_modOrders'].sum(),
                            'Count_cancelOrders':grp['Count_cancelOrders'].sum(),
                            'New_orderValue':grp['New_orderValue'].sum(),
                            'Mod_orderValue':grp['Mod_orderValue'].sum(),
                            'Cancel_orderValue':grp['Cancel_orderValue'].sum()})).reset_index().rename(columns={'Client_AC_Number':'Account'})).merge(
                trades_df.groupby(by=['Account','Symbol','Series']).apply(lambda grp:
                    pd.Series({
                    'trade_count': np.sum(grp['trade_count']),
                    'trade_qty': np.sum(grp['trade_qty']),
                    'trade_value': np.sum(grp['trade_value']),
                    })).reset_index(), on=['Account','Symbol','Series'], how="outer")
    

        final2 = (order_df.groupby(by=['Client_AC_Number','Symbol','Series','User_ID','Location_ID']).apply(lambda grp: pd.Series({
                            'ExpiryDate':np.nan, 'OptionType':np.nan, 'StrikePrice':np.nan,
                            'Count_newOrders': grp['Count_newOrders'].sum(),
                            'Count_modOrders':grp['Count_modOrders'].sum(),
                            'Count_cancelOrders':grp['Count_cancelOrders'].sum(),
                            'New_orderValue':grp['New_orderValue'].sum(),
                            'Mod_orderValue':grp['Mod_orderValue'].sum(),
                            'Cancel_orderValue':grp['Cancel_orderValue'].sum()})).reset_index().rename(columns={'Client_AC_Number':'Account',
                            'User_ID':'UserId','Location_ID':'CTCL code'})).merge(
        trades_df.groupby(by=['Account','Symbol','Series','UserId','CTCL code']).apply(lambda grp:
                    pd.Series({
                    'trade_count': np.sum(grp['trade_count']),
                    'trade_qty': np.sum(grp['trade_qty']),
                    'trade_value': np.sum(grp['trade_value']),
                    })).reset_index(), on=['Account','Symbol','Series','UserId','CTCL code'], how="outer")
    
        final1["Order_Trade_Ratio"]=(final1['New_orderValue']+final1['Mod_orderValue']+final1['Cancel_orderValue'])/final1['trade_value']
        final2["Order_Trade_Ratio"]=(final2['New_orderValue']+final2['Mod_orderValue']+final2['Cancel_orderValue'])/final2['trade_value']
        final1=final1.rename(columns={'Account':'UCC','ExpiryDate':'Expiry','OptionType':'Call/Put','StrikePrice':'Strike','Count_newOrders':'Count of Orders Entered','Count_modOrders':'Count of Orders Modified','Count_cancelOrders':'Count of Orders Cancelled','New_orderValue':'Original Order Value (entry)',
                              'Mod_orderValue':'Modified Order Value','Cancel_orderValue':'Cancelled Order Value','trade_count':'Count of Trade','trade_qty':'Trade Qty','trade_value':'Trade Value','Order_Trade_Ratio':'Order Trade Ratio in Value Terms'})
			
        final2=final2.rename(columns={'Account':'UCC','ExpiryDate':'Expiry','OptionType':'Call/Put','StrikePrice':'Strike','Count_newOrders':'Count of Orders Entered','Count_modOrders':'Count of Orders Modified','Count_cancelOrders':'Count of Orders Cancelled','New_orderValue':'Original Order Value (entry)',
                              'Mod_orderValue':'Modified Order Value','Cancel_orderValue':'Cancelled Order Value','trade_count':'Count of Trade','trade_qty':'Trade Qty','trade_value':'Trade Value','Order_Trade_Ratio':'Order Trade Ratio in Value Terms','CTCL code':'NNF Code'})
			
        final2['NNF Code']=final2['NNF Code'].astype(str)

        value_columns = ['Count of Orders Entered','Count of Orders Modified','Count of Orders Cancelled','Original Order Value (entry)','Modified Order Value','Cancelled Order Value','Count of Trade','Trade Qty','Trade Value','Order Trade Ratio in Value Terms']  
        for i in value_columns:
            final1[i]=final1[i].fillna(0.0)
            final2[i]=final2[i].fillna(0.0)
            
            final1[i]=final1[i].round(2)
            final2[i]=final2[i].round(2)
                


        writer = pd.ExcelWriter(os.path.join(data_dir,"OrderTradedata_cm_{}.xlsx".format(date)), engine='xlsxwriter')
        final1.to_excel(writer, sheet_name='sheet1',index=False)
        final2.to_excel(writer, sheet_name='sheet2',index=False)
        writer.save()

def main():
   # date=input("Enter the date- ")
    date=sys.argv[1]
    bkc_df,cm_trade=reading_order_trade_files(date,nse_id)
    generating_data(bkc_df,cm_trade,date)
    print("file generated for {}".format(date))
    
main()    
    
#    
#     file_list=[f for f in os.listdir(data_dir) if f.startswith("CM_ORD")]    
#     for  f in file_list:
#        d="{}".format(f[11:-13])
#        bkc_df,cm_trade=reading_order_trade_files(f,d,nse_id)
#        generating_data(bkc_df,cm_trade,d)
#        print("file generated for {}".format(d))
#       
        
        
        
        