#import libraires
import logging,datetime,psycopg2
import pandas as pd
import numpy as np
from sqlalchemy import create_engine

'''data paths'''
master_dir='D:\\devansh\\'

'''function to style columns of a dataframe'''
def highlight_vals_c1(row, cols):
    a1,a2= cols
    styles = {col: '' for col in row.index}
    
    if row[a1] >= 0 and row[a2] >= 0:
    
        styles[a1] = 'background-color: %s' % '#98fb98'
        styles[a2] = 'background-color: %s' % '#98fb98'
    
    else:
        
        styles[a1] = 'background-color: %s' % '#FF9999'
        styles[a2] = 'background-color: %s' % '#FF9999'
   
    return styles

'''function to generate summary report'''

def color_r_g_b(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    if val > 25:
        color = '#98fb98' 
    elif val>=20 and val<=25:
        color='blue' 
    else:
        color='#FF9999'
    return 'background-color: %s' % color

'''function to get the output in required excel format'''
def get_tca_split(d):
    #tca=pd.read_excel(master_dir+"output_{}.xlsx".format(d.strftime('%Y%m%d')),sheet_name='complete_output')#read file
    tca=pd.read_excel(master_dir+"output_20191015.xlsx",sheet_name='complete_output')
    #add column names to the newlist
    newlist=[]
    newlist=tca.columns
    
    #get column name ends with bse and nse and append them to the respective list
    bselist=[]
    nselist=[]
    for i in range(0,len(newlist)):
        if newlist[i].endswith('Bse'):
            bselist.append(newlist[i])
        if newlist[i].endswith('Nse'):
            nselist.append(newlist[i])
    
    #create pairlist and append row to it based on sor is y or n and security exchange is bse or nse
    pairlist=[]
    for col,row in tca.iterrows():
        if row["SOR"]=="Y":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType',
                        'LimitPrice','Side','SecurityExchange','StartTime','EndTime','OrderQty','SOR','NSEExecutedQty',
                        'NSEExecutedQty','NSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapNse','IntervalVwapLimitNse','DayVwapLimitNse','DayVwapNse','DayTwapNse','IntervalTwapNse',
                        'IntervalTwapLimitNse','DayTwapLimitNse','PwpNse','PwpLimitNse','AvgTradeSizeNse','IntervalVolNse',
                        'IntervalVolLimitNse','DayVolNse','DayVolLimitNse','volExecNse_intervalVolNse',
                        'volExecNse_intervalVolLimitNse','volExecNse_DayVolNse','volExecNse_DayVolLimitNse','ArrivalPrice']]
            result["SecurityExchange"]="NSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result) 
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                        'SecurityExchange','StartTime','EndTime','OrderQty','SOR','BSEExecutedQty','BSEExecutedQty',
                        'BSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapBse','IntervalVwapLimitBse','DayVwapLimitBse','DayVwapBse','DayTwapBse','IntervalTwapBse',
                        'IntervalTwapLimitBse','DayTwapLimitBse','PwpBse','PwpLimitBse','AvgTradeSizeBse','IntervalVolBse',
                        'IntervalVolLimitBse','DayVolBse','DayVolLimitBse','volExecBse_intervalVolBse','volExecBse_intervalVolLimitBse',
                        'volExecBse_DayVolBse', 'volExecBse_DayVolLimitBse','ArrivalPrice']]
            result["SecurityExchange"]="BSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
        
        if row["SOR"]=='N' and row["SecurityExchange"]=="NSE":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType',
                        'LimitPrice','Side','SecurityExchange','StartTime','EndTime','OrderQty','SOR','NSEExecutedQty',
                        'NSEExecutedQty','NSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapNse','IntervalVwapLimitNse','DayVwapLimitNse','DayVwapNse','DayTwapNse','IntervalTwapNse',
                        'IntervalTwapLimitNse','DayTwapLimitNse','PwpNse','PwpLimitNse','AvgTradeSizeNse','IntervalVolNse',
                        'IntervalVolLimitNse','DayVolNse','DayVolLimitNse','volExecNse_intervalVolNse',
                        'volExecNse_intervalVolLimitNse','volExecNse_DayVolNse','volExecNse_DayVolLimitNse','ArrivalPrice']]
            result["SecurityExchange"]="NSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
    
        if row["SOR"]=='N' and row["SecurityExchange"]=="BSE":
            result=row[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                        'SecurityExchange','StartTime','EndTime','OrderQty','SOR','BSEExecutedQty','BSEExecutedQty',
                        'BSEExecutedAvg','Remarks','Algorithm','LastFillTime','ArrivalTime',
                        'IntervalVwapBse','IntervalVwapLimitBse','DayVwapLimitBse','DayVwapBse','DayTwapBse','IntervalTwapBse',
                        'IntervalTwapLimitBse','DayTwapLimitBse','PwpBse','PwpLimitBse','AvgTradeSizeBse','IntervalVolBse',
                        'IntervalVolLimitBse','DayVolBse','DayVolLimitBse','volExecBse_intervalVolBse','volExecBse_intervalVolLimitBse',
                        'volExecBse_DayVolBse', 'volExecBse_DayVolLimitBse','ArrivalPrice']]
            result["SecurityExchange"]="BSE"
            result.reset_index(drop=True,inplace=True)
            result=result.T
            pairlist.append(result)
            
    final_df=pd.DataFrame(pairlist)
    final_df.columns=['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                      'SecurityExchange','StartTime','EndTime','OrderQty','SOR','QuantityExecuted','ExecutedQty',
                      'AvgPx','Remarks','Algorithm','LastFillTime','ArrivalTime',
                      'IntervalVwap','IntervalVwapLimit','DayVwapLimit','DayVwap','DayTwap','IntervalTwap',
                      'IntervalTwapLimit','DayTwapLimit','Pwp','PwpLimit','AvgTradeSize','IntervalVol',
                      'IntervalVolLimit','DayVol','DayVolLimit','volExec_intervalVol','volExec_intervalVolLimit',
                      'volExec_DayVol','volExec_DayVolLimit','ArrivalPrice']
    
    '''create two dataframes one for summary calculation other to write in excel'''
    
    final_df_r=final_df[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                      'SecurityExchange','StartTime','EndTime','OrderQty','SOR','QuantityExecuted','ExecutedQty',
                      'AvgPx','Remarks','Algorithm','LastFillTime','ArrivalTime',
                      'IntervalVwap','IntervalVwapLimit','DayVwapLimit','DayVwap','DayTwap','IntervalTwap',
                      'IntervalTwapLimit','DayTwapLimit','Pwp','PwpLimit','AvgTradeSize','IntervalVol',
                      'IntervalVolLimit','DayVol','DayVolLimit','volExec_intervalVol','volExec_intervalVolLimit',
                      'volExec_DayVol','volExec_DayVolLimit','ArrivalPrice']]
    
    final_write=final_df[['TradeId','ClientOrdID','Og_ClientOrdID','ClientName','Symbol','Series','Ticker','OrdType','LimitPrice','Side',
                      'SecurityExchange','StartTime','EndTime','OrderQty','SOR','QuantityExecuted','ExecutedQty',
                      'AvgPx','Remarks','Algorithm','LastFillTime','ArrivalTime',
                      'IntervalVwap','IntervalVwapLimit','DayVwapLimit','DayVwap','DayTwap','IntervalTwap',
                      'IntervalTwapLimit','DayTwapLimit','Pwp','PwpLimit','AvgTradeSize','IntervalVol',
                      'IntervalVolLimit','DayVol','DayVolLimit','volExec_intervalVol','volExec_intervalVolLimit',
                      'volExec_DayVol','volExec_DayVolLimit','ArrivalPrice']]
    
    final_df_r.reset_index(drop=True,inplace=True)
    final_write.reset_index(drop=True,inplace=True)
    
    return final_df_r,final_write



def generate_summary(df,final_write,d):
    
    final_write["TAG1"]='' #add tag 1 information here
    
    df['Start Time'] = pd.to_datetime(df['StartTime'])
    df['Date'] = df['Start Time']
    df['values'] = df['AvgPx']*df['QuantityExecuted']
    df['VWAPvalues'] = df['IntervalVwapLimit']*df['IntervalVolLimit']
    df['TWAPvalues'] = df['IntervalTwapLimit']*df['IntervalVolLimit']
    df['PWPvalues'] = df['PwpLimit']*df['IntervalVolLimit']
    df['uniquetdse'] = df['TradeId']+df['SecurityExchange']
    
    df = df[df['QuantityExecuted']!=0]
    
    combined_group = df.groupby('uniquetdse', as_index=False).agg({'IntervalVolLimit':'sum','QuantityExecuted':'sum','values':'sum', 'VWAPvalues':'sum', 'TWAPvalues':'sum', 'PWPvalues':'sum','TradeId':'first', 'SecurityExchange':'first','Date':'first', 'ClientName':'first', 'Symbol':'first', 'Side':'first', 'ArrivalPrice':'first'})
    print combined_group
    combined_group['wt_AvgPx'] = combined_group['values']/combined_group['QuantityExecuted']
    combined_group['wt_VWAP'] = combined_group['VWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_TWAP'] = combined_group['TWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_PWP'] = combined_group['PWPvalues']/combined_group['IntervalVolLimit']
    combined_group.fillna(0, inplace=True)
    combined_group.sort_values(by='Date', inplace=True)
    combined_group.drop(['values', 'VWAPvalues', 'TWAPvalues', 'PWPvalues'], axis=1, inplace=True)

    # calculating parameters
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
    combined_group['wtTWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_TWAP'])/combined_group['wt_TWAP'])*10000
    combined_group['wtPWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_PWP'])/combined_group['wt_PWP'])*10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice'])/combined_group['ArrivalPrice'])*10000
    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)

    # BUY side parameters
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtTWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtPWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtArrPx_vs_AvgPx']

    # SELL side parameters
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_TWAP'] != 0), 'wtTWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtTWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtPWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtArrPx_vs_AvgPx']

    # Difference parameters
    combined_group['VWAP_Value_Difference'] = (combined_group['wtVWAP_vs_AvgPx']*combined_group['wt_VWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['TWAP_Value_Difference'] = (combined_group['wtTWAP_vs_AvgPx']*combined_group['wt_TWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP_Value_Difference'] = (combined_group['wtPWP_vs_AvgPx']*combined_group['wt_PWP']*combined_group['QuantityExecuted'])/10000
    combined_group['ArrPx_Value_Difference'] = (combined_group['wtArrPx_vs_AvgPx']*combined_group['ArrivalPrice']*combined_group['QuantityExecuted'])/10000
    
    combined_group = combined_group[['TradeId','SecurityExchange','ClientName','QuantityExecuted', 'Symbol', 'Side', 'Date', 'wt_AvgPx', 'wt_VWAP', 'wtVWAP_vs_AvgPx', 'VWAP_Value_Difference', 'wt_TWAP', 'wtTWAP_vs_AvgPx', 'TWAP_Value_Difference', 'wt_PWP', 'wtPWP_vs_AvgPx', 'PWP_Value_Difference', 'ArrivalPrice', 'wtArrPx_vs_AvgPx', 'ArrPx_Value_Difference']]
    combined_group[['wt_AvgPx', 'wt_VWAP', 'wtVWAP_vs_AvgPx', 'VWAP_Value_Difference', 'wt_TWAP', 'wtTWAP_vs_AvgPx', 'TWAP_Value_Difference', 'wt_PWP', 'wtPWP_vs_AvgPx', 'PWP_Value_Difference', 'ArrivalPrice', 'wtArrPx_vs_AvgPx', 'ArrPx_Value_Difference']]=combined_group[['wt_AvgPx', 'wt_VWAP', 'wtVWAP_vs_AvgPx', 'VWAP_Value_Difference', 'wt_TWAP', 'wtTWAP_vs_AvgPx', 'TWAP_Value_Difference', 'wt_PWP', 'wtPWP_vs_AvgPx', 'PWP_Value_Difference', 'ArrivalPrice', 'wtArrPx_vs_AvgPx', 'ArrPx_Value_Difference']].astype(float).round(4)
    combined_group.columns = combined_group.columns.str.replace('_',' ')
    
    c1=combined_group[['wtVWAP vs AvgPx','VWAP Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['wtVWAP vs AvgPx','VWAP Value Difference']), axis=1)
    c2=combined_group[['wtTWAP vs AvgPx','TWAP Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['wtTWAP vs AvgPx','TWAP Value Difference']), axis=1)
    c3=combined_group[['wtPWP vs AvgPx','PWP Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['wtPWP vs AvgPx','PWP Value Difference']), axis=1)
    c4=combined_group[['wtArrPx vs AvgPx','ArrPx Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['wtArrPx vs AvgPx','ArrPx Value Difference']), axis=1)
    
    o1=combined_group[['TradeId','ClientName','QuantityExecuted','Symbol','Side','Date','SecurityExchange','wt AvgPx','wt VWAP']]
    o2=combined_group[['wt TWAP']]
    o3=combined_group[['wt PWP']]
    o4=combined_group[['ArrivalPrice']]
    
    writer = pd.ExcelWriter(master_dir+'final_tca_split_{}.xlsx'.format(d.strftime('%Y%m%d')),engine='xlsxwriter')

    final_write.to_excel(writer,sheet_name='complete_output',startrow=0 , startcol=0,index=False)
    
    o1.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=0,index=False)
    c1.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=9,index=False)

    o2.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=11,index=False)
    c2.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=12,index=False)

    o3.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=14,index=False)
    c3.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=15,index=False)

    o4.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=17,index=False)
    c4.to_excel(writer,sheet_name='summary_report',startrow=0 , startcol=18,index=False)

    writer.save()
    writer.close()
    
#    return combined_group

def dump_postgress(d):
    # log events in debug mode 
    logging.basicConfig(filename="TCA_update.log",
                            level=logging.DEBUG,
                            format="%(asctime)s:%(levelname)s:%(message)s")

    df=pd.read_excel(master_dir+'final_tca_split_{}.xlsx'.format(d.strftime('%Y%m%d')),sheetname="complete_output")
#     df["Tag1"]="TAG1"
    df["unique_id"]=df["TradeId"]+df["SecurityExchange"]
    df['Start Time'] = pd.to_datetime(df['StartTime'])
    df['tcadate']= df["Start Time"].dt.date
    '''uncomment below code if creating the table for first time or else dont make any changes'''
    # Connect to database (Note: The package psychopg2 is required for Postgres to work with SQLAlchemy)
    try: 
        conn = psycopg2.connect(dbname='NSE-FNO',
                     user='postgres',
                     password='kotak@123', 
                     host='172.17.9.182', 
                     port='5432')
    except:
        print("I am unable to connect to the database") 

    cur = conn.cursor()
    try:
        cur.execute("CREATE TABLE TCA_split (unique_id varchar PRIMARY KEY,tcadate Date, TradeId varchar,ClientOrdID varchar,Og_ClientOrdID varchar,ClientName varchar,Symbol varchar,Series char,Ticker char,OrdType char,LimitPrice float,Side char,SecurityExchange char,StartTime varchar,EndTime varchar,OrderQty float,SOR char,QuantityExecuted float,AvgPx float,NSEExecutedQty float,BSEExecutedQty float,NSEExecutedAvg float,BSEExecutedAvg float,Remarks char,Algorithm varchar,LastFillTime varchar,ArrivalTime varchar,IntervalVwap float,IntervalVwapNse float,IntervalVwapBse float,IntervalVwapLimit float,AvgPx_vs_IntervalVwapLimit float,IntervalVwapLimitNse float,IntervalVwapLimitBse float,DayVwapLimitNse float,DayVwapLimitBse float,DayVwapLimit float,DayVwap float,DayVwapNse float,DayVwapBse float,DayTwap float,DayTwapNse float,DayTwapBse float,IntervalTwap float,IntervalTwapNse float,IntervalTwapBse float,IntervalTwapLimit float,AvgPx_vs_IntervalTwapLimit float,IntervalTwapLimitNse float,IntervalTwapLimitBse float,DayTwapLimit float,DayTwapLimitNse float,DayTwapLimitBse float,AvgPx_vs_IntervalVwap float,AvgPx_vs_DayVwap float,AvgPx_vs_DayVwapLimit float,AvgPx_vs_IntervalTwap float,AvgPx_vs_DayTwap float,AvgPx_vs_DayTwapLimit float,AvgPx_vs_Pwp float,PwpNse float,PwpBse float,Pwp float,PwpLimit float,AvgPx_vs_PwpLimit float,PwpLimitNse float,PwpLimitBse float,AvgTradeSizeNse float,AvgTradeSizeBse float,AvgTradeSize float,IntervalVolNse float,IntervalVolBse float,IntervalVol float,IntervalVolLimitNse float,IntervalVolLimitBse float,IntervalVolLimit float,DayVolNse float,DayVolBse float,DayVol float,DayVolLimitNse float,DayVolLimitBse float,DayVolLimit float,volExecNse_intervalVolNse float,volExecBse_intervalVolBse float,volExec_vs_IntervalVol float,volExecNse_intervalVolLimitNse float,volExecBse_intervalVolLimitBse float,volExec_vs_IntervalVolLimit float,volExecNse_DayVolNse float,volExecBse_DayVolBse float,volExec_vs_DayVol float,volExecNse_DayVolLimitNse float,volExecBse_DayVolLimitBse float,volExec_vs_DayVolLimit float,ArrivalPriceNse float,ArrivalPriceBse float,ArrivalPrice float,AvgPx_vs_ArrivalPx float,Tag1 varchar);")
    except:
         print("database is already created you can drop it if you want to create new!")

    conn.commit() # <--- makes sure the change is shown in the database
    conn.close()
    cur.close()

    #copy data from dataframe to postgress
    dbname="NSE-FNO"
    user="postgres"
    password="kotak@123"
    ip="172.17.9.182"
    port="5432"
    engine = create_engine('postgresql://'+user+':'+password+'@'+ip+':'+port+'/'+dbname,echo=False) #create connection 
    con = engine.connect()
    df.columns = df.columns.str.lower()
    df.columns=['unique_id','tcadate','tradeid','clientordid','og_clientordid','clientname','symbol','series','ticker','ordtype','limitprice','side','securityexchange','starttime','endtime','orderqty','sor','quantityexecuted','avgpx','nseexecutedqty','bseexecutedqty','nseexecutedavg','bseexecutedavg','remarks','algorithm','lastfilltime','arrivaltime','intervalvwap','intervalvwapnse','intervalvwapbse','intervalvwaplimit','avgpx_vs_intervalvwaplimit','intervalvwaplimitnse','intervalvwaplimitbse','dayvwaplimitnse','dayvwaplimitbse','dayvwaplimit','dayvwap','dayvwapnse','dayvwapbse','daytwap','daytwapnse','daytwapbse','intervaltwap','intervaltwapnse','intervaltwapbse','intervaltwaplimit','avgpx_vs_intervaltwaplimit','intervaltwaplimitnse','intervaltwaplimitbse','daytwaplimit','daytwaplimitnse','daytwaplimitbse','avgpx_vs_intervalvwap','avgpx_vs_dayvwap','avgpx_vs_dayvwaplimit','avgpx_vs_intervaltwap','avgpx_vs_daytwap','avgpx_vs_daytwaplimit','avgpx_vs_pwp','pwpnse','pwpbse','pwp','pwplimit','avgpx_vs_pwplimit','pwplimitnse','pwplimitbse','avgtradesizense','avgtradesizebse','avgtradesize','intervalvolnse','intervalvolbse','intervalvol','intervalvollimitnse','intervalvollimitbse','intervalvollimit','dayvolnse','dayvolbse','dayvol','dayvollimitnse','dayvollimitbse','dayvollimit','volexecnse_intervalvolnse','volexecbse_intervalvolbse','volexec_vs_intervalvol','volexecnse_intervalvollimitnse','volexecbse_intervalvollimitbse','volexec_vs_intervalvollimit','volexecnse_dayvolnse','volexecbse_dayvolbse','volexec_vs_dayvol','volexecnse_dayvollimitnse','volexecbse_dayvollimitbse','volexec_vs_dayvollimit','arrivalpricense','arrivalpricebse','arrivalprice','avgpx_vs_arrivalpx','tag1']
    df.to_sql(name='tca_split', con=con, if_exists = 'replace', index=False) #change this replace to append after running it for first time
    #con.commit()
    con.close()
    
def get_postgress_data():
    #get latest date from database
    conn = psycopg2.connect(database="NSE-FNO",
                            user="postgres",
                             password="kotak@123", 
                             host="172.17.9.182", 
                             port="5432")
    cur=conn.cursor()
    r = cur.fetchall()[0][0]
    cur.execute("select * from tca_split where date ='{}';".format(r)) 
    df = cur.fetchall()
    df = pd.DataFrame(df)
    return df

def get_combine_op(df):
    '''processing for Dayvwap and volumelimit and daylimit and dates done in this code'''
#     df=pd.read_excel('output_20191015.xlsx',sheet_name='complete_output')
    df['values'] = df['AvgPx']*df['QuantityExecuted']
    df['VWAPvalues'] = df['IntervalVwapLimit']*df['IntervalVolLimit']
    df['PWPvalues'] = df['PwpLimit']*df['IntervalVolLimit']
    df['Start Time'] = pd.to_datetime(df['StartTime'])
    df['Date'] = df['Start Time']
    df['DayVwapvalues'] = df['DayVwapLimit']*df['DayVolLimit']
    df['percent_day_vol']=df["QuantityExecuted"]/df["DayVolLimit"]
    df['percent_interval_vol']=df["QuantityExecuted"]/df["IntervalVolLimit"]
    df['uniquetdse'] = df['TradeId']+df['SecurityExchange']
    df = df[df['QuantityExecuted']!=0]

    combined_group = df.groupby('uniquetdse', as_index=False).agg({'IntervalVolLimit':'sum','PWPvalues':'sum','VWAPvalues':'sum','DayVwapvalues':'sum','QuantityExecuted':'sum','percent_day_vol':'sum','percent_interval_vol':'sum','TradeId':'first','SecurityExchange':'first','Date':'first','ClientName':'first','Symbol':'first','Side':'first','ArrivalPrice':'first','values':'sum','StartTime':'first','EndTime':'first'})
    # print combined_group
    combined_group['wt_AvgPx'] = combined_group['values']/combined_group['QuantityExecuted']
    combined_group['wt_VWAP'] = combined_group['VWAPvalues']/combined_group['IntervalVolLimit']
    combined_group['wt_dayvwap'] = combined_group['DayVwapvalues']/combined_group['QuantityExecuted']
    combined_group['wt_PWP'] = combined_group['PWPvalues']/combined_group['IntervalVolLimit']
    
    
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
    combined_group['wtPWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_PWP'])/combined_group['wt_PWP'])*10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice'])/combined_group['ArrivalPrice'])*10000
    combined_group.fillna(0, inplace=True)
    combined_group.sort_values(by='Date', inplace=True)
    
    #calculating parameters
    combined_group['wtVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_VWAP'])/combined_group['wt_VWAP'])*10000
    combined_group['wtPWP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_PWP'])/combined_group['wt_PWP'])*10000
    combined_group['wtArrPx_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['ArrivalPrice'])/combined_group['ArrivalPrice'])*10000
    combined_group['wtdayVWAP_vs_AvgPx'] = ((combined_group['wt_AvgPx'] - combined_group['wt_dayvwap'])/combined_group['wt_dayvwap'])*10000
    combined_group.replace([np.inf, -np.inf], np.nan, inplace=True)
    combined_group.fillna(0, inplace=True)
    
    #buy side parameters
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_VWAP'] != 0), 'wtVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtVWAP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_PWP'] != 0), 'wtPWP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtPWP_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['ArrivalPrice'] != 0), 'wtArrPx_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtArrPx_vs_AvgPx']
    combined_group.loc[(combined_group['Side'] == 'BUY') & (combined_group['wt_dayvwap'] != 0), 'wtdayVWAP_vs_AvgPx'] = (-1)*combined_group.loc[combined_group['Side'] == 'BUY', 'wtdayVWAP_vs_AvgPx']
    
    #sell side parameters
    combined_group.loc[(combined_group['Side'] == 'SELL') & (combined_group['wt_dayvwap'] != 0), 'wtdayVWAP_vs_AvgPx'] = combined_group.loc[combined_group['Side'] == 'SELL', 'wtdayVWAP_vs_AvgPx']
    
    #difference
    combined_group['VWAP_Value_Difference'] = (combined_group['wtVWAP_vs_AvgPx']*combined_group['wt_VWAP']*combined_group['QuantityExecuted'])/10000
    combined_group['PWP_Value_Difference'] = (combined_group['wtPWP_vs_AvgPx']*combined_group['wt_PWP']*combined_group['QuantityExecuted'])/10000
    combined_group['ArrPx_Value_Difference'] = (combined_group['wtArrPx_vs_AvgPx']*combined_group['ArrivalPrice']*combined_group['QuantityExecuted'])/10000
    combined_group['dayVWAP_Value_Difference'] = (combined_group['wtdayVWAP_vs_AvgPx']*combined_group['wt_dayvwap']*combined_group['QuantityExecuted'])/10000
    combined_group[['wtArrPx_vs_AvgPx','wtPWP_vs_AvgPx','wtVWAP_vs_AvgPx','ArrPx_Value_Difference','PWP_Value_Difference','VWAP_Value_Difference','wtdayVWAP_vs_AvgPx','dayVWAP_Value_Difference','wt_dayvwap','percent_day_vol','percent_interval_vol']]=combined_group[['wtArrPx_vs_AvgPx','wtPWP_vs_AvgPx','wtVWAP_vs_AvgPx','ArrPx_Value_Difference','PWP_Value_Difference','VWAP_Value_Difference','wtdayVWAP_vs_AvgPx','dayVWAP_Value_Difference','wt_dayvwap','percent_day_vol','percent_interval_vol']].astype(float).round(4)
    combined_group.reset_index(drop=True,inplace=True)
    combined_group["StartTime"]=pd.to_datetime(combined_group["StartTime"])
    combined_group["EndTime"]=pd.to_datetime(combined_group["EndTime"])
    combined_group["Starttime"]=combined_group["StartTime"].dt.time
    combined_group["Endtime"]=combined_group["EndTime"].dt.time
    combined_group["TradeDate"]=combined_group["StartTime"].dt.date
    combined_group[["Starttime","Endtime"]]=combined_group[["Starttime","Endtime"]].astype(str)
    
    return combined_group

def final_output(combined_group):
    '''function to get the final dataframe'''
    df_summary=pd.read_excel('output_20191015.xlsx',sheet_name='summary_report')
    df_sample=pd.DataFrame(columns=["Security","Trade Date","Side","Order Type","Start - End Time","Shares","Total Value","Avg Trade Price","% from Interval VWAP","Interval VWAP Price","VWAP Value Difference","% from Arrival","Arrival Price","ArrPx Value Difference","% from Full Day VWAP","Full Day VWAP Price","DayVwap Value Difference","% of Day's Volume","% Interval Volume","% from PWP20","PWP20","PWP Value Difference","% from nearest PWP","PWP (rounded to nearest 5 of % Interval Vol)","Exchange","Tag1"])
    df_sample["Security"]=df_summary["Symbol"]
    df_sample["Side"]=df_summary["Side"]
    df_sample["Order Type"]="Limit"
    df_sample["Shares"]=df_summary["QuantityExecuted"]
    df_sample["Total Value"]=df_summary["QuantityExecuted"]*df_summary["wt AvgPx"]
    df_sample["Avg Trade Price"]=df_summary["wt AvgPx"]
    df_sample["Arrival Price"]=df_summary["ArrivalPrice"]
    df_sample["Interval VWAP Price"]=df_summary["wt VWAP"]
    df_sample["Full Day VWAP Price"]=combined_group["wt_dayvwap"]
    df_sample["PWP20"]=df_summary["wt PWP"]
    df_sample["VWAP Value Difference"]=df_summary["VWAP Value Difference"]
    df_sample["ArrPx Value Difference"]=df_summary["ArrPx Value Difference"]
    df_sample["PWP Value Difference"]=df_summary["PWP Value Difference"]
    df_sample["DayVwap Value Difference"]=combined_group["dayVWAP_Value_Difference"]
    df_sample["% of Day's Volume"]=combined_group["percent_day_vol"]
    df_sample["% Interval Volume"]=combined_group["percent_interval_vol"]
    df_sample["Start - End Time"]=combined_group["Starttime"]+'-'+combined_group["Endtime"]
    df_sample["Trade Date"]=combined_group["TradeDate"]
    
    df_sample["% from Interval VWAP"]=combined_group["wtdayVWAP_vs_AvgPx"]
    df_sample["% from Arrival"]=combined_group["wtArrPx_vs_AvgPx"]
    df_sample["% from PWP20"]=combined_group["wtPWP_vs_AvgPx"]
    df_sample["% from Full Day VWAP"]=combined_group["wtdayVWAP_vs_AvgPx"]
    df_sample=df_sample[["Security","Trade Date","Side","Order Type","Start - End Time","Shares","Total Value","Avg Trade Price","% from Interval VWAP","Interval VWAP Price","VWAP Value Difference","% from Arrival","Arrival Price","ArrPx Value Difference","% from Full Day VWAP","Full Day VWAP Price","DayVwap Value Difference","% of Day's Volume","% Interval Volume","% from PWP20","PWP20","PWP Value Difference","% from nearest PWP","PWP (rounded to nearest 5 of % Interval Vol)","Exchange","Tag1"]]
    df_sample['% from nearest PWP']=0 #add here
    df_sample['PWP (rounded to nearest 5 of % Interval Vol)']=0 #add here
    df_sample['Tag1']=0 #add here
    df_sample['Exchange']=combined_group["SecurityExchange"]
    c1=df_sample[['% from Interval VWAP','VWAP Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['% from Interval VWAP','VWAP Value Difference']), axis=1)
    c2=df_sample[['% from Full Day VWAP','DayVwap Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['% from Full Day VWAP','DayVwap Value Difference']), axis=1)
    c3=df_sample[['% from PWP20','PWP Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['% from PWP20','PWP Value Difference']), axis=1)
    c4=df_sample[['% from Arrival','ArrPx Value Difference']].style.apply(lambda x: highlight_vals_c1(x, cols=['% from Arrival','ArrPx Value Difference']), axis=1)
    df_sample["% of Day's Volume"]=df_sample["% of Day's Volume"]*100
    df_sample["% Interval Volume"]=df_sample["% Interval Volume"]*100
    c5=df_sample[["% of Day's Volume"]].style.applymap(color_r_g_b,subset=["% of Day's Volume"])
    c6=df_sample[["% Interval Volume"]].style.applymap(color_r_g_b,subset=["% Interval Volume"])
    c7=df_sample[['% from nearest PWP','PWP (rounded to nearest 5 of % Interval Vol)']].style.apply(lambda x: highlight_vals_c1(x, cols=['% from nearest PWP','PWP (rounded to nearest 5 of % Interval Vol)']), axis=1)

    return df_sample,c1,c2,c3,c4,c5,c6,c7

def output_excel(df_sample,c1,c2,c3,c4,c5,c6,c7):
    writer = pd.ExcelWriter('final.xlsx',engine='xlsxwriter')
    workbook=writer.book
    worksheet=workbook.add_worksheet('Result')
    writer.sheets['Result'] = worksheet
    df_sample.to_excel(writer,sheet_name='Result',startrow=0,startcol=0,index=False,header=True)    
    c1.to_excel(writer,sheet_name='Result',startrow=0,startcol=8,index=False,header=True)       
    c4.to_excel(writer,sheet_name='Result',startrow=0,startcol=11,index=False,header=True)       
    c2.to_excel(writer,sheet_name='Result',startrow=0,startcol=14,index=False,header=True)       
    c5.to_excel(writer,sheet_name='Result',startrow=0,startcol=17,index=False,header=True)       
    c6.to_excel(writer,sheet_name='Result',startrow=0,startcol=18,index=False,header=True)       
    c3.to_excel(writer,sheet_name='Result',startrow=0,startcol=19,index=False,header=True)       
    c7.to_excel(writer,sheet_name='Result',startrow=0,startcol=21,index=False,header=True)
    writer.save()
    writer.close()
    
def main():
    d=datetime.datetime.now().date()
    df,final_write=get_tca_split(d) #function to get data and perform processing on it 
    generate_summary(df,final_write,d) #function to generate reports that is complete_output and Summary_report
    dump_postgress(d)#dump data into postgress
    pdf = get_postgress_data() #get the data from postgress
    final_df=get_combine_op(pdf)
    df_sample,c1,c2,c3,c4,c5,c6,c7=final_output(final_df)
    output_excel(df_sample,c1,c2,c3,c4,c5,c6,c7)


main()