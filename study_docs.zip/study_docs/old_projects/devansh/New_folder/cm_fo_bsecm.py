# -*- coding: utf-8 -*-
"""
Created on Tue Sep  6 17:19:55 2022

@author: backup
"""


import os
import time
os.chdir("D:\\devansh\\New_folder")
import cm
import fo
import bse_cm
import smtplib
from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import shutil
import pandas as pd
import datetime
server = '172.17.9.144'; port = 25
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
order_path='/home/hadoop/OrderFile'
file_path='/home/hadoop/pnc_report/datafiles/'
output_path='/home/hadoop/pnc_report/output'
master_dir = "D:\\Data_dumpers\\Master\\"
ctcl_path=''

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails

def email_utility(emails, subject,file_list):
    
    '''Func to send daily report emails excel and text attachment combined'''

        
    # read the message file
   # message = open(file_dir+body_file,'rb').read()
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
    
    
   # attachment = open(data_dir+fname,'rb')
    for fname in file_list:
        print(fname)
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(os.path.join(output_path,fname), "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
        msg.attach(part)   
    
                    
    
 #   msg.attach(MIMEText(message,'plain'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()


def dateparse(date):
    '''Func to parse dates'''
    date = pd.to_datetime(date, dayfirst=True)
    return date


# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)

def process_run_check(d):
    '''Func to check if the process should run on current day or not'''

    if len(holiday_master[holiday_master['date']==d])==0:
        return 1

    elif len(holiday_master[holiday_master['date']==d])==1:
       # logging.info('Holiday: skip for current date :{} '.format(d))
        return -1



def checking_order_files(d1,d2):
    while True:
            if os.path.exists(os.path.join(order_path,'CM_ORD_LOG_{}_08081.CSV.gz'.format(d1))) and os.path.exists(os.path.join(order_path,'FO_ORD_LOG_{}_08081.CSV.gz'.format(d1))):
                 if os.path.exists(os.path.join(file_path,'BO{}.673.zip'.format(d2))):
                      file_list= [f for f in os.listdir(file_path) if f.startswith("CM_ORD")  or  f.startswith("FO_ORD")]
                      for f in file_list:
                          os.remove(os.path.join(file_path,f))
                      time.sleep(5) 
                      shutil.copy(os.path.join(order_path,'CM_ORD_LOG_{}_08081.CSV.gz'.format(d1)),os.path.join(file_path,'CM_ORD_LOG_{}_08081.CSV.gz'.format(d1))) 
                      shutil.copy(os.path.join(order_path,'FO_ORD_LOG_{}_08081.CSV.gz'.format(d1)),os.path.join(file_path,'FO_ORD_LOG_{}_08081.CSV.gz'.format(d1)))
                      time.sleep(5)
                      cm.main(d1,file_path,output_path,ctcl_path)
                      bse_cm.main(d2,file_path,output_path,ctcl_path)
                      fo.main(d1,file_path,output_path,ctcl_path)
                      break
            else:
                 time.sleep(60)
                  

def main(nd):
    d=datetime.datetime.now().date() - datetime.timedelta(days=nd)
    if process_run_check(d)== -1:
        return -1 
    d1=d.strftime("%d%m%Y")
    d2=d.strftime("%d%m%y")
    checking_order_files(d1,d2)
    file_list=["OrderTradedata_bsecm{}.xlsx".format(d2),"OrderTradedata_cm_{}.xlsx".format(d1),"OrderTradedata_fo_{}.xlsx".format(d1)]
    email_utility(get_contacts(os.path.join(output_path,'back.txt')),'ORDER_TRADE_FILES_{}'.format(d), file_list)

if __name__=='__main__':
    main(0)    
    
    
#import zipfile
#with zipfile.ZipFile(r'\\172.17.9.22\Users\krishna\geeta\order_trade\ORD\20220905\BO050922.673.zip', 'r') as zip_ref:
#    zip_ref.extractall(r'\\172.17.9.22\Users\krishna\geeta\order_trade\ORD\20220905')
#
#data_dir=r'\\172.17.9.22\Users\krishna\geeta\order_trade\ORD\data'
#
#for r,d,f in os.walk(data_dir):
#    try:
#        print(r)
#        date=r[-2:]+r[-4:-2]+r[-8:-4]
#        print(date)
#        os.rename(os.path.join(r,"nsecm.txt"),os.path.join(r,"nsecm_bkcapi_{}.txt".format(date)))
#        os.rename(os.path.join(r,"nsefo.txt"),os.path.join(r,"nsefo_bkcapi_{}.txt".format(date)))
#    except Exception as e:
#        print(e)
#        
#        
##    try:
##        with zipfile.ZipFile(os.path.join(r,'BO{}.673.zip'.format(date)), 'r') as zip_ref:
##            zip_ref.extractall(r)
##        print("done for {}".format(date))    
##    except Exception as e:
##        print(e)
##
#
#
#
#shutil.unpack_archive(r'\\172.17.9.22\Users\krishna\geeta\order_trade\ORD\20220905\BO050922.673.zip')


#main_dir=r'\\172.17.9.22\Users\krishna\geeta\order_trade\ORD\data1'
#
#def all_data():
#        for r,d,f in os.walk(main_dir):
#            try:
#                data_dir=r
#                print(r)
#                date=r[-2:]+r[-4:-2]+r[-8:-4]
#                print("process running for {}".format(date))
#                d=r[-2:]+r[-4:-2]+r[-6:-4]
#                print(date)
#                cm.main(date,data_dir)
#                bse_cm.main(d,data_dir)
#                fo.main(date,data_dir)
#                time.sleep(10)
#            except Exception as e:
#                print(e)
#def main():
#   all_data()
#
#main()









































