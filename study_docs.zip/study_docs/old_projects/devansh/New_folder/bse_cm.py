# -*- coding: utf-8 -*-
"""
Created on Thu Sep  1 14:28:39 2022

@author: backup
"""
import pandas as pd
import os
import numpy as np
import sys

#data_dir=r'\\172.17.9.22\Users\krishna\geeta\order_trade\ORD\data\20220902'


def reading_files(d,data_dir,ctcl_path):
        user_id=pd.read_csv(os.path.join(ctcl_path,"Client_ctcl_codes.csv"))
        nse_id=user_id['BSE-CM']
        nse_id = nse_id.dropna(axis=0) 
    #Reading order file
        bse_ord=pd.read_csv(os.path.join(data_dir,"BO{}.673.zip".format(d)),sep="|",header=None)
       # bse_ord=pd.read_csv(os.path.join(data_dir,"BO{}.673".format(d)),sep="|",header=None)
        bse_ord.drop([bse_ord.columns[19]],axis=1,inplace=True)
        #bse.columns=['Buy_Sell','Scrip_Code','Symbol',3,4,5,6,7,'Time','Date','Order_Number',11,'Client_Code',13,14,15,'Activity_Type','Exchange_Id','NNF_Code',19,20]
        bse_ord.columns=['Buy/Sell','Scripcode','Symbol','Qty','F2','PriceInPaisa','F4','F5','TradeTime','TradeDate','OrderNo','ScripGroup','ClientAccount','ProClient','OrderValidity','F6','Action','UserId','NNFID']
        
        bkc_df=bse_ord[bse_ord['UserId'].isin(nse_id.tolist())]
        mapping={'ORDER ADDED SUCCESSFULLY':'ONEW','ORDER DELETED SUCCESSFULLY':'OCXL','ORDER UPDATED SUCCESSFULLY':'OMOD'}
        bkc_df['Action']=bkc_df['Action'].map(mapping)
        bkc_df['NNFID']=bkc_df['NNFID'].astype(str)
        bkc_df['OrderNo']=bkc_df['OrderNo'].astype(str)
        
        # Reading Trade file
        bse_trade=pd.read_csv(os.path.join(data_dir,"bsecm.csv"),sep="|",header=None)  
        bse_trade=bse_trade.iloc[:,:23]  
        bse_trade.columns=['MemberId','UserId','ScripCode','Symbol','Average','Quantity','TradeStatus','CmCode','Time','Date',
                                           'Account','OrderId','OrderType','Side','TradeId','ClientType','ISIN','ScripGroup','SettNo','OrderTime',
                                           'APFlag','CTCL code','TradeModificationTime']
        
        bse_trade=bse_trade[bse_trade['TradeStatus']==11]
        bse_trade=bse_trade[bse_trade['UserId'].isin(nse_id.tolist())] 
        bse_trade['CTCL code']=bse_trade['CTCL code'].astype(str)
        
        return bkc_df,bse_trade

def order_handling(grp):
    
    new_ord=grp[grp['Action']=='ONEW'] 
    n=len(new_ord)
    if n!=0:
        new_ord['order_value']=new_ord['PriceInPaisa']*new_ord['Qty']
        nov=new_ord['order_value'].sum()
    else:
        nov=0.0        
    mod_ord=grp[grp['Action']=='OMOD']
    m=len(mod_ord)
    if m!=0:
       mod_ord['order_value']=mod_ord['PriceInPaisa']*mod_ord['Qty']
       mov=mod_ord['order_value'].sum()
    else:
       mov=0.0       
    cancel_ord=grp[grp['Action']=='OCXL']
    c=len(cancel_ord)
    if c!=0:
       cancel_ord['order_value']=cancel_ord['PriceInPaisa']*cancel_ord['Qty']
       cov=cancel_ord['order_value'].sum()
    else:
        cov=0.0
   
    return pd.Series({'ExpiryDate':np.nan,
                      'OptionType':np.nan,
                      'StrikePrice':np.nan,
                      'Count_newOrders':n,
                      'Count_modOrders':m,
                      'Count_cancelOrders':c,
                      'New_orderValue':nov,
                      'Mod_orderValue':mov,
                      'Cancel_orderValue':cov})

def modified_order_handling(grp):
    new_mod=grp[grp['Action']!='OCXL']
    mod_ord=grp[grp['Action']=='OMOD']
    if len(mod_ord)!=0:
        m=len(mod_ord)
    
        buy_data=new_mod[new_mod['Buy/Sell']=='B']
        if len(buy_data)!=0:
            buy_data['priority loss'] = np.where((buy_data['PriceInPaisa'] < buy_data['PriceInPaisa'].shift()) | ((buy_data['Qty'] > buy_data['Qty'].shift()) & (buy_data['PriceInPaisa'] == buy_data['PriceInPaisa'].shift())),"Yes","No")
            buy_count=buy_data[buy_data['priority loss']=="Yes"]
            count_mod_pri_loss=len(buy_count)
        else:   
            sell_data=new_mod[new_mod['Buy/Sell']=='S']
            sell_data['priority loss'] = np.where((sell_data['PriceInPaisa'] > sell_data['PriceInPaisa'].shift()) | ((sell_data['Qty'] > sell_data['Qty'].shift()) & (sell_data['PriceInPaisa'] == sell_data['PriceInPaisa'].shift())),"Yes","No")
            sell_count=sell_data[sell_data['priority loss']=="Yes"]
            count_mod_pri_loss=len(sell_count)
            
        new_mod['Priority maintained']=np.where((new_mod['PriceInPaisa']==new_mod['PriceInPaisa'].shift()) & (new_mod['Qty'] <= new_mod['Qty'].shift()),"Yes","No")
        priority_main=new_mod[new_mod['Priority maintained']=='Yes']
        count_mod_pri_main=len(priority_main)
        
        mod_percent=((count_mod_pri_loss+count_mod_pri_main)*100)/m
    else: 
         return pd.Series({"count_of_mod":0.0,
                          "Priority_loss":0.0,
                         "Priority_maintained":0.0,
                         "mod_percent":0.0})
    
            
    return pd.Series({"count_of_mod":m,
                      "Priority_loss":count_mod_pri_loss,
                         "Priority_maintained":count_mod_pri_main,
                         "mod_percent":mod_percent})
    

def generating_data(bkc_df,bse_trade,d,output_dir):  
    
        order_df = bkc_df.groupby(by=['ClientAccount','Scripcode','UserId','NNFID']).apply(lambda grp:
                                    order_handling(grp)).reset_index()
        
        
        trade_df=bse_trade.groupby(by=['Account','ScripCode','UserId','CTCL code']).apply(lambda grp:
                                               pd.Series({
                                                       'trade_count':len(grp),
                                                       'trade_qty':grp['Quantity'].sum(),
                                                       'trade_value':np.sum(grp['Average']*grp['Quantity'])
                                                       })).reset_index()   
        
        
        
        final1 = (order_df.groupby(by=['ClientAccount','Scripcode']).apply(lambda grp: pd.Series({
                                    'ExpiryDate':np.nan, 'OptionType':np.nan, 'StrikePrice':np.nan,
                                    'Count_newOrders': grp['Count_newOrders'].sum(),
                                    'Count_modOrders':grp['Count_modOrders'].sum(),
                                    'Count_cancelOrders':grp['Count_cancelOrders'].sum(),
                                    'New_orderValue':grp['New_orderValue'].sum(),
                                    'Mod_orderValue':grp['Mod_orderValue'].sum(),
                                    'Cancel_orderValue':grp['Cancel_orderValue'].sum()})).reset_index().rename(columns={'ClientAccount':'Account','Scripcode':'ScripCode'})).merge(
                        trade_df.groupby(by=['Account','ScripCode']).apply(lambda grp:
                            pd.Series({
                            'trade_count': np.sum(grp['trade_count']),
                            'trade_qty': np.sum(grp['trade_qty']),
                            'trade_value': np.sum(grp['trade_value']),
                            })).reset_index(), on=['Account','ScripCode'], how="outer")
                        
        final2 = (order_df.groupby(by=['ClientAccount','Scripcode','UserId','NNFID']).apply(lambda grp: pd.Series({
                                    'ExpiryDate':np.nan, 'OptionType':np.nan, 'StrikePrice':np.nan,
                                    'Count_newOrders': grp['Count_newOrders'].sum(),
                                    'Count_modOrders':grp['Count_modOrders'].sum(),
                                    'Count_cancelOrders':grp['Count_cancelOrders'].sum(),
                                    'New_orderValue':grp['New_orderValue'].sum(),
                                    'Mod_orderValue':grp['Mod_orderValue'].sum(),
                                    'Cancel_orderValue':grp['Cancel_orderValue'].sum()})).reset_index().rename(columns={'ClientAccount':'Account',
                                    'Scripcode':'ScripCode','NNFID':'CTCL code'})).merge(
                trade_df.groupby(by=['Account','ScripCode','UserId','CTCL code']).apply(lambda grp:
                            pd.Series({
                            'trade_count': np.sum(grp['trade_count']),
                            'trade_qty': np.sum(grp['trade_qty']),
                            'trade_value': np.sum(grp['trade_value']),
                            })).reset_index(), on=['Account','ScripCode','UserId','CTCL code'], how="outer")
        
        final1["Order_Trade_Ratio"]=(final1['New_orderValue']+final1['Mod_orderValue']+final1['Cancel_orderValue'])/final1['trade_value']
        final2["Order_Trade_Ratio"]=(final2['New_orderValue']+final2['Mod_orderValue']+final2['Cancel_orderValue'])/final2['trade_value']
               
        mod_data1 = bkc_df.groupby(by=['ClientAccount','Scripcode','OrderNo']).apply(lambda grp:
                                     modified_order_handling(grp)).reset_index()
                    
        mod_data11=mod_data1.groupby(by=['ClientAccount','Scripcode']).apply(lambda grp:
                                             pd.Series({
                                 "count_of_mod":grp['count_of_mod'].sum(),              
                                "Priority_loss":grp['Priority_loss'].sum(),
                                 "Priority_maintained":grp['Priority_maintained'].sum()})).reset_index() 
        
        mod_data11['mod_percent']= np.where(mod_data11['count_of_mod']!=0 ,(((mod_data11['Priority_loss']+mod_data11['Priority_maintained'])*100)/mod_data11['count_of_mod']).round(2),0.0)
        mod_data11.rename(columns={'ClientAccount':'Account','Scripcode':'ScripCode'},inplace=True)
        f1=final1.merge(mod_data11,on=['Account','ScripCode'],how="outer")
        f1.drop(['count_of_mod'],axis=1,inplace=True)  
        
        f1=f1.rename(columns={'Account':' UCC','ExpiryDate':'Expiry','OptionType':'Call/Put','StrikePrice':'Strike',
                              'Count_newOrders':'Count of Orders Entered','Count_modOrders':'Count of Orders Modified','Count_cancelOrders':'Count of Orders Cancelled',
                              'New_orderValue':'Original Order Value (entry)','Mod_orderValue':'Modified Order Value','Cancel_orderValue':'Cancelled Order Value','trade_count':'Count of Trade',
                              'trade_qty':'Trade Qty','trade_value':'Trade Value','Order_Trade_Ratio':'Order Trade Ratio in Value Terms',
                              'Priority_loss':'Count of Orders Modified with priority loss',
                              'Priority_maintained':'Count of Order Modified with prioity maintained',
                              'mod_percent':'Modification with Maintained/Lost Priority as a % of Total no. of modification'})
        								
         
        
        mod_data2=bkc_df.groupby(by=['ClientAccount','Scripcode','OrderNo','UserId','NNFID']).apply(lambda grp:
                                     modified_order_handling(grp)).reset_index()
            
        mod_data22=mod_data2.groupby(by=['ClientAccount','Scripcode','UserId','NNFID']).apply(lambda grp:
                                           pd.Series({
                                        "count_of_mod":grp['count_of_mod'].sum(),              
                                          "Priority_loss":grp['Priority_loss'].sum(),
                                         "Priority_maintained":grp['Priority_maintained'].sum()})).reset_index()
        
        mod_data22['mod_percent']= np.where(mod_data22['count_of_mod']!=0 ,(((mod_data22['Priority_loss']+mod_data22['Priority_maintained'])*100)/mod_data22['count_of_mod']).round(2),0.0)
        mod_data22.rename(columns={'ClientAccount':'Account','NNFID':'CTCL code','Scripcode':'ScripCode'},inplace=True)
        
           
         
        f2=final2.merge(mod_data22,on=['Account','ScripCode','UserId','CTCL code'],how="outer")
        f2.drop(['count_of_mod'],axis=1,inplace=True)          
        f2=f2.rename(columns={'Account':' UCC','CTCL code':'NNF Code','ExpiryDate':'Expiry','OptionType':'Call/Put','StrikePrice':'Strike',
                              'Count_newOrders':'Count of Orders Entered','Count_modOrders':'Count of Orders Modified','Count_cancelOrders':'Count of Orders Cancelled',
                              'New_orderValue':'Original Order Value (entry)','Mod_orderValue':'Modified Order Value','Cancel_orderValue':'Cancelled Order Value','trade_count':'Count of Trade',
                              'trade_qty':'Trade Qty','trade_value':'Trade Value','Order_Trade_Ratio':'Order Trade Ratio in Value Terms',
                              'Priority_loss':'Count of Orders Modified with priority loss',
                              'Priority_maintained':'Count of Order Modified with prioity maintained',
                              'mod_percent':'Modification with Maintained/Lost Priority as a % of Total no. of modification'})
        
        
            
        writer = pd.ExcelWriter(os.path.join(output_dir,"OrderTradedata_bsecm{}.xlsx".format(d)), engine='xlsxwriter')
        f1.to_excel(writer, sheet_name='sheet1',index=False)
        f2.to_excel(writer, sheet_name='sheet2',index=False)
        writer.save()
        
def main(d,data_dir,output_dir,ctcl_path):
    #d=sys.argv[1]
    bkc_df,bse_trade=reading_files(d,data_dir,ctcl_path)
    generating_data(bkc_df,bse_trade,d,output_dir)
    print("file generated for {}".format(d))
    
       
#if __name__=='__main__':
#     main()    
#    
    
    
    
    