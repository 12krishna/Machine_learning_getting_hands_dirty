import time,datetime,os
import pandas as pd 
import xlwings as xw
import win32api
import warnings, sys, glob
warnings.filterwarnings("ignore")
#from pathlib import Path
import numpy as np


#redis_host = "localhost"
#redis_host = "10.223.104.65"
#r = redis.Redis(host=redis_host, port=6379)

excel_interface = "Delivery_data_Realtime.xlsm"
col_names = ['Symbol','date','%DQ_10','%DQ_11','%DQ_12','%DQ_13','%DQ_14','%DQ_15','DQ_10','DQ_11','DQ_12',
                       'DQ_13','DQ_14','DQ_15','QT_10','QT_11','QT_12','QT_13','QT_14','QT_15',
                       'avgPrice_10','avgPrice_11','avgPrice_12','avgPrice_13','avgPrice_14','avgPrice_15']

def flattern(A):
    rt = []
    for i in A:
        if isinstance(i,list): rt.extend(flattern(i))
        else: rt.append(i)
    return rt
   
def data_format(df):
    
    result=df[df['Symbol_key'].str.endswith('10')].drop(columns=['date','Symbol_key'])
    result.rename(columns={'QT':'QT_{}'.format(10),'DQ':'DQ_{}'.format(10),'%DQ':'%DQ_{}'.format(10)}, inplace=True)
    
    for i in ['11','12','13','14','15','16'] :
        result = result.merge( df[df['Symbol_key'].str.endswith(i)].drop(columns=['date','Symbol_key']),
                                  on='Symbol',how='left', suffixes=("",""))
        result.rename(columns={'QT':'QT_{}'.format(i),'DQ':'DQ_{}'.format(i),'%DQ':'%DQ_{}'.format(i)}, inplace=True)
    
    columns = list(result.columns); columns.remove("Symbol")
    
    for col in columns:
        result[col] = result[col].str.replace('%','')
        result[col] = result[col].str.replace(',','')
        result[col] = pd.to_numeric(result[col], errors='coerce') 
    
    result['Symbol'] = result['Symbol'].str.upper()
    result.sort_values(by='Symbol', inplace=True)
    #result = result[result['Symbol'].isin(symbols_list)]
     
    
    return result
   

def pre_process_files(nse_f, bse_f):
    #nse
    df = pd.read_csv(nse_f)
    df.rename(columns={'pc_DQ_TQ':'%DQ','traded_date':'date','avg_price':'avgPrice'}, inplace=True)    
    df['date'] = df['date'].apply(lambda row: pd.to_datetime(row).date() )
        
    df = pd.pivot_table(df, values=['QT','DQ','%DQ','avgPrice'], 
                        index=['Symbol','date'], columns=['traded_time']).reset_index()
    df.columns = ['_'.join(col).strip() for col in df.columns.values]
    df.columns = [ '_'.join([col_list[0], col_list[1].split(":")[0]]) \
                for col_list in [ col.split("_") for col in df.columns.values ]]
    df.rename(columns={'Symbol_':'Symbol','date_':'date'}, inplace=True)
    #bse
    df1 = pd.read_csv(bse_f)
    df1.rename(columns={'pc_DQ_TQ':'%DQ','traded_date':'date'}, inplace=True)    
    df1['date'] = df1['date'].apply(lambda row: pd.to_datetime(row).date() )
        
    df1 = pd.pivot_table(df1, values=['QT','DQ','%DQ'], index=['Symbol','date'], columns=['traded_time']).reset_index()
    df1.columns = ['_'.join(col).strip() for col in df1.columns.values]
    df1.columns = [ '_'.join([col_list[0], col_list[1].split(":")[0]]) \
                for col_list in [ col.split("_") for col in df1.columns.values ]]
    df1.rename(columns={'Symbol_':'Symbol','date_':'date'}, inplace=True)
    
    # handle missing timeframes for current file 
    df = df.reindex(columns=list(set(df.columns.tolist() + col_names )) )
    df1 = df1.reindex(columns=list(set(df1.columns.tolist() + col_names)) )
    df.fillna(0, inplace=True)
    df1.fillna(0, inplace=True)
    
    df = df[col_names]
    df1 = df1[col_names]
    
    return df, df1


def get_data(blooms):
    # reads nse bse historical data 
    
    nse_files = pd.DataFrame(glob.glob(r"\\172.17.9.21\Agent\Ojas Shah\Security delivery position\NSE_delivery*.txt"),
                             columns=['Nse_file_path'])
    nse_files['date'] = nse_files['Nse_file_path'].apply(lambda x: 
        pd.to_datetime(x.split("_")[-1].split(".txt")[0] ).date() )
    
    bse_files = pd.DataFrame(glob.glob(r"\\172.17.9.21\Agent\Ojas Shah\Security delivery position\BSE_delivery*.txt"),
                             columns=['Bse_file_path'])
    bse_files['date'] = bse_files['Bse_file_path'].apply(lambda x: 
        pd.to_datetime(x.split("_")[-1].split(".txt")[0] ).date() )
        
    files = nse_files.merge(bse_files, how='left', on='date')
    files.sort_values(by=['date'], ascending =False, inplace=True)
    
    files = files.head(11)
      
    
    result=pd.DataFrame()
    
    for _, row in files.iterrows():
        
        nse,bse = pre_process_files(row['Nse_file_path'], row['Bse_file_path'])        
        
        #nse = pd.read_excel(row['path'], sheet_name='NSE')
        nse = nse.merge(blooms[['BloomCode','Symbol']], on='Symbol', how='left' )
        nse.drop(columns=['Symbol'], inplace=True); nse.rename(columns={'BloomCode':'Symbol'}, inplace=True)
        
        #bse = pd.read_excel(row['path'], sheet_name='BSE')
        bse = bse.merge(blooms[['BloomCode','Symbol']], on='Symbol', how='left' )
        bse.drop(columns=['Symbol'], inplace=True); bse.rename(columns={'BloomCode':'Symbol'}, inplace=True)
        
        # Combine NSE+BSE data
        nse = pd.concat([nse, bse], axis=0).fillna(0)
        nse = nse.groupby(by=['Symbol','date'], as_index=False).sum()
        
        #calc combined delivery %
        for i in range(10,16):
            nse['%DQ_{}'.format(i)] = nse['DQ_{}'.format(i)]/nse['QT_{}'.format(i)]*100
            nse['%DQ_{}'.format(i)] = nse['%DQ_{}'.format(i)].round(2)
            nse['%DQ_{}'.format(i)] = nse['%DQ_{}'.format(i)].fillna(0)
        #nse['date']=row['date']
        result = result.append(nse, ignore_index=True)
        
        
    # get todays data
    df = result[result['date']==max(result['date'])].copy(deep=True)
    result = result[result['date']!=max(result['date'])]
        
        
    # historical avg
        
    avg = result[result['date'].isin(flattern(files.iloc[1:6, files.columns.str.startswith("date")].values.tolist()))]
    avg = avg.replace(0, np.NaN)
    avg = avg.groupby('Symbol', as_index=False).mean()  # consist of delivery avg for hourly and EOD; 5 days
    
    avg10 = result.copy(deep=True); avg10=avg10.replace(0, np.NAN)
    avg10 = avg10.groupby('Symbol', as_index=False).mean()  # 10 days del avg
    
    # format for delivery quantity avg 5, 10 days 
    avg.set_index('Symbol', inplace=True); avg10.set_index('Symbol', inplace=True)
    
    avg = avg.loc[:, avg.columns.str.startswith('DQ_')]
    avg10 = avg10.loc[:, avg10.columns.str.startswith('DQ_')]
    
    avg = avg.add_suffix('_Avg_05'); avg10 = avg10.add_suffix('_Avg_10')
    
    avg.reset_index(inplace=True); avg10.reset_index(inplace=True)
    avg = avg.merge(avg10, on='Symbol', how='outer').set_index('Symbol')
    avg.sort_index(axis=1, ascending=True, inplace=True, kind='quicksort')
    avg.reset_index(inplace=True)
       
    return df, avg
    
    


def get_data_redis():
    
    # mock caller for debugging 
    xw.Book(excel_interface).set_mock_caller()
    # book instance for reading values from excel file 
    wb = xw.Book.caller()
    symbols_list = pd.DataFrame( wb.sheets[0].range('A5').expand('table').value )
    symbols_list[0] = symbols_list[0].str.strip()
    symbols_list = list(symbols_list[0].values) 
    
    
    # read bloomcodes    
    blooms = pd.read_excel( "{}\\BloomCodes.xlsx".format(str(os.path.split(wb.fullname)[0])) )   # relative path reading   
    
        
    # get historical del avgs for 5 and 10 days   and todays date 
    result, historical_avgs = get_data(blooms)
    historical_avgs.set_index('Symbol',inplace=True); result.set_index('Symbol',inplace=True)
    
    
    final = pd.DataFrame()
    for i in range(10, 16):
        t = result.loc[:, result.columns.str.endswith("_{}".format(i))]
        t1 = historical_avgs.loc[:, historical_avgs.columns.str.startswith("DQ_{}".format(i))]
        t = t.merge(t1, how='left', left_index=True, right_index=True )
        if final.empty==True:
            final = t
        else:
            final = final.merge( t,how='left', left_index=True, right_index=True)
        
    # highlight symbols that exceed DQ more than 5 or 10 days avg
    final = final.replace(0, np.NaN)
    highlight_symbols = []
    for i in range(10, 16):
        if i == int(datetime.datetime.now().time().hour):
            break
                    
        t = final.loc[:, final.columns.str.startswith("DQ_{}".format(i))]
        t = t[(t.iloc[:, 0]> t.iloc[:, 1]) | (t.iloc[:, 0]> t.iloc[:, 2]) ]    
    
        highlight_symbols.append(list(t.index))
        
    highlight_symbols = list(set(flattern(highlight_symbols)))  # highlight these symbols
    
    # rename columns
    cols = final.columns.values
    cols = { x: 'Avg_5' if x.endswith("Avg_05") else 'Avg_10' if x.endswith('Avg_10') else x for x in cols }
    final.rename(columns = cols, inplace=True)  
    
    cols = final.columns.values
    cols = { x: 'DQ' if x.startswith('DQ') else 'QT' if x.startswith('QT') else '%DQ' if x.startswith("%DQ") else 'avgPrice' if x.startswith("avgPrice") else x  for x in cols }
    final.rename(columns = cols, inplace=True)  
    
    #result = result.reset_index().merge(blooms.rename(columns={'SYMBOL':'Symbol'}), on='Symbol', how='left')
    final = final.reset_index().rename(columns={'Symbol':'BloomCode'})
    final.set_index(['BloomCode'], inplace=True)
    
    # display on front end 
    wb.sheets[0].range("A5:ZK300").value = ''
    wb.sheets[0].range('A4').value=final
    
    symbol_indices = final.reset_index()[['BloomCode']]
    symbol_indices = symbol_indices[symbol_indices['BloomCode'].isin(highlight_symbols)]
    symbol_indices = [ int(i) for i in list(symbol_indices.index)]
    
    # reset already set colours 
    xw.Range('A5:A500').color = (138, 169, 219)
    
    for i in symbol_indices:
        xw.Range('A{}'.format(5+i)).color = (242, 98, 85)
        
      
    win32api.MessageBox(wb.app.hwnd, "Delivery data imported !","Success !")  
        
     

def main(args):    
    if args:
        if args[0] == "delivery":
            get_data_redis() 
          

if __name__ == "__main__":
    main(sys.argv[1:])



