import time,datetime,os
import pandas as pd 
import xlwings as xw
import win32api
import warnings, sys, glob
warnings.filterwarnings("ignore")
#from pathlib import Path
import numpy as np
import smtplib
#from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import matplotlib as mpl
mpl.use('Agg')
import os,sys
import logging
from collections import OrderedDict
os.chdir("D:\\Delivery_data_realtime\\")
import sector_delivery

#redis_host = "localhost"
#redis_host = "10.223.104.65"
#r = redis.Redis(host=redis_host, port=6379)
server = '172.17.9.149'; port = 25  # mailing server
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'

master_dir= "D:\\Master\\"
output_dir = "D:\\Delivery_data_realtime\\Output\\"
contacts_dir = "D:\\Emails\\Contacts\\"

logging.basicConfig(filename="delivery_mailer.log",
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")

col_names = ['Symbol','date','%DQ_10','%DQ_11','%DQ_12','%DQ_13','%DQ_14','%DQ_15','DQ_10','DQ_11','DQ_12',
                       'DQ_13','DQ_14','DQ_15','QT_10','QT_11','QT_12','QT_13','QT_14','QT_15',
                       'avgPrice_10','avgPrice_11','avgPrice_12','avgPrice_13','avgPrice_14','avgPrice_15']

def dateparse(date):
    '''Func to parse dates'''    
    date = pd.to_datetime(date, dayfirst=True)    
    return date
      
# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)  


def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
    
      
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print 'Holiday: skip for current date :{} '.format(d)        
        return -1
    
def previous_working_day(d):
    '''Get previous wokring day'''
    
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                #print "Holiday : ",d
                d = d - datetime.timedelta(days=1)                
            else:
                return d    


def flattern(A):
    rt = []
    for i in A:
        if isinstance(i,list): rt.extend(flattern(i))
        else: rt.append(i)
    return rt
   
def data_format(df):
    
    result=df[df['Symbol_key'].str.endswith('10')].drop(columns=['date','Symbol_key'])
    result.rename(columns={'QT':'QT_{}'.format(10),'DQ':'DQ_{}'.format(10),'%DQ':'%DQ_{}'.format(10)}, inplace=True)
    
    for i in ['11','12','13','14','15','16'] :
        result = result.merge( df[df['Symbol_key'].str.endswith(i)].drop(columns=['date','Symbol_key']),
                                  on='Symbol',how='left', suffixes=("",""))
        result.rename(columns={'QT':'QT_{}'.format(i),'DQ':'DQ_{}'.format(i),'%DQ':'%DQ_{}'.format(i)}, inplace=True)
    
    columns = list(result.columns); columns.remove("Symbol")
    
    for col in columns:
        result[col] = result[col].str.replace('%','')
        result[col] = result[col].str.replace(',','')
        result[col] = pd.to_numeric(result[col], errors='coerce') 
    
    result['Symbol'] = result['Symbol'].str.upper()
    result.sort_values(by='Symbol', inplace=True)
    #result = result[result['Symbol'].isin(symbols_list)]
    logging.info("Data formatted")
    
    return result
   

def pre_process_files(nse_f, bse_f):
    #nse
    df = pd.read_csv(nse_f)
    df.rename(columns={'pc_DQ_TQ':'%DQ','traded_date':'date','avg_price':'avgPrice'}, inplace=True)    
    df['date'] = df['date'].apply(lambda row: pd.to_datetime(row).date() )
        
    df = pd.pivot_table(df, values=['QT','DQ','%DQ','avgPrice'], 
                        index=['Symbol','date'], columns=['traded_time']).reset_index()
    df.columns = ['_'.join(col).strip() for col in df.columns.values]
    df.columns = [ '_'.join([col_list[0], col_list[1].split(":")[0]]) \
                for col_list in [ col.split("_") for col in df.columns.values ]]
    df.rename(columns={'Symbol_':'Symbol','date_':'date'}, inplace=True)
    #bse
    df1 = pd.read_csv(bse_f)
    df1.rename(columns={'pc_DQ_TQ':'%DQ','traded_date':'date'}, inplace=True)    
    df1['date'] = df1['date'].apply(lambda row: pd.to_datetime(row).date() )
        
    df1 = pd.pivot_table(df1, values=['QT','DQ','%DQ'], index=['Symbol','date'], columns=['traded_time']).reset_index()
    df1.columns = ['_'.join(col).strip() for col in df1.columns.values]
    df1.columns = [ '_'.join([col_list[0], col_list[1].split(":")[0]]) \
                for col_list in [ col.split("_") for col in df1.columns.values ]]
    df1.rename(columns={'Symbol_':'Symbol','date_':'date'}, inplace=True)
    
    # handle missing timeframes for current file 
    df = df.reindex(columns=list(set(df.columns.tolist() + col_names )) )
    df1 = df1.reindex(columns=list(set(df1.columns.tolist() + col_names)) )
    df.fillna(0, inplace=True)
    df1.fillna(0, inplace=True)
    
    df = df[col_names]
    df1 = df1[col_names]
    logging.info("Data pre-processing for NSE, BSE done")
    
    return df, df1


def get_data(blooms, t_hour):
    # reads nse bse historical data 
    
    nse_files = pd.DataFrame(glob.glob(r"\\172.17.9.21\Agent\Ojas Shah\Security delivery position\NSE_delivery*.txt"),
                             columns=['Nse_file_path'])
    nse_files['date'] = nse_files['Nse_file_path'].apply(lambda x: 
        pd.to_datetime(x.split("_")[-1].split(".txt")[0] ).date() )
    
    bse_files = pd.DataFrame(glob.glob(r"\\172.17.9.21\Agent\Ojas Shah\Security delivery position\BSE_delivery*.txt"),
                             columns=['Bse_file_path'])
    bse_files['date'] = bse_files['Bse_file_path'].apply(lambda x: 
        pd.to_datetime(x.split("_")[-1].split(".txt")[0] ).date() )
        
    files = nse_files.merge(bse_files, how='left', on='date')
    files.sort_values(by=['date'], ascending =False, inplace=True)
    files = files.head(21)
      
    # check if all data available for this time frame 
    while True:
        try:
            nse,bse = pre_process_files(files['Nse_file_path'].values[0], files['Bse_file_path'].values[0])
        except Exception as e:
            print "File reading issue, {}\n sleep for 1 min".format(e)
            logging.info("File reading issue, {}\n sleep for 1 min".format(e))
            time.sleep(60)
            continue
        nse,bse = pre_process_files(files['Nse_file_path'].values[0], files['Bse_file_path'].values[0])
        # filter on current universe
        nse = nse[(nse['Symbol'].isin(blooms['Symbol'].values.tolist()))]
        bse = bse[(bse['Symbol'].isin(blooms['Symbol'].values.tolist()))]
        
        
        nse_count = (nse['QT_{}'.format(t_hour.hour)].values.tolist()).count(0)
        bse_count = (bse['QT_{}'.format(t_hour.hour)].values.tolist()).count(0)
        if (len(blooms)-len(nse) <= 5) and nse_count <= 5 and (len(blooms)-len(bse) <= 5) and bse_count <= 5:
            print "Break - > Symbol length {}, length NSE {}, length BSE {} \nData missing in NSE {}, data missing in BSE {}".format(
                    len(blooms), len(nse), len(bse), nse_count, bse_count)
            logging.info("Break - > Symbol length {}, length NSE {}, length BSE {} \nData missing in NSE {}, data missing in BSE {}".format(
                    len(blooms), len(nse), len(bse), nse_count, bse_count))
            break
        else:
            print "Sleep for 1 min \nData missing in NSE {}, data missing in BSE {}".format(nse_count, bse_count)
            logging.info("Sleep for 1 min \nData missing in NSE {}, data missing in BSE {}".format(nse_count, bse_count))
            time.sleep(60)
            continue
    
    
    
    result=pd.DataFrame()
    for _, row in files.iterrows():
        
        logging.info("Reading files for {}".format(row['date']))
    
        nse,bse = pre_process_files(row['Nse_file_path'], row['Bse_file_path'])        
        # filter on current universe
        nse = nse[(nse['Symbol'].isin(blooms['Symbol'].values.tolist()))]
        bse = bse[(bse['Symbol'].isin(blooms['Symbol'].values.tolist()))]
        
        #nse = pd.read_excel(row['path'], sheet_name='NSE')
        nse = nse.merge(blooms[['BloomCode','Symbol']], on='Symbol', how='left' )
        nse.drop(columns=['Symbol'], inplace=True); nse.rename(columns={'BloomCode':'Symbol'}, inplace=True)
        
        #bse = pd.read_excel(row['path'], sheet_name='BSE')
        bse = bse.merge(blooms[['BloomCode','Symbol']], on='Symbol', how='left' )
        bse.drop(columns=['Symbol'], inplace=True); bse.rename(columns={'BloomCode':'Symbol'}, inplace=True)
        
        # Combine NSE+BSE data
        nse = pd.concat([nse, bse], axis=0).fillna(0)
        nse = nse.groupby(by=['Symbol','date'], as_index=False).sum()
        
        #calc combined delivery %
        for i in range(10,16):
            nse['%DQ_{}'.format(i)] = nse['DQ_{}'.format(i)]/nse['QT_{}'.format(i)]*100
            nse['%DQ_{}'.format(i)] = nse['%DQ_{}'.format(i)].round(2)
            nse['%DQ_{}'.format(i)] = nse['%DQ_{}'.format(i)].fillna(0)
            nse['Value_{}'.format(i)] = (nse['DQ_{}'.format(i)]*nse['avgPrice_{}'.format(i)])/10**7
        #nse['date']=row['date']
        result = result.append(nse, ignore_index=True)
        
        
    # get todays data
    df = result[result['date']==max(result['date'])].copy(deep=True)
    result = result[result['date']!=max(result['date'])]
        
        
    # historical avg
    avg = result[result['date'].isin(flattern(files.iloc[1:11, files.columns.str.startswith("date")].values.tolist()))]
    avg = avg.replace(0, np.NaN)
    avg = avg.groupby('Symbol', as_index=False).mean()  # 10 days avg
    
    avg1 = result.copy(deep=True); avg1=avg1.replace(0, np.NAN)  # 20 days avg
    avg1 = avg1.groupby('Symbol', as_index=False).mean()  
    
    # format for delivery quantity avg 10, 20 days
    avg.set_index('Symbol', inplace=True); avg1.set_index('Symbol', inplace=True)
    
    avg = pd.concat([avg.loc[:, avg.columns.str.startswith('DQ_')], avg.loc[:, avg.columns.str.startswith('%DQ_')],
                             avg.loc[:, avg.columns.str.startswith('Value_')]], axis=1)
    avg1 = pd.concat([avg1.loc[:, avg1.columns.str.startswith('DQ_')], avg1.loc[:, avg1.columns.str.startswith('%DQ_')],
                               avg1.loc[:, avg1.columns.str.startswith('Value_')]], axis=1)
    
    avg = avg.add_suffix('_Avg_10'); avg1 = avg1.add_suffix('_Avg_20')
    
    avg.reset_index(inplace=True); avg1.reset_index(inplace=True)
    avg = avg.merge(avg1, on='Symbol', how='outer').set_index('Symbol')
    avg.sort_index(axis=1, ascending=True, inplace=True, kind='quicksort')
    avg.reset_index(inplace=True)
    logging.info("Historical avgs and data obtained")
       
    return df, avg



def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails


def email_utility(emails, subject, filename, attachments ):    
    '''Func to send daily report emails excel and text attachment combined'''

    # read the message file
    message = open(filename,'rb').read()
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
                     
    # add all attachments 
    for fname in attachments:
        print fname 
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(output_dir+fname, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="{}"'.format(fname))    
        msg.attach(part)   
      
    msg.attach(MIMEText(message,'html'))
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())
    s.quit()


def color_format_table(tables_dict, t_hour, d, sectoral_result):
    
    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>       
    html_string = "<html><head><style>{css_style}</style></head><body>\
                    <p>Delivery Value, Percentage delivery and Delivery quantity trends as on {d} {t}. </p>".format(css_style = open("D:\\Delivery_data_realtime\\df_style.css", 'r').read(),
                                                                                            d=d,t=t_hour)
                    
    # OUTPUT AN HTML FILE
    output_file = open(output_dir+"output_{}_{}.html".format(d, t_hour.hour), 'w')
    output_file.write(html_string)

    for key in [['Value','Delivery Value'],['%DQ','Percentage Delivery'],['DQ','Delivery Quantity'],['DQ hour-on-hour','DQ hour-on-hour Change']] :
        for name in ['Nifty','Non-Nifty']:
            
            table = tables_dict[key[0]+" "+name]     
            table.iloc[:,1:] = table.iloc[:,1:].round(2)
            table.rename(columns={'Value':'Value <br> (INR Cr)', 'Value_Avg_10':'Value_Avg_10 <br> (INR Cr)', 
                                  'Value_Avg_20':'Value_Avg_20 <br> (INR Cr)'}, inplace=True)
            
            table['Symbol'] = "text"+table['Symbol']
            tables_dict[key[0]+" "+name] = table
                 
            
        # write to file  
        #output_file.write("<p style='color:black;font-size:16px;font-weight:bold'>&nbsp&nbsp {} {} {}</p>".format(
        #                                keys[0],"&nbsp"*(120 - len(keys[0])) ,keys[1] ))
        table1 = (tables_dict[key[0]+" "+'Nifty'].to_html(classes='mystyle', index=False)).replace(
                                                '<table border="1" class="dataframe mystyle">',
                                                '<table border="1" class="mystyle"> <caption>{}</caption>'.format("Top - "+key[1]+" (Nifty names)" ))
        table2 = (tables_dict[key[0]+" "+"Non-Nifty"].to_html(classes='mystyle', index=False)).replace(
                                                '<table border="1" class="dataframe mystyle">',
                                                '<table border="1" class="mystyle"> <caption>{}</caption>'.format("Top - "+key[1]+" (Non-Nifty names)"))
           
        output_file.write("<table style='width:100%'><tr><td>{}</td><td>{}</td></tr></table>".format(table1 , table2))            
        output_file.write("<br><br>")        
    
    # sectoral trends
    sectoral_result['Sector'] = "text"+sectoral_result['Sector']
    sectoral_result = (sectoral_result.to_html(classes='mystyle', index=False)).replace(
                                                '<table border="1" class="dataframe mystyle">',
                                                '<table border="1" class="mystyle"> <caption>{}</caption>'.format(
                                                        "Sector-wise delivery trends" ))
    output_file.write("<br><br>")
    output_file.write("<table style='width:100%'><tr><td>{}</td></tr></table>".format(sectoral_result))            
                    
    output_file.write("</body></html>")    
    output_file.close()    
    output_file = open(output_dir+"output_{}_{}.html".format(d, t_hour.hour), 'r').read().replace("&lt;","<").replace("&gt;",">")
    output_file = output_file.replace("dataframe mystyle","mystyle")
    output_file = output_file.replace('<td>text','<td class="text">')
    
    with open(output_dir+"output_{}_{}.html".format(d, t_hour.hour), 'w') as f:
        f.write(output_file)
        
    
def hour_on_hour_changes(df, t_hour):
    '''Func to get hour on hour delivery quantity changes'''
    
    df.set_index('Symbol', inplace=True)
    # hourly price chg
    price_chg = df.iloc[:, df.columns.str.startswith("avgPrice")]
    try:
        price_chg['%px_chg'] = (price_chg['avgPrice_{}'.format(t_hour.hour)] - price_chg['avgPrice_{}'.format(t_hour.hour-1)])*100/price_chg['avgPrice_{}'.format(t_hour.hour-1)]
        price_chg = price_chg[['%px_chg']]
        price_chg['%px_chg'] = price_chg['%px_chg'].round(2)
    except Exception as e:
        print "First time interval for the day; {}".format(e)
        logging.info("First time interval for the day; {}".format(e))
        price_chg['%px_chg'] = 0
        price_chg = price_chg[['%px_chg']]
    
    # incremental delivery quantity chg
    delivery_chg = df.iloc[:, df.columns.str.startswith("DQ")]
        
    for i in range(10,16):
        if i>t_hour.hour:
            delivery_chg.drop(columns=['DQ_{}'.format(i)], inplace=True)
            continue
        try:
            delivery_chg['DQ_chg_{}-{}'.format(i,i-1)] = delivery_chg['DQ_{}'.format(i)] - delivery_chg['DQ_{}'.format(i-1)]
        except Exception as e:
            print "First time interval for delivery quantity; {}".format(e)
            logging.info("First time interval for delivery quantity; {}".format(e))
            delivery_chg['DQ_chg_{}-{}'.format(i,i-1)] = delivery_chg['DQ_{}'.format(i)]

    temp = delivery_chg.iloc[:, delivery_chg.columns.str.startswith("DQ_chg")]
    temp = temp.iloc[:,:-1]
    if temp.empty==True:
        temp['DQ_chg_{}-{}'.format(t_hour.hour,t_hour.hour-1)] = 0
        
    delivery_chg['DQ_mean'] = temp.mean(axis=1)
    delivery_chg['DQ_hourly_%chg'] = (delivery_chg.iloc[:,-2] - delivery_chg.iloc[:,-1])*100/delivery_chg.iloc[:,-1]
    delivery_chg['DQ_hourly_%chg'] = delivery_chg['DQ_hourly_%chg'].replace([np.inf, -np.inf, np.nan, np.NAN, np.NaN], 0)
    
    #delivery_chg['DQ_hourly_%chg'] = delivery_chg['DQ_hourly_%chg'].round(2)
    delivery_chg.sort_values(by='DQ_hourly_%chg', inplace=True, ascending=False)
    delivery_chg = delivery_chg.merge(price_chg, how='left', left_index=True, right_index=True)
    
    return delivery_chg
    
    
    
def pop_1(l):
    l = l.split("_")
    l.pop(1)
    return l

def filter_top_names(symbol_list, t_hour, d):
    '''func to get top names by diff criteria'''
    
    # get historical del avgs for 5 and 10 days   and todays date 
    result, historical_avgs = get_data(symbol_list, t_hour)
    result = (result.rename(columns={'Symbol':'BloomCode'})).merge(symbol_list[['Symbol','BloomCode','IsNifty']], 
                                                                     on='BloomCode', how='left')
    result.drop(columns=['BloomCode'], inplace=True)
    
    # get hour on hour changes
    DQ_hourly_result = hour_on_hour_changes(result.copy(deep=True), t_hour) 
    
    historical_avgs = (historical_avgs.rename(columns={'Symbol':'BloomCode'})).merge(symbol_list[['Symbol','BloomCode']], 
                                                                                      on='BloomCode', how='left')
    historical_avgs.drop(columns=['BloomCode'], inplace=True)
    
    historical_avgs.set_index('Symbol',inplace=True); result.set_index('Symbol',inplace=True)
    result.drop(columns=["date"], inplace=True)
    result = result.merge(historical_avgs, how='left', left_index=True, right_index=True)
    
    # get sector wise delivery
    #sector_delivery.sectoral_delivery(result.copy(deep=True), d, t, symbol_list[['Symbol','Sector']].copy(deep=True))
    sectoral_df = {"Value":result.iloc[:, result.columns.str.startswith("Value_"+str(t_hour.hour))].copy(deep=True)}
    
    # top nifty and non-nifty names for Delivery quantity in abs terms
    tables_dict = OrderedDict()
    writer = pd.ExcelWriter(output_dir+"Delivery_{}_{}.xlsx".format(str(d),''.join([str(t_hour.hour),str(t_hour.minute)])))
    
    for col, top in {'DQ_{}'.format(t_hour.hour):20, 'Value_{}'.format(t_hour.hour):5, '%DQ_{}'.format(t_hour.hour):5}.iteritems():
        print col
        for names,value in {'Nifty':True,'Non-Nifty':False}.iteritems():
            print names, value
            temp = result[result['IsNifty']==value].iloc[:, result.columns.str.startswith(col)]
            temp['PctChg (20D)'] = (temp[col] - temp['{}_Avg_20'.format(col)])/temp['{}_Avg_20'.format(col)]*100  # how far from 20 days avg
            temp['PctChg (20D)'] = temp['PctChg (20D)'].round(2)
            temp.sort_values(by='PctChg (20D)', inplace=True, ascending=False)
            temp.columns = [ '_'.join(pop_1(l)) if len(l.split("_"))>1 else l for l in temp.columns]
            
            # dump in excel
            if names=='Nifty':
                temp.to_excel(writer,sheet_name = "{}".format(col.split("_")[0]), startrow=0 , startcol=0)
            else:
                temp.to_excel(writer,sheet_name = "{}".format(col.split("_")[0]), startrow=0 , startcol=7)
                
            if col.startswith("DQ_"):
                print "Record DQ for sectoral trends"
                if "DQ" not in sectoral_df.keys():
                    sectoral_df["DQ"] = temp.copy(deep=True)
                else:
                    temp = temp.append(sectoral_df["DQ"])
                    sectoral_df["DQ"] = temp.copy(deep=True)
                    
            
            # filter and sort for email body
            temp = temp[(temp[col.split("_")[0]]>temp['{}_Avg_10'.format(col.split("_")[0])]) & (temp[col.split("_")[0]]>temp['{}_Avg_20'.format(col.split("_")[0])])]
            temp = temp.head(top)
            temp.reset_index(inplace=True)
            tables_dict[col.split("_")[0]+" "+names] = temp
            
            
    # DQ hourly changes
    DQ_hourly_result = DQ_hourly_result.merge(symbol_list[['Symbol','IsNifty']].set_index('Symbol'), how='left', left_index=True, right_index=True)
    for names,value in {'Nifty':True,'Non-Nifty':False}.iteritems():
        temp = DQ_hourly_result[DQ_hourly_result['IsNifty']==value]
        temp.drop(columns=['IsNifty'], inplace=True)
        temp.to_excel(writer,sheet_name = "DQ_hourly_{}".format(names), startrow=0 , startcol=0)
        
        temp = temp.iloc[:,-4:].reset_index()
        temp = temp.head(5)
        tables_dict['DQ hour-on-hour {}'.format(names)] = temp
        
    # get sectoral trends for security wise delivery data
    sectoral_result = sector_delivery.sectoral_delivery(sectoral_df, d, previous_working_day(d), t_hour,
                                                        symbol_list[['Symbol','Sector']].copy(deep=True))

    writer.save()
    writer.close()
    
    # format in html format for mailer 
    color_format_table(tables_dict, t_hour, d, sectoral_result)
    
    # trigger email
    # send email     
    email_utility(get_contacts(contacts_dir+'Delivery_hourly.txt'), 'Security-wise Delivery Mailer',
                  output_dir+"output_{}_{}.html".format(d, t_hour.hour),
                  ["Delivery_{}_{}.xlsx".format(str(d),''.join([str(t_hour.hour),str(t_hour.minute)]))])

    logging.info("Email triggered for {}".format(t_hour))
        
    

def main(nd):
    
    # read holiday master to check run criteria
    d = datetime.datetime.now().date() - datetime.timedelta(days=nd)
    if process_run_check(d) == -1:
        logging.info('Exit: Its an holiday.')
        return -1	 
    logging.info("Start Process")
    
    # load active fno stocks 
    symbol_list=pd.read_excel(master_dir+'MasterData.xlsx')
    symbol_list=symbol_list[(symbol_list["IsActiveFNO"]==True) & (symbol_list["Type"]=="SSF")]
    #symbol_list = list(sorted(symbol_list['SYMBOL'].tolist()))
    
    # get other stocks to monitor
    others = pd.read_excel(master_dir+"Security_delivery_nonNIFTY.xlsx")
    symbol_list = symbol_list.append(others, ignore_index=True)

    symbol_list.rename(columns={'SYMBOL':'Symbol'}, inplace=True)
        
    
    for t in range(10,16): 
        #if datetime.datetime.now().time() >= datetime.time(t,58):
        #    continue
    
        print "processing for hour ", datetime.time(t,0)
        logging.info("processing for hour {}".format(datetime.time(t,0)))
        filter_top_names(symbol_list, datetime.time(t,0), d)
      
    

if __name__ == "__main__":
    main(0)
