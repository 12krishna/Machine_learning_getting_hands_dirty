# -*- coding: utf-8 -*-
"""
Created on Wed May 13 20:14:13 2020

@author: krishna
"""
import os
import pandas as pd
import zipfile
import numpy as np
import datetime
import sys
import subprocess

#data_dir = "D:\\Volumes_intraday_mailer\\linux\\Data\\"
data_dir = "/opt/Sectoral_trends/Data/"
lots_file_dir = "/REPORTING/"
lots_archive_dir = "/REPORTING/PR FILE_INDEX IISL/old files/"

def get_bod_lot_file(d):
    
    # read open position file from network drive and read bod file
    date=d
    lots = pd.DataFrame()
    for i in range(5):
        # r"\\172.17.9.22\Users2\backoffice\Derv\189 REPORTING\PR FILE_INDEX IISL\NIFTY_500_{}{}{}.zip"
        #lots_file_dir+"PR FILE_INDEX IISL/NIFTY_500_{}{}{}.zip"
        if os.path.exists(lots_file_dir+"PR FILE_INDEX IISL/NIFTY_500_{}{}{}.zip".format(
                                                d.year,'0{}'.format(d.month) if len(str(d.month))==1 else d.month , d.day)):
            zf = zipfile.ZipFile(lots_file_dir+"PR FILE_INDEX IISL/NIFTY_500_{}{}{}.zip".format(d.year,
                                               '0{}'.format(d.month) if len(str(d.month))==1 else d.month, d.day))
            
            lots = pd.read_csv(zf.open(''.join([ f for f in zf.namelist() if f.startswith('bod') and f.endswith('.csv') ]) ))
            
            break
        else:
            d = d - datetime.timedelta(days=1)
        
    d=date
    # if not find inside old files 
    if lots.empty==True:
        print 'Looking backdated files'
        for i in range(200):
            print d
            # r"\\172.17.9.22\Users2\backoffice\Derv\189 REPORTING\PR FILE_INDEX IISL\old files\NIFTY_500_{}{}{}.zip"
            #lots_archive_dir+"NIFTY_500_{}{}{}.zip"
            if os.path.exists(lots_archive_dir+"NIFTY_500_{}{}{}.zip".format(
                                        d.year,'0{}'.format(d.month) if len(str(d.month))==1 else d.month , d.day)):
                
                zf = zipfile.ZipFile(lots_archive_dir+"NIFTY_500_{}{}{}.zip".format(
                                        d.year,'0{}'.format(d.month) if len(str(d.month))==1 else d.month , d.day))
                
                lots = pd.read_csv(zf.open(''.join([ f for f in zf.namelist() if f.startswith('bod') and f.endswith('.csv') ]) ))
                
                break
            else:
                d=d-datetime.timedelta(days=1)           
            
    lots = lots[lots['SERIES']=='EQ'][['SYMBOL','ISSUE_CAP','INVESTIBLE_FACTOR']].rename(columns={'SYMBOL':'Symbol'})
    
    return lots


def sumproduct(grp):
    # takes sum product for price and bases sector vice
    
    return pd.Series( {'Price_chg_percent': np.dot(grp['weight'], grp['fut_price_chg_m1']),
                       'Basis': np.dot(grp['weight'], grp['spread_bps']),
                       'Value': np.dot(grp['weight'], grp['value']),
                       'Value_cash':np.dot(grp['weight'], grp['value_cash'])} )
    


def sectoral_trends(df, d, t, cassandra_obj):    
    # calc sectoral price , value and basis trends for hourly snap
    
    print "Processing for {} {}".format(d,t)
    # read lots file
    lots = get_bod_lot_file(d)
    
    
    # read data; usually get input from another functions    
    #df = pd.read_csv(data_dir+"Snapshot_data.csv")
    #df['date'] = df['date'].apply(lambda x : pd.to_datetime(x).date())
    #df = df[(df['date']==d) & (df['time']==str(t) )]

    
    df = df.merge(lots, on='Symbol', how='left')  
    df.dropna(subset=['ISSUE_CAP','INVESTIBLE_FACTOR'], inplace=True)
    df['Float Market Cao'] = df['ISSUE_CAP']*df['INVESTIBLE_FACTOR']*df['ClosePrice_NSE']
    
    sectorwise_sum = df[['Sector','Float Market Cao']].groupby(by='Sector',as_index=False)['Float Market Cao'].sum()
    sectorwise_sum.rename(columns={'Float Market Cao':'sector_sum'}, inplace=True)
    
    df = df.merge(sectorwise_sum, on='Sector', how='left' )
    
    df.loc[df['sector_sum']!=0, 'weight'] = df['Float Market Cao']/df['sector_sum']    
    df.loc[df['sector_sum']==0, 'weight'] = 0
    
    sector_result = df[['Sector','weight','ClosePrice_fut_m1','LTP_fut_m1','spread_bps','VolumeTraded_fut_m1','VWAP_fut_m1',
                        'VolumeTraded_NSE','VolumeTraded_BSE','VWAP_NSE','VWAP_BSE']]
    # price change fut_m1 LTP - fut close price
    sector_result.loc[sector_result['ClosePrice_fut_m1']!=0,'fut_price_chg_m1'] = (sector_result['LTP_fut_m1'] - \
                     sector_result['ClosePrice_fut_m1'])*100/sector_result['ClosePrice_fut_m1']                       
    sector_result.loc[sector_result['ClosePrice_fut_m1']==0,'fut_price_chg_m1'] = 0
    
    
    #sector_result['fut_price_chg_m1'] = 'LTP_fut_m1' 'ClosePrice_fut_m1'
    sector_result['value'] = (sector_result['VolumeTraded_fut_m1']*sector_result['VWAP_fut_m1']).fillna(0)
    sector_result['value_cash'] = (sector_result['VolumeTraded_NSE']*sector_result['VWAP_NSE']).fillna(0) \
                                        + (sector_result['VolumeTraded_BSE']*sector_result['VWAP_BSE']).fillna(0)
    
    
    sector_result = sector_result.groupby(by=['Sector']).apply(lambda grp: sumproduct(grp) )
    sector_result.reset_index(inplace=True)
    sector_result[['Basis','Price_chg_percent','Value','Value_cash']] = sector_result[['Basis','Price_chg_percent','Value','Value_cash']].round(2)
    
    sector_result['date']=d; sector_result['time']=t
    
    sector_result = sector_result[['Sector','date','time','Price_chg_percent','Value','Value_cash','Basis']]
    
    
    # dump result in postgress db for every hourly snapshot; replace by code to save in db
    # dump result in postgress db for every hourly snapshot
    cassandra_obj.session.execute("create table if not exists sectoral_snapshot_data (Sector varchar, date date, time varchar,\
                                                                                    price_chg_percent float, Value float,\
                                                                                    value_cash float,	Basis float, \
                                                                                    primary key (sector, date, time)); ")
    
    sector_result.to_csv(data_dir+'sectordata.csv', index=False)
    # call sh function to dump data
    if (sys.platform).startswith('win'):
        #logging.info("Windows platform; dumping file via .bat ")
        os.system(data_dir+"sectordata.bat")
    else:                   
        os.putenv("filename", data_dir+'sectordata.csv')
        subprocess.call(data_dir+'sectordata.sh')
    
    print "{} rows dumped in db".format(len(sector_result))
    
    '''
    if sector_result.empty==False:        
        with open(data_dir+"Sector_snap_data.csv",'ab') as f:
            sector_result.to_csv(f,header=False, index=False, sep=',' )
    '''
       
    
    
"""
data = pd.read_csv(data_dir+"Snapshot_data.csv")
data['date'] = data['date'].apply(lambda x : pd.to_datetime(x).date())
data.drop_duplicates(keep='last', inplace=True, subset=['Symbol','date','time'])
data.to_csv("Snapshot_data_new1.csv", index=False)

dates = data.groupby(by=['date','time'], as_index=False).last()[['date','time']]
    
for _, row in dates.iterrows():
    sectoral_trends(data, row['date'], row['time'])

"""