# -*- coding: utf-8 -*-
"""
Created on Fri Jan  1 17:39:02 2021

@author: krishna
"""

from cassandra.cluster import Cluster
import pandas as pd
from decimal import Decimal

master_dir="D:\\Master\\"

# Define a pandas factory to read the cassandra data into pandas dataframe:
def pandas_factory(colnames, rows):
    return pd.DataFrame(rows, columns=colnames)

def cassandra_configs_cluster():
    f = open(master_dir+"config.txt",'r').readlines()
    f = [ str.strip(config.split("cassandra,")[-1].split("=")[-1]) for config in f if config.startswith("cassandra")]  
          
    from cassandra.auth import PlainTextAuthProvider

    auth_provider= PlainTextAuthProvider(username=f[1],password=f[2])
    cluster = Cluster([f[0]], auth_provider=auth_provider)
    
    return cluster

def corp_actions_factor(bhav_copy, ca_factors, datename):    
    '''Func to perfrom CA factor adjustments ; takes input datecolumn name and '''
    
    
    # perform CA on factor changes
    bhav_copy[datename] = bhav_copy[datename].apply(lambda d: pd.to_datetime(d.date()) )
    result = bhav_copy[~bhav_copy["symbol"].isin(ca_factors['Symbol'])]
    bhav_copy = bhav_copy[bhav_copy["symbol"].isin(ca_factors['Symbol'])]
    

    for gpname, grp in bhav_copy.groupby("symbol"):
        
        # check if symbol has any CA factors; perform on fly adjustment 
        if len(ca_factors[ca_factors['Symbol']==gpname])>=1:  # if more than one CA actions have happend
            adjust_df = ca_factors[ca_factors['Symbol']==gpname]          
            counter = 0; temp1='';
            for index, row in adjust_df.iterrows():
                
                print "CA action on {} for stock {}; Factor adjustment {}".format(row['Date'],row['Symbol'], 
                                    row['Factor'])
                if counter==0:
                    temp1 = grp[grp[datename]<row['Date']]   # first CA event 
                    # look for price and quanitiy columns 
                    for col in temp1.columns:
                        if col in ['price','open','high','low','close','last','prevclose']:
                            # perform price/factor conv
                            temp1[col] = temp1[col]/Decimal(row['Factor'])
                        elif col in 'open_int volume'.split(" "):  # perfrom quantity* factor
                            temp1[col] = temp1[col]*Decimal(row['Factor'])
                    
                    temp2 = grp[grp[datename]>=row['Date']]
                    temp1 = pd.concat([temp1,temp2], axis=0, ignore_index=True)
                    counter +=  1
                        
                else:   # more than one CA event 
                    print '******{} CA ratio******'.format(counter+1)
                    temp3 = temp1[temp1[datename]<row['Date']]
                    
                    for col in temp3.columns:
                        if col in 'price open high low close last prevclose'.split(" "):
                            # perform price/factor conv
                            temp3[col] = temp3[col]/Decimal(row['Factor'])
                        elif col in 'open_int volume'.split(" "):  # perfrom quantity* factor
                            temp3[col] = temp3[col]*Decimal(row['Factor'])                    
                    
                    temp4 = temp1[temp1[datename]>=row['Date']]
                    temp1 = pd.concat([temp3, temp4], axis=0, ignore_index=True)
                    counter += 1
            
            result = result.append(temp1, ignore_index=True)
        #else:  # no CA ratio actions 
        #    result = result.append(grp, ignore_index=True)
                    
        
    for col in result.columns:
        if col in 'price open high low close last prevclose open_int volume'.split(" "):
            result[col] = result[col].astype(float).round(2)  
    
    
    return result


def fetch_closeprices(d):
    
    # create python cluster object to connect to your cassandra cluster (specify ip address of nodes to connect within your cluster)
    #cluster = Cluster([cassandra_host])
    cluster = cassandra_configs_cluster()
    session = cluster.connect('rohit')
    #logging.info('Using test_df keyspace')
    session.row_factory = pandas_factory
    session.default_fetch_size = None
    rows = session.execute("select key,symbol,close,prevclose,timestamp from cm_bhavcopy \
                           where timestamp='{}' and series='EQ' allow filtering;".format(d))
    rows = rows._current_rows
    
    # read corporate actions file for reading symbols from cassandra
    ca = pd.read_excel(master_dir+'Corporate_actions.xlsx')
    ca_factors = ca[['Date','Symbol','Factor']]
    ca_factors.dropna(inplace=True)  
    ca_factors.sort_values(by=['Date','Symbol'], inplace=True)
    ca_factors['Date'] = pd.to_datetime(ca_factors['Date'], dayfirst=True)
    ca_factors['Factor'] = ca_factors['Factor'].round(3)
    ca=ca[["Old_bloomcode","Old_symbol","New_bloomcode","New_symbol"]]
    ca.dropna(inplace=True)
    
    for i in range(0,len(ca)):
        rows=rows.replace(to_replace=ca["Old_symbol"][i], value=ca["New_symbol"][i], regex=True)
    
    
    result = corp_actions_factor(rows, ca_factors, 'timestamp')
    result["timestamp"]=result["timestamp"].dt.date
    result["timestamp"]=result["timestamp"].astype(str)
    
    return result[['symbol','close']].rename(columns={'symbol':'Symbol','close':'ClosePrice'})