import numpy as np 
import pandas as pd
import logging 
#from dateutil import parser
import time
from datetime import date, timedelta
import datetime
#import redis
import zlib
import os 
import warnings
warnings.filterwarnings("ignore")
import tarfile
import sector_calc
import smtplib
#from string import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import socket    
#import bhavcopy_data_reader
import cassandra_utility
import subprocess
import sys
from collections import OrderedDict


server = '172.17.9.149'; port = 25  # mailing server
MY_ADDRESS = 'KIEFNODataAnalytics@kotak.com'
cassandra_host_list = ["172.17.9.51"]



#redis_host = '10.223.104.61'
#redis_host = "localhost"

download_dir = "/tmp/"
master_dir = "/opt/Basis_project/Master/"
log_path = "/opt/Sectoral_trends/logs/"
data_dir = "/opt/Sectoral_trends/Data/"
dividend_dir = "/Dividend/"
lots_file_dir = "/REPORTING/"
lots_archive_dir = "/REPORTING/PR FILE_INDEX IISL/old files/"
contacts_dir = "/opt/Sectoral_trends/"


"""
data_dir = "D:\\Volumes_intraday_mailer\\linux\\Data\\"
#download_dir = "D:\\Volumes_intraday_mailer\\Download\\"
master_dir = "D:\\Master\\"
log_path = "D:\\Volumes_intraday_mailer\\"
"""

result_df = pd.DataFrame()
last_vwap_data = pd.DataFrame()
values_snapshot = pd.DataFrame()
columns_dict = OrderedDict([('Symbol','symbol'),('date','date'),('time','time'),('IsNifty','isnifty'),('Sector','sector'),('Type','type'),
                            ('VolumeTraded_fut_m1','volumetraded_fut_m1'),('VWAP_fut_m1','vwap_fut_m1'),('LTP_fut_m1','ltp_fut_m1'),('ClosePrice_fut_m1','closeprice_fut_m1'),
                            ('VolumeTraded_fut_m2','volumetraded_fut_m2'),('VWAP_fut_m2','vwap_fut_m2'),('LTP_fut_m2','ltp_fut_m2'),('ClosePrice_fut_m2','closeprice_fut_m2'),
                            ('VolumeTraded_fut_m3','volumetraded_fut_m3'),('VWAP_fut_m3','vwap_fut_m3'),('LTP_fut_m3','ltp_fut_m3'),('ClosePrice_fut_m3','closeprice_fut_m3'),
                            ('VolumeTraded_NSE','volumetraded_nse'),('VWAP_NSE','vwap_nse'),('LTP_NSE','ltp_nse'),('ClosePrice_NSE','closeprice_nse'),
                            ('VolumeTraded_BSE','volumetraded_bse'),('VWAP_BSE','vwap_bse'),('LTP_BSE','ltp_bse'),('ClosePrice_BSE','closeprice_bse'),
                            ('spread_ab','spread_ab'),('spread_bps','spread_bps'),('Dividend','dividend')])

#global_avg_df = pd.DataFrame()

logging.basicConfig(filename=log_path+"market_hourly_snaps_{}.log".format(datetime.datetime.now().date()),
                        level=logging.DEBUG,
                        format="%(asctime)s:%(levelname)s:%(message)s")


cassandra_obj = cassandra_utility.CassandraUtil(host = cassandra_host_list, username='read', 
                              password='read@123', keyspace='rohit')   # this object will be used for all cassandra operations
cassandra_obj.connect()
cassandra_obj.set_pandas_factory()



def redis_key_generator():
    '''Generate all the keys needed for computation over a period of day '''
    
    #keys = []
    timekeys = []
    a = datetime.datetime(1,1,1,9,5)
    
    for i in range(77):
        a = a + datetime.timedelta(minutes=5)
        timekeys.append("{}{}".format(('0'+str(a.hour) if len(str(a.hour))==1 else str(a.hour)),
                                      ( '0'+str(a.minute) if len(str(a.minute))==1 else str(a.minute))))
        
    return timekeys

def dateparse1(d):
    '''Func to parse dates'''    
    d = pd.to_datetime(d, dayfirst=True)    
    return d

      
# read holiday master
holiday_master = pd.read_csv(master_dir+'Holidays_2019.txt', delimiter=',',
                                 date_parser=dateparse1, parse_dates={'date':[0]})    
holiday_master['date'] = holiday_master.apply(lambda row: row['date'].date(), axis=1)  

def previous_working_day(d):
    '''Get previous wokring day'''
    
    d = d - datetime.timedelta(days=1)
    while  True:
            if d in holiday_master["date"].values:
                #print "Holiday : ",d
                d = d - datetime.timedelta(days=1)                
            else:
                return d    
            

def get_prev_nth_day(d,c):
    for i in range(0,c):
        prev=previous_working_day(d)
        d=prev
        #print d
    return d


def gen_filename(timekeys, d):
    '''Generate filenames'''
    
    #d = datetime.date.today() -datetime.timedelta(0)
    filename = []
    for timek in timekeys:
        filename.append( 'debug_log_mktdata_{}{}{}_{}.txt'.format(('0'+str(d.day) if len(str(d.day))==1 else str(d.day)),
                                                ('0'+str(d.month) if len(str(d.month))==1 else str(d.month)),
                                                str(d.year), timek ))
        
    return filename


def dateparse(row):
    '''Func to parse dates while reading ticker files'''
    d = row.split("+")[0]
    d = pd.to_datetime(d, format='%Y-%m-%d %H:%M:%S')
    return d

def get_contacts(filename):
    """
    Return two lists names, emails containing names and email addresses
    read from a file specified by filename.
    """

    emails = []
    # list of To and Cc contacts 
    with open(filename, mode='r') as contacts_file:
        for a_contact in contacts_file:
            emails.append(a_contact.split()[1:])
    return emails


def email_utility(emails, subject, message):
    
    '''Func to send mount error alert'''
    
    # get total recipients 
    rcpt = []
    for email in emails:
        for i in email:
            rcpt.append(i)   
    
    # set up the SMTP server
    s = smtplib.SMTP(host=server, port=port)    
    
    msg = MIMEMultipart()# create a message
    # setup the parameters of the message
    msg['From']=MY_ADDRESS
    msg['To']=','.join(emails[0])
    msg['Cc']=','.join(emails[1])
    msg['Subject']= subject
                  
    msg.attach(MIMEText('{}'.format(message),'plain'))        
    
    s.sendmail(MY_ADDRESS,rcpt,msg.as_string())

    s.quit()


def detect_mount_and_email():    
    
    failed_mounts = []
    for dir_name in [dividend_dir, lots_file_dir]:
        if os.path.ismount(dir_name) == False:
            print "Mount doesnt exist {} ".format(dir_name)
            failed_mounts.append(dir_name)
            
    if len(failed_mounts)>0:
        print "Mount error"
        email_utility(get_contacts(contacts_dir+"mount_alert_emails.txt"), 
                      '({}) Mount error Alert!'.format(socket.gethostbyname(socket.gethostname())), 
                      "Please check following mount dir \n\n{}".format('\n '.join(failed_mounts)) ) 

        logging.info("Mount error alert sent ")
        return -1
    else:
        return 1
            
            

    
def agg_values(grp):
    '''agg func weighted avearge on LTP sum of volume diff'''    
    
    return pd.Series({'VolumeTraded':np.max(grp['VolumeTraded']),
                      'Value':np.sum(grp['Value']) ,
                      'LTP':grp['LTP'].iloc[-1],
                      'ClosePrice':grp['ClosePrice'].iloc[-1] })
    
    
def read_dividend_input(h, process_d):  # read dividends set for that hour
    
    try:
        #dividend = pd.read_csv(r"\\172.17.9.21\Agent\Ojas Shah\Dividend\current_month_debug2.csv" )
        #dividend = pd.read_csv(dividend_dir+"current_month.csv")
        # read daily dividend file
        dividend=pd.DataFrame()
        try:
            dividend = pd.read_excel(dividend_dir+"Dividend List.xlsx", sheet_name='Div.Scrwise', skiprows=1)
        except Exception as e:
            print "Sheet name 'Div.Scrwise' not present/ Error {} \n\nReading default 2nd sheet".format(e)
            logging.info("Sheet name 'Div.Scrwise' not present/ Error {} \n\nReading default 2nd sheet".format(e))
            dividend = pd.read_excel(dividend_dir+"Dividend List.xlsx", sheet_name=1, skiprows=1)
        
        dividend = dividend.iloc[:,2:-3]
        dividend['EX-DIV DATE'] = pd.to_datetime(dividend['EX-DIV DATE'], errors='coerce')
        dividend.dropna(subset=['EX-DIV DATE'], inplace=True)
        dividend.iloc[:, :2] = dividend.iloc[:, :2].apply(lambda col: col.str.strip() if col.dtype=='object' else col) 
        dividend['EX-DIV DATE'] = dividend['EX-DIV DATE'].dt.date
        dividend = dividend[(dividend['EX-DIV DATE'] > process_d) & (dividend['MONTH'].str.startswith(process_d.strftime("%b").upper()))]
        dividend = dividend.ix[:, [0,4]]
        dividend.columns= ['Symbol','Dividend']
        dividend['Dividend'] = pd.to_numeric(dividend['Dividend'], errors='coerce' )
        dividend.dropna(subset=['Dividend'], inplace=True)

        
        logging.info("Dividend file successfully read; number of symbols present {}".format(len(set(dividend['Symbol']))))
        return dividend[['Symbol','Dividend']]
    
    except Exception as e:
        print "Error reading dividend file"
        logging.info("Error reading dividend file; Error {}".format(e))
    
    
    
    
  
    
def get_hourly_snapshot(result, pairmaster, etime, process_d):
    
    if result.empty==True:
        d =  pd.DataFrame(columns=list(columns_dict.keys()) )
        #d.set_index('Symbol', inplace=True)
        return d
        
    result.rename(columns={'vwap':'VWAP'}, inplace=True)
    result.drop(columns=['Exchange'], inplace=True)
    
    # get volume and VWAP prices for realted cash and futs
    
    curr_df = (pairmaster[['Symbol','FutCode_m1']].rename(columns={'FutCode_m1':'SecurityCode'}) ).merge(result,
              on=['Symbol','SecurityCode'], how='left')
    next_df = (pairmaster[['Symbol','FutCode_m2']].rename(columns={'FutCode_m2':'SecurityCode'}) ).merge(result,
              on=['Symbol','SecurityCode'], how='left')
    far_df = (pairmaster[['Symbol','FutCode_m3']].rename(columns={'FutCode_m3':'SecurityCode'}) ).merge(result,
             on=['Symbol','SecurityCode'], how='left')
    cash_nse = (pairmaster[['Symbol','NSECashCode']].rename(columns={'NSECashCode':'SecurityCode'}) ).merge(result,
               on=['Symbol','SecurityCode'], how='left')
    cash_bse = (pairmaster[['Symbol','BSECashCode']].rename(columns={'BSECashCode':'SecurityCode'}) ).merge(result,
               on=['Symbol','SecurityCode'], how='left')
    
       
    # structure for db
    final_curr_df = (curr_df.drop(columns=['SecurityCode']).merge(next_df.drop(columns=['SecurityCode']), on=['Symbol','date','time'],
                                 how='outer', suffixes=('_fut_m1','_fut_m2'))).merge( far_df.drop(columns=['SecurityCode']),
                                on=['Symbol','date','time'], how='outer').rename(columns={'VWAP':'VWAP_fut_m3',
                                   'VolumeTraded':'VolumeTraded_fut_m3','ClosePrice':'ClosePrice_fut_m3','LTP':'LTP_fut_m3'})
    final_curr_df.dropna( subset=final_curr_df.columns[1:], how='all', inplace=True)
    
    final_curr_df = final_curr_df.merge( cash_nse.drop(columns=['SecurityCode']).merge(cash_bse.drop(columns=['SecurityCode']),
                                                on=['Symbol','date','time'], how='outer',suffixes=('_NSE','_BSE')  ),
                                        on=['Symbol','date','time'], how='outer' )
    final_curr_df.dropna( subset=final_curr_df.columns[1:], how='all', inplace=True)
    
    final_curr_df = final_curr_df.merge(pairmaster[['Symbol','IsNifty','Sector','Type']], on='Symbol', how='left')
    #final_curr_df['ClosePrice'] = final_curr_df['ClosePrice_NSE']
    
    #final_curr_df = final_curr_df.iloc[ :, ~final_curr_df.columns.str.startswith("ClosePrice_") ] 
    
    # get dividend file to calc basis
    div_df = read_dividend_input(etime, process_d)
    
    final_curr_df = final_curr_df.merge( div_df, on='Symbol', how='left')
    final_curr_df['Dividend'] = final_curr_df['Dividend'].fillna(0)
    
    # spread abs and bps
    final_curr_df['spread_ab'] = final_curr_df['LTP_fut_m1'] - final_curr_df['LTP_NSE']
   
    final_curr_df.loc[final_curr_df['LTP_NSE']!=0,'spread_bps'] = (final_curr_df['spread_ab'] + \
                                                             final_curr_df['Dividend'] )*10000/(final_curr_df['LTP_NSE'])
    final_curr_df.loc[final_curr_df['LTP_NSE']==0,'spread_bps'] = 0
    
    
    final_curr_df[['VolumeTraded_fut_m1','VWAP_fut_m1','LTP_fut_m1','ClosePrice_fut_m1',
                                   'VolumeTraded_fut_m2','VWAP_fut_m2','LTP_fut_m2','ClosePrice_fut_m2',
                                   'VolumeTraded_fut_m3','VWAP_fut_m3','LTP_fut_m3','ClosePrice_fut_m3',
                                   'VolumeTraded_NSE','VWAP_NSE','LTP_NSE','ClosePrice_NSE',
                                   'VolumeTraded_BSE','VWAP_BSE','LTP_BSE','ClosePrice_BSE',
                                  'spread_ab','spread_bps']] = final_curr_df[['VolumeTraded_fut_m1','VWAP_fut_m1','LTP_fut_m1','ClosePrice_fut_m1',
                                   'VolumeTraded_fut_m2','VWAP_fut_m2','LTP_fut_m2','ClosePrice_fut_m2',
                                   'VolumeTraded_fut_m3','VWAP_fut_m3','LTP_fut_m3','ClosePrice_fut_m3',
                                   'VolumeTraded_NSE','VWAP_NSE','LTP_NSE','ClosePrice_NSE',
                                   'VolumeTraded_BSE','VWAP_BSE','LTP_BSE','ClosePrice_BSE',
                                  'spread_ab','spread_bps']].round(2)

    
    final_curr_df = final_curr_df[list(columns_dict.keys())]
    
    
    return final_curr_df
    
    
def dump_snapshot_data(result, process_d, etime):
    
    result[['VolumeTraded_fut_m1','VolumeTraded_fut_m2','VolumeTraded_fut_m3','VolumeTraded_NSE','VolumeTraded_BSE']] = result[['VolumeTraded_fut_m1',
                  'VolumeTraded_fut_m2','VolumeTraded_fut_m3','VolumeTraded_NSE','VolumeTraded_BSE']].fillna(0)
    result[['VolumeTraded_fut_m1','VolumeTraded_fut_m2','VolumeTraded_fut_m3','VolumeTraded_NSE','VolumeTraded_BSE']] = result[['VolumeTraded_fut_m1',
                  'VolumeTraded_fut_m2','VolumeTraded_fut_m3','VolumeTraded_NSE','VolumeTraded_BSE']].astype(int)
    
    
    # calc sectoral prices, volumes, basis trends
    sector_calc.sectoral_trends(result.copy(deep=True), process_d, etime, cassandra_obj)  # store in secotral table in db 
    logging.info("Sectoral table saved")
    
    # dump result in postgress db for every hourly snapshot
    cassandra_obj.session.execute("create table if not exists market_snapshot_data (symbol varchar,date date ,time varchar, \
                                IsNifty varchar,Sector varchar,Type varchar,VolumeTraded_fut_m1 int,VWAP_fut_m1 float,\
                                LTP_fut_m1 float,ClosePrice_fut_m1 float,VolumeTraded_fut_m2 int,VWAP_fut_m2 float,\
                                LTP_fut_m2 float,ClosePrice_fut_m2 float,VolumeTraded_fut_m3 int,VWAP_fut_m3 float,\
                                LTP_fut_m3 float,ClosePrice_fut_m3 float,VolumeTraded_NSE int,VWAP_NSE float,\
                                LTP_NSE float,ClosePrice_NSE float,VolumeTraded_BSE int,VWAP_BSE float,\
                                LTP_BSE float,ClosePrice_BSE float,spread_ab float,spread_bps float,\
                                Dividend float, primary key (symbol, date, time)) ;")
    
    result.to_csv(data_dir+'snapshotdata.csv', index=False)
    # call sh function to dump data
    if (sys.platform).startswith('win'):
        logging.info("Windows platform; dumping file via .bat ")
        os.system(data_dir+"snapshotdata.bat")
    else:                   
        os.putenv("filename", data_dir+'snapshotdata.csv')
        subprocess.call(data_dir+'snapshotdata.sh')
           
    print "{} rows dumped in db".format(len(result))
    logging.info("{} rows dumped in db".format(len(result)))
   
    
    
    
def get_volume_vwap( pairmaster, prices, stime, etime, process_d ):
    '''Func to return max of volume traded and mean of LTP for 5 sec ticker data'''   
    
    agg_main = time.time()
    print "Get futures data; start time {} , end time {}".format(stime, etime)
    logging.info("Get futures data; start time {} , end time {}".format(stime, etime))
    
    
    prices['date'] = prices['date'].dt.date
    
    # return empty df if empty 
    if prices.empty==True:
        d =  pd.DataFrame(columns=list(columns_dict.keys()))
        #d.set_index('Symbol', inplace=True)
        return d
    
    print "Length {} ".format(len(prices))
    logging.info("Length {} ".format(len(prices)))
    
    #prices.to_csv("ogdata.csv")
    # get Last hour volume tarded and vwap values 
    global last_vwap_data
    prices_columns = prices.columns.tolist()
    prices = prices.append(last_vwap_data, ignore_index=True, sort=True)
    
    
    prices_df = pd.DataFrame()
    for col in ['NSECashCode', 'BSECashCode', 'FutCode_m1', 'FutCode_m2', 'FutCode_m3']:
        prices_df = prices_df.append((pairmaster[['Symbol',col]].rename(columns={col:'SecurityCode'})).merge( prices ,
               on='SecurityCode', how='inner', suffixes=('_P','')) )
    
    prices_df['Symbol'] = prices_df['Symbol_P']  ; prices_df.drop(columns=['Symbol_P'], inplace=True)   
    
    prices_df = prices_df.merge(pairmaster, on='Symbol', how='left')
    print "Length {} ".format(len(prices_df))
    logging.info("Length {} ".format(len(prices_df)))
    
    
    
    result = pd.DataFrame()  # processing result after aggregation over 5s data 
    #global_df = pd.DataFrame()
    for index in [['NFO','FutCode_m1','FutCode_m2','FutCode_m3' ],['NSE','NSECashCode'], ['BSE','BSECashCode']]:
        
        print 'Aggregating over exchange {}, with secuirty code on {}'.format(index[0], index[1])
        logging.info('Aggregating over exchange {}, with secuirty code on {}'.format(index[0], index[1]))
        
        
        opti = prices_df   
        
        
        if index[0]=='NFO':              
            opti = opti[(opti['ExchangeSegment']==index[0]) & ( 
                    (opti['SecurityCode']==opti[index[1]]) | (opti['SecurityCode']==opti[index[2]]) | (opti['SecurityCode']==opti[index[3]]) )]   
                        
        else:
            opti = opti[(opti['ExchangeSegment']==index[0]) & (opti['SecurityCode']==opti[index[1]])]   
         
    
        opti.sort_values(by=['Symbol','SecurityCode','time'], inplace=True)
        
        print len(opti)
        logging.info(len(opti))
        opti['Volume'] = opti.groupby(['Symbol','SecurityCode'], sort=True)['VolumeTraded'].diff()   # get volume from volume traded till now   
        
        
        if etime==datetime.time(10,0):
            #opti.loc[str(opti['Volume'])=='nan', 'Volume'] = opti['VolumeTraded']
            opti['Volume'] = np.where(opti['Volume'].isnull(), opti['VolumeTraded'], opti['Volume'])     
            
            #opti = opti[ (opti['time']>= stime ) & (opti['time']<= etime)]   # filter on time         
            opti['Value'] = opti['LTP']*opti['Volume']
            
            # keep a trace of this values instance for next computation
            global values_snapshot
            temp = opti[['Symbol','SecurityCode','date','Value']].copy(deep=True) # copy of current instance of values
            temp = temp.groupby(by=['Symbol','SecurityCode','date'])['Value'].sum().reset_index()
            temp['time'] = etime
            values_snapshot = values_snapshot.append(temp, sort=True, ignore_index=True)
                        
            opti = opti.groupby(by=['Symbol','SecurityCode','date']).apply(lambda grp: agg_values(grp)).reset_index()
            
            # save lpt and vwap both
            opti['vwap'] = opti[['Value','VolumeTraded','LTP']].apply(
                            lambda row: row['Value']/row['VolumeTraded'] if row['VolumeTraded']!=0 else row['LTP'], axis=1 )
            opti = opti[['Symbol','SecurityCode','date','VolumeTraded','vwap','LTP','ClosePrice']]
            
        else:
            #opti.dropna(axis=0, subset=['Volume'], inplace=True)
            opti['Volume'] = opti['Volume'].fillna(0)
            #opti = opti[ (opti['time']>= stime ) & (opti['time']<= etime)]   # filter on time         
            opti['Value'] = opti['LTP']*opti['Volume']
            
            # fetch values from the last instance
            temp = opti[['Symbol','SecurityCode','date','Value']].copy(deep=True)   # copy of current instance of values
            temp = temp.groupby(by=['Symbol','SecurityCode','date'])['Value'].sum().reset_index()
            temp['time'] = etime
            
            
            global values_snapshot
            
            temp1 = values_snapshot.groupby(by=['Symbol','SecurityCode','date'])['Value'].sum().reset_index()
            temp1.rename(columns={'Value':'last_value'}, inplace=True)
            
            opti = opti.groupby(by=['Symbol','SecurityCode','date']).apply(lambda grp: agg_values(grp)).reset_index()
            opti = opti.merge(temp1, on=['Symbol','SecurityCode','date'], how='left' )
            opti['last_value'] = opti['last_value'].fillna(0)
            opti['vwap'] = opti[['Value','VolumeTraded','last_value','LTP']].apply(
                            lambda row: (row['Value'] + row['last_value'] )/row['VolumeTraded'] if row['VolumeTraded']!=0 else row['LTP'], axis=1 )
            opti = opti[['Symbol','SecurityCode','date','VolumeTraded','vwap','LTP','ClosePrice']]
            
            # update values instance
            values_snapshot = values_snapshot.append(temp,sort=True, ignore_index=True )      
        
    
        #opti.to_csv("debug_{}.csv".format(index[0]))
        
        #opti['time'] = opti['date'].dt.time.astype(str)
        opti['time'] = etime
        opti.sort_values(by=['Symbol','SecurityCode','time'], inplace=True) # sort for fill         
        opti['Exchange'] = index[0]    
        #opti.set_index(['Symbol','time'], inplace=True)
        result = result.append(opti)
    
    
    #result.to_csv('beforedata.csv')
    # create trace of vwap and volume traded for this hour
    temp = result.copy(deep=True)
    temp.drop(columns=['vwap'], inplace=True)
    temp.rename(columns={'Exchange':'ExchangeSegment'}, inplace=True)
    temp = temp[prices_columns]
    last_vwap_data = last_vwap_data.append(temp, ignore_index=True, sort=True)
    last_vwap_data = last_vwap_data.groupby(by=['Symbol','date','SecurityCode'], as_index=False).last()
    last_vwap_data = last_vwap_data[prices_columns]
    
    #global values_snpashot
    #values_snapshot.to_csv('values_snapshot.csv')
    check_mount()
    
    result = get_hourly_snapshot(result, pairmaster, etime, process_d)  # store in db
    
    dump_snapshot_data(result.copy(deep=True), process_d, etime)
    
    
    print 'Volume vwap processing func : ',time.time() - agg_main
    print 'DF length: ',len(result)
    logging.info('Volume vwap processing func : {}'.format(time.time() - agg_main))
    logging.info('DF length: {}'.format(len(result)))    
    
    

def file_reader(filename):
    # reads files and filters on time 
    
    cols = ['date','Symbol','QtyBuy int','QtyBuy_2','QtyBuy_3','QtyBuy_4','QtyBuy_5','Bid','Bid_2','Bid_3','Bid_4','Bid_5','offer',
        'Offer_2','Offer_3','Offer_4','Offer_5','QtySell','QtySell_2','QtySell_3','QtySell_4','QtySell_5','VolumeTraded',
        'OpenPrice','Ccy', 'LTP','NumberOfOrdersBuy','NumberOfOrdersBuy_2','NumberOfOrdersBuy_3','NumberOfOrdersBuy_4',
        'NumberOfOrdersBuy_5','NumberOfOrdersSell','NumberOfOrdersSell_2','NumberOfOrdersSell_3','NumberOfOrdersSell_4',
        'NumberOfOrdersSell_5','LowerCircuitLimit','UpperCircuitLimit','HighPrice','LowPrice','ClosePrice','LTT timestamp',
        'NetChangeIndicator','LTQ','LotSize','OI','SecurityCode','ExchangeSegment','TradingSymbol']   
    
    prices_df = pd.DataFrame()

    
    # untar files and then read
    #with tarfile.open(r"//172.17.9.141/Backup/Marketlog/"+"{}.tar.gz".format(filename)) as tar:
    #    tar.extractall(path=r"//172.17.9.141/Backup/Marketlog/")
         
    
    try:  
        print 'Processing : ',filename
        
        # read input file for every 5 sec data 
        prices_df = pd.read_csv(download_dir +"{}".format(filename),delimiter=',', engine='c'
                                , names=cols,skipinitialspace=True, low_memory=False )[['date','Symbol','VolumeTraded',
                                'LTP','ClosePrice','SecurityCode','ExchangeSegment']]
        
        prices_df['date'] = prices_df['date'].str.split('+',expand=True)
        prices_df['date'] = pd.to_datetime(prices_df['date'], format='%Y-%m-%d %H:%M:%S')            
        logging.info('Sucessfully read ticker file {}'.format(filename))
        
    except ValueError as ve:
        if prices_df.empty!=True:
            print "File content corrupt \nError: {}\nHead sample data\n {}".format(ve, prices_df.head(2))
            logging.error("File content corrupt \nError: {}\nHead data\n {}".format(ve, prices_df.head(2)))
            return pd.DataFrame()
        else:
            print "File empty \nError: {}".format(ve)
            logging.error("File empty \nError: {}".format(ve))
            
    except Exception as e :
        print 'No file with name {} / Error {} '.format(filename, e)
        logging.info('No file with name {} / Error {} '.format(filename, e))   
    

    # retain records between market hours and ignore rest
    if prices_df.empty==True:
        logging.error("Market data file read error, file is empty")
        return pd.DataFrame()
    prices_df['time'] = prices_df['date'].dt.time   
    #prices = prices_df[ (prices_df['time']>= starttime ) & (prices_df['time']<= endtime)]     
    #ignore_tf = prices_df[ ~((prices_df['time']>= starttime ) & (prices_df['time']< endtime)) ]   
    
    
    # ignore codes with long codes
    prices_df['SecurityCode'] = prices_df['SecurityCode'].astype(str)
    prices_df = prices_df[ ~(prices_df.SecurityCode.str.len() > 6 ) ]
    #prices = prices[(prices['Symbol']=='ACC') | (prices['Symbol']=='ADANIENT')]

    # cpnvert to numeric
    prices_df['SecurityCode'] = pd.to_numeric(prices_df['SecurityCode'], errors='coerce') 
    
    
    
    # delete the extracted file
    #os.remove(r"//172.17.9.141/Backup/Marketlog/"+"{}".format(filename))

    
    return prices_df
    

    
    
def ticker_generator(files, hourly_time_files, pairmaster):
    '''Func to read 5 min log utility file and generate 1 min ticker stats for volume traded and LTP for each symbol''' 
    
    global result_df; stime = datetime.time(9,15)
    
    for f in files:
        
        while not os.path.exists(download_dir+"{}".format(f) ):               
            print 'Resume after 10 secs'
            #logging.info('Resume after 10 secs')
            time.sleep(10)            
        else:     
            time.sleep(60)
            print "5 min file present; read file and append to global ...."
            start = time.time()
            temp = file_reader(f)
            if temp.empty==True:
                logging.error("Market data file issue, file is empty....")
                continue
            result_df = result_df.append(temp, ignore_index=True)  
            
            print 'Total 5 min data processing time : {}'.format(time.time()-start)
            logging.info('Total 5 min data processing time : {}'.format(time.time()-start))
                    
            # check if hourly file
            if f in hourly_time_files:
                print "Taking hourly snapshot"
                etime = datetime.time(int(f.split('_')[-1].split('.')[0][:2]), int(f.split('_')[-1].split('.')[0][2:]))
                process_d = datetime.date(int(f.split("_")[-2][4:]), int(f.split("_")[-2][2:4]), int(f.split("_")[-2][:2]))
                print stime, etime
                logging.info("Processing for {} - {}".format(stime, etime))
              
                print "Length of Market data {}".format(len(result_df))                       
                result_df.drop_duplicates(inplace=True, keep='last')
                print "Length of Market data {}".format(len(result_df))
                logging.info("Length of Market data {}".format(len(result_df)))
                
                #result_df = result_df[(result_df['time']>=stime) & (result_df['time']<=etime)]
                
                #result_df[result_df['Symbol']=='HDFC'].to_csv("data_etime{}".format(etime.hour))
                
                # process to get volumes, price and basis for all names
                get_volume_vwap( pairmaster, result_df.copy(deep=True), stime, etime, process_d )  # futures and cash data for all FNO symbols and index
                print "data processed and saved in db for date {} , time {}".format(process_d, str(etime))
                logging.info("data processed and saved in db for date {} , time {}".format(process_d, str(etime)))
    
                result_df = pd.DataFrame() # reset global variable to store only hourly data
    



def process_run_check(d):
    '''Func to check if the process should run on current day or not'''
          
    # check if working day or not 
    if len(holiday_master[holiday_master['date']==d])==0:
        # working day so run until bhavcopy is downloaded
        return 1
    
    elif len(holiday_master[holiday_master['date']==d])==1:
        logging.info('Holiday: skip for current date :{} '.format(d))
        print ('Holiday: skip for current date :{} '.format(d))        
        return -1

def check_mount():
    # check if all mount dir exist
    while True:
        if detect_mount_and_email()==-1:
            print "Mounting Error"
            logging.info("Mounting Error")
            time.sleep(240)
        else:
            print "Mount in place"
            logging.info("Mount in place")
            break
    
def load_data_correction(prev_d):
    '''Func to load bhavcopy data and snapshot data for correction '''
    
    #fno_bhavcopy = bhavcopy_data_reader.get_fno_bhavcopy(prev_d)
    fno_bhavcopy = cassandra_obj.read(query = "SELECT symbol,key,instrument,close FROM FNO_bhavcopy \
                                                  WHERE price_date = '{}' ALLOW FILTERING;".format(prev_d) )    
    fno_bhavcopy = fno_bhavcopy[fno_bhavcopy['instrument'].str.startswith('FUT')]
    fno_bhavcopy.sort_values(by=['symbol','key'], inplace=True)
    fno_bhavcopy.drop(columns=['instrument'], inplace=True)
    
    #index_bhavcopy = bhavcopy_data_reader.get_index_bhavcopy(prev_d)
    index_bhavcopy = cassandra_obj.read(query="select closingindexvalue,indexname,indexdate from index_bhavcopy \
                               where indexdate='{}' allow filtering;".format(prev_d))    
    index_bhavcopy = index_bhavcopy[index_bhavcopy['indexname'].isin(['NIFTY','BANKNIFTY'])]
    
    #cm_bhavcopy = bhavcopy_data_reader.get_cm_bhavcopy(prev_d)
    cm_bhavcopy = cassandra_obj.read(query="select key,timestamp,close,symbol from cm_bhavcopy \
                               where timestamp='{}' allow filtering;".format(prev_d))
    cm_bhavcopy = cm_bhavcopy[cm_bhavcopy['key'].str.endswith("_EQ")]
    
    #df = pd.read_csv(data_dir+"Snapshot_data.csv")
    #df['date'] = pd.to_datetime(df['date']); df['date'] = df['date'].dt.date
    #df = df[(df['date']==prev_d) & (df['time']==str(datetime.time(15,30))) ]
    df = cassandra_obj.read(query="select * from market_snapshot_data \
                            where date='{}' and time='{}' allow filtering;".format(prev_d, str(datetime.time(15,30))) )
    df.rename(columns={v: k for k, v in columns_dict.iteritems()}, inplace=True)
    df = df[list(columns_dict.keys())]
    df['date'] = df['date'].apply(lambda x: x.date())
        
    
    
    # get data from cassandra db for sectoral trends
    #sector = pd.read_csv(data_dir+"Sector_snap_data.csv")
    #sector['date'] = pd.to_datetime(sector['date']); sector['date'] = sector['date'].dt.date
    #sector = sector[(sector['date']==prev_d) & (sector['time']==str(datetime.time(15,30))) ]
    sector = cassandra_obj.read(query="select * from sectoral_snapshot_data \
                                where date='{}' and time='{}' allow filtering".format(prev_d, str(datetime.time(15,30))))    
    sector.rename(columns={'sector':'Sector','price_chg_percent':'Price_chg_percent','value':'Value',
                           'value_cash':'Value_cash','basis':'Basis'}, inplace=True)
    sector['date'] = sector['date'].apply(lambda x: x.date())
        
    
    # drop duplicates
    #sector.drop_duplicates(keep='last', inplace=True, subset=['Sector','date','time'])
    #df.drop_duplicates(keep='last', inplace=True, subset=['Symbol','date','time'])
    
    return fno_bhavcopy, index_bhavcopy, cm_bhavcopy, df, sector
    
    
    
    
def prev_close_basis_correction(d):
    
    prev_d = get_prev_nth_day(d,1)
    
    # get bhavcopy data for previous day; 
    # get data from snapshot_data and sector_snap for correction; only for closing timeframe 
    fno_bhavcopy, index_bhavcopy, cm_bhavcopy, df, sector = load_data_correction(prev_d)
    
    # correct LTP values with NSE provided bhavcopy
    for col in ['LTP_fut_m1','LTP_fut_m2','LTP_fut_m3']:
        df = df.merge(fno_bhavcopy[fno_bhavcopy['key'].str.endswith(col[-1])][['symbol','close']].rename(
                columns={'symbol':'Symbol'}), on=['Symbol'], how='left')
        #df.dropna(subset=['close'], inplace=True)
        df[col] = df['close']
        df.drop(columns=['close'], inplace=True)
    
    index_bhavcopy = index_bhavcopy[['closingindexvalue','indexname']].rename(columns = {'closingindexvalue':'close','indexname':'Symbol'})
    cm_bhavcopy = cm_bhavcopy[['close','symbol']].rename(columns={'symbol':'Symbol'})    
    cm_bhavcopy = cm_bhavcopy.append(index_bhavcopy, ignore_index=True, sort=True)
    
    df = df.merge(cm_bhavcopy, on=['Symbol'], how='left')
    df['LTP_NSE'] = df['close']
    df.drop(columns=['close'], inplace=True)
    
    # correct 15:30's spread basis
    # spread abs and bps
    df['spread_ab'] = df['LTP_fut_m1'].astype(float) - df['LTP_NSE'].astype(float)
   
    df.loc[df['LTP_NSE']!=0,'spread_bps'] = (df['spread_ab'].astype(float) + df['Dividend'].astype(float) )*10000/(df['LTP_NSE'].astype(float))
    df.loc[df['LTP_NSE']==0,'spread_bps'] = 0
    df[['ClosePrice_fut_m1','LTP_fut_m1','VWAP_fut_m1']] = df[['ClosePrice_fut_m1','LTP_fut_m1','VWAP_fut_m1']].astype(float)
    
    
    dump_snapshot_data(df.copy(deep=True), prev_d, datetime.time(15,30))
    logging.info("Data corrected for both sector and market snapshot data for prev day {} time 15:30".format(prev_d))
     
    
    
def main(nd):
    '''Func to read files, process and do scheduling of entire process'''
    # read yesterdays bhavcopy file 
    
    d = datetime.datetime.now().date() - datetime.timedelta(days=nd)
    
    if process_run_check(d) == -1:
       logging.info('Exit: Its an holiday.')
       return -1    
    
    logging.info("Start Process")
    # read master file for cash and fut codes 
    pairmaster = pd.read_csv(master_dir+'PairMaster.csv')
    
    # read masterdata for nifty and non nifty ssf symbols
    symbols = pd.read_csv(master_dir+"MasterData.csv")
    pairmaster = pairmaster.merge( symbols[['SYMBOL','IsNifty','Sector','Type']].rename(columns={'SYMBOL':'Symbol'}),
                                  on='Symbol', how='left' )
    
    '''
    expiry_dates_master = pd.read_csv(master_dir+'Expiry_dates_master.csv')
    expiry_dates_master['date'] = expiry_dates_master.apply(lambda row: pd.to_datetime(str(row['Date'])+row['Month']+str(row['Year'])).date(),
                       axis=1)
    expiry_dates_master = expiry_dates_master[expiry_dates_master['Expiry']=='E']['date'] '''
    
    logging.info("Read master files")
    # create redis keys
    timekeys = redis_key_generator()
    
    # get filenames to be processed over a time 
    files = gen_filename(timekeys, d)
    hourly_time_files = [ f for f in files if f.endswith("00.txt") ] + [files[-1]]
    
            
    check_mount()
    
    # correct previous days close prices for all futures, cash and rectify basis for 15:30
    prev_close_basis_correction(d)
    logging.info("Previous day LTP and Basis correction done in data \n process for today")
    
    start = time.time()
    ticker_generator(files, hourly_time_files, pairmaster)           
                
    print 'Total data processing time : {}'.format(time.time()-start)
    logging.info('Total data processing time : {}'.format(time.time()-start))
    
 
    


if __name__ == '__main__':
    main(0)   # set date range here; 0 indicates current date
    logging.info("End of the process for the day")


# //172.17.9.141/Archive_Data/MarketdataAprMay/
