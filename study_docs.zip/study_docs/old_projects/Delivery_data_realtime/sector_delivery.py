# -*- coding: utf-8 -*-
"""
Created on Wed May 13 20:14:13 2020

@author: krishna
"""
import os
import pandas as pd
import zipfile
import numpy as np
import datetime
import fetch_cassandra_closeprices
#data_dir = "D:\\Volumes_intraday_mailer\\Data\\"
#from collections import OrderedDict

def get_bod_lot_file(d):
    
    # read open position file from network drive and read bod file
    date=d
    lots = pd.DataFrame()
    for i in range(5):
        if os.path.exists(r"\\172.17.9.22\Users2\backoffice\Derv\189 REPORTING\PR FILE_INDEX IISL\NIFTY_500_{}{}{}.zip".format(
                d.year,'0{}'.format(d.month) if len(str(d.month))==1 else d.month , d.day)):
            zf = zipfile.ZipFile(r"\\172.17.9.22\Users2\backoffice\Derv\189 REPORTING\PR FILE_INDEX IISL\NIFTY_500_{}{}{}.zip".format(d.year,
                                               '0{}'.format(d.month) if len(str(d.month))==1 else d.month, d.day))
            
            lots = pd.read_csv(zf.open(''.join([ f for f in zf.namelist() if f.startswith('bod') and f.endswith('.csv') ]) ))
            
            break
        else:
            d = d - datetime.timedelta(days=1)
        
    d=date
    # if not find inside old files 
    if lots.empty==True:
        print 'Looking backdated files'
        for i in range(200):
            print d
            if os.path.exists(r"\\172.17.9.22\Users2\backoffice\Derv\189 REPORTING\PR FILE_INDEX IISL\old files\NIFTY_500_{}{}{}.zip".format(
                d.year,'0{}'.format(d.month) if len(str(d.month))==1 else d.month , d.day)):
                
                zf = zipfile.ZipFile(r"\\172.17.9.22\Users2\backoffice\Derv\189 REPORTING\PR FILE_INDEX IISL\old files\NIFTY_500_{}{}{}.zip".format(
                d.year,'0{}'.format(d.month) if len(str(d.month))==1 else d.month , d.day))
                
                lots = pd.read_csv(zf.open(''.join([ f for f in zf.namelist() if f.startswith('bod') and f.endswith('.csv') ]) ))
                
                break
            else:
                d=d-datetime.timedelta(days=1)           
            
    lots = lots[lots['SERIES']=='EQ'][['SYMBOL','ISSUE_CAP','INVESTIBLE_FACTOR']].rename(columns={'SYMBOL':'Symbol'})
    
    return lots



def sectoral_delivery(df, d, prev_d, t, symbol_list):    
    # calc sectoral price , value and basis trends for hourly snap
    
    print "Calc sectoral delivery for {} {} ".format(str(d), str(t))
    # read lots file
    lots = get_bod_lot_file(d)
    lots = symbol_list.merge(lots, on=['Symbol'], how='left')
    lots.dropna(subset=['Sector'], inplace=True)
    # get prev close prices
    close = fetch_cassandra_closeprices.fetch_closeprices(prev_d)
    lots = lots.merge(close, how='left', on='Symbol')
    
    # sector wise value change
    sector_value = df['Value'].copy(deep=True)
    sector_value = sector_value.iloc[:, ~sector_value.columns.str.endswith("_Avg_10")].reset_index()
    sector_value = sector_value.merge(lots[['Symbol','Sector']], on='Symbol', how='left')
    sector_value.dropna(how='any', inplace=True)
    sector_value = sector_value.groupby(by=['Sector'], as_index=False)[['Value_'+str(t.hour), 'Value_'+str(t.hour)+'_Avg_20']].sum()  
    sector_value['PctChg (20D)'] = sector_value.apply(lambda row: (row['Value_'+str(t.hour)] - row['Value_'+str(t.hour)+'_Avg_20'])/row['Value_'+str(t.hour)+'_Avg_20']*100 \
                                    if row['Value_'+str(t.hour)+'_Avg_20']!=0 else 0, axis=1)
    
    sector_value.columns = ['Sector','Value <br> (INR Cr)','Value_Avg_20 <br> (INR Cr)','PctChg (20D)']
    sector_value[['Value <br> (INR Cr)','Value_Avg_20 <br> (INR Cr)','PctChg (20D)']]=sector_value[['Value <br> (INR Cr)','Value_Avg_20 <br> (INR Cr)','PctChg (20D)']].round(2)
    # sector wise DQ change
    sector_DQ = df['DQ'].copy(deep=True)[['PctChg (20D)']].reset_index()
    sector_DQ = sector_DQ.merge(lots, on='Symbol', how='left')  
    sector_DQ.dropna(subset=['ISSUE_CAP','INVESTIBLE_FACTOR'], inplace=True)
    sector_DQ['Float Market Cao'] = sector_DQ['ISSUE_CAP']*sector_DQ['INVESTIBLE_FACTOR']*sector_DQ['ClosePrice']
      
    sectorwise_sum = sector_DQ[['Sector','Float Market Cao']].groupby(by='Sector',as_index=False)['Float Market Cao'].sum()
    sectorwise_sum.rename(columns={'Float Market Cao':'sector_sum'}, inplace=True)
    sector_DQ = sector_DQ.merge(sectorwise_sum, on='Sector', how='left' )
    sector_DQ.loc[sector_DQ['sector_sum']!=0, 'weight'] = sector_DQ['Float Market Cao']/sector_DQ['sector_sum']    
    sector_DQ.loc[sector_DQ['sector_sum']==0, 'weight'] = 0
    
    sector_DQ = sector_DQ.groupby(by=['Sector'])[['PctChg (20D)','weight']].apply(
                    lambda grp: pd.Series({'DQ_PctChg (20D)': round(np.dot(grp['weight'], grp['PctChg (20D)']),2)})).reset_index()
       
    sector_result = sector_DQ.merge(sector_value, on='Sector', how='inner')
      
    return sector_result
    
       