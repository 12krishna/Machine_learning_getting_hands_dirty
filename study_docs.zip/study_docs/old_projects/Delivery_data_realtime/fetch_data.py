# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 19:30:29 2021

@author: krishna
"""

import pandas as pd
import os
import datetime, time

input_dir = r"\\172.17.9.43\Fno_analytics\Security delivery position"

d=datetime.datetime.now().date()
df=pd.DataFrame()
for file_prefix in ['BSE_delivery', 'NSE_delivery']:
    temp = pd.read_csv(os.path.join(input_dir, file_prefix+"_{}.txt".format(d)))
    temp['Exchange'] = file_prefix.split("_")[0]
    df = df.append(temp, ignore_index=True)
    
df = df[df['traded_time'].isin(['15:00:00','16:00:00'])]
df = df[['Exchange','Symbol','traded_date','traded_time','DQ','QT','pc_DQ_TQ','avg_price']]
df.to_excel("deliverydata.xlsx", index=False)

